# Finding a brand for Daedalus
![](img/2017-04-26-finding-a-brand-for-daedalus.002.png) 26 April 2017![](img/2017-04-26-finding-a-brand-for-daedalus.002.png)[ Richard Wild](tmp//en/blog/authors/richard-wild/page-1/)![](img/2017-04-26-finding-a-brand-for-daedalus.003.png) 6 mins read

![](img/2017-04-26-finding-a-brand-for-daedalus.004.png)[ Finding a brand for Daedalus - Input Output](https://ucarecdn.com/82a6bef9-c159-4da4-96f1-254a930d738f/-/inline/yes/ "Finding a brand for Daedalus - Input Output")

![Richard Wild](img/2017-04-26-finding-a-brand-for-daedalus.005.png)[](tmp//en/blog/authors/richard-wild/page-1/)
### [**Richard Wild**](tmp//en/blog/authors/richard-wild/page-1/)
Creative Director

Creative

- ![](img/2017-04-26-finding-a-brand-for-daedalus.006.png)[](https://uk.linkedin.com/in/richard-wild-a0552026 "LinkedIn")
- ![](img/2017-04-26-finding-a-brand-for-daedalus.007.png)[](https://twitter.com/IOHK_Richard "Twitter")

![Finding a brand for Daedalus](img/2017-04-26-finding-a-brand-for-daedalus.008.jpeg)

Just who was Daedalus? It was the first of many questions the design team had to answer when we started work to find a logo for the [digital wallet](http://daedaluswallet.io/ "Daedalus wallet") that will store the Ada cryptocurrency. Daedalus is an unusual name. We were in Riga, on an IOHK working sprint last autumn, when we got the brief to develop the visual identity and brand for the wallet, so the first thing we did was some [research online](https://en.wikipedia.org/wiki/Daedalus "Daedalus, Wikipedia.org").

Chỉ là ai là Daedalus?
Đó là câu hỏi đầu tiên trong số nhiều câu hỏi mà nhóm thiết kế phải trả lời khi chúng tôi bắt đầu làm việc để tìm logo cho [ví kỹ thuật số] (http://daedaluswallet.io/ "ví Daedalus") sẽ lưu trữ tiền điện tử Ada.
Daedalus là một cái tên bất thường.
Chúng tôi đã ở Riga, trên một cuộc chạy nước rút làm việc của IOHK vào mùa thu năm ngoái, khi chúng tôi có được bản tóm tắt để phát triển bản sắc trực quan và thương hiệu cho ví, vì vậy điều đầu tiên chúng tôi đã làm là một số [nghiên cứu trực tuyến] (https: //en.wikipedia.
org/wiki/daedalus "daedalus, wikipedia.org").

It turns out that the name was chosen with good reason for a cryptocurrency wallet. An important figure in Greek mythology, Daedalus was the father of Icarus, a great artist, an innovatorâ€¦ as well as the creator of the labyrinth that kept the minotaur forever captive.\_

Hóa ra cái tên được chọn với lý do chính đáng cho ví tiền điện tử.
Một nhân vật quan trọng trong thần thoại Hy Lạp, Daedalus là cha đẻ của Icarus, một nghệ sĩ vĩ đại, một nhà đổi mới - cũng như người tạo ra mê cung giữ cho Minotaur mãi mãi bị giam cầm. \ _

IOHK wants the wallet it is creating to be the best cryptocurrency wallet out there. Not just a place to store, send and receive cryptocurrency (the first of which it will hold is Ada) but a place where you can later access plug-ins and other developer tools/SDKs, anything from managing your mortgage to splitting a bill between people. The vision is that it will become a platform full of applications, and be as important a product as Internet Explorer was for Microsoft.\_

Iohk muốn ví mà nó đang tạo ra để trở thành ví tiền điện tử tốt nhất hiện có.
Không chỉ là một nơi để lưu trữ, gửi và nhận tiền điện tử (nơi đầu tiên nó sẽ giữ là ADA) mà là một nơi mà sau này bạn có thể truy cập các trình cắm và các công cụ phát triển khác
Mọi người.
Tầm nhìn là nó sẽ trở thành một nền tảng đầy đủ các ứng dụng và là một sản phẩm quan trọng như Internet Explorer dành cho Microsoft. \ _

The creative team needed to find an identity that would connect to that vision, to the meaning behind the name Daedalus and his story, and to what IOHK is as a company and the technology it builds.\_

Nhóm sáng tạo cần tìm một danh tính sẽ kết nối với tầm nhìn đó, với ý nghĩa đằng sau cái tên Daedalus và câu chuyện của anh ấy, và với những gì Iohk là một công ty và công nghệ mà nó xây dựng.

We got together to discuss it and an idea came out.\_

Chúng tôi đã cùng nhau thảo luận về nó và một ý tưởng đã xuất hiện. \ _

According to the myth, the minotaur never escapes the maze â€“ thatâ€™s how good a craftsman Daedalus was.\_

Theo huyền thoại, Minotaur không bao giờ thoát khỏi mê cung - đó là một người thợ thủ công tốt như thế nào. \ _

We argue creatively that the minotaur is your money, or your digital identity. The minotaur is forever held in an infinite prison where only you control your keys. We have a lot of clever cryptography powering the security of the wallet, and like the minotaur in his maze, your money will never be able to escape our wallet, so Daedalus represents our expertise in security, and in building methodically and securely.\_

Chúng tôi lập luận một cách sáng tạo rằng Minotaur là tiền của bạn, hoặc bản sắc kỹ thuật số của bạn.
Minotaur mãi mãi được giữ trong một nhà tù vô hạn, nơi chỉ bạn điều khiển chìa khóa của mình.
Chúng tôi có rất nhiều mật mã thông minh cung cấp năng lượng cho an ninh của ví, và giống như Minotaur trong mê cung của anh ấy, tiền của bạn sẽ không bao giờ có thể thoát khỏi ví của chúng tôi, vì vậy Daedalus đại diện cho chuyên môn của chúng tôi về bảo mật và xây dựng một cách có phương pháp và an toàn. \ _

[Tomas Vrana](tmp//en/team/tomas-vrana/ "Tomas Vrana, IOHK profile") and [Alexander Rukin](tmp//en/team/alexander-rukin/ "Alexander Rukin, IOHK profile"), both part of the design team, came up with some early concepts. Among many different designs, Tom produced a minotaur; Alexander came up with a contemporary â€œDâ€ design. They came up with creative sketches and drawings, trying to gauge how best to approach the form and the function of the logo. Some of their early designs are below.

.
Cả hai phần của nhóm thiết kế, đã đưa ra một số khái niệm ban đầu.
Trong số nhiều thiết kế khác nhau, Tom đã sản xuất một Minotaur;
Alexander đã đưa ra một thiết kế đương đại - D -€.
Họ đã đưa ra các bản phác thảo và bản vẽ sáng tạo, cố gắng đánh giá cách tốt nhất để tiếp cận hình thức và chức năng của logo.
Một số thiết kế ban đầu của họ dưới đây.

![](img/2017-04-26-finding-a-brand-for-daedalus.009.jpeg) Ribbon variant

![](img/2017-04-26-finding-a-brand-for-daedalus.009.jpeg) Flat maze variant

![](img/2017-04-26-finding-a-brand-for-daedalus.009.jpeg) Ribbon variant

![](img/2017-04-26-finding-a-brand-for-daedalus.009.jpeg) Origami Minotaur variant

![](img/2017-04-26-finding-a-brand-for-daedalus.009.jpeg) Gothic â€œDâ€ variant

![](img/2017-04-26-finding-a-brand-for-daedalus.009.jpeg) Minotaur variant

Then we threw open the design challenge to a competition, connecting to a community of designers to offer their solutions. This would provide us with a wealth of ideas and give us interesting feedback. We had about 100 entries from graphic designers, ranging from the bad, to the good, to the funny. There were solid corporate identities, also very creative executions. There were lots of designs based on the letter â€œDâ€. And lots based on keys (with a nod to public key cryptography). However, that was too obvious. We are a crypto wallet, yes we have keys. A simple key in a logo didnâ€™t covey a strong brand message, it didnâ€™t set us apart. None was quite right.\_

Sau đó, chúng tôi đã mở thử thách thiết kế cho một cuộc thi, kết nối với một cộng đồng các nhà thiết kế để đưa ra các giải pháp của họ.
Điều này sẽ cung cấp cho chúng tôi rất nhiều ý tưởng và cung cấp cho chúng tôi phản hồi thú vị.
Chúng tôi đã có khoảng 100 mục từ các nhà thiết kế đồ họa, từ xấu, đến tốt, đến hài hước.
Có những bản sắc công ty vững chắc, cũng thực hiện rất sáng tạo.
Có rất nhiều thiết kế dựa trên bức thư - œdâ €.
Và rất nhiều dựa trên các khóa (với một cái gật đầu với mật mã khóa công khai).
Tuy nhiên, điều đó là quá rõ ràng.
Chúng tôi là một ví tiền điện tử, vâng, chúng tôi có chìa khóa.
Một chìa khóa đơn giản trong logo đã không nhận ra một thông điệp thương hiệu mạnh mẽ, nó đã không khiến chúng ta khác biệt.
Không có gì hoàn toàn đúng. \ _

We were looking for something that would connect to the Daedalus story and have a huge potential for creative story telling in being a brand we could develop.\_

Chúng tôi đang tìm kiếm một cái gì đó sẽ kết nối với câu chuyện Daedalus và có một tiềm năng lớn để kể chuyện sáng tạo khi trở thành một thương hiệu mà chúng tôi có thể phát triển. \ _

So we updated the brief and asked the designers to focus on the story of Daedalus. There were about 30 entries this time. A maze in the shape of a key was good, but not excellent. And there were lots of minotaurs. On some, the execution was not great. There was one that looked like a pixelated deer.\_

Vì vậy, chúng tôi đã cập nhật bản tóm tắt và yêu cầu các nhà thiết kế tập trung vào câu chuyện của Daedalus.
Có khoảng 30 mục lần này.
Một mê cung trong hình dạng của một chìa khóa là tốt, nhưng không xuất sắc.
Và có rất nhiều minotaur.
Trên một số người, việc thực hiện không tuyệt vời.
Có một cái trông giống như một con nai pixel. \ _

The one we finally chose, with the help of IOHKâ€™s two founders, was by a designer called Zahidul Islam. Itâ€™s contemporary, it feels modern and fresh yet connects to a very old story. It has the minotaur. Itâ€™s a well crafted form, itâ€™s balanced, and yet still has the maze motif in it â€“ it reflects the identity of our brand.\_

Người cuối cùng chúng tôi đã chọn, với sự giúp đỡ của hai người sáng lập của Iohk, là bởi một nhà thiết kế tên là Zahidul Hồi giáo.
Đó là đương đại, nó cảm thấy hiện đại và mới mẻ nhưng kết nối với một câu chuyện rất cũ.
Nó có minotaur.
Đó là một hình thức được chế tạo tốt, nó cân bằng, nhưng vẫn có họa tiết mê cung trong đó - nó phản ánh danh tính của thương hiệu của chúng tôi.

![](img/2017-04-26-finding-a-brand-for-daedalus.010.jpeg)

There was one issue, it was quite complex, which meant it didnâ€™t work at smaller sizes. So we worked with the designer to develop a brand hierarchy â€“ which comprises a primary, secondary and tertiary form for the identity to be used in various situations as the rules dictate.\_Below are the primary, secondary and tertiary images, each with successively less complexity.

Có một vấn đề, nó khá phức tạp, điều đó có nghĩa là nó không hoạt động ở các kích thước nhỏ hơn.
Vì vậy, chúng tôi đã làm việc với nhà thiết kế để phát triển một hệ thống phân cấp thương hiệu - bao gồm một hình thức chính, phụ và cấp ba để nhận dạng được sử dụng trong các tình huống khác nhau như các quy tắc chỉ ra.
liên tiếp ít phức tạp hơn.

![](img/2017-04-26-finding-a-brand-for-daedalus.011.jpeg)

The primary logo will be the larger formats, for example to be used on T-shirts, or on main focal areas such as loading screens. (We have a plan to develop the identity, to make it a â€œlivingâ€ brand that is dynamic, so you see it moving if you have to wait for the screen to load for instance.)

Logo chính sẽ là các định dạng lớn hơn, ví dụ được sử dụng trên áo phông hoặc trên các khu vực tiêu cự chính như màn hình tải.
.

The secondary logo will be more of a symbol and used at smaller sizes. Some of the complexity has been removed, and it will be used if the requirements are for 64 pixels or smaller. And then we produced a tiny icon, to be used for example as a security feature on paper wallets.

Logo thứ cấp sẽ là một biểu tượng nhiều hơn và được sử dụng ở các kích thước nhỏ hơn.
Một số độ phức tạp đã được loại bỏ và nó sẽ được sử dụng nếu các yêu cầu dành cho 64 pixel hoặc nhỏ hơn.
Và sau đó chúng tôi đã tạo ra một biểu tượng nhỏ, được sử dụng làm tính năng bảo mật trên ví giấy.

![](img/2017-04-26-finding-a-brand-for-daedalus.012.jpeg)

![](img/2017-04-26-finding-a-brand-for-daedalus.012.jpeg)

The colours you see might change. The colour palette of the brand has only black and green in it now.

Màu sắc bạn nhìn thấy có thể thay đổi.
Bảng màu của thương hiệu chỉ có màu đen và màu xanh lá cây trong đó.

So why did we go to all this effort over five months?

Vậy tại sao chúng ta lại đi đến tất cả nỗ lực này trong năm tháng?

Behind the Daedalus wallet is so much time, money, skill and effort. You wouldnâ€™t want to represent all that hard work with a mark that is unconsidered, or one that lacks capacity to carry the story of Daedalus. You want to bring enigma, some creation to the symbol that represents your quest. This is about more than a platform, it is a brand and about building brand allegiance. It has to stand out, be different and make people think of you. This brand has a lot of runway, a lot of potential for development creatively. The design may change as the brand evolves, but the current identity will scale and develop into something wonderful from this point on.\_

Đằng sau ví Daedalus là rất nhiều thời gian, tiền bạc, kỹ năng và nỗ lực.
Bạn sẽ không muốn đại diện cho tất cả những công việc khó khăn đó với một dấu hiệu không bị ảnh hưởng, hoặc một người thiếu khả năng mang câu chuyện về Daedalus.
Bạn muốn mang lại bí ẩn, một số sáng tạo cho biểu tượng đại diện cho nhiệm vụ của bạn.
Đây là về nhiều hơn một nền tảng, nó là một thương hiệu và về việc xây dựng trung thành thương hiệu.
Nó phải nổi bật, khác biệt và khiến mọi người nghĩ về bạn.
Thương hiệu này có rất nhiều đường băng, rất nhiều tiềm năng để phát triển một cách sáng tạo.
Thiết kế có thể thay đổi khi thương hiệu phát triển, nhưng danh tính hiện tại sẽ mở rộng và phát triển thành một thứ gì đó tuyệt vời từ thời điểm này. \ _

## **Attachments**

## ** tệp đính kèm **

![](img/2017-04-26-finding-a-brand-for-daedalus.004.png)[ Finding a brand for Daedalus - Input Output](https://ucarecdn.com/82a6bef9-c159-4da4-96f1-254a930d738f/-/inline/yes/ "Finding a brand for Daedalus - Input Output")

