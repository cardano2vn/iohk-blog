# A trip to Malta and a Grothendieck milestone
![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.002.png) 18 April 2017![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.003.png) 6 mins read

![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.004.png)[ A trip to Malta and a Grothendieck milestone - Input Output](https://ucarecdn.com/0aebde3c-6dca-4790-bee7-620e40838033/-/inline/yes/ "A trip to Malta and a Grothendieck milestone - Input Output")

![Jeremy Wood](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

Last Monday should have been particularly jarring given the recent excitement. However, it was anything but. Sunlight was flooding the back garden and all the small birds of the neighborhood came together to perform an impromptu concert at maximum volume. I could hear them clearly through the double glazing. Spring had sprung in Dublin. And Iâ€™d just come back from Malta talking [Ethereum](tmp//en/projects/ethereum-classic/ "Ethereum Classic"), [Cardano](tmp//en/projects/cardano/ "Cardano"), blockchain, crypto, functional languages, goal management and a ton of other cool stuff. Life is good.

Thứ Hai tuần trước nên đặc biệt chói tai với sự phấn khích gần đây.
Tuy nhiên, nó là bất cứ điều gì nhưng.
Ánh sáng mặt trời tràn ngập khu vườn phía sau và tất cả những con chim nhỏ của khu phố đã cùng nhau thực hiện một buổi hòa nhạc đầy ngẫu hứng với khối lượng tối đa.
Tôi có thể nghe thấy chúng rõ ràng qua kính đôi.
Mùa xuân đã xuất hiện ở Dublin.
Và tôi vừa trở về từ Malta Talking [Ethereum] (TMP // EN/Project/Ethereum-Classic/"Ethereum Classic"), [Cardano] (TMP // EN/Project/Cardano/"Cardano"),
Blockchain, tiền điện tử, ngôn ngữ chức năng, quản lý mục tiêu và rất nhiều thứ tuyệt vời khác.
Cuộc sống là tốt đẹp.

It was my first time attending the [Financial Cryptography and Data Security conference](http://fc17.ifca.ai/ "Financial Cryptography and Data Security conference"). The conference isÂ a week-long annual event for cryptography as applied to finance. This year,Â IOHK's chief scientistÂ [Aggelos Kiayias](tmp//en/team/aggelos-kiayias/ "Aggelos Kiayias, IOHK profile") put a great programme of speakers together. Instantly recognizable figures from the crypto community attended â€“ Adam Back, Emin GÃ¼n Sirer, Vitalik Buterin and many more. IOHK researchers attended and it was great to see people who may only know each other through twitter feeds and published papers get to speak to each other.

Đây là lần đầu tiên tôi tham dự [Hội nghị về mật mã và bảo mật dữ liệu tài chính] (http://fc17.ifca.ai/ "Hội nghị về mật mã và bảo mật dữ liệu tài chính").
Hội nghị là một sự kiện hàng năm kéo dài một tuần cho mật mã như được áp dụng cho tài chính.
Năm nay, nhà khoa học trưởng của Iohk [Aggelos Kiayias] (TMP // EN/Team/Aggelos-Kiayias/"Aggelos Kiayias, hồ sơ IOHK") Đặt một chương trình loa tuyệt vời với nhau.
Các nhân vật có thể nhận ra ngay lập tức từ cộng đồng tiền điện tử đã tham dự - Adam Adam trở lại, Emin Gã Sirer, Vitalik Buterin và nhiều hơn nữa.
Các nhà nghiên cứu IOHK đã tham dự và thật tuyệt khi thấy những người chỉ có thể biết nhau thông qua các nguồn cấp dữ liệu Twitter và các bài báo được xuất bản có thể nói chuyện với nhau.

I hope and presume this conference has generated many fine and detailed articles on [Coindesk](http://www.coindesk.com/building-blockchain-researchers-arent-giving-internet-sized-ideas/ "Building the blockchain") and beyond. This won't be one of them. Particular highlights for me were listening to MIT professor and cryptography pioneer [Silvio Micali](http://www.coindesk.com/scalable-blockchain-consensus-turing-award-winner-thinks-hes-got-solution/ "Silvio Micaliâ€™s Algorand") speak about the Algorand protocol and the conscious decision to keep incentives out of the equation. That instantly generated a little controversy and is going to need a long second look.Â 

Tôi hy vọng và cho rằng hội nghị này đã tạo ra nhiều bài viết tốt và chi tiết về [Coindesk] (http://www.coindesk.com/building-blockchain-researchers-arent-giving-intert-sized-ideas/"xây dựng blockchain")
và hơn thế nữa.
Đây sẽ không phải là một trong số họ.
Những điểm nổi bật đặc biệt đối với tôi là lắng nghe Giáo sư MIT và Cryptography Pioneer [Silvio Micali] (http://www.coindesk.com/scalable-blockchain-đồng bộ
Algorand ") nói về giao thức Algorand và quyết định có ý thức để giữ các ưu đãi ra khỏi phương trình.
Điều đó ngay lập tức tạo ra một cuộc tranh cãi nhỏ và sẽ cần một cái nhìn dài thứ hai.

[Dmitry Meshkov, IOHK researcher](tmp//en/team/dmitry-meshkov/ "Dmitry Meshkov, IOHK profile"), presented [Improving Authenticated Dynamic Dictionaries, with Applications to Cryptocurrencies](tmp//en/research/papers/#PIZ7V323 "IOHK Research Paper")Â which is of particular interest to [Team Grothendieck](https://ethereumclassic.github.io/blog/2016-12-12-TeamGrothendieck/ "Grothendieck team") as we have wrestled with our implementation of the "Modified Merkle Patricia Trie" as specified in the original yellow paper. In all its forms itâ€™s a clever idea â€“ being able to move forward and back through the state by memorizing a root hash and being able to show tries are equivalent based on the equivalence of their root hashes. Dmitry et al have a scala implementation, and if I heard Vitalik Buterin correctly (he commented after the presentation) he suggested there might be room for improvement on the original implementation, so there are possibilities for enhancements there.

.
#PIZ7V323 "Tài liệu nghiên cứu IOHK") Â được đặc biệt quan tâm đối với [nhóm Grothendieck] (https://ethereumClassic.github.io/blog/2016-12-12-PeamGrothendieck/ "
Việc chúng tôi thực hiện "Trie Merkle Patricia đã được sửa đổi" như được chỉ định trong giấy vàng gốc.
Trong tất cả các hình thức của nó, đó là một ý tưởng thông minh - việc có thể tiến lên và quay trở lại trạng thái bằng cách ghi nhớ một hàm băm gốc và có thể hiển thị các thử nghiệm tương đương dựa trên sự tương đương của băm gốc của chúng.
Dmitry và cộng sự có một triển khai Scala, và nếu tôi nghe Vitalik Buterin chính xác (anh ấy nhận xét sau khi trình bày), anh ấy đề nghị có thể có chỗ để cải thiện việc thực hiện ban đầu, vì vậy có khả năng cải tiến ở đó.

The conference was good, but it had some stiff competition from all the fun I had and everything I learned from mixing with other IOHK employees. IOHK employees usually work remotely but for more than a week almost 40 people gathered in Malta, who had traveled from far flung places like Osaka, St. Petersburg and California, including IOHK founders [Jeremy Wood](tmp//en/team/jeremy-wood/ "Jeremy Wood, IOHK profile") and [Charles Hoskinson](tmp//en/team/charles-hoskinson/ "Charles Hoskinson, IOHK profile"). While that week was mostly about the conference it was also an opportunity to get some work done. On the top floor of some very nice rented office space, the Serokell and Daedalus teams along with other key personnel on the Cardano project hammered out plans and approaches to give said project a major push forward. There was time for some introspection too and a lot of productive meetings around development methodology. Â 

Hội nghị rất tốt, nhưng nó đã có một số sự cạnh tranh gay gắt từ tất cả những niềm vui tôi có và mọi thứ tôi học được từ việc trộn lẫn với các nhân viên IOHK khác.
Nhân viên thường làm việc từ xa nhưng trong hơn một tuần, gần 40 người đã tập trung ở Malta, những người đã đi từ những nơi xa như Osaka, St. Petersburg và California, bao gồm IOHK Founders [Jeremy Wood]
-Wood/"Jeremy Wood, IOHK Hồ sơ") và [Charles Hoskinson] (TMP // EN/Team/Charles-Hoskinson/"Charles Hoskinson, hồ sơ IOHK").
Trong khi tuần đó chủ yếu là về hội nghị, nó cũng là một cơ hội để hoàn thành một số công việc.
Trên tầng cao nhất của một số không gian văn phòng được thuê rất đẹp, các đội Serokell và Daedalus cùng với các nhân viên chủ chốt khác trong Dự án Cardano đã đưa ra các kế hoạch và cách tiếp cận để đưa ra dự án nói về phía trước.
Có thời gian cho một số hướng nội quá và rất nhiều cuộc họp hiệu quả xung quanh phương pháp phát triển.
MỘT

A real highlight of working for this company is tripping across experts in many technical fields â€“ functional languages, formal verification, full-time life time cryptographers, language designers and creators, high energy physicists... High energy physicists. Who tell jokes.Â 

Một điểm nổi bật thực sự khi làm việc cho công ty này là vấp ngã trong nhiều lĩnh vực kỹ thuật-Ngôn ngữ chức năng, xác minh chính thức, máy mật mã thời gian toàn thời gian, nhà thiết kế ngôn ngữ và người sáng tạo, nhà vật lý năng lượng cao ... Các nhà vật lý năng lượng cao.
Người kể chuyện cười.â

And it gets better. The previous week, the week of the 27th of March, Team Grothendieck arrived in Athens to work on our next and arguably most important milestone â€“ "Transaction Execution" or "tx execution" for short. This was the first time the whole team came together to work, physically together and in same time zone.Â 

Và nó trở nên tốt hơn.
Tuần trước, tuần của ngày 27 tháng 3, Đội Grothendieck đã đến Athens để làm việc cho cột mốc quan trọng nhất và quan trọng nhất của chúng tôi - "Thực hiện giao dịch" hoặc "thực hiện TX".
Đây là lần đầu tiên cả nhóm cùng nhau làm việc, cùng nhau về mặt thể chất và trong cùng múi giờ.

The team reached its first milestone on Friday 24th March. That milestone involved downloading all blocks to the local machine and providing those blocks to other clients, further dispersing the transactions across the peer-to-peer network. The client also supports "fast download", which is the process of downloading the state trie from a point in recent history in order to shorten the time required for a client to get fully up to date with the blockchain. The premise being that downloading the state trie is faster than executing every transaction since block 0. As our first milestone it was very exciting to reach, but also to see the blocks and transactions flying around the network and know that we can successfully synchronize our local database with the rest of the Ethereum Classic network.Â 

Nhóm đã đạt được cột mốc đầu tiên vào thứ Sáu ngày 24 tháng 3.
Mốc đó liên quan đến việc tải xuống tất cả các khối vào máy cục bộ và cung cấp các khối đó cho các khách hàng khác, phân tán các giao dịch trên mạng ngang hàng.
Khách hàng cũng hỗ trợ "Tải xuống nhanh", đây là quá trình tải xuống Trie trạng thái từ một điểm trong lịch sử gần đây để rút ngắn thời gian cần thiết để khách hàng cập nhật hoàn toàn với blockchain.
Tiền đề là việc tải xuống Trie trạng thái nhanh hơn thực hiện mọi giao dịch kể từ khối 0. Là cột mốc đầu tiên của chúng tôi, rất thú vị để đạt được
Cơ sở dữ liệu với phần còn lại của Mạng cổ điển Ethereum.â

We had a productive few days at the university of Athens, the area is quiet, cool in the shade and conducive to working. The sun shone, the wind blew and the coffee was good. Our hotel was close to the university so we got to walk the streets of Athens in the mornings and see a little of daily life in the city. The subject of our days in Athens (transaction execution) is the process of updating the ledger by applying valid transactions to it block by block. After each block of transactions has been applied to the ledger the ledger exhibits a new state. This state is stored in the form of a state trie and the root of this trie is a hash reflecting precisely the contents of the state trie. The questions we had to answer were â€“ did we understand the goal; did we understand how we measure success; did we have the functionality covered by existing tasks; how long would it take and finally some knowledge swapping as working apart inevitably means small knowledge silos had begun to develop despite our efforts. By Thursday evening we had satisfactorily answered all these questions and we expect to reach the tx execution milestone by the end of April.Â 

Chúng tôi đã có một vài ngày làm việc tại Đại học Athens, khu vực này yên tĩnh, mát mẻ trong bóng râm và có lợi cho công việc. Mặt trời chiếu sáng, gió thổi và cà phê rất ngon. Khách sạn của chúng tôi ở gần trường đại học, vì vậy chúng tôi phải đi bộ trên đường phố Athens vào buổi sáng và nhìn thấy một chút cuộc sống hàng ngày trong thành phố. Chủ đề của những ngày của chúng tôi ở Athens (thực thi giao dịch) là quá trình cập nhật sổ cái bằng cách áp dụng các giao dịch hợp lệ cho nó theo từng khối. Sau mỗi khối giao dịch đã được áp dụng cho sổ cái, sổ cái thể hiện một trạng thái mới. Trạng thái này được lưu trữ dưới dạng Trie trạng thái và gốc của Trie này là một hàm băm phản ánh chính xác nội dung của Trie trạng thái. Những câu hỏi chúng tôi phải trả lời là chúng tôi đã hiểu mục tiêu; Chúng tôi đã hiểu làm thế nào chúng tôi đo lường thành công; Có phải chúng tôi có chức năng được bao phủ bởi các nhiệm vụ hiện có; Mất bao lâu và cuối cùng một số kiến thức hoán đổi khi làm việc tách biệt chắc chắn có nghĩa là các silo kiến thức nhỏ đã bắt đầu phát triển bất chấp những nỗ lực của chúng tôi. Đến tối thứ Năm, chúng tôi đã trả lời thỏa đáng tất cả những câu hỏi này và chúng tôi hy vọng sẽ đạt được cột mốc thực hiện TX vào cuối tháng Tư.

On the Friday the team attended the [Smart Contracts conference](tmp//en/blog/smart-sontracts-conference-starts-in-athens/ "Smart contracts in Athens") and spoke with Charles Hoskinson, Prof Aggelos Kiayias, Darryl McAdams and others about the future of smart contracts and the law.

Vào thứ Sáu, nhóm đã tham dự [Hội nghị Hợp đồng thông minh] (TMP // EN/Blog/Thông minh-Contracts-Conference-In-Athens/"Hợp đồng thông minh ở Athens") và nói chuyện với Charles Hoskinson, Giáo sư Aggelos Kiayias, Darryl
McAdams và những người khác về tương lai của hợp đồng thông minh và luật pháp.

There was tentative agreement on the eventuality of smart contract template libraries, so if for example the author wanted to provide an upgrade path for the contract in the event of some issue being found (ahem!) or have some means of dissolving/locking the contract if the participants lose faith, a tried and trusted set of templates would exist for the contract author to mix and match. Templates of this type could claim regulatory compliance out of the box, which is a great (if not new) way to leverage the usefulness of software in the world of contract law â€“ solve a problem once and reuse the solution ad nauseam. I suspect this is an area most smart contract developers currently enjoy ignoring!Â 

Đã có thỏa thuận dự kiến về tính cuối cùng của các thư viện mẫu hợp đồng thông minh, vì vậy nếu tác giả muốn cung cấp một đường dẫn nâng cấp cho hợp đồng trong trường hợp một số vấn đề được tìm thấy (ahem!) Hoặc có một số phương tiện để giải thể/khóa hợp đồng
Nếu những người tham gia mất niềm tin, một bộ mẫu đã thử và đáng tin cậy sẽ tồn tại để tác giả hợp đồng kết hợp và kết hợp.
Các mẫu thuộc loại này có thể yêu cầu tuân thủ quy định ra khỏi hộp, đây là một cách tuyệt vời (nếu không phải là mới) để tận dụng tính hữu dụng của phần mềm trong thế giới luật hợp đồng - Giải quyết vấn đề một lần và sử dụng lại giải pháp quảng cáo.
Tôi nghi ngờ đây là một lĩnh vực mà hầu hết các nhà phát triển hợp đồng thông minh hiện đang thích bỏ qua! Â

A final word on Athens, the Acropolis museumÂ Â is a wonderful building and worth a visit even if they housed nothing there, but coupled with the treasures of the ancient world and a good restaurant it's a must-see if you find yourself in the area.

Một từ cuối cùng về Athens, Bảo tàng Acropolis là một tòa nhà tuyệt vời và đáng để ghé thăm ngay cả khi họ không có gì ở đó, nhưng cùng với kho báu của thế giới cổ đại và một nhà hàng tốt, đó là một nhà hàng phải xem nếu bạn thấy mình trong khu vực
.

Here's hoping the end of April sees us reach another exciting milestone, an even bigger one this time, and we are able to execute every transaction in the blockchain using the Grothendieck client. That would really give the birds something to sing about...Â 

Đây là hy vọng cuối tháng 4 thấy chúng tôi đạt được một cột mốc thú vị khác, một lần thậm chí còn lớn hơn lần này và chúng tôi có thể thực hiện mọi giao dịch trong blockchain bằng máy khách Grothendieck.
Điều đó thực sự sẽ cho những con chim một cái gì đó để hát về ... Â

## **Attachments**

## ** tệp đính kèm **

![](img/2017-04-18-a-trip-to-malta-and-a-grothendieck-milestone.004.png)[ A trip to Malta and a Grothendieck milestone - Input Output](https://ucarecdn.com/0aebde3c-6dca-4790-bee7-620e40838033/-/inline/yes/ "A trip to Malta and a Grothendieck milestone - Input Output")

