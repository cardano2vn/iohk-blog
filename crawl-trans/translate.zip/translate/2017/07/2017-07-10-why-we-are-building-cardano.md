# Why we are building Cardano
![](img/2017-07-10-why-we-are-building-cardano.002.png) 10 July 2017![](img/2017-07-10-why-we-are-building-cardano.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2017-07-10-why-we-are-building-cardano.003.png) 3 mins read

![](img/2017-07-10-why-we-are-building-cardano.004.png)[ Why we are building Cardano - Input Output](https://ucarecdn.com/098df8e0-c492-4615-ad2f-350d595be382/-/inline/yes/ "Why we are building Cardano - Input Output")

![Charles Hoskinson](img/2017-07-10-why-we-are-building-cardano.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2017-07-10-why-we-are-building-cardano.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2017-07-10-why-we-are-building-cardano.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2017-07-10-why-we-are-building-cardano.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Why we are building Cardano](img/2017-07-10-why-we-are-building-cardano.009.jpeg)

Iâ€™m delighted to announce the release of [Why Cardano](http://whycardano.com/ "Why we are building Cardano, IOHK"), a document explaining the philosophy behind the design and development of [Cardano](tmp//en/projects/cardano/ "Cardano project, IOHK"). Publishing this is a key milestone for the project and I hope it helps with explaining why we are building Cardano. The document is fully translated to Japanese, Chinese and Korean, also join the community by visiting Cardano community social channels via [cardanohub.org](https://cardanofoundation.org/ "Cardano Foundation's website").

Tôi vui mừng thông báo phát hành [Tại sao Cardano] (http://whycardano.com/ "Tại sao chúng tôi xây dựng Cardano, iohk"), một tài liệu giải thích triết lý đằng sau thiết kế và phát triển của [Cardano] (TMP
// en/dự án/cardano/"dự án cardano, iohk").
Xuất bản Đây là một cột mốc quan trọng cho dự án và tôi hy vọng nó sẽ giúp giải thích lý do tại sao chúng tôi xây dựng Cardano.
Tài liệu được dịch đầy đủ sang Nhật Bản, Trung Quốc và Hàn Quốc, cũng tham gia cộng đồng bằng cách truy cập các kênh xã hội cộng đồng Cardano thông qua [cardanohub.org] (https://cardanofoundation.org/ "Trang web của Cardano Foundation").

### **Introduction**

### **Giới thiệu**

Cardano is a project that began in 2015 as an effort to change the way cryptocurrencies are designed and developed. The overall focus beyond a particular set of innovations is to provide a more balanced and sustainable ecosystem that better accounts for the needs of its users as well as other systems seeking integration.

Cardano là một dự án bắt đầu vào năm 2015 như một nỗ lực để thay đổi cách thức tiền điện tử được thiết kế và phát triển.
Trọng tâm tổng thể vượt ra ngoài một tập hợp đổi mới cụ thể là cung cấp một hệ sinh thái cân bằng và bền vững hơn, giải thích tốt hơn cho nhu cầu của người dùng cũng như các hệ thống khác tìm kiếm sự tích hợp.

In the spirit of many open source projects, Cardano did not begin with a comprehensive roadmap or even an authoritative white paper. Rather it embraced a collection of design principles, engineering best practices and avenues for exploration. These include the following:

Theo tinh thần của nhiều dự án nguồn mở, Cardano đã không bắt đầu với một lộ trình toàn diện hoặc thậm chí là một tờ giấy trắng có thẩm quyền.
Thay vào đó, nó chấp nhận một bộ sưu tập các nguyên tắc thiết kế, thực tiễn tốt nhất kỹ thuật và con đường để khám phá.
Chúng bao gồm những điều sau đây:

- Separation of accounting and computation into different layers

- Tách kế toán và tính toán thành các lớp khác nhau

- Implementation of core components in highly modular functional code

- Thực hiện các thành phần cốt lõi trong mã chức năng mô -đun cao

- Small groups of academics and developers competing with peer reviewed research 

- Các nhóm nhỏ các học giả và nhà phát triển cạnh tranh với nghiên cứu đánh giá ngang hàng

- Heavy use of interdisciplinary teams including early use of InfoSec experts

- Sử dụng nhiều các nhóm liên ngành bao gồm sử dụng sớm các chuyên gia InfoSec

- Fast iteration between white papers, implementation and new research required to correct issues discovered during review

- Lặp lại nhanh giữa các giấy tờ trắng, thực hiện và nghiên cứu mới cần thiết để khắc phục các vấn đề được phát hiện trong quá trình xem xét

- Building in the ability to upgrade post-deployed systems without destroying the network

- Xây dựng khả năng nâng cấp các hệ thống sau triển khai mà không phá hủy mạng lưới

- Development of a decentralized funding mechanism for future work

- Phát triển cơ chế tài trợ phi tập trung cho công việc trong tương lai

- A long-term view on improving the design of cryptocurrencies so they can work on mobile devices with a reasonable and secure user experience

- Một cái nhìn dài hạn về việc cải thiện thiết kế tiền điện tử để chúng có thể làm việc trên các thiết bị di động với trải nghiệm người dùng hợp lý và an toàn

- Bringing stakeholders closer to the operations and maintenance of their cryptocurrency

- Đưa các bên liên quan đến gần hơn với các hoạt động và bảo trì tiền điện tử của họ

- Acknowledging the need to account for multiple assets in the same ledger

- thừa nhận sự cần thiết phải tính toán nhiều tài sản trong cùng một sổ cái

- Abstracting transactions to include optional metadata in order to better conform to the needs of legacy systems

- Tóm tắt các giao dịch để bao gồm siêu dữ liệu tùy chọn để phù hợp hơn với nhu cầu của các hệ thống kế thừa

- Learning from the nearly 1,000 altcoins by embracing features that make sense

- Học từ gần 1.000 altcoin bằng cách nắm lấy các tính năng có ý nghĩa

- Adopt a standards-driven process inspired by the Internet Engineering Task Force using a dedicated foundation to lock down the final protocol design

- Áp dụng quy trình dựa trên tiêu chuẩn lấy cảm hứng từ Lực lượng đặc nhiệm kỹ thuật Internet bằng cách sử dụng một nền tảng chuyên dụng để khóa thiết kế giao thức cuối cùng

- Explore the social elements of commerce

- Khám phá các yếu tố xã hội của thương mại

- Find a healthy middle ground for regulators to interact with commerce without compromising some core principles inherited from Bitcoin

- Tìm một nền tảng trung bình lành mạnh để các cơ quan quản lý tương tác với thương mại mà không ảnh hưởng đến một số nguyên tắc cốt lõi được thừa hưởng từ Bitcoin

From this unstructured set of ideas, the principals working on Cardano began both to explore cryptocurrency literature and to build a toolset of abstractions. The output of this research is IOHKâ€™s extensive [library of papers](tmp//en/research/library/ "IOHK Research Library"), numerous survey results such as this recent [scripting language overview](tmp//en/research/papers/#J8N6AMPU "Scripting smart contracts for distributed ledger technology, IOHK Paper") as well as an [Ontology of Smart Contracts](tmp//en/research/papers/#GSU52TA9 "Ontology of Smart Contracts, IOHK Paper"), and the [Scorex project](tmp//en/projects/scorex/ "Scorex project, IOHK"). Lessons yielded an appreciation for the cryptocurrency industryâ€™s unusual and at times counterproductive growth.

Từ tập hợp các ý tưởng phi cấu trúc này, các hiệu trưởng làm việc trên Cardano đã bắt đầu cả hai để khám phá văn học tiền điện tử và để xây dựng một bộ công cụ trừu tượng.
Đầu ra của nghiên cứu này là [Thư viện giấy tờ] (Thư viện giấy tờ] (TMP // EN/Nghiên cứu/Thư viện/"Thư viện nghiên cứu IOHK"), nhiều kết quả khảo sát như gần đây [Tổng quan về ngôn ngữ kịch bản] (TMP // EN
/Nghiên cứu/Giấy tờ/#J8N6AMPU "Kịch bản hợp đồng thông minh cho công nghệ sổ cái phân tán, giấy iohk") cũng như [bản thể học của các hợp đồng thông minh] (TMP // EN/Nghiên cứu/Giấy tờ/#GSU52TA9 "
") và [Dự án SCOREX] (TMP // EN/Project/ScoreX/" ProjectX Project, IOHK ").
Bài học mang lại sự đánh giá cao cho ngành công nghiệp tiền điện tử bất thường và đôi khi tăng trưởng phản tác dụng.

[](http://whycardano.com/ "Why we are building Cardano, IOHK")

[] (http://whycardano.com/ "Tại sao chúng tôi xây dựng Cardano, IOHK")

Read More Â»

Đọc thêm â »

## **Attachments**

## ** tệp đính kèm **

![](img/2017-07-10-why-we-are-building-cardano.004.png)[ Why we are building Cardano - Input Output](https://ucarecdn.com/098df8e0-c492-4615-ad2f-350d595be382/-/inline/yes/ "Why we are building Cardano - Input Output")

