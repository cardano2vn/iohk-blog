# First Hand Experiences of the Oregon Programming Languages Summer School
![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.002.png) 27 July 2017![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.002.png)[ Tamara Haasen](tmp//en/blog/authors/tamara-haasen/page-1/)![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.003.png) 11 mins read

![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.004.png)[ First Hand Experiences of the Oregon Programming Languages Summer School - Input Output](https://ucarecdn.com/ec94b2fe-7939-4a71-a84a-ac7b22530473/-/inline/yes/ "First Hand Experiences of the Oregon Programming Languages Summer School - Input Output")

![Tamara Haasen](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.005.png)[](tmp//en/blog/authors/tamara-haasen/page-1/)
### [**Tamara Haasen**](tmp//en/blog/authors/tamara-haasen/page-1/)
President & Chief of Staff

Human Resources

- ![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.006.png)[](mailto:tamara.haasen@iohk.io "Email")
- ![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.007.png)[](https://www.linkedin.com/in/tamarahaasen/ "LinkedIn")
- ![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.008.png)[](https://twitter.com/tamarahaasen "Twitter")

![First Hand Experiences of the Oregon Programming Languages Summer School](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.009.jpeg)

The Oregon Programming Languages Summer School (OPLSS) takes place annually at University of Oregon, and brings together academics and professionals who are interested in programming language theory. The goal of the school is to provide an opportunity for participants to understand the current landscape in programming language research.

Trường học lập trình Oregon Trường hè (OPLSS) diễn ra hàng năm tại Đại học Oregon, và tập hợp các học giả và các chuyên gia quan tâm đến lý thuyết ngôn ngữ lập trình.
Mục tiêu của trường là cung cấp cơ hội cho những người tham gia hiểu được bối cảnh hiện tại trong nghiên cứu ngôn ngữ lập trình.

During this two-week program, professors [lecture](https://www.youtube.com/channel/UCDe6N9R7U-RYWA57wzJQ2SQ/playlists "OPLSS lectures, YouTube") on a mix of the fundamentals and recent research in the field. Since its start in 2002, OPLSS has covered a [range of topics](https://www.cs.uoregon.edu/research/summerschool/archives.html "Topics, OPLSS"), including logic, language semantics, and mathematical proofs about language properties.

Trong chương trình hai tuần này, các giáo sư [Bài giảng] (https://www.youtube.com/channel/ucde6n9r7u-rywa57wzjq2sq/playlists "Các bài giảng của OPLSS, YouTube") về sự kết hợp của các nguyên tắc cơ bản và nghiên cứu gần đây trong lĩnh vực này.
Kể từ khi bắt đầu vào năm 2002, OPLSS đã đề cập đến [một loạt các chủ đề] (https://www.cs.uoregon.edu/research/summerschool/archives.html "chủ đề, OPLSS"), bao gồm logic, ngữ nghĩa ngôn ngữ và toán học và toán học
Bằng chứng về các thuộc tính ngôn ngữ.

This year, the theme was "A Spectrum of Types". This focuses on programming languages that can feature a type system to help programmers detect and prevent errors early in the development process.

Năm nay, chủ đề là "một phổ của các loại".
Điều này tập trung vào các ngôn ngữ lập trình có thể có hệ thống loại để giúp các lập trình viên phát hiện và ngăn ngừa lỗi sớm trong quá trình phát triển.

Toward the end, lecturers explored how typed languages can safely interface with untyped languages using contracts or proofs about the behavioral equivalence of programs implemented in different languages.

Để kết thúc, các giảng viên đã khám phá cách các ngôn ngữ được gõ có thể giao tiếp một cách an toàn với các ngôn ngữ chưa được sử dụng bằng cách sử dụng các hợp đồng hoặc bằng chứng về sự tương đương hành vi của các chương trình được thực hiện bằng các ngôn ngữ khác nhau.

Here are the experiences of three of our team members who attended the OPLSS:

Dưới đây là kinh nghiệm của ba thành viên trong nhóm của chúng tôi đã tham dự OPLSS:

[](tmp//team/lars-brunjes/)

[] (TMP // Team/Lars-Brunjes/)

![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.010.jpeg)

[**Lars BrÃ¼njes](tmp//en/team/lars-brunjes/ "Lars BrÃ¼njes, IOHK profile") **is a Cardano SL Developer within Team Haskell at IOHK**

[** Lars BrÃ¼njes] (TMP // EN/TEAM/LARS-BRUNJES/"Lars BrÃ¼njes, IOHK Hồ sơ")

When I flew to Eugene, Oregon, to attend the OPLSS 2017, the Oregon Programming Languages Summer School, I was both very excited and a bit apprehensive.

Khi tôi bay tới Eugene, Oregon, để tham dự Trường hè của OPLSS 2017, Ngôn ngữ lập trình Oregon, tôi vừa rất phấn khích vừa hơi e ngại.

I was excited for the chance to play student again, immerse myself into an academic environment and learn new things. I was also apprehensive because I had no formal background in type theory and was afraid that all the lectures would be well above my head.

Tôi rất hào hứng cho cơ hội chơi lại sinh viên, đắm mình vào một môi trường học thuật và học hỏi những điều mới.
Tôi cũng sợ hãi vì tôi không có nền tảng chính thức về lý thuyết loại và sợ rằng tất cả các bài giảng sẽ ở trên đầu tôi.

The first lecture by Bob Harper, the "God" of type theory, seemed to confirm my worries. I could barely read his handwriting on the whiteboard (my wife claims Iâ€™m too vain to wear glasses, maybe she has a point), and most of the things he mentioned in passing as something everybody knew were actually new to me. Bob Harper also doesnâ€™t like Haskell â€“ a fact that made me like his lecture even less.

Bài giảng đầu tiên của Bob Harper, "Thần" của lý thuyết loại, dường như xác nhận những lo lắng của tôi.
Tôi hầu như không thể đọc chữ viết tay của anh ấy trên bảng trắng (vợ tôi tuyên bố tôi quá vô ích khi đeo kính, có thể cô ấy có một điểm), và hầu hết những điều anh ấy đề cập khi đi qua như mọi người biết thực sự là mới đối với tôi.
Bob Harper cũng không giống như Haskell - một sự thật khiến tôi thích bài giảng của anh ấy thậm chí còn ít hơn.

However, things went steeply uphill from there.

Tuy nhiên, mọi thứ trở nên dốc lên dốc từ đó.

The next two lectures of the day were much easier to follow; I understood almost everything. In the afternoon "handson session", I started working on an exercise put forward by Bob, implementing a type checker and interpreter for "GÃ¶del T", and programming Euclidâ€™s Algorithm in that language.

Hai bài giảng tiếp theo trong ngày dễ theo dõi hơn nhiều;
Tôi đã hiểu hầu hết mọi thứ.
Vào buổi chiều "Phiên Handson", tôi bắt đầu thực hiện một bài tập do Bob đưa ra, thực hiện một trình kiểm tra và phiên dịch loại cho "GÃ¶del T" và lập trình thuật toán của Euclid trong ngôn ngữ đó.

We were encouraged to do that exercise in ML, but of course I did it in Haskell (take that, Bob!), and actually working with the material made things a lot clearer for me.

Chúng tôi được khuyến khích thực hiện bài tập đó trong ML, nhưng tất nhiên tôi đã làm điều đó ở Haskell (lấy đó, Bob!), Và thực sự làm việc với các tài liệu làm cho mọi thứ rõ ràng hơn rất nhiều đối với tôi.

The next dayâ€™s lecture by Bob was actually fascinating and a lot of fun. I finally understood how different ingredients come together to endow a language with features like polymorphism, inductive, dependent types, or general recursion.

Bài giảng ngày hôm sau của Bob thực sự hấp dẫn và rất nhiều niềm vui.
Cuối cùng tôi đã hiểu làm thế nào các thành phần khác nhau kết hợp với nhau để ban cho một ngôn ngữ với các tính năng như đa hình, quy nạp, các loại phụ thuộc hoặc đệ quy chung.

Over the next two weeks, I learnt a lot about dependent types, gradual types, session types, and secure compilation.

Trong hai tuần tới, tôi đã học được rất nhiều về các loại phụ thuộc, loại dần dần, loại phiên và biên dịch an toàn.

I also received an introduction to Idris, the "dependently typed Haskell", by Edwin Brady, the creator of the language himself! After that, I spent every idle moment hacking in Idris.

Tôi cũng đã nhận được lời giới thiệu về Idris, "Haskell được đánh máy", của Edwin Brady, người tạo ra ngôn ngữ!
Sau đó, tôi đã dành mọi khoảnh khắc nhàn rỗi khi hack ở Idris.

![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.011.jpeg) This is what made OPLSS 2017 a great experience for me: not only did I learn lots of new things, I also felt inspired. Being surrounded day and night by highly motivated and intelligent people does that to you.

Speaking of people â€“ they were great! Both the instructors, who all tried very hard to deliver excellent lectures, and the participants, who all shared their excitement for the material and their willingness to learn, no matter how tired and jetlagged they were. There were people from all over the world, and talking to them, exchanging stories, ideas, and experiences, was wonderful.

Nói về mọi người - Họ thật tuyệt!
Cả những người hướng dẫn, tất cả đều rất cố gắng để có những bài giảng xuất sắc, và những người tham gia, tất cả đều chia sẻ sự phấn khích của họ đối với tài liệu và sự sẵn sàng học hỏi của họ, bất kể họ mệt mỏi và phản lực như thế nào.
Có những người từ khắp nơi trên thế giới, và nói chuyện với họ, trao đổi những câu chuyện, ý tưởng và kinh nghiệm, là tuyệt vời.

I also really enjoyed getting to know my colleague Jake Mitchell better. Over many beers at the nearby pub, we talked about everything, ranging from Idris and dependent types, to politics and religion. I love working for a remote company like IOHK, but sometimes it is really nice to be in the same room with a colleague and be able to have a beer with him!

Tôi cũng thực sự rất thích làm quen với đồng nghiệp của tôi, Jake Mitchell.
Qua nhiều loại bia tại quán rượu gần đó, chúng tôi đã nói về mọi thứ, từ Idris và các loại phụ thuộc, đến chính trị và tôn giáo.
Tôi thích làm việc cho một công ty từ xa như IOHK, nhưng đôi khi thật tuyệt khi ở cùng phòng với một đồng nghiệp và có thể uống bia với anh ấy!

After the two weeks were over and we had to start thinking about travel arrangements home, we were all very sad. One Chinese PhD student even cried and couldnâ€™t be comforted when she had to say goodbye. It was a fantastic experience for me, and I am very grateful for IOHK for giving me the chance to attend. I would be even more grateful if I could attend again next year (pushing my luck here)!

Sau khi hai tuần kết thúc và chúng tôi phải bắt đầu suy nghĩ về việc sắp xếp du lịch về nhà, tất cả chúng tôi đều rất buồn.
Một sinh viên tiến sĩ Trung Quốc thậm chí còn khóc và không thể được an ủi khi cô phải nói lời tạm biệt.
Đó là một trải nghiệm tuyệt vời đối với tôi, và tôi rất biết ơn IOHK vì đã cho tôi cơ hội tham dự.
Tôi sẽ còn biết ơn nhiều hơn nếu tôi có thể tham dự lại vào năm tới (đẩy vận may của tôi ở đây)!

![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.010.jpeg) \*\*Kawin Worrasangasilpa is a PhD student working on formal verification of Proof of Stake at IOHK\*\*

I attended both the review sessions and the main program of OPLSS 2017 over the course of three weeks. With only self-taught knowledge that I had about type theory, I was slightly worried about understanding these lectures.

Tôi đã tham dự cả hai phiên đánh giá và chương trình chính của OPLSS 2017 trong suốt ba tuần.
Chỉ với kiến thức tự học mà tôi có về lý thuyết loại, tôi hơi lo lắng về việc hiểu những bài giảng này.

The first three days were allocated for the review sessions for those who hadnâ€™t had proper training in type theory. One of the lecturers, Paul Downen, prepared us with 11 presentations, so we could be confident enough to jump to the main sessions after this. I felt calm and prepared when I finished these three days, and most of my main questions were answered.

Ba ngày đầu tiên được phân bổ cho các phiên đánh giá cho những người không được đào tạo thích hợp về lý thuyết loại.
Một trong những giảng viên, Paul Downen, đã chuẩn bị cho chúng tôi 11 bài thuyết trình, vì vậy chúng tôi có thể đủ tự tin để nhảy vào các phiên chính sau đó.
Tôi cảm thấy bình tĩnh và chuẩn bị khi tôi kết thúc ba ngày này, và hầu hết các câu hỏi chính của tôi đã được trả lời.

The content provided during the three-day session, and the academic atmosphere naturally created by all of the participants who were eager to learn new things, was fantastic. We all had a chance to share our experiences and interests, what kind of work we had been doing, and why we attended the school.

Nội dung được cung cấp trong phiên ba ngày và bầu không khí học thuật tự nhiên được tạo ra bởi tất cả những người tham gia, những người mong muốn tìm hiểu những điều mới, là điều tuyệt vời.
Tất cả chúng tôi đã có cơ hội chia sẻ kinh nghiệm và sở thích của mình, loại công việc chúng tôi đã làm và tại sao chúng tôi theo học trường.

The real challenge began on the the first day of the main programme. Each day, we had to consume and digest three different 80-minute lectures. Most of the students and I felt overwhelmed initially. However, after the third lecture of the day, the hands-on session with exercises helped us to understand the concepts in practice. During this session, at least one lecturer was present to answer any questions participants asked.

Thử thách thực sự bắt đầu vào ngày đầu tiên của chương trình chính.
Mỗi ngày, chúng tôi phải tiêu thụ và tiêu hóa ba bài giảng 80 phút khác nhau.
Hầu hết các sinh viên và tôi cảm thấy choáng ngợp ban đầu.
Tuy nhiên, sau bài giảng thứ ba trong ngày, buổi thực hành với các bài tập đã giúp chúng tôi hiểu các khái niệm trong thực tế.
Trong phiên này, ít nhất một giảng viên đã có mặt để trả lời bất kỳ câu hỏi nào mà người tham gia đã hỏi.

Apart from lectures and hands-on sessions, there were activities for participants nearly every day. One of the activities was a group presentation, and participants were given the opportunity to present their work. Many people took part by sharing their ideas and asking questions, leading to improvements in their work and the wider view of how we can apply type theory to feasible research questions.

Ngoài các bài giảng và các buổi thực hành, còn có các hoạt động cho những người tham gia gần như mỗi ngày.
Một trong những hoạt động là một bài thuyết trình nhóm và những người tham gia được trao cơ hội trình bày công việc của họ.
Nhiều người tham gia bằng cách chia sẻ ý tưởng của họ và đặt câu hỏi, dẫn đến những cải tiến trong công việc của họ và quan điểm rộng hơn về cách chúng ta có thể áp dụng lý thuyết loại cho các câu hỏi nghiên cứu khả thi.

Aside from the friendly atmosphere, I learned about a range of interesting topics. These included Dependent Type and Linearity, Contracts and Gradual Types, Substructural Type Systems and Concurrent Programming, and techniques of using Idris and Racket.

Bên cạnh bầu không khí thân thiện, tôi đã tìm hiểu về một loạt các chủ đề thú vị.
Chúng bao gồm loại phụ thuộc và tuyến tính, hợp đồng và loại dần dần, hệ thống loại cấu trúc và lập trình đồng thời, và các kỹ thuật sử dụng IDRI và vợt.

The one that I want to share is the series of lectures, "Contracts and Gradual Types", by Sam Tobin-Hochstadt. Contracts are about how to identify who to "blame" if a program has errors within its many modules. For example, Alice builds a program containing Function f and provides a contract that f has â€˜intâ€™ as a domain, but then Bob calls f applying it to a string leading to an error, so Bob is to be blamed in this case because he breaks the contract. This situation would be reversed if Alice didnâ€™t write the contract specifying the domain of Function f but f only works on â€˜intâ€™, which makes Alice the one to blame since Bob calls f correctly but f doesnâ€™t work.

Phần mà tôi muốn chia sẻ là một loạt các bài giảng, "Hợp đồng và loại dần dần" của Sam Tobin-Hochstadt.
Hợp đồng là về cách xác định ai là "đổ lỗi" nếu một chương trình có lỗi trong nhiều mô -đun của nó.
Ví dụ, Alice xây dựng một chương trình chứa chức năng F và cung cấp một hợp đồng mà f có tên miền, nhưng sau đó Bob gọi F áp dụng nó vào một chuỗi dẫn đến lỗi, vì vậy Bob sẽ bị đổ lỗi trong việc này
trường hợp vì anh ta phá vỡ hợp đồng.
Tình huống này sẽ bị đảo ngược nếu Alice không viết hợp đồng chỉ định tên miền của chức năng nhưng chỉ hoạt động trên "
công việc.

At first, Sam showed us a useful message system using Racket, which can detect the specific module that is responsible for dynamic errors. Then, in subsequent lectures, he explained more precisely how contracts work by introducing contract semantics. In my opinion, this is a very practical topic for real-world problems because we work with other developers and plug in pieces of code from modules we donâ€™t own most of the time. Therefore, it would save time if we could always identify who must take responsibility for programsâ€™ errors and fix only the modules which work incorrectly. For more details on this topic and others, please see this [list](https://www.cs.uoregon.edu/research/summerschool/summer17/topics.php "List of Lectures, OPLSS") of all OPLSS lectures.

Lúc đầu, Sam đã cho chúng tôi thấy một hệ thống tin nhắn hữu ích bằng cách sử dụng vợt, có thể phát hiện mô -đun cụ thể chịu trách nhiệm cho các lỗi động.
Sau đó, trong các bài giảng tiếp theo, ông đã giải thích chính xác hơn cách các hợp đồng hoạt động bằng cách giới thiệu ngữ nghĩa hợp đồng.
Theo tôi, đây là một chủ đề rất thực tế cho các vấn đề trong thế giới thực bởi vì chúng tôi làm việc với các nhà phát triển khác và cắm các đoạn mã từ các mô-đun mà chúng tôi không sở hữu hầu hết thời gian.
Do đó, sẽ tiết kiệm thời gian nếu chúng ta luôn có thể xác định ai phải chịu trách nhiệm về các lỗi của các chương trình và chỉ sửa các mô -đun hoạt động không chính xác.
Để biết thêm chi tiết về chủ đề này và những người khác, vui lòng xem [danh sách] này (https://www.cs.uoregon.edu/research/summerchool/summer17/topics.php "Danh sách các bài giảng, oplSS") của tất cả các bài giảng của OPLSS.

I sincerely recommend this OPLSS programme to anyone who works specifically in programming language theory, uses a functional programming language regularly, or just wants to be exposed to this field. I am certain it will not disappoint and dare to promise that it will be worth participating.

Tôi chân thành giới thiệu chương trình OPLSS này cho bất kỳ ai làm việc cụ thể trong lý thuyết ngôn ngữ lập trình, sử dụng ngôn ngữ lập trình chức năng thường xuyên hoặc chỉ muốn được tiếp xúc với lĩnh vực này.
Tôi chắc chắn rằng nó sẽ không thất vọng và dám hứa rằng nó sẽ đáng để tham gia.

[](tmp//team/jacob-mitchell/)

[] (TMP // Team/Jacob-Mitchell/)

![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.010.jpeg)

[**Jacob Mitchell](tmp//en/team/jacob-mitchell/ "Jacob Mitchell, IOHK profile") **is a DevOps Engineer at IOHK**

[** Jacob Mitchell] (TMP // EN/TEAM/JACOB-MITCHELL/"Jacob Mitchell, IOHK Hồ sơ") ** là một kỹ sư của DevOps tại IOHK **

OPLSS began with an optional three-day review session on type theory. One of the lecturers, [Paul Downen](http://ix.cs.uoregon.edu/~pdownen/ "Paul Downen"), gave presentations based on chapters from [Benjamin C. Pierceâ€™s](https://www.cis.upenn.edu/~bcpierce/ "Benjamin Pierce") [Types and Programming Languages](https://www.seas.upenn.edu/~bcpierce/tapl/index.html "Types and Programming Language") and [Bob Harper's](https://www.cs.cmu.edu/~rwh/ "Bob Harper") [Practical Foundations for Programming Languages](https://www.cs.cmu.edu/~rwh/pfpl.html "Practical Foundations for Programming Languages").

OPLSS bắt đầu với một phiên đánh giá ba ngày tùy chọn trên lý thuyết loại.
Một trong những giảng viên, [Paul Downen] (http://ix.cs.uoregon.edu/~pdownen/ "Paul Downen"), đã thuyết trình dựa trên các chương từ [Benjamin C. Pierceâ € ™ (https:/
/www.cis.upenn.edu/~bcpierce/ "Benjamin Pierce") [Các loại và ngôn ngữ lập trình] (https://www.seas.upenn.edu/~bcpierce/tapl/index.html "
) và [Bob Harper's] (https://www.cs.cmu.edu/~rwh/ "Bob Harper") [Cơ sở thực tế cho các ngôn ngữ lập trình] (https://www.cs.cmu.edu/~rwh/
pfpl.html "Cơ sở thực tế cho các ngôn ngữ lập trình").

Before arriving I had already studied TAPL and other similar material. Living like a student again was shocking since it's been a while, but the familiar lecture content helped me re-acclimate to academic life. I enjoyed meeting so many students and professionals who were also interested in type theory yet wanted to be sure they grasped the basics. It encouraged us to meet others who were eager dissect the core material before moving on to more advanced topics.

Trước khi đến, tôi đã nghiên cứu TAPL và các tài liệu tương tự khác.
Sống như một học sinh một lần nữa đã gây sốc vì đã được một thời gian, nhưng nội dung bài giảng quen thuộc đã giúp tôi trở lại cuộc sống học tập.
Tôi rất thích gặp gỡ rất nhiều sinh viên và các chuyên gia, những người cũng quan tâm đến lý thuyết kiểu nhưng muốn chắc chắn rằng họ đã nắm bắt được những điều cơ bản.
Nó khuyến khích chúng tôi gặp gỡ những người khác đang háo hức mổ xẻ tài liệu cốt lõi trước khi chuyển sang các chủ đề nâng cao hơn.

The following two weeks were a whirlwind of material. When one of the lecturers, Professor Van Horn, recalled his experience attending OPLSS as a student he compared it to drinking from a firehose. I can relate. It was all interesting, but admittedly there was a lot I didn't fully grasp. I love that now I have a lot more interesting material to study and connect to what I already know about type theory!

Hai tuần sau đó là một cơn lốc vật liệu.
Khi một trong những giảng viên, Giáo sư Van Horn, nhớ lại kinh nghiệm của mình khi tham dự OPLSS khi còn là một sinh viên, ông đã so sánh nó với việc uống rượu từ một đám cháy.
Tôi có thể có liên quan.
Tất cả đều thú vị, nhưng phải thừa nhận rằng tôi đã không hoàn toàn nắm bắt được.
Tôi thích rằng bây giờ tôi có nhiều tài liệu thú vị hơn để nghiên cứu và kết nối với những gì tôi đã biết về lý thuyết loại!

For now I'll touch on some concepts that interested me most:

Bây giờ tôi sẽ chạm vào một số khái niệm khiến tôi quan tâm nhất:

**1. Idris and Dependent Types**

** 1.
Idris và các loại phụ thuộc **

[Idris](https://www.idris-lang.org/ "Idris") is a relatively new language with many similarities to Haskell, but one major difference is it's designed to support dependent types. Idris allows programmers to more precisely describe what the program may or may not do, and get helpful and rapid feedback from the computer when any code contradicts with those descriptions. This powerful type system prevents a lot of bugs and encourages clean, coherent designs.

[Idris] (https://www.idris-lang.org/ "Idris") là một ngôn ngữ tương đối mới với nhiều điểm tương đồng với Haskell, nhưng một sự khác biệt lớn là nó được thiết kế để hỗ trợ các loại phụ thuộc.
IDRIS cho phép các lập trình viên mô tả chính xác hơn những gì chương trình có thể hoặc không thể làm và nhận được phản hồi hữu ích và nhanh chóng từ máy tính khi bất kỳ mã nào mâu thuẫn với các mô tả đó.
Hệ thống loại mạnh mẽ này ngăn chặn rất nhiều lỗi và khuyến khích các thiết kế sạch sẽ, mạch lạc.

Let's consider a useful application for dependent types.

Hãy xem xét một ứng dụng hữu ích cho các loại phụ thuộc.

Engineering is largely about getting different pieces to interact with each other to solve a problem none of them could handle on their own. Interactions between components are often dictated by [state machines](https://en.wikipedia.org/wiki/Finite-state_machine "State machine, Wikipedia"). When a system breaks down it can frequently be traced to a part that went off script from a specified state machine. Software developers routinely face these problems, both when using a dependency that has unclear or cumbersome state machine requirements, and when designing a library to have clear and simple state machine expectations. Unfortunately, these kinds of bugs can be difficult to detect and often get deployed only to cause a disaster later on. It would be much better if the compiler could catch these bugs and convey them to the developer.

Kỹ thuật phần lớn là để có được các phần khác nhau để tương tác với nhau để giải quyết vấn đề mà không ai trong số họ có thể tự mình xử lý.
Tương tác giữa các thành phần thường được quyết định bởi [máy trạng thái] (https://en.wikipedia.org/wiki/finite-state_machine "Máy trạng thái, Wikipedia").
Khi một hệ thống bị hỏng, nó thường có thể được truy tìm thành một phần đã tắt kịch bản từ một máy trạng thái được chỉ định.
Các nhà phát triển phần mềm thường xuyên phải đối mặt với những vấn đề này, cả khi sử dụng một sự phụ thuộc có yêu cầu máy trạng thái không rõ ràng hoặc cồng kềnh và khi thiết kế thư viện để có những kỳ vọng của máy trạng thái rõ ràng và đơn giản.
Thật không may, những loại lỗi này có thể khó phát hiện và thường được triển khai chỉ để gây ra thảm họa sau này.
Sẽ tốt hơn nhiều nếu trình biên dịch có thể bắt các lỗi này và chuyển chúng cho nhà phát triển.

Professor Brady, the creator of Idris, suggested how dependent types can address exactly this problem. In particular, library developers can encode state machines using dependent types, and then users of those libraries get compile-time checks that verify whether their code is compatible with the upstream state machines. To learn more I recommend reading Brady's [Type-Driven Development with Idris](https://www.manning.com/books/type-driven-development-with-idris "Type-Driven Development with Idris, Manning Publications") and studying the state machine implementation for an ATM.

Giáo sư Brady, người tạo ra Idris, cho rằng làm thế nào các loại phụ thuộc có thể giải quyết chính xác vấn đề này.
Cụ thể, các nhà phát triển thư viện có thể mã hóa các máy trạng thái bằng cách sử dụng các loại phụ thuộc và sau đó người dùng của các thư viện đó nhận được kiểm tra thời gian biên dịch để xác minh xem mã của chúng có tương thích với các máy trạng thái ngược dòng hay không.
Để tìm hiểu thêm, tôi khuyên bạn nên đọc [phát triển loại điều khiển loại của Brady với IDRIS] (https://www.manning.com/books/type-driven-development-with-idris "Phát triển loại điều khiển với IDRIS, Manning Publications") và
Nghiên cứu việc thực hiện máy nhà nước cho một ATM.

**2. PLT Redex and Abstracting Abstract Machines**

** 2.
PLT Redex và Tóm tắt Máy trừu tượng **

Type theorists need a language for communicating about programming languages because they do it frequently. Although conventions exist, the precise details of the metalanguages used can vary from one researcher to the next. Worse, sometimes a single researcher's descriptions of a programming language are incoherent due to inconsistent use of metalanguage or typos.

Các nhà lý thuyết loại cần một ngôn ngữ để giao tiếp về các ngôn ngữ lập trình vì họ làm điều đó thường xuyên.
Mặc dù các quy ước tồn tại, các chi tiết chính xác của các ngôn ngữ kim loại được sử dụng có thể thay đổi từ nhà nghiên cứu này sang nhà nghiên cứu khác.
Tồi tệ hơn, đôi khi các mô tả của một nhà nghiên cứu về ngôn ngữ lập trình không liên quan đến việc sử dụng không nhất quán ngôn ngữ hoặc lỗi chính tả.

PLT Redex attempts to fix that problem by giving researchers a simple language to specify the semantics of a programming language. After implementing the language specification the researcher can even interactively test the language's behavior and typeset the specification for publication. As Professor Van Horn demonstrated, it is a useful tool for building abstract machines and interpreters, and discovering runtime properties of programs compatible with those abstractions.

PLT Redex cố gắng khắc phục vấn đề đó bằng cách cung cấp cho các nhà nghiên cứu một ngôn ngữ đơn giản để chỉ định ngữ nghĩa của ngôn ngữ lập trình.
Sau khi thực hiện đặc tả ngôn ngữ, nhà nghiên cứu thậm chí có thể kiểm tra tương tác hành vi của ngôn ngữ và sắp xếp thông số kỹ thuật để xuất bản.
Như Giáo sư Van Horn đã chứng minh, nó là một công cụ hữu ích để xây dựng các máy trừu tượng và phiên dịch viên, và khám phá các thuộc tính thời gian chạy của các chương trình tương thích với những trừu tượng đó.

**3. Correct and Secure Compilation for Multi-Language Software**

** 3.
Tổng hợp chính xác và bảo mật cho phần mềm đa ngôn ngữ **

Much of the foundational software used in industry is implemented in languages which aren't optimized for verification. As much as we'd like everything to be rigorously verified, at least for now the practical reality is we must rely on components which are difficult to verify. To make matters worse, the verified properties about our software are usually invalidated when linked with unverified code.

Phần lớn phần mềm nền tảng được sử dụng trong ngành được triển khai bằng các ngôn ngữ không được tối ưu hóa để xác minh.
Nhiều như chúng ta muốn mọi thứ được xác minh nghiêm ngặt, ít nhất là hiện tại thực tế là chúng ta phải dựa vào các thành phần khó xác minh.
Để làm cho vấn đề tồi tệ hơn, các thuộc tính đã được xác minh về phần mềm của chúng tôi thường bị vô hiệu hóa khi được liên kết với mã chưa được xác minh.

Professor Ahmed's research frames these problems precisely and introduces general strategies and, in specific scenarios, offers concrete solutions. I'm looking forward to doing a close reading of a paper she coauthored called "[FunTAL: Reasonably Mixing a Functional Language with Assembly](http://www.ccs.neu.edu/home/amal/papers/funtal.pdf "FunTAL: Reasonably Mixing a Functional Language with Assembly")".

Nghiên cứu của Giáo sư Ahmed đóng khung chính xác các vấn đề này và đưa ra các chiến lược chung và, trong các kịch bản cụ thể, cung cấp các giải pháp cụ thể.
Tôi mong muốn được đọc gần một bài báo mà cô ấy đồng tác giả gọi là "[Funtal: Trộn một cách hợp lý một ngôn ngữ chức năng với lắp ráp] (http://www.ccs.neu.edu/home/amal/papers/funtal.pdf
"Funtal: Trộn hợp lý một ngôn ngữ chức năng với lắp ráp") ".

## **Attachments**

## ** tệp đính kèm **

![](img/2017-07-27-first-hand-experiences-oregon-programming-languages-summer-school.004.png)[ First Hand Experiences of the Oregon Programming Languages Summer School - Input Output](https://ucarecdn.com/ec94b2fe-7939-4a71-a84a-ac7b22530473/-/inline/yes/ "First Hand Experiences of the Oregon Programming Languages Summer School - Input Output")

