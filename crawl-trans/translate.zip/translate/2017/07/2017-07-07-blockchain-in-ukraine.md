# Blockchain in Ukraine
![](img/2017-07-07-blockchain-in-ukraine.002.png) 7 July 2017![](img/2017-07-07-blockchain-in-ukraine.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-07-07-blockchain-in-ukraine.003.png) 4 mins read

![](img/2017-07-07-blockchain-in-ukraine.004.png)[ Blockchain in Ukraine - Input Output](https://ucarecdn.com/5228d103-98ed-4a04-b219-830af8c54c08/-/inline/yes/ "Blockchain in Ukraine - Input Output")

![Jeremy Wood](img/2017-07-07-blockchain-in-ukraine.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-07-07-blockchain-in-ukraine.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-07-07-blockchain-in-ukraine.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-07-07-blockchain-in-ukraine.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

A magnificent view across the Black Sea from a sunny rooftop terrace in Odessa â€“ itâ€™s hard to imagine a more beautiful location for a blockchain conference. Guests and speakers from more than 20 countries were at the fifth [Blockchain Incredible Party, BIP001](http://bip001.com/ "Cryptocurrency Conference BIP001"), a leading cryptocurrency and blockchain event in eastern Europe. The event started only two years ago but has already built up a following who keep coming back for the friendly atmosphere, line up of international speakers and emphasis on social events put together with a hospitable touch. 

![](img/2017-07-07-blockchain-in-ukraine.009.jpeg)

[Lilia Vershinina](https://twitter.com/lilechkafleur "Lilia Vershinina's Twitter") and [Pavel Kravchenko](https://twitter.com/kravchenkopo "Pavel Kravchenko's Twitter"), the organisers and founders, say Ukraine is fertile ground for blockchain start-ups because there is funding, a pool of talented developers and a general appetite for new business ideas. "There are a lot of people trying to experiment, and they are not afraid," said Pavel.

.
Mặt đất màu mỡ cho các công ty khởi nghiệp blockchain vì có tài trợ, một nhóm các nhà phát triển tài năng và sự thèm ăn chung cho các ý tưởng kinh doanh mới.
"Có rất nhiều người cố gắng thử nghiệm, và họ không sợ", Pavel nói.

The event aims to showcase the Ukrainian scene and strengthen ties between blockchain advocates in Ukraine and the west, he says, pointing out that they are a long way from Silicon Valley. Another goal is providing education for the enthusiastic and fast-growing Ukrainian blockchain community. Speakers at the sold out conference included Vlad Zamfir, developer at [Ethereum](https://ethereum.org/ "Ethereum project"), Giacomo Zucco, CEO at [BlockchainLAB](http://www.blockchainlab.it/ "Blockchain lab"), Rob Viglione, co-founder of [ZenCash](https://zensystem.io/ "ZEN"), and Pavel Kravchenko, co-founder at [DistributedLab](https://distributedlab.com/ "Distributed lab").

Sự kiện này nhằm mục đích giới thiệu cảnh Ukraine và củng cố mối quan hệ giữa những người ủng hộ blockchain ở Ukraine và phương Tây, ông nói, chỉ ra rằng họ cách Thung lũng Silicon dài.
Một mục tiêu khác là cung cấp giáo dục cho cộng đồng blockchain người Ukraine nhiệt tình và phát triển nhanh chóng.
Các diễn giả tại hội nghị đã bán hết bao gồm Vlad Zamfir, nhà phát triển tại [Ethereum] (https://ethereum.org/ "Dự án Ethereum"), Giacomo Zucco, CEO tại [blockchainlab] (http://www.blockchainlab.it/ "
Blockchain Lab "), Rob Viglione, đồng sáng lập [Zencash] (https://zensystem.io/" Zen ") và Pavel Kravchenko, đồng sáng lập tại [DistributionLab] (https://distributlab.com/"
Phòng thí nghiệm phân phối ").

Charles Hoskinson, CEO of IOHK, took to the stage to talk about the biggest challenge that he sees facing cryptocurrencies.

Charles Hoskinson, Giám đốc điều hành của IOHK, đã lên sân khấu để nói về thách thức lớn nhất mà ông thấy đối mặt với tiền điện tử.

He drew a sobering comparison between what he said was a current [cryptocurrency bubble](https://www.economist.com/news/finance-and-economics/21721425-it-may-also-spawn-valuable-innovations-market-initial-coin-offerings "The market in Initial Coin Offerings risks becoming a bubble, The Economist"), and the early period of the 20th century. Tracing an arc from the Knickbocker crisis of 1907, when a three-week financial panic crashed the US stock market, to the founding of the Securities Exchange Commission in 1934, Charles charted the excesses of capitalism that ravaged the economy during those years. From insider trading scandals to the novice investors who ploughed their savings into badly judged investments, the financial turmoil of that era took the US to the verge of bankruptcy and triggered the Great Depression.

Anh ấy đã tạo ra một sự so sánh nghiêm túc giữa những gì anh ấy nói là một [bong bóng tiền điện tử] hiện tại (https://www.economist.com/news/finance-and-conomics
-Nhch-coin-coin-cerferings "Thị trường trong các dịch vụ tiền xu ban đầu có nguy cơ trở thành bong bóng, nhà kinh tế") và thời kỳ đầu của thế kỷ 20.
Theo dõi một vòng cung từ cuộc khủng hoảng Knickbocker năm 1907, khi một cuộc hoảng loạn tài chính kéo dài ba tuần đã gặp nạn thị trường chứng khoán Mỹ, để thành lập Ủy ban Giao dịch Chứng khoán năm 1934, Charles đã vạch ra sự dư thừa của chủ nghĩa tư bản đã tàn phá nền kinh tế trong những năm đó.
Từ các vụ bê bối giao dịch nội gián cho đến các nhà đầu tư mới làm quen, những người đã đưa tiền tiết kiệm của họ vào các khoản đầu tư được đánh giá xấu, sự hỗn loạn tài chính của thời đại đó đã đưa Hoa Kỳ ra bờ khỏi phá sản và gây ra cuộc Đại suy thoái.

Comparing then to now, Charles said: "We are in a bubble and there will be a collapse. A lot of businesses will wash away; the strong will survive. Moving beyond that we either repeat history and create another Federal Reserve, or we can ask ourselves, 'what can we put into code?'"â€¨â€¨ "That is the ultimate challenge we face as a space. If we are successful, not only do you create something much better, more transparent, and efficient â€“ it will be a global system. That is my hope for what cryptocurrencies can achieve. If we can get there scams will disappear, and there will be an expectation that things will work the way they ought to, as opposed to today."

So sánh sau đó, Charles nói: "Chúng tôi đang ở trong một bong bóng và sẽ có một sự sụp đổ. Rất nhiều doanh nghiệp sẽ rửa sạch; mạnh mẽ sẽ tồn tại. Beyond chúng tôi lặp lại lịch sử và tạo ra một khu bảo tồn liên bang khác, hoặc chúng tôi có thể
Tự hỏi mình, 'Chúng ta có thể đặt mã cái gì?' "" "Đó là thử thách cuối cùng mà chúng ta phải đối mặt như một không gian.
"Đây sẽ là một hệ thống toàn cầu. Đó là hy vọng của tôi cho những gì tiền điện tử có thể đạt được. Nếu chúng ta có thể đến đó lừa đảo sẽ biến mất, và sẽ có một kỳ vọng rằng mọi thứ sẽ hoạt động theo cách mà họ nên, trái ngược với ngày hôm nay.
"

Other speakers also tackled the growing trend of ICOs, or looked at the issue of regulation.

Các diễn giả khác cũng đã giải quyết xu hướng ngày càng tăng của ICO, hoặc xem xét vấn đề quy định.

Also at the conference was Professor [Roman Oliynykov](tmp//en/team/roman-oliynykov/ "Roman Oliynykov, IOHK profile"), part of the [IOHK Veritas team](tmp//en/team/#cryptocurrency-diligence "IOHK Cryptocurrency Diligence"), which is based in Ukraine. Set up in 2016, the six-person team conducts due diligence, research and development in the area of cryptocurrencies. He summed up the local interest in the subject:

Cũng tại hội nghị còn có Giáo sư [Roman Oliynykov] (TMP // EN/TEAM/ROMAN-OLIYNYKOV/"Roman Oliynykov, IOHK Hồ sơ"), một phần của nhóm [iohk Veritas]
siêng năng "IOHK tiền điện tử siêng năng"), có trụ sở tại Ukraine.
Được thành lập vào năm 2016, nhóm sáu người tiến hành siêng năng, nghiên cứu và phát triển trong lĩnh vực tiền điện tử.
Anh ấy đã tóm tắt lợi ích địa phương về chủ đề:

"In my city, Kharkiv, there were more than 1,000 registrations for the last Bitcoin meet-up, which would have been unimaginable only six months ago. There is a huge popularity of blockchain systems in Ukraine and there are many qualified professionals for scientific research into blockchains."

"Ở thành phố của tôi, Kharkiv, đã có hơn 1.000 đăng ký cho cuộc gặp gỡ Bitcoin cuối cùng, điều này sẽ không thể tưởng tượng được chỉ sáu tháng trước.
thành blockchains. "

A main focus for the Veritas team has been research into treasury systems. This mechanism provides a pool of funding for the development of cryptocurrencies and allows communities, rather than single individuals or entities, to vote on the decisions that determine the future of a cryptocurrency.

Một trọng tâm chính cho nhóm Veritas đã được nghiên cứu về các hệ thống kho bạc.
Cơ chế này cung cấp một nhóm tài trợ cho việc phát triển tiền điện tử và cho phép các cộng đồng, thay vì các cá nhân hoặc thực thể đơn lẻ, bỏ phiếu về các quyết định xác định tương lai của một loại tiền điện tử.

Roman said: "Researchers at Lancaster University in the UK in collaboration with the Veritas team have almost finished a new voting protocol for a treasury, which provides privacy in voting, yet in a transparent process. It also provides delegation. Moreover, we can find out how popular each expert is, how many people are delegated to each expert, but the delegation itself remains private."

Roman nói: "Các nhà nghiên cứu tại Đại học Lancaster ở Anh phối hợp với nhóm Veritas gần như đã hoàn thành một giao thức bỏ phiếu mới cho một kho bạc, nơi cung cấp quyền riêng tư trong việc bỏ phiếu, nhưng trong một quy trình minh bạch.
Trong số các chuyên gia phổ biến như thế nào, có bao nhiêu người được giao cho mỗi chuyên gia, nhưng chính phái đoàn vẫn còn riêng tư. "

An expert as referenced in this case is a person trusted by the community. Some people will prefer to delegate their vote to experts.

Một chuyên gia được tham chiếu trong trường hợp này là một người được cộng đồng tin tưởng.
Một số người sẽ thích ủy thác phiếu bầu của họ cho các chuyên gia.

For the organisers of BIP, an expanded programme is being planned for the next event. Pavel is looking at the possibility of a week-long conference that could include courses too. That would be great news for the loyal fans of this well put together event.

Đối với các nhà tổ chức BIP, một chương trình mở rộng đang được lên kế hoạch cho sự kiện tiếp theo.
Pavel đang xem xét khả năng của một hội nghị kéo dài một tuần cũng có thể bao gồm các khóa học.
Đó sẽ là một tin tuyệt vời cho những người hâm mộ trung thành của sự kiện kết hợp tốt này.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-07-07-blockchain-in-ukraine.004.png)[ Blockchain in Ukraine - Input Output](https://ucarecdn.com/5228d103-98ed-4a04-b219-830af8c54c08/-/inline/yes/ "Blockchain in Ukraine - Input Output")

