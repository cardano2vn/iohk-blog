# Team Grothendieck move closer to ETC goal
### **Working on the code in Argentina**
![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.002.png) 22 May 2017![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.003.png) 6 mins read

![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.004.png)[ Team Grothendieck move closer to Ethereum Classic goal - Input Output](https://ucarecdn.com/6d53d125-b50d-476b-96f6-c0f055eed4c4/-/inline/yes/ "Team Grothendieck move closer to Ethereum Classic goal - Input Output")

![Jeremy Wood](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![Team Grothendieck move closer to ETC goal](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.009.jpeg)

It took a little longer than expected but I finally made the trip to Buenos Aires, Argentina. In fact, I'm standing at a work desk by the window in Frankfurt airport waiting for my flight back to Dublin. I'm enjoying a gloriously sunny day here through the wall of glass.Â 

Nó mất nhiều thời gian hơn dự kiến nhưng cuối cùng tôi đã thực hiện chuyến đi đến Buenos Aires, Argentina.
Trên thực tế, tôi đang đứng ở một bàn làm việc bên cửa sổ ở sân bay Frankfurt để chờ chuyến bay của tôi trở về Dublin.
Tôi đang tận hưởng một ngày nắng rực rỡ ở đây qua bức tường của kính.

It was another productive trip, a lot has happened since the Team Grothendieck trips to [Poland and St Petersburg](tmp//en/blog/mission-one%E2%80%93destination-st-petersburg-and-warsaw/ "Destination St Petersburg and Warsaw, IOHK blog"). In our work to build a Scala client for Ethereum Classic there has been a lot of code written, a lot of understanding gained, and a couple of milestones reached: we now have the ability to download and execute blocks of transactions from the ETC chain. We have also evolved a lot as a team.

Đó là một chuyến đi hiệu quả khác, rất nhiều điều đã xảy ra kể từ khi nhóm Grothendieck đi đến [Ba Lan và St Petersburg] (TMP // EN/Blog/Mission-One%E2%80%93Destination-St-Petersburg-and-Warsaw/"Destination
St Petersburg và Warsaw, blog IOHK ").
Trong công việc của chúng tôi để xây dựng một ứng dụng khách scala cho Ethereum Classic, đã có rất nhiều mã được viết, rất nhiều sự hiểu biết và một vài cột mốc đã đạt được: giờ đây chúng tôi có khả năng tải xuống và thực hiện các khối giao dịch từ chuỗi ETC.
Chúng tôi cũng đã phát triển rất nhiều như một đội.

The remaining milestones to reach include mining, and the JSON API â€“ to allow Mist and other dapp wallets to use our client. In parallel with that we need to focus on our codebase. It was this process that the Grothendieck teamâ€™s [Alan Verbner](tmp//en/team/alan-verbner/ "Alan Verbner") and [Nico Tallar](tmp//en/team/nicolas-tallar/ "Nicolas Tallar"), and I spent our time on in BA.Â 

Các cột mốc còn lại để tiếp cận bao gồm khai thác và API JSON - để cho phép sương mù và các ví DApp khác sử dụng khách hàng của chúng tôi.
Song song với điều đó chúng ta cần tập trung vào cơ sở mã của mình.
Đó là quá trình mà nhóm Grothendieck [Alan Verbner] (TMP // EN/Team/Alan-Verbner/"Alan Verbner") và [Nico Tallar] (TMP // EN/Team/Nicolas-Tallar/"
Nicolas Tallar "), và tôi đã dành thời gian của chúng tôi ở Ba.â

![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.010.jpeg)

As a background, in an ideal world we would create code from day one supporting the coupling that made sense as we approached the release. However, this is an almost impossible task because we can't usually know the most sensible "final" coupling when starting out. For the ETC client we took the (oft used) approach that we would write clean unit tested code that implemented the functionality we understood at the time and then refactor as we learnt more. For example, when we finished the block download phase we had very little in the way of model classes for â€˜blockchainâ€™. However, as we spun up the "Tx Execution" phase, we discovered it made a lot of sense to create a set of functions coalescing around a â€˜blockchainâ€™ model.Â 

Như một nền tảng, trong một thế giới lý tưởng, chúng tôi sẽ tạo mã từ ngày một hỗ trợ cho sự kết hợp có ý nghĩa khi chúng tôi tiếp cận bản phát hành.
Tuy nhiên, đây là một nhiệm vụ gần như không thể bởi vì chúng ta thường không thể biết được khớp nối "cuối cùng" hợp lý nhất khi bắt đầu.
Đối với máy khách ETC, chúng tôi đã thực hiện phương pháp (OFT đã sử dụng) mà chúng tôi sẽ viết mã được kiểm tra đơn vị sạch đã thực hiện chức năng mà chúng tôi hiểu vào thời điểm đó và sau đó tái cấu trúc khi chúng tôi biết nhiều hơn.
Ví dụ: khi chúng tôi hoàn thành giai đoạn tải xuống khối, chúng tôi có rất ít trong cách của các lớp mô hình cho - ˜blockchainâ € ™.
Tuy nhiên, khi chúng tôi tạo ra giai đoạn "thực thi TX", chúng tôi đã phát hiện ra rất có ý nghĩa để tạo ra một tập hợp các chức năng kết hợp xung quanh một mô hình - mô hình ˜blockchainâ € ™.

There's a school of thought that says this is the way to carry on: don't waste your time building "reusable" components that aren't reusable and won't be reused. I have sympathy for this approach because building reusable components is hard and it is embarrassing for your new component â€“ the one you spent time and effort on â€“ to fail at the first attempt at reuse because it doesn't *quite* do what you need it to. Better to allow the new functionality to drive refactors as and when it comes. There's a humility to this approach that appeals to me.Â 

Có một trường phái tư tưởng nói rằng đây là cách để tiếp tục: Đừng lãng phí thời gian của bạn để xây dựng các thành phần "có thể tái sử dụng" của bạn không thể tái sử dụng và sẽ không được sử dụng lại.
Tôi có thiện cảm với cách tiếp cận này bởi vì việc xây dựng các thành phần có thể tái sử dụng là khó khăn và thật đáng xấu hổ cho thành phần mới của bạn - một trong những thành phần bạn đã dành thời gian và nỗ lực để thất bại trong lần thử đầu tiên trong việc tái sử dụng vì nó không *khá *
Làm những gì bạn cần nó để.
Tốt hơn để cho phép các chức năng mới thúc đẩy các bộ tái cấu trúc như và khi nó đến.
Có một sự khiêm tốn cho cách tiếp cận này hấp dẫn tôi.

Guess what's coming next? We're going to look at ways to modularise our client. Why? Firstly and most importantly it's a functional requirement for the codebase to support a significant level of flexibility. Four things that might define the core of a blockchain client are the network module, the ledger, the consensus mechanism and the wallet. Closely coupling the wallet and ledger together, we would like to experiment with different types of ledger and different types of consensus. And these should be able to use a well defined network module. Â 

Đoán xem điều gì sẽ đến tiếp theo?
Chúng ta sẽ xem xét các cách để mô đun hóa khách hàng của mình.
Tại sao?
Đầu tiên và quan trọng nhất, đó là một yêu cầu chức năng cho cơ sở mã để hỗ trợ một mức độ linh hoạt đáng kể.
Bốn điều có thể xác định cốt lõi của máy khách blockchain là mô -đun mạng, sổ cái, cơ chế đồng thuận và ví.
Kết hợp chặt chẽ ví và sổ cái với nhau, chúng tôi muốn thử nghiệm các loại sổ cái khác nhau và các loại đồng thuận khác nhau.
Và những điều này sẽ có thể sử dụng một mô -đun mạng được xác định rõ.
MỘT

So we will first attempt to isolate the 'network' module. This is a module that maintains connections to peers and sends and receives a configurable set of messages. It allows messages to be addressed to a peer or broadcast to many peers. It allows clients of the module to register for types of messages and types of message per peer. It's also functionality that we have already created. We just need to organize it so that it's reusable!

Vì vậy, trước tiên chúng tôi sẽ cố gắng cách ly mô -đun 'mạng'.
Đây là một mô -đun duy trì các kết nối với các đồng nghiệp và gửi và nhận một bộ tin nhắn có thể định cấu hình.
Nó cho phép các tin nhắn được gửi đến một người ngang hàng hoặc phát cho nhiều đồng nghiệp.
Nó cho phép khách hàng của mô -đun đăng ký các loại tin nhắn và loại tin nhắn trên mỗi ngang hàng.
Đó cũng là chức năng mà chúng tôi đã tạo ra.
Chúng ta chỉ cần tổ chức nó để nó có thể tái sử dụng!

Why now? The JSON RPC API â€“ in theory â€“ should be controller layer code. The mining integration should â€“ also in theory â€“ not affect the workings of the network module. So the functionality to be reused should already exist and when we repackage it without breaking the existing system we know it's useful. By the time we get around to examining the coupling of the ledger and consensus the same should be true, we won't be making up use cases for invented modules, we will have specific working code to repackage. Will we produce interfaces and coupling that can be reused? That's the challenge. And after that â€“ optimization of the internals...

Tại sao bây giờ?
API JSON RPC - Theo lý thuyết - nên là mã lớp điều khiển.
Việc tích hợp khai thác nên về lý thuyết cũng không ảnh hưởng đến hoạt động của mô -đun mạng.
Vì vậy, chức năng sẽ được tái sử dụng đã tồn tại và khi chúng ta đóng gói lại mà không phá vỡ hệ thống hiện tại, chúng ta biết nó hữu ích.
Vào thời điểm chúng tôi đi xung quanh để kiểm tra khớp nối của sổ cái và sự đồng thuận giống như vậy, chúng tôi sẽ không tạo ra các trường hợp sử dụng cho các mô -đun được phát minh, chúng tôi sẽ có mã làm việc cụ thể để đóng gói lại.
Chúng ta sẽ tạo ra các giao diện và khớp nối có thể được sử dụng lại?
Đó là thử thách.
Và sau đó, tối ưu hóa nội bộ ...

Mining, web API and modularisation are not trivial tasks but they will end. And with them we reach the end of the existing roadmap â€“ stability, bug fixes and auditing aside. For the past five months we have been playing catch up, we didn't need to talk about future evolution of the technology because we had a clear and challenging mandate â€“ to recreate a client from the ground up. Now that we're relatively close to doing that, the exciting process of talking about the future of the codebase can begin.Â 

Khai thác, API web và mô đun hóa không phải là các nhiệm vụ tầm thường nhưng chúng sẽ kết thúc.
Và với họ, chúng tôi đi đến cuối lộ trình hiện có - sự ổn định, sửa lỗi và kiểm toán sang một bên.
Trong năm tháng qua, chúng tôi đã chơi bắt kịp, chúng tôi không cần phải nói về sự phát triển trong tương lai của công nghệ bởi vì chúng tôi đã có một nhiệm vụ rõ ràng và đầy thách thức - để tái tạo một khách hàng từ đầu.
Bây giờ chúng ta tương đối gần với việc đó, quá trình thú vị để nói về tương lai của cơ sở mã có thể bắt đầu.

While in BA, Sergio Lerner kindly hosted the three of us at his office and over decent coffee and [alfojores](http://www.huffingtonpost.com/2015/02/05/alfajores-cookie-the-best_n_6614242.html "Alfajores Are The Best Cookie Youâ€™ve Never Heard Of, Huffington Post") we had a good discussion about Ethereum tech, and some of the things he's been up to. And of course, RSK's upcoming release of their platform at Consensus 2017 in NYC. (Best of luck RSK!)

Khi ở BA, Sergio Lerner vui lòng tổ chức ba chúng tôi tại văn phòng của anh ấy và qua cà phê phong nha và [Alfojores] (http://www.huffingtonpost.com/2015/02/05/alfajores-cookie-The-Best_N_661424242
Alfajores là cookie tốt nhất mà bạn chưa từng nghe đến, Huffington Post ") Chúng tôi đã có một cuộc thảo luận tốt về Ethereum Tech, và một số điều anh ấy đã làm.
Và tất nhiên, việc phát hành nền tảng sắp tới của RSK tại sự đồng thuận 2017 tại NYC.
(Tốt nhất của may mắn RSK!)

I'm always interested in how a global blockchain aimed at general purpose use can scale, with no way to delete defunct contracts from the global state trie. Sergio made the interesting point that ETC probably won't need to scale for a couple of years. He also suggested that with storage being so cheap for a network in a steady state (with most nodes staying up to date) it would be more expensive for all nodes to delete a contract than to keep it.

Tôi luôn quan tâm đến việc một blockchain toàn cầu nhằm mục đích sử dụng mục đích chung có thể mở rộng quy mô, không có cách nào để xóa các hợp đồng không còn tồn tại khỏi Trie nhà nước toàn cầu.
Sergio đã đưa ra quan điểm thú vị rằng ET có lẽ sẽ không cần phải mở rộng quy mô trong một vài năm.
Ông cũng cho rằng với việc lưu trữ rất rẻ cho một mạng ở trạng thái ổn định (với hầu hết các nút luôn cập nhật), sẽ tốn kém hơn cho tất cả các nút để xóa hợp đồng hơn là giữ nó.

Apart from Rootstock, the [Bitcoin Embassy](https://www.facebook.com/espaciobitcoin/ "Facebook, Bitcoin Embassy")Â in Buenos Aires, where Alan and Nico normally work is littered with interesting people working on multiple ways of leveraging the Bitcoin blockchain. There's a great atmosphere in the building, calm and friendly but industrious and I really enjoyed my time there, so when it was suggested we attend a [live podcast](https://www.youtube.com/watch?v=7ZbQgewE2aA&feature=youtu.be&t=1951 "NoSoySatoshi #9 LTC SegWit, ENS, Tezos, Alan McSherry (ETC dev), YouTube")â€¦we said yes!

Ngoài gốc rễ, [Đại sứ quán Bitcoin] (https://www.facebook.com/espaciobitcoin/ "Facebook, Đại sứ quán Bitcoin")
Tận dụng blockchain bitcoin.
Có một bầu không khí tuyệt vời trong tòa nhà, bình tĩnh và thân thiện nhưng cần cù và tôi thực sự rất thích thời gian của mình ở đó, vì vậy khi đề nghị chúng tôi tham dự [podcast trực tiếp] (https://www.youtube.com/watch?v=7ZBQGEWE2AA&feature=
youtu.be & t = 1951 "Nosoysatoshi #9 LTC SEGWIT, ENS, TEZOS, ALAN MCSHERRY (ETC Dev), YouTube") - Chúng tôi đã nói có!

![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.011.jpeg)

A special shout out to Alan Verbner, a man who is proud of his city and I think the city can be proud of him. We walked the city the whole weekend and I got a real sense of it. BA is modern but you don't have to look too hard to find old world charm â€“ French restaurants with dark wood and marble counters, majestic old cafes full of Art Deco gold fittings and the smell of cardamon infused coffee. And then there's the steak. Vegetarians, look away now. I'm delighted to report that Argentinaâ€™s reputation for steak is well deserved. The variety of cuts, the sauces, the cooking...it might be worth going back just to eat steak.Â 

Một tiếng hét đặc biệt với Alan Verbner, một người đàn ông tự hào về thành phố của mình và tôi nghĩ rằng thành phố có thể tự hào về anh ta.
Chúng tôi đi bộ thành phố cả cuối tuần và tôi có một cảm giác thực sự về nó.
BA là hiện đại nhưng bạn không cần phải quá khó để tìm thấy sự quyến rũ của thế giới cũ - các nhà hàng Pháp với gỗ tối màu và quầy đá cẩm thạch, các quán cà phê cũ hùng vĩ với đầy đủ các phụ kiện vàng nghệ thuật và mùi cà phê được truyền thảo quả.
Và sau đó là bít tết.
Người ăn chay, nhìn đi chỗ khác.
Tôi rất vui khi báo cáo rằng danh tiếng của Argentina về bít tết rất xứng đáng.
Sự đa dạng của các vết cắt, nước sốt, nấu ăn ... có thể đáng để quay trở lại chỉ để ăn bít tết.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-05-22-team-grothendieck-move-closer-to-etc-goal.004.png)[ Team Grothendieck move closer to Ethereum Classic goal - Input Output](https://ucarecdn.com/6d53d125-b50d-476b-96f6-c0f055eed4c4/-/inline/yes/ "Team Grothendieck move closer to Ethereum Classic goal - Input Output")

