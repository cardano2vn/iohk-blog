# Cryptocurrencies need a safeguard to prevent another DAO disaster
### **High assurance brings mission-critical security to digital funds**
![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.002.png) 12 May 2017![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.002.png)[ Duncan Coutts](tmp//en/blog/authors/duncan-coutts/page-1/)![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.003.png) 13 mins read

![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.004.png)[ Cryptocurrencies need a safeguard to prevent another DAO disaster - Input Output](https://ucarecdn.com/f73bbb17-b79b-49b1-b1ae-4278fab218c5/-/inline/yes/ "Cryptocurrencies need a safeguard to prevent another DAO disaster - Input Output")

![Duncan Coutts](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.005.png)[](tmp//en/blog/authors/duncan-coutts/page-1/)
### [**Duncan Coutts**](tmp//en/blog/authors/duncan-coutts/page-1/)
Technical Architect

Well-Typed

- ![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.006.png)[](mailto:duncan.coutts@iohk.io "Email")
- ![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.007.png)[](https://www.youtube.com/watch?v=TZGVgNsJSnA "YouTube")
- ![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.008.png)[](http://www.linkedin.com/in/duncancoutts "LinkedIn")
- ![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.009.png)[](https://github.com/dcoutts "GitHub")

![Cryptocurrencies need a safeguard to prevent another DAO disaster](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.010.jpeg)

TL;DR You want to avoid the next DAO-like disaster: so you want *confidence* that the system underpinning your cryptocurrency doesnâ€™t have a hidden flaw that could be triggered at any time and render your assets worthless. To get that confidence you need a *high assurance* implementation of the system operating your cryptocurrency. Formal methods (mathematical specifications and proofs) are the best way to build high assurance software systems, and that is what we are aiming to do with the software behind the cryptocurrencies we build.

TL; dr bạn muốn tránh thảm họa giống như DAO tiếp theo: vì vậy bạn muốn * tự tin * rằng hệ thống củng cố tiền điện tử của bạn không có lỗ hổng ẩn có thể được kích hoạt bất cứ lúc nào và khiến tài sản của bạn trở nên vô giá trị.
Để có được sự tự tin đó, bạn cần triển khai * đảm bảo cao * của hệ thống vận hành tiền điện tử của bạn.
Phương pháp chính thức (thông số kỹ thuật và bằng chứng toán học) là cách tốt nhất để xây dựng các hệ thống phần mềm đảm bảo cao và đó là những gì chúng tôi đang hướng tới làm với phần mềm đằng sau tiền điện tử chúng tôi xây dựng.

## **How can you sleep at night?**

## ** Làm thế nào bạn có thể ngủ vào ban đêm? **

A gold bar or a wodge of cash stashed in a safe has the rather nice property that it doesnâ€™t just evaporate overnight. Money managed by computer software is not inherently so durable. Software flaws can be revealed without warning and can destroy the trust in whole systems.

Một thanh vàng hoặc một wodge tiền mặt được cất trong két an toàn có tài sản khá đẹp mà nó không chỉ bay hơi qua đêm.
Tiền được quản lý bởi phần mềm máy tính vốn không quá bền.
Lỗ hổng phần mềm có thể được tiết lộ mà không cần cảnh báo và có thể phá hủy sự tin tưởng trong toàn bộ hệ thống.

We only have to look around us to see the prevalence of software flaws. The IT trade press is full of news of data breaches, critical security patches, zero-day exploits etc. At root these are almost all down to software flaws. Standard software development practices inevitably lead to this state of affairs.

Chúng ta chỉ phải nhìn xung quanh chúng ta để thấy sự phổ biến của các lỗ hổng phần mềm.
Báo chí giao dịch CNTT có đầy đủ các tin tức về vi phạm dữ liệu, các bản vá bảo mật quan trọng, khai thác không ngày, v.v., những điều này gần như là tất cả các lỗ hổng phần mềm.
Thực tiễn phát triển phần mềm tiêu chuẩn chắc chắn dẫn đến tình trạng này.

With the DAO in particular, the flaw was in the implementation of the smart contract that defined the fund, not directly in Ethereum itself. So the implementation of contracts and the design of smart contract languages is certainly an important issue, but the next flaw could be somewhere else. Itâ€™s hard to know.

Với DAO nói riêng, lỗ hổng là trong việc thực hiện hợp đồng thông minh xác định quỹ, không trực tiếp trong chính Ethereum.
Vì vậy, việc thực hiện các hợp đồng và thiết kế các ngôn ngữ hợp đồng thông minh chắc chắn là một vấn đề quan trọng, nhưng lỗ hổng tiếp theo có thể là một nơi khác.
Thật khó để biết.

So how are we to sleep soundly at night? How can we be confident that our cryptocurrency coins are not just going to evaporate overnight? What we need is assurance. Not to be confused with insurance. Assurance is evidence and rational arguments that a system correctly does what it is supposed to do.

Vậy chúng ta ngủ ngon như thế nào vào ban đêm?
Làm thế nào chúng ta có thể tự tin rằng tiền điện tử của chúng ta không chỉ làm bay hơi qua đêm?
Những gì chúng ta cần là sự đảm bảo.
Đừng nhầm lẫn với bảo hiểm.
Đảm bảo là bằng chứng và lập luận hợp lý rằng một hệ thống thực hiện chính xác những gì nó phải làm.

Systems with high assurance are used in cases where safety or a lot of money is at stake. For example we rightly demand high assurance that aircraft flight control systems work correctly so we can all trust in safely getting from A to B.

Các hệ thống có sự đảm bảo cao được sử dụng trong trường hợp an toàn hoặc nhiều tiền bị đe dọa.
Ví dụ, chúng tôi yêu cầu đúng sự đảm bảo cao rằng các hệ thống điều khiển máy bay hoạt động chính xác để tất cả chúng ta có thể tin tưởng vào việc nhận được từ A đến B.

If as a community we truly believe that cryptocurrencies are not a toy and can and should be used when there are billions at stake then it behoves us to aim for high assurance implementations. If we do not have that aim, are we really serious or credible? And then in the long run we must actually *achieve* high assurance implementations.

Nếu là một cộng đồng, chúng tôi thực sự tin rằng tiền điện tử không phải là một món đồ chơi và có thể và nên được sử dụng khi có hàng tỷ người bị đe dọa thì nó khiến chúng tôi nhắm đến việc triển khai đảm bảo cao.
Nếu chúng ta không có mục tiêu đó, chúng ta thực sự nghiêm túc hay đáng tin cậy?
Và sau đó về lâu dài, chúng ta thực sự phải * đạt được * triển khai đảm bảo cao.

In this post weâ€™ll focus on the software aspects of systems and how formal methods help with designing high assurance software. Formal methods can be very useful in aspects of high assurance system design other than software, but thatâ€™ll have to wait for some other blog post.

Trong bài đăng này, chúng tôi sẽ tập trung vào các khía cạnh phần mềm của các hệ thống và cách các phương pháp chính thức giúp thiết kế phần mềm đảm bảo cao.
Các phương pháp chính thức có thể rất hữu ích trong các khía cạnh của thiết kế hệ thống đảm bảo cao ngoài phần mềm, nhưng điều đó sẽ phải chờ một số bài đăng trên blog khác.

## **What does assurance look like?**

## ** Đảm bảo trông như thế nào? **

While we might imagine that assurance is either â€œyesâ€œ or â€œnoâ€œ â€“ you have it or you donâ€™t â€“ it actually makes sense to talk about degrees of assurance. See for example the summaries of the assurance levels, EAL1 to EAL7, in the [CC security evaluation standard](https://en.wikipedia.org/wiki/Evaluation_Assurance_Level "Wikipedia, Evaluation Assurance Level"). The degree of assurance is about risk: how much risk of system failure are you prepared to tolerate? Higher assurance means a lower risk of failures. Of course all else being equal you would want higher assurance, but there is inevitably a trade-off. Achieving higher levels of assurance requires different approaches to system development, more specialised skills and extra up-front work. So the trade-off is that higher assurance is perceived to come with greater cost, longer development time and fewer features in a system. This is why almost all normal commercial software development is not high assurance.

Mặc dù chúng ta có thể tưởng tượng rằng sự đảm bảo đó là - â € œSesâ € œ hoặc "Không phải là bạn có nó hoặc bạn không thực sự có ý nghĩa khi nói về mức độ đảm bảo. Xem ví dụ các bản tóm tắt của các cấp độ đảm bảo, EAL1 đến EAL7, trong [Tiêu chuẩn đánh giá bảo mật CC] (https://en.wikipedia.org/wiki/Evalation_assurance_level "Wikipedia, mức độ đảm bảo đánh giá"). Mức độ đảm bảo là về rủi ro: Bạn đã chuẩn bị chịu đựng bao nhiêu rủi ro về sự thất bại của hệ thống? Đảm bảo cao hơn có nghĩa là rủi ro thất bại thấp hơn. Tất nhiên tất cả những thứ khác đều bình đẳng, bạn sẽ muốn đảm bảo cao hơn, nhưng chắc chắn có một sự đánh đổi. Đạt được mức độ đảm bảo cao hơn đòi hỏi các cách tiếp cận khác nhau để phát triển hệ thống, các kỹ năng chuyên môn hơn và công việc hoàn toàn phía trước. Vì vậy, sự đánh đổi là sự đảm bảo cao hơn được coi là có chi phí lớn hơn, thời gian phát triển dài hơn và ít tính năng hơn trong một hệ thống. Đây là lý do tại sao hầu hết tất cả sự phát triển phần mềm thương mại thông thường không phải là sự đảm bảo cao.

There are two basic approaches to higher assurance software: the traditional approach focused on process and the modern approach focused on evidence, especially formal mathematical evidence.

Có hai cách tiếp cận cơ bản để phần mềm đảm bảo cao hơn: phương pháp truyền thống tập trung vào quá trình và phương pháp hiện đại tập trung vào bằng chứng, đặc biệt là bằng chứng toán học chính thức.

Historically, going back to the 1980s and before, the best we could do was essentially to think hard and to be very careful. So the assurance standards were all about rigorously documenting everything, especially the *process* by which the software was designed, built and tested. The evidence at the end is in the form of a big stack of documents that essentially say â€œweâ€™ve been very methodical and carefulâ€.

Trong lịch sử, quay trở lại những năm 1980 và trước đó, điều tốt nhất chúng ta có thể làm về cơ bản là suy nghĩ kỹ và rất cẩn thận.
Vì vậy, các tiêu chuẩn đảm bảo là tất cả về tài liệu nghiêm ngặt về mọi thứ, đặc biệt là * quá trình * mà phần mềm được thiết kế, xây dựng và thử nghiệm.
Bằng chứng ở cuối là ở dạng một đống tài liệu lớn về cơ bản nói rằng chúng ta rất có phương pháp và cẩn thận.

Another approach comes from academic computer science â€“ starting in the 80â€™s and becoming more practical and mature ever since. It starts from the premise that computer programs are â€“ in principle â€“ mathematical objects and can be reasoned about mathematically. When we say â€œreason aboutâ€ we mean mathematical proofs of properties like â€œthis program satisfies this specificationâ€, or â€œthis program always computes the same result as that programâ€. The approach is that as part of the development process we produce mathematical evidence of the correctness of the software. The evidence is (typically) in the form of a mathematical specification along with proofs about some useful properties of the specification (eg security properties); and proofs that the final code (or critical parts thereof) satisfy the specification. If this sounds like magic then bear with me for a moment. We will look at a concrete example in the next section.

Một cách tiếp cận khác đến từ khoa học máy tính học thuật - bắt đầu từ những năm 80 và trở nên thực tế và trưởng thành hơn kể từ đó. Nó bắt đầu từ tiền đề rằng các chương trình máy tính là - về nguyên tắc - các đối tượng toán học và có thể được lý luận về toán học. Khi chúng ta nói "Lý do về" Chúng ta có nghĩa là bằng chứng toán học về các thuộc tính như "Chương trình này đáp ứng đặc điểm kỹ thuật này" hoặc "Chương trình này luôn tính toán kết quả tương tự như chương trình đó. Cách tiếp cận là một phần của quá trình phát triển, chúng tôi tạo ra bằng chứng toán học về tính chính xác của phần mềm. Bằng chứng là (thông thường) dưới dạng một đặc điểm kỹ thuật toán học cùng với các bằng chứng về một số thuộc tính hữu ích của đặc điểm kỹ thuật (ví dụ: các thuộc tính bảo mật); và bằng chứng cho thấy mã cuối cùng (hoặc các phần quan trọng của chúng) đáp ứng đặc điểm kỹ thuật. Nếu điều này nghe giống như ma thuật thì hãy chịu đựng tôi một lúc. Chúng tôi sẽ xem xét một ví dụ cụ thể trong phần tiếp theo.

One advantage of this approach compared to the traditional approach is that it produces evidence about the final software artefacts that stands by itself and can be checked by anyone. Indeed someone assessing the evidence does not need to know or care about the development process (which also makes it more compatible with open-source development). The evidence does not have to rely on document sign-offs saying essentially â€œwe did careful code review and all our tests passâ€. That kind of evidence is great, but it is indirect evidence and it is not precise or rigorous.

Một lợi thế của phương pháp này so với phương pháp truyền thống là nó tạo ra bằng chứng về các vật phẩm phần mềm cuối cùng tự đứng và có thể được kiểm tra bởi bất kỳ ai.
Thật vậy, ai đó đánh giá bằng chứng không cần biết hoặc quan tâm đến quá trình phát triển (điều này cũng làm cho nó tương thích hơn với sự phát triển nguồn mở).
Bằng chứng không phải dựa vào việc đăng xuất tài liệu về cơ bản là "Chúng tôi đã xem xét mã cẩn thận và tất cả các bài kiểm tra của chúng tôi đều vượt qua.
Loại bằng chứng đó là tuyệt vời, nhưng nó là bằng chứng gián tiếp và nó không chính xác hoặc nghiêm ngặt.

In principle this kind of mathematical approach can give us an extremely high level of assurance. One can use a piece of software called a proof assistant (such as Coq or Isabelle) which provides a machine-readable logical language for writing specifications and proofs â€“ and it can automatically check that the proofs are correct. This is not the kind of proof where a human mathematician checking the proof has to fill in the details in their head, but the logicianâ€™s kind of proof that is ultra pernickety with no room left for human error.

Về nguyên tắc, loại phương pháp toán học này có thể cho chúng ta một mức độ đảm bảo cực kỳ cao.
Người ta có thể sử dụng một phần mềm có tên là Trợ lý bằng chứng (như CoQ hoặc Isabelle) cung cấp ngôn ngữ logic có thể đọc được bằng máy để viết thông số kỹ thuật và bằng chứng-và nó có thể tự động kiểm tra xem bằng chứng có chính xác không.
Đây không phải là loại bằng chứng mà một nhà toán học của con người kiểm tra bằng chứng phải điền vào các chi tiết trong đầu của họ, nhưng loại bằng chứng của logician là cực kỳ khó khăn mà không còn chỗ cho lỗi của con người.

While this is perhaps the pinnacle of high assurance it is important to note that cryptocurrencies are not going to get there any time soon. Itâ€™s mostly down to time and cost, but also due to some annoying gaps between the languages of formal proof tools and the programming languages we use to implement systems.

Mặc dù đây có lẽ là đỉnh cao của sự đảm bảo cao, điều quan trọng cần lưu ý là tiền điện tử sẽ không đến đó sớm.
Nó chủ yếu là thời gian và chi phí, nhưng cũng do một số khoảng trống khó chịu giữa các ngôn ngữ của các công cụ chứng minh chính thức và các ngôn ngữ lập trình chúng tôi sử dụng để triển khai các hệ thống.

But realistically, we can expect to get much better evidence and assurance than we have today. Another benefit of taking an approach based on mathematical specification is that we very often end up with better designs: simpler, easier to test, easier to reason about later.

Nhưng thực tế, chúng ta có thể mong đợi có được bằng chứng và đảm bảo tốt hơn nhiều so với chúng ta có ngày hôm nay.
Một lợi ích khác của việc thực hiện một cách tiếp cận dựa trên đặc điểm kỹ thuật toán học là chúng tôi rất thường xuyên kết thúc với các thiết kế tốt hơn: đơn giản hơn, dễ kiểm tra hơn, dễ dàng hơn để lý luận sau này.

## **Programming from specifications**

## ** Lập trình từ thông số kỹ thuật **

In practice we do not first write a specification then write a program to implement the spec and then try to prove that the program satisfies the specification. There is typically too big a gap between the specification and implementation to make that tractable. But it also turns out that having a formal specification is a really useful aid *during* the process of designing and implementing the program.

Trong thực tế, trước tiên chúng tôi không viết một đặc điểm kỹ thuật sau đó viết một chương trình để thực hiện thông số kỹ thuật và sau đó cố gắng chứng minh rằng chương trình thỏa mãn đặc điểm kỹ thuật.
Thông thường có một khoảng cách quá lớn giữa đặc điểm kỹ thuật và triển khai để làm cho điều đó có thể điều đó.
Nhưng nó cũng chỉ ra rằng có một đặc điểm kỹ thuật chính thức là một trợ giúp thực sự hữu ích * trong quá trình * quá trình thiết kế và thực hiện chương trình.

The idea is that we start with a specification and iteratively *refine* it until it is more or less equivalent to an implementation that we would be happy with. Each refinement step produces another specification that is â€“ in a particular formal sense â€“ equivalent to the previous specification, but more detailed. This approach gives us an implementation that is correct by construction, since we transform the specification into an implementation, and provided that each refinement step is correct then we have a very straightforward argument that the implementation is correct. These refinement steps are not just mechanical. They often involve creativity. It is where we get to make design decisions.

Ý tưởng là chúng tôi bắt đầu với một đặc điểm kỹ thuật và lặp đi lặp lại * tinh chỉnh * nó cho đến khi nó ít nhiều tương đương với một triển khai mà chúng tôi sẽ hài lòng.
Mỗi bước sàng lọc tạo ra một đặc điểm kỹ thuật khác, theo nghĩa chính thức cụ thể - tương đương với đặc điểm kỹ thuật trước đó, nhưng chi tiết hơn.
Cách tiếp cận này cho chúng tôi một triển khai chính xác bằng cách xây dựng, vì chúng tôi chuyển đổi đặc tả thành một triển khai và với điều kiện mỗi bước sàng lọc là chính xác thì chúng tôi có một lập luận rất đơn giản rằng việc thực hiện là chính xác.
Những bước sàng lọc không chỉ là cơ học.
Họ thường liên quan đến sự sáng tạo.
Đó là nơi chúng tôi có thể đưa ra quyết định thiết kế.

To get a sense of what all this means, letâ€™s look at the example of Ouroboros. Ouroboros is a blockchain consensus protocol. Its key innovation is that it does not rely on *Proof of Work*, instead relying on *Proof of Stake*. It has been developed by a team of academic cryptography researchers, led by IOHK Chief Scientist [Aggelos Kiayias](tmp//en/team/aggelos-kiayias/ "Prof. Aggelos Kiayias, PhD, IOHK profile"). They have an [academic paper, Ouroboros](tmp//en/research/papers/#9BKRHCSI "Ouroboros research paper; iohk.io") describing the protocol and mathematical proofs of security properties similar to that which Bitcoin achieves. This is a very high level mathematical description aimed for peer review by other academic cryptographers.

Để hiểu được tất cả những điều này có nghĩa là gì, hãy xem xét ví dụ về Ouroboros.
Ouroboros là một giao thức đồng thuận blockchain.
Sự đổi mới quan trọng của nó là nó không dựa vào *bằng chứng công việc *, thay vào đó dựa vào *bằng chứng cổ phần *.
Nó đã được phát triển bởi một nhóm các nhà nghiên cứu mật mã học thuật, dẫn đầu bởi nhà khoa học trưởng của IOHK [Aggelos Kiayias] (TMP // EN/Team/Aggelos-Kiayias/"Giáo sư Aggelos Kiayias, Tiến sĩ, hồ sơ IOHK").
Họ có một [bài báo học thuật, ouroboros] (TMP // EN/Nghiên cứu/Giấy tờ/#9BKRHCSI "Tài liệu nghiên cứu OuroBoros;
Đây là một mô tả toán học cấp độ rất cao nhằm mục đích đánh giá ngang hàng của các nhà mật mã học khác.

This is a great starting point. It is a relatively precise mathematical description of the protocol and we can rely on the proofs of the security properties. So in principle, if we could prove an implementation is equivalent (in the appropriate way) to the description in the paper, then the security proofs would apply to our implementation, which is a great place to be.

Đây là một điểm khởi đầu tuyệt vời.
Đó là một mô tả toán học tương đối chính xác của giao thức và chúng tôi có thể dựa vào các bằng chứng của các thuộc tính bảo mật.
Vì vậy, về nguyên tắc, nếu chúng ta có thể chứng minh việc triển khai là tương đương (theo cách thích hợp) với mô tả trong bài báo, thì các bằng chứng bảo mật sẽ áp dụng cho việc thực hiện của chúng tôi, đây là một nơi tuyệt vời.

So how do we go from this specification to an implementation following the â€œcorrect by constructionâ€ approach? First we have to make the protocol specification from the paper more precise. It may seem surprising that we have to make a specification more precise than the one the cryptographers wrote, but this because it was written for other human cryptographers and not for machines. For the refinement process we need to be more like the pernickety logicians. So we have to take the protocol specification written in terms of English and mathematical symbols and redefine it in some suitable logical formalism that doesnâ€™t leave any room for ambiguity.

Vì vậy, làm thế nào để chúng ta đi từ đặc điểm kỹ thuật này đến một triển khai sau cách tiếp cận của xây dựng?
Đầu tiên chúng ta phải làm cho đặc tả giao thức từ bài báo chính xác hơn.
Có vẻ đáng ngạc nhiên khi chúng ta phải làm cho một đặc điểm kỹ thuật chính xác hơn so với cái mà các nhà mật mã đã viết, nhưng điều này bởi vì nó được viết cho các nhà mật mã học khác của con người chứ không phải cho máy móc.
Đối với quá trình sàng lọc, chúng ta cần giống như các nhà logicer nhạy bén hơn.
Vì vậy, chúng tôi phải lấy đặc tả giao thức được viết theo các biểu tượng tiếng Anh và toán học và xác định lại nó trong một số hình thức logic phù hợp mà không để lại bất kỳ chỗ nào cho sự mơ hồ.

We then have to embark on the process of refinement. The initial specification is the most abstract and least detailed. It says what must be done but has very little detail about how. If I have a more detailed specification that is a refinement of the initial specification then what that means intuitively is: if you are happy with the initial specification then you would be happy with the new specification. You can have different refinements of the same specification: they differ in details that are not covered in the original specification. Refinement also has a quite specific formal meaning, though it depends on exactly what formalism youâ€™re using. In process calculi, refinement is described in terms of possible observed behaviours. One specification is a refinement of the other if the set of possible observed behaviours are equivalent to the other. Formally the kind of equivalence we need is what is known as a [bisimulation](https://en.wikipedia.org/wiki/Bisimulation "Wikipedia, Bisimulation").

Sau đó chúng tôi phải bắt tay vào quá trình sàng lọc. Thông số kỹ thuật ban đầu là trừu tượng nhất và ít chi tiết nhất. Nó nói những gì phải được thực hiện nhưng có rất ít chi tiết về cách làm thế nào. Nếu tôi có một đặc điểm kỹ thuật chi tiết hơn, đó là sự tinh chỉnh của đặc điểm kỹ thuật ban đầu thì điều đó có nghĩa là gì theo trực giác: nếu bạn hài lòng với đặc điểm kỹ thuật ban đầu thì bạn sẽ hài lòng với đặc điểm kỹ thuật mới. Bạn có thể có các tinh chỉnh khác nhau của cùng một đặc điểm kỹ thuật: chúng khác nhau về các chi tiết không được đề cập trong thông số kỹ thuật ban đầu. Sự tinh chỉnh cũng có một ý nghĩa chính thức khá cụ thể, mặc dù nó phụ thuộc vào chính xác những gì mà chủ nghĩa hình thức mà bạn đang sử dụng. Trong quá trình tính toán, sự tinh chỉnh được mô tả theo các hành vi quan sát có thể. Một đặc điểm kỹ thuật là sự tinh chỉnh của cái kia nếu tập hợp các hành vi quan sát có thể tương đương với cái khác. Chính thức loại tương đương chúng ta cần là những gì được gọi là [phân chia] (https://en.wikipedia.org/wiki/Bisimulation "Wikipedia, Bisimulation").

In the case of Ouroboros we start with a very abstract specification. In particular it says very little about how the network protocol works: it describes things in terms of a reliable network broadcast operation. Of course real networks work in terms of unreliable unicast operations. There are many ways to implement broadcast. The initial specification doesnâ€™t say. And it rightly doesnâ€™t care. Any suitable choice will do. This is an example where we get to make a design choice.

Trong trường hợp của Ouroboros, chúng tôi bắt đầu với một đặc điểm kỹ thuật rất trừu tượng.
Cụ thể, nó nói rất ít về cách thức hoạt động của giao thức mạng: nó mô tả mọi thứ theo hoạt động phát sóng mạng đáng tin cậy.
Tất nhiên các mạng thực sự hoạt động về các hoạt động unicast không đáng tin cậy.
Có nhiều cách để thực hiện phát sóng.
Các đặc điểm kỹ thuật ban đầu không nói.
Và nó đúng không quan tâm.
Bất kỳ lựa chọn phù hợp sẽ làm.
Đây là một ví dụ mà chúng ta có thể đưa ra lựa chọn thiết kế.

The original specification also describes the protocol in terms of broadcasting entire blockchains. That is the whole chain back to the genesis block. This is not intended to be realistic. It is described this way because it makes the proofs in the paper easier. Obviously a real implementation needs to work in terms of sending blocks. So this is another case for refinement. We have to come up with a scheme where protocol participants broadcast and receive blocks and show how this is equivalent to the version that broadcasts chains. This is an interesting example because we are changing the observed behaviour of protocol participants: in one version we observe them broadcasting chains and in the other broadcasting blocks. The two do not match up in a trivial way but we should still be able to prove a bisimulation.

Thông số kỹ thuật ban đầu cũng mô tả giao thức về mặt phát sóng toàn bộ blockchains.
Đó là toàn bộ chuỗi trở lại khối Genesis.
Điều này không nhằm mục đích thực tế.
Nó được mô tả theo cách này bởi vì nó làm cho các bằng chứng trong bài báo dễ dàng hơn.
Rõ ràng một triển khai thực sự cần phải làm việc về mặt gửi các khối.
Vì vậy, đây là một trường hợp khác để sàng lọc.
Chúng tôi phải đưa ra một sơ đồ trong đó những người tham gia giao thức phát sóng và nhận các khối và cho thấy điều này tương đương với phiên bản phát sóng chuỗi.
Đây là một ví dụ thú vị bởi vì chúng tôi đang thay đổi hành vi quan sát của những người tham gia giao thức: Trong một phiên bản, chúng tôi quan sát chúng các chuỗi phát sóng và trong các khối phát sóng khác.
Cả hai không khớp với một cách tầm thường nhưng chúng ta vẫn có thể chứng minh sự nhị phân.

There are numerous other examples like this: cases where the specification is silent on details or suggests unrealistic things. These all need to be refined to get closer to something we can realistically implement. When do we move from specification to implementation? That line is very fuzzy. It is a continuum, which comes back to the point that both specifications and programs are mathematical objects. With Ouroboros the form of specification is such that at each refinement step we can directly implement the specification â€“ at least as a simulation. In a simulation itâ€™s perfectly OK to broadcast whole chains or to omit details of the broadcast algorithm since we can simulate reliable broadcast directly. Being able to run simulations lets us combine the refinement based approach with a test or prototype based approach. We can check weâ€™re going in the right direction, or establish some kinds of simulated behaviour and evaluate different design decisions.

Có rất nhiều ví dụ khác như thế này: các trường hợp đặc điểm kỹ thuật im lặng về các chi tiết hoặc gợi ý những điều phi thực tế.
Tất cả những điều này cần phải được tinh chỉnh để đến gần hơn với một cái gì đó chúng ta có thể thực hiện một cách thực tế.
Khi nào chúng ta chuyển từ đặc điểm kỹ thuật sang thực hiện?
Dòng đó rất mờ.
Đó là một sự liên tục, trở lại đến mức cả thông số kỹ thuật và chương trình đều là đối tượng toán học.
Với Ouroboros, hình thức đặc tả là như vậy ở mỗi bước sàng lọc, chúng tôi có thể trực tiếp thực hiện đặc điểm kỹ thuật - ít nhất là một mô phỏng.
Trong một mô phỏng, hoàn toàn ổn khi phát toàn bộ chuỗi hoặc bỏ qua các chi tiết của thuật toán phát sóng vì chúng tôi có thể mô phỏng phát sóng đáng tin cậy trực tiếp.
Có thể chạy các mô phỏng cho phép chúng tôi kết hợp phương pháp dựa trên tinh chỉnh với phương pháp kiểm tra hoặc phương pháp dựa trên nguyên mẫu.
Chúng ta có thể kiểm tra chúng ta đi đúng hướng, hoặc thiết lập một số loại hành vi mô phỏng và đánh giá các quyết định thiết kế khác nhau.

There are also appropriate intermediate points in the refinement when it makes sense to think about performance and resource use. We cannot think about resource use with the original high-level Ouroboros specification. Its description in terms of chain broadcast makes a nonsense of any assessment of resources use. On the other hand, by the time we have fully working code is too late in the design process. There is a natural point during the refinement where we have a specification that is not too detailed but concrete enough to talk about resource use. At this point we can make some formal arguments about resource use. This is also an appropriate point to design policies for dealing with overload, fairness and quality of service. This is critical for avoiding denial of service attacks, and is not something that the high-level specification covers.

Ngoài ra còn có các điểm trung gian thích hợp trong việc sàng lọc khi có ý nghĩa khi nghĩ về hiệu suất và sử dụng tài nguyên.
Chúng ta không thể nghĩ về việc sử dụng tài nguyên với đặc tả OuroBoros cấp cao ban đầu.
Mô tả của nó về mặt phát sóng chuỗi làm cho bất kỳ đánh giá nào về việc sử dụng tài nguyên.
Mặt khác, vào thời điểm chúng tôi có mã làm việc đầy đủ là quá muộn trong quá trình thiết kế.
Có một điểm tự nhiên trong quá trình sàng lọc nơi chúng tôi có một đặc điểm kỹ thuật không quá chi tiết nhưng đủ cụ thể để nói về việc sử dụng tài nguyên.
Tại thời điểm này, chúng tôi có thể thực hiện một số đối số chính thức về việc sử dụng tài nguyên.
Đây cũng là một điểm thích hợp để thiết kế các chính sách để xử lý quá tải, công bằng và chất lượng dịch vụ.
Điều này là rất quan trọng để tránh từ chối các cuộc tấn công dịch vụ và không phải là thứ mà đặc điểm kỹ thuật cấp cao bao gồm.

Of course any normal careful design process will cover all these issues. The point is simply that these things can integrate with a formal refinement approach that builds an argument, step by step, as to why the resulting design and implementation do actually meet the specification.

Tất nhiên bất kỳ quá trình thiết kế cẩn thận bình thường sẽ bao gồm tất cả các vấn đề này.
Vấn đề chỉ đơn giản là những điều này có thể tích hợp với cách tiếp cận sàng lọc chính thức xây dựng một đối số, từng bước, vì lý do tại sao thiết kế và thực hiện kết quả thực sự đáp ứng đặc điểm kỹ thuật.

Finally itâ€™s worth looking at how much flexibility this kind of development process gives us with the trade-off between assurance and time and effort. At the low end we could take this approach and not actually formally prove anything, but just try to convince ourselves that we could if we needed to. This would mean that the final assurance argument looks like the following. We have cryptographers check that the protocol description in their paper is equivalent to our description in our logical formalism. This isnâ€™t a proof, just mathematicians saying they believe the two descriptions are equivalent. Then we have all the intermediate specifications in the sequence of refinements. Again, there are no formal proofs of refinement here, but the steps are relatively small and anyone could review them along with prose descriptions of why we believe them to be proper refinements. Finally we would have an implementation of the most refined specification, which should match up in a 1:1 way. Again, computer scientists would need to review these side by side to convince themselves that they are indeed equivalent.

Cuối cùng, đáng để xem xét mức độ linh hoạt của quá trình phát triển này mang lại cho chúng ta sự đánh đổi giữa đảm bảo và thời gian và nỗ lực. Ở cấp thấp, chúng ta có thể thực hiện phương pháp này và không thực sự chính thức chứng minh bất cứ điều gì, nhưng chỉ cần cố gắng thuyết phục bản thân rằng chúng ta có thể nếu chúng ta cần. Điều này có nghĩa là đối số đảm bảo cuối cùng trông giống như sau. Chúng tôi có các nhà mật mã kiểm tra xem mô tả giao thức trong bài báo của họ tương đương với mô tả của chúng tôi trong chủ nghĩa hình thức logic của chúng tôi. Đây không phải là một bằng chứng, chỉ là các nhà toán học nói rằng họ tin rằng hai mô tả là tương đương. Sau đó, chúng tôi có tất cả các thông số kỹ thuật trung gian trong chuỗi các tinh chỉnh. Một lần nữa, không có bằng chứng chính thức nào về sự tinh tế ở đây, nhưng các bước tương đối nhỏ và bất cứ ai cũng có thể xem xét chúng cùng với các mô tả văn xuôi về lý do tại sao chúng tôi tin rằng chúng là những sàng lọc thích hợp. Cuối cùng, chúng tôi sẽ có một triển khai các đặc điểm kỹ thuật tinh tế nhất, sẽ phù hợp theo cách 1: 1. Một lần nữa, các nhà khoa học máy tính sẽ cần phải xem xét các bên cạnh nhau để thuyết phục bản thân rằng chúng thực sự tương đương.

So this gives us some intermediate level of assurance but the development time isnâ€™t too exorbitant and there is a relatively clear path to higher assurance. To get higher assurance we would reformulate the original protocol description using a proof assistant. Then instead of getting a sign-off from mathematicians about two descriptions being equivalent, we could prove the security properties directly with the new description using the proof assistant. For each refinement step the task is clear: prove using the proof assistant that each one really is a refinement. The final jump between the most detailed refined specification and equivalent executable code is still tricky because we have to step outside the domain of the proof assistant.

Vì vậy, điều này cho chúng ta một số mức độ đảm bảo trung gian nhưng thời gian phát triển không quá cắt cổ và có một con đường tương đối rõ ràng để đảm bảo cao hơn.
Để có được sự đảm bảo cao hơn, chúng tôi sẽ cải cách mô tả giao thức ban đầu bằng cách sử dụng một trợ lý chứng minh.
Sau đó, thay vì nhận được một bản đăng xuất từ các nhà toán học về hai mô tả là tương đương, chúng tôi có thể chứng minh các thuộc tính bảo mật trực tiếp với mô tả mới bằng cách sử dụng trợ lý chứng minh.
Đối với mỗi bước sàng lọc, nhiệm vụ rõ ràng: Chứng minh sử dụng trợ lý bằng chứng rằng mỗi người thực sự là một sàng lọc.
Bước nhảy cuối cùng giữa đặc tả tinh tế chi tiết nhất và mã thực thi tương đương vẫn còn khó khăn vì chúng ta phải bước ra khỏi miền của Trợ lý bằng chứng.

With the current state of proof tools and programming language tools we donâ€™t have a great solution for producing a fully watertight proof that a program described in a proof assistant and in a similar programming language are really equivalent. There are a number of promising approaches that may become practical in the next few years, but theyâ€™re not quite there yet. So for the moment this would still require some manual checking. Really high assurance still has some practical constraints: for example we would need a verified compiler and runtime system. This illustrates the point that assurance is only as good as the weakest link and we should focus our efforts on the links where the risks are greatest.

Với trạng thái hiện tại của các công cụ chứng minh và các công cụ ngôn ngữ lập trình, chúng tôi không có một giải pháp tuyệt vời để tạo ra một bằng chứng đầy nước đầy đủ rằng một chương trình được mô tả trong một trợ lý chứng minh và trong một ngôn ngữ lập trình tương tự thực sự tương đương.
Có một số cách tiếp cận đầy hứa hẹn có thể trở nên thực tế trong vài năm tới, nhưng chúng vẫn chưa hoàn toàn ở đó.
Vì vậy, hiện tại, điều này vẫn sẽ yêu cầu một số kiểm tra thủ công.
Đảm bảo thực sự cao vẫn có một số ràng buộc thực tế: ví dụ chúng tôi sẽ cần một trình biên dịch được xác minh và hệ thống thời gian chạy.
Điều này minh họa điểm rằng sự đảm bảo chỉ tốt như liên kết yếu nhất và chúng ta nên tập trung nỗ lực vào các liên kết nơi rủi ro là lớn nhất.

## **Direction of travel**

## **Hướng di chuyển**

As a company, IOHK believes that cryptocurrencies are not a toy, and therefore believes that users are entitled to expect proper assurance.

Là một công ty, IOHK tin rằng tiền điện tử không phải là một món đồ chơi, và do đó tin rằng người dùng có quyền mong đợi sự đảm bảo thích hợp.

As a development team we have the ambition, skills and resources to make an implementation with higher assurance. We are embarking on the first steps of this formal development process now and over time we will see useful results. Our approach means the first tangible results will offer a degree of assurance and we will be able to improve this over time.

Là một nhóm phát triển, chúng tôi có tham vọng, kỹ năng và nguồn lực để thực hiện với sự đảm bảo cao hơn.
Chúng tôi đang bắt đầu các bước đầu tiên của quá trình phát triển chính thức này và theo thời gian, chúng tôi sẽ thấy kết quả hữu ích.
Cách tiếp cận của chúng tôi có nghĩa là kết quả hữu hình đầu tiên sẽ cung cấp một mức độ đảm bảo và chúng tôi sẽ có thể cải thiện điều này theo thời gian.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-05-12-cryptocurrencies-need-a-safeguard-to-prevent-another-dao-disaster.004.png)[ Cryptocurrencies need a safeguard to prevent another DAO disaster - Input Output](https://ucarecdn.com/f73bbb17-b79b-49b1-b1ae-4278fab218c5/-/inline/yes/ "Cryptocurrencies need a safeguard to prevent another DAO disaster - Input Output")

