# Daedalus Wallet launches for Ethereum Classic
### **The Grothendieck team’s Daedalus integration for the Mantis client is now live**
![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.002.png) 22 December 2017![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.003.png) 5 mins read

![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.004.png)[ Daedalus Wallet launches for Ethereum Classic - Input Output](https://ucarecdn.com/297e62ba-536e-42b9-9e1b-310616040825/-/inline/yes/ "Daedalus Wallet launches for Ethereum Classic - Input Output")

![Jeremy Wood](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![Daedalus Wallet launches for Ethereum Classic](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.009.jpeg)

I am pleased to be able to write about the latest release from [Team Grothendieck](tmp//en/projects/ethereum-classic/#team "Grothendieck Team") in conjunction with [Team Daedalus](tmp//en/projects/daedalus/#team "Daedalus Team"). It's called the Daedalus release and it combines the functionality of the highly thought out [Daedalus Wallet](tmp/daedaluswallet.io "Daedalus Wallet") and the Mantis Ethereum Classic Client.

Tôi rất vui khi có thể viết về bản phát hành mới nhất từ [Team Grothendieck] (TMP // EN/Project/Ethereum-Classic/#Team "Grothendieck Team") kết hợp với [Team Daedalus] (TMP // EN/Dự án
/Daedalus/#Team "Daedalus Team").
Nó được gọi là bản phát hành của Daedalus và nó kết hợp chức năng của [ví Daedalus] (TMP/Daedaluswallet.io "Daedalus Wallet") và máy khách Mantis Ethereum Classic.

The previous release of the Mantis client was the [beta release](tmp//en/blog/mantis-ethereum-classic-beta-release/ "Mantis Ethereum Classic Beta, iohk.io") in August and since then we've been busy both supporting the Daedalus integration and improving the code base, making it ready for production. 

Bản phát hành trước của ứng dụng khách Mantis là [bản phát hành beta] (TMP // EN/Blog/Mantis-Ethereum-Classic-Beta-RELEASE/"Mantis Ethereum Classic Beta, iohk.io") vào tháng 8 và kể từ đó
đang bận rộn cả hai hỗ trợ tích hợp Daedalus và cải thiện cơ sở mã, làm cho nó sẵn sàng để sản xuất.

We are now delighted to make our first release candidate available. [Download](https://github.com/input-output-hk/mantis/releases "Download Daedalus") the Daedalus Mantis integration for Windows 10 and MacOS. 

Bây giờ chúng tôi rất vui mừng khi làm cho ứng viên phát hành đầu tiên của chúng tôi có sẵn.
.

Make sure to check the downloaded binary file against the fingerprint listed on the download page!

Hãy chắc chắn kiểm tra tệp nhị phân đã tải xuống so với dấu vân tay được liệt kê trên trang tải xuống!

The installer installs both Mantis backend and Daedalus wallet and sets up a secure connection between them using an SSL certificate. 

Trình cài đặt cài đặt cả phụ trợ Mantis và ví Daedalus và thiết lập kết nối an toàn giữa chúng bằng chứng chỉ SSL.

The Mantis part of the integration has been packaged with a Java Virtual Machine included to allow fast and easy setup of the client. This initial release has focused on the basic wallet to wallet transfer function and enjoys the safety features Daedalus is known for. This is still very new software, it is *not recommended* to use this wallet for any high value transactions because we consider this release to be a live test. For users who already use Daedalus Wallet for Cardano, these are currently separate products: one targeting ETC users and one for Cardano users and *should not* be installed side by side. Near future releases will provide a more integrated experience. 

Phần bọ ngựa của tích hợp đã được đóng gói với một máy ảo Java được bao gồm để cho phép thiết lập máy khách nhanh chóng và dễ dàng.
Bản phát hành ban đầu này đã tập trung vào chức năng chuyển ví cơ bản sang ví và thích các tính năng an toàn Daedalus được biết đến.
Đây vẫn là phần mềm rất mới, nó không được khuyến nghị * sử dụng ví này cho bất kỳ giao dịch giá trị cao nào vì chúng tôi coi việc phát hành này là một bài kiểm tra trực tiếp.
Đối với người dùng đã sử dụng ví Daedalus cho Cardano, đây hiện là các sản phẩm riêng biệt: một người dùng nhắm mục tiêu và một người dùng cho người dùng Cardano và * không nên * được cài đặt cạnh nhau.
Các bản phát hành gần tương lai sẽ cung cấp một trải nghiệm tích hợp hơn.

Ethereum Classic, for all it strengths, suffers from the same synchronization issue as other blockchains – it takes an impractically long time. Reducing this time will be a priority for future releases but at the moment it's quite impractical to wait for days to sync up the chain, and a synchronized chain is required to allow use of the wallet. 

Ethereum Classic, đối với tất cả các điểm mạnh của nó, phải chịu cùng một vấn đề đồng bộ hóa như các blockchain khác - phải mất một thời gian dài không chính xác.
Giảm thời gian này sẽ là ưu tiên hàng đầu cho các bản phát hành trong tương lai nhưng tại thời điểm này, việc chờ đợi nhiều ngày là không thực tế, và cần có một chuỗi đồng bộ để cho phép sử dụng ví.

The solution for this is to use our prepackaged bootstrap databases. Anyone familiar with the beta release will remember the bootstrap databases we provided to users to circumvent the download wait. 

Giải pháp cho điều này là sử dụng cơ sở dữ liệu bootstrap được đóng gói sẵn của chúng tôi.
Bất cứ ai quen thuộc với bản phát hành beta sẽ nhớ cơ sở dữ liệu bootstrap mà chúng tôi cung cấp cho người dùng để phá vỡ sự chờ đợi tải xuống.

The easiest way to get a bootstrap database is through the installer. The installer will download a bootstrap database, check that there's enough free space (~33GB) and then check the downloaded file’s fingerprint. All that being done, it will unzip the file to the appropriate database folder and then clean up after itself. This process can take as little as fifteen minutes or in the worst case several hours depending on the network and disk resources available. The compressed bootstrap file itself is of the order of 10GB.

Cách dễ nhất để có được cơ sở dữ liệu bootstrap là thông qua trình cài đặt.
Trình cài đặt sẽ tải xuống cơ sở dữ liệu Bootstrap, kiểm tra xem có đủ không gian trống không (~ 33GB) và sau đó kiểm tra dấu vân tay tệp đã tải xuống.
Tất cả những gì đang được thực hiện, nó sẽ giải nén tệp vào thư mục cơ sở dữ liệu thích hợp và sau đó tự dọn dẹp.
Quá trình này có thể mất ít nhất mười lăm phút hoặc trong trường hợp xấu nhất vài giờ tùy thuộc vào tài nguyên mạng và đĩa có sẵn.
Bản thân tệp bootstrap nén là thứ tự 10GB.

The log file, located by default in the $HOME/.mantis/logs folder gives a step by step account of the download process.

Tệp nhật ký, được đặt theo mặc định trong thư mục $ home/.Mantis/log cung cấp một tài khoản từng bước của quá trình tải xuống.

Upon successful completion, starting the Daedalus wallet will show an almost synchronized database which should take less than an hour to complete its synchronization, depending on how many days pass between when the database was created and installation time.

Sau khi hoàn thành thành công, bắt đầu ví Daedalus sẽ hiển thị cơ sở dữ liệu gần như được đồng bộ hóa, mất ít hơn một giờ để hoàn thành đồng bộ hóa, tùy thuộc vào thời gian trôi qua giữa khi cơ sở dữ liệu được tạo và thời gian cài đặt.

The second way to install the bootstrap database is to make sure Mantis is stopped and then [download the file](https://github.com/input-output-hk/mantis/wiki/Bootstrap-Database-Download-Links "Matis Bootstrap Database, Github") and unzip it into the $HOME/.mantis/leveldb folder. Remember to delete or move the previous contents of the folder. When Daedalus is restarted, it will pick up the database and the wallet should be up to date in less than an hour. Again, the time will depend on how old the bootstrap database is at the time of download.

Cách thứ hai để cài đặt cơ sở dữ liệu Bootstrap là đảm bảo Mantis bị dừng và sau đó [Tải xuống tệp] (https://github.com/input-output
Cơ sở dữ liệu Bootstrap, GitHub ") và giải nén nó vào thư mục $ home/.Mantis/levelDB.
Hãy nhớ xóa hoặc di chuyển các nội dung trước đó của thư mục.
Khi Daedalus được khởi động lại, nó sẽ nhận cơ sở dữ liệu và ví nên được cập nhật trong vòng chưa đầy một giờ.
Một lần nữa, thời gian sẽ phụ thuộc vào cơ sở dữ liệu bootstrap cũ vào thời điểm tải xuống.

To protect your self against MITM attacks always compare the hash of the bootstrap database against the hash published on the [Mantis download website](https://github.com/input-output-hk/mantis/wiki/Bootstrap-Database-Download-Links "Mantis download website").

Để bảo vệ bản thân của bạn chống lại các cuộc tấn công MITM luôn so sánh hàm băm của cơ sở dữ liệu bootstrap với băm được xuất bản trên trang web [Mantis Download] (https://github.com/input-output-hk/mantis/wiki/bootstrap-database tải xuống tải xuống.
-Links "Trang web tải xuống Mantis").

macOS users must use the manual bootstrap method for now!

Người dùng MacOS phải sử dụng phương thức Bootstrap thủ công ngay bây giờ!

Users should be aware that stopping the wallet also stops the Mantis backend and so ends the synchronization process. 

Người dùng nên lưu ý rằng việc dừng ví cũng ngăn chặn phụ trợ Mantis và do đó kết thúc quá trình đồng bộ hóa.

As well as the Daedalus Mantis integration we also announce release candidate 1 of the Mantis command line client. This is a continuation of the command line client we released in August. It is almost identical but where the default configuration is set up for Daedalus, the command line default is set up for "normal" use. Normal use just means that any client can connect to Mantis over HTTP rather than over HTTPS. It also is available for use on Linux and contains no prepackaged JVM.

Cũng như tích hợp Daedalus Mantis, chúng tôi cũng thông báo về việc phát hành ứng cử viên 1 của ứng dụng khách lệnh Mantis.
Đây là sự tiếp nối của máy khách dòng lệnh mà chúng tôi đã phát hành vào tháng Tám.
Nó gần như giống hệt nhau nhưng trong đó cấu hình mặc định được thiết lập cho Daedalus, mặc định dòng lệnh được thiết lập cho việc sử dụng "bình thường".
Sử dụng bình thường chỉ có nghĩa là bất kỳ máy khách nào cũng có thể kết nối với Mantis qua HTTP thay vì qua HTTPS.
Nó cũng có sẵn để sử dụng trên Linux và không chứa JVM được đóng gói sẵn.

Apart from the wallet integration, CPU mining has been added to the feature list. In the last release we provided integration with an external miner, this version allows Mantis to perform CPU mining by simply turning on a flag in [the configuration](https://github.com/input-output-hk/mantis/wiki/General-Configuration "Mantis Wiki General Configuration, Github").

Ngoài việc tích hợp ví, khai thác CPU đã được thêm vào danh sách tính năng.
Trong bản phát hành cuối cùng, chúng tôi đã cung cấp tích hợp với một công cụ khai thác bên ngoài, phiên bản này cho phép Mantis thực hiện khai thác CPU bằng cách bật cờ trong [Cấu hình] (https://github.com/input-output-hk/mantis/wiki/
Cấu hình chung "Cấu hình chung của Mantis Wiki, GitHub").

At about 17.30 GMT on Monday 11 December the first block reward reduction took place, the visible effect of ECIP 1017 and Mantis handled it as expected. After block 5,000,000 the reward for mining a block was reduced by 1 ETC. It was vitally important that all clients implemented this change to prevent a network split. 

Vào khoảng 17.30 GMT vào thứ Hai ngày 11 tháng 12, việc giảm phần thưởng khối đầu tiên đã diễn ra, hiệu ứng có thể nhìn thấy của ECIP 1017 và Mantis đã xử lý nó như mong đợi.
Sau khi khối 5.000.000 phần thưởng cho việc khai thác một khối đã giảm 1, v.v.
Điều cực kỳ quan trọng là tất cả các khách hàng đã thực hiện thay đổi này để ngăn chặn sự phân chia mạng.

Peer discovery, maintaining a gradually changing list of good peers as discovered by asking our peers for their peers and so on is another feature added since the beta release. 

Discovery Peer, duy trì một danh sách thay đổi dần dần các đồng nghiệp tốt như được phát hiện bằng cách hỏi các đồng nghiệp của chúng tôi cho các đồng nghiệp của họ và vì vậy là một tính năng khác được thêm vào kể từ khi phát hành beta.

I witnessed a lot of hard work going into this code base and I'm very pleased for the whole Mantis team, Team Daedalus and our DevOps troops who wrestled tirelessly with our various continuous integration pipelines. Their hard work has culminated in a software release they can be very proud of. 

Tôi đã chứng kiến rất nhiều công việc khó khăn khi đi vào cơ sở mã này và tôi rất hài lòng với toàn bộ đội ngũ Mantis, Đội Daedalus và quân đội DevOps của chúng tôi đã vật lộn không mệt mỏi với các đường ống tích hợp liên tục khác nhau của chúng tôi.
Công việc khó khăn của họ đã lên đến đỉnh điểm trong một bản phát hành phần mềm mà họ có thể rất tự hào.

Christmas is just around the corner here in Ireland and will be a welcome break. But January 2018 will be here soon and we will start our security audit of the Mantis code base – and more technology related adventure beckons!

Giáng sinh chỉ quanh góc ở Ireland và sẽ là một kỳ nghỉ chào mừng.
Nhưng tháng 1 năm 2018 sẽ sớm có mặt và chúng tôi sẽ bắt đầu kiểm toán bảo mật của cơ sở mã Mantis - và nhiều cuộc phiêu lưu liên quan đến công nghệ vẫy gọi!

## **Attachments**

## ** tệp đính kèm **

![](img/2017-12-22-daedalus-wallet-launches-for-ethereum-classic.004.png)[ Daedalus Wallet launches for Ethereum Classic - Input Output](https://ucarecdn.com/297e62ba-536e-42b9-9e1b-310616040825/-/inline/yes/ "Daedalus Wallet launches for Ethereum Classic - Input Output")

