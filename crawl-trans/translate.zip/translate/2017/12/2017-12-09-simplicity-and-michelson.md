# Simplicity and Michelson
### **A programming language that is too simple**
![](img/2017-12-09-simplicity-and-michelson.002.png) 9 December 2017![](img/2017-12-09-simplicity-and-michelson.002.png)[ Prof Philip Wadler](tmp//en/blog/authors/philip-wadler/page-1/)![](img/2017-12-09-simplicity-and-michelson.003.png) 10 mins read

![](img/2017-12-09-simplicity-and-michelson.004.png)[ Simplicity and Michelson - Input Output](https://ucarecdn.com/cb0054f1-4e81-4617-82c2-6a6a363270c7/-/inline/yes/ "Simplicity and Michelson - Input Output")

![Prof Philip Wadler](img/2017-12-09-simplicity-and-michelson.005.png)[](tmp//en/blog/authors/philip-wadler/page-1/)
### [**Prof Philip Wadler**](tmp//en/blog/authors/philip-wadler/page-1/)
Senior Research Fellow

Academic Research

- ![](img/2017-12-09-simplicity-and-michelson.006.png)[](mailto:philip.wadler@iohk.io "Email")
- ![](img/2017-12-09-simplicity-and-michelson.007.png)[](tmp///www.youtube.com/watch?v=ofN8ui2oH8Y "YouTube")
- ![](img/2017-12-09-simplicity-and-michelson.008.png)[](tmp///twitter.com/philipwadler "Twitter")
## **Simplicity**
Only once in my life have I encountered a programming language that was too simple to use. That was Lispkit Lisp, developed by Peter Henderson, Geraint Jones, and Simon Jones, which I saw while serving as a postdoc at Oxford, 1983â€“87, and which despite its simplicity was used to implement an entire operating system. It is an indightment of the field of programming languages that I have not since encountered another system that I consider too simple. Until today. I can now add a second system to the list of those that are too simple, the appropriately-titled Simplicity, developed by Russell O'Connor of Blockstream. It is described by a paper [here](https://blockstream.com/simplicity.pdf "Simplicity: A New Language for Blockchains, blockstream.com") and a website [here](https://blockstream.com/2017/10/30/simplicity.html "Simlicity Itself for Blockchains").

Chỉ một lần trong đời, tôi đã gặp một ngôn ngữ lập trình quá đơn giản để sử dụng.
Đó là Lispkit Lisp, được phát triển bởi Peter Henderson, Geraint Jones và Simon Jones, mà tôi đã thấy khi phục vụ như một postdoc tại Oxford, 1983 € 87, và mặc dù sự đơn giản của nó đã được sử dụng để thực hiện toàn bộ hệ điều hành.
Đó là một sự chỉ định của lĩnh vực ngôn ngữ lập trình mà tôi chưa từng gặp phải một hệ thống khác mà tôi cho là quá đơn giản.
Cho đến ngày nay.
Bây giờ tôi có thể thêm một hệ thống thứ hai vào danh sách những người quá đơn giản, sự đơn giản có tiêu đề phù hợp, được phát triển bởi Russell O'Connor của Blockstream.
Nó được mô tả bởi một bài báo [ở đây] (https://blockstream.com/simplicity.pdf "Đơn giản: một ngôn ngữ mới cho blockchains, blockstream.com") và một trang web [tại đây] (https://blockstream.com/
2017/10/30/Đơn giản.html "Simlicity cho blockchains").

The core of Simplicity consists of just nine combinators: three for products (pair, take, and drop), three for sums (injl, injr, and case), one for unit (unit), and two for plumbing (iden and comp). It is throughly grounded in ideas from the functional programming, programming language, and formal methods communities.

Cốt lõi của sự đơn giản chỉ bao gồm chín bộ kết hợp: ba cho sản phẩm (cặp, lấy và thả), ba cho tổng (INSN, INSN và trường hợp), một cho đơn vị (đơn vị) và hai cho hệ thống ống nước (IDEN và COMP)
.
Nó được đặt nền tảng trong các ý tưởng từ lập trình chức năng, ngôn ngữ lập trình và các phương pháp chính thức.

When I call Simplicity too simple it is intended as a compliment. It is delightful to see full adders and cryptographic hash functions cobbled together using just products, sums, and units. It is eye-opening to see how far one can get without recursion or iteration, and how this enables simple analyses of the time and space required to execute a program. It is a confirmation to see a system with foundations in category theory and sequent calculus. Now I know what to say when developers respond to my talk "Categories for the Working Hacker" by asking "But how can we use this in practice?" 

Khi tôi gọi sự đơn giản quá đơn giản, nó được dự định là một lời khen.
Thật thú vị khi thấy các hàm bổ sung đầy đủ và hàm băm mật mã được ghép lại với nhau bằng các sản phẩm, tổng và đơn vị.
Đó là mở mắt để xem người ta có thể đi được bao xa mà không cần đệ quy, và cách này cho phép các phân tích đơn giản về thời gian và không gian cần thiết để thực hiện một chương trình.
Đó là một xác nhận để xem một hệ thống có nền tảng trong lý thuyết thể loại và tính toán liên tục.
Bây giờ tôi biết phải nói gì khi các nhà phát triển trả lời "danh mục nói chuyện của tôi cho tin tặc hoạt động" bằng cách hỏi "nhưng làm thế nào chúng ta có thể sử dụng điều này trong thực tế?"

The system is accompanied by a proof of its correctness in Coq, which sets a high bar for competing systems. O'Connor even claims to have a proof in Coq that the Simplicity implementation of SHA-256 matches the reference specification provided by Andrew Appel's Verified Software Toolchain project (VST), which VST proved corresponds to the OpenSSL implementation of SHA-256 in C.

Hệ thống này được đi kèm với một bằng chứng về tính chính xác của nó trong CoQ, đặt ra một thanh cao cho các hệ thống cạnh tranh.
O'Connor thậm chí tuyên bố có bằng chứng trong COQ rằng việc triển khai SHA-256 đơn giản phù hợp với đặc tả tham chiếu được cung cấp bởi Dự án Công cụ phần mềm đã được xác minh (VST) của Andrew Appel, VST đã chứng minh tương ứng với việc triển khai OPENSSL của SHA-256 trong C. C.

At IOHK, I have been involved in the design of Plutus Core, our own smart contract scripting language, working with Darryl McAdams, Duncan Coutts, Simon Thompson, Pablo Lamela Seijas, and Grigore Rosu and his semantics team. We have a formal specification which we are preparing for release. O'Connor's work on Simplicity has caused us to rethink our own work: what can we do to make it simpler? Thank you, Russell! 

Tại IOHK, tôi đã tham gia vào việc thiết kế Plutus Core, ngôn ngữ kịch bản hợp đồng thông minh của chúng tôi, làm việc với Darryl McAdams, Duncan Coutts, Simon Thompson, Pablo Lamela Seijas, và Grigore Rosu và nhóm ngữ nghĩa của anh ấy.
Chúng tôi có một đặc điểm kỹ thuật chính thức mà chúng tôi đang chuẩn bị để phát hành.
Công việc của O'Connor về sự đơn giản đã khiến chúng ta phải suy nghĩ lại về công việc của chính mình: Chúng ta có thể làm gì để làm cho nó đơn giản hơn?
Cảm ơn bạn, Russell!

That said, Simplicity is still too simple, and despite its emphasis on rigour there are some gaps in its description. 

Điều đó nói rằng, sự đơn giản vẫn còn quá đơn giản, và mặc dù nhấn mạnh vào sự nghiêm ngặt, có một số khoảng trống trong mô tả của nó.

## **Jets**

## ** Jets **

A 256-bit full adder is expressed with 27,348 combinators, meaning addition in Simplicity requires several orders of magnitude more work than the four 64-bit addition instructions one would normally use. Simplicity proposes a solution: any commonly used sequence of instructions may be abbreviated as a "jet", and implemented in any equivalent matter. Hence, the 27,348 combinators for the 256-bit full adder can be ignored, and replaced by the equivalent four 64-bit additions.

Một bộ cộng đầy đủ 256 bit được thể hiện với 27.348 tổ hợp, có nghĩa là sự bổ sung đơn giản đòi hỏi một số đơn đặt hàng có nhiều công việc lớn hơn so với bốn hướng dẫn bổ sung 64 bit mà người ta thường sử dụng.
Đơn giản đề xuất một giải pháp: Bất kỳ chuỗi hướng dẫn thường được sử dụng thường được viết tắt là "máy bay phản lực" và được thực hiện trong bất kỳ vấn đề tương đương nào.
Do đó, có thể bỏ qua 27.348 tổ hợp cho bộ cộng đầy đủ 256 bit và được thay thế bằng bốn bổ sung 64 bit tương đương.

All well and good, but this is where it gets too simple. No one can afford to be inefficient by several orders of magnitude. Hence, any programmer will need to know what jets exist and to exploit them whenever possible. In this sense, Simplicity is misleadingly simple. It would be clearer and cleaner to define each jet as an opcode. Each opcode could still be specified by its equivalent in the other combinators of Simplicity, but programs would be more compact, faster to execute, andâ€”most importantâ€”easier to read, understand, and analyse accurately. If one ignores jets, the analyses of time and space required to execute a program, given toward the end of the paper, will be uselessâ€”off by orders of magnitude. The list of defined jets is given nowhere in the paper. Nor could I spot additional information on Simplicity linked to from its web page or findable by a web search. More needs to be done before Simplicity can be used in practice. 

Tất cả đều tốt và tốt, nhưng đây là nơi nó trở nên quá đơn giản.
Không ai có thể đủ khả năng để không hiệu quả bởi một số bậc độ lớn.
Do đó, bất kỳ lập trình viên nào cũng sẽ cần biết những gì máy bay phản lực tồn tại và khai thác chúng bất cứ khi nào có thể.
Theo nghĩa này, sự đơn giản là đơn giản sai lầm.
Sẽ rõ ràng hơn và sạch hơn để xác định từng máy bay phản lực là một opcode.
Mỗi opcode vẫn có thể được chỉ định bởi tương đương của nó trong các kết hợp đơn giản khác, nhưng các chương trình sẽ nhỏ gọn hơn, nhanh hơn để thực hiện và quan trọng nhất là dễ đọc, hiểu và phân tích chính xác.
Nếu một người bỏ qua các máy bay phản lực, các phân tích về thời gian và không gian cần thiết để thực hiện một chương trình, được đưa ra vào cuối bài báo, sẽ vô dụng bởi các đơn đặt hàng có độ lớn.
Danh sách các máy bay phản lực được xác định không được đưa ra trong bài báo.
Tôi cũng không thể phát hiện ra thông tin bổ sung về tính đơn giản được liên kết từ trang web của nó hoặc tìm thấy bằng tìm kiếm trên web.
Nhiều cần phải được thực hiện trước khi đơn giản có thể được sử dụng trong thực tế.

## **Gaps**

## ** GAPS **

It's not just the definition of jets which is absent from the paper, and cannot be found elsewhere on the web. Lots more remains to be supplied. 

Đó không chỉ là định nghĩa của các máy bay không có trong tờ giấy và không thể tìm thấy ở nơi khác trên web.
Rất nhiều vẫn còn được cung cấp.

- Sections 2.4, 2.5, 3.2 claim proofs in Coq, but apart from defining the semantics of the nine combinators in Appendix A, no Coq code is available for scrutiny.

- Phần 2.4, 2.5, 3.2 Bằng chứng yêu cầu trong CoQ, nhưng ngoài việc xác định ngữ nghĩa của chín bộ kết hợp trong Phụ lục A, không có mã CoQ nào có sẵn để xem xét kỹ lưỡng.

- Section 2.5 claims a representation of Simplicity terms as a dag, but it is not specified. Lacking this, there is no standard way to exchange code written in Simplicity.

- Phần 2.5 tuyên bố một đại diện của các thuật ngữ đơn giản là DAG, nhưng nó không được chỉ định.
Thiếu điều này, không có cách nào tiêu chuẩn để trao đổi mã được viết một cách đơn giản.

- Section 4.4 defines an extended semantics for Simplicity that can read the signature of the current transaction, support Merklised abstract syntax trees, and fail when a transaction does not validate. It also lifts meanings of core (unextended) Simplicity programs to the extended semantics. However, it says nothing about how the seven combinators that combine smaller Simplicity programs into bigger ones act in the extended semantics! It's not hard to guess the intended definitions, but worrying that they were omitted from a paper that aims for rigour.

- Phần 4.4 xác định một ngữ nghĩa mở rộng cho sự đơn giản có thể đọc chữ ký của giao dịch hiện tại, hỗ trợ các cây cú pháp trừu tượng Merklised và thất bại khi một giao dịch không xác nhận.
Nó cũng nâng ý nghĩa của các chương trình đơn giản cốt lõi (không mở rộng) lên ngữ nghĩa mở rộng.
Tuy nhiên, nó không nói gì về cách bảy tổ hợp kết hợp các chương trình đơn giản nhỏ hơn thành các chương trình lớn hơn hành động trong ngữ nghĩa mở rộng!
Không khó để đoán các định nghĩa dự định, nhưng lo lắng rằng chúng bị bỏ qua từ một bài báo nhằm mục đích nghiêm ngặt.

- Section 3 provides a Bit Machine to model the space and time required to execute Simplicity. The model is of limited use, since it ignores the several orders of magnitude improvement offered by jets. Further, the Bit Machine has ten instructions, enumerated on pages 10â€“12, but the list omits the vital "case" instruction which appears in Figure 2. Again, it's not hard to guess, but worrying it was omitted.

- Phần 3 cung cấp một máy BIT để mô hình hóa không gian và thời gian cần thiết để thực hiện tính đơn giản.
Mô hình này được sử dụng hạn chế, vì nó bỏ qua một số thứ tự cải thiện cường độ được cung cấp bởi Jets.
Hơn nữa, máy bit có mười hướng dẫn, được liệt kê trên các trang 10 € 12, nhưng danh sách bỏ qua hướng dẫn "trường hợp" quan trọng xuất hiện trong Hình 2. Một lần nữa, không khó để đoán, nhưng lo lắng nó đã bị bỏ qua.

## **Michelson**

## ** Michelson **

A second language for scripting blockchains is Michelson. It is described by a paper [here](https://www.tezos.com/static/papers/language.pdf "Michelson: the language of Smart Contracts in Tezos, tezos.com") and a website [here](https://www.michelson-lang.com/ "The Michelson Language, michelson-lang.com"). (Oddly, the website fails to link to the paper.)

Một ngôn ngữ thứ hai cho các blockchains kịch bản là Michelson.
Nó được mô tả bởi một bài báo [ở đây] (https://www.tezos.com/static/papers/language.pdf "Michelson: Ngôn ngữ của các hợp đồng thông minh ở Tezos, Tezos.com") và một trang web [ở đây] (
https://www.michelson-lang.com/ "Ngôn ngữ Michelson, Michelson-Lang.com").
(Thật kỳ lạ, trang web không liên kết với bài báo.)

I will offer just one word on Michelson. The word is: "Why?" Michelson takes many ideas from the functional programming community, including higher-order functions, data structures such as lists and maps, and static type safety. 

Tôi sẽ chỉ cung cấp một từ trên Michelson.
Từ này là: "Tại sao?"
Michelson lấy nhiều ý tưởng từ cộng đồng lập trình chức năng, bao gồm các chức năng bậc cao, cấu trúc dữ liệu như danh sách và bản đồ và an toàn loại tĩnh.

Currently, it is also much more thoroughly described and documented than Simplicity. All of this is to be commended.

Hiện tại, nó cũng được mô tả và ghi lại kỹ lưỡng hơn nhiều so với đơn giản.
Tất cả điều này sẽ được khen ngợi.

But Michelson is an inexplicably low-level language, requiring the programmer to explicitly manipulate a stack. Perhaps this was done so that there is an obvious machine model, but Simplicity offers a far superior solution: a high-level model for programming, which compiles to a low-level model (the Bit Machine) to explicate time and space costs. 

Nhưng Michelson là một ngôn ngữ cấp thấp không thể giải thích được, yêu cầu lập trình viên phải thao túng rõ ràng một ngăn xếp.
Có lẽ điều này đã được thực hiện để có một mô hình máy rõ ràng, nhưng sự đơn giản cung cấp một giải pháp vượt trội hơn nhiều: một mô hình cấp cao để lập trình, biên dịch cho một mô hình cấp thấp (máy bit) để giải thích chi phí thời gian và không gian.

Or perhaps Michelson is low-level to improve efficiency. Most of the cost of evaluating a smart contract is in cryptographic primitives. The rest is cheap, whether compiled or interpreted. Saving a few pennies of electricity by adopting an error prone languageâ€”where there is a risk of losing millions of dollars in an exploitâ€”is a false economy indeed. Premature optimisation is the root of all evil. 

Hoặc có lẽ Michelson là cấp thấp để cải thiện hiệu quả.
Hầu hết các chi phí đánh giá một hợp đồng thông minh là trong các nguyên thủy mật mã.
Phần còn lại là rẻ, cho dù được biên soạn hay giải thích.
Tiết kiệm một vài đồng xu điện bằng cách áp dụng một ngôn ngữ dễ bị lỗi - nơi có nguy cơ mất hàng triệu đô la trong một khai thác thực sự là một nền kinh tế sai lầm.
Tối ưu hóa sớm là gốc rễ của mọi điều ác.

The language looks a bit like all the bad parts of Forth and Lisp, without the unity that makes each of those languages a classic. Lisp idioms such as CAAR and CDADAR are retained, with new ones like DUUP, DIIIIP, and PAAIAIAAIR thrown in. 

Ngôn ngữ trông hơi giống tất cả các phần xấu của Forth và Lisp, mà không có sự thống nhất làm cho mỗi ngôn ngữ đó trở thành một tác phẩm kinh điển.
Các thành ngữ của Lisp như Caar và CDadar được giữ lại, với những người mới như DUUP, DIIIIP và Paaiaiair ném vào.

There is a fair set of built-in datatypes, including strings, signed and unsigned integers, unit, product, sum, options, lists, sets, maps, and higher-order functions. But there is no way for users to define their own data types. There is no way to name a variable or a routine; everything must be accessed by navigating a data structure on the stack. 

Có một bộ công bằng các kiểu dữ liệu tích hợp, bao gồm các chuỗi, số nguyên đã ký và không dấu, đơn vị, sản phẩm, tổng, tùy chọn, danh sách, bộ, bản đồ và các hàm bậc cao hơn.
Nhưng không có cách nào để người dùng xác định các loại dữ liệu của riêng họ.
Không có cách nào để đặt tên cho một biến hoặc một thói quen;
Mọi thứ phải được truy cập bằng cách điều hướng cấu trúc dữ liệu trên ngăn xếp.

Some operations are specified formally, but others are left informal. For lists, we are given formal rewriting rules for the first three operators (CONS, NIL, IF\_CONS) but not the last two (MAP, REDUCE). Type rules are given in detail, but the process of type inference is not described, leaving me with some questions about which programs are well typed and which are not. It reminds me of a standard problem one sees in early work by studentsâ€”the easy parts are thoroughly described, but the hard parts are glossed over. 

Một số hoạt động được chỉ định chính thức, nhưng một số khác là không chính thức.
Đối với các danh sách, chúng tôi được cung cấp các quy tắc viết lại chính thức cho ba toán tử đầu tiên (nhược điểm, không, nếu \ _cons) nhưng không phải là hai toán tử cuối cùng (MAP, giảm).
Các quy tắc loại được đưa ra chi tiết, nhưng quá trình suy luận loại không được mô tả, để lại cho tôi một số câu hỏi về chương trình nào được gõ tốt và cái nào không.
Nó làm tôi nhớ đến một vấn đề tiêu chuẩn mà người ta thấy trong công việc ban đầu của các sinh viên, các phần dễ dàng được mô tả kỹ lưỡng, nhưng các phần cứng được che đậy.

If I have understood correctly, the inference rules assign types that are monomorphic, meaning each term has exactly one type. This omits one of the most successful ideas in functional programming, polymorphic routines that act on many types. It means back to the bad old days of Pascal, where one has to write one routine to sort a list of integers and a different routine to sort a list of strings. 

Nếu tôi đã hiểu chính xác, các quy tắc suy luận gán các loại đơn hình, có nghĩa là mỗi thuật ngữ có chính xác một loại.
Điều này bỏ qua một trong những ý tưởng thành công nhất trong lập trình chức năng, các thói quen đa hình hoạt động theo nhiều loại.
Nó có nghĩa là trở lại những ngày xưa tồi tệ của Pascal, nơi người ta phải viết một thói quen để sắp xếp một danh sách các số nguyên và một thói quen khác để sắp xếp một danh sách các chuỗi.

Several of these shortcomings are also shared by Simplicity. But whereas Simplicity is intended as a compilation target, not to be read by humans, the Michelson documentation includes a large collection of examples suggesting it is intended for humans to write and read. 

Một số trong những thiếu sót này cũng được chia sẻ bởi sự đơn giản.
Nhưng trong khi sự đơn giản được dự định là mục tiêu tổng hợp, không được đọc bởi con người, tài liệu Michelson bao gồm một bộ sưu tập lớn các ví dụ cho thấy nó dành cho con người viết và đọc.

Here is one of the simpler examples from the paper. 

Đây là một trong những ví dụ đơn giản hơn từ bài báo.

{ DUP ; CDAAR ; # T

{Dup;
CDAAR;
# T

NOW ;

BÂY GIỜ ;

COMPARE ; LE ;

SO SÁNH ;
Le;

IF { DUP ; CDADR ; # N

Nếu {dup;
CDADR;
# N

`     `BALANCE ;

`` Cân bằng;

`     `COMPARE ; LE ;

`` So sánh;
Le;

`     `IF { CDR ; UNIT ; PAIR }

`` Nếu {cdr;
ĐƠN VỊ ;
Cặp}

`        `{ DUP ; CDDDR ; # B

`` {Dup;
CDDDR;
# B

`          `BALANCE ; UNIT ;

`` Cân bằng;
ĐƠN VỊ ;

`          `DIIIP { CDR } ;

`` DIIIP {cdr};

`          `TRANSFER\_TOKENS ;

`` Chuyển giao \ _Tokens;

`          `PAIR } }

`` Cặp}}

`   `{ DUP ; CDDAR ; # A

`` {Dup;
CDDAR;
# MỘT

`     `BALANCE ;

`` Cân bằng;

`     `UNIT ;

`` Đơn vị;

`     `DIIIP { CDR } ;

`` DIIIP {cdr};

`     `TRANSFER\_TOKENS ;

`` Chuyển giao \ _Tokens;

`     `PAIR } }

`` Cặp}}

The comment # T is inserted as a reminder that CDAAR extracts variable T, and similarly for the other variables N, B, and A. This isn't the 1950s. Why don't we write T when we mean T, instead of CDAAR? WHY ARE WE WRITING IN ALL CAPS? 

Nhận xét # T được chèn dưới dạng một lời nhắc nhở rằng CDAAR trích xuất biến T và tương tự cho các biến khác N, B và A. Đây không phải là những năm 1950.
Tại sao chúng ta không viết T khi chúng ta có nghĩa là T, thay vì CDAAR?
Tại sao chúng ta viết trong tất cả các mũ?

In short, Michelson is a bizarre mix of some of the best and worst of computing.

Nói tóm lại, Michelson là một sự pha trộn kỳ quái của một số tính toán tốt nhất và tồi tệ nhất.

## **Conclusion**

## **Sự kết luận**

It is exciting to see ideas from the functional programming, programming languages, and formal methods communities gaining traction among cryptocurrencies and blockchains. While there are shortcomings, it is fantastic to see an appreciation of how these techniques can be applied to increase reliabilityâ€”something which the multi-million dollar exploits against Ethereum show is badly needed. I look forward to participating in the conversations that ensue!

Thật thú vị khi thấy các ý tưởng từ lập trình chức năng, ngôn ngữ lập trình và cộng đồng phương pháp chính thức đạt được sức hút giữa các loại tiền điện tử và blockchains.
Mặc dù có những thiếu sót, thật tuyệt vời khi thấy sự đánh giá cao về cách các kỹ thuật này có thể được áp dụng để tăng độ tin cậy-một cái gì đó mà số tiền khai thác trị giá hàng triệu đô la đối với Ethereum Show là rất cần thiết.
Tôi mong muốn được tham gia vào các cuộc trò chuyện xảy ra sau đó!

### **Postscript**

### ** PostScript **

The conversation has begun! [Tezos](https://www.tezos.com/ "tezos.com") have put up a page to explain [Why Michelson](http://www.michelson-lang.com/why-michelson.html "Why Michelson? michelson-lang.com"). I've also learned there is a higher-level language intended to compile into Michelson, called [Liquidity](http://www.liquidity-lang.org/ "liquidity-lang.org").

Cuộc trò chuyện đã bắt đầu!
[Tezos] (https://www.tezos.com/ "Tezos.com") đã đưa ra một trang để giải thích [tại sao Michelson] (http://www.michelson-lang.com/why-michelson.html "
Tại sao Michelson? Michelson-lang.com ").
Tôi cũng đã học được rằng có một ngôn ngữ cấp cao hơn nhằm biên dịch vào Michelson, được gọi là [thanh khoản] (http://www.liquicity-lang.org/ "thanh khoản-lang.org").

## **Attachments**

## ** tệp đính kèm **

![](img/2017-12-09-simplicity-and-michelson.004.png)[ Simplicity and Michelson - Input Output](https://ucarecdn.com/cb0054f1-4e81-4617-82c2-6a6a363270c7/-/inline/yes/ "Simplicity and Michelson - Input Output")

