# IELE: A New Virtual Machine for the Blockchain
### **Specialized smart contract execution on the blockchain**
![](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.002.png) 15 December 2017![](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.002.png)[ Grigore Rosu](tmp//en/blog/authors/grigore-rosu/page-1/)![](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.003.png) 8 mins read

![](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.004.png)[ IELE- A New Virtual Machine for the Blockchain - Input Output](https://ucarecdn.com/0dc38324-8874-47e4-9376-d03adaa32a42/-/inline/yes/ "IELE- A New Virtual Machine for the Blockchain - Input Output")

![Grigore Rosu](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.005.png)[](tmp//en/blog/authors/grigore-rosu/page-1/)
### [**Grigore Rosu**](tmp//en/blog/authors/grigore-rosu/page-1/)
President/CEO Runtime Verification

![IELE: A New Virtual Machine for the Blockchain](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.006.jpeg)

Runtime Verification (RV) is proud to release their first version of IELE, a new virtual machine for the blockchain.

Xác minh thời gian chạy (RV) tự hào phát hành phiên bản đầu tiên của IELE, một máy ảo mới cho blockchain.

## **What is IELE?**

## ** iele là gì? **

IELE is a variant of [LLVM](http://llvm.org/ "llvm.org") specialized to execute smart contracts on the blockchain. Its design, definition and implementation have been done at the highest mathematical standards, following a semantics-first approach with verification of smart contracts as a major objective. Specifically, we have defined the formal syntax and semantics of IELE using the K framework, which in return gives us an executable reference model in addition to a series of program analysis tools, including a program verifier. K was created by our team during the last 15 years and incorporates the state of the art in language design, semantics and formal methods. The design of IELE was based on our experience with formally defining [dozens of languages in K](https://github.com/kframework "K Framework, Github"), but especially on recent experience and lessons learned while formally defining two other virtual machines in K, namely:

IELE là một biến thể của [LLVM] (http://llvm.org/ "llvm.org") chuyên thực hiện các hợp đồng thông minh trên blockchain.
Thiết kế, định nghĩa và thực hiện của nó đã được thực hiện ở các tiêu chuẩn toán học cao nhất, theo cách tiếp cận thứ nhất ngữ nghĩa với việc xác minh các hợp đồng thông minh là một mục tiêu chính.
Cụ thể, chúng tôi đã xác định cú pháp chính thức và ngữ nghĩa của IELE bằng cách sử dụng khung K, mà đổi lại cho chúng tôi một mô hình tham chiếu thực thi ngoài một loạt các công cụ phân tích chương trình, bao gồm cả trình xác minh chương trình.
K được tạo ra bởi nhóm của chúng tôi trong 15 năm qua và kết hợp trạng thái nghệ thuật trong thiết kế ngôn ngữ, ngữ nghĩa và phương pháp chính thức.
Thiết kế của IELE dựa trên kinh nghiệm của chúng tôi với việc xác định chính thức [hàng chục ngôn ngữ trong K] (https://github.com/kframework "K Framework, GitHub"), nhưng đặc biệt là về kinh nghiệm và bài học gần đây trong khi chính thức xác định hai
Máy ảo trong K, cụ thể là:

- [KEVM](https://github.com/kframework/evm-semantics "EVM Semantics, Github"), our semantics of the [Ethereum Virtual Machine](https://github.com/ethereum/yellowpaper "Ethereum Virtual Machine Yellow Paper") (EVM); and

- [KEVM] (https://github.com/kframework/evm-semantics "EVM Semantics, GitHub"), ngữ nghĩa của chúng tôi về [máy ảo Ethereum] (https://github.com
Máy vàng giấy ") (EVM);
và

- KLLVM, our semantics of [LLVM](http://llvm.org/ "llvm.org"); the latest version of the LLVM semantics will be made public when complete and published, but an earlier version [is available](https://github.com/kframework/llvm-semantics "LLVM Semantics").

- kllvm, ngữ nghĩa của chúng tôi về [llvm] (http://llvm.org/ "llvm.org");
Phiên bản mới nhất của ngữ nghĩa LLVM sẽ được công khai khi hoàn thành và xuất bản, nhưng phiên bản trước [có sẵn] (https://github.com/kframework/llvm-semantics "LLVM Semantics").

Unlike the EVM, which is a stack-based machine, IELE is a register-based machine, like LLVM. It has an unbounded number of registers and also supports unbounded integers. To get a feel for how IELE programs look like, here are two of them (these have not been verified yet and may change):

Không giống như EVM, là một máy dựa trên ngăn xếp, IELE là một máy dựa trên đăng ký, như LLVM.
Nó có một số lượng thanh ghi không giới hạn và cũng hỗ trợ các số nguyên không giới hạn.
Để cảm nhận về các chương trình IELE trông như thế nào, đây là hai trong số chúng (chúng chưa được xác minh và có thể thay đổi):

- [erc20.iele](https://github.com/runtimeverification/iele-semantics/blob/master/iele-examples/erc20.iele "IELE Examples, erc20") - a IELE implementation of an ERC20 token

- [ERC20.IELE] (https://github.com/runtimeverification/iele-semantics/blob/master/iele-examples/erc20.iele "IELE

- [forwardingWallet.iele](https://github.com/runtimeverification/iele-semantics/blob/master/iele-examples/forwardingWallet.iele "forwardingwallet.iele, Github") - a wallet implementation that creates and calls into another contract

- [ForwardingWallet.iele] (https://github.com/runtimeverification/iele-semantics/blob/master/iele-examples/forwardingwallet.iele "
hợp đồng

## **Design Rationale**

## ** Thiết kế lý do **

Here are the forces that drove the design of IELE:

Dưới đây là các lực lượng đã thúc đẩy thiết kế của IELE:

1. To serve as a uniform, lower-level platform for translating and executing smart contracts from higher-level languages. The contracts can interact with each other by means of an ABI (Application Binary Interface). The ABI is a core element of IELE, and not just a convention on top of it. The unbounded integers and unbounded number of registers should make compilation from higher-level languages more straightforward and elegant and, looking at the success of LLVM, more efficient in the long term. Indeed, many of the LLVM optimizations are expected to carry over. For that reason, IELE followed the design choices and representation of LLVM as much as possible. The team also includes LLVM experts from the University of Illinois (where LLVM was created).

1. Để phục vụ như một nền tảng cấp thấp, thống nhất để dịch và thực hiện các hợp đồng thông minh từ các ngôn ngữ cấp cao hơn.
Các hợp đồng có thể tương tác với nhau bằng ABI (Giao diện nhị phân ứng dụng).
ABI là một yếu tố cốt lõi của IELE, và không chỉ là một quy ước trên đỉnh của nó.
Các số nguyên không giới hạn và số lượng thanh ghi không giới hạn sẽ làm cho việc biên dịch từ các ngôn ngữ cấp cao hơn đơn giản và thanh lịch hơn và, nhìn vào sự thành công của LLVM, hiệu quả hơn trong dài hạn.
Thật vậy, nhiều tối ưu hóa LLVM dự kiến sẽ thực hiện.
Vì lý do đó, IELE đã tuân theo các lựa chọn thiết kế và đại diện của LLVM càng nhiều càng tốt.
Nhóm nghiên cứu cũng bao gồm các chuyên gia LLVM từ Đại học Illinois (nơi LLVM được tạo ra).

1. To provide a uniform gas model, across all languages. The general design philosophy of gas calculation in IELE is "no limitations, but pay for what you consume". For example, the more registers a IELE program uses, the more gas it consumes. Or the larger the numbers computed at runtime, the more gas it consumes. The more memory it uses, in terms of both locations and size of data stored at locations, the more gas it consumes. And so on.

1. Để cung cấp một mô hình khí đồng đều, trên tất cả các ngôn ngữ.
Triết lý thiết kế chung về tính toán khí trong IELE là "không có giới hạn, nhưng trả tiền cho những gì bạn tiêu thụ".
Ví dụ, càng nhiều đăng ký chương trình IELE sử dụng, nó càng tiêu thụ nhiều khí.
Hoặc các số lớn hơn được tính toán trong thời gian chạy, nó càng tiêu thụ nhiều khí.
Càng sử dụng nhiều bộ nhớ, về cả hai vị trí và kích thước của dữ liệu được lưu trữ tại các vị trí, nó càng tiêu thụ nhiều khí.
Và như thế.

1. To make it easier to write secure smart contracts. This includes writing requirements specifications that smart contracts must obey as well as making it easier to develop automated techniques that mathematically verify / prove smart contracts correct with respect to such specifications. For example, pushing a possibly computed number on the stack and then jumping to it regarded as an address makes verification hard, and thus security weaker, with current smart contract paradigms. IELE has named labels, like LLVM, and jump statements can only jump to those labels. Also, it avoids the use of a bounded stack and not having to worry about stack or arithmetic overflow makes specification and verification of smart contracts significantly easier.

1. Để làm cho việc viết các hợp đồng thông minh an toàn dễ dàng hơn.
Điều này bao gồm các thông số kỹ thuật yêu cầu viết rằng các hợp đồng thông minh phải tuân theo cũng như giúp việc phát triển các kỹ thuật tự động dễ dàng hơn để xác minh / chứng minh các hợp đồng thông minh chính xác đối với các thông số kỹ thuật đó.
Ví dụ, đẩy một số có thể tính toán trên ngăn xếp và sau đó nhảy vào nó được coi là một địa chỉ làm cho xác minh khó khăn, và do đó bảo mật yếu hơn, với các mô hình hợp đồng thông minh hiện tại.
IELE đã đặt tên cho các nhãn, như LLVM và các câu lệnh Jump chỉ có thể nhảy vào các nhãn đó.
Ngoài ra, nó tránh được việc sử dụng một ngăn xếp bị ràng buộc và không phải lo lắng về Stack hoặc Overflow Alithmetic giúp đặc điểm kỹ thuật và xác minh các hợp đồng thông minh dễ dàng hơn đáng kể.

Like [KEVM](https://github.com/kframework/evm-semantics "EVM Semantics, Github"), the formal semantics of EVM that we previously defined, validated and evaluated using the [K framework](http://www.kframework.org/index.php/Main_Page "kframework.org"), the design of IELE was also done in a semantics-based style, using K. Together with a fast (LLVM-based) execution backend for K that is still under development, it is expected that the interpreter obtained automatically from the semantics of IELE will be sufficiently efficient to serve as a reference implementation of IELE.

Giống như [Kevm] (https://github.com/kframework/evm-semantics "EVM Semantics, GitHub"), ngữ nghĩa chính thức của EVM mà trước đây chúng tôi đã xác định, xác thực và đánh giá bằng [K Framework] (http: //
www.kframework.org/index.php/main_page "kframework.org"), thiết kế của IELE cũng được thực hiện theo phong cách dựa trên ngữ nghĩa, sử dụng K. cùng với phụ trợ thực thi nhanh (dựa trên LLVM) cho K đó là
Vẫn đang được phát triển, người ta hy vọng rằng thông dịch viên thu được tự động từ ngữ nghĩa của IELE sẽ đủ hiệu quả để phục vụ như một triển khai tham chiếu của IELE.

## **What's next?**

## **Cái gì tiếp theo?**

To achieve the full potential of IELE, we plan to next work on the following:

Để đạt được toàn bộ tiềm năng của IELE, chúng tôi dự định làm việc tiếp theo về những điều sau:

- Efficient backend for K. Then K semantics, including IELE, can be executed at acceptable performance. As discussed in our KEVM paper, the current version of K can execute the EVM semantics at performance that stays within an order of magnitude from the performance of the [reference C++ implementation of the EVM](https://github.com/ethereum/cpp-ethereum/ "cpp-ethereum, Github"). We believe that we can improve the execution performance of K by one order of magnitude. If this is achieved, then there is no incentive to implement IELE in an ad-hoc way: the K executable semantics of IELE will also be its implementation, so it will be correct by construction and thus implementation defects of the VM itself cannot be exploited anymore. Also, IELE itself would be easier to maintain and future versions will be easier to deploy.

- Trợ lý hiệu quả cho K. Sau đó, K ngữ nghĩa, bao gồm IELE, có thể được thực hiện với hiệu suất chấp nhận được.
Như đã thảo luận trong bài báo KEVM của chúng tôi, phiên bản K hiện tại của K có thể thực hiện ngữ nghĩa EVM theo hiệu suất nằm trong một thứ tự cường độ so với hiệu suất của việc thực hiện [tham chiếu C ++ của EVM] (https://github.com/ethereum/
CPP-Ethereum/ "CPP-Ethereum, GitHub").
Chúng tôi tin rằng chúng tôi có thể cải thiện hiệu suất thực hiện của K theo một bậc độ lớn.
Nếu điều này đạt được, thì không có động cơ nào để thực hiện IELE theo cách đặc biệt: ngữ nghĩa thực thi K của IELE cũng sẽ là việc triển khai của nó
nữa không.
Ngoài ra, bản thân IELE sẽ dễ dàng hơn để duy trì và các phiên bản trong tương lai sẽ dễ dàng triển khai hơn.

- Compilers/Translators from [Solidity](https://solidity.readthedocs.io/en/develop/ "Solidity Documentation") and [Plutus](https://cardanodocs.com/technical/plutus/introduction/ "Plutus Introduction, cardanodocs.com") to IELE. Writing smart contracts directly in IELE is a bit more feasible than in the EVM, because IELE follows the LLVM IR which was designed to be human-readable, but the IELE code is still low-level and thus error-prone. To properly test IELE and gain confidence in its overall design and capabilities, we will implement a compiler/translator from [Solidity](https://solidity.readthedocs.io/en/develop/ "Solidity Documentation") to IELE, also in K. Since [Plutus](https://cardanodocs.com/technical/plutus/introduction/ "Plutus Introduction, cardanodocs.com") rises as a star among the functional programming languages for smart contracts and since we are defining a [formal semantics of Plutus](https://github.com/kframework/plutus-core-semantics "Plutus Core Semantics, Github") as well, a compiler from Plutus to IELE will be developed immediately after Solidity's.

- Trình biên dịch/dịch giả từ [Solidity] (https://solility.readthedocs.io/en/develop/ "Tài liệu Sollity") và [Plutus] (https://cardanodocs.com/technical/plutus/intrio , cardanodocs.com ") đến iele. Viết hợp đồng thông minh trực tiếp trong IELE khả thi hơn một chút so với EVM, bởi vì IELE theo LLVM IR được thiết kế để có thể đọc được của con người, nhưng mã IELE vẫn ở mức thấp và do đó dễ bị lỗi. Để kiểm tra đúng IELE và đạt được sự tin tưởng vào thiết kế và khả năng tổng thể của nó, chúng tôi sẽ triển khai trình biên dịch/dịch giả từ [Solidity] (https://solility.readthedocs.io/en/develop/ "Tài liệu Solidity") K. Kể từ [Plutus] (https://cardanodocs.com/technical/plutus/introduction/ "Giới thiệu Plutus, cardanodocs.com") Semantics of Plutus] (https://github.com/kframework/plutus-core-semantics "Sao tích Plutus Core, GitHub")

- Semantics-based compilation. In addition to improving K's performance, we plan to implement a tool that we call semantics-based compiler on top of K. See our previous [blog post](https://runtimeverification.com/blog/?p=459 "New Technologies for the Blockchain: IELE, runtimeverification.com") for details. The idea is to take a programming language semantics L and a program P in L, and generate (using symbolic execution heavily) a new language semantics L' which is a specialization of L for P. We expect at least one order of magnitude increase in performance. More importantly, this will give us a uniform mechanism to translate any programs in any programming languages that have a K semantics to IELE, thus making IELE and K into a universal platform for executing smart contracts in any language.

- Tổng hợp dựa trên ngữ nghĩa.
Ngoài việc cải thiện hiệu suất của K, chúng tôi có kế hoạch triển khai một công cụ mà chúng tôi gọi là trình biên dịch dựa trên ngữ nghĩa trên đầu của K. Xem [bài đăng trên blog] trước đây của chúng tôi (https://runtimeverification.com/blog/?p=459 "Công nghệ mới
Đối với blockchain: iele, runTimeverification.com ") để biết chi tiết.
Ý tưởng là lấy một ngữ nghĩa ngôn ngữ lập trình l và một chương trình p trong l, và tạo ra (sử dụng thực thi biểu tượng rất nhiều) một ngữ nghĩa ngôn ngữ mới l 'là một chuyên môn hóa L cho P. Chúng tôi mong đợi ít nhất một thứ tự tăng cường độ
màn biểu diễn.
Quan trọng hơn, điều này sẽ cung cấp cho chúng tôi một cơ chế thống nhất để dịch bất kỳ chương trình nào bằng bất kỳ ngôn ngữ lập trình nào có ngữ nghĩa K sang IELE, do đó biến IELE và K thành một nền tảng phổ quát để thực hiện các hợp đồng thông minh bằng bất kỳ ngôn ngữ nào.

- Deploy IELE on the Cardano blockchain.

- Triển khai IELE trên blockchain Cardano.

## **Technical Details and Download**

## ** Chi tiết kỹ thuật và tải xuống **

IELE is thoroughly commented and freely available under the UIUC license (as permissive as the MIT license) on Github:

IELE được bình luận kỹ lưỡng và có sẵn tự do theo giấy phép UIUC (được cho phép như giấy phép MIT) trên GitHub:

- [IELE repository on Github](https://github.com/runtimeverification/iele-semantics "IELE Semantics, Github")

-

In addition to the two IELE programs mentioned above, erc20.iele and forwardingWallet.iele showing that the IELE code is human readable, the following links into the github repo will give a good idea what IELE is and how it differs from EVM and LLVM:

Ngoài hai chương trình IELE được đề cập ở trên, ERC20.iele và ForwardingWallet.iele cho thấy mã IELE có thể đọc được con người, các liên kết sau vào repo GitHub sẽ cho ý tưởng tốt về IELE là gì và nó khác với EVM và LLVM như thế nào: LLVM:

- [iele-syntax.md](https://github.com/runtimeverification/iele-semantics/blob/master/iele-syntax.md "IELE Textual Syntax") - the complete formal syntax of the IELE language.

-[iele-syntax.md] (https://github.com/runtimeverification/iele-semantics/blob/master/iele-syntax.md "cú pháp văn bản iele")-Cú pháp chính thức hoàn chỉnh của ngôn ngữ IELE.

- [iele.md](https://github.com/runtimeverification/iele-semantics/blob/master/iele.md "IELE Execution") - the complete formal executable semantics of the IELE language

- [iele.md] (https://github.com/runtimeverification/iele-semantics/blob/master/iele.md "thực thi iele")

- [Design.md](https://github.com/runtimeverification/iele-semantics/blob/master/Design.md "IELE Design") - the design rationale of IELE, as well as detailed comparisons with LLVM and EVM

- [Design.md] (https://github.com/runtimeverification/iele-semantics/blob/master/design.md "thiết kế iele") - Cơ sở thiết kế của IELE, cũng như so sánh chi tiết với LLVM và EVM

- [iele-gas.md](https://github.com/runtimeverification/iele-semantics/blob/master/iele-gas.md "IELE Gas Calculation") - the current gas model of IELE (which is still to be tuned as we develop compilers to IELE)

-[iele-gas.md] (https://github.com/runtimeverification/iele-semantics/blob/master/iele-gas.md "Tính toán khí iele")-Mô hình khí hiện tại của IELE (vẫn còn
được điều chỉnh khi chúng tôi phát triển các trình biên dịch thành IELE)

## **Get involved**

## **Tham gia vào**

In the spirit of open source, community-driven development, we will be holding all IELE discussions on our channels

Theo tinh thần của nguồn mở, phát triển dựa trên cộng đồng, chúng tôi sẽ tổ chức tất cả các cuộc thảo luận IELE trên các kênh của chúng tôi

- [#IELE:matrix.org](https://riot.im/app/#/room/#IELE:matrix.org "IELE Riot") on [Riot](https://about.riot.im/ "riot.im")

-]
"Riot.im")

- [runtimeverification/iele-semantics](https://gitter.im/runtimeverification/iele-semantics "IELE Gitter") on [Gitter](https://gitter.im/ "Gitter")

-

We encourage any interested parties to engage us, ask questions, contribute code, or build experience with our tools. We are also always looking for contributors able to work on documentation, efficient install/quickstart process for new developers, and more examples and tests. We are hiring, and will be sure to keep an eye open for helpful contributors!

Chúng tôi khuyến khích bất kỳ bên quan tâm nào thu hút chúng tôi, đặt câu hỏi, đóng góp mã hoặc xây dựng kinh nghiệm với các công cụ của chúng tôi.
Chúng tôi cũng luôn tìm kiếm những người đóng góp có thể làm việc trên tài liệu, quá trình cài đặt/nhanh hiệu quả cho các nhà phát triển mới, và nhiều ví dụ và thử nghiệm hơn.
Chúng tôi đang tuyển dụng, và chắc chắn sẽ để mắt đến những người đóng góp hữu ích!

We will also be posting updates on our brand new Twitter page [@rv_inc](https://twitter.com/rv_inc "Runtime Verification on Twitter"), which we hope any interested developers will follow and interact with.

Chúng tôi cũng sẽ đăng cập nhật trên trang Twitter hoàn toàn mới của chúng tôi [@RV_INC] (https://twitter.com/RV_INC "Xác minh thời gian chạy trên Twitter"), mà chúng tôi hy vọng bất kỳ nhà phát triển quan tâm nào cũng sẽ theo dõi và tương tác.

Let's build more secure smart contracts for everybody, together!

Hãy xây dựng các hợp đồng thông minh an toàn hơn cho mọi người, cùng nhau!

## **Acknowledgements**

## **Sự nhìn nhận**

We warmly thank [IOHK](https://iohk.io/ "iohk.io") for their generous funding support of both [IELE](https://github.com/runtimeverification/iele-semantics "IELE Semantics, Github") and [KEVM](https://github.com/kframework/evm-semantics "EVM Semantics, Github"). IELE, in particular, would have not been possible without IOHK's support, its continuous research meetings, and the stimulating technical discussions we had with their research team.

Chúng tôi nồng nhiệt cảm ơn [iohk] (https://iohk.io/ "iohk.io") vì sự hỗ trợ tài trợ hào phóng của họ cho cả hai [iele] (https://github.com
") và [kevm] (https://github.com/kframework/evm-semantics" EVM Semantics, GitHub ").
IELE, đặc biệt, sẽ không thể thực hiện được nếu không có sự hỗ trợ của IOHK, các cuộc họp nghiên cứu liên tục và các cuộc thảo luận kỹ thuật kích thích mà chúng tôi có với nhóm nghiên cứu của họ.

We also thank the K team who defined the [KEVM](https://github.com/kframework/evm-semantics "EVM Semantics, Github") semantics (see [technical report](https://www.ideals.illinois.edu/handle/2142/97207 "KEVM: A Complete Semantics of the Ethereum Virtual Machine"), too) and verified smart contracts for ERC20 compliance. Their effort and non-trivial proofs at the EVM level led to the quest for a new VM with better support for verification of smart contracts.

Chúng tôi cũng cảm ơn nhóm K, người đã xác định [KEVM] (https://github.com/kframework/evm-semantics "EVM Semantics, GitHub") ngữ nghĩa (xem [Báo cáo kỹ thuật] (https: //www.ideals.illinois
.edu/tay cầm/2142/97207 "KEVM: Một ngữ nghĩa hoàn chỉnh của máy ảo Ethereum"), cũng vậy) và đã xác minh các hợp đồng thông minh để tuân thủ ERC20.
Nỗ lực của họ và bằng chứng không tầm thường ở cấp EVM đã dẫn đến việc tìm kiếm một VM mới với sự hỗ trợ tốt hơn để xác minh các hợp đồng thông minh.

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.007.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com/resources.php)

[Mike Beeple](http://www.beeple-crap.com/resources.php)

[Mike Beeple] (http://www.beeple-crap.com/resource.php)

## **Attachments**

## ** tệp đính kèm **

![](img/2017-12-15-iele-a-new-virtual-machine-for-the-blockchain.004.png)[ IELE- A New Virtual Machine for the Blockchain - Input Output](https://ucarecdn.com/0dc38324-8874-47e4-9376-d03adaa32a42/-/inline/yes/ "IELE- A New Virtual Machine for the Blockchain - Input Output")

