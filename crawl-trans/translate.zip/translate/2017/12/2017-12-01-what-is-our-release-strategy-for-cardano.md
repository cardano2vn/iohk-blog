# What is our release strategy for Cardano?
### **A new development approach from IOHK engineers will bring benefits to users**
![](img/2017-12-01-what-is-our-release-strategy-for-cardano.002.png) 1 December 2017![](img/2017-12-01-what-is-our-release-strategy-for-cardano.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-12-01-what-is-our-release-strategy-for-cardano.003.png) 4 mins read

![](img/2017-12-01-what-is-our-release-strategy-for-cardano.004.png)[ What is our release strategy for Cardano - Input Output](https://ucarecdn.com/bfb745ae-c236-4721-8d72-a730e164ec32/-/inline/yes/ "What is our release strategy for Cardano - Input Output")

![Jeremy Wood](img/2017-12-01-what-is-our-release-strategy-for-cardano.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-12-01-what-is-our-release-strategy-for-cardano.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-12-01-what-is-our-release-strategy-for-cardano.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-12-01-what-is-our-release-strategy-for-cardano.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![What is our release strategy for Cardano?](img/2017-12-01-what-is-our-release-strategy-for-cardano.009.jpeg)

Since the release of mainnet, IOHK engineers have not only started work planning the new features of Shelley, the next big release, but have also been evolving the way they work. The biggest change is that the team developing Cardano will follow a new release cycle where updates are more regularly made to the live software. This is now possible because we have the foundation of Byron to build on. This approach will benefit the community because it means we can deliver features to users sooner, and also has other advantages, such as allowing us to design very detailed tests for the code. Considerable planning has been under way to help the team shift to this approach, and we are confident it will bring good results. This blog post explains what is happening behind the scenes. [Cardano](https://cardanohub.org "Cardano Hub") involves collaboration from several development teams working towards a common vision following the same [roadmap](https://cardanoroadmap.com/ "Cardano Roadmap"). The development teams collaborating on the project include Core SL (Settlement Layer), Networking, Cardano Blockchain Explorer, Wallet Backend, and [Daedalus](https://daedaluswallet.io/ "Daedalus Wallet"). Development follows the agile software development approach, which allows us to continuously inspect, adapt and improve the way we build and ship Cardano. Agile is an iterative approach where software is built incrementally from the start of the project, instead of delivering it all at once near the end, as we did with Byron, the launch of mainnet.

Kể từ khi phát hành chính, các kỹ sư IOHK không chỉ bắt đầu lên kế hoạch cho các tính năng mới của Shelley, bản phát hành lớn tiếp theo, mà còn phát triển cách chúng làm việc. Thay đổi lớn nhất là nhóm phát triển Cardano sẽ theo chu kỳ phát hành mới, nơi các bản cập nhật được thực hiện thường xuyên hơn cho phần mềm trực tiếp. Điều này bây giờ là có thể bởi vì chúng tôi có nền tảng của Byron để xây dựng. Cách tiếp cận này sẽ có lợi cho cộng đồng vì điều đó có nghĩa là chúng tôi có thể cung cấp các tính năng cho người dùng sớm hơn và cũng có những lợi thế khác, chẳng hạn như cho phép chúng tôi thiết kế các bài kiểm tra rất chi tiết cho mã. Lập kế hoạch đáng kể đã được tiến hành để giúp nhóm chuyển sang cách tiếp cận này và chúng tôi tự tin rằng nó sẽ mang lại kết quả tốt. Bài đăng trên blog này giải thích những gì đang xảy ra đằng sau hậu trường. . Các nhóm phát triển hợp tác trong dự án bao gồm Core SL (Lớp giải quyết), Mạng, Cardano Blockchain Explorer, Wallet phụ trợ và [Daedalus] (https://daedaluswallet.io/ "ví Daedalus"). Phát triển theo phương pháp phát triển phần mềm Agile, cho phép chúng tôi liên tục kiểm tra, thích nghi và cải thiện cách chúng tôi xây dựng và vận chuyển Cardano. Agile là một cách tiếp cận lặp đi lặp lại, nơi phần mềm được xây dựng tăng dần từ khi bắt đầu dự án, thay vì cung cấp tất cả cùng một lúc gần cuối, như chúng tôi đã làm với Byron, sự ra mắt của Mainnet.

The development teams working on Shelley now follow synchronized two-week sprints, which are a set period of time during which specific work has to be completed and made ready for review. There are daily meetings to coordinate the teams and resolve any issues. The product backlog â€“ where the prioritized list of features are stored and is essentially all the work that needs to go into developing Cardano â€“ is being managed in an issue tracker tool. Individual teams have their own sprints that take their work from this shared product backlog.

Các nhóm phát triển làm việc trên Shelley hiện theo các lần chạy nước rút hai tuần được đồng bộ hóa, đây là một khoảng thời gian được thiết lập trong đó công việc cụ thể phải được hoàn thành và sẵn sàng để xem xét.
Có các cuộc họp hàng ngày để phối hợp các đội và giải quyết mọi vấn đề.
Backlog sản phẩm - trong đó danh sách các tính năng được ưu tiên được lưu trữ và về cơ bản là tất cả các công việc cần phát triển Cardano - đang được quản lý trong một công cụ theo dõi vấn đề.
Các nhóm cá nhân có những lần chạy nước rút của riêng họ lấy công việc của họ từ tồn đọng sản phẩm được chia sẻ này.

After a two-week sprint, we will deliver a testnet release. After a number of testnet releases there will be a mainnet release based on feedback from the community and internal quality assurance testing.

Sau khi chạy nước rút hai tuần, chúng tôi sẽ phát hành TestNet.
Sau một số bản phát hành TestNet, sẽ có bản phát hành chính dựa trên phản hồi từ cộng đồng và thử nghiệm đảm bảo chất lượng nội bộ.

Our goal is to reduce the time between mainnet deployments. To release early and often, weâ€™re adopting time-based releases as opposed to feature-based releases. Time-based release strategies are used in many commercial and open source projects, for example, [Linux](https://en.wikipedia.org/wiki/Linux "Linux, Wikipedia"). Moving to time-based releases means no more waiting for features to be ready; instead we merge only the features that are ready at the time of the release. This doesnâ€™t include patches, which are updates to improve the software or fix bugs, which will continue to be released when they are ready.

Mục tiêu của chúng tôi là giảm thời gian giữa các triển khai chính.
Để phát hành sớm và thường xuyên, chúng tôi áp dụng các bản phát hành dựa trên thời gian trái ngược với các bản phát hành dựa trên tính năng.
Các chiến lược phát hành dựa trên thời gian được sử dụng trong nhiều dự án thương mại và nguồn mở, ví dụ, [Linux] (https://en.wikipedia.org/wiki/linux "Linux, Wikipedia").
Chuyển sang các bản phát hành dựa trên thời gian có nghĩa là không còn chờ đợi các tính năng nào sẵn sàng;
Thay vào đó, chúng tôi chỉ hợp nhất các tính năng đã sẵn sàng tại thời điểm phát hành.
Điều này không bao gồm các bản vá, là các bản cập nhật để cải thiện phần mềm hoặc sửa lỗi, sẽ tiếp tục được phát hành khi chúng đã sẵn sàng.

One of the problems with the "big bang" release approach we followed for Byron is that it creates a bottleneck due to problems coordinating all the features slated for release at the same time. Decoupling features from releases, where possible, means that in future we will not have to delay a release because we are waiting for one feature to be ready. It also means that we can focus on getting smaller features out of the door and into the hands of our community quicker. The shorter feedback loops allow us to gather valuable feedback from the community on the direction that we are taking Cardano. It allows users, contributors and stakeholders to prepare and plan around a predictable timeframe.

Một trong những vấn đề với phương pháp phát hành "Big Bang" mà chúng tôi đã làm theo Byron là nó tạo ra một nút cổ chai do các vấn đề phối hợp tất cả các tính năng dự kiến phát hành cùng một lúc.
Decoupling các tính năng từ các bản phát hành, nếu có thể, có nghĩa là trong tương lai chúng ta sẽ không phải trì hoãn việc phát hành vì chúng ta đang chờ một tính năng đã sẵn sàng.
Điều đó cũng có nghĩa là chúng ta có thể tập trung vào việc đưa các tính năng nhỏ hơn ra khỏi cửa và vào tay cộng đồng của chúng ta nhanh hơn.
Các vòng phản hồi ngắn hơn cho phép chúng tôi thu thập phản hồi có giá trị từ cộng đồng về hướng mà chúng tôi đang thực hiện Cardano.
Nó cho phép người dùng, người đóng góp và các bên liên quan chuẩn bị và lên kế hoạch xung quanh khung thời gian có thể dự đoán được.

![Release Strategy Diagram](img/2017-12-01-what-is-our-release-strategy-for-cardano.010.png)

However, scaling this agile approach across several teams working on the same product brings merging and integration challenges. We are using a well known, successful git branching model called [git-flow](http://nvie.com/posts/a-successful-git-branching-model/ "A Successful Git Branching Model, nvie.com") to help manage this.

Tuy nhiên, việc mở rộng cách tiếp cận nhanh nhẹn này trên một số nhóm làm việc trên cùng một sản phẩm mang đến những thách thức hợp nhất và tích hợp.
Chúng tôi đang sử dụng một mô hình phân nhánh Git nổi tiếng, thành công được gọi là [GIT-flow] (http://nvie.com/posts/a-successful-granching-model/ "Một mô hình phân nhánh Git thành công, NVIE.com")
để giúp quản lý điều này.

Once a development sprint is finished, our DevOps (development and operations) team branches off the code from the develop branch into the release branch. Changes are deployed to internal staging and once testing approves the changes, they are redeployed to the testnet. Once we decide to release mainnet, the release branch is merged to the master branch and tagged. The master branch is therefore always in stable state as the mainnet. Weâ€™re working to align our processes to enable moving towards more frequent, scheduled releases. Once a suitable release schedule is decided it will be shared with the community. The process described here is not an end state. We strive to continuously improve, so updates to our release process can be expected as we fine tune our software development processes.

Khi một cuộc chạy nước rút phát triển kết thúc, các nhóm DevOps (phát triển và hoạt động) của chúng tôi, các chi nhánh ra khỏi mã từ nhánh phát triển vào nhánh phát hành.
Các thay đổi được triển khai để dàn dựng nội bộ và sau khi thử nghiệm phê duyệt các thay đổi, chúng được triển khai lại cho TestNet.
Khi chúng tôi quyết định phát hành chính, nhánh phát hành được hợp nhất với nhánh chính và được gắn thẻ.
Do đó, nhánh chính luôn ở trạng thái ổn định như chính.
Chúng tôi đang làm việc để sắp xếp các quy trình của mình để cho phép di chuyển theo hướng các bản phát hành thường xuyên hơn, theo lịch trình.
Khi một lịch trình phát hành phù hợp được quyết định, nó sẽ được chia sẻ với cộng đồng.
Quá trình được mô tả ở đây không phải là một trạng thái kết thúc.
Chúng tôi cố gắng liên tục cải thiện, vì vậy các bản cập nhật cho quá trình phát hành của chúng tôi có thể được dự kiến khi chúng tôi tinh chỉnh các quy trình phát triển phần mềm của chúng tôi.

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2017-12-01-what-is-our-release-strategy-for-cardano.011.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com/resources.php)

[Mike Beeple](http://www.beeple-crap.com/resources.php)

[Mike Beeple] (http://www.beeple-crap.com/resource.php)

## **Attachments**

## ** tệp đính kèm **

![](img/2017-12-01-what-is-our-release-strategy-for-cardano.004.png)[ What is our release strategy for Cardano - Input Output](https://ucarecdn.com/bfb745ae-c236-4721-8d72-a730e164ec32/-/inline/yes/ "What is our release strategy for Cardano - Input Output")

