# A Crypto on the Edge of Forever
![](img/2017-12-28-a-crypto-on-the-edge-of-forever.002.png) 28 December 2017![](img/2017-12-28-a-crypto-on-the-edge-of-forever.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2017-12-28-a-crypto-on-the-edge-of-forever.003.png) 7 mins read

![](img/2017-12-28-a-crypto-on-the-edge-of-forever.004.png)[ A Crypto on the Edge of Forever - Input Output](https://ucarecdn.com/3bd7ce91-891e-40b0-89f7-d0ab97619233/-/inline/yes/ "A Crypto on the Edge of Forever - Input Output")

![Charles Hoskinson](img/2017-12-28-a-crypto-on-the-edge-of-forever.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2017-12-28-a-crypto-on-the-edge-of-forever.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2017-12-28-a-crypto-on-the-edge-of-forever.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2017-12-28-a-crypto-on-the-edge-of-forever.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![A Crypto on the Edge of Forever](img/2017-12-28-a-crypto-on-the-edge-of-forever.009.png)

Now that the dust has settled after travelling to more than 20 countries, dozens of conferences, major events and community meet and greets this year, Iâ€™ve finally had the time to reflect on the progress of the Cardano project as well as some of the lessons Iâ€™ve learned. Itâ€™s honestly been the most challenging year of my life, filled with drama, stress, death and some unbelievably cruel people. Itâ€™s also been one of the most rewarding and joyful years, having had the chance to meet thousands of passionate and kind fans, technologists and scientists â€“ I can see the inspiration that Charles Dickens had when he said it was the best of times and the worst of times. The reality is that the internet and in particular the cryptocurrency space can be a really toxic place if you allow it to get to you. There were times after reading some blog post or comment on Reddit that I seriously questioned if this effort was worth it. I can understand why Mike Hearn left Bitcoin. 

Bây giờ bụi đã lắng sau khi đi đến hơn 20 quốc gia, hàng chục hội nghị, sự kiện lớn và gặp gỡ cộng đồng trong năm nay, cuối cùng tôi đã có thời gian để suy ngẫm về tiến trình của dự án Cardano cũng như một số Những bài học tôi đã học được. Thành thật mà nói, đó là năm thử thách nhất trong cuộc đời tôi, chứa đầy kịch tính, căng thẳng, cái chết và một số người độc ác không thể tin được. Cũng là một trong những năm tháng bổ ích và vui vẻ nhất, đã có cơ hội gặp gỡ hàng ngàn người hâm mộ, công nghệ và nhà khoa học đam mê và tốt bụng - Tôi có thể thấy cảm hứng mà Charles Dickens có khi nói đó là điều tốt nhất của thời gian và những thời điểm tồi tệ nhất. Thực tế là Internet và đặc biệt là không gian tiền điện tử có thể là một nơi thực sự độc hại nếu bạn cho phép nó đến với bạn. Có những lúc sau khi đọc một số bài đăng trên blog hoặc nhận xét về Reddit rằng tôi nghiêm túc đặt câu hỏi liệu nỗ lực này có xứng đáng không. Tôi có thể hiểu tại sao Mike Hearn rời Bitcoin.

But Iâ€™ve never been here for the short term, itâ€™s always been the dream of finding a way to get financial services to the three billion people who donâ€™t have them using technology that was only a dream a generation ago. And I think we are making great progress there. 

Nhưng tôi chưa bao giờ ở đây trong thời gian ngắn, luôn luôn là giấc mơ tìm cách có được các dịch vụ tài chính cho ba tỷ người không có họ sử dụng công nghệ chỉ là một thế hệ mơ ước một thế hệ
trước kia.
Và tôi nghĩ rằng chúng tôi đang đạt được tiến bộ lớn ở đó.

In January of 2017, Cardano was still mostly in a very early alpha stage. We had tremendous engineering difficulty getting Haskell, our DevOps and the new protocols such as Ouroboros and Scrape to play nicely together. Rather it was a constant learning curve of how to tame the three headed dragon of research, decentralized teams and exotic programming languages while managing the expectations of a huge community. 

Vào tháng 1 năm 2017, Cardano vẫn chủ yếu ở giai đoạn Alpha rất sớm.
Chúng tôi đã gặp khó khăn về kỹ thuật rất lớn khi nhận Haskell, DevOps của chúng tôi và các giao thức mới như Ouroboros và Scrape để chơi độc đáo với nhau.
Thay vào đó, đó là một đường cong học tập liên tục về cách chế ngự ba con rồng nghiên cứu, các nhóm phi tập trung và ngôn ngữ lập trình kỳ lạ trong khi quản lý kỳ vọng của một cộng đồng lớn.

As an aside, Cardano has one of the fastest growing and most intelligent fanbases. We actively invited people who care about formal methods, peer review and functional programming to come and see what we are working on. These people arenâ€™t swayed by jargon or flashy marketing. They were born with bullshit detectors in their cribs.

Bên cạnh, Cardano có một trong những người hâm mộ phát triển nhanh nhất và thông minh nhất.
Chúng tôi chủ động mời những người quan tâm đến các phương pháp chính thức, đánh giá ngang hàng và lập trình chức năng đến và xem những gì chúng tôi đang làm việc.
Những người này bị ảnh hưởng bởi các biệt ngữ hoặc tiếp thị hào nhoáng.
Họ được sinh ra với các máy dò nhảm nhí trong cũi của họ.

Iâ€™ve gained significant strength and a much needed boost in morale from interacting with our community. For example, one member asked about how we were verifying the proofs in the Ouroboros paper and I posted a link to Kawinâ€™s [Isabelle repo](https://bitbucket.org/wkawin/ouroboros "Ouroboros, bitbucket.org"). Most would simply say â€˜thatâ€™s niceâ€™ and move on. This member took the time to read the code and mentioned we had a long way to go with specific examples. 

Tôi đã có được sức mạnh đáng kể và sự thúc đẩy rất cần thiết trong tinh thần từ việc tương tác với cộng đồng của chúng tôi.
Ví dụ, một thành viên đã hỏi về cách chúng tôi xác minh các bằng chứng trong bài báo Ouroboros và tôi đã đăng một liên kết đến Kawinâ € [Isabelle Repo] (https://bitbucket.org/wkawin/ouroboros "OuroBoros, bitbucket.org"
).
Hầu hết chỉ đơn giản là nói "Điều đó thật tuyệt vời và tiếp tục.
Thành viên này đã dành thời gian để đọc mã và đề cập đến việc chúng tôi đã có một chặng đường dài để đi với các ví dụ cụ thể.

For most people, [Isabelle](https://en.wikipedia.org/wiki/Isabelle_proof_assistant "Isabelle, Proof Assistant, Wikipedia") is a name followed by a lake in Minnesota. For our community, some can actually read the code and comment on it. Thatâ€™s a rare gift and itâ€™s the privilege of a lifetime to be in this kind of environment (we ended up hiring the person who commented on the code).

Đối với hầu hết mọi người, [Isabelle] (https://en.wikipedia.org/wiki/isabelle_proof_assistant "Isabelle, Trợ lý bằng chứng, Wikipedia") là một cái tên theo sau một hồ nước ở Minnesota.
Đối với cộng đồng của chúng tôi, một số thực sự có thể đọc mã và nhận xét về nó.
Đó là một món quà hiếm hoi và đó là đặc quyền của cả đời để ở trong môi trường này (cuối cùng chúng tôi đã thuê người nhận xét về mã).

Moving through the months, Cardano moved from the lab to a series of testnets to eventually being released in September. Dealing with these transitions gave us a newfound appreciation for just how many different computer and network configurations exist. I can almost feel a Windows force ghost whispering â€œI told you soâ€ in a smug voice. 

Chuyển qua các tháng, Cardano chuyển từ phòng thí nghiệm sang một loạt các thử nghiệm để cuối cùng được phát hành vào tháng Chín.
Đối phó với các chuyển đổi này đã cho chúng tôi một sự đánh giá cao mới về việc có bao nhiêu cấu hình máy tính và mạng khác nhau tồn tại.
Tôi gần như có thể cảm thấy một Windows Force Ghost thì thầm - Tôi đã nói với bạn một giọng nói tự mãn.

We designed Byron (the September release of Cardano) to be the minimum viable product necessary to test the concepts Cardano is built upon. We wanted to run Ouroboros in a production setting to see epochs function properly. We wanted extensive logging of both the edge nodes and relays to see how our network is being used. We wanted to have third parties play with our APIs and tell us where we screwed up (boy did they ever!). We wanted to test the update system a few times. 

Chúng tôi đã thiết kế Byron (bản phát hành Cardano tháng 9) để trở thành sản phẩm khả thi tối thiểu cần thiết để kiểm tra các khái niệm Cardano được xây dựng.
Chúng tôi muốn chạy Ouroboros trong một cài đặt sản xuất để thấy Epochs hoạt động đúng.
Chúng tôi muốn ghi nhật ký rộng rãi của cả hai nút cạnh và rơle để xem mạng của chúng tôi đang được sử dụng như thế nào.
Chúng tôi muốn có các bên thứ ba chơi với API của chúng tôi và cho chúng tôi biết nơi chúng tôi đã làm hỏng việc (cậu bé đã làm họ!).
Chúng tôi muốn kiểm tra hệ thống cập nhật một vài lần.

Overall, the experiment has been a tremendous success. There are several thousand edge nodes concurrently connected to the network. There are several exchanges and other third parties using our software in the harshest possible way. There is a wealth of data flowing in that is giving us a much better sense of what we need to do to make Cardano better. 

Nhìn chung, thí nghiệm đã thành công to lớn.
Có vài nghìn nút cạnh được kết nối đồng thời với mạng.
Có một số trao đổi và các bên thứ ba khác sử dụng phần mềm của chúng tôi theo cách khắc nghiệt nhất có thể.
Có rất nhiều dữ liệu chảy trong đó là cho chúng ta cảm giác tốt hơn nhiều về những gì chúng ta cần làm để làm cho Cardano tốt hơn.

Since launch, weâ€™ve already pushed three updates to the network without incident. Weâ€™ve started a very rapid redesign of our middleware and its associated APIs to make it easier for third parties to integrate. Weâ€™ve started a series of systematic improvements to our network stack that will be finished with the Shelley release that should dramatically improve things. 

Kể từ khi ra mắt, chúng tôi đã đẩy ba bản cập nhật vào mạng mà không gặp sự cố.
Chúng tôi đã bắt đầu một thiết kế lại rất nhanh về phần mềm trung gian của chúng tôi và các API liên quan của nó để giúp các bên thứ ba dễ dàng tích hợp hơn.
Chúng tôi đã bắt đầu một loạt các cải tiến có hệ thống cho ngăn xếp mạng của chúng tôi sẽ được hoàn thành với bản phát hành Shelley sẽ cải thiện đáng kể mọi thứ.

However, what excites me most about 2018 is that Cardano is starting to open up to the world. Delegation and staking will be rolled out all throughout Q1 and Q2 in coordination with the community. Soon weâ€™ll have a testnet running [IELE](https://github.com/runtimeverification/iele-semantics "IELE Semantics, Github") allowing developers to play around with our smart contract model for the first time. And weâ€™ll be deploying our first verified protocol with [Praos](https://github.com/input-output-hk/ouroboros-spec "Ouroboros Spec, Github") thereby engaging the formal methods community.

Tuy nhiên, điều khiến tôi phấn khích nhất về năm 2018 là Cardano đang bắt đầu mở ra thế giới.
Phái đoàn và cổ phần sẽ được triển khai trong suốt Q1 và Q2 phối hợp với cộng đồng.
Chẳng mấy chốc, chúng tôi sẽ có một TestNet chạy [IELE] (https://github.com/runtimeverification/iele-semantics "IELE Semantics, GitHub") cho phép các nhà phát triển chơi với mô hình hợp đồng thông minh của chúng tôi lần đầu tiên.
Và chúng tôi sẽ triển khai giao thức được xác minh đầu tiên của chúng tôi với [PRAOS] (https://github.com/input-output

Constantly living in the moment, one tends to eschew Cardanoâ€™s vast scope in exchange for the problem of the week. But looking at our [ever growing Cardano whiteboard series](https://www.youtube.com/playlist?list=PLnPTB0CuBOBxDBrD4-ZflYF6y3L3jMUOs "Cardano Whiteboard Videos, YouTube") demonstrates how many brilliant people wake up every morning thinking about how to solve the problems of scalability, interoperability and sustainability. These arenâ€™t just hypothetical lectures. They are backed by papers, funding and developers working full time.

Liên tục sống trong khoảnh khắc, người ta có xu hướng tránh phạm vi rộng lớn của Cardano để đổi lấy vấn đề trong tuần.
Nhưng nhìn vào loạt [sê-ri bảng trắng Cardano đang phát triển của chúng tôi] (https://www.youtube.com/playlist?list=PlNPTB0CubObObxDBRD4-zflyf6y3l3jmuos "
Giải quyết các vấn đề về khả năng mở rộng, khả năng tương tác và tính bền vững.
Những bài giảng giả thuyết này chỉ là những bài giảng giả thuyết.
Họ được hỗ trợ bởi các bài báo, tài trợ và các nhà phát triển làm việc toàn thời gian.

Then there are the new things. The work by [Professor Rosu](http://fsl.cs.illinois.edu/index.php/Grigore_Rosu "Professor Rosu, Formal Systems Laboratory") and Runtime Verification on K and semantics based compilation isnâ€™t just really smart competitive differentiation, itâ€™s literally moving the chains of the entire field of programming language theory. The Cardano project is creating a financial incentive to have correct by construction infrastructure from virtual machines to compilers. Our success means you donâ€™t have to handwrite this code ever again â€“ not just in a cryptocurrency context but in a general context. 

Sau đó, có những điều mới.
Công việc của [Giáo sư Rosu] (http://fsl.cs.illinois.edu/index.php/grigore_rosu "
Sự khác biệt cạnh tranh, nó thực sự di chuyển các chuỗi của toàn bộ lĩnh vực lý thuyết ngôn ngữ lập trình.
Dự án Cardano đang tạo ra một động lực tài chính để có chính xác bởi cơ sở hạ tầng xây dựng từ máy ảo đến các trình biên dịch.
Thành công của chúng tôi có nghĩa là bạn không phải viết mã này một lần nữa - không chỉ trong bối cảnh tiền điện tử mà trong một bối cảnh chung.

Our research efforts at Tokyo Tech under Professors Mario Larangeira and Bernardo David with multiparty computation is rapidly bringing these protocols into practical use. [Kaleidoscope](https://www.youtube.com/watch?v=VCz359FG8kM&t=2s "Cardano whiteboard; Kaleidoscope with Bernardo David, YouTube") and Royale are case studies on how to achieve everything that Ethereum does off chain, in a low latency setting, privately and at a scale of millions of concurrent users each in their own domain. Further abstractions will push this work into more useful domains like decentralized exchange. And eventually DApp developers will be able to integrate these protocols into their code via libraries.

Những nỗ lực nghiên cứu của chúng tôi tại Tokyo Tech dưới thời giáo sư Mario Larangeira và Bernardo David với tính toán nhiều bên đang nhanh chóng đưa các giao thức này vào sử dụng thực tế.
.
Một cài đặt độ trễ thấp, riêng tư và ở quy mô hàng triệu người dùng đồng thời trong phạm vi riêng của họ.
Tóm tắt hơn nữa sẽ đẩy công việc này vào các lĩnh vực hữu ích hơn như trao đổi phi tập trung.
Và cuối cùng các nhà phát triển DAPP sẽ có thể tích hợp các giao thức này vào mã của họ thông qua các thư viện.

[Professor Bingsheng Zhang](http://www.lancaster.ac.uk/staff/zhangb2/ "Bingsheng Zhang, Lancaster University")â€™s research on [treasuries and voting](https://www.youtube.com/watch?v=Hyh3h_yX-S0 "Cardano whiteboard; Treasuries with Bingsheng Zhang, YouTube") is groundbreaking. It gives our project the ability to open a discussion about how changes to cryptocurrencies should be proposed, debated, approved and funded. Whatâ€™s most special here is the interdisciplinary nature of the effort that can draw from political science, game theory, sociology, open source software governance and computer science. There is something for everybody. Â Â Â 

[Giáo sư Bingsheng Zhang] (http:
com/watch? V = hyh3h_yx-s0 "Bảng trắng Cardano; Kho bạc với Bingsheng Zhang, YouTube") là đột phá.
Nó cung cấp cho dự án của chúng tôi khả năng mở một cuộc thảo luận về cách các thay đổi đối với tiền điện tử nên được đề xuất, tranh luận, phê duyệt và tài trợ.
Điều đặc biệt nhất ở đây là bản chất liên ngành của nỗ lực có thể rút ra từ khoa học chính trị, lý thuyết trò chơi, xã hội học, quản trị phần mềm nguồn mở và khoa học máy tính.
Có một cái gì đó cho tất cả mọi người.
Â Â Â

Moving into 2018, we are going to open this discussion up by both engaging the community directly and by holding a conference in Switzerland. More details will be published later, but the basic idea is that this area isnâ€™t a Cardano problem. Itâ€™s a cryptocurrency problem. And there are many great projects from Dash to Pivx who are trying to solve it in a novel way. We ought to talk to each other.

Chuyển sang năm 2018, chúng tôi sẽ mở cuộc thảo luận này bằng cách cả hai tham gia trực tiếp cộng đồng và tổ chức một hội nghị ở Thụy Sĩ.
Thêm chi tiết sẽ được công bố sau, nhưng ý tưởng cơ bản là khu vực này không phải là vấn đề Cardano.
Đó là một vấn đề tiền điện tử.
Và có nhiều dự án tuyệt vời từ Dash đến PIVX, những người đang cố gắng giải quyết nó theo một cách mới lạ.
Chúng tôi nên nói chuyện với nhau.

I could continue to enumerate our research efforts (thereâ€™s a lot more to write), but I think the point has been made. Cardano isnâ€™t a cryptocurrency as much as it is a movement of minds who are frustrated with the way technology works in practice. 

Tôi có thể tiếp tục liệt kê các nỗ lực nghiên cứu của chúng tôi (có rất nhiều thứ để viết), nhưng tôi nghĩ rằng vấn đề đã được đưa ra.
Cardano không phải là một loại tiền điện tử nhiều như nó là một phong trào của những người thất vọng với cách thức hoạt động của công nghệ trong thực tế.

The functional programming community has for decades had great solutions to many of the problems plaguing modern developers, but they have been historically ignored. Our RINA guys, if given a chance, could build a much better and more fair internet. Layering protocol development with formal methods extracts a much cleaner and more meaningful design process where ambiguity and hand waving is slain.

Cộng đồng lập trình chức năng trong nhiều thập kỷ đã có những giải pháp tuyệt vời cho nhiều vấn đề gây khó chịu cho các nhà phát triển hiện đại, nhưng họ đã bị bỏ qua trong lịch sử.
Những người Rina của chúng tôi, nếu có cơ hội, có thể xây dựng một Internet tốt hơn và công bằng hơn nhiều.
Phát triển giao thức layering với các phương pháp chính thức chiết xuất một quá trình thiết kế sạch hơn và có ý nghĩa hơn trong đó sự mơ hồ và vẫy tay bị giết.

What Cardano has given us is a chance to answer if only the world worked this way with why not? We have the freedom to dream again and the freedom to try new things without asking permission. I even have a chance to work with my heroes like Phil Wadler. 2018 is going to be one hell of a year. 

Những gì Cardano đã cho chúng ta là cơ hội để trả lời nếu chỉ có thế giới làm việc theo cách này với lý do tại sao không?
Chúng ta có quyền tự do mơ ước một lần nữa và tự do thử những điều mới mà không cần xin phép.
Tôi thậm chí có cơ hội làm việc với các anh hùng của mình như Phil Wadler.
Năm 2018 sẽ là một địa ngục của một năm.

Thanks for reading.

Cảm ơn vì đã đọc.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-12-28-a-crypto-on-the-edge-of-forever.004.png)[ A Crypto on the Edge of Forever - Input Output](https://ucarecdn.com/3bd7ce91-891e-40b0-89f7-d0ab97619233/-/inline/yes/ "A Crypto on the Edge of Forever - Input Output")

