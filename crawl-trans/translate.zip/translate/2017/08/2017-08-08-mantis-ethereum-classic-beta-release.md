# Mantis – Ethereum Classic Beta Release
### **A command line interface client for the ETC community**
![](img/2017-08-08-mantis-ethereum-classic-beta-release.002.png) 8 August 2017![](img/2017-08-08-mantis-ethereum-classic-beta-release.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-08-08-mantis-ethereum-classic-beta-release.003.png) 4 mins read

![](img/2017-08-08-mantis-ethereum-classic-beta-release.004.png)[ Mantis – Ethereum Classic Beta Release - Input Output](https://ucarecdn.com/177749ef-1a6e-412a-868a-0037c4ff3a30/-/inline/yes/ "Mantis – Ethereum Classic Beta Release - Input Output")

![Jeremy Wood](img/2017-08-08-mantis-ethereum-classic-beta-release.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-08-08-mantis-ethereum-classic-beta-release.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-08-08-mantis-ethereum-classic-beta-release.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-08-08-mantis-ethereum-classic-beta-release.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![Mantis – Ethereum Classic Beta Release](img/2017-08-08-mantis-ethereum-classic-beta-release.009.jpeg)

We are excited to announce that there is now an Ethereum (ETH) client built specifically for the Ethereum Classic (ETC) community. The [release of this beta client](https://github.com/input-output-hk/etc-client/releases "Mantis, Ethereum Classic client, GitHub"), Mantis, will take place today and is the culmination of seven months of work by the Grothendieck Team, the IOHK developers dedicated to Ethereum Classic. There are three reasons for the client. First, IOHK wants to demonstrate that it has the technical competency and culture to be a leader for the development of ETC. Second, IOHK wants to dispel the myth that ETC is a “copy and paste” coin that uses other people's code, and show that it is an independent and viable alternative to Ethereum. Third, the client is built in Scala, which is a functional programming language that offers security guarantees that other languages do not.

Chúng tôi rất vui mừng thông báo rằng hiện tại có một ứng dụng khách Ethereum (ETH) được xây dựng dành riêng cho cộng đồng Ethereum Classic (v.v.).
[Phát hành máy khách beta này] (https://github.com/input-output
Bảy tháng làm việc của nhóm Grothendieck, các nhà phát triển IOHK dành riêng cho Ethereum Classic.
Có ba lý do cho khách hàng.
Đầu tiên, IOHK muốn chứng minh rằng nó có năng lực và văn hóa kỹ thuật để trở thành một nhà lãnh đạo cho sự phát triển của v.v ...
Thứ hai, IOHK muốn xua tan huyền thoại rằng ETC là một bản sao và dán đồng tiền sử dụng mã của người khác và cho thấy rằng đó là một sự thay thế độc lập và khả thi cho Ethereum.
Thứ ba, máy khách được xây dựng trong Scala, là ngôn ngữ lập trình chức năng cung cấp các đảm bảo bảo mật mà các ngôn ngữ khác không có.

This release is comprised of the four [functional milestones](tmp//en/blog/a-trip-to-malta-and-a-grothendieck-milestone/ "A trip to Malta and a Grothendieck milestone, IOHK") we have been working on since January.

Bản phát hành này bao gồm bốn [cột mốc chức năng] (TMP // EN/Blog/A-Trip-to-Malta-and-A-Grothendieck-Milestone/"
đã làm việc từ tháng một.

- Blockchain download

- Tải xuống blockchain

- [Transaction execution](tmp//en/blog/team-grothendieck-move-closer-to-ETC-goal/ "Team Grothendieck move closer to ETC goal, IOHK")

-[Thực hiện giao dịch] (TMP // EN/Blog/Team-Grothendieck-Move-Closer-to-etc-pal

- Command and query interface

- Giao diện lệnh và truy vấn

- Mining integration

- Tích hợp khai thác

However, please be aware that this is an early release – the important thing is that we get the Mantis client into the hands of ETC community members who can provide valuable feedback. Tell us what you think, and how we can improve Mantis. We want to stress that this is not yet production ready and has not been optimized for performance, so there will be bugs. \*\*Anyone using the beta release of the Mantis client should be using it on a testnet only, please do not use the Mantis client with actual funds.\*\*

Tuy nhiên, xin lưu ý rằng đây là một bản phát hành sớm - điều quan trọng là chúng tôi đưa khách hàng Mantis vào tay ETC cộng đồng, những người có thể cung cấp phản hồi có giá trị.
Hãy cho chúng tôi những gì bạn nghĩ, và làm thế nào chúng ta có thể cải thiện bọ ngựa.
Chúng tôi muốn nhấn mạnh rằng điều này chưa sẵn sàng sản xuất và chưa được tối ưu hóa cho hiệu suất, vì vậy sẽ có lỗi.
Gọi

These are some of the features that made it into the beta release for the Mantis client:

Đây là một số tính năng đã đưa nó vào bản phát hành beta cho ứng dụng khách Mantis:

- Mist Integration

- Tích hợp sương mù

  Connect the Mist browser to the Mantis client over HTTP.

Kết nối trình duyệt Mist với máy khách Mantis qua HTTP.

- Multi-platform

- đa nền tảng

  We have tested the application on recent versions of Linux (16.02), Mac OS (El Capitan, Sierra) and Windows (10, 8).

Chúng tôi đã thử nghiệm ứng dụng trên các phiên bản gần đây của Linux (16.02), Mac OS (El Capitan, Sierra) và Windows (10, 8).

- Testnet and Private Chain Support

- Hỗ trợ chuỗi testnet và chuỗi riêng

  The client supports synchronizing with the Morden testnet and also creating private chains.

Khách hàng hỗ trợ đồng bộ hóa với Morden Testnet và cũng tạo ra các chuỗi riêng.

- Documented Configuration

- Cấu hình tài liệu

  Our client uses neatly formatted configuration files in the “conf” folder to configure the client, all the keys and values have descriptions to help the user optimize the client's utility.

Khách hàng của chúng tôi sử dụng các tệp cấu hình được định dạng gọn gàng trong thư mục Conf Conf để định cấu hình máy khách, tất cả các khóa và giá trị đều có mô tả để giúp người dùng tối ưu hóa tiện ích của khách hàng.

We are also able to include a “Fast Sync” feature in this release. From start-up, the Mantis client (using default settings) will attempt to discover existing ETC nodes on the internet and fast sync the ETC chain from them. Fast Sync is fantastic feature for a blockchain client because it downloads a recent snapshot of the blockchain and this speeds up the process of setting up a properly functioning full node. It also downloads the entire blockchain history to have this available to other peers on request. Fast Sync is faster, and more convenient than downloading all of the blocks from peers, although this is also supported and can be switched using a flag in the configuration file.

Chúng tôi cũng có thể bao gồm một tính năng đồng bộ hóa nhanh chóng trong bản phát hành này.
Từ khởi động, ứng dụng khách Mantis (sử dụng cài đặt mặc định) sẽ cố gắng khám phá các nút ETC hiện có trên internet và đồng bộ nhanh chuỗi ETC từ chúng.
Fast Sync là tính năng tuyệt vời cho máy khách blockchain vì nó tải xuống một ảnh chụp nhanh gần đây về blockchain và điều này tăng tốc quá trình thiết lập một nút đầy đủ hoạt động đúng.
Nó cũng tải xuống toàn bộ lịch sử blockchain để có sẵn cho các đồng nghiệp khác theo yêu cầu.
Sync nhanh nhanh hơn và thuận tiện hơn so với việc tải xuống tất cả các khối từ các đồng nghiệp, mặc dù điều này cũng được hỗ trợ và có thể được chuyển đổi bằng cách sử dụng cờ trong tệp cấu hình.

Although Fast Sync is quicker, it is still slow by today's internet standards. For those who would like to get a node synchronized as fast as possible a “bootstrap database” has been provided. This database contains the whole chain up until August 2nd 2017. Users can download this large file, unzip it in their data folder and then start the Mantis client.

Mặc dù đồng bộ nhanh nhanh hơn, nhưng nó vẫn chậm theo tiêu chuẩn Internet ngày nay.
Đối với những người muốn có được một nút được đồng bộ hóa càng nhanh càng tốt, một cơ sở dữ liệu bootstrap đã được cung cấp.
Cơ sở dữ liệu này chứa toàn bộ chuỗi cho đến ngày 2 tháng 8 năm 2017. Người dùng có thể tải xuống tệp lớn này, giải nén nó trong thư mục dữ liệu của họ và sau đó bắt đầu ứng dụng khách Mantis.

The Mantis client is now being passed into the hands of technically savvy community members. Enthusiasts, who are comfortable with a command line interface and are willing to install code that has not been fully tested, will have a lot of fun using the Mantis client and can provide us with valuable feedback. We would like to encourage anyone with the necessary technical skills to try out the client and report any bugs to the [ETC Slack channel](https://ethereumclassic.herokuapp.com/ "ETC Slack channel").

Khách hàng Mantis hiện đang được chuyển vào tay các thành viên cộng đồng hiểu biết về kỹ thuật.
Những người đam mê, những người thoải mái với giao diện dòng lệnh và sẵn sàng cài đặt mã chưa được kiểm tra đầy đủ, sẽ có rất nhiều niềm vui khi sử dụng ứng dụng khách Mantis và có thể cung cấp cho chúng tôi phản hồi có giá trị.
Chúng tôi muốn khuyến khích bất cứ ai có các kỹ năng kỹ thuật cần thiết để thử khách hàng và báo cáo bất kỳ lỗi nào cho [Kênh Slack] (https://ethereumClassic.herokuapp.com/ "Kênh Slack").

We will have more updates and news coming soon, and will share our progress with the community in the upcoming weeks. Please stay tuned for more details!

Chúng tôi sẽ có nhiều cập nhật và tin tức sắp ra mắt, và sẽ chia sẻ tiến trình của chúng tôi với cộng đồng trong những tuần tới.
Hãy theo dõi để biết thêm chi tiết!

## **Attachments**

## ** tệp đính kèm **

![](img/2017-08-08-mantis-ethereum-classic-beta-release.004.png)[ Mantis – Ethereum Classic Beta Release - Input Output](https://ucarecdn.com/177749ef-1a6e-412a-868a-0037c4ff3a30/-/inline/yes/ "Mantis – Ethereum Classic Beta Release - Input Output")

