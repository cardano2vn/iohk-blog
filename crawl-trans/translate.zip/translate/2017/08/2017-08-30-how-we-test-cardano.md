# How we test Cardano
### **The importance of testing our cryptocurrency systems**
![](img/2017-08-30-how-we-test-cardano.002.png) 30 August 2017![](img/2017-08-30-how-we-test-cardano.002.png)[ Duncan Coutts](tmp//en/blog/authors/duncan-coutts/page-1/)![](img/2017-08-30-how-we-test-cardano.003.png) 8 mins read

![](img/2017-08-30-how-we-test-cardano.004.png)[ How we test Cardano - Input Output](https://ucarecdn.com/5c915142-2f71-4859-bdd1-ca14301e4140/-/inline/yes/ "How we test Cardano - Input Output")

![Duncan Coutts](img/2017-08-30-how-we-test-cardano.005.png)[](tmp//en/blog/authors/duncan-coutts/page-1/)
### [**Duncan Coutts**](tmp//en/blog/authors/duncan-coutts/page-1/)
Technical Architect

Well-Typed

- ![](img/2017-08-30-how-we-test-cardano.006.png)[](mailto:duncan.coutts@iohk.io "Email")
- ![](img/2017-08-30-how-we-test-cardano.007.png)[](https://www.youtube.com/watch?v=TZGVgNsJSnA "YouTube")
- ![](img/2017-08-30-how-we-test-cardano.008.png)[](http://www.linkedin.com/in/duncancoutts "LinkedIn")
- ![](img/2017-08-30-how-we-test-cardano.009.png)[](https://github.com/dcoutts "GitHub")

![How we test Cardano](img/2017-08-30-how-we-test-cardano.010.jpeg)

Testing is of course critically important to a cryptocurrency because the correctness and robustness of the system are what you rely on to keep your money safe, and ensure that you can spend it when you need to. So as you would expect, as our development team is getting ready for the Cardano mainnet release, testing is one of the main things that is on our minds.

Kiểm tra tất nhiên là cực kỳ quan trọng đối với một loại tiền điện tử bởi vì tính chính xác và mạnh mẽ của hệ thống là những gì bạn dựa vào để giữ tiền của bạn an toàn và đảm bảo rằng bạn có thể chi tiêu khi bạn cần.
Vì vậy, như bạn mong đợi, vì nhóm phát triển của chúng tôi đã sẵn sàng cho bản phát hành Cardano Mainnet, thử nghiệm là một trong những điều chính trong tâm trí của chúng tôi.

There are many different ways in which we test Cardano and in this post we will talk about several.

Có nhiều cách khác nhau để chúng tôi kiểm tra Cardano và trong bài đăng này, chúng tôi sẽ nói về một số cách.

Testing can be divided into two main kinds: [functional and non-functional](https://en.wikipedia.org/wiki/Software_testing#Functional_vs_non-functional_testing "Software testing, Wikipedia"):

Thử nghiệm có thể được chia thành hai loại chính: [chức năng và không có chức năng] (https://en.wikipedia.org/wiki/software_testing#functional_vs_non-foctional_testing "Kiểm tra phần mềm, wikipedia"):

- Functional testing is about checking that all the system's components meet their specifications.

- Kiểm tra chức năng là về việc kiểm tra xem tất cả các thành phần của hệ thống có đáp ứng thông số kỹ thuật của chúng không.

Functional testing is done with components on their own, in which case we call it unit testing or component testing. It is also done with all the components together, in which case we call it integration testing or system testing.

Kiểm tra chức năng được thực hiện với các thành phần của riêng họ, trong trường hợp đó chúng tôi gọi nó là kiểm tra đơn vị hoặc thử nghiệm thành phần.
Nó cũng được thực hiện với tất cả các thành phần cùng nhau, trong trường hợp chúng tôi gọi nó là kiểm tra tích hợp hoặc thử nghiệm hệ thống.

These kinds of tests are typically of the form: given some scenario, and certain inputs, the component or system produces the correct output or takes the correct next action.

Các loại thử nghiệm này thường có dạng: với một số kịch bản và một số đầu vào nhất định, thành phần hoặc hệ thống tạo ra đầu ra chính xác hoặc thực hiện hành động tiếp theo chính xác.

- Non-functional testing reveals "how" the system behaves, including the performance of the system, the resources it uses and how the system behaves when under great load or attack.

- Thử nghiệm phi chức năng cho thấy "cách" hệ thống hoạt động, bao gồm hiệu suất của hệ thống, các tài nguyên mà nó sử dụng và cách hệ thống hoạt động khi chịu tải hoặc tấn công lớn.

We have a few major parts of the Cardano system: the core, the wallet backend and the Daedulus frontend. Different parts of the system are appropriate to test in different ways.

Chúng tôi có một vài phần chính của hệ thống Cardano: cốt lõi, phụ trợ ví và mặt tiền Daedulus.
Các phần khác nhau của hệ thống là phù hợp để kiểm tra theo những cách khác nhau.

Public testnets

Testnet công khai

-----

-----

The most visible form of testing is of course the public testnets where we ask users to try the system out. This is a kind of [beta testing](https://en.wikipedia.org/wiki/Software_testing#Beta_testing "Beta testing, Wikipedia"). This is just the tip of the iceberg compared to all the testing we do internally, but it is still very useful because it covers a different set of problems compared to our internal tests.

Hình thức thử nghiệm dễ thấy nhất là tất nhiên các thử nghiệm công cộng nơi chúng tôi yêu cầu người dùng thử hệ thống.
Đây là một loại [thử nghiệm beta] (https://en.wikipedia.org/wiki/software_testing#beta_testing "Kiểm tra beta, wikipedia").
Đây chỉ là phần nổi của tảng băng so với tất cả các thử nghiệm chúng tôi thực hiện trong nội bộ, nhưng nó vẫn rất hữu ích vì nó bao gồm một loạt các vấn đề khác so với các thử nghiệm nội bộ của chúng tôi.

Users have a huge variety of desktop computers, both in hardware and configuration. It is impossible for us to test all the combinations that our users have. So having lots of real users try out the system really helps to find those strange combinations where something does not work well, and gives us the confidence that we will not bump into similar problems for mainnet.

Người dùng có rất nhiều máy tính để bàn, cả về phần cứng và cấu hình.
Chúng tôi không thể kiểm tra tất cả các kết hợp mà người dùng của chúng tôi có.
Vì vậy, có rất nhiều người dùng thực sự thử hệ thống thực sự giúp tìm ra những kết hợp kỳ lạ đó trong đó một cái gì đó không hoạt động tốt và cho chúng tôi sự tự tin rằng chúng tôi sẽ không gặp phải các vấn đề tương tự cho Mainnet.

A testnet release helps us test usability of the system: our websites, the installers, the Daedulus interface and how many cryptocurrency concepts people need to know to use the system.

Bản phát hành TestNet giúp chúng tôi kiểm tra khả năng sử dụng của hệ thống: trang web của chúng tôi, trình cài đặt, giao diện Daedulus và có bao nhiêu khái niệm tiền điện tử mà mọi người cần biết để sử dụng hệ thống.

There is no escaping the fact that a public testnet release is in some ways more "real" than any test situations we can construct artificially. Though we can certainly push the system to breaking point using our internal stress tests, there are complexities of a real world deployment that are hard to replicate in an artificial test.

Không có gì thoát khỏi thực tế là một bản phát hành TestNet công khai theo một số cách "thực tế" hơn bất kỳ tình huống thử nghiệm nào chúng ta có thể xây dựng một cách giả tạo.
Mặc dù chúng tôi chắc chắn có thể đẩy hệ thống đến điểm đột phá bằng cách sử dụng các bài kiểm tra căng thẳng nội bộ của chúng tôi, nhưng có sự phức tạp của một triển khai trong thế giới thực khó tái tạo trong một thử nghiệm nhân tạo.

Finally, it also helps our team practice making public releases, which helps us work out the kinks in our processes so that we can avoid problems during the mainnet release or later updates. And it's not just our developers and technical operations teams, a successful launch also depends on our communications and support teams. The very process of getting questions, feedback and problem reports from users during the testnet phases helps us to make sure that our support teams have the right procedures in place so that we can be confident that they can help everyone effectively during and after the mainnet launch.

Cuối cùng, nó cũng giúp nhóm của chúng tôi thực hành các bản phát hành công khai, giúp chúng tôi tìm ra các kink trong các quy trình của chúng tôi để chúng tôi có thể tránh các vấn đề trong quá trình phát hành chính hoặc cập nhật sau này.
Và đó không chỉ là các nhà phát triển và nhóm hoạt động kỹ thuật của chúng tôi, một sự ra mắt thành công cũng phụ thuộc vào các nhóm truyền thông và hỗ trợ của chúng tôi.
Chính quá trình nhận câu hỏi, phản hồi và báo cáo sự cố từ người dùng trong các giai đoạn TestNet giúp chúng tôi đảm bảo rằng các nhóm hỗ trợ của chúng tôi có các quy trình phù hợp để chúng tôi có thể tự tin rằng họ có thể giúp mọi người trong và sau khi ra mắt MainNet ra mắt
.

Automatic unit and component testing

Kiểm tra đơn vị tự động và thành phần

-----

-----

We have an increasing collection of fully automatic functional tests that cover various important parts of the logic in the core and wallet backend. These are functional tests in that they check that each component meets its specification.

Chúng tôi có một bộ sưu tập ngày càng tăng các thử nghiệm chức năng hoàn toàn tự động bao gồm các phần quan trọng khác nhau của logic trong phần phụ trợ lõi và ví.
Đây là các thử nghiệm chức năng ở chỗ họ kiểm tra xem mỗi thành phần có đáp ứng đặc điểm kỹ thuật của nó không.

These tests are run automatically by our [continuous integration](https://en.wikipedia.org/wiki/Software_testing#Continuous_testing "Continuous Testing, Wikipedia") system, which means they are run before any change to the code is accepted into our master branch. This helps to protect us against introducing [regressions](https://en.wikipedia.org/wiki/Software_testing#Regression_testing "Regression Testing, Wikipedia").

Các thử nghiệm này được chạy tự động bởi [tích hợp liên tục] (https://en.wikipedia.org/wiki/software_testing#continult_testing "Kiểm tra liên tục, Wikipedia")
Chi nhánh chính của chúng tôi.
Điều này giúp bảo vệ chúng tôi chống lại việc giới thiệu [hồi quy] (https://en.wikipedia.org/wiki/software_testing#regression_testing "Kiểm tra hồi quy, Wikipedia").

Wherever possible we make use of property based testing, rather than simple individual unit tests. Classic unit tests for a component tend to simply use a specific set of inputs and check that a specific output is produced. To comprehensively test a component in this style often requires a large number of specific pairs of input and expected output. This is laborious and tends to miss corner cases that programmers do not think of. By contrast, property based testing involves taking the component's high level specification and reformulating the specification as an executable property. That means that for any specific inputs the property can actually be executed to check that the property is true for those inputs. These properties are expressed in the same programming language as the code being tested. The technique then involves checking the property on hundreds or thousands of test inputs. The technique is to use systematic random generation to produce test inputs. This means that programmers do not have to think of lots of test inputs and it avoids human bias. So it tends to give much better test coverage with less effort.

Bất cứ nơi nào có thể, chúng tôi sử dụng thử nghiệm dựa trên tài sản, thay vì các bài kiểm tra đơn vị riêng lẻ đơn giản. Các thử nghiệm đơn vị cổ điển cho một thành phần có xu hướng chỉ cần sử dụng một tập hợp các đầu vào cụ thể và kiểm tra xem một đầu ra cụ thể có được tạo ra không. Để kiểm tra toàn diện một thành phần theo kiểu này thường đòi hỏi một số lượng lớn các cặp đầu vào cụ thể và đầu ra mong đợi. Đây là công việc tốn nhiều công sức và có xu hướng bỏ lỡ các trường hợp góc mà các lập trình viên không nghĩ đến. Ngược lại, thử nghiệm dựa trên tài sản liên quan đến việc lấy thông số kỹ thuật cấp cao của thành phần và cải tổ đặc tả là một tài sản thực thi. Điều đó có nghĩa là đối với bất kỳ đầu vào cụ thể nào, tài sản thực sự có thể được thực thi để kiểm tra xem thuộc tính này có đúng với các đầu vào đó không. Các thuộc tính này được thể hiện bằng cùng một ngôn ngữ lập trình khi mã được kiểm tra. Kỹ thuật sau đó liên quan đến việc kiểm tra tài sản trên hàng trăm hoặc hàng ngàn đầu vào thử nghiệm. Kỹ thuật này là sử dụng thế hệ ngẫu nhiên có hệ thống để tạo ra các đầu vào thử nghiệm. Điều này có nghĩa là các lập trình viên không phải nghĩ về nhiều đầu vào thử nghiệm và nó tránh được sự thiên vị của con người. Vì vậy, nó có xu hướng cung cấp bảo hiểm thử nghiệm tốt hơn nhiều với ít nỗ lực hơn.

Specifically, we use the [QuickCheck](https://en.wikipedia.org/wiki/QuickCheck "QuickCheck, Wikipedia") system for property based testing. Perhaps the greatest advantage is that it makes developers *think* in terms of the specification and properties of their code, rather than individual inputs and outputs. This is a much higher level way of thinking about code and helps to produce simpler more reliable code.

Cụ thể, chúng tôi sử dụng [QuickCheck] (https://en.wikipedia.org/wiki/quickcheck "QuickCheck, Wikipedia") để kiểm tra dựa trên tài sản.
Có lẽ lợi thế lớn nhất là nó làm cho các nhà phát triển * nghĩ * về đặc điểm kỹ thuật và thuộc tính của mã của họ, thay vì đầu vào và đầu ra riêng lẻ.
Đây là một cách suy nghĩ cấp cao hơn nhiều về mã và giúp tạo ra mã đáng tin cậy hơn đơn giản hơn.

System level tests and performance tests

Kiểm tra cấp hệ thống và kiểm tra hiệu suất

-----

-----

While all the unit and component testing gives us confidence that each part of the system works ok on its own, [system level tests](https://en.wikipedia.org/wiki/Software_testing#System_testing "System Testing, Wikipedia") are to check if the parts all work together as a whole.

Mặc dù tất cả các thử nghiệm đơn vị và thành phần cho chúng ta sự tự tin rằng mỗi phần của hệ thống hoạt động tốt, [[kiểm tra cấp hệ thống] (https://en.wikipedia.org/wiki/software_testing#system_testing "Kiểm tra hệ thống, wikipedia")
là kiểm tra xem các bộ phận có làm việc cùng nhau như một toàn bộ không.

For this we have to set up a cluster of machines and configure them to run the blockchain protocol together. The main functional test that we use works like this: we have a special transaction generator program that constructs tens of thousands of transactions and submits them to nodes in the cluster. The code is instrumented to record certain key events in a log file, such as when each transaction reaches each node. We let this run for around an hour. At the end of the run we have a tool that analyses the blockchain and the log files from all the nodes. This checks that all the transactions that were submitted did make it into the blockchain. It also checks if there were any unexpected forks in the blockchain or missing blocks. In normal conditions there will be no forks or missing blocks.

Đối với điều này, chúng tôi phải thiết lập một cụm máy và định cấu hình chúng để chạy giao thức blockchain với nhau.
Thử nghiệm chức năng chính mà chúng tôi sử dụng các hoạt động như thế này: Chúng tôi có một chương trình Trình tạo giao dịch đặc biệt xây dựng hàng chục ngàn giao dịch và gửi chúng đến các nút trong cụm.
Mã này được thiết bị để ghi lại một số sự kiện chính trong một tệp nhật ký, chẳng hạn như khi mỗi giao dịch đạt đến mỗi nút.
Chúng tôi để điều này chạy trong khoảng một giờ.
Khi kết thúc lần chạy, chúng tôi có một công cụ phân tích blockchain và các tệp nhật ký từ tất cả các nút.
Điều này kiểm tra xem tất cả các giao dịch đã được gửi đã đưa nó vào blockchain.
Nó cũng kiểm tra xem có bất kỳ dĩa bất ngờ nào trong blockchain hoặc các khối bị thiếu không.
Trong điều kiện bình thường sẽ không có dĩa hoặc khối thiếu.

We can use the same basic approach to test the system when we deliberately attack it, such as taking out nodes, or preventing nodes from talking to each other for a while. In this case we expect temporary forks or missing blocks, but we can check that the system recovers properly.

Chúng ta có thể sử dụng cùng một cách tiếp cận cơ bản để kiểm tra hệ thống khi chúng ta cố tình tấn công nó, chẳng hạn như lấy các nút hoặc ngăn các nút nói chuyện với nhau trong một thời gian.
Trong trường hợp này, chúng tôi mong đợi các dĩa tạm thời hoặc các khối bị thiếu, nhưng chúng tôi có thể kiểm tra xem hệ thống có phục hồi đúng không.

We use the same basic approach for non-functional [performance tests](https://en.wikipedia.org/wiki/Software_testing#Software_performance_testing "Software Performance Testing, Wikipedia"). We adjust the transaction generator to submit transactions at a higher rate to stress the system and see how high we can push the throughput before it hits a bottleneck. We can also check that even though the system has hit its maximum capacity it continues to function in a stable way.

Chúng tôi sử dụng cùng một cách tiếp cận cơ bản cho [Kiểm tra hiệu suất không có chức năng (https://en.wikipedia.org/wiki/software_testing#software_performance_testing "Kiểm tra hiệu suất phần mềm, Wikipedia").
Chúng tôi điều chỉnh trình tạo giao dịch để gửi các giao dịch với tốc độ cao hơn để nhấn mạnh hệ thống và xem chúng tôi có thể đẩy thông lượng cao đến mức nào trước khi nó chạm vào một nút cổ chai.
Chúng tôi cũng có thể kiểm tra xem mặc dù hệ thống đã đạt được công suất tối đa, nó vẫn tiếp tục hoạt động theo cách ổn định.

Throughput, meaning transactions per second, is important but so is latency. By latency we mean how long it takes for a transaction to get into the blockchain. Our analysis tool can also determine the distribution of latency. A low latency with little variance shows us that transactions are flowing smoothly to the nodes that create blocks and that those nodes are creating blocks on time.

Thông lượng, có nghĩa là giao dịch mỗi giây, là quan trọng nhưng độ trễ cũng vậy.
Theo độ trễ, chúng tôi có nghĩa là mất bao lâu để một giao dịch vào blockchain.
Công cụ phân tích của chúng tôi cũng có thể xác định phân phối độ trễ.
Độ trễ thấp với ít phương sai cho chúng ta thấy rằng các giao dịch đang chảy trơn tru đến các nút tạo ra các khối và các nút đó đang tạo các khối đúng thời gian.

Frontend testing

Kiểm tra phía trước

-----

-----

Our Daedalus frontend team have a fully automated set of tests that cover every function of the user interface. In turn this also tests every interaction between the wallet frontend and wallet backend. So this also gives us an automatic integration test for the combination of the wallet frontend and backend.

Nhóm Frontalus Frontend của chúng tôi có một bộ thử nghiệm hoàn toàn tự động bao gồm mọi chức năng của giao diện người dùng.
Đổi lại, điều này cũng kiểm tra mọi tương tác giữa mặt tiền ví và phụ trợ ví.
Vì vậy, điều này cũng cung cấp cho chúng tôi một bài kiểm tra tích hợp tự động cho sự kết hợp của mặt tiền ví và phụ trợ.

Frontend testing is a bit different from most other testing. Most testing works by a test program directly using a program interface, whereas frontend testing requires interacting with an actual human interface. User interface testing frameworks simulate what a real user does: clicking buttons and typing in web form boxes.

Kiểm tra frontend là một chút khác biệt so với hầu hết các thử nghiệm khác.
Hầu hết các thử nghiệm hoạt động theo chương trình thử nghiệm trực tiếp bằng giao diện chương trình, trong khi thử nghiệm Frontend yêu cầu tương tác với giao diện người thực tế.
Khung kiểm tra giao diện người dùng mô phỏng những gì người dùng thực sự làm: nhấp vào nút và nhập hộp biểu mẫu web.

The result is actually rather fascinating to watch: it's as if an invisible robot is sitting at the computer typing and clicking very quickly to set up accounts, send transactions and all the other things.

Kết quả thực sự khá hấp dẫn khi xem: như thể một robot vô hình đang ngồi ở máy tính và nhấp rất nhanh để thiết lập tài khoản, gửi giao dịch và tất cả những thứ khác.

Daedalus acceptance tests â€“ a fully automated set of tests that cover every function of the user interface.

Các bài kiểm tra chấp nhận của Daedalus - Một bộ kiểm tra hoàn toàn tự động bao gồm mọi chức năng của giao diện người dùng.

Security auditing

Kiểm toán bảo mật

-----

-----

Counterintuitively, when it comes to cryptography and security -- which cryptocurrencies of course rely on completely -- testing is in fact not very effective. Testing usually shows us that the expected things do work, but it's hard to use normal testing to show that unexpected things cannot happen. And showing that some hacker cannot subvert the system is just the kind of thing that is hard to test for.

Phản đối, khi nói đến mật mã và bảo mật - điều mà các loại tiền điện tử tất nhiên dựa vào hoàn toàn - thử nghiệm trên thực tế là không hiệu quả lắm.
Thử nghiệm thường cho chúng ta thấy rằng những thứ mong đợi hoạt động, nhưng thật khó để sử dụng thử nghiệm thông thường để cho thấy những điều bất ngờ không thể xảy ra.
Và cho thấy rằng một số tin tặc không thể lật đổ hệ thống chỉ là loại điều khó kiểm tra.

The solution is not testing but auditing by experts in cryptography and security. This means experts carefully reviewing the designs to check that the arguments for why the system should be safe are sound, and also reviewing the code to make sure the code matches up with the design.

Giải pháp không phải là kiểm tra mà là kiểm toán bởi các chuyên gia về mật mã và bảo mật.
Điều này có nghĩa là các chuyên gia xem xét cẩn thận các thiết kế để kiểm tra xem các đối số về lý do tại sao hệ thống phải an toàn là âm thanh, và cũng xem xét mã để đảm bảo mã khớp với thiết kế.

Of course, the basic design for the proof of stake blockchain used in Cardano has already been peer reviewed by academic cryptographers. There are other parts of the system that we have had to develop in the last year -- beyond just the blockchain -- and the most security critical parts of those have been reviewed by our research team, and also by an external security audit team. Additionally, the security audit team have reviewed many of the most important parts of the code to check that the code matches the design.

Tất nhiên, thiết kế cơ bản cho bằng chứng về blockchain cổ phần được sử dụng trong Cardano đã được đánh giá ngang hàng bởi các nhà mật mã học.
Có những phần khác của hệ thống mà chúng tôi đã phải phát triển trong năm ngoái - ngoài chỉ số blockchain - và những phần quan trọng nhất trong số những người đã được nhóm nghiên cứu của chúng tôi xem xét, và bởi một nhóm kiểm toán bảo mật bên ngoài.
Ngoài ra, nhóm kiểm toán bảo mật đã xem xét nhiều phần quan trọng nhất của mã để kiểm tra xem mã có phù hợp với thiết kế không.

Conclusion

Sự kết luận

-----

-----

A cryptocurrency system is a surprisingly complex piece of software and it has to work correctly, be robust to deliberate attacks and have good performance. Of course Cardano is a new from-scratch cryptocurrency, not based on any existing system, so all of it has to be carefully tested or reviewed.

Một hệ thống tiền điện tử là một phần mềm phức tạp đáng ngạc nhiên và nó phải hoạt động chính xác, mạnh mẽ để có chủ ý các cuộc tấn công và có hiệu suất tốt.
Tất nhiên Cardano là một loại tiền điện tử mới từ đầu, không dựa trên bất kỳ hệ thống hiện có nào, vì vậy tất cả đều phải được kiểm tra hoặc xem xét cẩn thận.

Hopefully this post has given you some insight into how much is involved in testing Cardano, and how serious we are about security, robustness and performance.

Hy vọng rằng bài đăng này đã cung cấp cho bạn một số cái nhìn sâu sắc về bao nhiêu liên quan đến việc thử nghiệm Cardano và mức độ nghiêm trọng của chúng tôi về an ninh, mạnh mẽ và hiệu suất.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-08-30-how-we-test-cardano.004.png)[ How we test Cardano - Input Output](https://ucarecdn.com/5c915142-2f71-4859-bdd1-ca14301e4140/-/inline/yes/ "How we test Cardano - Input Output")

