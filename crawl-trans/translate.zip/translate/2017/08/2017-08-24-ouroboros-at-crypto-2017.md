# Ouroboros at Crypto 2017
### **IOHK presents first provably secure proof of stake algorithm at flagship event**
![](img/2017-08-24-ouroboros-at-crypto-2017.002.png) 24 August 2017![](img/2017-08-24-ouroboros-at-crypto-2017.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2017-08-24-ouroboros-at-crypto-2017.003.png) 3 mins read

![](img/2017-08-24-ouroboros-at-crypto-2017.004.png)[ Ouroboros at Crypto 2017 - Input Output](https://ucarecdn.com/9a58efb5-e664-4a5b-bbc9-16ed312ee1a1/-/inline/yes/ "Ouroboros at Crypto 2017 - Input Output")

![Jane Wild](img/2017-08-24-ouroboros-at-crypto-2017.005.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2017-08-24-ouroboros-at-crypto-2017.006.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2017-08-24-ouroboros-at-crypto-2017.007.png)[](https://twitter.com/jane_wild_ "Twitter")

Developing a secure proof of stake algorithm is one of the big challenges in cryptocurrency, and a proposed solution to this problem won the attention of the academic community this week in California. Several hundred cryptographers from around the world arrived at the University of California Santa Barbara on Sunday for the flagship annual event of their field, Crypto 2017. Over several days, they present cutting edge research for the scrutiny of their peers, while in the evenings they continue discussions with friends and colleagues over dinner on the university campus, with the inspiring backdrop of the Santa Ynez mountains meeting the Pacific ocean behind them.

Phát triển một bằng chứng an toàn về thuật toán cổ phần là một trong những thách thức lớn trong tiền điện tử, và một giải pháp đề xuất cho vấn đề này đã giành được sự chú ý của cộng đồng học thuật trong tuần này ở California.
Hàng trăm nhà mật mã từ khắp nơi trên thế giới đã đến Đại học California Santa Barbara vào Chủ nhật cho sự kiện thường niên hàng đầu của họ, Crypto 2017. Trong nhiều ngày, họ trình bày nghiên cứu tiên tiến để xem xét kỹ lưỡng các đồng nghiệp của họ, trong khi vào buổi tối, họ
Tiếp tục thảo luận với bạn bè và đồng nghiệp trong bữa tối trong khuôn viên trường đại học, với bối cảnh đầy cảm hứng của dãy núi Santa Ynez gặp nhau ở Thái Bình Dương phía sau họ.

Ouroboros, developed by a team led by IOHK chief scientist Aggelos Kiayias, made it through a tough admission process for the prestigious conference. This year, 311 papers were submitted and of those 72 were accepted. Only three papers at the conference were on the subject of blockchain. All three papers were supported by IOHK funding.

Ouroboros, được phát triển bởi một nhóm do nhà khoa học trưởng của IOHK Aggelos Kiayias dẫn đầu, đã vượt qua một quá trình nhập học khó khăn cho hội nghị uy tín.
Năm nay, 311 giấy tờ đã được gửi và trong số 72 người đã được chấp nhận.
Chỉ có ba bài báo tại hội nghị là về chủ đề blockchain.
Tất cả ba bài báo được hỗ trợ bởi tài trợ của IOHK.

Speaking after his presentation, Professor Kiayias said: "Weâ€™re very happy that we had the opportunity to present Ouroboros at the conference. The protocol and especially its security analysis were very well received by fellow cryptographers."

Phát biểu sau bài thuyết trình của mình, Giáo sư Kiayias nói: "Chúng tôi rất vui vì chúng tôi đã có cơ hội trình bày Ouroboros tại hội nghị.

"Our next steps will be to focus on the next version of the protocol, [Ouroboros Praos](tmp//en/research/papers/#XJ6MHFXX "Ouroboros Praos, iohk.io") which improves even further the security and performance characteristics of the protocol."

"Các bước tiếp theo của chúng tôi sẽ là tập trung vào phiên bản tiếp theo của giao thức, [OuroBoros PRAOS] (TMP // EN/Nghiên cứu/Giấy tờ/#XJ6MHFXX" OuroBoros PRAOS, IOHK.IO ")
của giao thức. "

The Ouroboros protocol stands out as the first proof of stake algorithm that is provably secure, meaning that it offers security guarantees that are mathematically proven. This is essential for a protocol that is intended to be used in cryptocurrency, an infrastructure that must be relied on to carry billions of dollars worth of value. In addition to security, if blockchains are going to become infrastructure for new financial systems they must be able to comfortably handle millions of users. The key to scaling up is proof of stake, a far more energy efficient and cost effective algorithm, and as such this research represents a significant step forward in cryptography. Ouroboros also has the distinction of being implemented â€“ the protocol will be an integral part of Cardano, a blockchain system currently in development.

Giao thức Ouroboros nổi bật là bằng chứng đầu tiên về thuật toán cổ phần được bảo mật có thể chứng minh được, có nghĩa là nó cung cấp các đảm bảo bảo mật được chứng minh về mặt toán học.
Điều này rất cần thiết cho một giao thức được dự định sẽ được sử dụng trong tiền điện tử, một cơ sở hạ tầng phải được dựa vào để mang lại giá trị hàng tỷ đô la.
Ngoài bảo mật, nếu các blockchain sẽ trở thành cơ sở hạ tầng cho các hệ thống tài chính mới, họ phải có khả năng xử lý hàng triệu người dùng.
Chìa khóa để nhân rộng là bằng chứng về cổ phần, một thuật toán hiệu quả hơn về năng lượng và hiệu quả về chi phí, và do đó, nghiên cứu này thể hiện một bước tiến đáng kể trong mật mã.
Ouroboros cũng có sự khác biệt được thực hiện - Giao thức sẽ là một phần không thể thiếu của Cardano, một hệ thống blockchain hiện đang được phát triển.

There were two other papers presented at the bitcoin session on Monday. The [Bitcoin Backbone Protocol with Chains of Variable Difficulty](https://eprint.iacr.org/2016/1048.pdf "The Bitcoin Backbone Protocol with Chains of Variable Difficulty, Eprint, IACR"), was produced by a team of three researchers and included Prof Kiayias. It is a continuation of previous research into Bitcoin, which was itself the first work to prove security properties of its blockchain.

Có hai bài báo khác được trình bày tại phiên Bitcoin vào thứ Hai.
[Giao thức xương sống Bitcoin với chuỗi độ khó thay đổi] (https://eprint.iacr.org/2016/1048.pdf "Giao thức xương sống Bitcoin với chuỗi khó khăn thay đổi, EPrint, IACR")
Ba nhà nghiên cứu và bao gồm Giáo sư Kiayias.
Đó là sự tiếp nối của nghiên cứu trước đây về Bitcoin, bản thân nó là công việc đầu tiên để chứng minh các đặc tính bảo mật của blockchain của nó.

A third paper on the subject of bitcoin was presented, [Bitcoin as a Transaction Ledger: A Composable Treatment](https://eprint.iacr.org/2017/149.pdf "Bitcoin as a Transaction Ledger: A Composable Treatment, Eprint, IACR").

Một bài báo thứ ba về chủ đề của Bitcoin đã được trình bày, [Bitcoin như một sổ cái giao dịch: một điều trị có thể kết hợp] (https://eprint.iacr.org/2017/149.pdf "Bitcoin như một sổ cái giao dịch: điều trị có thể kết hợp, Eprint
, IACR ").

Other notable talks at the conference included a presentation by John Martinis, an expert on quantum computing and former physics professor at the University of California Santa Barbara, who is now working at Google to build a quantum computer.

Các cuộc nói chuyện đáng chú ý khác tại hội nghị bao gồm một bài thuyết trình của John Martini, một chuyên gia về điện toán lượng tử và cựu giáo sư vật lý tại Đại học California Santa Barbara, người hiện đang làm việc tại Google để xây dựng một máy tính lượng tử.

Leading cryptographers at the conference included Whitfield Diffie, pioneer of the public key cryptography that made Bitcoin possible, and Ron Rivest, Adi Shamir, and Leonard Adleman, who came up with the RSA public-key cryptosystem that is widely used for secure data transmission.

Các nhà mật mã học hàng đầu tại hội nghị bao gồm Whitfield Diffie, người tiên phong của mật mã chủ chốt công cộng đã biến Bitcoin có thể, và Ron Rivest, Adi Shamir và Leonard Adman, người đã đưa ra hệ thống mật mã khóa công cộng RSA được sử dụng rộng rãi để truyền dữ liệu an toàn.

![Ouroboros Authors at Crypto 2017](img/2017-08-24-ouroboros-at-crypto-2017.008.jpeg) Ouroboros Praos researchers, left to right: Bernardo David, Alexander Russell, Aggelos Kiayias, Peter GaÅ¾i

## **Attachments**

## ** tệp đính kèm **

![](img/2017-08-24-ouroboros-at-crypto-2017.004.png)[ Ouroboros at Crypto 2017 - Input Output](https://ucarecdn.com/9a58efb5-e664-4a5b-bbc9-16ed312ee1a1/-/inline/yes/ "Ouroboros at Crypto 2017 - Input Output")

