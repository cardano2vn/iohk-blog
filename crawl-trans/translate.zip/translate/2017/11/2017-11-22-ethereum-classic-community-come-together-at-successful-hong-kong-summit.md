# Ethereum Classic community comes together at successful Hong Kong summit
### **Principles and plans for growth unite participants at event organised by Grayscale**
![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.002.png) 22 November 2017![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.003.png) 10 mins read

![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.004.png)[ Ethereum Classic community comes togeth](https://ucarecdn.com/5c3a1417-0a48-4500-8fab-6baeaa5d50d1/-/inline/yes/ "Ethereum Classic community comes togeth")

![Jeremy Wood](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

Since day one, Ethereum Classic has been driven by principles. What began as a disparate group of people who came together after the DAO hack and the consequent hard fork on Ethereum has now become a strong and growing community, united by a belief in immutability and that code is law. So it was tremendously exciting to see everyone gather at the first Ethereum Classic Summit held last week and watch the community move beyond the realm of instant messaging to interacting in person and making new friends. There were many highlights of the two day summit in Hong Kong. It was a moment to reflect on how much Ethereum Classic has achieved in a little over a year, developing its identity, building its technology and securing its future. Grayscale, which provides Bitcoin and Ethereum Classic investment trusts, has provided much momentum by organising this event.

Barry Silbert, founder, explained that Grayscale will put a third of its ETC fees for three years into supporting the growth of ETC though development, marketing and the community, and the ETC Cooperative has been established to do this. Barry told IOHK: â€œWe wanted to do our part and help support increased communication, collaboration and bring together all the various stakeholders at least once a year. Iâ€™ve been super excited to see the participation, the level of engagement, the quality of the speakers and participants and think this year has been a huge success.â€

![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.009.jpeg) Charles Hoskinson giving his keynote speech

What might come a surprise to some is that Ethereum Classic is not a direct competitor to Ethereum. In [his keynote speech](https://www.youtube.com/watch?v=eUqdgEzKZMg "ETC Summit, Charles Hoskinson, CEO, IOHK") on the first day of the summit, Charles Hoskinson, founder and CEO of IOHK, and former CEO of Ethereum, said: â€œFrankly, we compete far more with Bitcoin. To me, Ethereum Classic is basically a digital commodity, itâ€™s digital gold. Itâ€™s really exciting because it can give us a very interesting design space that we can explore thatâ€™s totally independent of the design space that Ethereum is pursuing. We donâ€™t have to embrace proof of stake, Plasma or the fork of the week. Instead we can start with principles and we can grow from principles.â€

Điều có thể gây ngạc nhiên cho một số người là Ethereum Classic không phải là đối thủ cạnh tranh trực tiếp với Ethereum.
Trong [Bài phát biểu quan trọng của anh ấy] (https://www.youtube.com/watch?v=euqdgezkzmg "Hội nghị thượng đỉnh, Charles Hoskinson, CEO, IOHK")
và cựu Giám đốc điều hành của Ethereum, cho biết: "Một cách đáng kinh ngạc, chúng tôi cạnh tranh nhiều hơn với Bitcoin.
Đối với tôi, Ethereum Classic về cơ bản là một mặt hàng kỹ thuật số, đó là vàng kỹ thuật số.
Nó thực sự thú vị bởi vì nó có thể cung cấp cho chúng ta một không gian thiết kế rất thú vị mà chúng ta có thể khám phá điều đó hoàn toàn độc lập với không gian thiết kế mà Ethereum đang theo đuổi.
Chúng tôi không phải chấp nhận bằng chứng về cổ phần, huyết tương hoặc nĩa trong tuần.
Thay vào đó chúng ta có thể bắt đầu với các nguyên tắc và chúng ta có thể phát triển từ các nguyên tắc.

Charles argued that two separate philosophies had always sat uncomfortably together in Ethereum, even before the community split. â€œWe actually had two Ethereums from the beginning but we didnâ€™t know that. We had two philosophies at the same time. One was this notion that code is law, that code canâ€™t care, it doesnâ€™t matter what youâ€™re running and it doesnâ€™t matter about the consequences. But there was this other philosophy, the notion of a world computer, the idea that you could have universal infrastructure that would be a beautiful computation layer that could be added to the internet. But the fundamental problem is that these things are philosophically so different they canâ€™t coexist. When youâ€™re the world computer you have to fork, you have to embrace mutability and have a lot of flexibility in your platform.â€

Charles lập luận rằng hai triết lý riêng biệt luôn ngồi bên nhau một cách khó chịu trong Ethereum, ngay cả trước khi cộng đồng chia tay.
"Chúng tôi thực sự đã có hai Ethereums ngay từ đầu nhưng chúng tôi đã không biết điều đó.
Chúng tôi đã có hai triết lý cùng một lúc.
Một là khái niệm rằng mã là luật, mã đó không thể quan tâm, nó không quan trọng những gì bạn đang chạy và nó không quan trọng về hậu quả.
Nhưng có một triết lý khác này, khái niệm về một máy tính thế giới, ý tưởng rằng bạn có thể có cơ sở hạ tầng phổ quát sẽ là một lớp tính toán đẹp có thể được thêm vào internet.
Nhưng vấn đề cơ bản là những điều này về mặt triết học rất khác nhau, chúng không thể cùng tồn tại.
Khi bạn phải là máy tính thế giới mà bạn phải bỏ qua, bạn phải nắm lấy khả năng đột biến và có rất nhiều sự linh hoạt trong nền tảng của bạn.

Now more than a year after the split, Ethereum Classic has developed its own identity. It had a great asset in its principled and warm spirited community, Charles pointed out and championed the development work being done. â€œWe see a lot of great things coming down the pipeline. Itâ€™s got to a point where we can prove beyond reasonable doubt that we can keep up with Ethereum Foundation and in some cases weâ€™re writing better software. As a comparison, Bitcoin Core has about 110,000 to 120,000 lines of C++ code. The [Mantis client](https://github.com/input-output-hk/mantis "Mantis, Github") does more and itâ€™s 10,000 lines of code. Itâ€™s twelve times more concise. â€œThe Sputnik VM, pulling the VM out and having it as a standalone, is a phenomenal idea, itâ€™s a great piece of engineering. Itâ€™s far better than anything coming out of the Ethereum Foundation.â€

Bây giờ hơn một năm sau khi chia tay, Ethereum Classic đã phát triển bản sắc riêng của mình.
Nó có một tài sản lớn trong cộng đồng tinh thần nguyên tắc và ấm áp của nó, Charles đã chỉ ra và bảo vệ công việc phát triển đang được thực hiện.
"Chúng tôi thấy rất nhiều điều tuyệt vời sắp diễn ra.
Đó là một điểm mà chúng ta có thể chứng minh vượt quá sự nghi ngờ hợp lý rằng chúng ta có thể theo kịp Ethereum Foundation và trong một số trường hợp, chúng ta đã viết phần mềm tốt hơn.
Để so sánh, Bitcoin Core có khoảng 110.000 đến 120.000 dòng mã C ++.
[Ứng dụng khách Mantis] (https://github.com/input-output-hk/mantis "Mantis, github") làm nhiều hơn và 10.000 dòng mã.
Đó là mười hai lần ngắn gọn hơn.
"Sputnik VM, kéo VM ra và có nó như một độc lập, là một ý tưởng phi thường, đó là một phần kỹ thuật tuyệt vời.
Nó tốt hơn nhiều so với bất cứ điều gì phát ra từ nền tảng Ethereum.

A highlight of the conference was hearing about the steady pace of development of the ETC protocol. The eight-strong team of engineers that make up ETCDEV team are working on implementing the monetary policy, a flexible software developer kit that can be used to build applications on Ethereum Classic, and making performance and reliability improvements to the Ethereum Virtual Machine. Isaac Ardis, Go developer from ETC Dev, outlined the direction and purpose of the Emerald Project, which is not just a wallet but a library and suite of tools for third party developers. Licensing projects under Apache 2.0 makes them commercial-friendly, and easy to implement.

Một điểm nổi bật của hội nghị đã được nghe về tốc độ phát triển ổn định của giao thức ETC.
Nhóm các kỹ sư gồm tám người tạo nên nhóm ETCDEV đang làm việc để thực hiện chính sách tiền tệ, một bộ công cụ phát triển phần mềm linh hoạt có thể được sử dụng để xây dựng các ứng dụng trên Ethereum Classic và cải thiện hiệu suất và độ tin cậy cho máy ảo Ethereum.
Isaac Ardis, nhà phát triển từ ETC Dev, phác thảo hướng và mục đích của dự án Emerald, không chỉ là ví mà là một thư viện và bộ công cụ cho các nhà phát triển bên thứ ba.
Các dự án cấp phép theo Apache 2.0 làm cho chúng thân thiện với thương mại và dễ thực hiện.

Igor Artamanov, CTO of ETCDEV, told IOHK that he believed Ethereum Classic would rise to be in the top three cryptocurrencies. â€œWeâ€™ll continue our work on open tools for developers who will build apps on top of ETC blockchain. Our goal is to set up development processes and help with building various tools for engineers and open source libraries around ETC.â€ A theme of the conference was formal verification, and on that topic Igor said: â€œIt will be cool to have. We are not experts in formal verification, but if someone will decide to introduce it to SputnikVM, weâ€™ll appreciate that.â€ On monetary policy, Matt Mazur, advisor to the ETC Dev team, gave a clearly explained presentation on ECIP 1017, the proposal that contains changes such as capping the amount of ETC that can be created, in contrast to Ethereumâ€™s uncapped supply.

Igor Artamanov, CTO của ETCDEV, nói với IOHK rằng ông tin rằng Ethereum Classic sẽ tăng lên trong ba loại tiền điện tử hàng đầu.
"Chúng tôi sẽ tiếp tục công việc của chúng tôi trên các công cụ mở cho các nhà phát triển, những người sẽ xây dựng các ứng dụng trên blockchain ETC.
Mục tiêu của chúng tôi là thiết lập các quy trình phát triển và giúp xây dựng các công cụ khác nhau cho các kỹ sư và thư viện nguồn mở xung quanh, v.v.
.
Chúng tôi không phải là chuyên gia về xác minh chính thức, nhưng nếu ai đó quyết định giới thiệu nó với Sputnikvm, chúng tôi sẽ đánh giá cao điều đó.
1017, đề xuất chứa các thay đổi như giới hạn lượng ETC có thể được tạo ra, trái ngược với nguồn cung chưa được khai thác của Ethereum.

![Alan Verbner speaking at ETC Summit](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.010.jpeg) 

Alan Verbner speaking at ETC Summit

Alan Verbner phát biểu tại Hội nghị thượng đỉnh ETC

The [ETC monetary policy](/blog/ethereum-classic/a-joint-statement-on-ethereum-classics-monetary-policy/ "ETC monetary policy, iohk.io") is modelled on Bitcoinâ€™s monetary policy, and is designed to reduce risk, create simplicity, and encourage investors. Every 5 million blocks, there is a 20 per cent reduction in block rewards. The question of how Ethereum Classic will scale has always been an issue of debate. Igor shared insights on how sidechains could be deployed, making use of public and private sidechains and having the main chain for security. Cody Burns, ETCDEV adviser, talked about cross-chain interoperability and how [cross-chain atomic swaps](https://medium.com/@DontPanicBurns/ethereum-cross-chain-atomic-swaps-5a91adca4f43 "Cody Burns, Medium") could allow people to exchange coins in a trustless manner.

[Chính sách tiền tệ ETC] (/Blog/Ethereum-Classic/A-Joint-Statement-on-Ethereum-Classics-monetary-policy/"ETC Chính sách tiền tệ, IOHK.IO")
và được thiết kế để giảm rủi ro, tạo ra sự đơn giản và khuyến khích các nhà đầu tư.
Cứ sau 5 triệu khối, phần thưởng khối giảm 20 %.
Câu hỏi làm thế nào Ethereum Classic sẽ quy mô luôn luôn là một vấn đề tranh luận.
Igor đã chia sẻ những hiểu biết về cách Sidechains có thể được triển khai, sử dụng các sidechains công cộng và tư nhân và có chuỗi chính để bảo mật.
Cody Burns, Cố vấn ETCDEV, đã nói về khả năng tương tác chuỗi chéo và cách [hoán đổi nguyên tử chéo] (https://medium.com/@dontpanicburns/ethereum-cross-Chain-Atomic-SWAPS-5A91ADCA4F43 "Cody Burns, Medium"
) có thể cho phép mọi người trao đổi tiền xu một cách đáng tin cậy.

There was news from the Grothendieck team, the IOHK developers that are dedicated to ETC and who have over the past year built the Mantis client for Ethereum Classic. Alan McSherry, team lead, gave details about integration with the Daedalus wallet. It will be fantastic for the community to have another option for a wallet, where they can securely store their ETC. â€œThe Daedalus release is going to happen hopefully in December. Thatâ€™s taking the Daedalus wallet, the UI that was built for [Cardano](http://cardanohub.org/ "Cardano Hub"), and putting it on top of our Mantis client, our ETC node, so youâ€™re able to use a familiar UI with Ethereum Classic.â€

Có tin tức từ nhóm Grothendieck, các nhà phát triển IOHK dành riêng cho ETC và những người trong năm qua đã xây dựng khách hàng Mantis cho Ethereum Classic.
Alan McSherry, trưởng nhóm, đã đưa ra chi tiết về việc tích hợp với ví Daedalus.
Thật tuyệt vời khi cộng đồng có một lựa chọn khác cho một ví, nơi họ có thể lưu trữ an toàn, v.v.
"Bản phát hành Daedalus sẽ xảy ra hy vọng vào tháng 12.
Đó là lấy ví Daedalus, UI được xây dựng cho [Cardano] (http://cardanohub.org/ "Cardano Hub"), và đặt nó lên đầu khách hàng Mantis của chúng tôi, nút của chúng tôi, vì vậy bạn
™ có thể sử dụng giao diện người dùng quen thuộc với Ethereum Classic.

Alan McSherry also offered a look at what the team are thinking about in terms of Mantis development in 2018. With regard to [K Framework](https://github.com/runtimeverification/k "K Framework, Github"), the important research to create formal semantics of the EVM done by Professor Grigore Rosu at the University of Illinois, and funded by IOHK, he said: â€œWith any luck, that will result in the possibility of writing Scala contracts that can be compiled to run on the EVM, or a slightly different version of the EVM, and weâ€™ll have the formal verification and itâ€™ll be a question of trying to create formal proofs around those contracts.â€ [IOHK research into sidechains](tmp//en/research/papers/#67CHCNP8 "Non-Interactive Proofs of Proof-of-Work, iohk.io") could allow the possibility of creating contracts to allow interactions between ETC and Ethereum and ETC and Bitcoin, while other features on the horizon for ETC include zero knowledge proofs and anonymous addresses, he said.

Alan McSherry cũng đưa ra một cái nhìn về những gì nhóm đang nghĩ về sự phát triển của con ngựa năm 2018. Liên quan đến [K Framework] (https://github.com/runtimeverification/k "K Framework, GitHub"), điều quan trọng Nghiên cứu để tạo ra ngữ nghĩa chính thức của EVM được thực hiện bởi Giáo sư Grigore Rosu tại Đại học Illinois, và được tài trợ bởi IOHK, ông nói: "Với bất kỳ may mắn nào, điều đó sẽ dẫn đến khả năng viết các hợp đồng Scala có thể được biên dịch để chạy trên EVM, hoặc một phiên bản hơi khác của EVM và chúng tôi sẽ có xác minh chính thức và nó sẽ là một câu hỏi về việc cố gắng tạo ra các bằng chứng chính thức xung quanh các hợp đồng đó. // EN/Nghiên cứu/Giấy tờ/#67CHCNP8 "Bằng chứng không tương tác của bằng chứng làm việc, iohk.io") có thể cho phép khả năng tạo ra các hợp đồng cho phép tương tác giữa ETC và Ethereum và ETC và Bitcoin khác, trong khi các tính năng khác trên Chân trời cho ETC bao gồm bằng chứng kiến thức bằng không và địa chỉ ẩn danh, ông nói.

And Alan Verbner, developer on the team, gave a reminder of why the team use Scala. â€œFunctional programming allows you to create less and more secure code and thatâ€™s why we are trying to build in Mantis compact code that is safe and you can check its correctness. Our client has 10,000 lines of code, itâ€™s easier to read and easier to access. We are building open source software so we like people to look into it and analyse it to look for bugs and security issues. You have fewer lines of code to test.â€

Và Alan Verbner, nhà phát triển trong nhóm, đã nhắc nhở lý do tại sao nhóm sử dụng Scala.
"Lập trình chức năng cho phép bạn tạo mã ít hơn và an toàn hơn và đó là lý do tại sao chúng tôi đang cố gắng xây dựng mã nhỏ gọn Mantis an toàn và bạn có thể kiểm tra tính chính xác của nó.
Khách hàng của chúng tôi có 10.000 dòng mã, việc đọc và dễ dàng hơn để truy cập dễ dàng hơn.
Chúng tôi đang xây dựng phần mềm nguồn mở để chúng tôi muốn mọi người xem xét nó và phân tích nó để tìm kiếm các lỗi và các vấn đề bảo mật.
Bạn có ít dòng mã hơn để kiểm tra.

The theme of principles arose again when it came to hearing from Ethereum Classic miners. We heard how mining pools chose ETC because of the core principles of the community, proving the attractiveness of the code is law philosophy. There was good news from the 91Pool, the first group that ever mined on ETC, when Meicy Mei announced the group has purchased a building in Shanghai to serve as a dedicated hub for the ETC community in China, with a cafe and bar that will host meet ups.

Chủ đề của các nguyên tắc phát sinh một lần nữa khi nghe từ các thợ mỏ cổ điển Ethereum.
Chúng tôi đã nghe cách các nhóm khai thác đã chọn vv vì các nguyên tắc cốt lõi của cộng đồng, chứng minh sự hấp dẫn của bộ luật là triết lý luật pháp.
Có một tin tốt từ 91pool, nhóm đầu tiên được khai thác trên vv, khi Meiic Mei tuyên bố nhóm đã mua một tòa nhà ở Thượng Hải để phục vụ như một trung tâm chuyên dụng cho cộng đồng ETC ở Trung Quốc, với một quán cà phê và quán bar sẽ tổ chức
gặp gỡ.

![ETC Summit key stakeholders on stage](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.010.jpeg) 

ETC Summit key stakeholders on stage

Vv Hội nghị các bên liên quan chính trên sân khấu

A final reminder of the principles that brought the Ethereum Classic together came during an impassioned keynote speech from Meredith Patterson, an expert in programming language security. She recounted the scorn that Ethereum had responded with when formal methods of software development were suggested as a good idea. She argued that Ethereum Classic still had the chance to adopt formal methods â€“ an approach that IOHK is a strong advocate of and actively pursues during its development process. For code to be law, she said, the meaning of the code must be unambiguous, and users must have the same understanding of it that machines do. Steps to get there include adopting a rigorous formal semantics, like KEVM. Deficits in test suites should be found and the problem corrected. Solidity should be replaced.

Một lời nhắc nhở cuối cùng về các nguyên tắc đã kết hợp Ethereum Classic đến với nhau trong một bài phát biểu quan trọng từ Meredith Patterson, một chuyên gia về bảo mật ngôn ngữ lập trình.
Cô kể lại sự khinh miệt mà Ethereum đã trả lời khi các phương pháp phát triển phần mềm chính thức được đề xuất là một ý tưởng tốt.
Cô lập luận rằng Ethereum Classic vẫn có cơ hội áp dụng các phương pháp chính thức - một cách tiếp cận mà IOHK là một người ủng hộ mạnh mẽ và tích cực theo đuổi trong quá trình phát triển của nó.
Để mã là luật, cô nói, ý nghĩa của mã phải không rõ ràng và người dùng phải có cùng hiểu biết về nó mà máy móc làm.
Các bước để đạt được điều đó bao gồm áp dụng một ngữ nghĩa chính thức nghiêm ngặt, như Kevm.
Thiếu hụt trong các bộ thử nghiệm nên được tìm thấy và vấn đề được sửa chữa.
Sự vững chắc nên được thay thế.

The importance of coming together as a community to debate these issues cannot be underestimated. The results of these discussions will drive the development of Ethereum Classic. Sharing this view, Barry told IOHK: â€œI think in the digital currency space thereâ€™s a little too much interaction done through social media and through anonymous forums and itâ€™s important to get people together to meet each other, challenge each other, and do it in a way that is respectful and that fosters communication and collaboration. So I do think itâ€™s important to have summits like this. I absolutely expect that weâ€™ll do it again next year and hopefully the year after that will become an annual event that everybody in the community looks forward to.â€

Tầm quan trọng của việc đến với nhau như một cộng đồng để tranh luận về những vấn đề này không thể được đánh giá thấp.
Kết quả của các cuộc thảo luận này sẽ thúc đẩy sự phát triển của Ethereum Classic.
Chia sẻ quan điểm này, Barry nói với IOHK: "Tôi nghĩ trong không gian tiền tệ kỹ thuật số có quá nhiều tương tác được thực hiện thông qua phương tiện truyền thông xã hội và thông qua các diễn đàn ẩn danh và điều quan trọng là phải gặp nhau để gặp nhau, thách thức từng người
khác, và làm điều đó theo cách tôn trọng và thúc đẩy giao tiếp và hợp tác.
Vì vậy, tôi nghĩ rằng điều quan trọng là phải có những hội nghị thượng đỉnh như thế này.
Tôi hoàn toàn hy vọng rằng chúng tôi sẽ làm lại vào năm tới và hy vọng năm sau đó sẽ trở thành một sự kiện thường niên mà mọi người trong cộng đồng mong chờ.

"Ethereum Classic is the most decentralized coin, and the most distributed without a significant holder of the token supply." - via Meicy Mei from 91 Pool [#ETCSummit](https://twitter.com/hashtag/ETCSummit?src=hash&ref_src=twsrc%5Etfw) [#etc](https://twitter.com/hashtag/etc?src=hash&ref_src=twsrc%5Etfw)

"Ethereum Classic là đồng tiền phi tập trung nhất và phân phối nhiều nhất mà không có người giữ nguồn cung cấp mã thông báo đáng kể."
- thông qua Meiic Mei từ 91 Pool [#etcsummit] (https://twitter.com/hashtag/etcsummit?src=hash&ref_src=twsrc%5etfw) [#ETC]
= Hash & ref_src = twsrc%5etfw)

â€” Ethereum Classic (@eth\_classic) [14 November 2017](https://twitter.com/eth_classic/status/930317743013933056?ref_src=twsrc%5Etfw)

â € Ethereum Classic (@eth \ _Classic) [14 tháng 11 năm 2017] (https://twitter.com/eth_classic/status/930317743013933056?ref_src=twsrc%5etfw)

Over 29K views from our global community who tuned in to our live stream.[#ETCSummit](https://twitter.com/hashtag/ETCSummit?src=hash&ref_src=twsrc%5Etfw) was trending on Twitter in Hong Kong during the summit with the amount of engagement from our community. 

Hơn 29k lượt xem từ cộng đồng toàn cầu của chúng tôi, những người đã điều chỉnh đến luồng trực tiếp của chúng tôi. [
với số lượng tham gia từ cộng đồng của chúng tôi.

Thank you all for the support and we are excited about the future. [#ETC](https://twitter.com/hashtag/ETC?src=hash&ref_src=twsrc%5Etfw) [#ETCisComing](https://twitter.com/hashtag/ETCisComing?src=hash&ref_src=twsrc%5Etfw) [pic.twitter.com/ncGL1CHWJ2](https://t.co/ncGL1CHWJ2)

Cảm ơn tất cả các bạn đã hỗ trợ và chúng tôi rất vui mừng về tương lai.
[#ETC] (https://twitter.com/hashtag/etc?src=hash&ref_src=twsrc
[pic.twitter.com/ncgl1chwj2THER(https://t.co/ncgl1chwj2)

â€” Ethereum Classic (@eth\_classic) [15 November 2017](https://twitter.com/eth_classic/status/930808055876419584?ref_src=twsrc%5Etfw)

â € Ethereum Classic (@eth \ _Classic) [15 tháng 11 năm 2017] (https://twitter.com/eth_classic/status/930808055876419584?ref_src=twsrc

## **Attachments**

## ** tệp đính kèm **

![](img/2017-11-22-ethereum-classic-community-come-together-at-successful-hong-kong-summit.004.png)[ Ethereum Classic community comes togeth](https://ucarecdn.com/5c3a1417-0a48-4500-8fab-6baeaa5d50d1/-/inline/yes/ "Ethereum Classic community comes togeth")

