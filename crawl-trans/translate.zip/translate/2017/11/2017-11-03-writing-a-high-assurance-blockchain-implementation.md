# Writing a High-Assurance Blockchain Implementation
### **Guest blog from Edsko de Vries, who is working on the high assurance implementation of the Ouroboros blockchain protocol**
![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.002.png) 3 November 2017![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.002.png)[ Edsko de Vries](tmp//en/blog/authors/edsko-de-vries/page-1/)![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.003.png) 9 mins read

![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.004.png)[ Writing a High-Assurance Blockchain Implementation - Input Output](https://ucarecdn.com/ccc9e08c-f362-44fb-be67-369e8edb3f35/-/inline/yes/ "Writing a High-Assurance Blockchain Implementation - Input Output")

![Edsko de Vries](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.005.png)[](tmp//en/blog/authors/edsko-de-vries/page-1/)
### [**Edsko de Vries**](tmp//en/blog/authors/edsko-de-vries/page-1/)
Software Engineer

Well-Typed

- ![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.006.png)[](http://www.linkedin.com/in/edsko-de-vries-04126b31 "LinkedIn")
- ![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.007.png)[](https://twitter.com/EdskoDeVries "Twitter")
- ![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.008.png)[](https://github.com/edsko "GitHub")

![Writing a High-Assurance Blockchain Implementation](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.009.jpeg)

In our previous blog post [Cryptocurrencies need a safeguard to prevent another DAO disaster](tmp//en/blog/cryptocurrencies-need-a-safeguard-to-prevent-another-DAO-disaster/ "Cryptocurrencies need a safeguard to prevent another DAO disaster, IOHK blog") we discussed the need for high assurance development of cryptocurrencies and their underlying blockchain protocols. We also sketched one way in which one might go about this, but we did not give much detail. In this follow-up blog post we delve into computer science theory a bit more, and in particular we will take a closer look at process algebras. We will have no choice but omit a lot of detail still, but hopefully we can develop some intuition and provide a starting point for reading more.

Trong bài đăng trên blog trước đây của chúng tôi [tiền điện tử cần một biện pháp bảo vệ để ngăn chặn một thảm họa DAO khác] (TMP // EN/blog/tiền điện tử-cần thiết
Dao thảm họa, blog IOHK ") Chúng tôi đã thảo luận về sự cần thiết phải phát triển bảo đảm cao của tiền điện tử và các giao thức blockchain cơ bản của chúng.
Chúng tôi cũng đã phác thảo một cách mà người ta có thể đi về điều này, nhưng chúng tôi không cung cấp nhiều chi tiết.
Trong bài đăng trên blog tiếp theo này, chúng tôi đi sâu vào lý thuyết khoa học máy tính hơn một chút, và đặc biệt chúng tôi sẽ xem xét kỹ hơn về đại số quy trình.
Chúng tôi sẽ không có lựa chọn nào khác ngoài việc bỏ qua rất nhiều chi tiết, nhưng hy vọng chúng tôi có thể phát triển một số trực giác và cung cấp một điểm khởi đầu để đọc thêm.

## **Compositionality**

## ** Tính sáng tác **

When we want to study computer programs as mathematical objects that we can manipulate and analyze, we need to write them in a programming language for which we have a well understood mathematical theory. If this mathematical theory inherits much of what we know from elementary mathematics, that's an additional benefit. For example, we learn in school that:

Khi chúng ta muốn nghiên cứu các chương trình máy tính như các đối tượng toán học mà chúng ta có thể thao tác và phân tích, chúng ta cần viết chúng bằng ngôn ngữ lập trình mà chúng ta có một lý thuyết toán học được hiểu rõ.
Nếu lý thuyết toán học này thừa hưởng nhiều những gì chúng ta biết từ toán học cơ bản, đó là một lợi ích bổ sung.
Ví dụ, chúng ta học ở trường rằng:

for every number n, n + n = 2 \* n

cho mỗi số n, n + n = 2 \* n

Shockingly, in many programming languages even this most basic of equations does not hold. For example, in the language C, when we define

Thật đáng kinh ngạc, trong nhiều ngôn ngữ lập trình, ngay cả các phương trình cơ bản nhất này không được giữ.
Ví dụ, bằng ngôn ngữ C, khi chúng ta xác định

int f() {

int f () {

` `return 5;

`` Trả lại 5;

}

}

int g() {

int g () {

` `int x;

`` int x;

` `scanf("%d", &x);

`` scanf ("%d", & x);

` `return x;

`` Trả lại x;

}

}

we have that while f() + f() is the same as 2 *f() (both equate to 10), g() + g() is certainly not the same as 2* g(): the former asks the user for two numbers and adds them together, the latter asks the user for a single number and multiplies it by two. In the language Haskell this distinction between an honest-to-goodness number, and a program that returns a number is explicit (this is what we mean when we say that Haskell is a pure language), and for numbers basic mathematical equations such as the above hold true. Knowing that for every number n, n + n = 2 *n in Haskell would still not be particularly useful without another property of Haskell: when we see the expression n + n anywhere in a program, we can (almost) always replace it with 2* n and know that our program still behaves in the same way: we say that Haskell is referentially transparent. This is key: it means that we can analyze bits of our program at a time and know that our conclusions are also correct in the wider context of the whole program. In other words, it means that we can do compositional reasoning: we can understand the larger program by understanding its components individually. This is essential when dealing with anything but toy examples.

chúng ta có điều đó trong khi f () + f () giống như 2 * f () (cả hai đều tương đương với 10), g () + g () chắc chắn không giống với 2 * g () Người dùng cho hai số và thêm chúng lại với nhau, cái sau yêu cầu người dùng cho một số duy nhất và nhân với hai số. Trong ngôn ngữ Haskell Sự khác biệt này giữa một số trung thực để tốt và một chương trình trả về một số là rõ ràng (đây là những gì chúng ta muốn nói khi chúng ta nói rằng Haskell là một ngôn ngữ thuần túy) và đối với các phương trình toán học cơ bản như Trên giữ đúng. Biết rằng với mỗi số N, N + N = 2 *N trong Haskell vẫn sẽ không đặc biệt hữu ích nếu không có thuộc tính khác của Haskell: khi chúng ta thấy biểu thức N + N ở bất cứ đâu trong một chương trình, chúng ta có thể (gần như) 2* n và biết rằng chương trình của chúng tôi vẫn hoạt động theo cùng một cách: chúng tôi nói rằng Haskell là minh bạch một cách tham chiếu. Đây là chìa khóa: điều đó có nghĩa là chúng tôi có thể phân tích các bit của chương trình của chúng tôi tại một thời điểm và biết rằng kết luận của chúng tôi cũng chính xác trong bối cảnh rộng hơn của toàn bộ chương trình. Nói cách khác, điều đó có nghĩa là chúng ta có thể thực hiện lý luận sáng tác: chúng ta có thể hiểu chương trình lớn hơn bằng cách hiểu các thành phần của nó một cách riêng lẻ. Điều này là điều cần thiết khi xử lý bất cứ điều gì ngoại trừ các ví dụ đồ chơi.

## **Process Algebra**

## ** Quy trình Đại số **

Of course, even in Haskell we can read from files, write to network sockets, etc. and while the type system makes sure that such programs are distinguished from pure values, reasoning about such programs is nonetheless more difficult because we do not have a good mathematical theory that covers all of these "effects". It is therefore useful to identify a subset of effects for which we do have a mathematical theory. Different kinds of applications need different subsets of effects. For some applications a process algebra is a good match. A process algebra is a programming language in which we can express systems of concurrent programs that communicate with each other, along with a mathematical theory. There are many different kinds of process algebras, and they differ in the details. For example, some provide synchronous point to point communication, others asynchronous; a few provide broadcast communication. So what would be an analogue to a law like n + n = 2 \* n in such a language? Well, there are multiple answers, but one answer is bisimilarity, which intuitively allows us to say that "two processes behave the same". For example, consider the two following processes

Tất nhiên, ngay cả trong Haskell, chúng tôi có thể đọc từ các tệp, viết vào các ổ cắm mạng, v.v. Và trong khi hệ thống loại đảm bảo rằng các chương trình như vậy được phân biệt với các giá trị thuần túy, lý do về các chương trình như vậy là khó khăn hơn vì chúng tôi không có Lý thuyết toán học bao gồm tất cả các "hiệu ứng" này. Do đó, rất hữu ích để xác định một tập hợp các hiệu ứng mà chúng ta có một lý thuyết toán học. Các loại ứng dụng khác nhau cần các tập hợp con hiệu ứng khác nhau. Đối với một số ứng dụng, đại số quy trình là một kết hợp tốt. Đại số quy trình là ngôn ngữ lập trình, trong đó chúng ta có thể diễn đạt các hệ thống các chương trình đồng thời giao tiếp với nhau, cùng với một lý thuyết toán học. Có nhiều loại đại số quy trình khác nhau, và chúng khác nhau về chi tiết. Ví dụ, một số cung cấp điểm đồng bộ để giao tiếp điểm, một số khác không đồng bộ; Một số ít cung cấp truyền thông phát sóng. Vậy điều gì sẽ tương tự như một luật như N + N = 2 \* n trong một ngôn ngữ như vậy? Chà, có nhiều câu trả lời, nhưng một câu trả lời là một chút, theo trực giác cho phép chúng ta nói rằng "hai quá trình hành xử giống nhau". Ví dụ: xem xét hai quy trình sau

p1 m = forever $ do

p1 m = mãi mãi $ làm

`        `bcast m

`` Bcast m

`        `bcast m

`` Bcast m

p2 m = forever $ do

p2 m = mãi mãi $ làm

`        `bcast m

`` Bcast m

Both p1 and p2 consist of an infinite loop; p1 broadcasts message m twice within that loop, and p2 only once. While these two processes may look different, they really aren't: both broadcast message m indefinitely. To make "they aren't really different" more precise, we can try to prove that p1 and p2 are bisimilar. Intuitively, this means that we have to show that any action that p1 can take, p2 can also take, and they are still bisimilar after taking those actions. The proof for p1 and p2 would look something like this, where a red line indicates "can do the same action here":

Cả P1 và P2 đều bao gồm một vòng vô hạn;
P1 phát thông báo m hai lần trong vòng lặp đó và P2 chỉ một lần.
Mặc dù hai quá trình này có thể trông khác nhau, nhưng chúng thực sự không: cả hai thông báo phát sóng M vô thời hạn.
Để thực hiện "chúng không thực sự khác biệt" chính xác hơn, chúng ta có thể cố gắng chứng minh rằng P1 và P2 rất giống nhau.
Theo trực giác, điều này có nghĩa là chúng ta phải chỉ ra rằng bất kỳ hành động nào mà P1 có thể thực hiện, P2 cũng có thể thực hiện và chúng vẫn rất giống nhau sau khi thực hiện những hành động đó.
Bằng chứng cho P1 và P2 sẽ trông giống như thế này, trong đó một đường màu đỏ chỉ ra "có thể thực hiện hành động tương tự ở đây":

![Process Algebra](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.010.png)

So why is this useful? When two processes are bisimilar, you know three things: they can do the same actions, they will continue to be able to do the same actions, and most importantly, this is compositional: if p1 is bisimilar to p2 then we can replace p1 with p2 in (most) contexts. As before, this is essential: it means we can understand and analyze a larger program by understanding and analyzing its components.

Vậy tại sao điều này lại hữu ích?
Khi hai quá trình rất giống nhau, bạn biết ba điều: chúng có thể thực hiện các hành động tương tự, họ sẽ tiếp tục có thể thực hiện các hành động tương tự và quan trọng nhất là điều này là thành phần: nếu P1 rất giống với P2 thì chúng ta có thể thay thế P1 bằng P1 bằng
P2 trong bối cảnh (hầu hết).
Như trước đây, điều này rất cần thiết: nó có nghĩa là chúng ta có thể hiểu và phân tích một chương trình lớn hơn bằng cách hiểu và phân tích các thành phần của nó.

## **Psi-calculus**

## ** psi-calculus **

Process algebra is a large field in computer science, and many different kinds of algebras have been studied and are being studied. Some of the earliest and perhaps most well-known are the [Calculus of Communicating Systems (CCS)](https://en.wikipedia.org/wiki/Calculus_of_communicating_systems "Calculus of communicating systems, Wikipedia") and [Communicating Sequential Processes (CSP)](https://en.wikipedia.org/wiki/Communicating_sequential_processes "Communicating sequential processes, Wikipedia"). These days one of the most important process algebras is the [pi calculus](https://en.wikipedia.org/wiki/%CE%A0-calculus "Ï€-calculus, Wikipedia"); argueably, the pi calculus is to concurrent programming what the lambda calculus is to functional programming. While the lambda calculus forms the theoretical basis for functional programming, nobody actually writes any code in the lambda calculus; it would be akin to writing in assembly language. Instead we write programs in a much more sophisticated functional language like Haskell. Similarly, the pi calculus is a "core" calculus, good for foundational research but not so good for actually writing programs. Instead, we will use the [psi calculus](https://www.it.uu.se/research/group/concurrency/publ "Some publications by the Concurrency Group, Uppsala University") which is a generalization of the pi calculus with more advanced features, but still with a well understood theory. Let's consider an example of bisimilarity in the psi calculus, similar to the previous example but slightly more interesting. Do you think we should regard processes p3 and p4 as "behaving the same"?

Đại số quá trình là một lĩnh vực lớn trong khoa học máy tính, và nhiều loại đại số khác nhau đã được nghiên cứu và đang được nghiên cứu. Một số sớm nhất và có lẽ nổi tiếng nhất là [tính toán của các hệ thống giao tiếp (CCS)] (https://en.wikipedia.org/wiki/calculus_of_creanicication_systems "Tính toán của các hệ thống giao tiếp, wikipedia"). Csp)] (https://en.wikipedia.org/wiki/Creadication_questential_processes "Truyền đạt các quy trình tuần tự, Wikipedia"). Ngày nay, một trong những đại số quy trình quan trọng nhất là [tính toán pi] (https://en.wikipedia.org/wiki/%CE%A0-calculus "ï € -calculus, wikipedia"); Thật khó khăn, tính toán PI là lập trình đồng thời những gì tính toán Lambda là lập trình chức năng. Mặc dù tính toán Lambda tạo thành cơ sở lý thuyết cho lập trình chức năng, nhưng không ai thực sự viết bất kỳ mã nào trong tính toán Lambda; Nó sẽ giống như viết bằng ngôn ngữ lắp ráp. Thay vào đó, chúng tôi viết các chương trình bằng một ngôn ngữ chức năng tinh vi hơn nhiều như Haskell. Tương tự, tính toán PI là tính toán "cốt lõi", tốt cho nghiên cứu nền tảng nhưng không tốt cho các chương trình thực sự. Thay vào đó, chúng tôi sẽ sử dụng [Tính toán PSI] (https://www.it.uu.se/research/group/concurrency/publ "Một số ấn phẩm của nhóm đồng thời, Đại học Uppsala") Với các tính năng nâng cao hơn, nhưng vẫn có một lý thuyết được hiểu rõ. Chúng ta hãy xem xét một ví dụ về tính nhị phân trong tính toán PSI, tương tự như ví dụ trước nhưng thú vị hơn một chút. Bạn có nghĩ rằng chúng ta nên coi các quy trình P3 và P4 là "hành xử giống nhau" không?

p3 m = forever $ do

p3 m = mãi mãi $ làm

`        `k  <- newKey ; bcast (encrypt k  m)

`` k <- newkey;
bcast (mã hóa k m)

`        `k' <- newKey ; bcast (encrypt k' m)

`` k '<- newkey;
bcast (mã hóa k 'm)

p4 m = forever $ do

p4 m = mãi mãi $ làm

`        `k  <- newKey ; bcast (encrypt k m)

`` k <- newkey;
bcast (mã hóa k m)

What about process p5 and p3?

Còn quá trình P5 và P3 thì sao?

p5 m = forever $ do

p5 m = mãi mãi $ làm

`        `k <- newKey

`` K <- Newkey

`        `bcast (encrypt k m)

`` Bcast (mã hóa k m)

`        `bcast (encrypt k m)

`` Bcast (mã hóa k m)

It turns out process p3 and p4 are bisimilar, and the proof is almost the same as before

Hóa ra quá trình P3 và P4 rất giống nhau và bằng chứng gần giống như trước đây

![Psi Calculus](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.011.png)

They both send out an infinite number of messages, each message encrypted with a new key. Although p3 and p4 will generate different keys, from the outside we cannot tell them apart because we don't know anything about those keys. Process p5 and p4 are however not bisimilar:

Cả hai đều gửi một số lượng tin nhắn vô hạn, mỗi tin nhắn được mã hóa bằng một khóa mới.
Mặc dù P3 và P4 sẽ tạo ra các khóa khác nhau, nhưng từ bên ngoài chúng ta không thể nói với họ vì chúng ta không biết gì về các phím đó.
Tuy nhiên, quá trình P5 và P4 không phải là một chút:

![Psi Calculus](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.012.png)

After p5 sends out a message encrypted with some key k, it then sends that message again encrypted with the same key; p4 cannot follow.

Sau khi P5 gửi một tin nhắn được mã hóa bằng một số khóa K, sau đó nó sẽ gửi lại tin nhắn đó được mã hóa với cùng một khóa;
P4 không thể theo dõi.

## **Ouroboros Praos**

## ** OUROBOROS PRAOS **

One of the nice things about the psi calculus is that we can embed it as a domain-specific language (DSL) in Haskell. We use this to define a model of the Ouroboros Praos blockchain protocol, which we can both execute and run (it's just Haskell after all), and even test using [QuickCheck](https://hackage.haskell.org/package/QuickCheck "The QuickCheck package, Haskell.org") (Haskell's randomized testing tool), but moreover is also amenable to formal verification using the psi calculus metatheory.

Một trong những điều tốt đẹp về tính toán PSI là chúng ta có thể nhúng nó như một ngôn ngữ cụ thể về miền (DSL) trong Haskell.
Chúng tôi sử dụng điều này để xác định một mô hình của giao thức blockchain praos Ouroboros, mà chúng tôi có thể thực hiện và chạy (sau tất cả chỉ là Haskell) và thậm chí kiểm tra bằng [QuickCheck] (https://hackage.haskell.org/package
"Gói QuickCheck, haskell.org") (công cụ thử nghiệm ngẫu nhiên của Haskell), nhưng hơn nữa cũng có thể chấp nhận xác minh chính thức bằng cách sử dụng phép đo tính toán PSI.

We start by expressing the algorithm as it is defined in the [Ouroboros Praos paper](tmp//en/research/papers/#XJ6MHFXX "Ouroboros Praos: An adaptively-secure, semi-synchronous proof-of-stake protocol, IOHK") in our Haskell psi calculus embedding. Although we cannot formally verify that this algorithm matches the one in the paper, the correspondence is close enough that it can easily be verified by hand. We can run this implementation and experiment with it. This first implementation will do various things that, while we can implement them, we would not want to do in a real implementation. So we then make a number of small, incremental adjustments, that get us closer and closer to an actual high performance implementation. Each of the individual adjustments should be small enough that a human reader can understand how we go from one implementation to the next and convince themselves that we haven't changed anything fundamental.

Chúng tôi bắt đầu bằng cách thể hiện thuật toán vì nó được định nghĩa trong [Bài viết của OuroBoros PRAOS] (TMP // EN/Nghiên cứu/Giấy tờ/#XJ6MHFXX "
) trong Haskell PSI Tính toán của chúng tôi nhúng.
Mặc dù chúng tôi không thể chính thức xác minh rằng thuật toán này khớp với cái trong bài báo, nhưng thư từ đủ gần để nó có thể dễ dàng được xác minh bằng tay.
Chúng ta có thể chạy triển khai này và thử nghiệm với nó.
Việc triển khai đầu tiên này sẽ làm nhiều việc khác nhau, trong khi chúng tôi có thể thực hiện chúng, chúng tôi sẽ không muốn thực hiện trong một triển khai thực sự.
Vì vậy, sau đó chúng tôi thực hiện một số điều chỉnh nhỏ, gia tăng, giúp chúng tôi ngày càng gần gũi hơn với việc thực hiện hiệu suất cao thực tế.
Mỗi điều chỉnh riêng lẻ phải đủ nhỏ để người đọc có thể hiểu cách chúng ta đi từ việc thực hiện này sang việc thực hiện tiếp theo và thuyết phục bản thân rằng chúng ta không thay đổi bất cứ điều gì cơ bản.

Each of these algorithms can be run, so that we can test that all of the adjustments we make to the original algorithm don't change any fundamental properties. Since we express the algorithm in terms of a well-understood process calculus, we can also take some of these adjustments and formally prove that we haven't changed anything fundamental. Bisimulation is but one tool in the theoretical toolbox here; there are many others. The end result is that we have a bridge from the high level specification of the algorithm in the academic literature to the actual low level implementation that we implement, with high assurance that what we actually run indeed corresponds to the algorithm defined and proved correct by the cryptographers.

Mỗi thuật toán này có thể được chạy, để chúng tôi có thể kiểm tra rằng tất cả các điều chỉnh chúng tôi thực hiện đối với thuật toán ban đầu không thay đổi bất kỳ thuộc tính cơ bản nào.
Vì chúng tôi thể hiện thuật toán về tính toán quy trình được hiểu rõ, chúng tôi cũng có thể thực hiện một số điều chỉnh này và chính thức chứng minh rằng chúng tôi không thay đổi bất cứ điều gì cơ bản.
Bisimulation là một công cụ trong hộp công cụ lý thuyết ở đây;
Có nhiều người khác.
Kết quả cuối cùng là chúng tôi có một cầu nối từ đặc điểm kỹ thuật cấp cao của thuật toán trong tài liệu học thuật đến việc thực hiện cấp thấp thực tế mà chúng tôi thực hiện, với sự đảm bảo cao rằng những gì chúng tôi thực sự chạy thực sự tương ứng với thuật toán được xác định và chứng minh
Máy mật mã.

## **Download and Contributing**

## ** Tải xuống và đóng góp **

If you want to follow the work in progress, you can find the psi calculus development of the Praos blockchain protocol at [Praos Formalization](https://github.com/input-output-hk/ouroboros-spec "Praos formalization, Github"). One way in which you could contribute would be to read the document, compare it to the Praos algorithm in the literature, and convince yourself that indeed they do the same thing; after all, this is a step we cannot formally prove. Although the subsequent adjustments are in principle formally provable, in practice we may only have resources to do that for a few steps; so here too the more people read the document and try to poke holes in the arguments, the better. If you want to do more than verify what we have done, we would be happy to discuss the possibilities; contact us [here](mailto:duncan@iohk.io). We look forward to hearing from you!

Nếu bạn muốn theo dõi công việc đang được tiến hành, bạn có thể tìm thấy sự phát triển tính toán PSI của giao thức blockchain PRAOS tại [chính thức hóa PRAOS] (https://github.com/input-output-hk
").
Một cách mà bạn có thể đóng góp là đọc tài liệu, so sánh nó với thuật toán PRAOS trong văn học, và thuyết phục bản thân rằng thực sự họ làm điều tương tự;
Rốt cuộc, đây là một bước chúng ta không thể chính thức chứng minh.
Mặc dù các điều chỉnh tiếp theo về nguyên tắc chính thức có thể chứng minh, nhưng trong thực tế, chúng ta chỉ có thể có tài nguyên để làm điều đó trong một vài bước;
Vì vậy, ở đây cũng vậy, càng nhiều người đọc tài liệu và cố gắng chọc các lỗ hổng trong các cuộc tranh luận thì càng tốt.
Nếu bạn muốn làm nhiều hơn là xác minh những gì chúng tôi đã làm, chúng tôi sẽ rất vui khi thảo luận về các khả năng;
Liên hệ với chúng tôi [tại đây] (mailto: duncan@iohk.io).
Chúng tôi mong chờ tin từ bạn!

## **Attachments**

## ** tệp đính kèm **

![](img/2017-11-03-writing-a-high-assurance-blockchain-implementation.004.png)[ Writing a High-Assurance Blockchain Implementation - Input Output](https://ucarecdn.com/ccc9e08c-f362-44fb-be67-369e8edb3f35/-/inline/yes/ "Writing a High-Assurance Blockchain Implementation - Input Output")

