# IOHK Spotlight – Alan Verbner
### **Building a future for Ethereum Classic in Argentina**
![](img/2017-09-21-iohk-spotlight-alan-verbner.002.png) 21 September 2017![](img/2017-09-21-iohk-spotlight-alan-verbner.002.png)[ Laurie Wang](tmp//en/blog/authors/laurie-wang/page-1/)![](img/2017-09-21-iohk-spotlight-alan-verbner.003.png) 4 mins read

![](img/2017-09-21-iohk-spotlight-alan-verbner.004.png)[ IOHK Spotlight – Alan Verbner - Input Output](https://ucarecdn.com/863740a3-5013-4ca9-9971-3bb70e5b5feb/-/inline/yes/ "IOHK Spotlight – Alan Verbner - Input Output")

![Laurie Wang](img/2017-09-21-iohk-spotlight-alan-verbner.005.png)[](tmp//en/blog/authors/laurie-wang/page-1/)
### [**Laurie Wang**](tmp//en/blog/authors/laurie-wang/page-1/)
Social Media Lead

Marketing and Communications

- ![](img/2017-09-21-iohk-spotlight-alan-verbner.006.png)[](https://www.linkedin.com/in/lauriewang "LinkedIn")
- ![](img/2017-09-21-iohk-spotlight-alan-verbner.007.png)[](https://twitter.com/lauriewang_ "Twitter")
- ![](img/2017-09-21-iohk-spotlight-alan-verbner.008.png)[](https://github.com/laurieiohk "GitHub")

![IOHK Spotlight – Alan Verbner](img/2017-09-21-iohk-spotlight-alan-verbner.009.jpeg)

What is money and how is it created? And how can we make a better financial system? Alan Verbner, an Ethereum Classic developer on Team Grothendieck at IOHK, started asking these questions as he lived through the volatile [economic crisis in Argentina](https://en.wikipedia.org/wiki/Economic_history_of_Argentina#Economic_crisis_.281998_-_2002.29 "Economic history of Argentina, Wikipedia") from 1998 to 2002. During this time, Argentina had defaulted on [billions of dollars worth of debt](http://www.nytimes.com/2001/12/24/world/argentine-leader-declares-default-on-billions-in-debt.html "Argentine leader declares default on billions in debt, The New York Times"). People protested in the streets and roared their disapproval of the government. 

Tiền là gì và nó được tạo ra như thế nào?
Và làm thế nào chúng ta có thể tạo ra một hệ thống tài chính tốt hơn?
Alan Verbner, một nhà phát triển Ethereum Classic trên Team Grothendieck tại IOHK, bắt đầu hỏi những câu hỏi này khi anh ta sống qua cuộc khủng hoảng kinh tế ở Argentina] (https://en.wikipedia.org/wiki/economic_history_of_argentina.
29 "Lịch sử kinh tế của Argentina, Wikipedia") từ năm 1998 đến 2002. Trong thời gian này, Argentina đã mặc định về [hàng tỷ đô la nợ nần] (http://www.nytimes.com/2001/12/24/world/
Argentina-Leader-Declares-Default-on-Billions-in-debt.html "Nhà lãnh đạo Argentina tuyên bố mặc định về hàng tỷ nợ, Thời báo New York").
Mọi người phản đối trên đường phố và gầm lên sự từ chối của chính phủ.

“I no longer believed that banks and money were necessary. Society will find a way to survive without them,” Alan said. He saw that local citizens in his country were unable to take their money out of the bank to [access their savings](http://www.bbc.co.uk/news/world-latin-america-15981406 "Argentines recall economic crisis 10 years on, BBC"), and long queues formed outside banks across Argentina as people desperately tried to get hold of their money. In January 2002, the government decided to devalue the peso, and [abandon the peg to the US dollar](https://en.wikipedia.org/wiki/Convertibility_plan "Convertibility plan, Wikipedia"), which resulted in the peso rapidly losing its value with respect to the US currency over just a few months. 

Tôi không còn tin rằng các ngân hàng và tiền là cần thiết.
Xã hội sẽ tìm cách tồn tại mà không có họ, ông Alan Alan nói.
Anh ta thấy rằng các công dân địa phương ở nước anh ta không thể lấy tiền của họ ra khỏi ngân hàng để [truy cập tiết kiệm của họ] (http://www.bbc.co.uk/news/world-latin-america-15981406 "Argentine nhớ lại kinh tế
Khủng hoảng 10 năm, BBC "), và hàng dài đã hình thành bên ngoài các ngân hàng trên khắp Argentina khi mọi người rất cố gắng nắm giữ tiền của họ.
Vào tháng 1 năm 2002, chính phủ đã quyết định phá giá peso và [từ bỏ chốt cho đô la Mỹ] (https://en.wikipedia.org/wiki/convertable_plan "Kế hoạch chuyển đổi, Wikipedia"), dẫn đến PESO nhanh chóng
Mất giá trị của nó đối với tiền tệ của Hoa Kỳ chỉ trong vài tháng.

Alan explains that this was when his interest in blockchain and cryptocurrencies began. He despised corruption and wanted to find an alternative solution for the citizens of his country.

Alan giải thích rằng đây là khi sự quan tâm của anh ấy đối với blockchain và tiền điện tử bắt đầu.
Ông coi thường tham nhũng và muốn tìm một giải pháp thay thế cho công dân của đất nước ông.

Alan started to read more about Bitcoin, and researched the white paper by its creator, Satoshi Nakamoto. He was hooked, joined Argentina’s growing blockchain community, and the rest is history. 

Alan bắt đầu đọc thêm về Bitcoin và nghiên cứu về tờ giấy trắng bởi người tạo ra nó, Satoshi Nakamoto.
Anh ta bị cuốn hút, gia nhập cộng đồng blockchain đang phát triển của Argentina, và phần còn lại là lịch sử.

Since then, Alan focused his efforts on getting into the blockchain industry. Following his interest in computers, developed at an early age from the influence of his mother’s technology career as a bank IT professional, Alan studied at the Engineering University of Buenos Aires and became a software engineer.

Kể từ đó, Alan tập trung nỗ lực vào ngành công nghiệp blockchain.
Sau sự quan tâm của anh ấy đối với máy tính, được phát triển từ khi còn nhỏ từ ảnh hưởng của sự nghiệp công nghệ của mẹ anh ấy với tư cách là một chuyên gia CNTT ngân hàng, Alan học tại Đại học Kỹ thuật Buenos Aires và trở thành một kỹ sư phần mềm.

After graduation, Alan created Atix, which is a company he co-founded with three friends from university. They work on software development, and half the company are working in the area of blockchain. Alan decided to base his company at Bitcoin Embassy, a key meeting place for many of the leading minds in bitcoin development in the country.

Sau khi tốt nghiệp, Alan đã tạo ra Atix, một công ty mà anh đồng sáng lập với ba người bạn từ trường đại học.
Họ làm việc về phát triển phần mềm và một nửa công ty đang làm việc trong lĩnh vực blockchain.
Alan quyết định dựa trên công ty của mình tại Đại sứ quán Bitcoin, một nơi gặp gỡ quan trọng cho nhiều bộ óc hàng đầu trong phát triển Bitcoin ở nước này.

He is optimistic about the future of crypto in Argentina’s bustling blockchain community. "Our country has the ideal conditions for crypto development. We have highly skilled and passionate people looking to contribute to the industry. For example, our office is located in a building where about eight crypto companies have their space and meetups are held every week with interesting debates taking place," Alan said.

Anh ấy lạc quan về tương lai của Crypto trong cộng đồng blockchain nhộn nhịp của Argentina.
"Đất nước chúng ta có điều kiện lý tưởng để phát triển tiền điện tử. Chúng tôi có những người có kỹ năng và đam mê cao muốn đóng góp cho ngành công nghiệp. Ví dụ, văn phòng của chúng tôi nằm trong một tòa nhà nơi có khoảng tám công ty tiền điện tử có không gian và cuộc gặp gỡ của họ được tổ chức mỗi tuần
Các cuộc tranh luận thú vị diễn ra, "Alan nói.

It was at Bitcoin Embassy where Alan met Charles Hoskinson, the CEO of IOHK, and he was given the opportunity to work in Team Grothendieck on Ethereum Classic development. They built and recently launched the beta version of an Ethereum Classic client, [Mantis](https://bitcoinmagazine.com/articles/ethereum-classic-forges-its-own-identity-new-mantis-client/ "Ethereum Classic forges its own identity with new Mantis client, Bitcoin Magazine"), in the functional programming language Scala.

Đó là tại Đại sứ quán Bitcoin, nơi Alan gặp Charles Hoskinson, Giám đốc điều hành của IOHK, và ông đã có cơ hội làm việc trong Team Grothendieck về Ethereum Classic Development.
Họ đã xây dựng và gần đây đã ra mắt phiên bản beta của một ứng dụng khách Ethereum Classic, [Mantis] (https://bitcoinmagazine.com/articles/ethereum-lassic-forges-its-own-identity-new-mantis-client/ "Ethereum Classic Forge Forge Forge Forge Forge Forge Forge Forge Forge Forgees ForGes
Bản sắc riêng của nó với New Mantis Client, Tạp chí Bitcoin "), trong ngôn ngữ lập trình chức năng Scala.

On the programming language of choice for ETC development, Alan is a fan of functional programming because it has allowed him to create less verbose, more readable and secure code. For him, Scala is a solid and fun language to work with. It has a lot of tools and useful libraries, for example Akka). Last but not least, it runs on a Java virtual machine so he is able to support different platforms (see the [Mantis documentation](http://mantis.readthedocs.io/en/latest/ "Mantis documentation, Mantis wiki") for instructions) without any extra effort.

Về ngôn ngữ lập trình được lựa chọn để phát triển ETC, Alan là một fan hâm mộ của lập trình chức năng vì nó đã cho phép anh ta tạo ra các mã ít dài hơn, dễ đọc hơn và an toàn hơn.
Đối với anh, Scala là một ngôn ngữ vững chắc và thú vị để làm việc.
Nó có rất nhiều công cụ và thư viện hữu ích, ví dụ Akka).
Cuối cùng nhưng không kém phần quan trọng, nó chạy trên máy ảo Java để anh ta có thể hỗ trợ các nền tảng khác nhau (xem [tài liệu Mantis] (http://mantis.readthedocs.io/en/latest/ "Tài liệu Mantis, Mantis Wiki")
cho hướng dẫn) mà không cần thêm nỗ lực.

![Alan Verbner](img/2017-09-21-iohk-spotlight-alan-verbner.010.jpeg)

Being a remote team based in Argentina, and working with other distributed teams in IOHK globally, has been less complicated than most would expect. Alan and the team ensures that they have the discipline and precision to make everything work like a Swiss watch. This includes two main goals, one is communicating successfully with daily standup meetings to discuss tasks and key blockers, and the second is a strong and well defined code review process to catch bugs and establish a consistent coding style.

Trở thành một nhóm từ xa có trụ sở tại Argentina và làm việc với các nhóm phân tán khác ở IOHK trên toàn cầu, đã ít phức tạp hơn hầu hết mong đợi.
Alan và nhóm đảm bảo rằng họ có kỷ luật và chính xác để làm cho mọi thứ hoạt động như một chiếc đồng hồ Thụy Sĩ.
Điều này bao gồm hai mục tiêu chính, một là giao tiếp thành công với các cuộc họp đứng hàng ngày để thảo luận về các nhiệm vụ và trình chặn chính, và thứ hai là một quy trình xem xét mã mạnh mẽ và được xác định rõ ràng để bắt lỗi và thiết lập phong cách mã hóa nhất quán.

As someone who lived through pivotal moments in a country where corruption and poverty have been two big themes in society, Alan envisions a future where blockchain can address these issues. He would love to see a world where blockchain technology is being applied to areas such as voting transparency, microlending and fair access to financial services, immutable government data release, and trusted financial systems for all. “We are yet to see the various use cases blockchain technology can contribute to. I'm confident that the ecosystem will mature and become part of our daily life,” Alan said.

Là một người sống qua những khoảnh khắc then chốt ở một quốc gia nơi tham nhũng và nghèo đói là hai chủ đề lớn trong xã hội, Alan hình dung một tương lai nơi blockchain có thể giải quyết những vấn đề này.
Ông rất thích nhìn thấy một thế giới nơi công nghệ blockchain được áp dụng cho các lĩnh vực như tính minh bạch bỏ phiếu, vi mô và truy cập công bằng vào các dịch vụ tài chính, phát hành dữ liệu chính phủ bất biến và các hệ thống tài chính đáng tin cậy cho tất cả mọi người.
Chúng tôi vẫn chưa thấy các trường hợp sử dụng khác nhau, công nghệ blockchain có thể đóng góp.
Tôi tự tin rằng hệ sinh thái sẽ trưởng thành và trở thành một phần trong cuộc sống hàng ngày của chúng ta, ông Alan Alan nói.

To find out more about Alan and our other talented Team Grothendieck members working on the ETC development of [Mantis](tmp//en/blog/mantis-ethereum-classic-beta-release/ "Mantis – Ethereum Classic beta release, IOHK blog"), check out our [IOHK team page](tmp//en/team/ "Team profiles, IOHK").

Để tìm hiểu thêm về Alan và các thành viên nhóm tài năng khác của chúng tôi làm việc về sự phát triển ETC của [Mantis] (TMP // EN/Blog/Mantis-Ethereum-Classic-Beta-RELEASE/"Mantis-Ethereum Classic Beta Release, IOHK Blog
"), hãy xem [trang nhóm IOHK của chúng tôi] (TMP // EN/TEAM/" Hồ sơ nhóm, IOHK ").

## **Attachments**

## ** tệp đính kèm **

![](img/2017-09-21-iohk-spotlight-alan-verbner.004.png)[ IOHK Spotlight – Alan Verbner - Input Output](https://ucarecdn.com/863740a3-5013-4ca9-9971-3bb70e5b5feb/-/inline/yes/ "IOHK Spotlight – Alan Verbner - Input Output")

