# Cardano prepares to launch
### **Development during the past weeks has strengthened the network**
![](img/2017-09-01-cardano-prepares-to-launch.002.png) 1 September 2017![](img/2017-09-01-cardano-prepares-to-launch.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2017-09-01-cardano-prepares-to-launch.003.png) 4 mins read

![](img/2017-09-01-cardano-prepares-to-launch.004.png)[ Cardano prepares to launch - Input Output](https://ucarecdn.com/5daa0bd0-c0e4-48fe-82b4-aaa703cc40cb/-/inline/yes/ "Cardano prepares to launch - Input Output")

![Charles Hoskinson](img/2017-09-01-cardano-prepares-to-launch.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2017-09-01-cardano-prepares-to-launch.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2017-09-01-cardano-prepares-to-launch.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2017-09-01-cardano-prepares-to-launch.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

Developing Cardano is no small feat. There is no other project that has ever been built to these parameters, combining peer reviewed cryptographic research with an implementation in highly secure Haskell code. This is not the copy and paste code seen in so many other blockchains. Instead, Cardano was designed with input from a large global team including leading experts and professors in the fields of computer programming languages, network design and cryptography. We are extremely proud of Cardano, which required a months-long meticulous and painstaking development process by our talented engineers. With that in mind, Iâ€™m pleased to report that we are finally reaching the end of development. The target launch date is September 29 and this is based on all current, known information. We had originally planned to launch by the end of August, so there have been a few additional weeks of development. The extra time was partly due to our team uncovering a few unexpected bugs which delayed testing of the overall network. It also took longer to set up Cardanoâ€™s internal test network than expected. But during those extra weeks, we have also been able to make enhancements to dramatically improve Cardanoâ€™s performance. â€¨â€¨One of the things engineers did to improve Cardanoâ€™s performance was to change the format of messages that are sent between nodes on the network. We upgraded our binary serialisation format from a custom version to one based on an open, common standard that means third parties, such as exchanges, will find it easier to build their own nodes, and our system becomes more transparent.

Phát triển Cardano là một kỳ công không nhỏ. Không có dự án nào khác từng được xây dựng cho các tham số này, kết hợp nghiên cứu mật mã được đánh giá ngang hàng với việc triển khai trong mã Haskell an toàn cao. Đây không phải là mã bản sao và mã dán được thấy trong rất nhiều blockchain khác. Thay vào đó, Cardano được thiết kế với đầu vào từ một nhóm lớn toàn cầu bao gồm các chuyên gia và giáo sư hàng đầu trong các lĩnh vực ngôn ngữ lập trình máy tính, thiết kế mạng và mật mã. Chúng tôi vô cùng tự hào về Cardano, trong đó đòi hỏi một quá trình phát triển tỉ mỉ và siêng năng kéo dài hàng tháng bởi các kỹ sư tài năng của chúng tôi. Với ý nghĩ đó, tôi rất vui khi báo cáo rằng cuối cùng chúng ta cũng đã kết thúc sự phát triển. Ngày ra mắt mục tiêu là ngày 29 tháng 9 và điều này dựa trên tất cả các thông tin hiện tại, đã biết. Ban đầu chúng tôi đã lên kế hoạch ra mắt vào cuối tháng 8, vì vậy đã có thêm một vài tuần phát triển. Thời gian thêm một phần là do nhóm của chúng tôi phát hiện ra một vài lỗi bất ngờ làm trì hoãn việc thử nghiệm mạng tổng thể. Cũng mất nhiều thời gian hơn để thiết lập mạng thử nghiệm nội bộ của Cardano so với dự kiến. Nhưng trong những tuần thêm đó, chúng tôi cũng đã có thể thực hiện các cải tiến để cải thiện đáng kể hiệu suất của Cardano. "Một trong những điều mà các kỹ sư đã làm để cải thiện hiệu suất của Cardano là thay đổi định dạng của các tin nhắn được gửi giữa các nút trên mạng. Chúng tôi đã nâng cấp định dạng tuần tự hóa nhị phân từ phiên bản tùy chỉnh lên một phiên bản tùy chỉnh dựa trên một tiêu chuẩn phổ biến, có nghĩa là các bên thứ ba, chẳng hạn như trao đổi, sẽ thấy dễ dàng hơn để xây dựng các nút của riêng họ và hệ thống của chúng tôi trở nên minh bạch hơn.

In recent weeks, engineers also made improvements to the network layer, rewriting code to make it run faster. The system is more stable under load and the number of transactions per second is higher. We are further improving the transaction speeds of the network and in the coming months after release will demonstrate our results. These two improvements took a few weeks to fully implement and test.

Trong những tuần gần đây, các kỹ sư cũng đã cải thiện lớp mạng, viết lại mã để làm cho nó chạy nhanh hơn.
Hệ thống ổn định hơn theo tải và số lượng giao dịch mỗi giây cao hơn.
Chúng tôi đang cải thiện hơn nữa tốc độ giao dịch của mạng và trong những tháng tới sau khi phát hành sẽ chứng minh kết quả của chúng tôi.
Hai cải tiến này đã mất một vài tuần để thực hiện và thử nghiệm đầy đủ.

We have now added additional protection against DDoS, or distributed denial of service, attacks. The networkâ€™s core nodes have been placed behind firewalls, so they are not accessible from the public internet. This gives us some protection against this type of attack, because potential attackers canâ€™t reach Cardanoâ€™s core nodes. To do this, we surrounded the core nodes with proxies, called relay nodes, which by contrast are visible to the internet. As their name suggests, these nodes relay messages to the core nodes. Even if there was an attack, the blockchain would be protected because the core nodes are not directly exposed.

Bây giờ chúng tôi đã thêm bảo vệ bổ sung chống lại DDO, hoặc từ chối dịch vụ, các cuộc tấn công.
Các nút cốt lõi của mạng đã được đặt phía sau tường lửa, vì vậy chúng không thể truy cập được từ Internet công cộng.
Điều này cho chúng tôi một số bảo vệ chống lại loại tấn công này, bởi vì những kẻ tấn công tiềm năng không thể đạt được các nút cốt lõi của Cardano.
Để làm điều này, chúng tôi đã bao quanh các nút cốt lõi với các proxy, được gọi là các nút tiếp sức, ngược lại có thể nhìn thấy trên internet.
Như tên của chúng cho thấy, các nút này chuyển tiếp các thông điệp đến các nút cốt lõi.
Ngay cả khi có một cuộc tấn công, blockchain sẽ được bảo vệ vì các nút cốt lõi không được phơi sáng trực tiếp.

We have also introduced improvements to Cardanoâ€™s [delegation scheme](https://ucarecdn.com/b5e9a111-93dd-42d8-a873-a2aa5616e78e/-/inline/yes/ "Delegation and State Locking in Cardano, IOHK.io"), which keeps the network running even if its end users are not online, to strengthen it against attacks to its signature scheme. This provides an element of future-proofing by preventing attackers from stealing funds if new attacks against its signature scheme are discovered in the future. Cardano is based on proof of stake, so our solution is that Ada holders will have separate public-private keys for their coins and for their stake and the public key for the coins will not be published. This is the first step of a long term strategy to harden Ouroboros against quantum computers, a process which will require new research.

Chúng tôi cũng đã giới thiệu các cải tiến cho [Chương trình ủy quyền] của Cardano (https://ucarecdn.com/b5e9a111-93dd-42d8-a873-a2aa5616e78e/
"), điều này giữ cho mạng chạy ngay cả khi người dùng cuối của nó không trực tuyến, để tăng cường nó chống lại các cuộc tấn công vào sơ đồ chữ ký của nó.
Điều này cung cấp một yếu tố của việc chứng minh trong tương lai bằng cách ngăn chặn những kẻ tấn công ăn cắp tiền nếu các cuộc tấn công mới vào kế hoạch chữ ký của nó được phát hiện trong tương lai.
Cardano dựa trên bằng chứng về cổ phần, vì vậy giải pháp của chúng tôi là chủ sở hữu ADA sẽ có chìa khóa công cộng riêng cho tiền của họ và cho cổ phần của họ và khóa công khai cho các đồng tiền sẽ không được công bố.
Đây là bước đầu tiên của một chiến lược dài hạn để làm cứng ouroboros đối với máy tính lượng tử, một quá trình sẽ yêu cầu nghiên cứu mới.

While all this work was going on during the past few weeks, the team has done a lot more testing, which is always good. We found bugs, which we fixed, and the testing gave us a better assurance of quality.

Trong khi tất cả các công việc này đã diễn ra trong vài tuần qua, nhóm đã thực hiện nhiều thử nghiệm hơn, điều này luôn luôn tốt.
Chúng tôi đã tìm thấy các lỗi, mà chúng tôi đã sửa và thử nghiệm đã cho chúng tôi sự đảm bảo tốt hơn về chất lượng.

Recently, IOHK research â€“ our [Ouroboros](https://bitcoinmagazine.com/articles/op-ed-cryptographic-design-perspective-blockchains-bitcoin-ouroboros/ "Ouroboros in Bitcoin Magazine") and [SCRAPE](tmp//en/blog/a-solution-for-scalable-randomness/ "A solution for scalable randomness, IOHK.io") papers â€“ were also accepted to two major conferences, [ACNS](https://cy2sec.comm.eng.osaka-u.ac.jp/acns2017/index.html "ACNS, 2017") in Japan, and [Crypto 2017](https://www.forbes.com/sites/amycastor/2017/08/23/at-crypto-2017-blockchain-presentations-focus-on-proofs-not-concepts/#37ab296b7b70 "At Major Crypto Conference, Blockchain Projects Tighten Security With Math, Forbes") in the US, and we were very proud our work has been recognised by the academic community and has been peer reviewed. A major exchange that has agreed to list Ada at launch has also been integrating with Cardanoâ€™s network. As a result, we have been adding some recommended features and minor changes.

Gần đây, nghiên cứu của IOHK-[OuroBoros] của chúng tôi (https://bitcoinmagazine.com/articles/op-ed-cryptouss-design-perspective-blockchains-bitcoin-urooboros/"ouroboros trên tạp chí bitcoin")
TMP // EN/Blog/A-Solution-for-Scalable-Randomness/"Một giải pháp cho sự ngẫu nhiên có thể mở rộng, iohk.io")
.Comm.eng.osaka-u.ac.jp/acns2017/index.html "ACNS, 2017") tại Nhật Bản và [Crypto 2017] (https://www.forbes.com/sites/amycastor/2017/08
.
Công việc của chúng tôi đã được cộng đồng học thuật công nhận và đã được xem xét ngang hàng.
Một trao đổi lớn đã đồng ý liệt kê ADA khi ra mắt cũng đã tích hợp với mạng của Cardano.
Do đó, chúng tôi đã thêm một số tính năng được đề xuất và thay đổi nhỏ.

All this development work has meant that Cardanoâ€™s code has changed, sometimes significantly. That means everything has to be retested. You canâ€™t simply update code and assume that everything will be fine. The process of releasing a new version of the software takes a couple of weeks because that is how long it takes to test, and fix bugs and carry out tasks such as preparing new installers.

Tất cả các công việc phát triển này có nghĩa là mã của Cardano đã thay đổi, đôi khi đáng kể.
Điều đó có nghĩa là mọi thứ phải được kiểm tra lại.
Bạn không thể cập nhật mã và cho rằng mọi thứ sẽ ổn.
Quá trình phát hành phiên bản mới của phần mềm mất vài tuần vì đó là thời gian để kiểm tra và sửa lỗi và thực hiện các tác vụ như chuẩn bị trình cài đặt mới.

Development has been a lengthy process but we are now very pleased to share a detailed plan showing the launch countdown. Cardano is a unique and very special product and we look forward to passing it into your hands.

Phát triển đã là một quá trình dài nhưng chúng tôi hiện rất vui khi chia sẻ một kế hoạch chi tiết cho thấy việc đếm ngược ra mắt.
Cardano là một sản phẩm độc đáo và rất đặc biệt và chúng tôi mong muốn đưa nó vào tay bạn.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-09-01-cardano-prepares-to-launch.004.png)[ Cardano prepares to launch - Input Output](https://ucarecdn.com/5daa0bd0-c0e4-48fe-82b4-aaa703cc40cb/-/inline/yes/ "Cardano prepares to launch - Input Output")

