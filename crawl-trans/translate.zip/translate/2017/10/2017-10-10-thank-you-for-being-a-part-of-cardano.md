# Thank you all for being a part of Cardano
![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.002.png) 10 October 2017![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.003.png) 3 mins read

![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.004.png)[ Thank you all for being a part of Cardano - Input Output](https://ucarecdn.com/e405440a-25bd-411d-94c5-f0911f478d43/-/inline/yes/ "Thank you all for being a part of Cardano - Input Output")

![Charles Hoskinson](img/2017-10-10-thank-you-for-being-a-part-of-cardano.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Thank you all for being a part of Cardano](img/2017-10-10-thank-you-for-being-a-part-of-cardano.009.jpeg)

Over two years ago IOHK joined a movement to build a truly unique collection of technology that married the best engineering principles with the dreams of scientists in far removed universities. It was a tremendously ambitious and complex project to grasp. Tens of millions of dollars would need to be gathered, long term roadmaps developed, research institutions established and properly managed as well as numerous entities staffed. In short, it was an insane project to attempt. Yet we attempted it. 

Hơn hai năm trước, IOHK đã tham gia một phong trào xây dựng một bộ sưu tập công nghệ thực sự độc đáo kết hôn với các nguyên tắc kỹ thuật tốt nhất với giấc mơ của các nhà khoa học trong các trường đại học xa xôi.
Đó là một dự án rất tham vọng và phức tạp để nắm bắt.
Hàng chục triệu đô la sẽ cần được thu thập, các lộ trình dài hạn được phát triển, các tổ chức nghiên cứu được thành lập và quản lý đúng cách cũng như nhiều thực thể nhân viên.
Nói tóm lại, đó là một dự án điên rồ để cố gắng.
Tuy nhiên, chúng tôi đã cố gắng.

Now there are well over 100 people working full time on the [Cardano project](https://www.cardanohub.org/ "Cardano hub"), three research centers drafting peer reviewed papers, a legion of haskell developers pushing the limits of the language and three well capitalized entities with a mandate and funding to build Cardano until 2020 - IOHK, the [Cardano Foundation](https://cardanofoundation.org/ "Cardano Foundation") and [Emurgo](http://emurgo.io/ "Emurgo").

Bây giờ có hơn 100 người làm việc toàn thời gian trong [Dự án Cardano] (https://www.cardanohub.org/ "Cardano Hub"), ba trung tâm nghiên cứu soạn thảo các bài báo đánh giá ngang hàng, một quân đoàn của các nhà phát triển Haskell đẩy giới hạn giới hạn của giới hạn giới hạn của giới hạn giới hạn của
Ngôn ngữ và ba thực thể được viết hoa tốt với một nhiệm vụ và tài trợ để xây dựng Cardano cho đến năm 2020 - IOHK, [Quỹ Cardano] (https://cardanofoundation.org/ "Quỹ Cardano") và [Emurgo] (http: // eMurgo.
io/ "Emurgo").

Itâ€™s both unbelievable and humbling to see how far we have gone in such a short time. Cardano is literally evolving computer science from semantics based compilation to entirely new cryptographic protocols to formal verification of code. Cardano also managed to build an amazing community more than 10,000 strong in a slow and methodical way. 

Cả hai đều không thể tin được và khiêm tốn khi thấy chúng ta đã đi được bao xa trong một thời gian ngắn như vậy.
Cardano theo nghĩa đen là phát triển khoa học máy tính từ tổng hợp dựa trên ngữ nghĩa sang các giao thức mật mã hoàn toàn mới để xác minh chính thức mã.
Cardano cũng quản lý để xây dựng một cộng đồng tuyệt vời hơn 10.000 người mạnh mẽ theo cách chậm chạp và có phương pháp.

We [launched the mainnet](https://bitcoinmagazine.com/articles/iohk-launches-cardano-blockchain-ada-now-trading-bittrex/ "IOHK launches Cardano blockchain Ada now trading on Bittrex") recently with very little fanfare and marketing. Rather it seems to be a small stop on a much longer and more elegant journey. While itâ€™s certainly a challenging sojourn, Iâ€™m confident that we have come to know it and have developed the endurance to survive. 

Chúng tôi [ra mắt Mainnet] (https://bitcoinmagazine.com/articles/iohk-launches-cardano-blockchain-ada-now-trading-bittrex/ "iohk ra mắt cardano blockchain ada hiện đang giao dịch trên Bittrex")
và tiếp thị.
Thay vào đó, nó dường như là một điểm dừng nhỏ trên một hành trình dài hơn và thanh lịch hơn nhiều.
Mặc dù đó chắc chắn là một sự thách thức, tôi tự tin rằng chúng ta đã biết nó và đã phát triển sức chịu đựng để tồn tại.

In reflection, Iâ€™ve been to over 30 countries since we started our journey. Iâ€™ve met thousands of people ranging from the bizarre to the saintly with a few notorious ones littered in between. The most remarkable thing so far has been experiencing the near unlimited excitement and youth regardless of where I went. 

Trong suy ngẫm, tôi đã đến hơn 30 quốc gia kể từ khi chúng tôi bắt đầu hành trình.
Tôi đã gặp hàng ngàn người, từ kỳ quái đến thánh với một vài người khét tiếng ở giữa.
Điều đáng chú ý nhất cho đến nay đã trải qua sự phấn khích gần như không giới hạn và tuổi trẻ bất kể tôi đã đi đâu.

The world really does seem like itâ€™s ready for a new financial system. Itâ€™s hard to say if Cardano can get us there, yet we arenâ€™t alone any more. Thereâ€™s now an army of some of the best throughout the world on this journey. Leaderless, inspired and brilliant, itâ€™s an honor to be among them. I never believed I could be part of something like this movement. 

Thế giới thực sự có vẻ như đã sẵn sàng cho một hệ thống tài chính mới.
Thật khó để nói nếu Cardano có thể đưa chúng ta đến đó, nhưng chúng ta không còn một mình nữa.
Bây giờ có một đội quân của một số người giỏi nhất trên toàn thế giới trên hành trình này.
Lãnh đạo, truyền cảm hứng và xuất sắc, đó là một vinh dự khi nằm trong số đó.
Tôi không bao giờ tin rằng tôi có thể là một phần của một cái gì đó như phong trào này.

Thank you all for being part of Cardano. Thank you for your patience when we have fallen. Thank you for your support and kind words. Thank you for your dreams. Now letâ€™s get back to the road ahead. Iâ€™ve come to know this place for the first time.

Cảm ơn tất cả các bạn đã là một phần của Cardano.
Cảm ơn bạn vì sự kiên nhẫn của bạn khi chúng tôi đã sụp đổ.
Cảm ơn bạn đã hỗ trợ và những lời tốt đẹp của bạn.
Cảm ơn bạn vì ước mơ của bạn.
Bây giờ hãy để trở lại con đường phía trước.
Tôi đã đến để biết nơi này lần đầu tiên.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-10-10-thank-you-for-being-a-part-of-cardano.004.png)[ Thank you all for being a part of Cardano - Input Output](https://ucarecdn.com/e405440a-25bd-411d-94c5-f0911f478d43/-/inline/yes/ "Thank you all for being a part of Cardano - Input Output")

