# Designing a new virtual machine and universal language framework
### **Guest blog from Professor Rosu explains the work being done in a partnership between Runtime Verification and IOHK**
![](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.002.png) 26 October 2017![](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.002.png)[ Grigore Rosu](tmp//en/blog/authors/grigore-rosu/page-1/)![](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.003.png) 8 mins read

![](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.004.png)[ Designing a new virtual machine and universal language framework - Input Output](https://ucarecdn.com/45a7832c-8350-4075-bafc-d4e6b7f002bd/-/inline/yes/ "Designing a new virtual machine and universal language framework - Input Output")

![Grigore Rosu](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.005.png)[](tmp//en/blog/authors/grigore-rosu/page-1/)
### [**Grigore Rosu**](tmp//en/blog/authors/grigore-rosu/page-1/)
President/CEO Runtime Verification

![Designing a new virtual machine and universal language framework](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.006.jpeg)

The IELE and K team Mathematical rigor and good design of programming languages and underlying virtual machines are critical for the success of blockchain technologies and applications. Indeed, decades of accumulated evidence show that formal techniques and their early adoption in the design of computing systems can significantly increase the safety, security and dependability of such systems. Moreover, when paired with good user interfaces that hide the mathematical complexity, such techniques can also increase the effectiveness, elegance and quality of code development. A good example is the recent success of functional programming languages and of automated theorem provers or constraint solvers.

Sự nghiêm ngặt toán học của IELE và K TEAM và thiết kế tốt các ngôn ngữ lập trình và các máy ảo cơ bản là rất quan trọng cho sự thành công của các công nghệ và ứng dụng blockchain.
Thật vậy, nhiều thập kỷ bằng chứng tích lũy cho thấy các kỹ thuật chính thức và việc áp dụng sớm của họ trong việc thiết kế các hệ thống điện toán có thể làm tăng đáng kể sự an toàn, bảo mật và độ tin cậy của các hệ thống đó.
Hơn nữa, khi được ghép nối với các giao diện người dùng tốt che giấu độ phức tạp toán học, các kỹ thuật như vậy cũng có thể làm tăng hiệu quả, sự thanh lịch và chất lượng phát triển mã.
Một ví dụ điển hình là sự thành công gần đây của các ngôn ngữ lập trình chức năng và các provers hoặc giải quyết định lý tự động.

[Runtime Verification](https://runtimeverification.com/ "Runtime Verification Website"), a University of Illinois start-up founded by computer science Professor Grigore Rosu, has been recently awarded a research and development contract by [IOHK](https://iohk.io "IOHK Website") to design a next generation virtual machine and a universal language framework to be used as core infrastructure for future blockchain technologies. The formal analysis and verification technology employed in this project was initiated by Prof. Rosu and his collaborators back in 2001, when he was a NASA scientist, and has been improved over more than 15 years of research and development both in his [Formal System Laboratory (FSL)](http://fsl.cs.illinois.edu/ "Formal System Laboratory, University of Illinois") at the University of Illinois at Urbana-Champaign and at Runtime Verification, with generous funding of more than $10M from organisations including NSF, NASA, DARPA, NSA, Boeing, Microsoft, Toyota, and Denso. It is about time that aircraft grade, software analysis technology used for mission critical software gets deployed to smart contracts, the blockchain and cryptocurrencies. The project will be executed by a team of Runtime Verification experts led by Prof Rosu, who will work closely with students at the University of Illinois â€“ also funded by IOHK â€“ and with the IOHK research and development team.

. : //iohk.io "Trang web IOHK") để thiết kế một máy ảo thế hệ tiếp theo và khung ngôn ngữ phổ quát được sử dụng làm cơ sở hạ tầng cốt lõi cho các công nghệ blockchain trong tương lai. Công nghệ phân tích và xác minh chính thức được sử dụng trong dự án này được bắt đầu bởi Giáo sư Rosu và các cộng tác viên của ông vào năm 2001, khi ông là một nhà khoa học của NASA, và đã được cải thiện trong hơn 15 năm nghiên cứu và phát triển cả trong phòng thí nghiệm hệ thống chính thức của ông (FSL)] (http://fsl.cs.illinois.edu/ "Phòng thí nghiệm hệ thống chính thức, Đại học Illinois") Các tổ chức bao gồm NSF, NASA, DARPA, NSA, Boeing, Microsoft, Toyota và Denso. Đó là khoảng thời gian mà lớp máy bay, công nghệ phân tích phần mềm được sử dụng cho phần mềm quan trọng nhiệm vụ được triển khai cho các hợp đồng thông minh, blockchain và tiền điện tử. Dự án sẽ được thực hiện bởi một nhóm các chuyên gia xác minh thời gian chạy do Giáo sư Rosu, người sẽ làm việc chặt chẽ với các sinh viên tại Đại học Illinois - cũng được tài trợ bởi IOHK - và với nhóm nghiên cứu và phát triển của IOHK.

## **IELE â€“ A Register-Based Virtual Machine for the Blockchain**

## ** IELE-Một máy ảo dựa trên đăng ký cho blockchain **

Based on learnings from defining [KEVM](https://github.com/kframework/evm-semantics "K Semantics of the Ethereum Virtual Machine (EVM)"), our semantics of EVM in [K](http://www.kframework.org/ "K Framework"), we will design and define a new VM, which we call IELE (after the [Mythological Iele](https://en.wikipedia.org/wiki/Iele "Iele, Wikipedia")). Unlike the EVM, which is a stack-based machine, IELE will be a register-based machine, like [LLVM](http://llvm.org/ "The LLVM Compiler Infrastructure"). It will have an unbounded number of registers and will also support unbounded integers. There are some tricky but manageable aspects with respect to gas calculation, a critical part of the design.

Dựa trên các nghiên cứu từ việc xác định [kevm] (https://github.com/kframework/evm-semantics "K S hãy ngữ nghĩa của máy ảo Ethereum (EVM)"), ngữ nghĩa của chúng tôi về EVM trong [K] (http: // www
.Kframework.org/"K Framework"), chúng tôi sẽ thiết kế và xác định một VM mới, mà chúng tôi gọi là IELE (sau [iele thần thoại] (https://en.wikipedia.org/wiki/IELE "IELE, WIKIPEDIA"
)).
Không giống như EVM, là một máy dựa trên ngăn xếp, IELE sẽ là một máy dựa trên đăng ký, như [LLVM] (http://llvm.org/ "Cơ sở hạ tầng trình biên dịch LLVM").
Nó sẽ có một số lượng thanh ghi không giới hạn và cũng sẽ hỗ trợ các số nguyên không giới hạn.
Có một số khía cạnh khó khăn nhưng có thể quản lý đối với tính toán khí, một phần quan trọng của thiết kế.

Here are the forces that will drive the design of IELE:

Dưới đây là các lực lượng sẽ thúc đẩy thiết kế của IELE:

1. To serve as a uniform, lower-level platform for translating and executing smart contracts from higher-level languages, which can also interact with each other by means of an ABI (Application Binary Interface). The ABI will be a core element of IELE, and not just a convention on top of it. Also, unbounded integers and an unbounded number of registers will make compilation from higher-level languages more straightforward and elegant and, looking at the success of LLVM, more efficient in the long term. Indeed, many of the LLVM optimizations are expected to carry over. For that reason, IELE will follow the design choices and representation of LLVM as much as possible. The team includes an advanced PhD student from Vikram Adveâ€™s lab at the University of Illinois, where LLVM was created, and who is an expert in LLVM.

1. Để phục vụ như một nền tảng cấp thấp, thống nhất để dịch và thực hiện các hợp đồng thông minh từ các ngôn ngữ cấp cao hơn, cũng có thể tương tác với nhau bằng ABI (Giao diện nhị phân ứng dụng).
ABI sẽ là một yếu tố cốt lõi của IELE, và không chỉ là một quy ước trên đỉnh của nó.
Ngoài ra, các số nguyên không giới hạn và số lượng thanh ghi không giới hạn sẽ làm cho việc tổng hợp từ các ngôn ngữ cấp cao hơn đơn giản và thanh lịch hơn và, nhìn vào sự thành công của LLVM, hiệu quả hơn trong dài hạn.
Thật vậy, nhiều tối ưu hóa LLVM dự kiến sẽ thực hiện.
Vì lý do đó, IELE sẽ tuân theo các lựa chọn thiết kế và đại diện của LLVM càng nhiều càng tốt.
Nhóm nghiên cứu bao gồm một sinh viên tiến sĩ tiên tiến của phòng thí nghiệm của Vikram tại Đại học Illinois, nơi LLVM được thành lập, và là một chuyên gia về LLVM.

1. To provide a uniform gas model, across all languages. The general design philosophy of gas calculation in IELE is â€œno limitations, but pay for what you consumeâ€. For example, the more registers a IELE program uses, the more gas it consumes. Or the larger the numbers computed at runtime, the more gas it consumes. The more memory it uses, in terms of both locations and size of data stored at locations, the more gas it consumes. And so on. 

1. Để cung cấp một mô hình khí đồng đều, trên tất cả các ngôn ngữ.
Triết lý thiết kế chung về tính toán khí trong IELE là "Không có giới hạn, nhưng trả tiền cho những gì bạn tiêu thụ".
Ví dụ, càng nhiều đăng ký chương trình IELE sử dụng, nó càng tiêu thụ nhiều khí.
Hoặc các số lớn hơn được tính toán trong thời gian chạy, nó càng tiêu thụ nhiều khí.
Càng sử dụng nhiều bộ nhớ, về cả hai vị trí và kích thước của dữ liệu được lưu trữ tại các vị trí, nó càng tiêu thụ nhiều khí.
Và như thế.

1. To make it easier to write secure smart contracts. This includes writing requirements specifications that smart contracts must obey as well as making it easier to develop automated techniques that mathematically verify/prove smart contracts correct wrt to such specifications. For example, pushing a possibly computed number on the stack and then jumping to it regarded as an address makes verification hard, and thus security weaker, with current smart contract paradigms. We will have actual labels in IELE, like in LLVM, and structured jumps to those labels. Also, avoiding the use of a bounded stack and not having to worry about stack or arithmetic overflow will make specification and verification of smart contracts significantly easier.

1. Để làm cho việc viết các hợp đồng thông minh an toàn dễ dàng hơn.
Điều này bao gồm các thông số kỹ thuật yêu cầu viết rằng các hợp đồng thông minh phải tuân theo cũng như giúp việc phát triển các kỹ thuật tự động dễ dàng hơn để xác minh/chứng minh hợp đồng thông minh chính xác với các thông số kỹ thuật đó.
Ví dụ, đẩy một số có thể tính toán trên ngăn xếp và sau đó nhảy vào nó được coi là một địa chỉ làm cho xác minh khó khăn, và do đó bảo mật yếu hơn, với các mô hình hợp đồng thông minh hiện tại.
Chúng tôi sẽ có các nhãn thực tế trong IELE, như trong LLVM và có cấu trúc nhảy vào các nhãn đó.
Ngoài ra, tránh việc sử dụng một ngăn xếp bị ràng buộc và không phải lo lắng về Stack hoặc Overmetic Overflow sẽ làm cho thông số kỹ thuật và xác minh các hợp đồng thông minh dễ dàng hơn đáng kể.

Like [KEVM](https://github.com/kframework/evm-semantics "K Semantics of the Ethereum Virtual Machine (EVM)"), the formal semantics of EVM that we previously defined, validated and evaluated using the [K framework](https://coinjournal.net/kevm-wins-ic3-ethereum-crypto-boot-camp-2017-competition/ "KEVM Wins IC3-Ethereum Crypto Boot Camp 2017 Competition, Coin Journal"), the design of IELE will also be done in a semantics-based style, using K. Together with a fast (LLVM-based) execution backend for K, it is expected that the interpreter obtained automatically from the semantics of IELE will be sufficiently efficient to serve as a reference implementation of IELE.

Như [kevm] (https://github.com/kframework/evm-semantics "K ngữ nghĩa của máy ảo Ethereum (EVM)"), ngữ nghĩa chính thức của EVM mà trước đây chúng tôi đã xác định, xác thực và đánh giá
] (https://coinjournal.net/kevm-wins-ic3-ethereum-crypto-boot-camp-2017-competition/ "KEVM thắng IC3-Ethereum Crypto Boot Boot 2017 cạnh tranh, Tạp chí Coin")
Cũng được thực hiện theo phong cách dựa trên ngữ nghĩa, sử dụng K. cùng với một phụ trợ thực thi nhanh (dựa trên LLVM) cho K, người ta hy vọng rằng thông dịch viên có được tự động từ ngữ nghĩa của IELE sẽ đủ hiệu quả để phục vụ như một triển khai tham chiếu
của iele.

## **K as a Universal Language for the Blockchain**

## ** k như một ngôn ngữ phổ quát cho blockchain **

Besides EVM, several languages have been given a complete formal semantics in K, including C, Java, and JavaScript. Several others will be given K semantics as part of this project, including IELE itself, Solidity and Plutus. We want to allow all these languages, and possibly more as they are given K semantics, to be used for writing smart contracts. For that, we need to enhance the capabilities and implementation of the K platform itself, which will increase the practicality of all new and existing K semantics. We will implement several performance improvements not yet taken beyond proofs of concept, and develop production-quality implementations of analysis features such as the K symbolic execution engine, the semantics-based compiler (SBC), and the program verifier, which currently have only prototype-quality implementations in the academic K project.

Bên cạnh EVM, một số ngôn ngữ đã được cung cấp một ngữ nghĩa chính thức hoàn chỉnh trong K, bao gồm C, Java và JavaScript.
Một số người khác sẽ được cung cấp K ngữ nghĩa như một phần của dự án này, bao gồm cả IELE, Solility và Plutus.
Chúng tôi muốn cho phép tất cả các ngôn ngữ này và có thể nhiều hơn khi chúng được cung cấp K ngữ nghĩa, được sử dụng để viết hợp đồng thông minh.
Vì vậy, chúng ta cần tăng cường các khả năng và thực hiện chính nền tảng K, điều này sẽ làm tăng tính thực tế của tất cả các ngữ nghĩa K mới và hiện tại.
Chúng tôi sẽ thực hiện một số cải tiến hiệu suất chưa được thực hiện ngoài bằng chứng về khái niệm và phát triển các triển khai chất lượng sản xuất của các tính năng phân tích như công cụ thực thi biểu tượng K, trình biên dịch dựa trên ngữ nghĩa (SBC) và trình xác minh chương trình, hiện chỉ có nguyên mẫu
-Các thực hiện thực hiện trong dự án K học thuật.

### **Faster Execution**

### ** Thực thi nhanh hơn **

We plan to develop a concrete execution backend to K that will be at least one order of magnitude faster than the current one. The current one is based on translation to OCaml; we plan on translating to LLVM and specializing the pattern matcher to the specific patterns that occur in semantics. We believe it will be possible to execute programs against our KEVM semantics as efficiently as the reference C++ EVM implementation(!). If that will indeed be the case, and we strongly believe it will, then this will mark an unprecedented moment in the history of programming languages, when a language implementation automatically derived from a formal semantics of the language can serve as a realistic implementation of that language. While this was proved as a concept with toy languages, it has never been proven to work with real languages in practice. The K technology has reached a point where this is possible now. And not only to execute programs, or smart contracts, but also to reason about them, because a formal semantics, unlike an interpreter, can also be used for formal verification.

Chúng tôi dự định phát triển một phụ trợ thực thi cụ thể cho K sẽ nhanh hơn một thứ tự nhanh hơn một thứ tự hiện tại. Hiện tại dựa trên dịch sang OCAML; Chúng tôi có kế hoạch dịch sang LLVM và chuyên về trình kết hợp mẫu sang các mẫu cụ thể xảy ra trong ngữ nghĩa. Chúng tôi tin rằng sẽ có thể thực hiện các chương trình chống lại ngữ nghĩa KEVM của chúng tôi một cách hiệu quả như việc triển khai C ++ EVM tham chiếu (!). Nếu đó thực sự sẽ là trường hợp, và chúng tôi tin tưởng mạnh mẽ nó, thì điều này sẽ đánh dấu một thời điểm chưa từng có trong lịch sử ngôn ngữ lập trình, khi việc triển khai ngôn ngữ tự động xuất phát từ một ngữ nghĩa chính thức của ngôn ngữ có thể phục vụ như một triển khai thực tế về điều đó ngôn ngữ. Mặc dù điều này đã được chứng minh như một khái niệm với các ngôn ngữ đồ chơi, nhưng nó chưa bao giờ được chứng minh là làm việc với các ngôn ngữ thực trong thực tế. Công nghệ K đã đạt đến một điểm mà điều này là có thể bây giờ. Và không chỉ để thực hiện các chương trình, hoặc hợp đồng thông minh, mà còn để lý luận về chúng, bởi vì một ngữ nghĩa chính thức, không giống như một thông dịch viên, cũng có thể được sử dụng để xác minh chính thức.

### **Semantics-Based Compilation**

### ** biên dịch dựa trên ngữ nghĩa **

One of the most challenging components of the K framework that will be built in this project is what we call semantics-based compilation. The following picture shows how SBC works:

Một trong những thành phần thách thức nhất của khung K sẽ được xây dựng trong dự án này là cái mà chúng tôi gọi là tổng hợp dựa trên ngữ nghĩa.
Hình ảnh sau đây cho thấy cách SBC hoạt động:

![Semantics-Based Compilation](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.007.png)

We have implemented a rough prototype and were able to make it work with a simple imperative language, which we call IMP. Here is an example:

Chúng tôi đã thực hiện một nguyên mẫu thô và có thể làm cho nó hoạt động với một ngôn ngữ bắt buộc đơn giản mà chúng tôi gọi là IMP.
Đây là một ví dụ:

![Simple Imperative Language - IMP](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.008.png)

The program to the left is transformed, using the semantics, into a much simpler program that looks like an abstract machine. The four states represent the â€œinstructionsâ€ of the new language Lâ€™, and the edges are the new semantic rules of Lâ€™. As seen, the semantics of the various sequences of instructions has been symbolically summarized, so that the amount of computation that needs to be done at runtime is minimized and everything that can be done statically is hardwired in the new semantics of Lâ€™, so all done before the program is executed. Preliminary experiments are encouraging, confirming our strong belief that the resulting SBC programs will execute one order of magnitude, or more, faster:

Chương trình bên trái được chuyển đổi, sử dụng ngữ nghĩa, thành một chương trình đơn giản hơn nhiều trông giống như một máy trừu tượng.
Bốn tiểu bang đại diện cho các cuộc đấu tranh của ngôn ngữ mới, và các cạnh là các quy tắc ngữ nghĩa mới của lâ € ™.
Như đã thấy, ngữ nghĩa của các chuỗi hướng dẫn khác nhau đã được tóm tắt một cách tượng trưng, do đó, lượng tính toán cần phải được thực hiện trong thời gian chạy được giảm thiểu và mọi thứ có thể được thực hiện theo nguyên tắc đều được tạo ra trong ngữ nghĩa mới của Lâ € ™, vì vậy
Tất cả được thực hiện trước khi chương trình được thực hiện.
Các thí nghiệm sơ bộ rất đáng khích lệ, xác nhận niềm tin mạnh mẽ của chúng tôi rằng các chương trình SBC kết quả sẽ thực hiện một bậc độ lớn, hoặc nhiều hơn, nhanh hơn:

![Semantics-Based Compilation Table](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.009.png)

These improvements to the K framework will not only yield a reasonably efficient prototype of executing smart contracts on IELE, but, more importantly, will give us an approach to write smart contracts in any programming languages that have a formal semantics in K.

Những cải tiến này đối với khung K sẽ không chỉ mang lại một nguyên mẫu hiệu quả hợp lý trong việc thực hiện các hợp đồng thông minh trên IELE, mà quan trọng hơn, sẽ cho chúng tôi một cách tiếp cận để viết các hợp đồng thông minh bằng bất kỳ ngôn ngữ lập trình nào có ngữ nghĩa chính thức trong K.

We, the K team at RV and at UIUC, are very excited to pursue this new project with IOHK. This gives us a unique chance to demonstrate that the K technology is ready to transit to the real world, in a space where security and trust in computation are paramount. It almost feels like smart contracts are the opportunity that K was waiting for all along, like what it was designed and implemented for.

Chúng tôi, nhóm K tại RV và tại UIUC, rất vui mừng được theo đuổi dự án mới này với IOHK.
Điều này cho chúng ta một cơ hội duy nhất để chứng minh rằng công nghệ K đã sẵn sàng chuyển sang thế giới thực, trong một không gian nơi bảo mật và tin tưởng vào tính toán là tối quan trọng.
Nó gần như cảm thấy như các hợp đồng thông minh là cơ hội mà K đang chờ đợi tất cả, giống như những gì nó được thiết kế và thực hiện.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-10-26-designing-a-new-virtual-machine-and-universal-language-framework.004.png)[ Designing a new virtual machine and universal language framework - Input Output](https://ucarecdn.com/45a7832c-8350-4075-bafc-d4e6b7f002bd/-/inline/yes/ "Designing a new virtual machine and universal language framework - Input Output")

