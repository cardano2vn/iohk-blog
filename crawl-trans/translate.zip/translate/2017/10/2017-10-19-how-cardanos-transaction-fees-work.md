# How Cardano's transaction fees work
### **The mathematician working on the protocol's incentives explains the research and IOHK's design**
![](img/2017-10-19-how-cardanos-transaction-fees-work.002.png) 19 October 2017![](img/2017-10-19-how-cardanos-transaction-fees-work.002.png)[ Lars Brünjes](tmp//en/blog/authors/lars-brunjes/page-1/)![](img/2017-10-19-how-cardanos-transaction-fees-work.003.png) 4 mins read

![](img/2017-10-19-how-cardanos-transaction-fees-work.004.png)[ How Cardano's transaction fees work - Input Output](https://ucarecdn.com/fc1efae6-8254-4b13-8c2f-baa5dba59197/-/inline/yes/ "How Cardano's transaction fees work - Input Output")

![Lars Brünjes](img/2017-10-19-how-cardanos-transaction-fees-work.005.png)[](tmp//en/blog/authors/lars-brunjes/page-1/)
### [**Lars Brünjes**](tmp//en/blog/authors/lars-brunjes/page-1/)
Education Director

Education

- ![](img/2017-10-19-how-cardanos-transaction-fees-work.006.png)[](mailto:lars.bruenjes@iohk.io "Email")
- ![](img/2017-10-19-how-cardanos-transaction-fees-work.007.png)[](https://www.linkedin.com/in/dr-lars-br%C3%BCnjes-1640993b "LinkedIn")
- ![](img/2017-10-19-how-cardanos-transaction-fees-work.008.png)[](https://twitter.com/LarsBrunjes "Twitter")
- ![](img/2017-10-19-how-cardanos-transaction-fees-work.009.png)[](https://github.com/brunjlar "GitHub")

![How Cardano's transaction fees work](img/2017-10-19-how-cardanos-transaction-fees-work.010.jpeg)
## **Why do we need transaction fees?**
There are two main reasons why transaction fees are needed for a cryptocurrency like Cardano:

Có hai lý do chính tại sao phí giao dịch là cần thiết cho một loại tiền điện tử như Cardano:

People who run full Cardano nodes spend time, money and effort to run the protocol, for which they should be compensated and rewarded. In contrast to Bitcoin, where new currency is created with each mined block, in Cardano, transaction fees are the only source of income for participants in the protocol.

Những người chạy các nút Cardano đầy đủ dành thời gian, tiền bạc và nỗ lực để điều hành giao thức, mà họ nên được bồi thường và khen thưởng.
Trái ngược với Bitcoin, nơi tiền tệ mới được tạo ra với mỗi khối được khai thác, trong Cardano, phí giao dịch là nguồn thu nhập duy nhất cho những người tham gia giao thức.

The second reason for transaction fees is the prevention of DDoS (Distributed Denial of Service) attacks. In a DDoS attack, an attacker tries to flood the network with dummy transactions, and if he has to pay a sufficiently high fee for each of those dummy transactions, this form of attack will become prohibitively expensive for him.

Lý do thứ hai cho phí giao dịch là phòng ngừa các cuộc tấn công DDO (từ chối dịch vụ phân tán).
Trong một cuộc tấn công của DDOS, một kẻ tấn công cố gắng tràn vào mạng với các giao dịch giả và nếu anh ta phải trả một khoản phí đủ cao cho mỗi giao dịch giả đó, hình thức tấn công này sẽ trở nên đắt đỏ đối với anh ta.

## **How do transaction fees work?**

## ** Phí giao dịch hoạt động như thế nào? **

Whenever somebody wants to transfer an amount of Ada, some *minimal fees* are computed for that transaction. In order for the transaction to be valid, these minimal fees have to be included (although the sender is free to pay higher fees if he so wishes). All transaction fees are collected in a virtual pool and then later distributed amongst participants in the Cardano protocol.

Bất cứ khi nào ai đó muốn chuyển một lượng ADA, một số * phí tối thiểu * được tính toán cho giao dịch đó.
Để giao dịch có hiệu lực, các khoản phí tối thiểu này phải được bao gồm (mặc dù người gửi được miễn phí trả phí cao hơn nếu anh ta mong muốn).
Tất cả các khoản phí giao dịch được thu trong một nhóm ảo và sau đó được phân phối giữa những người tham gia giao thức Cardano.

## **How are the minimal transaction fees calculated?**

## ** Phí giao dịch tối thiểu được tính như thế nào? **

The minimal fees for a transaction are calculated according to the formula

Các khoản phí tối thiểu cho một giao dịch được tính theo công thức

a + b × size,

kích thước A + B ×,

where 'a' and 'b' are constants and 'size' is the size of the transaction in Bytes. At the moment, the constants 'a' and 'b' have the values

Trong đó 'A' và 'B' là hằng số và 'kích thước' là kích thước của giao dịch trong byte.
Hiện tại, các hằng số 'A' và 'B' có các giá trị

a = 0.155381 ADA,

A = 0,155381 ADA,

b = 0.000043946 ADA/Byte.

b = 0,000043946 ADA/byte.

This means that each transaction costs at least 0.155381 ADA, with an additional cost of 0.000043946 ADA per Byte of transaction size. For example, a transaction of size 200 Byte (a fairly typical size) costs

Điều này có nghĩa là mỗi chi phí giao dịch ít nhất là 0,155381 ADA, với chi phí bổ sung là 0,000043946 ADA mỗi byte quy mô giao dịch.
Ví dụ: một giao dịch có kích thước 200 byte (kích thước khá điển hình) chi phí

0.155381 ADA + 0.000043946 ADA/Byte × 200 Byte = 0.1641702 ADA.

0.155381 ADA + 0,000043946 ADA/byte × 200 byte = 0.1641702 ADA.

Why did we pick this particular formula? The reason for having parameter 'a' is the prevention of DDoS attacks mentioned above: even a very small dummy transaction should cost enough to hurt an attacker who tries to generate many thousands of them. Parameter 'b' has been introduced to reflect actual costs: storing larger transactions needs more computer memory than storing smaller transactions, so larger transactions should be more expensive than smaller ones.

Tại sao chúng tôi chọn công thức đặc biệt này?
Lý do để có tham số 'A' là việc ngăn chặn các cuộc tấn công DDoS được đề cập ở trên: Ngay cả một giao dịch giả rất nhỏ cũng phải có giá đủ để làm tổn thương một kẻ tấn công cố gắng tạo ra hàng ngàn người trong số họ.
Tham số 'B' đã được giới thiệu để phản ánh chi phí thực tế: Lưu trữ các giao dịch lớn hơn cần nhiều bộ nhớ máy tính hơn là lưu trữ các giao dịch nhỏ hơn, vì vậy các giao dịch lớn hơn nên đắt hơn so với các giao dịch nhỏ hơn.

In order to arrive at the particular values for parameters 'a' and 'b', we had to answer questions like:

Để đi đến các giá trị cụ thể cho các tham số 'A' và 'B', chúng tôi phải trả lời các câu hỏi như:

- How expensive is one byte of computer memory?

- Làm thế nào đắt là một byte bộ nhớ máy tính?

- How many transactions will there be on average per second?

- Trung bình sẽ có bao nhiêu giao dịch mỗi giây?

- How large will a transaction be on average?

- Trung bình một giao dịch sẽ lớn như thế nào?

- How much does it cost to run a full node?

- Chi phí chạy một nút đầy đủ là bao nhiêu?

We had to *estimate* the answers to those questions, but now that Cardano is up and running, we will be able to gather statistics to find more accurate answers. This means that 'a' and 'b' will probably be adjusted in future to better reflect actual costs.

Chúng tôi đã phải * ước tính * câu trả lời cho những câu hỏi đó, nhưng bây giờ Cardano đang hoạt động, chúng tôi sẽ có thể thu thập số liệu thống kê để tìm câu trả lời chính xác hơn.
Điều này có nghĩa là 'A' và 'B' có thể sẽ được điều chỉnh trong tương lai để phản ánh tốt hơn chi phí thực tế.

We even plan to eventually come up with a scheme that will adjust those constants *dynamically* in a *market driven way*, so that no human intervention will be needed to react to changes in traffic and operational costs. How to achieve this is one focus of our active research.

Chúng tôi thậm chí còn có kế hoạch cuối cùng đưa ra một kế hoạch sẽ điều chỉnh các hằng số đó *một cách linh hoạt *theo cách *điều khiển thị trường *, do đó sẽ không cần sự can thiệp của con người để phản ứng với những thay đổi trong giao thông và chi phí vận hành.
Làm thế nào để đạt được điều này là một trọng tâm của nghiên cứu tích cực của chúng tôi.

## **How are fees distributed?**

## ** Phí phân phối như thế nào? **

All transaction fees of a given "epoch" are collected in a virtual pool, and the idea is to then redistribute the money from that pool amongst people who were elected "slot leaders" by the [proof of stake algorithm](https://www.youtube.com/watch?v=JwxVySVF-U4 "Ouroboros presentation, IACR Crypto-2017") during that epoch and who created blocks.

Tất cả các khoản phí giao dịch của một "epoch" nhất định được thu thập trong một nhóm ảo và sau đó ý tưởng là phân phối lại số tiền từ nhóm đó trong số những người được bầu "các nhà lãnh đạo khe" bằng [bằng chứng về thuật toán cổ phần] (https: //
www.youtube.com/watch?v=JWXVYSVF-U4 "Trình bày OuroBoros, IACR Crypto-2017") trong thời đại đó và người đã tạo ra các khối.

At this stage of Cardano, where all blocks are created by nodes operated by IOHK and our partners, fees are already collected (to prevent [DDoS attacks](https://en.wikipedia.org/wiki/Denial-of-service_attack "Denial of Service Attack, Wikipedia")), but they will *not* be distributed and instead will be *burnt*.

Ở giai đoạn này của Cardano, nơi tất cả các khối được tạo bởi các nút do IOHK và các đối tác của chúng tôi hoạt động, các khoản phí đã được thu thập (để ngăn chặn [các cuộc tấn công của DDOS] (https://en.wikipedia.org/wiki/denial-of-service_attack "
Từ chối tấn công dịch vụ, wikipedia ")), nhưng chúng sẽ *không được phân phối và thay vào đó sẽ *bị cháy *.

As soon as Cardano enters its next, fully decentralized stage, fees will be distributed as described above.

Ngay khi Cardano bước vào giai đoạn tiếp theo, phân cấp hoàn toàn, phí sẽ được phân phối như mô tả ở trên.

## **What next?**

## **Tiếp theo là gì?**

Coming up with a solid scheme for fee distribution is a challenging mathematical problem: How do we incentivize "good" behavior and promote efficiency while punishing "bad" behavior and attacks? How do we make sure that people who participate in the protocol receive their fair reward, while also ensuring that the best way to earn money with Cardano is to make the system as reliable and efficient as possible? The trick is to align incentives for node operators with the "common good", so that rewards are highest when the system is running at optimal performance.

Đưa ra một kế hoạch vững chắc để phân phối phí là một vấn đề toán học đầy thách thức: làm thế nào để chúng ta khuyến khích hành vi "tốt" và thúc đẩy hiệu quả trong khi trừng phạt hành vi "xấu" và tấn công?
Làm thế nào để chúng tôi đảm bảo rằng những người tham gia giao thức nhận được phần thưởng công bằng của họ, đồng thời đảm bảo rằng cách tốt nhất để kiếm tiền với Cardano là làm cho hệ thống trở nên đáng tin cậy và hiệu quả nhất có thể?
Bí quyết là sắp xếp các ưu đãi cho các nhà khai thác nút với "lợi ích chung", do đó phần thưởng cao nhất khi hệ thống đang chạy với hiệu suất tối ưu.

These are questions studied by the mathematical discipline called [*Game Theory*](https://en.wikipedia.org/wiki/Game_theory "Game Theory, Wikipedia"), and we are proud to have prominent game theorist and Gödel Award laureate Prof. Elias Koutsoupias of the University of Oxford working with us on finding solutions to this problem.

Đây là những câu hỏi được nghiên cứu bởi kỷ luật toán học có tên [*Lý thuyết trò chơi*] (https://en.wikipedia.org/wiki/game_theory "Lý thuyết trò chơi, Wikipedia"), và chúng tôi tự hào có nhà lý thuyết trò chơi nổi tiếng và giải thưởng Gt
Giáo sư Elias Koutsoupias của Đại học Oxford làm việc với chúng tôi về việc tìm kiếm các giải pháp cho vấn đề này.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-10-19-how-cardanos-transaction-fees-work.004.png)[ How Cardano's transaction fees work - Input Output](https://ucarecdn.com/fc1efae6-8254-4b13-8c2f-baa5dba59197/-/inline/yes/ "How Cardano's transaction fees work - Input Output")

