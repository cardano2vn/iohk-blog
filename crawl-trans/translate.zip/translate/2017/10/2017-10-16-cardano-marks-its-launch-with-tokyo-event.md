# Cardano marks its launch with Tokyo event
### **Hundreds of fans celebrate bright future for the cryptocurrency**
![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.002.png) 16 October 2017![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.003.png) 8 mins read

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.004.png)[ Cardano marks its launch with Tokyo event - Input Output](https://ucarecdn.com/f0080953-1a94-4089-b719-ed69ecf2ad07/-/inline/yes/ "Cardano marks its launch with Tokyo event - Input Output")

![Jane Wild](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.005.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.006.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.007.png)[](https://twitter.com/jane_wild_ "Twitter")

The technology was conceived in an Osaka restaurant more than two years ago and from that small beginning Cardano has been built into a leading cryptocurrency. The project has amassed a team of experts in countries around the world, has generated more than 67,000 lines of code, and has a strong and growing community in countries across Asia and beyond. Along the way, Cardano has set new standards for cryptocurrencies with best practices such as peer review and high assurance methods of software engineering. The official launch was held in the district of Shibuya in Tokyo on Saturday October 14 for an audience of about 500 people, who had each won a ticket through a lottery held on social media. Excited cryptocurrency enthusiasts, Ada holders and business people from across Japan queued to get Cardano t-shirts and souvenir physical Ada coins, before going into the main hall to hear about how Cardano was created and the vision for its future. "The first thing we did when we knew the project was real was to build great partnerships," Charles Hoskinson, founder and CEO of IOHK, told the audience. "Our chief scientist is based at University of Edinburgh, it is a wonderful place, where they built the heart of Cardano. We have a lot of wonderful people at the University of Athens, they are rigorous, making sure that the theory works. And we have people at Tokyo Tech who work on multi party computation and look to the future, and work out how to make Cardano last a long time." The vision for Cardano, Hoskinson said, was that it would pull together academic research and bright ideas from computer science to produce a cryptocurrency capable of much more than its predecessors.

[This "third generation" cryptocurrency](https://www.bitsonline.com/video-hoskinson-cardano/ "Time for â€Third Generationâ€™ Blockchains, Says Cardanoâ€™s Charles Hoskinson, Bitsonline") would be able to scale to a billion users, using a proof of stake algorithm, Ouroboros, which avoided the huge energy consumption of proof of work cryptocurrencies. Features that would be added to Cardano to help it scale included sidechains, trusted hardware, and RINA, or recursive internetwork architecture. Sustainability would be part of the design by way of a treasury system to fund development indefinitely, allowing stakeholders to vote on proposed changes to the protocol. Meanwhile, the computation layer of the technology, would be innovative in using a tool called [K Framework](https://coinjournal.net/kevm-wins-ic3-ethereum-crypto-boot-camp-2017-competition/ "KEVM Wins IC3-Ethereum Crypto Boot Camp 2017 Competition, Coin Journal") to allow developers to write smart contracts in the programming language of their choice, he said. Security is paramount to cryptocurrency because flaws in code increase the risk of hacks and the loss of coin holder funds, unfortunately witnessed too often. With that in mind, Duncan Coutts, head of engineering at IOHK, explained how the company approaches software development: cryptography research papers are translated into code using the technique of formal specification. This involves a series of mathematical steps that progressively take the cryptography closer to the code that the developers write, a process that allows checks to be made that the specifications are indeed correct.

![Duncan Coutts at the Cardano Launch event](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.008.jpeg) Duncan Coutts, IOHK Director of Engineering, presenting at the Cardano launch event

"Iâ€™m passionate about bringing clever ideas from computer science and using them in Cardano," Coutts said. "And Iâ€™m obsessive about software quality. Beautiful software is like beautiful mathematics or poetry." Aside from engineering, the other twin pillar of IOHK is research, and Bernardo David went on stage to talk about the rigour supporting the papers that IOHK produces. David is an assistant professor at Tokyo Tech where IOHK has a research partnership, and was one of the team that produced Ouroboros, a provably secure proof of stake algorithm. On the question of whether people should accept the quality of the research, he pointed to the paperâ€™s peer review through its acceptance to [Crypto 2017](https://www.forbes.com/sites/amycastor/2017/08/23/at-crypto-2017-blockchain-presentations-focus-on-proofs-not-concepts/1 "Blockchain Projects Tighten Security with Math, Forbes"), the annual cryptography conference held in California. "This is the first proof of stake paper that was published in a big conference so you can trust the largest and most respected cryptography conference in the world," he said. "You donâ€™t have to take my word, you can trust all the other cryptographers."

"Tôi đam mê mang những ý tưởng thông minh từ khoa học máy tính và sử dụng chúng trong Cardano," Coutts nói. "Và tôi ám ảnh về chất lượng phần mềm. Phần mềm đẹp giống như toán học hay thơ đẹp." Ngoài kỹ thuật, một trụ cột sinh đôi khác của IOHK là nghiên cứu, và Bernardo David đã lên sân khấu để nói về sự nghiêm khắc hỗ trợ các bài báo mà IOHK sản xuất. David là một giáo sư trợ lý tại Tokyo Tech, nơi IOHK có quan hệ đối tác nghiên cứu và là một trong những nhóm sản xuất Ouroboros, một bằng chứng an toàn về thuật toán cổ phần. Về câu hỏi liệu mọi người có nên chấp nhận chất lượng nghiên cứu hay không, ông đã chỉ ra đánh giá ngang hàng của tờ giấy thông qua sự chấp nhận của nó đối với [Crypto 2017] (https://www.forbes.com/sites/amycastor/2017/08 . "Đây là bằng chứng đầu tiên của bài báo cổ phần được xuất bản trong một hội nghị lớn để bạn có thể tin tưởng hội nghị mật mã lớn nhất và được kính trọng nhất trên thế giới," ông nói. "Bạn không phải nói, bạn có thể tin tưởng tất cả các nhà mật mã học khác."

![Michael Parsons at the Cardano Launch event](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.008.jpeg) Michael Parsons, Chairman of Cardano, speaking at the Cardano launch event

The launch event introduced the other important organisations supporting Cardano, such as the Cardano Foundation. The Swiss-based standards body acts as the guardian of the protocol and its duties include providing information to the community and working with governments to shape regulation. Michael Parsons, chairman, announced that Ada holders would be able to store their coins in the Ledger hardware wallet and integration was being worked on. Plans for the future included working with a respected London think-tank to produce blockchain research. Thanking the community, he said: "Cardano is a blockchain protocol with integrity. We are dedicated to helping it derive its full potential and make the world a better place. You supported us to help make Cardano what it is, so thank you." The third organisation supporting Cardano is Emurgo, which is based in Japan and extends support and advice to anyone wishing to build applications on the software.

Sự kiện ra mắt đã giới thiệu các tổ chức quan trọng khác hỗ trợ Cardano, chẳng hạn như Quỹ Cardano.
Cơ quan tiêu chuẩn có trụ sở tại Thụy Sĩ đóng vai trò là người bảo vệ giao thức và nhiệm vụ của nó bao gồm cung cấp thông tin cho cộng đồng và làm việc với các chính phủ để định hình quy định.
Michael Parsons, chủ tịch, tuyên bố rằng những người nắm giữ Ada sẽ có thể lưu trữ tiền của họ trong ví phần cứng sổ cái và tích hợp đang được thực hiện.
Kế hoạch cho tương lai bao gồm làm việc với một cơ hội tư duy London đáng kính để sản xuất nghiên cứu blockchain.
Cảm ơn cộng đồng, ông nói: "Cardano là một giao thức blockchain với tính toàn vẹn. Chúng tôi dành riêng để giúp nó có được tiềm năng đầy đủ của nó và biến thế giới thành một nơi tốt đẹp hơn. Bạn đã hỗ trợ chúng tôi giúp tạo ra Cardano, cảm ơn bạn."
Tổ chức thứ ba hỗ trợ Cardano là Emurgo, có trụ sở tại Nhật Bản và mở rộng hỗ trợ và tư vấn cho bất kỳ ai muốn xây dựng các ứng dụng trên phần mềm.

![Naomi Nisiguchi from Tokyo](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.009.jpeg) 

Cardano fan Naomi Nisiguchi

Cardano Fan Naomi Nisiguchi

Ken Kodama, CEO of Emurgo, emphasised the advantages of Cardanoâ€™s technology over older cryptocurrencies, and said: "Emurgo sees a bright future that Cardano will provide a more trustable way of identifying individuals and also a reasonable, and faster payment method to people who don't have them now. Emurgo will play an important role in plugging developers and startups to the Cardano ecosystem." Kodama, along with Darren Camas, senior adviser to Emurgo, spoke about how a network was being established in other Asian countries to support its growth. Camas said: "The question for us is how do we help Ada become the fuel that powers financial technology, not only in the developed world but in Malaysia, Vietnam, Argentina, Nigeriaâ€¦ How do we bring more people from across the globe to transact in the Cardano ecosystem?"

Ken Kodama, Giám đốc điều hành của Emurgo, nhấn mạnh những lợi thế của công nghệ Cardano so với các loại tiền điện tử cũ hơn và nói: "Emurgo thấy một tương lai tươi sáng rằng Cardano sẽ cung cấp một cách đáng tin cậy hơn để xác định các cá nhân và cũng là một phương thức thanh toán nhanh hơn và nhanh chóng để
Những người không có chúng bây giờ. Emurgo sẽ đóng một vai trò quan trọng trong việc cắm các nhà phát triển và khởi nghiệp vào hệ sinh thái Cardano. "
Kodama, cùng với Darren Camas, cố vấn cấp cao của Emurgo, đã nói về cách một mạng lưới được thành lập ở các nước châu Á khác để hỗ trợ sự phát triển của nó.
Camas nói: "Câu hỏi cho chúng tôi là làm thế nào để chúng tôi giúp Ada trở thành nhiên liệu cung cấp năng lượng cho công nghệ tài chính, không chỉ ở thế giới phát triển mà ở Malaysia, Việt Nam, Argentina, Nigeria - làm thế nào để chúng tôi đưa nhiều người hơn từ khắp nơi trên thế giới đến
Transe trong hệ sinh thái Cardano? "

After the presentation crowds formed outside the hall to have their photos taken with the Cardano team. Some people who came along were longstanding supporters of the project, such as Naomi Nisiguchi, from Mie Prefecture. She works as a manager in the construction industry and has had an interest in cryptocurrency for four years. "Around two years ago I heard about Ada and that Charles Hoskinson was involved," she said. "Iâ€™ve been following the news on Facebook and Iâ€™m very interested to learn how the project will move on."

Sau khi trình bày đám đông hình thành bên ngoài hội trường để chụp ảnh với nhóm Cardano.
Một số người đến cùng là những người ủng hộ lâu dài của dự án, như Naomi Nisiguchi, từ tỉnh Mie.
Cô làm việc như một người quản lý trong ngành xây dựng và đã quan tâm đến tiền điện tử trong bốn năm.
"Khoảng hai năm trước tôi đã nghe về Ada và Charles Hoskinson có liên quan," cô nói.
"Tôi đã theo dõi tin tức trên Facebook và tôi rất quan tâm để tìm hiểu làm thế nào dự án sẽ tiếp tục."

![Ken Kodama speaking at Cardano launch event](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.008.jpeg) Ken Kodama, CEO of Emurgo, speaking at the Cardano launch event

Many people had plans regarding Cardano. Takashi Kawaguchi set up Fintech Academia last month to give Japanese people information about cryptocurrencies, and came along because he believes Cardano has the potential to rise up and be on par with Bitcoin and Ethereum. His website would provide educational resources that would help people understand and trust crypto, he said, and learn that it wasnâ€™t an enemy, but represented the future.

Nhiều người đã có kế hoạch liên quan đến Cardano.
Takashi Kawaguchi đã thành lập Học viện Fintech vào tháng trước để cung cấp cho người dân Nhật Bản thông tin về tiền điện tử, và đã xuất hiện vì ông tin rằng Cardano có khả năng tăng lên và ngang tầm với Bitcoin và Ethereum.
Trang web của anh ấy sẽ cung cấp các nguồn lực giáo dục giúp mọi người hiểu và tin tưởng tiền điện tử, và biết rằng đó không phải là kẻ thù, nhưng đại diện cho tương lai.

Other people at the event were planning business interests, such as Nobuyoshi Hayashi from Tochigi prefecture, who owns a consultancy and wants to begin offering cryptocurrency advisory services. The launch itself is only the beginning for Cardano, with many new features to be added during the next three years that will cement its position as the leading cryptocurrency. Mario Larangeira, specially appointed associate professor at Tokyo Tech, was in the audience, and said it was a great time to be working in cryptography. "To be part of this project is challenging, complex but also very exciting," he said. "Now we are working on multi party computation and putting even more cryptography into Cardano, for example with [Kaleidoscope](tmp//en/research/papers/#P684RSHV "IOHK Papers, Kaleidoscope"), new research that is being produced at Tokyo Tech with Bernardo David and Rafael Dowsley."

Những người khác tại sự kiện đã lên kế hoạch cho lợi ích kinh doanh, chẳng hạn như Nobuyoshi Hayashi từ tỉnh Tochigi, người sở hữu một công ty tư vấn và muốn bắt đầu cung cấp dịch vụ tư vấn tiền điện tử.
Bản thân việc ra mắt chỉ là khởi đầu cho Cardano, với nhiều tính năng mới sẽ được thêm vào trong ba năm tới sẽ củng cố vị trí của nó là tiền điện tử hàng đầu.
Mario Larangeira, phó giáo sư được bổ nhiệm đặc biệt tại Tokyo Tech, đã có mặt trong khán giả, và nói rằng đây là thời điểm tuyệt vời để làm việc trong mật mã.
"Trở thành một phần của dự án này là một thách thức, phức tạp nhưng cũng rất thú vị", ông nói.
"Bây giờ chúng tôi đang làm việc về tính toán đa nhóm và đưa nhiều mật mã hơn vào Cardano, ví dụ với [Kính vạn hoa] (TMP // EN/Nghiên cứu/Giấy tờ/#P684RSHV" IOHK Papers, Kaleidoscope "), nghiên cứu mới đang được sản xuất tại
Tokyo Tech với Bernardo David và Rafael Dowsley. "

![Bernardo David speaking at Cardano launch event](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.008.jpeg) Bernardo David, IOHK Research Fellow, speaking at the Cardano launch event

There was much hard work ahead, agreed Charles Hoskinson, and holding an event in Tokyo with Cardano partners was a very special occasion. "This is a really fun event," he said. "Cardano has its largest community here in Japan and we felt it was so important to have a launch event to thank the community for being so supportive, loyal and patient. The point of this event has been to talk about where we came from and where we plan on going, and meet some new people and make new friends."

Có nhiều công việc khó khăn phía trước, Charles Hoskinson đồng ý và tổ chức một sự kiện ở Tokyo với Cardano Partners là một dịp rất đặc biệt.
"Đây là một sự kiện thực sự thú vị," ông nói.
"Cardano có cộng đồng lớn nhất ở Nhật Bản và chúng tôi cảm thấy điều quan trọng là phải có một sự kiện ra mắt để cảm ơn cộng đồng vì đã rất ủng hộ, trung thành và kiên nhẫn.
Chúng tôi dự định đi, và gặp gỡ một số người mới và kết bạn mới. "

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.010.jpeg)[](https://ucarecdn.com/1f67d026-139b-471d-9f9e-92ef85492b88/)

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.010.jpeg)[](https://ucarecdn.com/e12a00a2-7c0f-425a-a2fb-09dc401729f7/)

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.010.jpeg)[](https://ucarecdn.com/ddc59fc8-87f9-476b-a31f-dba33a3b8add/)

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.010.jpeg)[](https://ucarecdn.com/cf296d46-da87-4ba3-806f-d4824d13b2b2/)

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.010.jpeg)[](https://ucarecdn.com/b703f992-bc2a-4dc5-b6b6-c0dd1630bd74/)

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.010.jpeg)[](https://ucarecdn.com/9d61cbdd-6d87-4ead-bf9d-68d7b143a5a1/)

## **Attachments**

## ** tệp đính kèm **

![](img/2017-10-16-cardano-marks-its-launch-with-tokyo-event.004.png)[ Cardano marks its launch with Tokyo event - Input Output](https://ucarecdn.com/f0080953-1a94-4089-b719-ed69ecf2ad07/-/inline/yes/ "Cardano marks its launch with Tokyo event - Input Output")

