# Cardano help desk tour arrives in Tokyo
### **Customer service team reach last of five Japanese destinations**
![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.002.png) 12 October 2017![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.003.png) 6 mins read

![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.004.png)[ Cardano help desk tour arrives in Tokyo - Input Output](https://ucarecdn.com/c4478ec4-0c9a-4632-b841-46600237179a/-/inline/yes/ "Cardano help desk tour arrives in Tokyo - Input Output")

![Jeremy Wood](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![Cardano help desk tour arrives in Tokyo](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.009.jpeg)

The launch of Cardano brings to an end an exciting first phase of development for us at IOHK, after more than a year spent planning and developing the technology. Now weâ€™ve handed the product over to users and they are getting to know how it works. Using new software can be tricky â€“ some people wonâ€™t need any help, but there will be those who need a little assistance. To make sure that people know how to use the software and arenâ€™t experiencing any problems, IOHK and Cardano Foundation organised a help desk tour around Japan. As far as we know, this is the first time there has been a customer service tour for a cryptocurrency.

Over two weeks, starting from the end of September, the team visited five cities in Japan: Osaka, Nagoya, Hiroshima, Fukuoka and Tokyo, where we are holding three days of seminars. To figure out where we should go, the [Cardano Foundation](https://cardanofoundation.org "Cardano Foundation") had previously sent out a questionnaire to find out who needed our help, and what kinds of questions people had. This helped us plan the tour accordingly.

![Charles Hoskinson with an Ada holder](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.010.jpeg) 

IOHK founder Charles Hoskinson 

Người sáng lập IOHK Charles Hoskinson

with an Ada holder

với một người giữ ADA

We started out on a Saturday at the end of September in Osaka before moving on to Nagoya and making our way around Japan. Being able to meet and talk to the community of Ada holders was a really good experience. People were excited, eager to learn and had lots of positive comments and feedback. There was a mix of different ages, with the youngest people aged about 20 and the very oldest about 70. There were men and women, and there was a good turn out â€“ sessions were nearly always just about full. Kondo, aged 45, heard about Cardano through Facebook and joined the online community to learn more. "I think Cardanoâ€™s future is very bright," Kondo said at a help desk seminar. "I brought my PC today and managed to redeem my Ada. I donâ€™t think I couldâ€™ve done that without the staffâ€™s help. Iâ€™m glad that everythingâ€™s solved."

Chúng tôi bắt đầu vào một ngày thứ bảy vào cuối tháng 9 tại Osaka trước khi chuyển đến Nagoya và đi vòng quanh Nhật Bản.
Có thể gặp gỡ và nói chuyện với cộng đồng của những người nắm giữ Ada là một trải nghiệm thực sự tốt.
Mọi người rất hào hứng, háo hức để học và có rất nhiều bình luận và phản hồi tích cực.
Có một sự kết hợp của các độ tuổi khác nhau, với những người trẻ nhất khoảng 20 tuổi và khoảng 70 tuổi nhất khoảng 70. Có những người đàn ông và phụ nữ, và có một phiên họp tốt - các phiên gần như luôn luôn đầy đủ.
Kondo, 45 tuổi, đã nghe về Cardano thông qua Facebook và tham gia cộng đồng trực tuyến để tìm hiểu thêm.
"Tôi nghĩ tương lai của Cardano rất tươi sáng", Kondo nói tại một hội thảo bàn trợ giúp.
"Tôi đã mang PC của mình ngày hôm nay và quản lý để đổi ADA của mình. Tôi không nghĩ rằng tôi không thể làm điều đó mà không cần sự giúp đỡ của nhân viên. Tôi rất vui vì mọi thứ đã được giải quyết."

Some people came along to meet other members of the community. New "crypto friends" swapped details so they could use talk about cryptocurrency using Line. Others were excited and wanted to share their thanks with the team and good wishes for the future of Cardano. Each Cardano help desk programme lasted a full day, over which we ran several sessions. The most popular presentation was on exchanges, and explained cryptocurrency markets and [Bittrex](https://bittrex.com "Bittrex Digital Currency Exchange"), the exchange that Ada launched on. That session included a demonstration of how to use Bittrex, given by Daniel Friedman, a Japanese speaking IOHK staff member based in Osaka, and Toshiaki Miyatake, a Cardano community moderator from Tokyo, and the presentation was followed by a question and answer session. Aside from making sure that people had no technical problems, another objective of the help desk tour was to inform and educate. Cardano has attracted many people who are discovering an interest in cryptocurrency, so we want to help them get started by providing them with high quality resources and information.

Một số người đã đến để gặp gỡ các thành viên khác của cộng đồng. "Friends Crypto Friends" mới đã hoán đổi chi tiết để họ có thể sử dụng nói về tiền điện tử bằng cách sử dụng dòng. Những người khác rất hào hứng và muốn chia sẻ lời cảm ơn của họ với đội và những lời chúc tốt đẹp cho tương lai của Cardano. Mỗi chương trình bàn trợ giúp Cardano kéo dài cả ngày, chúng tôi đã chạy nhiều phiên. Bài thuyết trình phổ biến nhất là trên các sàn giao dịch và giải thích các thị trường tiền điện tử và [Bittrex] (https://bittrex.com "Trao đổi tiền kỹ thuật số Bittrex"), trao đổi mà ADA đã đưa ra. Phiên đó bao gồm một minh chứng về cách sử dụng Bittrex, được đưa ra bởi Daniel Friedman, một nhân viên IOHK nói tiếng Nhật có trụ sở tại Osaka và Toshiaki Miyatake, một người điều hành cộng đồng Cardano từ Tokyo, và bài thuyết trình được theo sau bởi một câu hỏi và trả lời. Bên cạnh việc đảm bảo rằng mọi người không có vấn đề kỹ thuật, một mục tiêu khác của tour du lịch bàn trợ giúp là thông báo và giáo dục. Cardano đã thu hút nhiều người đang khám phá mối quan tâm đến tiền điện tử, vì vậy chúng tôi muốn giúp họ bắt đầu bằng cách cung cấp cho họ các nguồn lực và thông tin chất lượng cao.

Another presentation covered the [Daedalus wallet](https://daedaluswallet.io "Daedalus Wallet"). This wallet is where Ada is stored, and where users send and receive Ada. Step by step, we walked people through using Daedalus, including showing them how to store their private keys, how to add their Ada to the wallet and send it to the exchange. This session included offering one-to-one technical help, for anyone who needed personal assistance. People brought their laptops and we had memory sticks to install Daedalus for them if they hadnâ€™t installed it already. There was also a popular presentation for people who wanted to join the growing Cardano community on social media. Miyatake showed people the Twitter accounts, the official Facebook group and how to join the conversation taking place in channels on Slack, with both Japanese and English language accounts available to join. Meeting Cardano users was enjoyable and hopefully provided them with all the help they needed, but it was also helpful for us too.

Một bài thuyết trình khác bao gồm [ví Daedalus] (https://daedaluswallet.io "ví Daedalus"). Ví này là nơi ADA được lưu trữ và nơi người dùng gửi và nhận ADA. Từng bước, chúng tôi dẫn mọi người qua sử dụng Daedalus, bao gồm chỉ cho họ cách lưu trữ các khóa riêng của họ, cách thêm ADA của họ vào ví và gửi nó đến sàn giao dịch. Phiên này bao gồm cung cấp trợ giúp kỹ thuật một-một, cho bất kỳ ai cần hỗ trợ cá nhân. Mọi người đã mang máy tính xách tay của họ và chúng tôi có que bộ nhớ để cài đặt Daedalus cho họ nếu họ đã cài đặt nó. Ngoài ra còn có một bài thuyết trình phổ biến cho những người muốn tham gia cộng đồng Cardano đang phát triển trên phương tiện truyền thông xã hội. Miyatake đã cho mọi người thấy các tài khoản Twitter, nhóm Facebook chính thức và cách tham gia cuộc trò chuyện diễn ra trong các kênh trên Slack, với cả tài khoản tiếng Nhật và tiếng Anh có sẵn để tham gia. Cuộc họp người dùng Cardano rất thú vị và hy vọng cung cấp cho họ tất cả sự giúp đỡ họ cần, nhưng nó cũng hữu ích cho chúng tôi.

![Jeremy Wood on Cardano Hrlp Desk Tour](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.011.jpeg) IOHK founder Jeremy Wood at the help desk tour

During the course of the sessions and meeting and talking to so many users, we uncovered a couple of small bugs in Daedalus, which our developers could begin work on fixing. Some of the bugs or issues we discovered were:

Trong quá trình của các phiên và cuộc họp và nói chuyện với rất nhiều người dùng, chúng tôi đã phát hiện ra một vài lỗi nhỏ ở Daedalus, mà các nhà phát triển của chúng tôi có thể bắt đầu hoạt động để sửa chữa.
Một số lỗi hoặc vấn đề chúng tôi đã phát hiện ra là:

- Using Japanese characters when naming the wallet could cause the wallet to crash. A fix for this is due to be made soon. 

- Sử dụng các ký tự Nhật Bản khi đặt tên ví có thể khiến ví bị sập.
Một sửa chữa cho điều này là do được thực hiện sớm.

- Daedalus now requires Windows users to synchronise the clock on their PC to the time on the internet.

- Daedalus hiện yêu cầu người dùng Windows phải đồng bộ hóa đồng hồ trên PC của họ cho đến thời điểm trên internet.

- Windows users may find that when they try to connect to the network for a second time after quitting the application, they are stuck connecting to the network. Developers are looking into issue, which can sometimes can be fixed by restarting the computer. 

- Người dùng Windows có thể thấy rằng khi họ cố gắng kết nối với mạng lần thứ hai sau khi rời khỏi ứng dụng, họ sẽ bị kẹt kết nối với mạng.
Các nhà phát triển đang xem xét vấn đề, đôi khi có thể được sửa chữa bằng cách khởi động lại máy tính.

- For a small number of people, transactions may not seen in the wallet despite being registered on the blockchain when they try to make a withdrawal from Bittrex. A fix for this is being worked on by developers.

- Đối với một số ít người, các giao dịch có thể không thấy trong ví mặc dù đã được đăng ký trên blockchain khi họ cố gắng rút tiền từ Bittrex.
Một sửa chữa cho điều này đang được các nhà phát triển làm việc.

- We have had reports that Daedalus may be wrongly identified as malware by the machine leaning algorithms used in some anti virus software. With time, this should change. Please be cautious if you are unsure and file a bug report. If you have a problem, first make sure your wallet is backed up, then download Daedalus again and reinstall it on your computer. 

- Chúng tôi đã có báo cáo rằng Daedalus có thể được xác định sai là phần mềm độc hại bởi các thuật toán nghiêng máy được sử dụng trong một số phần mềm chống virus.
Với thời gian, điều này sẽ thay đổi.
Vui lòng thận trọng nếu bạn không chắc chắn và nộp báo cáo lỗi.
Nếu bạn gặp sự cố, trước tiên hãy chắc chắn rằng ví của bạn được sao lưu, sau đó tải lại Daedalus và cài đặt lại nó trên máy tính của bạn.

- Windows users may not be able to use a tablet and instead should use a desktop computer.

- Người dùng Windows có thể không sử dụng máy tính bảng và thay vào đó nên sử dụng máy tính để bàn.

It was a busy but rewarding two weeks, now finishing up in Tokyo, where high demand means we had three full days booked at TKP Garden City in Shibuya. Now that Cardano is in the hands of the community there will be a special event in Tokyo this week to mark the successful launch. All three partners who are responsible for Cardano â€“ IOHK as its developers, the Cardano Foundation as the standards body and guardian, and Emurgo, the venture builder for decentralised applications â€“ will come together to talk about what users can expect to see with Cardano over the next three years. For coverage of the event, and to join the community, follow our social channels on [Facebook](https://www.facebook.com/groups/CardanoCommunity/ "Cardano Community, Facebook"), [Twitter](https://twitter.com/cardanocom "Cardano Community, Twitter"), and [Slack](https://cardano.herokuapp.com/ "Cardano, Slack").

Đó là một ngày bận rộn nhưng bổ ích hai tuần, hiện đang kết thúc ở Tokyo, nơi nhu cầu cao có nghĩa là chúng tôi đã có ba ngày được đặt tại TKP Garden City ở Shibuya.
Bây giờ Cardano nằm trong tay cộng đồng, sẽ có một sự kiện đặc biệt ở Tokyo trong tuần này để đánh dấu sự ra mắt thành công.
Cả ba đối tác chịu trách nhiệm về Cardano - Iohk là nhà phát triển của mình, Quỹ Cardano với tư cách là cơ quan tiêu chuẩn và người giám hộ, và Emurgo, người xây dựng liên doanh cho các ứng dụng phi tập trung - sẽ kết hợp với nhau để nói về những gì người dùng có thể thấy
với Cardano trong ba năm tới.
Để đưa tin về sự kiện và tham gia cộng đồng, hãy theo dõi các kênh xã hội của chúng tôi trên [Facebook] (https://www.facebook.com/groups/cardanocommunity/ "Cộng đồng Cardano, Facebook"), [Twitter] (https:/
/twitter.com/cardanocom "Cardano Community, Twitter") và [Slack] (https://cardano.herokuapp.com/ "Cardano, Slack").

## **Attachments**

## ** tệp đính kèm **

![](img/2017-10-12-cardano-help-desk-tour-arrives-in-tokyo.004.png)[ Cardano help desk tour arrives in Tokyo - Input Output](https://ucarecdn.com/c4478ec4-0c9a-4632-b841-46600237179a/-/inline/yes/ "Cardano help desk tour arrives in Tokyo - Input Output")

