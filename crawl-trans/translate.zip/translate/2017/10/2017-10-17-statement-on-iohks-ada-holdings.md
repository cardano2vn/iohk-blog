# Statement on IOHK's Ada Holdings
![](img/2017-10-17-statement-on-iohks-ada-holdings.002.png) 17 October 2017![](img/2017-10-17-statement-on-iohks-ada-holdings.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2017-10-17-statement-on-iohks-ada-holdings.003.png) 2 mins read

![](img/2017-10-17-statement-on-iohks-ada-holdings.004.png)[ Statement on IOHK's Ada Holdings - Input Output](https://ucarecdn.com/532de2c0-d7bf-4838-b70e-2551cf806e32/-/inline/yes/ "Statement on IOHK's Ada Holdings - Input Output")

![Charles Hoskinson](img/2017-10-17-statement-on-iohks-ada-holdings.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2017-10-17-statement-on-iohks-ada-holdings.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2017-10-17-statement-on-iohks-ada-holdings.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2017-10-17-statement-on-iohks-ada-holdings.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Statement on IOHK's Ada Holdings](img/2017-10-17-statement-on-iohks-ada-holdings.009.jpeg)

IOHK received both Bitcoin and Ada for its contract to work on the Cardano project. IOHK converted most of its Bitcoin at the time of receiving it to fiat in order to ensure project stability. With respect to IOHK's holdings of Ada, IOHK does not expect a need to liquidate any of its Ada to cover immediate costs related to the Cardano project until 2019. However, like most ventures in the cryptocurrency space, we have made certain payroll commitments in Ada to several IOHK personnel, contractors and third party firms.

IOHK đã nhận được cả Bitcoin và ADA cho hợp đồng của mình để làm việc trong dự án Cardano.
IOHK đã chuyển đổi hầu hết bitcoin của mình tại thời điểm nhận nó thành Fiat để đảm bảo sự ổn định của dự án.
Liên quan đến việc nắm giữ ADA của IOHK, IOHK không mong đợi việc thanh lý bất kỳ ADA nào của mình để trang trải chi phí ngay lập tức liên quan đến dự án Cardano cho đến năm 2019. Tuy nhiên, giống như hầu hết các dự án trong không gian tiền điện tử, chúng tôi đã thực hiện các cam kết biên chế nhất định trong ADA
cho một số nhân viên IOHK, nhà thầu và các công ty bên thứ ba.

Therefore, IOHK will voluntarily adopt the following vesting schedule for its Ada. A third of IOHK's Ada holdings will be immediately available to IOHK. A third will be made available after June 1st of 2018. The final third of IOHK's Ada will be made available after June 1st of 2019.

Do đó, IOHK sẽ tự nguyện áp dụng lịch trình giao dịch sau đây cho ADA của mình.
Một phần ba nắm giữ ADA của IOHK sẽ có sẵn ngay lập tức cho IOHK.
Một phần ba sẽ được cung cấp sau ngày 1 tháng 6 năm 2018. Thứ ba cuối cùng của ADA của IOHK sẽ được cung cấp sau ngày 1 tháng 6 năm 2019.

Charles Hoskinson will not receive any Ada until the final third of supply unlocks in June of 2019. When the computation layer of Cardano is released next year, IOHK will move its total Ada supply into a custom vesting contract to reflect the above policy.

Charles Hoskinson sẽ không nhận được bất kỳ ADA nào cho đến lần thứ ba cuối cùng của việc mở cửa vào tháng 6 năm 2019. Khi lớp tính toán của Cardano được phát hành vào năm tới, IOHK sẽ chuyển tổng nguồn cung ADA của mình vào hợp đồng giao dịch tùy chỉnh để phản ánh chính sách trên.

In the spirit of full disclosure, IOHK's initial Ada address is: 

Theo tinh thần tiết lộ đầy đủ, địa chỉ ADA ban đầu của IOHK là:

[](https://cardanoexplorer.com/tx/fa2d2a70c0b5fd45cb6c3989f02813061f9d27f15f30ecddd38780c59f413c62)

[].

fa2d2a70c0b5fd45cb6c3989f02813061f9d27f15f30ecddd38780c59f413c62

FA2D2A70C0B5FD45CB6C3989F02813061F9D27F15F30ECDDDDD38780C59F413C62

. We will make a follow-up statement when funds are moved to a custom vesting address.

.
Chúng tôi sẽ đưa ra một tuyên bố tiếp theo khi tiền được chuyển đến một địa chỉ giao dịch tùy chỉnh.

As for Emurgo and the Cardano Foundation, we have requested both partners to make a similar statement about use of funds. As they are independent businesses, they will do so at a time and manner of their choosing.

Đối với Emurgo và Cardano Foundation, chúng tôi đã yêu cầu cả hai đối tác đưa ra một tuyên bố tương tự về việc sử dụng tiền.
Vì họ là các doanh nghiệp độc lập, họ sẽ làm như vậy vào một thời điểm và cách họ lựa chọn.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-10-17-statement-on-iohks-ada-holdings.004.png)[ Statement on IOHK's Ada Holdings - Input Output](https://ucarecdn.com/532de2c0-d7bf-4838-b70e-2551cf806e32/-/inline/yes/ "Statement on IOHK's Ada Holdings - Input Output")

