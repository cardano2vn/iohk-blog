# Shanghai, New York and a hot pink rabbit: January IOHK news round-up
![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.002.png) 3 February 2017![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.003.png) 4 mins read

![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.004.png)[ Shanghai, New York and a hot pink rabbit January IOHK news round-up - Input Output](https://ucarecdn.com/c4998c9f-1025-4ee7-8c6b-ead85898008d/-/inline/yes/ "Shanghai, New York and a hot pink rabbit January IOHK news round-up - Input Output")

![Jane Wild](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.005.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.006.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.007.png)[](https://twitter.com/jane_wild_ "Twitter")
## **Winter School on blockchain**
The year got off to an invigorating start for IOHK when a team of its researchers arrived in a chilly Shanghai for the first ever Winter School on cryptocurrency and blockchain technologies.

![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.008.jpeg) The 121-year-old Jiao Tong University â€“ one of Chinaâ€™s leading institutions with alumni including the former president of China Jiang Zemin â€“ hosted the conference in step with a rising interest in blockchain in China, including in its capital of commerce, Shanghai. The winter school follows a similar event in Greece last year, the first Bitcoin Summer School, run by the International Association for Cryptologic Research.

The main hall at the universityâ€™s technology building was packed for the three-day event, with a cast of renowned cryptographers on the stage, including IOHK chief scientist [Aggelos Kiayias](tmp//en/team/aggelos-kiayias/ "Aggelos Kiayias, IOHK"). Professor Kiayias presented a double session on his work on proving the security of blockchain protocols. Jonathan Katz from the University of Maryland spoke on game theory, as well as chairing the event.

![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.009.jpeg) IOHK researcher [Alex Chepurnoy](/team/alexander-chepurnoy/ "Alex Chepurnoy, IOHK") gave a talk on [Scorex](/projects/scorex/ "Scorex, IOHK Project"), the prototype cryptocurrency he is working on with fellow IOHK developers [Dmitry Meshkov](/team/dmitry-meshkov/ "Dmitry Meshkov, IOHK") and [Jan Kotek](/team/jan-kotek/ "Jan Kotek, IOHK"). The project is open source, like all of IOHKâ€™s projects, and it aims to speed up the development of blockchains.

A lively panel debate on bitcoin, blockchain and their future, saw IOHK co-founder Charles Hoskinson take to the stage with his former collaborator at Ethereum, Vitalik Buterin.

Một cuộc tranh luận về bảng điều khiển sôi động về Bitcoin, Blockchain và tương lai của họ, đã thấy người đồng sáng lập IOHK Charles Hoskinson lên sân khấu với cộng tác viên cũ của mình tại Ethereum, Vitalik Buterin.

Other speakers included Andrew Miller from the University of Illinois, Loi Luu from the National University of Singapore, Joseph Bonneau from Stanford University, Vassilis Zikas from Rensselaer Polytechnic Institute and Hong-Sheng Zhou from Virginia Commonwealth University.

Các diễn giả khác bao gồm Andrew Miller từ Đại học Illinois, Loi Luu từ Đại học Quốc gia Singapore, Joseph Boneau từ Đại học Stanford, Vassilis Zikas từ Viện Bách khoa Rensselaer và Hong-Sheng Zhou từ Đại học Virginia Commonwealth.

During a break in programming the IOHK delegation honed their taxi hailing techniques (Shanghaiâ€™s cabs may be empty but that doesnâ€™t mean they will stop) to travel across town for filming. See the videos [here](https://www.youtube.com/channel/UCBJ0p9aCW-W82TwNM-z3V2w/feed "IOHK YouTube videos").

Trong thời gian nghỉ lập trình, phái đoàn IOHK đã mài giũa các kỹ thuật gọi taxi của họ (những chiếc taxi của Thượng Hải có thể trống rỗng nhưng điều đó không có nghĩa là họ sẽ dừng lại) để đi khắp thị trấn để quay phim.
Xem các video [tại đây] (https://www.youtube.com/channel/ucbj0p9acw-w82twnm-z3v2w/feed "video YouTube iohk").

## **Cryptography comes out of the classroom**

## ** Mật mã ra khỏi lớp học **

Even earlier than Shanghai, IOHK researchers were already busy this January, at Real World Crypto in New York. The aim of the annual conference is to strengthen the links between academics and developers in the hope of bringing the latest research into commercial applications in areas such as the internet, the cloud and embedded devices.

Thậm chí sớm hơn Thượng Hải, các nhà nghiên cứu của IOHK đã bận rộn vào tháng 1 này, tại Real World Crypto ở New York.
Mục đích của hội nghị thường niên là tăng cường liên kết giữa các học giả và nhà phát triển với hy vọng đưa nghiên cứu mới nhất vào các ứng dụng thương mại trong các lĩnh vực như Internet, đám mây và các thiết bị nhúng.

Prof Kiayias, who is chair of Cyber Security and Privacy at the University of Edinburgh, is an organiser and member of the steering committee.

Giáo sư Kiayias, chủ tịch của an ninh mạng và quyền riêng tư tại Đại học Edinburgh, là một nhà tổ chức và là thành viên của ban chỉ đạo.

From its beginnings as a gathering of some 150 specialists a few years ago, the audience at Real World Crypto has now grown to almost four times that size.

Từ khi bắt đầu như một tập hợp của khoảng 150 chuyên gia vài năm trước, khán giả tại Real World Crypto hiện đã tăng lên gần bốn lần kích thước đó.

â€œWeâ€™ve seen more people come each year,â€ says Prof Kiayias. â€œOur audience considers this to be the one of the primary events they go to, to get information about the applied aspects of cryptography.â€

"Chúng tôi đã thấy nhiều người đến mỗi năm," Giáo sư Kiayias nói.
"Khán giả của chúng tôi coi đây là một trong những sự kiện chính mà họ tham dự, để có được thông tin về các khía cạnh ứng dụng của mật mã.

![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.010.jpeg) 

Alex Chepurnoy speaking

Alex Chepurnoy nói

Russia-based Alex Chepurnoy also flew to the US for the conference for a [presentation](https://www.youtube.com/watch?v=PHY7JnLrK5o "Improving Authenticated Dynamic Dictionaries, YouTube") on a co-authored paper on blockchain efficiency.

Alex Chepurnoy có trụ sở tại Nga cũng đã bay tới Hoa Kỳ để tham dự hội nghị [thuyết trình] (https://www.youtube.com/watch?v=Phy7jnlrk5o "Cải thiện từ điển động được xác thực, YouTube")
Hiệu quả blockchain.

The work, [Improving Authenticated Dynamic Dictionaries](https://eprint.iacr.org/2016/994.pdf "Improving Authenticated Dynamic Dictionaries at IACR"), is written with Leonid Reyzin, Dmitry Meshkov, Alex and Sasha Ivanov.

Công việc, [cải thiện từ điển động được xác thực] (https://eprint.iacr.org/2016/994.pdf "Cải thiện từ điển động được xác thực tại IACR"), được viết bằng Leonid Reyzin, Dmitry Meshkov, Alex và Sasha Ivanov.

Topics tackled at the conference included passwords, blockchain, and TLS, the transport layer protocol through which data is exchanged on the internet.

Các chủ đề được giải quyết tại hội nghị bao gồm mật khẩu, blockchain và TLS, giao thức lớp vận chuyển thông qua đó dữ liệu được trao đổi trên Internet.

## **Designing a brand**

## ** Thiết kế một thương hiệu **

![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.011.jpeg) A leaping rabbit coloured in shades from hot pink to electric blue was the unlikely contender in the shortlist to become the logo for Deadalus, the wallet currently being put together by IOHK developers. Eight choices remain after designs were put to a popular vote. Designers took inspiration from locks, keys, and mazes in their draft visualisations of the Daedalus logo, referencing the high security of the wallet provided by Haskell code and the [Greek myth of Daedalus](https://en.wikipedia.org/wiki/Daedalus "Greek myth of Daedalus, Wikipedia") â€“ father of Icarus and creator of the Labyrinth in Crete where the Minotaur was held.

Vote for the winner in our [public poll](https://99designs.co.uk/contests/poll/3ctcwt "99DESIGNS.CO.UK")

Bỏ phiếu cho người chiến thắng trong [Cuộc thăm dò công khai] của chúng tôi (https://99designs.co.uk/contests/poll/3ctcwt "99Designs.co.uk")

### **Links**

### ** Liên kết **

Visit the ADA faucet to join development on our test net: [tada.iohk.io](https://tada.iohk.io "Cardano ADA Faucet")

Truy cập vòi ADA để tham gia phát triển trên mạng thử nghiệm của chúng tôi: [Tada.iohk.io] (https://tada.iohk.io "Vòi Cardano Ada")

Read about Cardano SL: [cardano-docs.iohk.io](https://cardano-docs.iohk.io/ "Cardano SL Documentation")

Đọc về Cardano SL: [Cardano-docs.iohk.io] (https://cardano-docs.iohk.io/ "Tài liệu Cardano SL")

Download the Daedalus wallet, available soon for OSX & Linux: [daedaluswallet.io](https://daedaluswallet.io "Cryptocurrency Desktop Wallet")

Tải xuống ví Daedalus, sớm có sẵn cho OSX & Linux: [Daedaluswallet.io] (https://daedaluswallet.io "Wallet Desktop Cryptocurrency")

## **Attachments**

## ** tệp đính kèm **

![](img/2017-02-03-shanghai-new-york-and-a-hot-pink-rabbit-january-iohk-news-round-up.004.png)[ Shanghai, New York and a hot pink rabbit January IOHK news round-up - Input Output](https://ucarecdn.com/c4998c9f-1025-4ee7-8c6b-ead85898008d/-/inline/yes/ "Shanghai, New York and a hot pink rabbit January IOHK news round-up - Input Output")

