# Mission one – Destination St Petersburg and Warsaw
![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.002.png) 22 February 2017![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.003.png) 3 mins read

![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.004.png)[ Mission one – Destination St Petersburg and Warsaw - Input Output](https://ucarecdn.com/75f3aeb6-df55-4906-896e-6227f81509d5/-/inline/yes/ "Mission one – Destination St Petersburg and Warsaw - Input Output")

![Jeremy Wood](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![Mission one – Destination St Petersburg and Warsaw](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.009.jpeg)

One of my first priorities after coming onboard with the [Grothendieck team](tmp//en/blog/ethereum-classic/introducing-the-grothendieck-team/ "Grothendieck team") to take forward Ethereum Classic was to get out and meet colleagues and IOHK’s developers, wherever they might be. That meant making a trip to St Petersburg and to Warsaw, which was an excellent opportunity to meet face-to-face, and all the more valuable given that we are usually spread out around the world and across timezones. When I arrived in St Petersburg at the end of January to see Alex Chepurnoy, IOHK Research Fellow and Scorex Team manager, the temperature outside was hovering below zero degrees celsius. Lunch involved Alex and I walking across a frozen lake, where a guy was fishing through the ice and another brave citizen in swimming trunks was going for a quick splash in the lake’s icy water. Later, Alex and I put our heads together to look at [Scorex](tmp//en/projects/scorex/ "Scorex") and whether it would be compatible for our Scala implementation of the Ethereum Client. We got into detailed discussions on how consensus is formed in ETC and the differences between it and Scorex, before going on to consider the network layer, and I also learnt from Alex about some of the potential future attacks on Ethereum. By the end of the trip we concluded that Scorex was not the right fit for use on the ETC client, because Ethereum is specified to a much greater degree of detail than Scorex was designed to accommodate. It was a useful discussion to have. We also shared thoughts on the philosophy of how blockchains work and IODB, which Jan Kotek at IOHK has developed specifically as a blockchain database and which supports versioning and key value pairs. All in all, it was a productive trip, rounded off with a visit to the State Russian museum, which I highly recommend.

Những ưu tiên đầu tiên của tôi sau khi lên tàu với [nhóm Grothendieck] (TMP // EN/Blog/Ethereum-Classic/Giới thiệu-The-the-Grothendieck-Team/"Grothendieck Team") Các đồng nghiệp và các nhà phát triển của IOHK, bất cứ nơi nào họ có thể. Điều đó có nghĩa là thực hiện một chuyến đi đến St Petersburg và đến Warsaw, đó là một cơ hội tuyệt vời để gặp mặt trực tiếp, và tất cả đều có giá trị hơn mà chúng ta thường trải rộng trên khắp thế giới và trên khắp thời gian. Khi tôi đến St Petersburg vào cuối tháng 1 để xem Alex Chepurnoy, IOHK Research Fellow và Scorx Team Manager, nhiệt độ bên ngoài đang lơ lửng dưới mức không. Ăn trưa liên quan đến Alex và tôi đi bộ qua một hồ nước đông lạnh, nơi một anh chàng đang câu cá qua băng và một công dân dũng cảm khác trong thân bơi đang đi chơi nhanh trong nước băng giá. Sau đó, Alex và tôi đặt đầu của chúng tôi lại với nhau để xem xét [SCOREX] (TMP // EN/Project/scorx/"Scorsx") và liệu nó có tương thích với việc triển khai máy khách Ethereum của chúng tôi hay không. Chúng tôi đã tham gia vào các cuộc thảo luận chi tiết về cách đồng thuận được hình thành trong ETC và sự khác biệt giữa nó và điểm số, trước khi tiếp tục xem xét lớp mạng và tôi cũng đã học được từ Alex về một số cuộc tấn công tiềm năng trong tương lai vào Ethereum. Vào cuối chuyến đi, chúng tôi đã kết luận rằng SCOREX không phù hợp để sử dụng cho khách hàng ETC, bởi vì Ethereum được chỉ định ở mức độ chi tiết lớn hơn nhiều so với SCORX được thiết kế để phù hợp. Đó là một cuộc thảo luận hữu ích để có. Chúng tôi cũng chia sẻ những suy nghĩ về triết lý về cách thức hoạt động của blockchain và IODB, Jan Kotek tại IOHK đã phát triển đặc biệt như một cơ sở dữ liệu blockchain và hỗ trợ các cặp giá trị chính và phiên bản. Nói chung, đó là một chuyến đi hiệu quả, làm tròn với một chuyến thăm đến Bảo tàng Nga, mà tôi rất khuyến khích.

In early February I visited Warsaw, to get to know the part of the Grothendieck team based in Poland. They normally work from home, so we hired a co-working space in Warsaw. True to the spirit of remote working, we set up a laptop and the Grothendieck team’s Argentine contingent – Alan Verbner and Nicolas Tallar – joined online from Buenos Aires. It was a fun variation from our usual daily call to keep up to date.

Đầu tháng 2, tôi đã đến thăm Warsaw, để làm quen với một phần của nhóm Grothendieck có trụ sở tại Ba Lan.
Họ thường làm việc tại nhà, vì vậy chúng tôi đã thuê một không gian làm việc chung ở Warsaw.
Đúng như tinh thần làm việc từ xa, chúng tôi đã thiết lập một máy tính xách tay và đội ngũ của Grothendieck, đội quân Argentina Argentina - Alan Verbner và Nicolas Tallar - đã tham gia trực tuyến từ Buenos Aires.
Đó là một biến thể thú vị từ cuộc gọi hàng ngày thông thường của chúng tôi để cập nhật.

So with the Polish part of the team – Radek Tkaczyk, Adam Smolarek, Lukasz Gasior and Jan Ziniewicz – we set out a timeline for our work on ETC and walked through all the functionality filling in gaps in each other’s knowledge as we went along. It was a very useful session followed by a well deserved team dinner and a beer (Thank you Pawel Marzec for organising!) On the second day, with the help of the whiteboard, we went through gas calculation, the architectural layer and architectural layering and components in the codebase.

Vì vậy, với phần Ba Lan của đội - Radek Tkac nhận, Adam Smolarek, Lukasz Gasior và Jan Ziniewicz - chúng tôi đã đặt ra một dòng thời gian cho công việc của chúng tôi về vv và đi qua tất cả các chức năng lấp đầy những khoảng trống trong kiến thức khác khi chúng tôi đi cùng.
Đó là một phiên rất hữu ích, sau đó là một bữa tối của nhóm rất xứng đáng và một ly bia (cảm ơn Pawel Marzec đã tổ chức!) Vào ngày thứ hai, với sự giúp đỡ của bảng trắng, chúng tôi đã trải qua tính toán khí, lớp kiến trúc và lớp kiến trúc và lớp học kiến trúc và
Các thành phần trong cơ sở mã.

Next stop, Argentina!

Điểm dừng tiếp theo, Argentina!

## **Attachments**

## ** tệp đính kèm **

![](img/2017-02-22-mission-one–destination-st-petersburg-and-warsaw.004.png)[ Mission one – Destination St Petersburg and Warsaw - Input Output](https://ucarecdn.com/75f3aeb6-df55-4906-896e-6227f81509d5/-/inline/yes/ "Mission one – Destination St Petersburg and Warsaw - Input Output")

