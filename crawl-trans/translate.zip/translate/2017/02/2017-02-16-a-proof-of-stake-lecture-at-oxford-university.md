# A Proof-of-Stake lecture at Oxford university
![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.002.png) 16 February 2017![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.003.png) 3 mins read

![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.004.png)[ A Proof-of-Stake lecture at Oxford university - Input Output](https://ucarecdn.com/2908eb3c-4d42-41bb-b0e5-4d571219acf0/-/inline/yes/ "A Proof-of-Stake lecture at Oxford university - Input Output")

![Jane Wild](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.005.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.006.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.007.png)[](https://twitter.com/jane_wild_ "Twitter")

![A Proof-of-Stake lecture at Oxford university](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.008.jpeg)

Mathematicians with a curiosity about the algorithms behind blockchain came to hear [Aggelos Kiayias](tmp//en/team/aggelos-kiayias/ "Aggelos Kiayias profile") speak at Oxford universityâ€™s Mathematical Institute on Wednesday. Professor Kiayias, Chief Scientist at IOHK, had been invited to the university to give a talk on his work on [Ouroboros, a provably secure Proof-of-Stake algorithm](tmp//en/research/papers/a-provably-secure-proof-of-stake-blockchain-protocol/ "Ouroboros Proof-of-Stake paper") for blockchain.

It the first time such a cryptographic protocol has been devised and is significant because its use would enable blockchains to process many more transactions, giving the technology the muscle that would scale it up for far wider use than at present.

![Aggelos Kiayias](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.009.jpeg)

â€œBitcoin is slow,â€ he said in the presentation, in an outline of the problem. â€œThe transactions per second of Visa are in the order of many thousands, for Paypal in the order of hundreds, and Bitcoin is far less than that â€“ clearly thatâ€™s something that canâ€™t scale to a global level.â€

"Bitcoin chậm," ông nói trong bài thuyết trình, trong một phác thảo về vấn đề.
"Các giao dịch mỗi giây của thị thực theo thứ tự của hàng ngàn người, đối với PayPal theo thứ tự hàng trăm, và Bitcoin ít hơn nhiều so với cấp độ đó
.â €

In addition to the much greater efficiency of Ouroboros, Prof Kiayias explained a novel reward mechanism for incentivising the protocol and used game theory to show why attacks such as selfish mining and block withholding would be neutralised.

Ngoài hiệu quả lớn hơn nhiều của Ouroboros, Giáo sư Kiayias đã giải thích một cơ chế thưởng mới để khuyến khích giao thức và lý thuyết trò chơi đã sử dụng để cho thấy lý do tại sao các cuộc tấn công như khai thác ích kỷ và giữ lại khối sẽ bị vô hiệu hóa.

A Nash equilibrium is a prescription of a strategy for each rational player, with the property that if other players follow it, it does not make sense for a rational player to deviate from it.

Cân bằng Nash là một đơn thuốc của một chiến lược cho mỗi người chơi hợp lý, với tài sản mà nếu những người chơi khác tuân theo nó, thì không có ý nghĩa gì đối với một người chơi hợp lý để đi chệch khỏi nó.

Prof Kiayias described how Ouroboros can be proven to be an approximate Nash equilibrium, thus distinguishing this blockchain system from Bitcoin, which is known to be not incentive compatible.

Giáo sư Kiayias đã mô tả làm thế nào ouroboros có thể được chứng minh là một trạng thái cân bằng gần đúng của Nash, do đó phân biệt hệ thống blockchain này với Bitcoin, được biết là không tương thích.

The Ouroboros paper was first published last December with Alexander Russel, Bernardo David and Roman Oliynykov and Prof Kiayias presented the work at the [Alan Turing Institute](https://www.youtube.com/watch?v=whdUSchadEs "Aggelos Kiayias at the Alan Turing Institute") in London last year.

Bài báo Ouroboros được xuất bản lần đầu vào tháng 12 năm ngoái với Alexander Russel, Bernardo David và Roman Oliynykov và Giáo sư Kiayias đã trình bày tác phẩm tại [Viện Alan Turing] (https://www.youtube.com/watch?v=
Viện Alan Turing ") ở London năm ngoái.

![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.010.jpeg)

A new version of the Ouroboros technical report will be available as early as next week, and will contain updated benchmarks that illustrate the performance benefits of the protocol.

Một phiên bản mới của báo cáo kỹ thuật OuroBoros sẽ có sẵn vào đầu tuần tới và sẽ chứa các điểm chuẩn được cập nhật minh họa lợi ích hiệu suất của giao thức.

Among the audience was Hayyu Imanda, whose desire to specialise in cryptography for her PhD studies brought her to hear the presentation. The 22-year-old is currently in a class of 26 students at Oxford university studying for an MSc in Mathematics and Foundations of Computer Science.

Trong số các khán giả có Hayyu Imanda, người có mong muốn chuyên về mật mã cho các nghiên cứu tiến sĩ của cô đã đưa cô đến nghe bài thuyết trình.
Cầu thủ 22 tuổi này hiện đang ở trong một lớp 26 sinh viên tại Đại học Oxford đang học thạc sĩ toán học và nền tảng của khoa học máy tính.

â€œI come from a pure maths background and I find cryptography very interesting, in that it was relatively recently founded and there is so much research happening,â€ she says. â€œI see it as a bridge from pure maths into real life, with many uses in terms of security, and itâ€™s going to be a growing field.â€

"Tôi đến từ một nền tảng toán học thuần túy và tôi thấy mật mã rất thú vị, ở chỗ nó được thành lập gần đây và có rất nhiều nghiên cứu xảy ra, cô nói.
"Tôi thấy nó như một cây cầu từ toán học thuần túy vào cuộc sống thực, với nhiều công dụng về mặt bảo mật, và nó sẽ là một lĩnh vực đang phát triển."

## **Attachments**

## ** tệp đính kèm **

![](img/2017-02-16-a-proof-of-stake-lecture-at-oxford-university.004.png)[ A Proof-of-Stake lecture at Oxford university - Input Output](https://ucarecdn.com/2908eb3c-4d42-41bb-b0e5-4d571219acf0/-/inline/yes/ "A Proof-of-Stake lecture at Oxford university - Input Output")

