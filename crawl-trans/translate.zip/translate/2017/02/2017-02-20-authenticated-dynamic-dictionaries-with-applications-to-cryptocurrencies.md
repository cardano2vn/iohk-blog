# Authenticated Dynamic Dictionaries, with Applications to Cryptocurrencies
![](img/2017-02-20-authenticated-dynamic-dictionaries-with-applications-to-cryptocurrencies.002.png) 20 February 2017![](img/2017-02-20-authenticated-dynamic-dictionaries-with-applications-to-cryptocurrencies.002.png)[ Alexander Chepurnoy](tmp//en/blog/authors/alexander-chepurnoy/page-1/)![](img/2017-02-20-authenticated-dynamic-dictionaries-with-applications-to-cryptocurrencies.003.png) 3 mins read

![Alexander Chepurnoy](img/2017-02-20-authenticated-dynamic-dictionaries-with-applications-to-cryptocurrencies.004.png)[](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
### [**Alexander Chepurnoy**](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
Research Fellow

Team Scorex Manager

- ![](img/2017-02-20-authenticated-dynamic-dictionaries-with-applications-to-cryptocurrencies.005.png)[](https://www.youtube.com/watch?v=Pxu4gpuVnQE "YouTube")
- ![](img/2017-02-20-authenticated-dynamic-dictionaries-with-applications-to-cryptocurrencies.006.png)[](https://twitter.com/chepurnoy "Twitter")
- ![](img/2017-02-20-authenticated-dynamic-dictionaries-with-applications-to-cryptocurrencies.007.png)[](https://github.com/kushti "GitHub")

Our paper ["Improving Authenticated Dynamic Dictionaries, with Applications to Cryptocurrencies"](https://eprint.iacr.org/2016/994) will appear at the [Financial Cryptography 2017](http://fc17.ifca.ai/program.html "Financial Cryptography conference") conference in Malta in April. It was also presented at the Real World Crypto 2017 conference in New York and I highly recommend watching the impressive [presentation from Leonid Reyzin](https://www.youtube.com/watch?v=PHY7JnLrK5o "Improving Authenticated Dynamic Dictionaries"), professor of computer science at Boston University and one of the four authors of the paper.

Bài viết của chúng tôi ["Cải thiện từ điển động được xác thực, với các ứng dụng cho tiền điện tử"] (https://eprint.iacr.org/2016/994) sẽ xuất hiện tại [Cryptography 2017] (http://fc17.ifca.ai/
Chương trình.html Hội nghị "Cryptography") Chương trình tại Malta vào tháng Tư.
Nó cũng được trình bày tại Hội nghị thực tế thế giới 2017 ở New York và tôi khuyên bạn nên xem bài thuyết trình ấn tượng [từ Leonid Reyzin] (https://www.youtube.com/watch?v=Phy7Jnlrk5o "Cải thiện từ điển động được xác thực")
, Giáo sư Khoa học Máy tính tại Đại học Boston và một trong bốn tác giả của bài báo.

Some background. Previously I worked for the [Nxt platform](https://nxt.org/ "Nxt.org") which has assets and many more cool features. The problem is, the blockchain processing becomes incredibly heavyweight (considering the pretty low number of transactions, in comparison with Bitcoin) with new features added. The same problem with Ethereum these days - after the attacks in autumn, it is nearly impossible to wait until processing being finished on an ordinary laptop.

Một số nền tảng.
Trước đây tôi đã làm việc cho [nền tảng NXT] (https://nxt.org/ "nxt.org") có tài sản và nhiều tính năng thú vị hơn.
Vấn đề là, quá trình xử lý blockchain trở nên cực kỳ nặng (xem xét số lượng giao dịch khá thấp, so với Bitcoin) với các tính năng mới được thêm vào.
Vấn đề tương tự với Ethereum những ngày này - sau các cuộc tấn công vào mùa thu, gần như không thể chờ đợi cho đến khi xử lý được hoàn thành trên một máy tính xách tay thông thường.

The problem is in a state (e.g. UTXO set in Bitcoin) persistence. Once it hits a secondary storage (HDD or SSD), processing becomes very slow.

Vấn đề nằm ở trạng thái (ví dụ: UTXO được đặt trong Bitcoin).
Khi nó đạt được bộ nhớ thứ cấp (ổ cứng hoặc SSD), việc xử lý trở nên rất chậm.

Thus two considerations behind our work on AVL+ trees and a proposed scheme for cryptocurrencies:

Do đó, hai cân nhắc đằng sau công việc của chúng tôi trên cây AVL+ và sơ đồ đề xuất cho tiền điện tử:

- It should be feasible to run a full-node (maybe not a mining node) on commodity hardware

- Không khả thi để chạy một nút đầy đủ (có thể không phải là nút khai thác) trên phần cứng hàng hóa

- Initial blockchain processing, and then block processing must use RAM only

- Xử lý blockchain ban đầu, và sau đó xử lý chặn chỉ sử dụng RAM

As commodity hardware is pretty limited in RAM, the idea is not to store the state for full-nodes at all. The scheme is as follows:

Vì phần cứng hàng hóa khá hạn chế trong RAM, nên ý tưởng không phải là lưu trữ trạng thái cho các nút đầy đủ.
Đề án như sau:

1. The state is authenticated with the help of a 2-party dynamic authenticated dictionary.

1. Trạng thái được xác thực với sự trợ giúp của từ điển được xác thực động 2 bên.

1. A mining node is storing the whole state. When packing transactions into a block, it generates proofs of the authenticated state transformations and announces a new root hash after the transformations being done in a blockheader. Proofs are to be included into the block.

1. Một nút khai thác đang lưu trữ toàn bộ trạng thái.
Khi đóng gói các giao dịch thành một khối, nó sẽ tạo ra các bằng chứng về các phép biến đổi trạng thái được xác thực và thông báo một hàm băm mới sau khi các phép biến đổi được thực hiện trong một blockheader.
Bằng chứng sẽ được đưa vào khối.

1. A full-node receiving the block checks that 1) Transactions are correct (format and signatures are correct etc) 2) State transformation operations derived from the transactions are corresponding to the proofs 3) Proofs are correct 4) Resulting roothash (a verifier is getting it just by processing proofs) is the same as the announced one. Thus the node is checking everything, but without holding the state (e.g. UTXO set).

1. Một nút đầy đủ nhận được kiểm tra khối rằng 1) giao dịch là chính xác (định dạng và chữ ký là chính xác, v.v.) 2) Các hoạt động chuyển đổi trạng thái có nguồn gốc từ các giao dịch tương ứng với bằng chứng 3) Bằng chứng là chính xác 4) dẫn đến ROTHASH (một trình xác minh
đang nhận được nó chỉ bằng cách xử lý bằng chứng) giống như cái được công bố.
Do đó, nút đang kiểm tra mọi thứ, nhưng không giữ trạng thái (ví dụ: bộ UTXO).

Then the paper is about to find a most efficient structure out of many candidates (and the winner is custom-tailored authenticated AVL+ trees).

Sau đó, bài báo sắp tìm thấy một cấu trúc hiệu quả nhất trong số nhiều ứng cử viên (và người chiến thắng là cây AVL+ được xác thực tùy chỉnh).

Not mentioned in the paper but worth mentioning is that proofs in a block could be authenticated themselves (with the help of a Merkle tree which is perfect for static data) with a root hash included in a blockheader. Then if node is holding the state it could skip downloading proofs from the network, also there is possibility to prune them in the future (this scheme reminds me of the SegWit proposal for Bitcoin).

Không được đề cập trong bài báo nhưng đáng nói là các bằng chứng trong một khối có thể được xác thực (với sự trợ giúp của một cây Merkle hoàn hảo cho dữ liệu tĩnh) với một hàm băm gốc được bao gồm trong một blockheader.
Sau đó, nếu Node đang giữ trạng thái, nó có thể bỏ qua các bằng chứng tải xuống từ mạng, thì cũng có khả năng cắt tỉa chúng trong tương lai (chương trình này làm tôi nhớ đến đề xuất SEGWIT cho Bitcoin).

Proofs are adding a significant burden regarding block size (actually a proof can be longer than the corresponding transaction), so decreased throughput is to be considered seriously.

Bằng chứng đang thêm một gánh nặng đáng kể liên quan đến kích thước khối (thực tế là một bằng chứng có thể dài hơn giao dịch tương ứng), do đó, thông lượng giảm sẽ được xem xét nghiêm túc.

The code had been released [on GitHub](https://github.com/input-output-hk/scrypto "GitHub code") during RealWorldCrypto â€“ see the section on authenticated data structures. There are some possible further minor optimizations (possibly reducing proof size by few percent in total) we are now discussing.

Mã đã được phát hành [trên GitHub] (https://github.com/input-output-hk/scrypto "mã github") trong realworldcrypto-Xem phần về cấu trúc dữ liệu được xác thực.
Có một số tối ưu hóa nhỏ hơn nữa (có thể giảm tổng số phần trăm bằng chứng bằng chứng) mà chúng ta hiện đang thảo luận.

