# Smart contracts conference starts in Athens
![](img/2017-03-31-smart-contracts-conference-starts-in-athens.002.png) 31 March 2017![](img/2017-03-31-smart-contracts-conference-starts-in-athens.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2017-03-31-smart-contracts-conference-starts-in-athens.003.png) 4 mins read

![](img/2017-03-31-smart-contracts-conference-starts-in-athens.004.png)[ Smart contracts conference starts in Athens - Input Output](https://ucarecdn.com/4553482e-aba0-40d4-bf4b-4cb75af5cbcc/-/inline/yes/ "Smart contracts conference starts in Athens - Input Output")

![Jeremy Wood](img/2017-03-31-smart-contracts-conference-starts-in-athens.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2017-03-31-smart-contracts-conference-starts-in-athens.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2017-03-31-smart-contracts-conference-starts-in-athens.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2017-03-31-smart-contracts-conference-starts-in-athens.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![Smart contracts conference starts in Athens](img/2017-03-31-smart-contracts-conference-starts-in-athens.009.jpeg)

Experts in law and cryptography are speaking today at a [smart contracts](tmp//en/blog/thoughts-on-an-ontology-for-smart-contracts/ "Thoughts on an ontology for smart contracts") day in Athens, organised by IOHK chief scientist [Aggelos Kiayias](tmp//en/team/aggelos-kiayias/ "Aggelos Kiayias, IOHK profile"), chair of cyber security and privacy at the University of Edinburgh as well as director of its Blockchain Technology Laboratory. Smart contracts are an emerging technology that run on the same infrastructure that supports Bitcoin: a blockchain. They are digital legal contracts between parties that rely not on the traditional rule of law and institutions such as legal offices and courts, but on cryptography. Professor Aggelos Kiayias says: "To understand the technology it is useful to contrast cryptography and law. Law regulates interactions between persons ensuring fairness and basic rights. In this way, law offers protection from other persons with conflicting interests by relying on rule of law and social institutions. On the other hand, cryptography is the science of redistributing trust in any system that emerges from the interaction of multiple persons. It also protects people from other persons with conflicting interests but its protection is achieved by relying on hard mathematical problems."

Các chuyên gia về luật và mật mã đang phát biểu hôm nay tại [Hợp đồng thông minh] (TMP // EN/Blog/Suy nghĩ trên một bản thể học đối với các hợp đồng thông minh/"Suy nghĩ về bản thể học cho các hợp đồng thông minh") Được tổ chức bởi nhà khoa học trưởng của IOHK [Aggelos Kiayias] (TMP // EN/Team/Aggelos-Kiayias/"Aggelos Kiayias, hồ sơ IOHK") . Hợp đồng thông minh là một công nghệ mới nổi chạy trên cùng một cơ sở hạ tầng hỗ trợ Bitcoin: một blockchain. Chúng là các hợp đồng pháp lý kỹ thuật số giữa các bên không dựa vào luật pháp truyền thống của pháp luật và các tổ chức như văn phòng pháp lý và tòa án, mà là vào mật mã. Giáo sư Aggelos Kiayias nói: "Để hiểu công nghệ, thật hữu ích khi đối chiếu mật mã và luật pháp. Luật điều chỉnh sự tương tác giữa những người đảm bảo sự công bằng và các quyền cơ bản. Theo cách này, luật pháp bảo vệ từ những người khác có lợi ích xung đột bằng cách dựa vào luật pháp và luật pháp và Mặt khác, các tổ chức xã hội, mật mã là khoa học phân phối lại niềm tin vào bất kỳ hệ thống nào xuất hiện từ sự tương tác của nhiều người. Nó cũng bảo vệ người dân khỏi những người khác có lợi ích mâu thuẫn nhưng sự bảo vệ của nó đạt được bằng cách dựa vào các vấn đề toán học khó khăn. "

So how do smart contracts work? Prof Kiayias again: "A smart contract is a piece of code written in a formal language that records all terms for a certain engagement. It has the power to self execute when certain conditions are triggered and can enforce its outcomes in a cryptographic sense. There is a multitude of smart contract applications in areas such as intellectual property, financial instruments, rental and leasing agreements and others."

Vậy hợp đồng thông minh hoạt động như thế nào?
Giáo sư Kiayias một lần nữa: "Hợp đồng thông minh là một đoạn mã được viết bằng ngôn ngữ chính thức ghi lại tất cả các điều khoản cho một sự tham gia nhất định. Nó có khả năng tự thực hiện khi một số điều kiện được kích hoạt và có thể thực thi kết quả của nó theo nghĩa mật mã. Có.
là vô số ứng dụng hợp đồng thông minh trong các lĩnh vực như sở hữu trí tuệ, công cụ tài chính, thỏa thuận cho thuê và cho thuê và các ứng dụng khác. "

Also speaking at the conference are [Charles Hoskinson](tmp//en/team/charles-hoskinson/ "Charles Hoskinson, IOHK profile"), IOHK CEO and Co-Founder; Burkard Schafer, Professor of Computational Legal Theory and director of the SCRIPT Centre for IT and IP law at the University of Edinburgh; Peter Van Valkenburgh, Director of Research at Coin Center; and Christoph Sorge, holder of the juris professorship of legal informatics, co-director of the Institute for Law and Informatics, and member of the Center for IT Security, Privacy and Accountability at Saarland University.

Cũng phát biểu tại hội nghị là [Charles Hoskinson] (TMP // EN/Team/Charles-Hoskinson/"Charles Hoskinson, hồ sơ IOHK"), Giám đốc điều hành IOHK và đồng sáng lập;
Burkard Schafer, Giáo sư Lý thuyết pháp lý tính toán và Giám đốc Trung tâm Kịch bản về Luật CNTT và IP tại Đại học Edinburgh;
Peter Van Valkenburgh, Giám đốc nghiên cứu tại Trung tâm Coin;
và Christoph Sorge, người giữ giáo sư luật học về tin học pháp lý, đồng giám đốc của Viện Luật và Tin học, và là thành viên của Trung tâm Bảo mật CNTT, quyền riêng tư và trách nhiệm tại Đại học Saarland.

[Darryl McAdams](tmp//en/team/darryl-mcadams/ "Darryl McAdams, IOHK profile"), IOHK's Team Plutus manager is working on a new programming language for smart contracts (Plutus) and is in Athens for the conference. According to Darryl, "A smart contract is a program which can implement an agreement of one form or another between multiple parties. They can be simple transfers of money, contracts in the traditional sense involving rights and obligations of various parties, or things more complex such as a game of chess, a distributed library, or a decentralized DNS system. In all of these cases, the purpose and behaviour of the system needs to be well understood, and in many cases, such as financial contracts with large sums of money involved, the correctness of the program is absolutely vital. In my talk, I will discuss the design of the Plutus language, a new programming language for authoring smart contracts, and demonstrate its use. I'll also discuss the motivation behind its design, especially with a view towards correct implementation of a contract's purpose and behaviour."

. Theo Darryl, "Hợp đồng thông minh là một chương trình có thể thực hiện thỏa thuận của hình thức này hay biểu mẫu khác giữa nhiều bên. Họ có thể chuyển tiền đơn giản, hợp đồng theo nghĩa truyền thống liên quan đến quyền và nghĩa vụ của các bên khác nhau, hoặc những điều phức tạp hơn chẳng hạn như một trò chơi cờ vua, thư viện phân tán hoặc hệ thống DNS phi tập trung. Trong tất cả các trường hợp này, mục đích và hành vi của hệ thống cần phải được hiểu rõ, và trong nhiều trường hợp, chẳng hạn như hợp đồng tài chính với số tiền lớn Tham gia, tính chính xác của chương trình là hoàn toàn quan trọng. đặc biệt là với quan điểm hướng tới việc thực hiện chính xác mục đích và hành vi của hợp đồng. "

The event â€“ "Smart Contracts Day, Cryptography & Law: Information, Privacy and Smart Contracts" â€“ is taking place at the Hotel Divani Caravel, in central Athens. It is highly anticipated and currently sold out with more than 200 participants. Hereâ€™s more information: [law.bitcoinschool.gr](https://law.bitcoinschool.gr "law.bitcoinschool.gr")

Sự kiện này "Ngày hợp đồng thông minh, mật mã & luật: thông tin, quyền riêng tư và hợp đồng thông minh" - đang diễn ra tại khách sạn Divani Caravel, ở trung tâm Athens.
Nó rất được mong đợi và hiện đang bán hết với hơn 200 người tham gia.
Đây là thông tin thêm: [Law.bitcoinschool.gr] (https://law.bitcoinschool.gr "Law.bitcoinschool.gr")

Prof Kiayias concludes: "In the near future, this technology will give rise to "cryptolegal" frameworks, that, by merging cryptography and law, will be able to regulate interactions of persons at a global scale. In this way, such frameworks will transcend geographic and jurisdictional boundaries and create a dynamic global social institution that belongs to all and can be abused by none."

Giáo sư Kiayias kết luận: "Trong tương lai gần, công nghệ này sẽ tạo ra các khung" Cryptolegal ", bằng cách hợp nhất mật mã và luật pháp, sẽ có thể điều chỉnh các tương tác của người ở quy mô toàn cầu. Theo cách này, các khung như vậy sẽ vượt qua
Các ranh giới địa lý và tài phán và tạo ra một tổ chức xã hội toàn cầu năng động thuộc về tất cả và có thể bị lạm dụng bởi không có ai. "

## **Attachments**

## ** tệp đính kèm **

![](img/2017-03-31-smart-contracts-conference-starts-in-athens.004.png)[ Smart contracts conference starts in Athens - Input Output](https://ucarecdn.com/4553482e-aba0-40d4-bf4b-4cb75af5cbcc/-/inline/yes/ "Smart contracts conference starts in Athens - Input Output")

