# Proof refinement basics
![](img/2017-03-07-proof-refinement-basics.002.png) 7 March 2017![](img/2017-03-07-proof-refinement-basics.002.png)[ Rebecca Valentine](tmp//en/blog/authors/rebecca-valentine/page-1/)![](img/2017-03-07-proof-refinement-basics.003.png) 19 mins read

![](img/2017-03-07-proof-refinement-basics.004.png)[ Proof Refinement Basics - Input Output](https://ucarecdn.com/acd33d70-27c0-4e24-b150-0be8c5721402/-/inline/yes/ "Proof Refinement Basics - Input Output")

![Rebecca Valentine](img/2017-03-07-proof-refinement-basics.005.png)[](tmp//en/blog/authors/rebecca-valentine/page-1/)
### [**Rebecca Valentine**](tmp//en/blog/authors/rebecca-valentine/page-1/)
Cardano SL Developer Team

Plutus Manager

- ![](img/2017-03-07-proof-refinement-basics.006.png)[](https://github.com/psygnisfive "GitHub")

![Proof refinement basics](img/2017-03-07-proof-refinement-basics.007.jpeg)

In this blog post, I'm going to discuss the overall structure of a proof refinement system. Such systems can be used for implementing automatic theorem provers, proof assistants, and type checkers for programming languages. The proof refinement literature is either old or hard to understand, so this post, and subsequent ones on the same topic, will present it in a more casual and current way. Work on proof refinement as a methodology for building type checkers and interactive proof systems has a long history, going back to LCF, HOL, Nuprl, and Coq. These techniques never really penetrated into the mainstream of programming language implementation, but perhaps this may change.

Trong bài đăng trên blog này, tôi sẽ thảo luận về cấu trúc tổng thể của một hệ thống sàng lọc bằng chứng.
Các hệ thống như vậy có thể được sử dụng để thực hiện các provers định lý tự động, trợ lý chứng minh và người kiểm tra loại cho các ngôn ngữ lập trình.
Các tài liệu sàng lọc bằng chứng là cũ hoặc khó hiểu, vì vậy bài đăng này, và những bài tiếp theo về cùng một chủ đề, sẽ trình bày nó theo cách giản dị và hiện tại hơn.
Làm việc về sự tinh chỉnh bằng chứng như một phương pháp cho người kiểm tra loại xây dựng và các hệ thống chứng minh tương tác có một lịch sử lâu dài, quay trở lại LCF, HOL, NUPRL và CoQ.
Những kỹ thuật này không bao giờ thực sự thâm nhập vào dòng chính của việc thực hiện ngôn ngữ lập trình, nhưng có lẽ điều này có thể thay đổi.

The GitHub repo for this project can be found [here](https://github.com/psygnisfive/proof-refinement-basics).

Có thể tìm thấy repo github cho dự án này [tại đây] (https://github.com/psygnisfive/proof-refinement-basics).

## **Prologue**

## ** Prologue **

As part of my work for IOHK, I've been designing and implementing a programming language called Plutus, which we use as the scripting language for our blockchains. Because IOHK cares deeply about the correctness of its systems, Plutus needs to be held to a very high standard, and needs to enable easy reasoning about its behavior. For that reason, I chose to make Plutus a pure, functional language with a static type system. Importantly, the language has a formal type theoretic specification.

Là một phần trong công việc của tôi cho IOHK, tôi đã thiết kế và thực hiện một ngôn ngữ lập trình có tên Plutus, mà chúng tôi sử dụng làm ngôn ngữ kịch bản cho các blockchain của chúng tôi.
Bởi vì IOHK quan tâm sâu sắc đến tính chính xác của các hệ thống của mình, Plutus cần phải được giữ theo tiêu chuẩn rất cao và cần cho phép lý luận dễ dàng về hành vi của nó.
Vì lý do đó, tôi đã chọn biến Plutus thành một ngôn ngữ tinh khiết, chức năng với một hệ thống tĩnh.
Điều quan trọng, ngôn ngữ có một đặc điểm lý thuyết chính thức.

To implement the type checker for the language, I used a fairly standard technique. However, recently I built a new framework for implementing programming languages which, while different from the usual way, has a more direct connection to the formal specification. This greater similarity makes it easier to check that the implementation is correct.

Để thực hiện trình kiểm tra loại cho ngôn ngữ, tôi đã sử dụng một kỹ thuật khá chuẩn.
Tuy nhiên, gần đây tôi đã xây dựng một khung mới để triển khai các ngôn ngữ lập trình, trong khi khác với cách thông thường, có kết nối trực tiếp hơn với đặc điểm kỹ thuật chính thức.
Sự tương đồng lớn hơn này giúp kiểm tra việc thực hiện dễ dàng hơn.

The framework also makes a number of bugs easier to eliminate. One class of bugs that arose a number of times in the first implementation was that of metavariables and unification. Because the language supports a certain about of unification-driven type inference, it's necessary to propagate updates to the information state of the type checking algorithm, so that everything is maximally informative and the algorithm can run correctly. Propagating this information by hand is error prone, and the new framework makes it possible to do it once and for all, in a bug-free way.

Khung cũng làm cho một số lỗi dễ dàng hơn để loại bỏ.
Một loại lỗi phát sinh một số lần trong lần thực hiện đầu tiên là các metavaria và thống nhất.
Bởi vì ngôn ngữ hỗ trợ một số suy luận loại định hướng thống nhất, nên cần truyền các bản cập nhật đến trạng thái thông tin của thuật toán kiểm tra loại, để mọi thứ có nhiều thông tin và thuật toán có thể chạy chính xác.
Truyền thông tin này bằng tay là dễ bị lỗi và khung mới giúp nó có thể thực hiện nó một lần và mãi mãi, theo một cách không có lỗi.

The framework additionally makes some features easier to program. For example, good error reporting is extremely important. But good error messages need to have certain information about where the error occurs. Not just where in the source code, but where in the logical structure of the program. All sorts of important information about the nature of the error, and the possible solutions, depend on that. The framework I developed also makes this incredibly easy to implement, so much so that it's build right into the system, and any language implemented using it can take advantage of it.

Khung cũng làm cho một số tính năng dễ dàng hơn để lập trình.
Ví dụ, báo cáo lỗi tốt là vô cùng quan trọng.
Nhưng thông báo lỗi tốt cần phải có thông tin nhất định về nơi xảy ra lỗi.
Không chỉ ở đâu trong mã nguồn, mà ở đâu trong cấu trúc logic của chương trình.
Tất cả các loại thông tin quan trọng về bản chất của lỗi và các giải pháp có thể, phụ thuộc vào đó.
Khung tôi phát triển cũng giúp việc thực hiện này cực kỳ dễ dàng, đến nỗi nó được xây dựng ngay vào hệ thống và bất kỳ ngôn ngữ nào được triển khai bằng cách sử dụng nó có thể tận dụng nó.

### **Proofs and Proof Systems**

### ** Bằng chứng và hệ thống chứng minh **

In the context of modern proof theory and type theory, a proof can be seen as a tree structure with labeled nodes and the class of proof trees which are valid is defined by a set of rules that specify how a node in a tree may relate to its child nodes. The labels, in the context of proofs, are usually hypothetical judgments, and the rules are inference rules, but you can also use the same conceptual framework for many other things.

Trong bối cảnh của lý thuyết bằng chứng hiện đại và lý thuyết loại
các nút con của nó.
Các nhãn, trong bối cảnh bằng chứng, thường là các phán đoán giả thuyết và các quy tắc là các quy tắc suy luận, nhưng bạn cũng có thể sử dụng cùng một khung khái niệm cho nhiều thứ khác.

An example of a rule is for any choice of A and B, if you can show that A is true and that B is true, then it's permissible to conclude Aâˆ§B is true. This is usually written with the notation

Một ví dụ về một quy tắc là cho bất kỳ sự lựa chọn nào của A và B, nếu bạn có thể chỉ ra rằng A là đúng và B là đúng, thì có thể kết luận Aâˆ §B là đúng.
Điều này thường được viết với ký hiệu

![Maths](img/2017-03-07-proof-refinement-basics.008.png)

This rule explains one way that it's ok to have a node labeled 

Quy tắc này giải thích một cách rằng bạn có thể có một nút được dán nhãn

Aâˆ§B is true

Aâ là §b là đúng

