# Bidirectional proof refinement
![](img/2017-03-16-bidirectional-proof-refinement.002.png) 16 March 2017![](img/2017-03-16-bidirectional-proof-refinement.002.png)[ Rebecca Valentine](tmp//en/blog/authors/rebecca-valentine/page-1/)![](img/2017-03-16-bidirectional-proof-refinement.003.png) 18 mins read

![](img/2017-03-16-bidirectional-proof-refinement.004.png)[ Bidirectional proof refinement - Input Output](https://ucarecdn.com/9c520277-15b2-4ef1-81c7-8b671e87219e/-/inline/yes/ "Bidirectional proof refinement - Input Output")

![Rebecca Valentine](img/2017-03-16-bidirectional-proof-refinement.005.png)[](tmp//en/blog/authors/rebecca-valentine/page-1/)
### [**Rebecca Valentine**](tmp//en/blog/authors/rebecca-valentine/page-1/)
Cardano SL Developer Team

Plutus Manager

- ![](img/2017-03-16-bidirectional-proof-refinement.006.png)[](https://github.com/psygnisfive "GitHub")

In [my last blog post](tmp//en/blog/proof-refinement-basics/ "Proof refinement basics, IOHK blog"), we looked at the very basics of proof refinement systems. I noted at the end that there was a big drawback of the systems as shown, namely that information flows only in one direction: from the root of a proof tree to the leaves. In this post, we'll see how to get information to flow in the opposite direction as well. The code for this blog post can be found on GitHub [here](https://github.com/psygnisfive/bidirectional-proof-refinement "GitHub; Psygnisfive, Bidirectional proof refinement").

Trong [Bài đăng trên blog cuối cùng của tôi] (TMP // EN/Blog/Proof-Refinement-Basics/"Tái cấu trúc bằng chứng, blog IOHK"), chúng tôi đã xem xét những điều cơ bản của các hệ thống tinh chỉnh bằng chứng.
Tôi đã lưu ý rằng cuối cùng có một nhược điểm lớn của các hệ thống như được hiển thị, cụ thể là thông tin chỉ chảy theo một hướng: từ gốc của cây chứng minh đến lá.
Trong bài đăng này, chúng ta sẽ xem cách lấy thông tin theo hướng ngược lại.
Mã cho bài đăng trên blog này có thể được tìm thấy trên GitHub [tại đây] (https://github.com/psygnisfive/bidirectional-proof-refinement "github; psygnisfive, sàng lọc bằng chứng hai chiều").

### **Addition Again**

### ** bổ sung một lần nữa **

The addition judgment Plus which we defined last time was a three-argument judgment. The judgment Plus L M N was a claim that N is the sum of L and M. But we might want to instead think about specifying only some of the arguments to this judgment. In a language like Prolog, this is implemented by the use of metavariables which get valued in the course of computation. In the proof refinement setting, however, we take a different approach. Instead, we make use of a notion called bidirectionality, where we specify that a judgment's arguments can come in two modes: input and output. This is somewhat related to viewing thing from a functional perspective, but in a more non-deterministic or relational fashion.

Phán quyết bổ sung cộng với chúng tôi định nghĩa lần trước là một bản án ba mục đích.
Phán quyết cộng với l m n là một tuyên bố rằng N là tổng của L và M. nhưng thay vào đó chúng ta có thể muốn nghĩ về việc chỉ định một số lập luận cho phán quyết này.
Trong một ngôn ngữ như Prolog, điều này được thực hiện bằng cách sử dụng các metavaria được đánh giá cao trong quá trình tính toán.
Tuy nhiên, trong cài đặt sàng lọc bằng chứng, chúng tôi có một cách tiếp cận khác.
Thay vào đó, chúng tôi sử dụng một khái niệm gọi là tính hai chiều, trong đó chúng tôi chỉ định rằng các đối số của phán đoán có thể có hai chế độ: đầu vào và đầu ra.
Điều này có phần liên quan đến việc xem điều từ góc độ chức năng, nhưng theo kiểu không xác định hoặc quan hệ hơn.

Let's start by deciding that the mode of the first two arguments to Plus is that of input, and the third is output. This way we'll think about actually computing the sum of two numbers. Instead of three Nat inputs, we'll instead use only two. We'll use a judgment name that reflects which two:

Hãy bắt đầu bằng cách quyết định rằng chế độ của hai đối số đầu tiên cộng với đầu vào và thứ ba là đầu ra.
Bằng cách này, chúng ta sẽ nghĩ về việc thực sự tính toán tổng của hai số.
Thay vì ba đầu vào NAT, thay vào đó chúng tôi chỉ sử dụng hai đầu vào.
Chúng tôi sẽ sử dụng một tên phán quyết phản ánh hai:

-- Haskell

- Haskell

data Judgment = Plus12 Nat Nat

Phán quyết dữ liệu = Plus12 Nat Nat

`  `deriving (Show)

`` Deriving (Hiển thị)

// JavaScript

// JavaScript

function Plus12(x,y) {

hàm plus12 (x, y) {

`    `return { tag: "Plus12", args: [x,y] };

`` return {tag: "plus12", args: [x, y]};

}

}

The behavior of the decomposer for Plus12 will have to be slightly different now, though, because there are only two arguments. But additionally, we want to not only expand a goal into subgoals, but also somehow synthesize a result from the results of the subgoals. So where before we had only to map from a goal to some new goals, now we must also provide something that maps from some subresults to a result.

Tuy nhiên, hành vi của trình phân hủy cho Plus12 sẽ phải khác một chút, vì chỉ có hai đối số.
Nhưng ngoài ra, chúng tôi muốn không chỉ mở rộng một mục tiêu sang các khu vực, mà còn bằng cách nào đó tổng hợp một kết quả từ kết quả của các tiểu thể.
Vì vậy, trước khi chúng tôi chỉ phải ánh xạ từ mục tiêu đến một số mục tiêu mới, bây giờ chúng tôi cũng phải cung cấp một cái gì đó ánh xạ từ một số subresult đến kết quả.

Rather than giving two separate functions, we'll give a single function that returns both the new subgoals, and the function that composes a value from the values synthesized for those subgoals.

Thay vì đưa ra hai chức năng riêng biệt, chúng tôi sẽ cung cấp một hàm duy nhất trả về cả hai tiểu thể mới và hàm tạo ra một giá trị từ các giá trị được tổng hợp cho các phân nhóm đó.

-- Haskell

- Haskell

decomposePlus12 :: Nat -> Nat -> Maybe ([Judgment], [Nat] -> Nat)

decomposeplus12 :: nat -> nat -> có thể ([phán đoán], [nat] -> nat)

decomposePlus12 Zero y = Just ([], \zs -> y)

decomposeplus12 zero y = just ([], \ zs -> y)

decomposePlus12 (Suc x) y = Just ([Plus12 x y], \[z] -> Suc z)

DEST

decompose :: Judgment -> Maybe ([Judgment], [Nat] -> Nat)

Phá hủy :: Phán quyết -> Có thể ([Phán quyết], [Nat] -> Nat)

decompose (Plus12 x y) = decomposePlus12 x y

phân hủy (cộng 12 x y) = decomposeplus12 x y

// JavaScript

// JavaScript

function decomposePlus12(x,y) {

hàm decomposeplus12 (x, y) {

`    `if (x.tag === "Zero") {

`` if (x.tag === "Zero") {

`        `return Just([[], zs => y]);

`` trả về chỉ ([[], zs => y]);

`    `} else if (x.tag === "Suc") {

``} khác if (x.tag === "Suc") {

`        `return Just([[Plus12(x.arg,y)], zs => Suc(zs[0])]);

`` trả về chỉ ([[plus12 (x.arg, y)], zs => Suc (zs [0])]);

`    `}

``}

}

}

function decompose(j) {

chức năng phân tách (j) {

`    `if (j.tag === "Plus12") {

`` if (jtag === "cộng 12") {

`        `return decomposePlus12(j.args[0], j.args[1]);

`` return decomposeplus12 (j.args [0], j.args [1]);

`    `}

``}

}

}

The decompose function is somewhat redundant in this example, but the shape of the problem is preserved by having this redundancy. The same is true of the Maybe in the types. We can always decompose now, so the Nothing option is never used, but I'm keeping it here to maintain parallelism with the general framework.

Hàm phân tách có phần dư thừa trong ví dụ này, nhưng hình dạng của vấn đề được bảo tồn bằng cách có sự dư thừa này.
Điều tương tự cũng đúng với các loại có thể trong các loại.
Chúng ta luôn có thể phân hủy bây giờ, vì vậy tùy chọn không bao giờ được sử dụng, nhưng tôi giữ nó ở đây để duy trì sự song song với khung chung.

Building a proof tree in this setting proceeds very similarly to how it did before, except now we need to make use of the synthesis functions in parallel with building a proof tree:

Xây dựng một cây chứng minh trong cài đặt này tiến hành rất giống với cách nó đã làm trước đây, ngoại trừ bây giờ chúng ta cần sử dụng các hàm tổng hợp song song với việc xây dựng một cây chứng minh:

-- Haskell

- Haskell

findProof :: Judgment -> Maybe (ProofTree, Nat)

FindProof :: JUDGMED -> Có thể (ProofTree, Nat)

findProof j =

FindProof J =

`  `case decompose j of

`` Trường hợp phân hủy j của

`    `Nothing -> Nothing

`` Không có gì -> Không có gì

`    `Just (js, f) -> case sequence (map findProof js) of

`` Chỉ

`      `Nothing -> Nothing

`` Không có gì -> Không có gì

`      `Just tns -> let (ts, ns) = unzip tns

`` Chỉ là tns -> let (ts, ns) = unzip tns

`                  `in Just (ProofTree j ts, f ns)

`` Chỉ trong (ProofTree J TS, F NS)

// JavaScript

// JavaScript

function unzip(xys) {

hàm unzip (xys) {

`    `var xs = [];

`` var xs = [];

`    `var ys = [];

`` var ys = [];

`    `for (var i = 0; i < xys.length; i++) {

`` for (var i = 0; i <xys.length; i ++) {

`        `xs.push(xys[i][0]);

`` xs.push (xys [i] [0]);

`        `ys.push(xys[i][1]);

`` ys.push (Xys [i] [1]);

`    `}

``}

`    `return [xs,ys]

`` Trả lại [XS, YS]

}

}

function findProof(j) {

hàm findproof (j) {

`    `var mjs = decompose(j);

`` var mjs = phân hủy (j);

`    `if (mjs.tag === "Nothing") {

`` if (mjs.tag === "Không có gì") {

`        `return Nothing;

`` Không trả lại gì;

`    `} else if (mjs.tag === "Just") {

``} khác if (mjs.tag === "Chỉ") {

`        `var js = mjs.arg[0]

`` var js = mjs.arg [0]

`        `var f = mjs.arg[1]

`` var f = mjs.arg [1]

`        `var mtns = sequence(js.map(j => findProof(j)));

`` var mtns = sequence (js.map (j => findproof (j)));

`        `if (mtns.tag === "Nothing") {

`` if (mtns.tag === "Không có gì") {

`            `return Nothing;

`` Không trả lại gì;

`        `} else if (mtns.tag === "Just") {

``} khác if (mtns.tag === "Chỉ") {

`            `var tsns = unzip(mtns.arg);

`` var tsns = unzip (mtns.arg);

`            `return Just([ProofTree(j, tsns[0]), f(tsns[1])]);

`` trả về chỉ ([ProofTree (J, TSNS [0]), F (TSNS [1])]));

`        `}

``}

`    `}

``}

}

}

Now when we run this on some inputs, we get back not only a proof tree, but also the resulting value, which is the Nat that would have been the third argument of Plus in the previous version of the system.

Bây giờ khi chúng tôi chạy điều này trên một số đầu vào, chúng tôi sẽ quay lại không chỉ là một cây chứng minh, mà cả giá trị kết quả, đó là NAT sẽ là đối số thứ ba của Plus trong phiên bản trước của hệ thống.

Let's now add another judgment, Plus13, which will synthesize the second argument of the original Plus judgment from the other two. Therefore, the judgment Plus13 L N means L subtracted from N. We'll add this judgment to the existing Judgment declarations.

Bây giờ chúng ta hãy thêm một bản án khác, Plus13, sẽ tổng hợp đối số thứ hai của bản gốc cộng với bản án từ hai người kia.
Do đó, bản án Plus13 L n có nghĩa là L bị trừ khỏi N. Chúng tôi sẽ thêm phán quyết này vào các tuyên bố phán quyết hiện có.

-- Haskell

- Haskell

data Judgment = Plus12 Nat Nat | Plus13 Nat Nat

Phán quyết dữ liệu = Plus12 Nat Nat |
Plus13 Nat Nat

`  `deriving (Show)

`` Deriving (Hiển thị)

// JavaScript

// JavaScript

function Plus13(x,z) {

hàm plus13 (x, z) {

`    `return { tag: "Plus13", args: [x,z] };

`` return {tag: "plus13", args: [x, z]};

}

}

We can now define a decomposition function for this judgment. Notice that this one is partial, in that, for some inputs, there's no decomposition because the first argument is larger than the second. We'll also extend the decompose function appropriately.

Bây giờ chúng ta có thể xác định một chức năng phân hủy cho phán đoán này.
Lưu ý rằng cái này là một phần, trong đó, đối với một số đầu vào, không có sự phân tách vì đối số đầu tiên lớn hơn so với thứ hai.
Chúng tôi cũng sẽ mở rộng chức năng phân hủy một cách thích hợp.

-- Haskell

- Haskell

decomposePlus13 :: Nat -> Nat -> Maybe ([Judgment], [Nat] -> Nat)

decomposeplus13 :: nat -> nat -> có thể ([phán đoán], [nat] -> nat)

decomposePlus13 Zero z = Just ([], \xs -> z)

decomposeplus13 zero z = Just ([], \ xs -> z)

decomposePlus13 (Suc x) (Suc z) = Just ([Plus13 x z], \[x] -> x)

DEST

decomposePlus13 \_ \_ = Nothing

decomposeplus13 \ _ \ _ = không có gì

decompose :: Judgment -> Maybe ([Judgment], [Nat] -> Nat)

Phá hủy :: Phán quyết -> Có thể ([Phán quyết], [Nat] -> Nat)

decompose (Plus12 x y) = decomposePlus12 x y

phân hủy (cộng 12 x y) = decomposeplus12 x y

decompose (Plus13 x z) = decomposePlus13 x z

phân hủy (plus13 x z) = decomposeplus13 x z

// JavaScript

// JavaScript

function decomposePlus13(x,z) {

hàm decomposeplus13 (x, z) {

`    `if (x.tag === "Zero") {

`` if (x.tag === "Zero") {

`        `return Just([[], xs => z]);

`` trả về chỉ ([[], xs => z]);

`    `} else if (x.tag === "Suc" && z.tag === "Suc") {

``} khác if (x.tag === "Suc" && z.tag === "Suc") {

`        `return Just([[Plus13(x.arg, z.arg)], xs => xs[0]]);

`` trả về chỉ ([[plus13 (x.arg, z.arg)], xs => xs [0]]);

`    `} else {

``} khác {

`        `return Nothing;

`` Không trả lại gì;

`    `}

``}

}

}

function decompose(j) {

chức năng phân tách (j) {

`    `if (j.tag === "Plus12") {

`` if (jtag === "cộng 12") {

`        `return decomposePlus12(j.args[0], j.args[1]);

`` return decomposeplus12 (j.args [0], j.args [1]);

`    `} else if (j.tag === "Plus13") {

``} khác if (jtag === "cộng 13") {

`        `return decomposePlus13(j.args[0], j.args[1]);

`` return decomposeplus13 (J.ARGS [0], J.ARGS [1]);

`    `}

``}

}

}

If we now try to find a proof for Plus13 (Suc Zero) (Suc (Suc (Suc Zero))), we get back Suc (Suc Zero), as expected, because 1 subtracted from 3 is 2. Similarly, if we try to find a proof for Plus13 (Suc (Suc Zero)) (Suc Zero), we find that we get no proof, because we can't subtract a number from something smaller than it.

Nếu bây giờ chúng ta cố gắng tìm một bằng chứng cho Plus13 (Suc Zero) (Suc (Suc không)), chúng ta sẽ trở lại Suc
Để tìm bằng chứng cho Plus13 (Suc (Suc Zero)) (Suc Zero), chúng tôi thấy rằng chúng tôi không nhận được bằng chứng, bởi vì chúng tôi không thể trừ một số từ một cái gì đó nhỏ hơn nó.

### **Type Checking Again**

### ** Kiểu kiểm tra lại **

We'll aim to do the same thing with the type checker as we did with addition. We'll split the HasType judgment into two judgments, Check and Synth. The Check judgment will be used precisely in those cases where a type must be provided for the proof to go through, while the Synth judgment will be used for cases where the structure of the program is enough to tell us its type.

Chúng tôi sẽ đặt mục tiêu làm điều tương tự với người kiểm tra loại như chúng tôi đã làm với bổ sung.
Chúng tôi sẽ chia phán quyết của Hastype thành hai bản án, kiểm tra và synth.
Phán quyết kiểm tra sẽ được sử dụng chính xác trong những trường hợp phải cung cấp một loại cho bằng chứng đi qua, trong khi bản án tổng hợp sẽ được sử dụng cho các trường hợp cấu trúc của chương trình là đủ để cho chúng ta biết loại của nó.

-- Haskell

- Haskell

data Judgment = Check [(String,Type)] Program Type

Dữ liệu phán đoán = Kiểm tra [(chuỗi, loại)] Loại chương trình

`              `| Synth [(String,Type)] Program

`` |
Chương trình synth [(chuỗi, loại)]

`  `deriving (Show)

`` Deriving (Hiển thị)

// JavaScript

// JavaScript

function Check(g,m,a) {

Kiểm tra chức năng (g, m, a) {

`    `return { tag: "Check", args: [g,m,a] };

`` return {tag: "kiểm tra", args: [g, m, a]};

}

}

function Synth(g,m) {

function synth (g, m) {

`    `return { tag: "Synth", args: [g,m] };

`` return {tag: "synth", args: [g, m]};

}

}

Additionally, because of these changes in information flow, we'll remove some type annotations from the various program forms, and instead introduce a general type annotation form that will be used to shift between judgments explicitly.

Ngoài ra, do những thay đổi trong luồng thông tin này, chúng tôi sẽ xóa một số chú thích loại khỏi các mẫu chương trình khác nhau và thay vào đó giới thiệu một hình thức chú thích loại chung sẽ được sử dụng để thay đổi giữa các phán đoán.

-- Haskell

- Haskell

data Program = Var String | Ann Program Type

Chương trình dữ liệu = chuỗi var |
Loại chương trình ANN

`             `| Pair Program Program | Fst Program | Snd Program

`` |
Chương trình cặp đôi |
Chương trình FST |
Chương trình SND

`             `| Lam String Program | App Program Program

`` |
Chương trình Chuỗi Lam |
Chương trình ứng dụng chương trình

`  `deriving (Show)

`` Deriving (Hiển thị)

// JavaScript

// JavaScript

function Var(x) {

hàm var (x) {

`    `return { tag: "Var", arg: x };

`` return {tag: "var", arg: x};

}

}

function Ann(m,a) {

hàm ann (m, a) {

`    `return { tag: "Ann", args: [m,a] };

`` return {tag: "ann", args: [m, a]};

}

}

function Pair(m,n) {

cặp chức năng (m, n) {

`    `return { tag: "Pair", args: [m,n] };

`` return {tag: "cặp", args: [m, n]};

}

}

function Fst(m) {

hàm fst (m) {

`    `return { tag: "Fst", arg: m };

`` return {tag: "fst", arg: m};

}

}

function Snd(m) {

hàm và (m) {

`    `return { tag: "Snd", arg: m };

`` return {tag: "snd", arg: m};

}

}

function Lam(x,m) {

hàm Lam (x, m) {

`    `return { tag: "Lam", args: [x,m] };

`` return {tag: "lam", args: [x, m]};

}

}

function App(m,n) {

Ứng dụng chức năng (m, n) {

`    `return { tag: "App", args: [m,n] };

`` return {tag: "app", args: [m, n]};

}

}

The last change that we'll make will be to change the notion of synthesis a little bit from what we had before. In the addition section, we said merely that we needed a function that synthesized a new value from some subvalues. More generally, though, we need that process to be able to fail, because we wish to place constraints on the synthesized values. To capture this, we'll wrap the return type in Maybe.

Thay đổi cuối cùng mà chúng tôi sẽ thực hiện là thay đổi khái niệm tổng hợp một chút so với những gì chúng tôi có trước đây.
Trong phần bổ sung, chúng tôi chỉ nói rằng chúng tôi cần một hàm tổng hợp một giá trị mới từ một số giá trị phụ.
Mặc dù vậy, tổng quát hơn, chúng ta cần quá trình đó để có thể thất bại, bởi vì chúng ta muốn đặt các ràng buộc trên các giá trị tổng hợp.
Để nắm bắt điều này, chúng tôi sẽ bọc loại trả lại trong có thể.

-- Haskell

- Haskell

decomposeCheck

phân hủy

`  `:: [(String,Type)]

`` :: [(chuỗi, loại)]

`  `-> Program

``-> Chương trình

`  `-> Type

``-> Loại

`  `-> Maybe ([Judgment], [Type] -> Maybe Type)

`` -> Có thể ([phán đoán], [loại] -> có thể loại)

decomposeCheck g (Pair m n) (Prod a b) =

DepoMposecheck g (cặp m n) (prod a b) =

`  `Just ([Check g m a, Check g n b], \as -> Just undefined)

`` Chỉ ([Kiểm tra g m a, kiểm tra g n b], \ as -> chỉ không xác định)

decomposeCheck g (Lam x m) (Arr a b) =

Decomposecheck g (lam x m) (mảng a b) =

`  `Just ([Check ((x,a):g) m b], \as -> Just undefined)

`` Chỉ ([kiểm tra ((x, a): g) m b], \ as -> chỉ không xác định)

decomposeCheck g m a =

phân hủy g m a =

`  `Just ( [Synth g m]

`` Chỉ ([synth g m]

`       `, \[a2] -> if a == a2 then Just undefined else Nothing

``, \ [A2] -> Nếu a == A2 thì không xác định được gì khác

**This document was truncated here because it was created in the Evaluation Mode.**

** Tài liệu này đã bị cắt ngắn ở đây vì nó được tạo trong chế độ đánh giá. **

