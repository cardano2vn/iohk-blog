# Thoughts on an ontology of smart contracts
![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.002.png) 6 March 2017![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.003.png) 6 mins read

![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.004.png)[ Thoughts on an ontology of smart contracts - Input Output](https://ucarecdn.com/c0c9901b-cfdb-4983-8f1b-aa12e7e7a36b/-/inline/yes/ "Thoughts on an ontology of smart contracts - Input Output")

![Charles Hoskinson](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Thoughts on an ontology of smart contracts](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.009.jpeg)

The concept of smart contracts has grown considerably since the birth of Ethereum. We've seen an explosion of interdisciplinary research and experimentation bundling legal, social, economic, cryptographic and even philosophical concerns into a rather strange milieu of tokenized intellect. Yet despite this digital cambrian explosion of thought, there seems to be a lack of a unified ontology for smart contracts. What exactly is an ontology? Eschewing the philosophical sense of the word, an ontology is simply a framework for connecting concepts or groups alongside their properties to the relationships between them. It's a fundamental word that generally is the attempt at bedrock for a topic. For example, it's meaningful to discuss the ontology of democracy or the [ontology of mathematics](https://philpapers.org/browse/ontology-of-mathematics "ontology of mathematics").

Khái niệm hợp đồng thông minh đã phát triển đáng kể kể từ khi Ethereum ra đời.
Chúng ta đã thấy một sự bùng nổ của nghiên cứu liên ngành và thử nghiệm bó hợp pháp, xã hội, kinh tế, mật mã và thậm chí các mối quan tâm triết học thành một môi trường khá kỳ lạ của trí tuệ.
Tuy nhiên, bất chấp sự bùng nổ tư tưởng của Cambrian kỹ thuật số này, dường như thiếu một bản thể luận thống nhất cho các hợp đồng thông minh.
Chính xác thì một bản thể luận là gì?
Eschewing ý nghĩa triết học của từ này, một bản thể học chỉ đơn giản là một khuôn khổ để kết nối các khái niệm hoặc nhóm bên cạnh các thuộc tính của chúng với các mối quan hệ giữa chúng.
Đó là một từ cơ bản mà nói chung là nỗ lực làm nền tảng cho một chủ đề.
Ví dụ, thật có ý nghĩa khi thảo luận về bản thể học của nền dân chủ hoặc [bản thể học của toán học] (https://philpapers.org/browse/ontology-of-mathics "Bản thể học của toán học").

Why would one want to develop an ontology for smart contracts? What is gained from this exercise? Is it mostly an academic exercise or is there a prescriptive value to it? I suppose there are more questions to glean, but let's take a stab at the why.

Tại sao người ta muốn phát triển một bản thể học cho các hợp đồng thông minh?
Những gì có được từ bài tập này?
Nó chủ yếu là một bài tập học thuật hay có giá trị quy định cho nó?
Tôi cho rằng có nhiều câu hỏi hơn để lượm lặt, nhưng chúng ta hãy đâm vào lý do tại sao.

Smart contracts are essentially two concepts mashed together. One is the notion of software. Cold, austere code that does as it is written and executes for the world to see. The other is the idea of an agreement between parties. Both have semantical demands that humans have traditionally had issues with and both have connections to worlds beyond the scope in which the contract lives.

Hợp đồng thông minh về cơ bản là hai khái niệm kết hợp với nhau.
Một là khái niệm về phần mềm.
Mã lạnh, khắc khổ làm như nó được viết và thực hiện cho thế giới nhìn thấy.
Khác là ý tưởng về một thỏa thuận giữa các bên.
Cả hai đều có nhu cầu ngữ nghĩa mà con người có truyền thống có vấn đề và cả hai đều có mối liên hệ với thế giới ngoài phạm vi mà hợp đồng sống.

Much of the focus of our current platforms, such as Ethereum, is on performance or security, yet abstracting to a more ontological viewpoint, one ought to ask about semantics and scope.

Phần lớn trọng tâm của các nền tảng hiện tại của chúng tôi, chẳng hạn như Ethereum, là về hiệu suất hoặc bảo mật, nhưng trừu tượng hóa một quan điểm bản thể hơn, người ta nên hỏi về ngữ nghĩa và phạm vi.

From a semantical perspective, we are trying to establish what the authors and users of smart contracts believe to be the purpose of the contract. Here we have consent, potential for *non est factum* style circumstances, a hierarchy of enforceability and other factors that have challenged contract law. What about cultural and linguistic barriers? Ambiguity is also king in this land.

Từ góc độ ngữ nghĩa, chúng tôi đang cố gắng thiết lập những gì các tác giả và người dùng hợp đồng thông minh tin là mục đích của hợp đồng.
Ở đây chúng tôi có sự đồng ý, tiềm năng cho hoàn cảnh phong cách * không thực tế *, một hệ thống phân cấp về khả năng thực thi và các yếu tố khác đã thách thức luật hợp đồng.
Thế còn các rào cản văn hóa và ngôn ngữ?
Sự mơ hồ cũng là vua ở vùng đất này.

Where normal contracts tend to pragmatically bind to a particular jurisdiction and set of interpretations with the escape hatch of arbitration or courts to parse purposeful ambiguity, decentralized machines have no such luxury. For better or worse, there is a pipeline with smart contracts that amplifies the semantical gap and then encapsulates the extracted consensus into code that again suffers from its own gap ([Loi Luu](http://www.comp.nus.edu.sg/~loiluu/ "Loi Luu, National University of Singapore") demonstrated this recently using [Oyente](https://eprint.iacr.org/2016/633.pdf "Making smart contracts smarter")).

Trong trường hợp các hợp đồng bình thường có xu hướng liên kết thực tế với một khu vực tài phán cụ thể và tập hợp các giải thích với việc thoát khỏi trọng tài hoặc tòa án để phân tích sự mơ hồ có chủ đích, các máy móc phi tập trung không có sự xa xỉ như vậy.
Dù tốt hay xấu, có một đường ống với các hợp đồng thông minh khuếch đại khoảng cách ngữ nghĩa và sau đó gói gọn sự đồng thuận được trích xuất thành mã một lần nữa bị khoảng cách của chính nó ([loi luu] (http://www.comp.nus.edu.
sg/~ loiluu/"loi luu, Đại học quốc gia Singapore") đã chứng minh điều này gần đây bằng cách sử dụng [oyente] (https://eprint.iacr.org/2016/633.pdf "làm cho hợp đồng thông minh thông minh hơn")).

Then these structures presume dominion over something of value. Whether this dominion be data, tokens or markers that represent real life commitments or things such as deeds or titles. For the last category, like software giving recommendations to act on something in physical world, the program can tell one what to do, but someone has to do it.

Sau đó, các cấu trúc này giả định sự thống trị đối với một cái gì đó có giá trị.
Cho dù sự thống trị này là dữ liệu, mã thông báo hoặc điểm đánh dấu đại diện cho các cam kết thực tế hoặc những điều như hành động hoặc tiêu đề.
Đối với danh mục cuối cùng, như phần mềm đưa ra các khuyến nghị để hành động trên một cái gì đó trong thế giới vật lý, chương trình có thể nói với một người phải làm gì, nhưng ai đó phải làm điều đó.

So we have an object that combines software and agreements that has a deep semantic and scope concern, but one could add more dimensions. There is the question of establishing facts and events. The relationship with time. The levels of interpretation for any given agreement. Should everything be strictly speaking parsed by machines? Is there room for human judgement in this model (see Nick Szabo, [Wet and dry code](https://unenumerated.blogspot.com/2006/11/wet-code-and-dry.html "Wet and dry code - Nick Szabo") and [this presentation](https://www.youtube.com/watch?v=tWuN2R2DC6c "Nick Szabo on smart contracts"))?

Vì vậy, chúng tôi có một đối tượng kết hợp phần mềm và các thỏa thuận có mối quan tâm về ngữ nghĩa và phạm vi sâu sắc, nhưng người ta có thể thêm nhiều chiều hơn.
Có câu hỏi thiết lập sự thật và sự kiện.
Mối quan hệ với thời gian.
Các cấp độ giải thích cho bất kỳ thỏa thuận nhất định.
Mọi thứ có nên được nói một cách nghiêm ngặt được phân tích cú pháp bởi máy móc?
Có chỗ cho sự phán xét của con người trong mô hình này không (xem Nick Szabo, [Mã ướt và khô] (https://unenumerated.blogspot.com/2006/11/wet-code-and-dry.html "Mã khô và khô-Mã khô-
Nick Szabo ") và [Bài thuyết trình này] (https://www.youtube.com/watch?v=tWun2R2DC6C" Nick Szabo trên hợp đồng thông minh "))?

One could make a fair argument that one of the core pieces of complexity behind protocols like Ethereum is that it actually isn't just flirting with self-enforcing smart contracts. There are inherited notions from the Bitcoin ecosystem such as maximizing decentralization, maintaining a certain level of privacy, the use of a blockchain to order facts and events. Let's not even explore the native unit of account.

Người ta có thể đưa ra một lập luận công bằng rằng một trong những phần phức tạp cốt lõi đằng sau các giao thức như Ethereum là nó thực sự không chỉ tán tỉnh các hợp đồng thông minh tự thực hiện.
Có những khái niệm được thừa hưởng từ hệ sinh thái bitcoin như tối đa hóa phân cấp, duy trì một mức độ riêng tư nhất định, sử dụng blockchain để đặt hàng các sự kiện và sự kiện.
Thậm chí chúng ta đừng khám phá đơn vị bản địa của tài khoản.

These concepts and utilities are fascinating, but contaminate attempts at a reasonable ontology that could be constructive. A less opinionated effort has come from the fintech world with both Christopher Clack's work on [Smart Contract Templates](https://arxiv.org/abs/1608.00771 "Smart contract templates: foundations, design landscape and research directions") and Willi Brammertzâ€™s work on [Project ACTUS](https://www.stevens.edu/research-entrepreneurship/research-centers-labs/hanlon-financial-systems-center/research/actus-algorithmic-contract-types-unified-standards "Algorithmic contract types unified standards"). Here we don't need immutability or blockchains. The execution environment doesn't matter as much. It's more about consensus on intent and evaluation to optimize processes.

Những khái niệm và tiện ích này là hấp dẫn, nhưng những nỗ lực gây ô nhiễm ở một bản thể học hợp lý có thể mang tính xây dựng.
Một nỗ lực ít quan điểm hơn đã đến từ thế giới fintech với cả công việc của Christopher Clack trên [Mẫu hợp đồng thông minh] (https://arxiv.org/abs/1608.00771 "Các mẫu hợp đồng thông minh: Cơ sở, Cảnh quan thiết kế và hướng nghiên cứu")
€ ™ làm việc trên [dự án Actus] (https://www.stevens.edu/research-entrepreneurship/research-centers-labs/hanlon-financial-systems-center/research/actus-algorithmic-contract
Tiêu chuẩn "Các loại hợp đồng thuật toán thống nhất tiêu chuẩn").
Ở đây chúng ta không cần bất biến hoặc blockchains.
Môi trường thực hiện không quan trọng bằng.
Đó là nhiều hơn về sự đồng thuận về ý định và đánh giá để tối ưu hóa các quy trình.

What about the relationship of smart contracts with other smart contracts? In the cryptocurrency space, we tend to be blockchain focused, yet this concept actually obfuscates that there are three data domains in a system that uses smart contracts.

Còn mối quan hệ của hợp đồng thông minh với các hợp đồng thông minh khác thì sao?
Trong không gian tiền điện tử, chúng ta có xu hướng tập trung vào blockchain, nhưng khái niệm này thực sự làm xáo trộn rằng có ba miền dữ liệu trong một hệ thống sử dụng hợp đồng thông minh.

The blockchain accounts for facts, events and value. There is a graph of smart contracts in relation to each other. Then there is a social graph of nodes or things that can interact with smart contracts. These are all incredibly different actors. Adding relays into the mix, one could even discuss the internet of smart contract systems.

Blockchain chiếm các sự kiện, sự kiện và giá trị.
Có một biểu đồ của các hợp đồng thông minh liên quan đến nhau.
Sau đó, có một biểu đồ xã hội của các nút hoặc những thứ có thể tương tác với các hợp đồng thông minh.
Đây là tất cả các diễn viên cực kỳ khác nhau.
Thêm rơle vào hỗn hợp, người ta thậm chí có thể thảo luận về các hệ thống hợp đồng thông minh.

Perhaps where an ontology could be most useful is on this last point. There seems to be economic value in marrying code to law for at least the purpose of standardization and efficiency, yet the hundreds of implicit assumptions and conditions upon which these systems are built need to be modelled explicitly for interoperability.

Có lẽ khi một bản thể luận có thể hữu ích nhất là ở điểm cuối cùng này.
Dường như có giá trị kinh tế trong việc kết hôn với pháp luật với ít nhất mục đích của tiêu chuẩn hóa và hiệu quả, tuy nhiên hàng trăm giả định và điều kiện ngầm mà các hệ thống này được xây dựng cần phải được mô hình hóa rõ ràng cho khả năng tương tác.

For example, if one takes a smart contract hosted on Rootstock and then via a relay communicates with a contract hosted on Ethereum and then connects to a data feed from a service such as Bloomberg offers, then what's the trust model? What assumptions has one made about the enforceability of this agreement, the actors who can influence it and the risk to the value contained? Like using dozens of software libraries with different licenses, one is creating a digital mess.

Ví dụ: nếu một người có hợp đồng thông minh được lưu trữ trên gốc rễ và sau đó thông qua một rơle giao tiếp với một hợp đồng được lưu trữ trên Ethereum và sau đó kết nối với nguồn cấp dữ liệu từ một dịch vụ như Bloomberg cung cấp, thì mô hình ủy thác là gì?
Những giả định nào có người ta đưa ra về khả năng thực thi của Thỏa thuận này, các tác nhân có thể ảnh hưởng đến nó và rủi ro đối với giá trị có?
Giống như sử dụng hàng tá thư viện phần mềm với các giấy phép khác nhau, người ta đang tạo ra một mớ hỗn độn kỹ thuật số.

To wrap up some of my brief thoughts, I think we need to do the following. First, decouple smart contracts conceptually from blockchains and their associated principles. Second, come to grips with the semantic gap and also scope of enforcement. Third, model the relationships of smart contracts with each other, the actors who use them and related systems. Fourth, extract some patterns, standards and common use practices from already deployed contracts to see what we can infer. Finally, come up with better ways of making assumptions explicit.

Để kết thúc một số suy nghĩ ngắn gọn của tôi, tôi nghĩ rằng chúng ta cần phải làm như sau.
Đầu tiên, Decouple hợp đồng thông minh về mặt khái niệm từ các blockchain và các nguyên tắc liên quan của chúng.
Thứ hai, đến để nắm bắt với khoảng cách ngữ nghĩa và cả phạm vi thực thi.
Thứ ba, mô hình hóa các mối quan hệ của các hợp đồng thông minh với nhau, các diễn viên sử dụng chúng và các hệ thống liên quan.
Thứ tư, trích xuất một số mẫu, tiêu chuẩn và thực tiễn sử dụng phổ biến từ các hợp đồng đã được triển khai để xem những gì chúng ta có thể suy ra.
Cuối cùng, đưa ra những cách tốt hơn để đưa ra các giả định rõ ràng.

The benefits of this approach seem to be making preparations for sorting out how one will design systems that host smart contracts and how such systems will relate to each other. There seems to be a profound lack of metadata for smart contracts floating around. Perhaps an ontology could provide a coherent way of labeling things?

Lợi ích của phương pháp này dường như là chuẩn bị để sắp xếp cách một người sẽ thiết kế các hệ thống lưu trữ hợp đồng thông minh và cách các hệ thống như vậy sẽ liên quan đến nhau.
Dường như thiếu siêu dữ liệu cho các hợp đồng thông minh nổi xung quanh.
Có lẽ một bản thể học có thể cung cấp một cách gắn nhãn mạch lạc?

Thanks for reading,

Cảm ơn vì đã đọc,

Charles

Charles

## **Attachments**

## ** tệp đính kèm **

![](img/2017-03-06-thoughts-on-an-ontology-for-smart-contracts.004.png)[ Thoughts on an ontology of smart contracts - Input Output](https://ucarecdn.com/c0c9901b-cfdb-4983-8f1b-aa12e7e7a36b/-/inline/yes/ "Thoughts on an ontology of smart contracts - Input Output")

