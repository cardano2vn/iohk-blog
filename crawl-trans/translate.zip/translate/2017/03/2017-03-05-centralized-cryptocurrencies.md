# Centralized cryptocurrencies
![](img/2017-03-05-centralized-cryptocurrencies.002.png) 5 March 2017![](img/2017-03-05-centralized-cryptocurrencies.002.png)[ Alexander Chepurnoy](tmp//en/blog/authors/alexander-chepurnoy/page-1/)![](img/2017-03-05-centralized-cryptocurrencies.003.png) 6 mins read

![](img/2017-03-05-centralized-cryptocurrencies.004.png)[ Centralized cryptocurrencies - Input Output](https://ucarecdn.com/4f9418f2-9aa8-4a53-99cc-ae3c8fc18bf9/-/inline/yes/ "Centralized cryptocurrencies - Input Output")

![Alexander Chepurnoy](img/2017-03-05-centralized-cryptocurrencies.005.png)[](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
### [**Alexander Chepurnoy**](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
Research Fellow

Team Scorex Manager

- ![](img/2017-03-05-centralized-cryptocurrencies.006.png)[](https://www.youtube.com/watch?v=Pxu4gpuVnQE "YouTube")
- ![](img/2017-03-05-centralized-cryptocurrencies.007.png)[](https://twitter.com/chepurnoy "Twitter")
- ![](img/2017-03-05-centralized-cryptocurrencies.008.png)[](https://github.com/kushti "GitHub")

![Centralized cryptocurrencies](img/2017-03-05-centralized-cryptocurrencies.009.jpeg)

This article is inspired by my recent visit to a [blockchain technology conference](http://www.osp.ru/iz/blockchain "blockchain technology conference") and my discussions with colleagues about ideas to improve blockchain. Most of the conference speakers were from big Russian banks and their talks were about blockchain use cases, mainly as databases or smart contract platforms. However, none of the speakers were able to answer the question, â€why did they really need blockchain?â€™. The correct answer for this question recently came from the R3 CEV consortium: ["no blockchain because we don't need one"](https://twitter.com/Beautyon_/status/834152812405735425?ref_src=twsrc%5Etfw "R3 Twitter - no blockchain"). Blockchain is not needed for banks, it is needed instead of banks. It is required for decentralized systems only, applications with a trusted party will always be more efficient, simple, etc. The meaning of decentralization has been widely discussed (see, for example, this post from [Vitalik Buterin](https://medium.com/@VitalikButerin/the-meaning-of-decentralization-a0c92b76a274#.x5k6j4cxg "Vitalik Buterin - the meaning of decentralization") and it is the only real purpose of blockchains. In this blog post I'm going to discuss the degree of centralization of existing cryptocurrencies and the reasons leading to it.

Bài viết này được lấy cảm hứng từ chuyến thăm gần đây của tôi đến [Hội nghị công nghệ blockchain] (http://www.osp.ru/iz/blockchain "Hội nghị công nghệ blockchain") và các cuộc thảo luận của tôi với các đồng nghiệp về ý tưởng để cải thiện blockchain. Hầu hết các diễn giả hội nghị đến từ các ngân hàng lớn của Nga và các cuộc nói chuyện của họ là về các trường hợp sử dụng blockchain, chủ yếu là cơ sở dữ liệu hoặc nền tảng hợp đồng thông minh. Tuy nhiên, không ai trong số các diễn giả có thể trả lời câu hỏi, "tại sao họ thực sự cần blockchain?". Câu trả lời đúng cho câu hỏi này gần đây đến từ Hiệp hội CEV R3: ["Không có blockchain vì chúng tôi không cần một"] - Không có blockchain "). Blockchain là không cần thiết cho các ngân hàng, nó là cần thiết thay vì các ngân hàng. Chỉ cần cho các hệ thống phi tập trung, các ứng dụng với một bên đáng tin cậy sẽ luôn hiệu quả hơn, đơn giản, v.v ... Ý nghĩa của việc phân cấp đã được thảo luận rộng rãi (xem, ví dụ, bài đăng này từ [Vitalik .com/@vitalikbuterin/có nghĩa là phân cấp-A0C92B76A274#.x5K6J4CXG "Vitalik Buterin-Ý nghĩa của phân cấp") và đó là mục đích thực sự duy nhất của blockchains. Trong bài đăng trên blog này. tập trung hóa các loại tiền điện tử hiện có và các lý do dẫn đến nó.

## **Governance and development centralization**

## ** Tập trung quản trị và phát triển **

Let's start with a non-technical topic. It is nice to think that **no-one controls blockchain**, ie that network participants (miners) act as a decentralized community and chose the direction of development. In fact, everything is much worse.

Hãy bắt đầu với một chủ đề phi kỹ thuật.
Thật tuyệt khi nghĩ rằng ** không ai kiểm soát blockchain **, tức là những người tham gia mạng (người khai thác) hoạt động như một cộng đồng phi tập trung và chọn hướng phát triển.
Trong thực tế, mọi thứ đều tồi tệ hơn nhiều.

The first source of centralization here, is the source of the protocol for improvement. Only a small group of **core developers** is able to accept changes to the source code or even understand some protocol [improvement proposals](https://en.bitcoin.it/wiki/Bitcoin_Improvement_Proposals "Bitcoin Wiki improvement proposals"). No-one works for free and the organization that pays money to the core team in fact controls the cryptocurrencyâ€™s source code. For example, Bitcoin development is controlled by Blockstream, and this organization has its own interests. A **treasury system** like the one for [Dash](tmp//en/research/papers/dash-governance-system-analysis-and-suggestions-for-improvement/ "Suggestions for improvement - IOHK") or the one proposed for [Ethereum Classic](https://www.scribd.com/document/339563725/Ethereum-Classic-Treasury-System-Proposal-Google-Docs "Ethereum Classic treasury system proposal, IOHK") may be the solution here. However, a lot of questions are still open (for example, the 78 pages of ETC treasury proposal are quite complicated, while the Dash treasury system was developed without any documentation).

Nguồn đầu tiên của tập trung ở đây, là nguồn của giao thức để cải thiện. Chỉ có một nhóm nhỏ các nhà phát triển cốt lõi ** có thể chấp nhận các thay đổi đối với mã nguồn hoặc thậm chí hiểu một số giao thức [Đề xuất cải tiến] (https://en.bitcoin.it/wiki/bitcoin_improvement_proposals " . Không ai hoạt động miễn phí và tổ chức trả tiền cho nhóm cốt lõi trong thực tế kiểm soát mã nguồn của tiền điện tử. Ví dụ, phát triển bitcoin được kiểm soát bởi blockstream và tổ chức này có lợi ích riêng. Một hệ thống Kho bạc ** giống như hệ thống cho [Dash] (TMP // EN/Nghiên cứu/Giấy tờ/Dash-Thống trị-Hệ thống phân tích và Suggestions-For-Aformement/" Một đề xuất cho [Ethereum Classic] (https://www.scripd.com/document/339563725/ethereum-cassic-tasury-system-proposal-google-docs "Đề xuất hệ thống kho bạc cổ điển Ethereum, IOHK") có thể là giải pháp ở đây . Tuy nhiên, rất nhiều câu hỏi vẫn còn mở (ví dụ, 78 trang đề xuất Kho bạc ETC khá phức tạp, trong khi hệ thống Kho bạc Dash được phát triển mà không có bất kỳ tài liệu nào).

The next centralization risk in governance is the **cult of personality**. While Vitalik tells us in his [post](https://medium.com/@VitalikButerin/the-meaning-of-decentralization-a0c92b76a274#.x5k6j4cxg "Vitalik Buterin, the meaning of decentralization"), that no-one controls cryptocurrencies, his opinion is so important for the Ethereum community, that most of its members accepted the bailout of the DAO, which breaks the basic immutability principle of cryptocurrencies.

Rủi ro tập trung tiếp theo trong quản trị là ** sùng bái tính cách **.
Trong khi Vitalik nói với chúng tôi trong [bài] của anh ấy (https://medium.com/@vitalikbuterin/the-meaning-of-decentralization-a0c92b76a274#.x5k6j4cxg
, ý kiến của ông rất quan trọng đối với cộng đồng Ethereum, đến nỗi hầu hết các thành viên của nó đã chấp nhận sự cứu trợ của DAO, phá vỡ nguyên tắc bất biến cơ bản của tiền điện tử.

Finally, there are a lot of interested parties behind cryptocurrencies, and the opinion of some of them (for example the end users of the currency) is usually **ignored**. Anyway, the development of cryptocurrencies is a social consensus, and it is good to have a manifesto, declaring its purpose from the start.

Cuối cùng, có rất nhiều bên quan tâm đằng sau tiền điện tử và ý kiến của một số trong số họ (ví dụ như người dùng cuối của tiền tệ) thường bị bỏ qua **.
Dù sao, sự phát triển của tiền điện tử là một sự đồng thuận xã hội, và thật tốt khi có một tuyên ngôn, tuyên bố mục đích của nó ngay từ đầu.

## **Services centralization**

## ** tập trung dịch vụ **

One of the biggest problems with existing cryptocurrencies is the centralization of services. Blockchain **processing is heavy** (eg Ethereum processing from the genesis block may take weeks) and regular users that just want to send some coins have to **trust centralized services**. Most Bitcoin users trust [blockchain.info](http://blockchain.info/ "Blockchain.info"), Ethereum users trust [myetherwallet](https://www.myetherwallet.com/ "MyEtherWallet.com") and so on. If these popular wallets were to be compromised, usersâ€™ funds would be lost.

Một trong những vấn đề lớn nhất với tiền điện tử hiện có là tập trung hóa các dịch vụ.
Xử lý blockchain ** nặng ** (ví dụ: xử lý Ethereum từ khối Genesis có thể mất vài tuần) và người dùng thường xuyên chỉ muốn gửi một số đồng tiền phải ** tin tưởng các dịch vụ tập trung **.
Hầu hết người dùng bitcoin tin tưởng [blockchain.info] (http://blockchain.info/ "blockchain.info"), người dùng ethereum tin cậy [myetherwallet] (https://www.myetherwallet.com
trên.
Nếu các ví phổ biến này bị xâm phạm, số tiền của người dùng sẽ bị mất.

Moreover, most users trust in blockchain explorers and never check that the blocks in it are correct. What is the meaning of the "decentralized" social network Steemit, if almost none of its users download a blockchain and believe that the data on [Steemit.com](https://steemit.com "Steemit.com") is correct? Or imagine that blockchain.info was compromised: an attacker could steal all the usersâ€™ money from their wallets, hide the criminal transactions and show user-created transactions in blockchain explorer, and the attack could go unnoticed for a long time. Thus, trust in centralized services produces a **single point of failure**, allows **censorship** and puts user coins in **jeopardy**.

Hơn nữa, hầu hết người dùng tin tưởng vào Blockchain Explorers và không bao giờ kiểm tra xem các khối trong đó có chính xác không.
Ý nghĩa của mạng xã hội "phi tập trung" là gì, nếu hầu như không có người dùng nào tải xuống blockchain và tin rằng dữ liệu trên [steemit.com] (https://steemit.com "Steemit.com") là chính xác?
Hoặc tưởng tượng rằng blockchain.info đã bị xâm phạm: kẻ tấn công có thể đánh cắp tất cả tiền của người dùng khỏi ví của họ, ẩn các giao dịch tội phạm và hiển thị các giao dịch do người dùng tạo trong Blockchain Explorer và cuộc tấn công có thể không được chú ý trong một thời gian dài.
Do đó, niềm tin vào các dịch vụ tập trung tạo ra một điểm thất bại ** **, cho phép ** kiểm duyệt ** và đặt tiền người dùng vào ** Jeopardy **.

## **Mining centralization**

## ** Tập trung khai thác **

With popular cryptocurrencies, **hardware requirements are high** even just for blockchain validation. Even if you own modern hardware able to process blocks fast, your network channel may not be wide enough to download the created blocks fast enough. This leads to a situation where only a few high-end computers are able to create new blocks, which leads to mining centralization. Being open by design, Bitcoin mining power is now concentrated in a limited group of miners, which could easily meet and agree to perform a 51% attack (or just censor selected transactions or blocks). Mining pools worsen the situation, for example, in Bitcoin just five mining pools control more than 50% of the hash rate (at least if you believe [blockchain.info](https://blockchain.info/pools "Hash rate distribution - blockchain.info"). Another option for miners is to skip transaction processing and produce empty blocks, which would also make blockchain meaningless.

Với tiền điện tử phổ biến, các yêu cầu phần cứng ** cao ** ngay cả khi chỉ để xác thực blockchain.
Ngay cả khi bạn sở hữu phần cứng hiện đại có thể xử lý các khối nhanh, kênh mạng của bạn có thể không đủ rộng để tải xuống các khối được tạo đủ nhanh.
Điều này dẫn đến một tình huống chỉ có một vài máy tính cao cấp có thể tạo ra các khối mới, dẫn đến việc tập trung khai thác.
Được mở bởi thiết kế, sức mạnh khai thác bitcoin hiện tập trung trong một nhóm người khai thác hạn chế, có thể dễ dàng gặp gỡ và đồng ý thực hiện một cuộc tấn công 51% (hoặc chỉ kiểm duyệt các giao dịch hoặc khối được chọn).
Ví dụ, các nhóm khai thác làm xấu đi tình hình, trong Bitcoin chỉ có năm nhóm khai thác kiểm soát hơn 50% tỷ lệ băm (ít nhất là nếu bạn tin [blockchain.info] (https://blockchain.info/pools "Phân phối tỷ lệ băm -
blockchain.info "). Một tùy chọn khác cho người khai thác là bỏ qua việc xử lý giao dịch và tạo ra các khối trống, điều này cũng sẽ khiến Blockchain trở nên vô nghĩa.

Proof-of-Stake is usually regarded as more hardware friendly, however, a really popular blockchain requires a wide network channel to synchronize the network anyway. Also, it is usually unprofitable to keep a mining node in PoS and just a small percentage of coins are online that makes the network vulnerable. This is usually fixed by delegating mining power to someone else, that also leads to a **small amount of mining nodes**.

Bằng chứng cổ phần thường được coi là thân thiện với phần cứng hơn, tuy nhiên, một blockchain thực sự phổ biến đòi hỏi một kênh mạng rộng để đồng bộ hóa mạng.
Ngoài ra, thường không có lợi khi giữ một nút khai thác trong POS và chỉ một tỷ lệ nhỏ các đồng tiền trực tuyến khiến mạng dễ bị tổn thương.
Điều này thường được cố định bằng cách ủy thác sức mạnh khai thác cho người khác, điều đó cũng dẫn đến một lượng nhỏ các nút khai thác **.

## **Centralization as a solution**

## ** Tập trung như một giải pháp **

The most scary point of all this is that more and more often, centralization is regarded as a solution for some problems of cryptocurrencies. To fix scalability issues, cryptocurrencies propose to use a limited number of trusted ["masternodes"](http://dashmasternode.org/what-is-a-masternode/ "What is a master node?"), ["witnesses"](https://byteball.org/Byteball.pdf "Byteball: A Decentralized System for Storage and Transfer of Value"), ["delegates"](https://bitshares.org/technology/delegated-proof-of-stake-consensus/ "Delegated Proof-of-Stake consensus"), ["federations"](https://blockstream.com/2017/01/16/strong-federations-paper-released-liquid.html "Strong Federations, Foundation of Liquid, Whitepaper Released") and so on to "fix" the too-large amount of mining nodes in the network. The number of these trusted nodes may vary, but by using this method to fix scalability issues, developers also **destroy the decentralized nature of the currency**. Eventually this would lead to a cryptocurrency with only one performing node, that processes transactions very efficiently, without confirmation delays and forks, but suddenly a blockchain is not needed, as in R3's case.

Điểm đáng sợ nhất của tất cả điều này là ngày càng thường xuyên, tập trung hóa được coi là một giải pháp cho một số vấn đề của tiền điện tử. Để khắc phục các vấn đề về khả năng mở rộng, tiền điện tử đề xuất sử dụng một số lượng hạn chế đáng tin cậy ["MasterNodes"] (http://dashmasternode.org/what-is-a-masternode/ "Nút chính là gì?"), ["Nhân chứng" ] (https://byteball.org/byteball.pdf "byteball: một hệ thống phi tập trung để lưu trữ và chuyển giao giá trị"), [ Cổ phần-Đưa ra/"Đồng thuận bằng chứng chứng minh được ủy quyền"), ["Liên đoàn"] (https://blockstream.com/2017/01/16/strong-federation Nền tảng của chất lỏng, whitepaper được phát hành "), v.v. để" sửa "lượng các nút khai thác quá lớn trong mạng. Số lượng các nút đáng tin cậy này có thể khác nhau, nhưng bằng cách sử dụng phương pháp này để khắc phục các vấn đề về khả năng mở rộng, các nhà phát triển cũng ** phá hủy bản chất phi tập trung của tiền tệ **. Cuối cùng, điều này sẽ dẫn đến một loại tiền điện tử chỉ có một nút thực hiện, xử lý các giao dịch rất hiệu quả, mà không cần sự chậm trễ và dĩa, nhưng đột nhiên một blockchain là không cần thiết, như trong trường hợp của R3.

Unfortunately, most users are not able to determine the lie in cryptocurrencies and like these centralized blockchains more and more, because for sure, the centralized way is (and will always be) more simple and user-friendly.

Thật không may, hầu hết người dùng không thể xác định lời nói dối trong tiền điện tử và giống như các blockchains tập trung này ngày càng nhiều hơn, bởi vì chắc chắn, cách tập trung là (và sẽ luôn luôn) đơn giản và thân thiện với người dùng hơn.

## **Conclusion**

## **Sự kết luận**

We are going to see more centralized cryptocurrencies and that will inevitably lead to mass disappointment in blockchain technology, because it is not needed for centralized solutions. It is still a user choice, whether to believe a beautiful and fast web interface or to use trustless, but harmful software, requiring you to download blockchain data and process it.

Chúng ta sẽ thấy các loại tiền điện tử tập trung hơn và điều đó chắc chắn sẽ dẫn đến sự thất vọng hàng loạt trong công nghệ blockchain, bởi vì nó không cần thiết cho các giải pháp tập trung.
Nó vẫn là một lựa chọn của người dùng, cho dù tin rằng một giao diện web đẹp và nhanh hay sử dụng phần mềm không đáng tin cậy, nhưng có hại, yêu cầu bạn tải xuống dữ liệu blockchain và xử lý nó.

Most centralization risks may be fixed, if trustless full-nodes, wallets, explorers are cheap to launch and easy to use. I'm not going to propose a solution in this paper, but I hope it is coming soon!

Hầu hết các rủi ro tập trung có thể được sửa chữa, nếu phần đầy đủ, ví, ví, nhà thám hiểm có giá rẻ để khởi chạy và dễ sử dụng.
Tôi sẽ không đề xuất một giải pháp trong bài viết này, nhưng tôi hy vọng nó sẽ đến sớm!

## **Attachments**

## ** tệp đính kèm **

![](img/2017-03-05-centralized-cryptocurrencies.004.png)[ Centralized cryptocurrencies - Input Output](https://ucarecdn.com/4f9418f2-9aa8-4a53-99cc-ae3c8fc18bf9/-/inline/yes/ "Centralized cryptocurrencies - Input Output")

