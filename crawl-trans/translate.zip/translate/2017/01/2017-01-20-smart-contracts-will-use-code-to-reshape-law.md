# Smart contracts will use code to reshape law
![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.002.png) 20 January 2017![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.003.png) 2 mins read

![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.004.png)[ Smart contracts will use code to reshape law - Input Output](https://ucarecdn.com/f3e9b710-47db-40f7-aec9-7c711dd9e822/-/inline/yes/ "Smart contracts will use code to reshape law - Input Output")

![Jane Wild](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.005.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.006.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.007.png)[](https://twitter.com/jane_wild_ "Twitter")

![Smart contracts will use code to reshape law](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.008.jpeg)

On a frosty Friday morning in Switzerlandâ€™s commercial centre of Zurich, an audience arrived early at the university to learn about the emerging field of smart contracts in a presentation given by Charles Hoskinson. A completely new way of quantifying concepts like trust, reputation and ambiguity, smart contracts are a digital legal system â€“ a computer protocol that facilitates, verifies or enforces the negotiation or performance of a contract.

The idea is now gaining new momentum from ventures including [Cardano](tmp//en/projects/cardano/), and academic papers are also providing a driving force behind the development. These contracts arenâ€™t written in legalese, but in computer code, and that gives them the flexibility to quickly adapt to societyâ€™s needs in a way legislation cannot.

![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.009.jpeg) Charles outlined the five elements needed for smart contracts:
## **1. A secure distributed systemâ€¨**
Who gets to design the protocol is an important question. Useful resources are offered in work by Tim Swanson, who has written a lot about private/public blockchains. [Rich Hickeyâ€™s lecture, the Value of Values](https://www.youtube.com/watch?v=-6BsiVyC1kM), is worth watching on YouTube.â€¨

Ai được thiết kế giao thức là một câu hỏi quan trọng.
Các tài nguyên hữu ích được cung cấp trong công việc của Tim Swanson, người đã viết rất nhiều về các blockchain riêng/công cộng.
.

## **2. A language in which to write the contractsâ€¨**

## ** 2.
Một ngôn ngữ để viết các hợp đồng "

Cardanoâ€™s researchers have conceived Plutus to write its smart contracts. Creating a language is the easy part, but the question of how you deal with ambiguity must be addressed; who would you go to if there is a problem?â€¨

Các nhà nghiên cứu của Cardano đã hình thành Plutus để viết các hợp đồng thông minh của mình.
Tạo một ngôn ngữ là phần dễ dàng, nhưng câu hỏi về cách bạn đối phó với sự mơ hồ phải được giải quyết;
Bạn sẽ đến ai nếu có vấn đề? "

## **3. A secure way of performing computationâ€¨**

## ** 3.
Một cách thực hiện tính toán an toàn

[â€œVerifiable computingâ€](https://en.wikipedia.org/wiki/Verifiable_computing) is the concept to explore here. There is a debate about hardware versus software â€“ how can you be sure the system has had no backdoor installed?â€¨

.
Có một cuộc tranh luận về phần cứng so với phần mềm - Làm thế nào bạn có thể chắc chắn rằng hệ thống đã không được cài đặt Backdoor? "

## **4. A method of representing assets and valueâ€¨**

## **4.
Một phương pháp đại diện cho tài sản và giá trị € ¨ **

This could be done by creating a token that is pegged to a value-stable currency such as the dollar. Another matter to consider is what jurisdiction the digital asset falls under.â€¨

Điều này có thể được thực hiện bằng cách tạo một mã thông báo được gắn với một loại tiền tệ ổn định giá trị như đồng đô la.
Một vấn đề khác cần xem xét là quyền tài phán mà tài sản kỹ thuật số thuộc về.

## **5. Trustworthy data feedsâ€¨**

## ** 5.
Nguồn cấp dữ liệu đáng tin cậy - € ¨ **

In traditional finance this might be supplied by a Bloomberg terminal. A smart contract needs a similar source, but there is no equivalent yet in this field to provide the necessary information stream.â€¨

Trong tài chính truyền thống, điều này có thể được cung cấp bởi một thiết bị đầu cuối Bloomberg.
Một hợp đồng thông minh cần một nguồn tương tự, nhưng chưa có tương đương trong lĩnh vực này để cung cấp luồng thông tin cần thiết.

This reimagining of how legal processes can work has the potential to solve some problems of current legal systems, offering a clarity of code in place of ambiguous legal clauses. If needed, a layer can be added to the protocol to allow for human judgement and arbitration. This all combines to sharply bring down the cost of legal services.

Việc mô phỏng lại cách thức hoạt động của các quy trình pháp lý có khả năng giải quyết một số vấn đề của các hệ thống pháp lý hiện tại, đưa ra sự rõ ràng về mã thay cho các điều khoản pháp lý mơ hồ.
Nếu cần, một lớp có thể được thêm vào giao thức để cho phép phán đoán và phân xử của con người.
Tất cả điều này kết hợp để giảm mạnh chi phí của các dịch vụ pháp lý.

## **Attachments**

## ** tệp đính kèm **

![](img/2017-01-20-smart-contracts-will-use-code-to-reshape-law.004.png)[ Smart contracts will use code to reshape law - Input Output](https://ucarecdn.com/f3e9b710-47db-40f7-aec9-7c711dd9e822/-/inline/yes/ "Smart contracts will use code to reshape law - Input Output")

