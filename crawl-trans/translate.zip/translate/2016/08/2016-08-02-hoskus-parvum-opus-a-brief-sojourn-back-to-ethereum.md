# Hoskus Parvum Opus: A Brief Sojourn Back to Ethereum
![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.002.png) 2 August 2016![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.003.png) 14 mins read

![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.004.png)[ Hoskus Parvum Opus, A Brief Sojourn Back to Ethereum - Input Output HongKong](https://ucarecdn.com/8da5e31b-3373-4151-96f6-b8ad1f5ad91e/-/inline/yes/ "Hoskus Parvum Opus, A Brief Sojourn Back to Ethereum - Input Output HongKong")

![Charles Hoskinson](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Hoskus Parvum Opus: A Brief Sojourn Back to Ethereum](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.009.jpeg)
### **Heart of Darkness**
We must never cease from exploration and at the end of all of our exploring will be to arrive at where we started and know the place for the first time. This quote from T.S. Elliot has become increasingly more meaningful to me over the last few years. Iâ€™ve had an opportunity to travel to 15 countries, more than 500,000 miles and meet thousands of amazing people, yet I feel as if Iâ€™ve returned to where I started with a new perspective.

Chúng ta không bao giờ ngừng khám phá và vào cuối tất cả các cuộc thám hiểm của chúng ta sẽ là đến nơi chúng ta bắt đầu và biết nơi đầu tiên.
Trích dẫn này từ T.S.
Elliot đã ngày càng trở nên có ý nghĩa hơn đối với tôi trong vài năm qua.
Tôi đã có cơ hội đi du lịch tới 15 quốc gia, hơn 500.000 dặm và gặp hàng ngàn người tuyệt vời, nhưng tôi cảm thấy như thể tôi đã trở lại nơi tôi bắt đầu với một viễn cảnh mới.

First, I suppose itâ€™s prudent to start with the early days of my journey. Quite painfully, I recall June of 2014. I had pneumonia and had just left Switzerland after a brutal fight over the future of the Ethereum project. I was on the losing side and now was headed to England to spend a few days with Michael Parsons, who was generous enough to provide a room in his house while I collected my thoughts about my future. I was in shock from being stripped of an identity.

Đầu tiên, tôi cho rằng đó là thận trọng khi bắt đầu với những ngày đầu của hành trình của tôi.
Khá đau đớn, tôi nhớ lại tháng 6 năm 2014. Tôi bị viêm phổi và vừa rời Thụy Sĩ sau một cuộc chiến tàn khốc về tương lai của dự án Ethereum.
Tôi đã ở bên thua cuộc và bây giờ đã đến Anh để dành vài ngày với Michael Parsons, người đủ hào phóng để cung cấp một căn phòng trong nhà trong khi tôi thu thập suy nghĩ của mình về tương lai của mình.
Tôi đã bị sốc vì bị tước danh tính.

Just a few days prior, I was a founder of a remarkable project with a beautiful vision of a decentralized world computer that was immune to censorship alongside the machinations of inconvenienced power brokers. And then I had become a sickly man having trouble breathing, traveling through an overcast city to a small house without a title, purpose or any vesting in a movement. It was a dark time, bereft of humanity or kindness save a few rare friends and my Marlene for whom Iâ€™m eternally indebted.

Chỉ vài ngày trước đó, tôi là người sáng lập một dự án đáng chú ý với tầm nhìn tuyệt đẹp về một máy tính thế giới phi tập trung, miễn nhiễm với sự kiểm duyệt cùng với sự mưu mô của các nhà môi giới quyền lực bất tiện.
Và sau đó tôi đã trở thành một người đàn ông ốm yếu gặp khó khăn khi thở, đi qua một thành phố u ám đến một ngôi nhà nhỏ mà không có tiêu đề, mục đích hoặc bất kỳ vesting nào trong một phong trào.
Đó là một thời gian đen tối, sự thân thiện của nhân loại hoặc lòng tốt cứu một vài người bạn hiếm hoi và Marlene của tôi mà tôi đã vĩnh viễn mắc nợ.

The following months were left with a great degree of uncertainty. I pondered returning to mathematics and picking up where I left off studying the great unsolved problems of additive number theory (See Nathanson's excellent two part series on the topic.) I received several offers to lead a new ventures- some with VC backing and good teams. Yet honestly my heart wasnâ€™t in the game anymore.

Những tháng tiếp theo được để lại với một mức độ không chắc chắn lớn.
Tôi đã suy nghĩ về việc trở lại toán học và chọn nơi tôi đã nghiên cứu các vấn đề lớn chưa được giải quyết của lý thuyết số phụ gia (xem loạt hai phần xuất sắc của Nathanson về chủ đề này.)
.
Nhưng thành thật mà nói, trái tim tôi không còn trong trò chơi nữa.

### **Ethereum Rising**

### ** Ethereum tăng **

I really loved the amazing promise that Ethereum presented and to watch it unfold from the sidelines without stake or the ability to contribute was just too much. I invested so much time sleeping on floors, flying around the world and fighting almost constant exhaustion trying to keep everything together despite deep philosophical divisions in the team and vision. I had to detach and do other things.

Tôi thực sự yêu thích lời hứa tuyệt vời mà Ethereum đã trình bày và để xem nó mở ra từ bên lề mà không có cổ phần hay khả năng đóng góp là quá nhiều.
Tôi đã đầu tư rất nhiều thời gian ngủ trên sàn nhà, bay vòng quanh thế giới và chiến đấu gần như kiệt sức cố gắng giữ mọi thứ lại với nhau bất chấp sự phân chia triết học sâu sắc trong đội và tầm nhìn.
Tôi đã phải tách ra và làm những việc khác.

While I had my grievances with the remaining founders, there was great solace in the project maintaining the original social contract. And despite my admittedly bitter criticisms about governance and the use of funds, this contract seemed to be immutable. Gavin invented new words to encapsulate the code is law mantra, and Vitalik would appear on a nearly weekly basis in some form of media extolling the need for a censorship resistance smart contract system.

Trong khi tôi có sự bất bình của mình với những người sáng lập còn lại, đã có sự an ủi lớn trong dự án duy trì hợp đồng xã hội ban đầu.
Và mặc dù tôi thừa nhận những lời chỉ trích cay đắng về quản trị và sử dụng vốn, hợp đồng này dường như là bất biến.
Gavin đã phát minh ra các từ mới để gói gọn Bộ luật là Thần chú Luật và Vitalik sẽ xuất hiện trên cơ sở gần như hàng tuần trong một số hình thức truyền thông làm giảm nhu cầu về hệ thống hợp đồng thông minh kháng chiến kiểm duyệt.

The world was surprisingly receptive to the vision. Ethereum grew like a weed both in mindshare and market capitalization. It was incredibly satisfying to see every doubter reassess their prior comments, forgetting old stings and trying to eschew the hard line for a more neutral tone. Itâ€™s amazing how prognostications of impending doom and gloom transform into praise when people start making money. Readers with an overabundance of time should refer to Jeff Garzikâ€™s 

Thế giới đã tiếp nhận đáng ngạc nhiên vào tầm nhìn.
Ethereum phát triển như một loại cỏ dại cả về tư duy và vốn hóa thị trường.
Thật là thỏa mãn khi thấy mọi nghi ngờ đánh giá lại những bình luận trước đó của họ, quên đi những vết chích cũ và cố gắng tránh đường cứng rắn cho một giai điệu trung lập hơn.
Thật đáng kinh ngạc khi các tiên lượng của sự diệt vong sắp xảy ra và u ám biến thành lời khen khi mọi người bắt đầu kiếm tiền.
Độc giả với sự dư thừa thời gian nên đề cập đến Jeff Garzik's

[](https://twitter.com/jgarzik/status/515512676793847809)

[] (https://twitter.com/jgarzik/status/515512676793847809)

tweets

tweet

.

.

### **Bad Decisions**

### ** Quyết định tồi **

Itâ€™s a pointless exercise to litigate the sins of Ethereumâ€™s governance in a blog post nor justify my latent bitterness in a sharply written argument. Nothing productive can be gained from this effort outside of reinforcing notions people already have. Rather it should be stated that the core of Ethereum has become badly compromised by an extremely poor decision.

Đây là một bài tập vô nghĩa để kiện các tội lỗi của quản trị Ethereum trong một bài đăng trên blog cũng như không biện minh cho sự cay đắng tiềm ẩn của tôi trong một cuộc tranh luận được viết mạnh mẽ.
Không có gì hiệu quả có thể đạt được từ nỗ lực này bên ngoài việc củng cố các khái niệm mà mọi người đã có.
Thay vào đó, cần phải nói rằng cốt lõi của Ethereum đã trở nên bị tổn hại nặng nề bởi một quyết định cực kỳ nghèo nàn.

The Ethereum protocol doesnâ€™t care about Charles Hoskinson. It doesnâ€™t care about Gatecoin or Bitfinex. It doesnâ€™t care about the IRS, the SEC or the government of China. This lack of concern is the value propositionâ€™s apex. Ethereum is a horribly inefficient computer that is perhaps the most expensive ever built relative to its peers. The reason we pay that price is because we want a guarantee of computational apathy.

Giao thức Ethereum không quan tâm đến Charles Hoskinson.
Nó không quan tâm đến Gatecoin hoặc Bitfinex.
Nó không quan tâm đến IRS, SEC hoặc chính phủ Trung Quốc.
Sự thiếu quan tâm này là đỉnh của đề xuất giá trị.
Ethereum là một máy tính không hiệu quả khủng khiếp, có lẽ là loại đắt nhất từng được xây dựng so với các đồng nghiệp của nó.
Lý do chúng tôi trả giá đó là vì chúng tôi muốn đảm bảo sự thờ ơ tính toán.

The leadership of the ethereum project have made a decision to fork the protocol to eliminate the social contract of computational apathy. This fork is not about returning stolen money. Itâ€™s not about protecting the interests of the Foundation from a legal or regulatory perspective. Itâ€™s simply about changing the code is law paradigm to code is usually law until itâ€™s not.

Sự lãnh đạo của dự án Ethereum đã đưa ra quyết định đưa ra giao thức để loại bỏ hợp đồng xã hội của sự thờ ơ tính toán.
Ngã ba này không phải là để trả lại tiền bị đánh cắp.
Đó không phải là về việc bảo vệ lợi ích của nền tảng khỏi góc độ pháp lý hoặc quy định.
Nó chỉ đơn giản là về việc thay đổi mã là mô hình luật thành mã thường là luật cho đến khi nó không.

There was another option. I recall when Bitcoin has to make sudden changes to avoid a 

Có một lựa chọn khác.
Tôi nhớ lại khi Bitcoin phải thay đổi đột ngột để tránh

[](https://en.bitcoin.it/wiki/Value_overflow_incident)

[] (https://en.bitcoin.it/wiki/value_overflow_incident)

bug

sâu bọ

that allowed for the creation of billions of new coins. Issues that are clear flaws in the protocolâ€™s design that break the intended social contract are non-controversial to fix. I donâ€™t believe there are many in the ETC community who would object to correcting a flaw in the EVM that suddenly creates billions of new ether. Itâ€™s the changes to the social contract that are hazardous and always result in a community split.

Điều đó cho phép tạo ra hàng tỷ đồng tiền mới.
Các vấn đề là những sai sót rõ ràng trong thiết kế của giao thức phá vỡ hợp đồng xã hội dự định là không gây tranh cãi để sửa chữa.
Tôi không tin rằng có rất nhiều người trong cộng đồng ETC, những người sẽ phản đối việc sửa một lỗ hổng trong EVM đột nhiên tạo ra hàng tỷ ether mới.
Đó là những thay đổi đối với hợp đồng xã hội nguy hiểm và luôn dẫn đến sự phân chia cộng đồng.

For these changes, there needs to be a commitment made by the holders of the token to embrace the new system. Proof of burn is a perfect mechanism to accomplish this task. With ethereum, it could have been taken to the new level. An assurance proof of burn smart contract could have been written to pool ether holders wanting to embrace the new system if there was a certain threshold of participation (say 51 percent). If the threshold wasnâ€™t reached within a time limit, then the participants get refunded. Otherwise, the contract executes and all the funds are burnt leaving a clean cryptographic proof to redeem tokens on a new chain. DAO holders could have been given a special purpose token excluding the thief.

Đối với những thay đổi này, cần phải có một cam kết được thực hiện bởi những người nắm giữ mã thông báo để nắm lấy hệ thống mới.
Bằng chứng Burn là một cơ chế hoàn hảo để thực hiện nhiệm vụ này.
Với Ethereum, nó có thể đã được đưa lên cấp độ mới.
Một bằng chứng đảm bảo về hợp đồng thông minh Burn có thể đã được viết cho các chủ sở hữu ether muốn nắm lấy hệ thống mới nếu có một ngưỡng tham gia nhất định (giả sử 51 phần trăm).
Nếu ngưỡng không đạt được trong giới hạn thời gian, thì những người tham gia sẽ được hoàn trả.
Mặt khác, hợp đồng thực thi và tất cả các quỹ đều bị đốt cháy để lại bằng chứng mật mã sạch để đổi mã thông báo trên một chuỗi mới.
Những người nắm giữ Dao có thể đã được cung cấp một mã thông báo đặc biệt không bao gồm tên trộm.

The purity of this approach creates universal consent amongst the participants in the new system with the new social contract. A vacuous vote with no stake at risk is not consensus- especially when there is around 10 percent participation. Instead it seems to be a failed attempt to manufacture a democratic mandate to do something the core developers already wanted to do. It appears they didnâ€™t want two chains to co-exist so they forced the issue.

Độ tinh khiết của phương pháp này tạo ra sự đồng ý phổ biến giữa những người tham gia hệ thống mới với hợp đồng xã hội mới.
Một cuộc bỏ phiếu trống không có cổ phần có nguy cơ không phải là sự đồng thuận- đặc biệt là khi có khoảng 10 phần trăm tham gia.
Thay vào đó, nó dường như là một nỗ lực thất bại trong việc sản xuất một nhiệm vụ dân chủ để làm điều gì đó mà các nhà phát triển cốt lõi đã muốn làm.
Có vẻ như họ không muốn hai chuỗi cùng tồn tại nên họ đã buộc vấn đề này.

I did not sign up for the paradigm of code is sometimes law. It makes absolutely no sense to me. Why waste millions of dollars in energy and run such an inefficient computer if itâ€™s not going to provide hard guarantees of fidelity? Why shouldnâ€™t I just run code on a federation of servers with carefully chosen trust pairings? Why shouldnâ€™t I just play the jurisdiction game and trust my code to neutral and stable states like Switzerland? Such places usually have the moral high ground of a democratic mandate and known conflicts of interest unlike the current leadership of Ethereum.

Tôi đã không đăng ký mô hình mã đôi khi là luật.
Nó hoàn toàn không có ý nghĩa với tôi.
Tại sao lại lãng phí hàng triệu đô la năng lượng và chạy một máy tính không hiệu quả như vậy nếu nó sẽ không cung cấp sự đảm bảo khó khăn về độ trung thực?
Tại sao tôi không nên chạy mã trên một liên đoàn máy chủ với các cặp tin cậy được lựa chọn cẩn thận?
Tại sao tôi chỉ chơi trò chơi quyền tài phán và tin tưởng mã của tôi vào các quốc gia trung lập và ổn định như Thụy Sĩ?
Những nơi như vậy thường có nền tảng đạo đức cao của một nhiệm vụ dân chủ và xung đột lợi ích được biết đến không giống như sự lãnh đạo hiện tại của Ethereum.

Obviously the existence of Ethereum Classic seems to convey that Iâ€™m not alone in my protest and disgust for the fork. There are thousands of very angry miners, developers, and stakeholders who did not support the actions the foundation took and are directly expressing their rage via supporting the original codebase.

Rõ ràng sự tồn tại của Ethereum Classic dường như truyền đạt rằng tôi không đơn độc trong sự phản đối và ghê tởm của mình đối với ngã ba.
Có hàng ngàn người khai thác, nhà phát triển và các bên liên quan rất tức giận, những người không ủng hộ các hành động mà nền tảng đã thực hiện và đang trực tiếp thể hiện cơn thịnh nộ của họ thông qua việc hỗ trợ cơ sở mã ban đầu.

While this aggregation is powerful and clearly deserves a re-evaluation of the decisions of the last few weeks, itâ€™s not a cohesive, productive ecosystem with a vision, a roadmap and the ability to execute. Itâ€™s effectively the cryptocurrency equivalent of a recall election. People made a choice to fire the prime minister, but they didnâ€™t select a new one.

Mặc dù tập hợp này rất mạnh mẽ và rõ ràng xứng đáng được đánh giá lại các quyết định trong vài tuần qua, nhưng nó không phải là một hệ sinh thái hiệu quả, gắn kết với tầm nhìn, lộ trình và khả năng thực hiện.
Đó là hiệu quả của tiền điện tử tương đương với một cuộc bầu cử thu hồi.
Mọi người đã đưa ra một lựa chọn để sa thải thủ tướng, nhưng họ không chọn một người mới.

### **Return to the Center**

### ** Quay trở lại trung tâm **

This brings me back to my return to Ethereum. 2014 was a very long time ago for me. Iâ€™ve grown a lot as a person. I lead 

Điều này đưa tôi trở lại trở lại Ethereum.
Năm 2014 là một thời gian rất dài đối với tôi.
Tôi đã phát triển rất nhiều như một người.
tôi dẫn

[](https://iohk.io/)

[] (https://iohk.io/)

new company with nearly 30 employees to worry about. We are engaged in thoroughly interesting work ranging from the formalization of proof of stake, complete with security proofs based on the 

Công ty mới với gần 30 nhân viên phải lo lắng.
Chúng tôi đang tham gia vào các công việc hoàn toàn thú vị, từ việc chính thức hóa bằng chứng cổ phần, hoàn thành với các bằng chứng bảo mật dựa trên

[](https://eprint.iacr.org/2014/765.pdf)

[] (https://eprint.iacr.org/2014/765.pdf)

GKL15 model (publishing soon!), to studying governance at its most elemental level.

Mô hình GKL15 (xuất bản sớm!), Để nghiên cứu quản trị ở cấp độ nguyên tố nhất.

I have no desire to abandon our current projects and my personal obligations to attempt to force a Vitalik versus Charles showdown. A vanity play would accomplish nothing, and the market itself is a far better distributor of karma than any man could ever hope. There isnâ€™t an ether white whale for me to slay.

Tôi không muốn từ bỏ các dự án hiện tại của chúng tôi và nghĩa vụ cá nhân của tôi để cố gắng buộc Vitalik so với Charles Showdown.
Một vở kịch phù phiếm sẽ không hoàn thành gì, và chính thị trường là nhà phân phối nghiệp tốt hơn nhiều so với bất kỳ người đàn ông nào có thể hy vọng.
Có một con cá voi trắng ether để tôi giết.

### **My Participation in Ethereum Classic**

### ** Sự tham gia của tôi vào Ethereum Classic **

Thus it is my burden to explicitly state how I would like to contribute to the ETC community alongside what I wonâ€™t do. First, I will not seek a leadership position. It is needlessly divisive to inject myself into this movement with the aim of being the ETC CEO or some other kind of power broker. Nothing good can come from the distraction, and there are better people to lead. Second, I will not promote a roadmap that enforces a zero sum game between ETH and ETC. They are now projects governed by different philosophies and different communities. They shouldnâ€™t conflict in principle. Third, I will not support an effort to centralize the project around a new foundation. Centralization of power is the entire reason we are in this mess.

Do đó, đó là gánh nặng của tôi để nêu rõ cách tôi muốn đóng góp cho cộng đồng ETC cùng với những gì tôi sẽ không làm.
Đầu tiên, tôi sẽ không tìm kiếm một vị trí lãnh đạo.
Nó không cần thiết phải chia rẽ để đưa bản thân vào phong trào này với mục đích trở thành CEO ETC hoặc một số loại nhà môi giới quyền lực khác.
Không có gì tốt có thể đến từ sự phân tâm, và có những người tốt hơn để lãnh đạo.
Thứ hai, tôi sẽ không quảng bá một lộ trình thực thi một trò chơi tổng bằng không giữa ETH và v.v.
Bây giờ họ là các dự án được điều chỉnh bởi các triết lý khác nhau và các cộng đồng khác nhau.
Về nguyên tắc, họ không nên xung đột.
Thứ ba, tôi sẽ không hỗ trợ một nỗ lực để tập trung dự án xung quanh một nền tảng mới.
Tập trung quyền lực là toàn bộ lý do chúng ta đang ở trong mớ hỗn độn này.

Now on to the things I will do. As I previously mentioned, ETC is currently unified in anger and resentment. There are many groups of people in the ETC community and they will eventually conflict with each other after the dust has settled. Also a fairly large amount of trading volume into ETC has come from the bitcoin space. Itâ€™s unclear if this community is going to solidify behind a stable vision and roadmap outside of the code is law paradigm, which is admittedly an extension of bitcoinâ€™s honey badger approach to transactions.

Bây giờ đến những điều tôi sẽ làm.
Như tôi đã đề cập trước đây, vv hiện đang thống nhất trong sự tức giận và phẫn nộ.
Có nhiều nhóm người trong cộng đồng ETC và cuối cùng họ sẽ mâu thuẫn với nhau sau khi bụi đã lắng xuống.
Ngoài ra, một lượng lớn khối lượng giao dịch vào ETC đã đến từ không gian Bitcoin.
Không rõ liệu cộng đồng này sẽ củng cố đằng sau tầm nhìn và lộ trình ổn định bên ngoài Bộ luật là mô hình luật, được thừa nhận là một phần mở rộng của cách tiếp cận của Bitcoin Badger đối với các giao dịch.

Abstracting the point to something productive, I think itâ€™s reasonable to explicitly state the social contract of ETC and make a commitment that it will not change. Bit Novosti 

Tóm tắt quan điểm cho một cái gì đó hiệu quả, tôi nghĩ rằng thật hợp lý khi nêu rõ hợp đồng xã hội của ETC và thực hiện một cam kết rằng nó sẽ không thay đổi.
Bit Novosti

[](https://medium.com/@bit_novosti/a-crypto-decentralist-manifesto-6ba1fa0b9ede#.fe04h1b6r)

[] (https://medium.com/@bit_novosti/a-crypto-decentralist-manifesto-6ba1fa0b9ede#.fe04h1b6r)

drafted a manifesto

đã phác thảo một tuyên ngôn

that seems to be the current ideological driver of ETC.

Đó dường như là động lực tư tưởng hiện tại của v.v.

Therefore my first goal is to unify a fairly strong majority behind the basic tenets of immutability, irreversibility and openness. My hope is to transmute the anger into a productive movement unified behind some basic goals like Bitcoin enjoys. I fully admit this might not be possible and some hard choices may have to be made; however, Iâ€™m optimistic we can pull together into a cohesive movement.

Do đó, mục tiêu đầu tiên của tôi là thống nhất đa số khá mạnh đằng sau các nguyên lý cơ bản về tính bất biến, không thể đảo ngược và cởi mở.
Hy vọng của tôi là biến sự tức giận thành một phong trào sản xuất thống nhất đằng sau một số mục tiêu cơ bản như Bitcoin thích.
Tôi hoàn toàn thừa nhận điều này có thể không thể thực hiện được và một số lựa chọn khó khăn có thể phải được thực hiện;
Tuy nhiên, tôi lạc quan, chúng ta có thể tập hợp lại thành một chuyển động gắn kết.

Second, from a roadmap perspective, ETC needs to decide whether it will stay connected to ETH or diverge. I strongly argue that divergence is necessary as itâ€™s logically inconsistent to reject the Foundationâ€™s judgement, yet still accept their vision for the project. While obvious improvements, bug fixes and optimizations of things like the EVM should be capitalized on, ETC should chart its own path.

Thứ hai, từ góc độ lộ trình, vv cần quyết định xem nó sẽ được kết nối với ETH hay phân kỳ.
Tôi thực sự cho rằng sự phân kỳ là cần thiết vì nó không phù hợp về mặt logic khi từ chối phán đoán của Foundation, nhưng vẫn chấp nhận tầm nhìn của họ đối với dự án.
Mặc dù những cải tiến rõ ràng, việc sửa lỗi và tối ưu hóa những thứ như EVM nên được tận dụng, v.v.

The most immediate concern is the proof of stake transition. I believe that the transition to Casper will not be straightforward. Rather, difficulty will likely be experienced due to the ad hoc methodology of Casperâ€™s design and the inexperience of its architects.

Mối quan tâm ngay lập tức nhất là bằng chứng của quá trình chuyển đổi cổ phần.
Tôi tin rằng việc chuyển đổi sang Casper sẽ không đơn giản.
Thay vào đó, khó khăn có thể sẽ được trải nghiệm do phương pháp ad hoc của thiết kế của Casper và sự thiếu kinh nghiệm của các kiến trúc sư của nó.

Designing new consensus algorithms is among the most challenging tasks in computer science, as illustrated by Lamportâ€™s turing prize for Paxos. Trying to address problems of scalability, human incentives, modeling with process calculi and other such things in a single transition with a billion dollars at stake is a tall order.

Thiết kế các thuật toán đồng thuận mới là một trong những nhiệm vụ thách thức nhất trong khoa học máy tính, như được minh họa bởi Giải thưởng Turing của Lamport cho Paxos.
Cố gắng giải quyết các vấn đề về khả năng mở rộng, khuyến khích của con người, mô hình hóa với tính toán quy trình và những thứ khác trong một lần chuyển đổi duy nhất với tỷ lệ tiền đe dọa là một thứ tự cao.

It seems far more reasonable to embrace a smaller change and focus on the other major deficiencies of the system such as the developer experience of smart contracts or sub-protocols such as the recent ZCash contract and HAWK. Therefore, I will advocate to remove the difficulty bomb and to transition to something like VCUâ€™s recently developed 

Có vẻ hợp lý hơn nhiều khi nắm lấy một sự thay đổi nhỏ hơn và tập trung vào các thiếu sót lớn khác của hệ thống như trải nghiệm nhà phát triển về các hợp đồng thông minh hoặc các giao thức phụ như hợp đồng ZCASH gần đây và Hawk.
Do đó, tôi sẽ ủng hộ để loại bỏ quả bom khó khăn và chuyển sang một thứ như được phát triển gần đây

[](https://eprint.iacr.org/2016/716.pdf)

[] (https://eprint.iacr.org/2016/716.pdf)

PoW/PoS hybrid algorithm

Thuật toán lai POW/POS

, which enjoys an incredibly sound theoretical foundation and the careful hand of peer review. Furthermore, when ETH takes the leap to Casper, the miners have somewhere to go.

, trong đó thích một nền tảng lý thuyết cực kỳ âm thanh và bàn tay cẩn thận của đánh giá ngang hàng.
Hơn nữa, khi ETH thực hiện bước nhảy vọt đến Casper, những người khai thác có một nơi nào đó để đi.

As a final point in the short term roadmap, the failure of the DAO is not solely due to the arrogance and greed of the Slock.it team. The language they used to develop the DAO (solidity) was never designed for high assurance software. There exist well designed formal methods such as coq proofs that can provide 

Là điểm cuối cùng trong lộ trình ngắn hạn, sự thất bại của DAO không chỉ là do sự kiêu ngạo và tham lam của đội Slock.it.
Ngôn ngữ họ sử dụng để phát triển DAO (Solidity) không bao giờ được thiết kế cho phần mềm đảm bảo cao.
Tồn tại các phương pháp chính thức được thiết kế tốt như bằng chứng COQ có thể cung cấp

[](https://www.youtube.com/watch?v=-4Yp3j_jk8Q)

[] (https://www.youtube.com/watch?v=-4YP3J_JK8Q)

mathematical guarantees of behavior

đảm bảo toán học về hành vi

.

.

It has always puzzled me why the ethereum team didnâ€™t initially emphasize these techniques. Smart contracts are generally small pieces of code that need high assurance of correctness. Thatâ€™s literally what these tools were developed to provide. There has been some great 

Nó luôn làm tôi bối rối tại sao nhóm Ethereum không nhấn mạnh vào các kỹ thuật này.
Hợp đồng thông minh thường là những đoạn mã nhỏ cần sự đảm bảo cao về tính chính xác.
Đó là những gì theo nghĩa đen những gì các công cụ này đã được phát triển để cung cấp.
Đã có một số tuyệt vời

[](http://publications.lib.chalmers.se/records/fulltext/234939/234939.pdf)

[] (http://publications.lib.chalmers.se/records/fulltext/234939/234939.pdf)

initial work done by Pattersson and Edstrom at Chalmers on using Idris to draft smart contracts. Furthermore, the Foundation seems to be taking 

Công việc ban đầu được thực hiện bởi Pattersson và Edstrom tại Chalmers về việc sử dụng IDRIS để soạn thảo các hợp đồng thông minh.
Hơn nữa, nền tảng dường như đang lấy

[](https://www.youtube.com/watch?v=rx0NPckEWGI)

[] (https://www.youtube.com/watch?v=rx0Npckewgi)

formal verification more seriously. I will support work along these lines and attempt to bring such things to ETC.

Xác minh chính thức nghiêm túc hơn.
Tôi sẽ hỗ trợ công việc dọc theo các dòng này và cố gắng mang những thứ như vậy đến, v.v.

Third, there is the matter of governance and funding. As I previously stated, I believe firmly it is counterproductive to establish a new foundation for ETC. We are blessed with an opportunity to try new ideas. Ralph Merkle has recently published a well written whitepaper (cite) on a system called 

Thứ ba, có vấn đề quản trị và tài trợ.
Như tôi đã nói trước đây, tôi tin rằng chắc chắn việc thiết lập một nền tảng mới cho ETC.
Chúng tôi may mắn có một cơ hội để thử những ý tưởng mới.
Ralph Merkle gần đây đã xuất bản một whitepaper được viết tốt (trích dẫn) trên một hệ thống gọi là

[](http://merkle.com/papers/DAOdemocracyDraft.pdf)

[] (http://merkle.com/papers/daodemocarydraft.pdf)

DAOs, Democracy and Governance

Daos, Dân chủ và Quản trị

based upon ideas from Robin Hanson and others (

dựa trên ý tưởng từ Robin Hanson và những người khác (

[](https://www.youtube.com/watch?v=dvzpvXLbpv4)

[] (https://www.youtube.com/watch?v=DVZPVXLBPV4)

also enjoy his recent Epicenter Bitcoin Interview). Arthur Breitman is preparing to release the first version of 

Cũng tận hưởng cuộc phỏng vấn Bitcoin Epicenter gần đây của anh ấy).
Arthur Breitman đang chuẩn bị phát hành phiên bản đầu tiên của

[](https://www.youtube.com/watch?v=3mgaDpuMSc0)

[] (https://www.youtube.com/watch?v=3MGADPUMSC0)

Tezos at Strange Loop in September that will create a formal mechanism to update a cryptocurrency protocol. And the Dash community seems to be focusing heavily on decentralizing governance and appears to have achieved some degree of success for their project. Given all of these advancements and great ideas, why should we resign ourselves to a foundation chained to local laws in a particular jurisdiction with a director?

Tezos tại Strange Loop vào tháng 9 sẽ tạo ra một cơ chế chính thức để cập nhật giao thức tiền điện tử.
Và cộng đồng Dash dường như đang tập trung rất nhiều vào việc phân cấp quản trị và dường như đã đạt được một mức độ thành công nào đó cho dự án của họ.
Đưa ra tất cả những tiến bộ và ý tưởng tuyệt vời này, tại sao chúng ta phải từ chức một nền tảng bị xích vào luật pháp địa phương trong một khu vực tài phán cụ thể với một giám đốc?

It seems more prudent to gain community consensus on where ETC and ETH will diverge in the immediate future and then focus attention on developing a better governance model inspired by these ideas. As for funding, IOHK will commit to hiring three full time developers to exclusively work on implementing a roadmap for ETC for at least one year. Furthermore, IOHKâ€™s research division will develop a governance proposal within that year for ETC. In terms of an initial start, we are exploring if our 

Có vẻ như thận trọng hơn để đạt được sự đồng thuận của cộng đồng về nơi ETC và ETH sẽ phân kỳ trong tương lai trước mắt và sau đó tập trung sự chú ý vào việc phát triển một mô hình quản trị tốt hơn lấy cảm hứng từ những ý tưởng này.
Đối với tài trợ, IOHK sẽ cam kết thuê ba nhà phát triển toàn thời gian để thực hiện một lộ trình cho ETC trong ít nhất một năm.
Hơn nữa, bộ phận nghiên cứu của IOHK sẽ phát triển một đề xuất quản trị trong năm đó cho v.v.
Về mặt khởi đầu ban đầu, chúng tôi đang khám phá nếu

[](https://github.com/input-output-hk/Scorex)

[] (https://github.com/input-output-hk/scorex)

Scorex codebase

CodeBase điểm số

and EthereumJ can be hybridized.

và Ethereumj có thể được lai.

Finally and somewhat ironically, Iâ€™d like to try to be a peacemaker during my time in this community. We gain nothing from fighting each other or name calling. We gain nothing from staging 51% attacks or a lawsuit against entity X for grievances. The reality is that ethereum classic should be treated as sharedrop targeted towards ETH holders. Everyone got the drop. Some sold, some lost their ETC and yes the DAO hacker gets a large share. But it is important to point out no one paid for their initial ETC.

Cuối cùng và một cách trớ trêu, tôi muốn cố gắng trở thành một người hòa giải trong thời gian của tôi trong cộng đồng này.
Chúng tôi không đạt được gì từ việc chiến đấu với nhau hoặc gọi tên.
Chúng tôi không đạt được gì từ việc dàn dựng 51% các cuộc tấn công hoặc một vụ kiện chống lại thực thể X cho những bất bình.
Thực tế là Ethereum Classic nên được đối xử như chia sẻ nhắm vào người nắm giữ ETH.
Mọi người đã giảm.
Một số được bán, một số bị mất ETC của họ và vâng, hacker DAO nhận được một phần lớn.
Nhưng điều quan trọng là chỉ ra không ai trả tiền cho ban đầu của họ, v.v.

If we continue to treat ETC or ETH as the one true chain, then we will spend the next few years sorting out the differences if itâ€™s even possible. Letâ€™s instead treat this like a philosophical split of an existing open source project and someone gets to be libreoffice and someone gets to be open office. I understand itâ€™s not clean and that wasnâ€™t the decision of the people in ETC, but itâ€™s where we are at and we have to accept it.

Nếu chúng ta tiếp tục coi ETC hoặc ETH là một chuỗi thực sự, thì chúng ta sẽ dành vài năm tới để sắp xếp sự khác biệt nếu điều đó thậm chí có thể.
Thay vào đó, hãy coi điều này giống như một sự phân chia triết học của một dự án nguồn mở hiện có và ai đó trở thành Libreoffice và ai đó được mở văn phòng.
Tôi hiểu nó không sạch sẽ và đó không phải là quyết định của người dân, v.v., nhưng đó là nơi chúng tôi đang ở và chúng tôi phải chấp nhận nó.

As a fig leaf, it seems reasonable for the first joint effort of the ETH and ETC development teams should be an effort to completely resolve the replay attack concerns (

Là một lá sung, có vẻ hợp lý cho nỗ lực chung đầu tiên của các nhóm phát triển ETH và v.v.

[](http://vessenes.com/hard-fork-and-replay-concerns/)

[] (http://vessenes.com/hard-fork-and-replay-concerns/)

hereâ€™s a nice writeup

Đây là một bài viết tốt đẹp

). Someone has to blink.

).
Ai đó phải chớp mắt.

Successful divergence gives ETH and ETC a wonderful what if opportunity to AB test different ideas. Why should it be wasted because of pettiness? To the ETC community, Bitcoin stayed by its principles and has achieved a ten billion dollar market cap and changed the world. We donâ€™t need to win by destroying ETH.

Sự phân kỳ thành công mang lại cho ETH và vv một điều tuyệt vời nếu cơ hội để kiểm tra các ý tưởng khác nhau.
Tại sao nó nên bị lãng phí vì pettiness?
Đối với cộng đồng ETC, Bitcoin ở lại theo các nguyên tắc của nó và đã đạt được mức vốn hóa thị trường mười tỷ đô la và thay đổi thế giới.
Chúng tôi không cần phải giành chiến thắng bằng cách tiêu diệt ETH.

### **I Know This Place**

### **Tôi biết nơi này**

I hope you enjoyed reading this long blog as much as I enjoyed writing it. One of my fondest memories was traveling to Miami in January of 2014 and meeting the Ethereum team for the first time in person. It was an innocent time filled with unbounded potential and passion. ETC feels like those times again, and we have an incredible opportunity to do something special with a great community that is willing to go the extra mile for their principles. Thatâ€™s a rare gift and Iâ€™m glad to be part of it in any capacity thatâ€™s helpful to its growth.

Tôi hy vọng bạn thích đọc blog dài này nhiều như tôi thích viết nó.
Một trong những kỷ niệm đẹp nhất của tôi là đi đến Miami vào tháng 1 năm 2014 và lần đầu tiên gặp nhóm Ethereum.
Đó là một thời gian vô tội chứa đầy tiềm năng và niềm đam mê không giới hạn.
ETC cảm thấy như những lúc đó một lần nữa, và chúng tôi có một cơ hội đáng kinh ngạc để làm một cái gì đó đặc biệt với một cộng đồng tuyệt vời sẵn sàng đi xa hơn cho các nguyên tắc của họ.
Đó là một món quà hiếm hoi và tôi rất vui khi trở thành một phần của nó trong bất kỳ khả năng nào hữu ích cho sự phát triển của nó.

It seems I've come to know this place for the first time. Itâ€™s been a remarkable journey.

Có vẻ như tôi đã biết nơi này lần đầu tiên.
Đó là một hành trình đáng chú ý.

## **Attachments**

## ** tệp đính kèm **

![](img/2016-08-02-hoskus-parvum-opus-a-brief-sojourn-back-to-ethereum.004.png)[ Hoskus Parvum Opus, A Brief Sojourn Back to Ethereum - Input Output HongKong](https://ucarecdn.com/8da5e31b-3373-4151-96f6-b8ad1f5ad91e/-/inline/yes/ "Hoskus Parvum Opus, A Brief Sojourn Back to Ethereum - Input Output HongKong")

