# LTB Live - Ethereum: Consensus vs Immutability
![](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.002.png) 4 August 2016![](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.003.png) <1 min read

![Charles Hoskinson](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.004.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.005.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.006.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.007.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![LTB Live - Ethereum: Consensus vs Immutability](img/2016-08-04-ltb-live-ethereum-consensus-vs-immutability.008.jpeg)
