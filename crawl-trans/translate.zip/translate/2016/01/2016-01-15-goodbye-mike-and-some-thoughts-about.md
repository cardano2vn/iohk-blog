# Goodbye Mike and Some Thoughts About Bitcoin
![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.002.png) 15 January 2016![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.003.png) 15 mins read

![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.004.png)[ Goodbye Mike and Some Thoughts About Bitcoin - Input Output HongKong](https://ucarecdn.com/ba981b8a-8fa8-481c-80ee-bf0051d80f10/-/inline/yes/ "Goodbye Mike and Some Thoughts About Bitcoin - Input Output HongKong")

![Charles Hoskinson](img/2016-01-15-goodbye-mike-and-some-thoughts-about.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Goodbye Mike and Some Thoughts About Bitcoin](img/2016-01-15-goodbye-mike-and-some-thoughts-about.009.jpeg)
### **On Mike**
After reading Mike Hearn's 

Sau khi đọc Mike Hearn's

[](https://medium.com/@octskyward/the-resolution-of-the-bitcoin-experiment-dabb30201f7#.5p891umf0)

[] (https://medium.com/@octskyward/the-resolution-of-the-bitcoin-experiment-dabb30201f7#.5p891umf0)

farewell letter to the community

Thư chia tay cho cộng đồng

, I've decided to finally draft my thoughts on the blocksize debate, but first a few things about Mike. Hearn, joined the Bitcoin community back in May of 2009 and has been an active contributor for as long as I can remember in some capacity or another. He's also an incredibly bright and creative person who brought a lot to this ecosystem in its earliest days.

, Tôi đã quyết định cuối cùng đã phác thảo những suy nghĩ của mình về cuộc tranh luận về khối, nhưng trước tiên, một vài điều về Mike.
Hearn, gia nhập cộng đồng Bitcoin vào tháng 5 năm 2009 và là người đóng góp tích cực miễn là tôi có thể nhớ trong một khả năng này hay khả năng khác.
Anh ấy cũng là một người vô cùng sáng sủa và sáng tạo, người đã mang lại rất nhiều cho hệ sinh thái này trong những ngày đầu tiên.

The point of decentralized systems is never to reach ubiquitous consensus about truth. Settling upon a final truth is pyrrhic at best and almost certainly a sisyphean endeavor. The goal is to facilitate the free flow of ideas and provide an effective framework to actually test them with something at stake.

Điểm của các hệ thống phi tập trung là không bao giờ đạt được sự đồng thuận phổ biến về sự thật.
Giải quyết một sự thật cuối cùng là Pyrrhic tốt nhất và gần như chắc chắn là một nỗ lực của Sisyphean.
Mục tiêu là để tạo điều kiện cho dòng ý tưởng tự do và cung cấp một khung hiệu quả để thực sự kiểm tra chúng với một cái gì đó đang bị đe dọa.

Mike was a voice for a certain philosophy and regardless of whether you feel that philosophy is correct, it is a terrible tragedy that our community descended into the murky swamps of censorship and personal attacks. I will miss Mike and want to extend a profound thank you for all he has done and good luck on future projects.

Mike là một tiếng nói cho một triết lý nhất định và bất kể bạn có cảm thấy triết học đó là chính xác hay không, đó là một thảm kịch khủng khiếp mà cộng đồng của chúng ta rơi vào đầm lầy âm u của kiểm duyệt và các cuộc tấn công cá nhân.
Tôi sẽ nhớ Mike và muốn gửi lời cảm ơn sâu sắc cho tất cả những gì anh ấy đã làm và chúc may mắn cho các dự án trong tương lai.

All this said about Mike's contributions and positive influence on the space, I would be remiss if I didn't comment on his core argument that the Bitcoin project has failed. It's not only wrong, but utterly offensive to the thousands who have contributed weekends, painful explanations about the nature of money to their friends at bars and the repeated scorn of having to endure the scams, exchange failures and regulatory misunderstandings.

Tất cả những điều này nói về những đóng góp của Mike và ảnh hưởng tích cực đến không gian, tôi sẽ cảm thấy hối hận nếu tôi không bình luận về lập luận cốt lõi của anh ấy rằng dự án Bitcoin đã thất bại.
Không chỉ sai, mà hoàn toàn gây khó chịu cho hàng ngàn người đã đóng góp vào cuối tuần, những lời giải thích đau đớn về bản chất của tiền cho bạn bè của họ tại các quán bar và sự khinh miệt lặp đi lặp lại khi phải chịu đựng những trò gian lận, trao đổi thất bại và hiểu lầm quy định.

[](http://www.coindesk.com/charges-against-colorado-bitcoin-trader-dismissed/)

[] (http:

Burt Wagner

Burt Wagner

was arrested for legally selling bitcoin and had to spend his life savings to have the State of Colorado accept its own laws. He's still in the Bitcoin space. Many of the thousands affected by the collapse in MtGOX are still in the space. There are hundreds of meetup groups actively evangelizing, onboarding their local communities and coming up with creative solutions to various problems. A colleague of mine even paid for a recent meal at the Shard with Bitcoin thanks to the magic of Xapo (American beef is still better :) ):

đã bị bắt vì bán Bitcoin hợp pháp và phải dành tiền tiết kiệm thời gian của mình để có Bang Colorado chấp nhận luật pháp của chính mình.
Anh ấy vẫn ở trong không gian bitcoin.
Nhiều trong số hàng ngàn người bị ảnh hưởng bởi sự sụp đổ trong MTGOX vẫn còn trong không gian.
Có hàng trăm nhóm gặp gỡ tích cực truyền giáo, đưa lên cộng đồng địa phương của họ và đưa ra các giải pháp sáng tạo cho các vấn đề khác nhau.
Một đồng nghiệp của tôi thậm chí đã trả tiền cho một bữa ăn gần đây tại Shard với Bitcoin nhờ sự kỳ diệu của Xapo (thịt bò Mỹ vẫn tốt hơn :)):

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***Mike thinks we don't matter :(***|

| *** Mike nghĩ rằng chúng ta không quan trọng: (*** |

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***In Pounds; Paid in Bitcoin***|

| *** tính bằng bảng Anh;
Được trả bằng bitcoin *** |

Furthermore, the state of Bitcoin technology has never been better. One has to look no further than the [Princeton bitcoin paper](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwj3t4vloK3KAhUN4WMKHZKcBxkQFggdMAA&url=http%3A%2F%2Fwww.jbonneau.com%2Fdoc%2FBMCNKF15-IEEESP-bitcoin.pdf&usg=AFQjCNE534nrsn9uiTdfTHbKk6Z1Bws7cQ&sig2=Z0GnO8vJinjb5EtEFFZI2w) to see the amazing diversity of interesting problems being examined in academia and industry. A recent redditor posted a [database of over 600 papers on Bitcoin or related to cryptocurrency technology](https://docs.google.com/spreadsheets/d/1VaWhbAj7hWNdiE73P-W-wrl5a0WNgzjofmZXe0Rh5sg/edit?usp=sharing). [IC3 is a joint research group of two major US universities](http://www.initc3.org/) lead by some of the top cryptographers in the world and they have received a 3 million dollar NSF grant to study cryptocurrency technology. And yes those [scaling bitcoin conferences were very productive](https://lists.linuxfoundation.org/pipermail/bitcoin-dev/2015-December/011865.html) and included a lot of wonderful industry support: 

Hơn nữa, công nghệ Bitcoin chưa bao giờ tốt hơn. Người ta không phải tìm đâu xa ngoài [giấy bitcoin Princeton] (https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&co 2f%2fwww.jbonneau.com%2fdoc%2fbmcnkf15-ieesp-bitcoin.pdf & usg = afqjcne534nrsn9uitdfthbkk6z1bws7cq & sig2 Một Redditor gần đây đã đăng một [cơ sở dữ liệu của hơn 600 bài báo về Bitcoin hoặc liên quan đến công nghệ tiền điện tử] (https://docs.google.com/spreadsheets/d/1vawhbaj7hwndie73p-wrl5a0Wngz . Và vâng, những hội nghị Bitcoin mở rộng rất hiệu quả] (https://lists.linuxfoundation.org/pipermail/bitcoin-dev/2015-dember/011865.html) và bao gồm rất nhiều hỗ trợ công nghiệp tuyệt vời:

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***Mike thinks we don't matter :(***|

| *** Mike nghĩ rằng chúng ta không quan trọng: (*** |

Bitcoin has hundreds of thousands of passionate people, over a billion dollars in VC money and the support of ideas from over a thousand altcoins running experiments including Bitshares and Ethereum. The fact that we are having a transaction crisis is a symptom of success not coming doom!

Bitcoin có hàng trăm ngàn người đam mê, hơn một tỷ đô la tiền VC và sự hỗ trợ của các ý tưởng từ hơn một ngàn altcoin chạy các thí nghiệm bao gồm Bitshares và Ethereum.
Thực tế là chúng ta đang gặp khủng hoảng giao dịch là một triệu chứng thành công không đến!

So Mike I'm terribly sorry that you lost the XT fight and it's definitely true that it wasn't a fair fight, but don't take your anger out on Bitcoin the experiment nor the Bitcoin community:

Vì vậy, Mike, tôi rất xin lỗi vì bạn đã thua cuộc chiến XT và điều đó chắc chắn là đó không phải là một cuộc chiến công bằng, nhưng đừng trút giận lên Bitcoin, cũng như cộng đồng Bitcoin:

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***Darth Vader on Mike Hearn***|

| *** Darth Vader trên Mike Hearn *** |

### **Some Basics About Blocksize**

### ** Một số điều cơ bản về khối **

Now on to blocksize, there is already a great deal of detailed content floating around the interwebs on the various issues thus I will quickly summarize the crux of the matter. Bitcoin blocks have an arbitrary size cap of X MBs and each transaction takes on average Y bytes. As the network grows, we will (and have) hit this cap and the result will be an overall reduction of performance, reliability and robustness of the Bitcoin network.

Bây giờ để chặn, đã có rất nhiều nội dung chi tiết trôi nổi xung quanh các interwebs về các vấn đề khác nhau, do đó tôi sẽ nhanh chóng tóm tắt mấu chốt của vấn đề.
Các khối bitcoin có giới hạn kích thước tùy ý là X MBS và mỗi giao dịch mất trung bình y byte.
Khi mạng phát triển, chúng tôi sẽ (và có) đạt được giới hạn này và kết quả sẽ là giảm tổng thể hiệu suất, độ tin cậy và độ mạnh của mạng bitcoin.

So how does one resolve this seemingly intractable problem? The naive and kicking the can down the road solution is simply to increase the blocksize from X to a new arbitrary amount- say X(1). If Bitcoin continues to grow, then we'd have the same debate all over again in a few months or perhaps years (

Vậy làm thế nào để một người giải quyết vấn đề dường như khó hiểu này?
Giải pháp ngây thơ và đá có thể xuống giải pháp đường bộ chỉ đơn giản là tăng khối khối từ X lên một lượng tùy ý mới- nói x (1).
Nếu Bitcoin tiếp tục phát triển, thì chúng ta sẽ có cùng một cuộc tranh luận trong một vài tháng hoặc có lẽ nhiều năm (

[](https://en.wikipedia.org/wiki/United_States_debt-ceiling_crisis_of_2011)

[] (https://en.wikipedia.org/wiki/united_states_debt-ceiling_crisis_of_2011)

see US Debt Ceiling Debates

Xem các cuộc tranh luận về trần nợ của chúng tôi

). This said, one could develop either an algorithm to scale blocksize via some set of network parameters or increase it at regular intervals similar to how coinbase awards are cut in half every four years.

).
Điều này cho biết, người ta có thể phát triển một thuật toán để tỷ lệ khối khối thông qua một số tập hợp các tham số mạng hoặc tăng nó theo các khoảng thời gian đều đặn tương tự như cách các giải thưởng Coinbase bị cắt giảm trong một nửa mỗi bốn năm.

One could also increase the rate of block production (referred to as the block interval). There have been several proposals to do this in a way that wouldn't increase the amount of stale blocks and Ethereum even implemented one called 

Người ta cũng có thể tăng tốc độ sản xuất khối (được gọi là khoảng thời gian khối).
Đã có một số đề xuất để làm điều này theo cách không làm tăng số lượng khối cũ và Ethereum thậm chí đã thực hiện một

[](https://eprint.iacr.org/2013/881.pdf)

[] (https://eprint.iacr.org/2013/881.pdf)

GHOST developed by Zohar and Sompolinsky. The basic concept is turn Bitcoin's blockchain into a 

Ghost được phát triển bởi Zohar và Sompolinsky.
Khái niệm cơ bản là biến blockchain của Bitcoin thành một

[](https://www.youtube.com/watch?v=LOr_abIZL04)

[] (https://www.youtube.com/watch?v=lor_Abizl04)

directed acyclic graph from an append only linked list. This path is reasonable, but doesn't resolve the issue of data bloat (more on this later).

Đồ thị acyclic được định hướng từ một danh sách chỉ liên kết.
Đường dẫn này là hợp lý, nhưng không giải quyết được vấn đề về dữ liệu phình ra (nhiều hơn về vấn đề này sau).

We could approach the problem from the other side by examining transactions. Again the most naive approach is to reduce the size of transactions from Y to something smaller say Y(1). Again this approach doesn't solve the fundamental problem that future growth will push blocks to their cap.

Chúng tôi có thể tiếp cận vấn đề từ phía bên kia bằng cách kiểm tra các giao dịch.
Một lần nữa, cách tiếp cận ngây thơ nhất là giảm quy mô của các giao dịch từ y xuống một cái gì đó nhỏ hơn nói y (1).
Một lần nữa phương pháp này không giải quyết được vấn đề cơ bản rằng sự tăng trưởng trong tương lai sẽ đẩy các khối lên nắp của họ.

Along the same line of thought, one could create a mechanism to gradually retire transactions (called pruning) or reduce the amount stored on chain. There have been some interesting ideas proposed like 

Cùng một dòng suy nghĩ, người ta có thể tạo ra một cơ chế để nghỉ hưu dần dần (được gọi là cắt tỉa) hoặc giảm số lượng được lưu trữ trên chuỗi.
Đã có một số ý tưởng thú vị được đề xuất như

[](https://www.youtube.com/watch?v=NOYNZB5BCHM)

[] (https://www.youtube.com/watch?v=noyNZB5BCHM)

segregated witnesses

Nhân chứng tách biệt

and Pieter Wuille has been a great mind in considering pruning. It's a nice efficiency improvement and something that could definitely help the network, but again doesn't solve the core issue of long term growth.

Và Pieter Wuille đã là một tâm trí tuyệt vời trong việc xem xét cắt tỉa.
Đó là một cải tiến hiệu quả tốt đẹp và một cái gì đó chắc chắn có thể giúp mạng, nhưng một lần nữa không giải quyết được vấn đề cốt lõi của tăng trưởng dài hạn.

Finally, one could push transactions off-chain so they don't appear in the Bitcoin network at all or eventually in a reduced form. This idea is seen in efforts like the 

Cuối cùng, người ta có thể đẩy các giao dịch ra khỏi chuỗi để chúng không xuất hiện trong mạng bitcoin hoặc cuối cùng ở dạng giảm.
Ý tưởng này được nhìn thấy trong những nỗ lực như

[](https://lightning.network/)

[] (https://lightning.network/)

Bitcoin Lightning Network and the 

Mạng Lightning Bitcoin và

[](http://gendal.me/2014/10/26/a-simple-explanation-of-bitcoin-sidechains/)

[] (http:

Sidechains project. It's the most politically friendly of all proposals as there are already many projects exploring how to facilitate the offchain infrastructure without necessarily requiring a fork of the Bitcoin protocol (or at least a dramatic hard fork). As a side note, It's probably not an accident that a large pool of the Bitcoin core developers happen to work for the company spearheading these approaches.

Dự án Sidechains.
Đó là sự thân thiện nhất về mặt chính trị trong tất cả các đề xuất vì đã có nhiều dự án khám phá cách tạo điều kiện cho cơ sở hạ tầng ngoài khơi mà không nhất thiết phải yêu cầu giao thức bitcoin (hoặc ít nhất là một hard hard ấn tượng).
Một lưu ý phụ, có lẽ không phải là một tai nạn mà một nhóm lớn các nhà phát triển lõi Bitcoin tình cờ làm việc cho công ty dẫn đầu các phương pháp này.

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***Blade Runner's take on Transaction Pruning and Off-Chain Solutions***|

| *** Blade Runner thực hiện các giải pháp cắt tỉa giao dịch và ngoài chuỗi *** |

Off-chain is compelling, but still has a lot of unresolved questions about trust models, security concerns, centralization issues (in certain cases) and also unpredictable privacy (for example, if transactions are moving to a new network, then the gatekeepers of that network could attach metadata to the transactions for KYC/AML and other such things). Furthermore, the practical question of why bother seems to be looming? We are going to solve the issues of Bitcoin by using federated or centralized actors?

Chuỗi Off rất hấp dẫn, nhưng vẫn có rất nhiều câu hỏi chưa được giải quyết về các mô hình ủy thác, mối quan tâm bảo mật, các vấn đề tập trung hóa (trong một số trường hợp nhất định) và cũng không thể đoán trước được
Mạng có thể đính kèm siêu dữ liệu vào các giao dịch cho KYC/AML và những thứ khác như vậy).
Hơn nữa, câu hỏi thực tế về lý do tại sao lại bận tâm dường như lờ mờ?
Chúng ta sẽ giải quyết các vấn đề của Bitcoin bằng cách sử dụng các tác nhân liên kết hoặc tập trung?

I recall the argument to get merchants to adopt bitcoin is to use services like Bitpay, yet then we go back to the solution to asset volatility of our decentralized network is to connect all the merchants to a centralized service provider? The same applies for transaction scalability solutions for the Bitcoin network. Seek decentralization wherever possible!

Tôi nhớ lại đối số để khiến các thương nhân áp dụng Bitcoin là sử dụng các dịch vụ như BitPay, nhưng sau đó chúng tôi quay lại giải pháp cho sự biến động tài sản của mạng phi tập trung của chúng tôi là kết nối tất cả các thương nhân với nhà cung cấp dịch vụ tập trung?
Điều tương tự cũng áp dụng cho các giải pháp khả năng mở rộng giao dịch cho mạng bitcoin.
Tìm kiếm sự phân cấp bất cứ nơi nào có thể!

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***What the Bitcoin movement is trying to do in a nutshell***|

| *** Phong trào Bitcoin đang cố gắng làm gì trong một Nutshell *** |

Â  

MỘT

### **Solutions in a Technological Context**

### ** Giải pháp trong bối cảnh công nghệ **

Â  

MỘT

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***I created this graphic on Gliffy. Gliffy is pretty Spiffy!***|

| *** Tôi đã tạo ra đồ họa này trên Gliffy.
Gliffy khá là Spiffy! *** |

The diagram above presents a rough idea of what the Bitcoin blockchain actually looks like. There are two components: a block header and the block body storing the actual transactions.

Biểu đồ trên thể hiện một ý tưởng sơ bộ về blockchain bitcoin thực sự trông như thế nào.
Có hai thành phần: tiêu đề khối và thân khối lưu trữ các giao dịch thực tế.

All the parts are wired together with some form of crypto. The block body is connected to the header via a merkle tree data structure. The headers are wired together via hash pointers. And proof of work provides a mechanism for validating a given collection of blocks (the proposed blockchain) is the correct one via the notion of algorithmic weight (the proposed chain with the most work wins).

Tất cả các bộ phận được nối cùng với một số dạng tiền điện tử.
Thân khối được kết nối với tiêu đề thông qua cấu trúc dữ liệu cây Merkle.
Các tiêu đề được nối với nhau thông qua các con trỏ băm.
Và bằng chứng công việc cung cấp một cơ chế để xác thực một bộ sưu tập các khối nhất định (blockchain được đề xuất) là chính xác thông qua khái niệm trọng lượng thuật toán (chuỗi đề xuất có nhiều chiến thắng công việc nhất).

So we have been given a menu of options to change the core protocol to reflect the goal of more transactions. Increasing the blocksize makes the block contents heavier (larger merkle tree), but has no impact on the block header. It's an interesting question to consider the impact of larger blocks on block propagation times. I'd highly recommend this 

Vì vậy, chúng tôi đã được cung cấp một menu các tùy chọn để thay đổi giao thức cốt lõi để phản ánh mục tiêu của nhiều giao dịch hơn.
Tăng khối khối làm cho nội dung khối nặng hơn (cây Merkle lớn hơn), nhưng không có tác động đến tiêu đề khối.
Đó là một câu hỏi thú vị để xem xét tác động của các khối lớn hơn đối với thời gian lan truyền khối.
Tôi rất khuyến khích điều này

[](http://diyhpl.us/%7Ebryan/papers2/bitcoin/Information%20propagation%20in%20the%20Bitcoin%20network.pdf)

[] (http:

excellent paper

Giấy tuyệt vời

studying propagation in general by Decker and Wattenhoffer.

Nghiên cứu tuyên truyền nói chung bằng Decker và Watttenhoffer.

Reducing the block interval will likely involve changing the structure from a single hash pointer to multiple hash pointers to different blocks, but no impact on the block contents. Inclusion of double spend transactions and longest chain selection rules are the topics of primary interest here. I'd recommend two papers to get a deeper understanding. First, Sergio Lerner's 

Việc giảm khoảng thời gian khối có thể sẽ liên quan đến việc thay đổi cấu trúc từ một con trỏ băm đơn sang nhiều con trỏ băm sang các khối khác nhau, nhưng không có tác động đến nội dung khối.
Bao gồm các giao dịch chi tiêu gấp đôi và các quy tắc lựa chọn chuỗi dài nhất là chủ đề quan tâm chính ở đây.
Tôi muốn giới thiệu hai bài báo để có được sự hiểu biết sâu sắc hơn.
Đầu tiên, Sergio Lerner's

[](https://bitslog.files.wordpress.com/2015/09/dagcoin-v41.pdf)

[] (https://bitslog.files.wordpress.com/2015/09/dagcoin-v41.pdf)

DAG-Coin proposal and then Lewenberg et all 

Đề xuất của Dag-Coin và sau đó là Lewenberg et tất cả

[](http://fc15.ifca.ai/preproceedings/paper_101.pdf)

[] (http://fc15.ifca.ai/preproceedings/paper_101.pdf)

Inclusive Blockchain Protocols.

Giao thức blockchain bao gồm.

Pruning means that over time certain leaves in the merkle tree should be removed or perhaps even entire blocks replaced with different representations. It's also interesting to consider what other authenticated data structures could be put into the block headers to improve scalability or better facilitate pruning schemes without compromising trust. The Bitcoin wonderkid researcher Andrew Miller has 

Cắt tỉa có nghĩa là theo thời gian, một số lá trong cây Merkle nên được loại bỏ hoặc thậm chí có thể toàn bộ các khối được thay thế bằng các biểu diễn khác nhau.
Cũng rất thú vị khi xem xét những cấu trúc dữ liệu được xác thực khác có thể được đưa vào các tiêu đề khối để cải thiện khả năng mở rộng hoặc tạo điều kiện tốt hơn cho các sơ đồ cắt tỉa mà không ảnh hưởng đến niềm tin.
Nhà nghiên cứu Bitcoin Wonderkid Andrew Miller có

[](https://www.cs.umd.edu/%7Emwh/papers/gpads.pdf)

[] (https://www.cs.umd.edu/%7emwh/papers/gpads.pdf)

done some foundational research

thực hiện một số nghiên cứu nền tảng

with Katz and others.

với Katz và những người khác.

And finally off-chain means that we are effectively wiring something more onto the block via the header or more likely in the block contents. The concept here is separation of concerns and layering. For example, 

Và cuối cùng ngoài chuỗi có nghĩa là chúng ta đang nối dây một cách hiệu quả một thứ gì đó nhiều hơn vào khối thông qua tiêu đề hoặc nhiều khả năng trong nội dung khối.
Khái niệm ở đây là tách các mối quan tâm và xếp lớp.
Ví dụ,

[](http://www.rootstock.io/)

[] (http://www.rootstock.io/)

rootstock

gốc gốc

is discussing how to do smart contracts via a sidechain of bitcoin. This area reduces the need for whole sets of transactions by simply having them done outside of the main Bitcoin blockchain in different domain. It also modularizes the set of things a client has to download.

đang thảo luận về cách thực hiện hợp đồng thông minh thông qua một sidechain của Bitcoin.
Khu vực này làm giảm nhu cầu toàn bộ các bộ giao dịch bằng cách chỉ cần thực hiện bên ngoài blockchain bitcoin chính trong các miền khác nhau.
Nó cũng mô đun hóa tập hợp những thứ mà khách hàng phải tải xuống.

### **The Hidden Demons Behind the Debate**

### ** Những con quỷ ẩn đằng sau cuộc tranh luận **

The original design of Bitcoin was to have a completely decentralized network of equal actors with no barrier to entry for participation. Mining was done on ordinary CPUs ([in fact Satoshi mined more than a million bitcoins using CPUs](https://bitslog.wordpress.com/2013/04/17/the-well-deserved-fortune-of-satoshi-nakamoto/)). Maintaining a full node wasn't a serious commitment. It was less taxing than running bittorrent with a few HD movies.

Thiết kế ban đầu của Bitcoin là có một mạng lưới hoàn toàn phi tập trung của các diễn viên bình đẳng không có rào cản để tham gia.
Khai thác được thực hiện trên CPU thông thường ([thực tế Satoshi đã khai thác hơn một triệu bitcoin bằng CPU] (https://bitslog.wordpress.com/2013/04/17/the-well-deserved-fortune-of-satoshi-nakamoto
/)).
Duy trì một nút đầy đủ không phải là một cam kết nghiêm túc.
Nó ít đánh thuế hơn là chạy Bittorrent với một vài bộ phim HD.

The separation of block headers from the block contents does suggest a path to heterogeneity via light nodes holding only the header collection; however, again this action isn't forced upon anyone.

Việc tách các tiêu đề khối từ các nội dung khối cho thấy một đường dẫn đến tính không đồng nhất thông qua các nút ánh sáng chỉ giữ bộ sưu tập tiêu đề;
Tuy nhiên, một lần nữa hành động này không bị ép buộc.

Now enter 2016, Bitcoin is a very different animal. The Bitcoin blockchain has grown considerably. Mining is heavily centralized:

Bây giờ bước vào năm 2016, Bitcoin là một con vật rất khác.
Các blockchain bitcoin đã phát triển đáng kể.
Khai thác được tập trung nhiều:

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***These Guys Own More than 51 Percent of the Mining Power***|

| *** Những người này sở hữu hơn 51 phần trăm sức mạnh khai thác *** |

There are millions of dollars of value floating around every block. There are numerous, well-funded business interests and even a cabal of powerful bankers scheming in a sufficiently NWOish named group called R3CEV: 

Có hàng triệu đô la giá trị nổi xung quanh mỗi khối.
Có rất nhiều lợi ích kinh doanh được tài trợ tốt và thậm chí là một nhóm các chủ ngân hàng mạnh mẽ âm mưu trong một nhóm có tên đủ của NWOISH có tên là R3CEV:

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***Totally not trying to co-opt the ecosystem!***|

| *** Hoàn toàn không cố gắng hợp tác với hệ sinh thái! *** |

Thus things have really changed over the past seven years beyond the humble beginnings of Hal and Satoshi trying to get the wallet to work in order to send a single transaction (It was block 170 BTW- a whole 10 bitcoins!).

Do đó, mọi thứ đã thực sự thay đổi trong bảy năm qua ngoài sự khởi đầu khiêm tốn của Hal và Satoshi đang cố gắng để ví hoạt động để gửi một giao dịch duy nhất (đó là khối 170 btw- toàn bộ 10 bitcoin!).

I feel that this debate has exposed more than certain people's inability to work productively with each other or the need for a new set of reddit moderators. It has exposed that Bitcoin is basically at a philosophical impasse. There really isn't a clear direction for the Bitcoin ecosystem to take. Is it supposed to be the ultimate payment system with a super cool deflationary digital gold coin backing it? Is it a settlement layer for many systems to eventually clear upon? Is it the arbiter of digital truth providing a cryptographic beacon, notary services and a logical clock? Is it a system for decentralized governance?

Tôi cảm thấy rằng cuộc tranh luận này đã phơi bày nhiều hơn một số người không có khả năng làm việc hiệu quả với nhau hoặc nhu cầu về một bộ điều hành Reddit mới.
Nó đã phơi bày rằng Bitcoin về cơ bản là một sự bế tắc triết học.
Thực sự không có hướng đi rõ ràng cho hệ sinh thái Bitcoin.
Có phải nó được cho là hệ thống thanh toán cuối cùng với một đồng tiền vàng kỹ thuật số giảm phát siêu tuyệt vời ủng hộ nó?
Đây có phải là một lớp định cư cho nhiều hệ thống để cuối cùng rõ ràng?
Đây có phải là trọng tài của sự thật kỹ thuật số cung cấp đèn hiệu mã hóa, dịch vụ công chứng và đồng hồ logic?
Nó có phải là một hệ thống cho quản trị phi tập trung?

Fair arguments can be made for any of these directions and there is a legion of good tech to sneak into the protocol to make Bitcoin better suited for these tasks. In general, Bitcoin could basically be the entire financial stack:

Các đối số công bằng có thể được thực hiện cho bất kỳ hướng dẫn nào trong số này và có một quân đoàn tốt để lẻn vào giao thức để làm cho Bitcoin phù hợp hơn với các nhiệm vụ này.
Nói chung, Bitcoin về cơ bản có thể là toàn bộ ngăn xếp tài chính:

|![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.010.png)|

| :- |

|
:- |

|***Bitcoin could be the whole stack***|

| *** Bitcoin có thể là toàn bộ ngăn xếp *** |

We simply cannot productively move forward until the meta-question of **what does bitcoin want to be when it grows up** is answered. There is no measuring stick to say ok this is good enough. For example, 3 transactions per second is absolutely fine if our goal is settlement of large contracts between multibillion dollar actors, but it's terrible if we are trying to replace VISA.

Chúng tôi chỉ đơn giản là không thể tiến lên một cách hiệu quả cho đến khi câu hỏi meta của ** Bitcoin muốn gì khi nó lớn lên ** được trả lời.
Không có thước đo để nói OK điều này là đủ tốt.
Ví dụ, 3 giao dịch mỗi giây là hoàn toàn tốt nếu mục tiêu của chúng tôi là giải quyết các hợp đồng lớn giữa các diễn viên trị giá hàng tỷ đô la, nhưng thật khủng khiếp nếu chúng tôi đang cố gắng thay thế Visa.

Should Bitcoin be blind and deaf to other systems and cryptocurrency or does it need to talk to them on a regular basis? Are we going to tokenize all assets like gold and USDs and trade them in a decentralized network? Or are we going to trade them on exchanges and move them between exchanges using some connection to the Bitcoin blockchain? If there is a dispute, then is arbitration connected to the data held on a blockchain?

Bitcoin có nên bị mù và điếc với các hệ thống và tiền điện tử khác hay nó cần phải nói chuyện với họ một cách thường xuyên?
Chúng ta sẽ token hóa tất cả các tài sản như vàng và USD và giao dịch chúng trong một mạng lưới phi tập trung?
Hay chúng ta sẽ giao dịch chúng trên các sàn giao dịch và di chuyển chúng giữa các trao đổi bằng cách sử dụng một số kết nối với blockchain bitcoin?
Nếu có tranh chấp, thì trọng tài có được kết nối với dữ liệu được giữ trên blockchain không?

Each of these questions and the hundreds more have a dramatic impact on what needs to go into a transaction, how of many per second we need to include in the Bitcoin blockchain and also the intended set of users. Let's be intellectually honest, have we answered them? Where do you even go to start that process? Who gets to decide?

Mỗi câu hỏi này và hàng trăm người khác có tác động mạnh mẽ đến những gì cần phải đi vào một giao dịch, làm thế nào nhiều giây mỗi giây chúng ta cần đưa vào blockchain bitcoin và cả bộ người dùng dự định.
Hãy trung thực về mặt trí tuệ, chúng ta đã trả lời họ chưa?
Bạn thậm chí đi đâu để bắt đầu quá trình đó?
Ai được quyết định?

In effect, we don't have a blocksize crisis, we have a governance and philosophy crisis. And the pain will continue until this crisis has been resolved either out of some cabal gaining control of the network or by a new mechanism to decide things in a decentralized manner (See 

Trên thực tế, chúng ta không có một cuộc khủng hoảng khối, chúng ta có một cuộc khủng hoảng quản trị và triết học.
Và nỗi đau sẽ tiếp tục cho đến khi cuộc khủng hoảng này được giải quyết ngoài một số quyền kiểm soát mạng lưới hoặc bằng một cơ chế mới để quyết định mọi thứ theo cách phi tập trung (xem

[](https://en.wikipedia.org/wiki/Decentralized_autonomous_organization)

[].

DAO

Đạo

s).

S).

### **My Proposal to Solve the Debate**

### ** Đề xuất của tôi để giải quyết cuộc tranh luận **

Since everyone has a proposal, I might as well throw my hat into the ring. First, we need to solve the immediate crisis at hand. Let's take Kryder's Law of storage growth and combine it with Nielsen's law of bandwidth to produce a reasonable rate of block growth in regular intervals. The basic idea is that blocks will grow at a rate that scales with local storage and the rate of bandwidth increases of internet connections.

Vì mọi người đều có một đề xuất, tôi cũng có thể ném chiếc mũ của mình vào võ đài.
Đầu tiên, chúng ta cần giải quyết cuộc khủng hoảng ngay lập tức trong tay.
Chúng ta hãy lấy luật tăng trưởng lưu trữ của Kryder và kết hợp nó với định luật băng thông của Nielsen để tạo ra tốc độ tăng trưởng khối hợp lý theo các khoảng thời gian đều đặn.
Ý tưởng cơ bản là các khối sẽ phát triển với tốc độ mở rộng với lưu trữ cục bộ và tốc độ tăng băng thông của các kết nối internet.

Second, adopt the plan devised at the scaling bitcoin conference. It's reasonable and doesn't require dramatic action. Segregated witnesses in particular are a very solid concept. Furthermore, scaling bitcoin should really be a bi-annual event moving forward- get people talking to each other on a regular basis.

Thứ hai, áp dụng kế hoạch được nghĩ ra tại Hội nghị Bitcoin quy mô.
Đó là hợp lý và không yêu cầu hành động kịch tính.
Các nhân chứng tách biệt nói riêng là một khái niệm rất vững chắc.
Hơn nữa, việc mở rộng Bitcoin thực sự sẽ là một sự kiện hai năm một lần tiến về phía trước- khiến mọi người nói chuyện với nhau một cách thường xuyên.

Both of these actions will take the pain off of the network and give us some breathing room. We have to then move on to phase II, which is investing in some foundational technology to radically improve the entire network.

Cả hai hành động này sẽ loại bỏ nỗi đau của mạng và cho chúng tôi một số phòng thở.
Sau đó, chúng ta phải chuyển sang Giai đoạn II, đó là đầu tư vào một số công nghệ nền tảng để cải thiện triệt để toàn bộ mạng.

- Sidechains is a fundamentally sound and reasonable idea. It's a conversation about getting blockchains to talk to each other and move value without needing special actors. The project is also incredibly well funded and backed by some of the best people in the space. Sprinkle some soft fork on that shit. In the absence of soft forking, [BTC-Relay](http://btcrelay.org/) is pretty cool.

- Sidechains là một ý tưởng cơ bản và hợp lý.
Đó là một cuộc trò chuyện về việc có được blockchain để nói chuyện với nhau và di chuyển giá trị mà không cần các diễn viên đặc biệt.
Dự án cũng được tài trợ tốt và được hỗ trợ bởi một số người giỏi nhất trong không gian.
Rắc một số nĩa mềm lên cái chết tiệt đó.
Trong trường hợp không có sự thay đổi mềm mại, [BTC-relay] (http://btcrelay.org/) là khá tuyệt.

- Reducing the block interval is a really good idea. Ethereum's implementation of GHOST serves as a great example of a path to do this and the researchers behind DAGs are solid people. Faster settlement with the same level of security as the slower interval is frankly good for us all.

- Giảm khoảng thời gian khối là một ý tưởng thực sự tốt.
Việc thực hiện ma của Ethereum đóng vai trò là một ví dụ tuyệt vời về một con đường để làm điều này và các nhà nghiên cứu đằng sau DAG là những người vững chắc.
Giải quyết nhanh hơn với mức độ bảo mật tương tự như khoảng thời gian chậm hơn thực sự tốt cho tất cả chúng ta.

- Change Bitcoin's consensus algorithm from proof of work to something else. Mining centralization is a problem. The original idea was that the network was to be secured by many different people not a small cabal of anonymous mining corporations floating around Asia. Furthermore, we have a lot of cool things that can be done with different consensus algorithms like voting and allowing for many assets to exist concurrently on the Bitcoin network in a scalable and mobile friendly way.

- Thay đổi thuật toán đồng thuận của Bitcoin từ bằng chứng công việc sang một thứ khác.
Tập trung khai thác là một vấn đề.
Ý tưởng ban đầu là mạng lưới được bảo đảm bởi nhiều người khác nhau không phải là một nhóm nhỏ của các tập đoàn khai thác ẩn danh trôi nổi khắp châu Á.
Hơn nữa, chúng tôi có rất nhiều điều thú vị có thể được thực hiện với các thuật toán đồng thuận khác nhau như bỏ phiếu và cho phép nhiều tài sản tồn tại đồng thời trên mạng Bitcoin theo cách thân thiện và có thể mở rộng.

- Invest in Blockchain sharding. There is an interesting project by [Professor Shirer](https://www.cs.cornell.edu/people/egs/) that has some legs. The point here is that Bitcoin's data model is 1 byte requires N bytes of total storage with N being the set of full nodes. It's terribly wasteful. Increase the dataset from D to D(1) via erasure codes and then chop up the blockchain into reasonable sets of shards. We could have a many petabyte blockchain that is in 50 MB pieces. Changes to Bitcoin's consensus algorithm and fundamental data structures could dramatically help here.

- Đầu tư vào blockchain Sharding.
Có một dự án thú vị của [Giáo sư Shirer] (https://www.cs.cornell.edu/people/egs/) có một số chân.
Điểm ở đây là mô hình dữ liệu của Bitcoin là 1 byte yêu cầu n byte tổng lưu trữ với N là tập hợp các nút đầy đủ.
Nó thật lãng phí.
Tăng bộ dữ liệu từ D lên D (1) thông qua các mã xóa và sau đó cắt blockchain thành các bộ mảnh hợp lý.
Chúng ta có thể có nhiều blockchain petabyte trong các mảnh 50 MB.
Những thay đổi đối với thuật toán đồng thuận của Bitcoin và cấu trúc dữ liệu cơ bản có thể giúp ích đáng kể ở đây.

- Develop more productive federation technology for service providers in the Bitcoin space to interact with the Bitcoin blockchain. The reality is that we'll still have a lot of services off-chain entirely for privacy, cost or performance reasons, but we shouldn't have to completely trust the people running those networks. Ideas like Pavel Kravchenko's [Infraproject](https://docs.google.com/document/d/13dPJCaQ_NtS_nz4hEwf0WUAOe4RSpC1WpnCMOAPp7Kc/edit) and Blockstream's [Liquid](https://blockstream.com/2015/10/12/introducing-liquid/) are movements in the right direction as are concepts like proof of solvency.

- Phát triển công nghệ liên kết hiệu quả hơn cho các nhà cung cấp dịch vụ trong không gian Bitcoin để tương tác với Bitcoin Blockchain.
Thực tế là chúng tôi vẫn sẽ có nhiều dịch vụ hoàn toàn vì lý do quyền riêng tư, chi phí hoặc hiệu suất, nhưng chúng tôi không phải hoàn toàn tin tưởng vào những người chạy các mạng đó.
Các ý tưởng như Pavel Kravchenko [Infraproject] (https://docs.google.com/document/d/13dpjcaq_nts_nz4hewf0wuaoe4rspc1wpncmoapp7kc/edit).
) là các phong trào theo đúng hướng cũng như các khái niệm như bằng chứng về khả năng thanh toán.

- Create a mechanism to incentivize data relay on the Bitcoin network. As the network scales, there will be enormous amounts of data floating around and it needs to be economically optimized or else you'll have centralized hubs acting as relays to millions of dependent nodes. [Eric Lombrozo](https://github.com/CodeShark) has been a great voice of reason in this respect.

- Tạo một cơ chế để khuyến khích chuyển tiếp dữ liệu trên mạng bitcoin.
Khi quy mô mạng, sẽ có một lượng dữ liệu khổng lồ nổi xung quanh và nó cần được tối ưu hóa về mặt kinh tế nếu không bạn sẽ có các trung tâm tập trung đóng vai trò chuyển tiếp đến hàng triệu nút phụ thuộc.
[Eric Lombrozo] (https://github.com/codeshark) đã là một tiếng nói tuyệt vời của lý do về mặt này.

The final phase is to make Bitcoin a self-funding evolutionary system. There needs to be a DAO that integrates into the core protocol that provides a framework to discuss and implement BIPs as well as cover their associated costs of implementation.

Giai đoạn cuối cùng là biến Bitcoin thành một hệ thống tiến hóa tự tài trợ.
Cần phải có một DAO tích hợp vào giao thức cốt lõi cung cấp một khung để thảo luận và thực hiện các BIP cũng như chi trả các chi phí thực hiện liên quan của họ.

Until the development of Bitcoin is free from outside corporate influences, it can't be discussed in an objective and fact based way, and the stakeholders of the system are able to decide instead of a cabal of well capitalized actors, we aren't going to gain the resilience of the crowd.

Cho đến khi sự phát triển của Bitcoin không có ảnh hưởng bên ngoài của công ty, nó không thể được thảo luận một cách khách quan và thực tế, và các bên liên quan của hệ thống có thể quyết định thay vì một nhóm các diễn viên được viết hoa tốt, chúng ta sẽ không
Để có được sự kiên cường của đám đông.

This phase is probably an innovation of the size and scale of Bitcoin itself and thus is unlikely to materialize immediately, but organically over a collection of hundreds of experiments. And like Bitcoin, it would fundamentally change the very nature of organizations, their mandate and the flow of funding.

Giai đoạn này có lẽ là một sự đổi mới về kích thước và quy mô của chính Bitcoin và do đó không có khả năng thành hiện thực ngay lập tức, nhưng về mặt hữu cơ trên một tập hợp hàng trăm thí nghiệm.
Và giống như Bitcoin, về cơ bản nó sẽ thay đổi bản chất của các tổ chức, nhiệm vụ và dòng tài trợ của họ.

Thanks for Reading!

Cảm ơn vì đã đọc!

## **Attachments**

## ** tệp đính kèm **

![](img/2016-01-15-goodbye-mike-and-some-thoughts-about.004.png)[ Goodbye Mike and Some Thoughts About Bitcoin - Input Output HongKong](https://ucarecdn.com/ba981b8a-8fa8-481c-80ee-bf0051d80f10/-/inline/yes/ "Goodbye Mike and Some Thoughts About Bitcoin - Input Output HongKong")

