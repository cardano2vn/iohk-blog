# How to Save (Or Destroy) the Bitcoin Foundation
![](img/2016-01-12-how-to-save-or-destroy-bitcoin.002.png) 12 January 2016![](img/2016-01-12-how-to-save-or-destroy-bitcoin.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-01-12-how-to-save-or-destroy-bitcoin.003.png) 8 mins read

![](img/2016-01-12-how-to-save-or-destroy-bitcoin.004.png)[ How to Save (Or Destroy) the Bitcoin Foundation - Input Output HongKong](https://ucarecdn.com/797b349e-9715-475c-9915-4fc1b9ccbe45/-/inline/yes/ "How to Save (Or Destroy) the Bitcoin Foundation - Input Output HongKong")

![Charles Hoskinson](img/2016-01-12-how-to-save-or-destroy-bitcoin.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-01-12-how-to-save-or-destroy-bitcoin.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-01-12-how-to-save-or-destroy-bitcoin.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-01-12-how-to-save-or-destroy-bitcoin.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![How to Save (Or Destroy) the Bitcoin Foundation](img/2016-01-12-how-to-save-or-destroy-bitcoin.009.jpeg)

I've been thinking about the Bitcoin Foundation over the last few months. After I left as the first chairman of the education committee back in late 2013, I dismissed the Foundation as a mostly inept attempt by some business interests in the community to gain an edge over their competitors. The actions of 

Tôi đã suy nghĩ về Tổ chức Bitcoin trong vài tháng qua.
Sau khi tôi rời khỏi vị trí chủ tịch đầu tiên của ủy ban giáo dục vào cuối năm 2013, tôi đã bác bỏ nền tảng này là một nỗ lực chủ yếu là bất kỳ bởi một số lợi ích kinh doanh trong cộng đồng để có được lợi thế so với các đối thủ của họ.
Hành động của

[](http://qz.com/81167/bitcoin-75-million-coinlab-lawsuit-against-mt-gox-could-destroy-currency-exchange/)

[] (http:

Peter Vessenes and Mark Karpeles

Peter Vessenes và Mark Karpele

alongside the board's indifference to the Foundation's membership as well as the mainstream Bitcoin community made it seem likely that the Foundation would simply go bankrupt and collapse under its own weight like a great battleship built for a war that would never happen and then left to rust in neglect (see I can be poetic too). Sure enough, they are functionally bankrupt having burnt through about 7 million dollars worth of Bitcoin (they even spent a million dollars on that spiffy Amsterdam conference!).

Bên cạnh sự thờ ơ của hội đồng đối với tư cách thành viên của nền tảng cũng như cộng đồng Bitcoin chính thống khiến cho nền tảng này chỉ đơn giản là phá sản và sụp đổ dưới sức nặng của chính nó như một chiến hạm lớn được xây dựng cho một cuộc chiến sẽ không bao giờ xảy ra và sau đó bị rỉ sét để rỉ sét vào
Bỏ bê (xem tôi cũng có thể thơ ca).
Chắc chắn, họ bị phá sản về mặt chức năng khi bị đốt cháy trong khoảng 7 triệu đô la bitcoin (họ thậm chí còn chi một triệu đô la cho hội nghị Amsterdam Spiffy đó!).

So why the sudden interest after my self-imposed exile? After traveling extensively throughout the world, I've notice that there is still an impression internationally that the Foundation is relevant and in some way represents Bitcoin- especially among the international press. It's not accurate and probably similar in spirit to the headlines stating Bitcoin's CEO has been arrested.

Vậy tại sao sự quan tâm đột ngột sau khi tôi bị lưu đày?
Sau khi đi du lịch rộng rãi trên khắp thế giới, tôi đã nhận thấy rằng vẫn còn một ấn tượng quốc tế rằng nền tảng có liên quan và theo một cách nào đó đại diện cho Bitcoin- đặc biệt là trong báo chí quốc tế.
Nó không chính xác và có lẽ tương tự về tinh thần với các tiêu đề cho biết CEO của Bitcoin đã bị bắt giữ.

We also have a larger, but somewhat related problem that the blocksize debate has made blatantly clear- governance. It seems nearly impossible to get the community to agree on anything outside of trying to increase adoption and the underlying value of the bitcoin token.

Chúng tôi cũng có một vấn đề lớn hơn, nhưng phần nào liên quan đến việc tranh luận về khối đã làm cho quản trị rõ ràng một cách trắng trợn.
Dường như không thể khiến cộng đồng đồng ý về bất cứ điều gì ngoài việc cố gắng tăng áp dụng và giá trị cơ bản của mã thông báo bitcoin.

Hence, I think we have an opportunity to solve two problems at once. The Foundation can be productively reborn preventing another media boondoggle and at the same time we have an excellent opportunity to explore new types of governance, algorithmic regulation and social consensus.

Do đó, tôi nghĩ rằng chúng ta có cơ hội để giải quyết hai vấn đề cùng một lúc.
Nền tảng có thể được tái sinh một cách hiệu quả ngăn chặn một phương tiện truyền thông khác và đồng thời chúng tôi có cơ hội tuyệt vời để khám phá các loại quản trị mới, quy định thuật toán và đồng thuận xã hội.

So assuming it's somehow a good idea to rebuild the Foundation (I fully agree that there are solid arguments to simply let it burn), let's explore what it would take to do so. As a side-note, I would be equally happy with seeing the Foundation shutdown if it didn't harm the Bitcoin brand and community.

Vì vậy, giả sử rằng bằng cách nào đó là một ý tưởng tốt để xây dựng lại nền tảng (tôi hoàn toàn đồng ý rằng có những lập luận vững chắc để chỉ để nó bị đốt cháy), chúng ta hãy khám phá những gì cần thiết để làm như vậy.
Là một ghi chú phụ, tôi cũng sẽ rất vui khi thấy sự tắt máy của nền tảng nếu nó không gây hại cho thương hiệu và cộng đồng Bitcoin.

First, the Foundation has lost any form of legitimacy. It's broke because prior leaders looted it. It's undemocratic by forcing out elected board members and replacing them with appointed ones. It's utterly unable to listen to outside opinions and conduct basic affairs such as managing board meetings, elections or produce a viable road-map.

Đầu tiên, nền tảng đã mất bất kỳ hình thức hợp pháp nào.
Nó đã bị phá vỡ vì các nhà lãnh đạo trước đó đã cướp bóc nó.
Đó là phi dân chủ bằng cách buộc các thành viên hội đồng được bầu và thay thế họ bằng những người được chỉ định.
Nó hoàn toàn không thể lắng nghe các ý kiến bên ngoài và tiến hành các vấn đề cơ bản như quản lý các cuộc họp của hội đồng quản trị, bầu cử hoặc tạo ra một bản đồ đường bộ khả thi.

Thus these issues need to be corrected before any future progress can be made. So let's start with an independent audit of the Foundation's books, relationships and accomplishments. Hire an auditor paid from an outside pool of capital (hell I'll throw some money into that fund) and give him a mandate to do the following:

Do đó, những vấn đề này cần phải được sửa chữa trước khi bất kỳ tiến bộ trong tương lai có thể được thực hiện.
Vì vậy, hãy bắt đầu với một cuộc kiểm toán độc lập về các cuốn sách, mối quan hệ và thành tích của nền tảng.
Thuê một kiểm toán viên được trả từ một nhóm vốn bên ngoài (địa ngục tôi sẽ ném một số tiền vào quỹ đó) và cho anh ta một nhiệm vụ để làm như sau:

1. Build a timeline of all major events since the Foundations inception

1. Xây dựng dòng thời gian của tất cả các sự kiện lớn kể từ khi bắt đầu nền tảng

1. Provide detailed financial records on the Foundation's expenses and income

1. Cung cấp hồ sơ tài chính chi tiết về chi phí và thu nhập của nền tảng

1. Annotate all business relationships the Foundation has had since its inception and their association (if any) to current and past board members and executive directors

1. Chú thích tất cả các mối quan hệ kinh doanh mà nền tảng đã có từ khi thành lập và sự liên kết của họ (nếu có) với các thành viên hội đồng quản trị hiện tại và quá khứ và giám đốc điều hành

1. Provide an HR database of all personnel that the foundation has retained and their compensation. Also build a social graph showing the relationship between the Foundation employees and the board members past and present including if they worked for or with the board members in previous or current ventures

1. Cung cấp một cơ sở dữ liệu nhân sự của tất cả các nhân viên mà nền tảng đã giữ lại và khoản bồi thường của họ.
Cũng xây dựng một biểu đồ xã hội cho thấy mối quan hệ giữa các nhân viên nền tảng và các thành viên hội đồng quản trị trong quá khứ và hiện tại, bao gồm nếu họ làm việc cho hoặc với các thành viên hội đồng quản trị trong các dự án trước đây hoặc hiện tại

1. List the major efforts the Foundation has embarked upon and rate their success based upon the Auditor's best judgement and whatever objective metrics can be established

1. Liệt kê những nỗ lực lớn mà nền tảng đã bắt tay vào và đánh giá thành công của họ dựa trên phán đoán tốt nhất của kiểm toán viên và bất kỳ số liệu khách quan nào có thể được thiết lập

1. Give each executive director- past and present- an opportunity to write an explanation for the findings of the auditor.

1. Cung cấp cho mỗi giám đốc điều hành- quá khứ và hiện tại- một cơ hội để viết một lời giải thích cho những phát hiện của kiểm toán viên.

Once drafted, then release the report to the general public- unless criminal conduct is discovered, then first release the evidence to the relevant agencies and let them choose when to release it.

Sau khi được soạn thảo, sau đó phát hành báo cáo cho công chúng nói chung- trừ khi hành vi tội phạm được phát hiện, sau đó trước tiên đưa ra bằng chứng cho các cơ quan liên quan và cho phép họ chọn khi nào phát hành.

Here's what an audit accomplishes:

Đây là những gì một cuộc kiểm toán hoàn thành:

1. It divorces the Foundation from its past by bringing everything out into the light and exposing any corruption from past or present leadership. If anyone is responsible for criminal acts, then they will be exposed and I'd hope prosecuted

1. Nó ly dị nền tảng từ quá khứ của nó bằng cách đưa mọi thứ ra ánh sáng và phơi bày bất kỳ tham nhũng nào từ sự lãnh đạo trong quá khứ hoặc hiện tại.
Nếu bất cứ ai chịu trách nhiệm cho các hành vi tội phạm, thì họ sẽ bị phơi bày và tôi hy vọng bị truy tố

1. It acts as a basis for the Foundation to re-engage the Bitcoin community. The Foundation can say ok this is what we did wrong so tell us how we can be better in the future?

1. Nó hoạt động làm cơ sở cho nền tảng để thu hẹp lại cộng đồng Bitcoin.
Nền tảng có thể nói ok đây là những gì chúng tôi đã làm sai vì vậy hãy cho chúng tôi biết làm thế nào chúng ta có thể tốt hơn trong tương lai?

1. Those who are asking for the Foundation to be shutdown can now have a fair debate. The audit will provide an independent assessment of where the Foundation has been and what it has accomplished given its resources

1. Những người đang yêu cầu nền tảng sẽ đóng cửa giờ đây có thể có một cuộc tranh luận công bằng.
Kiểm toán sẽ cung cấp một đánh giá độc lập về nơi nền tảng đã được và những gì nó đã đạt được với các nguồn lực của nó

At the end of this process, my hope would be for the Foundation to work with the Bitcoin community towards either shutting itself down or some form of reconstruction. The point is that its now done with reason, evidence and consensus instead of a shouting match. In my experience, people get angry when they feel like they've been deceived or aren't being heard. There is a very strong perception in the Bitcoin community that the Foundation has been historically dishonest and deaf. An audit strikes at the heart of the anger.

Vào cuối quá trình này, hy vọng của tôi sẽ là nền tảng để làm việc với cộng đồng Bitcoin hướng tới việc tự đóng cửa hoặc một số hình thức tái thiết.
Vấn đề là bây giờ nó được thực hiện với lý do, bằng chứng và sự đồng thuận thay vì một trận đấu hét lên.
Theo kinh nghiệm của tôi, mọi người tức giận khi họ cảm thấy như họ đã bị lừa dối hoặc không được nghe thấy.
Có một nhận thức rất mạnh mẽ trong cộng đồng Bitcoin rằng nền tảng này đã không trung thực và bị điếc trong lịch sử.
Một cuộc kiểm toán tấn công vào trung tâm của sự tức giận.

Second, let's say the Foundation somehow survives an audit and the community -or a wealthy patron(s)- seeks to continue the Foundation's existence, then the next step is to solidify the organization behind a new mission and values. This action is a wonderful opportunity to work with several ventures such as 

Thứ hai, giả sử nền tảng bằng cách nào đó tồn tại một cuộc kiểm toán và cộng đồng - hoặc một người bảo trợ giàu có - tìm cách tiếp tục sự tồn tại của nền tảng, sau đó bước tiếp theo là củng cố tổ chức đằng sau một nhiệm vụ và giá trị mới.
Hành động này là một cơ hội tuyệt vời để làm việc với một số dự án như

[](http://colony.io/)

[] (http://colony.io/)

Colony

Thuộc địa

and 

và

[](http://boardroom.to/)

[] (http://boardroom.to/)

Boardroom focusing on 

Phòng họp tập trung vào

[](https://en.wikipedia.org/wiki/Decentralized_autonomous_organization)

[].

DAOs and other 

Daos và khác

[](http://liquidfeedback.org/)

[] (http://liquidfeedback.org/)

algorithmically enforced structures of 

các cấu trúc được thực thi theo thuật toán của

[](https://e-estonia.com/)

[] (https://e-estonia.com/)

governance.

quản trị.

But it's natural to ask to what end? I don't think Charles Hoskinson should decide that. More to the point, no one person should. Instead let's make proposals and draft a candidate constitution. Then have the Bitcoin community vote on proposals. In my view, the core value proposition for continuing the Foundation is to experiment with technology that allows for decentralized governance. If the Foundation should continue under an unelected or pseudo-elected board, then just shut it down. **We created Bitcoin to get away from these things.**

Nhưng đó là điều tự nhiên để yêu cầu kết thúc gì?
Tôi không nghĩ Charles Hoskinson nên quyết định điều đó.
Hơn nữa, không một người nên.
Thay vào đó, hãy đưa ra các đề xuất và soạn thảo một hiến pháp ứng cử viên.
Sau đó, bỏ phiếu cộng đồng Bitcoin về các đề xuất.
Theo quan điểm của tôi, đề xuất giá trị cốt lõi để tiếp tục nền tảng là thử nghiệm công nghệ cho phép quản trị phi tập trung.
Nếu nền tảng nên tiếp tục theo một bảng không được bầu chọn hoặc được bầu, thì chỉ cần tắt nó xuống.
** Chúng tôi đã tạo ra Bitcoin để tránh xa những điều này. **

This process could be amazingly beneficial. It- like Bitcoin was and still is- serves as an experiment driven by a well intended community instead of the mandate of an overlord seeking power or control (also drop Satoshi from the board, it's insulting). We would also gain tangible data on how to discuss controversial ideas within a productive framework with the aim of eventually reaching a community consensus (can you think of any debate Bitcoiners are having right now?). Finally, the community can also explore how to regulate a custodial entity using cryptography instead of trusted founders (wow, think of all those smart contracts and prove of solvency proposals that people have been preaching about- someone call Peter Todd!).

Quá trình này có thể có lợi đáng kinh ngạc.
Nó giống như Bitcoin đã và vẫn còn là một thử nghiệm được thúc đẩy bởi một cộng đồng có ý định tốt thay vì nhiệm vụ của một quyền lực hoặc kiểm soát của Overlord (cũng thả Satoshi từ bảng, nó xúc phạm).
Chúng tôi cũng sẽ có được dữ liệu hữu hình về cách thảo luận về các ý tưởng gây tranh cãi trong khuôn khổ hiệu quả với mục đích cuối cùng đạt được sự đồng thuận của cộng đồng (bạn có thể nghĩ về bất kỳ người tranh luận nào đang có ngay bây giờ không?).
Cuối cùng, cộng đồng cũng có thể khám phá cách điều chỉnh một thực thể giám sát bằng mật mã thay vì những người sáng lập đáng tin cậy (wow, hãy nghĩ về tất cả các hợp đồng thông minh đó và chứng minh các đề xuất khả năng thanh toán mà mọi người đã giảng về- ai đó gọi Peter Todd!).

And now comes the objection: But Charles there isn't enough money to do this stuff! And I say: Aren't Mirror, Coinprism and other Bitcoin companies incredibly well funded, and don't they need a good showcase for their tech? Wouldn't the good press and community goodwill serve as excellent advertisement for their platforms?

Và bây giờ là sự phản đối: nhưng Charles không có đủ tiền để làm công việc này!
Và tôi nói: không phải là gương, coinprism và các công ty bitcoin khác được tài trợ cực kỳ tốt, và họ không cần một chương trình giới thiệu tốt cho công nghệ của họ?
Không phải báo chí tốt và thiện chí cộng đồng sẽ đóng vai trò là quảng cáo tuyệt vời cho nền tảng của họ?

**Money is never the issue**. It's vision and the ability to forge partnerships around it. If the current board can't accomplish this task, then fire them or shut the whole thing down. I'm extremely tired of hearing that we can't accomplish something. **The entire point of Bitcoin has been doing the stuff that people have been saying we can't do on a consistent basis.** 

** Tiền không bao giờ là vấn đề **.
Đó là tầm nhìn và khả năng tạo mối quan hệ đối tác xung quanh nó.
Nếu bảng hiện tại không thể hoàn thành nhiệm vụ này, thì hãy bắn chúng hoặc đóng cửa toàn bộ.
Tôi vô cùng mệt mỏi khi nghe rằng chúng ta không thể hoàn thành điều gì đó.
** Toàn bộ quan điểm của Bitcoin đã làm những điều mà mọi người đã nói rằng chúng tôi không thể làm trên cơ sở nhất quán. **

The argument above showcases my primary issue with the Foundation. It just doesn't lead. It lacks any notion of a vision or a purpose. Let's not blame them for it. Let's just install one that benefits the entire community.

Đối số ở trên cho thấy vấn đề chính của tôi với nền tảng.
Nó chỉ không dẫn.
Nó thiếu bất kỳ khái niệm về một tầm nhìn hoặc một mục đích.
Chúng ta đừng đổ lỗi cho họ vì điều đó.
Chúng ta hãy cài đặt một cái có lợi cho toàn bộ cộng đồng.

Third, let's discuss management and global representation. Traveling around the world, I've had the privilege to meet some exceptional people from Switzerland to Japan. I'm headed to Argentina next month and will have a chance to spend some time with one of the most passionate Bitcoin communities that you can find. It utterly disturbing to see the passive level of commitment that the current (and former) members of the Foundation's leadership have outside of Bruce and a few others.

Thứ ba, hãy thảo luận về quản lý và đại diện toàn cầu.
Đi du lịch vòng quanh thế giới, tôi đã có đặc quyền gặp một số người đặc biệt từ Thụy Sĩ đến Nhật Bản.
Tôi sẽ đến Argentina vào tháng tới và sẽ có cơ hội dành một chút thời gian với một trong những cộng đồng bitcoin đam mê nhất mà bạn có thể tìm thấy.
Thật đáng lo ngại khi thấy mức độ cam kết thụ động mà các thành viên hiện tại (và trước đây) của lãnh đạo nền tảng có bên ngoài Bruce và một vài người khác.

There are legions of Bitcoiners who would work with the Foundation full or part time with both enthusiasm and zeal if only given a chance. If the Foundation is going to continue existing, then it should reach out to the existing Bitcoin communities. More specifically, the Bitcoin meetup groups. They are run by passionate volunteers who love this space, the technology and its rich philosophical roots.

Có những quân đoàn của Bitcoiners, những người sẽ làm việc với nền tảng đầy đủ hoặc bán thời gian với cả sự nhiệt tình và nhiệt tình nếu chỉ có cơ hội.
Nếu nền tảng sẽ tiếp tục tồn tại, thì nó sẽ tiếp cận với các cộng đồng Bitcoin hiện có.
Cụ thể hơn, các nhóm gặp Bitcoin.
Họ được điều hành bởi các tình nguyện viên đam mê, những người yêu thích không gian này, công nghệ và nguồn gốc triết học phong phú của nó.

The Bitcoin meetup groups are also largely responsible for Bitcoin's growth from a novel technology to a global movement. I'd love to see the Foundation serve as a hub connecting them together and recruiting from within their ranks on a global basis. When people are given a great vision and a purpose, they aren't motivated by money to do work. The open source movement has proven this truth time and again.

Các nhóm gặp gỡ Bitcoin cũng chịu trách nhiệm lớn cho sự phát triển của Bitcoin từ một công nghệ mới đến một phong trào toàn cầu.
Tôi rất muốn thấy nền tảng phục vụ như một trung tâm kết nối họ với nhau và tuyển dụng từ trong hàng ngũ của họ trên cơ sở toàn cầu.
Khi mọi người được đưa ra một tầm nhìn tuyệt vời và một mục đích, họ không bị thúc đẩy bởi tiền để làm việc.
Phong trào nguồn mở đã chứng minh sự thật này hết lần này đến lần khác.

Alright, so in conclusion, audit the Foundation, turn over any evidence of criminal conduct to the relevant authorities, draft a constitution via community participation, govern using tech from well funded Bitcoin startups, and link all the Bitcoin meetup groups together to act as the execution engine, talent farm and source of great ideas (See 

Được rồi, vì vậy, kết luận, kiểm toán Quỹ, chuyển bất kỳ bằng chứng nào về hành vi tội phạm cho các cơ quan có liên quan, soạn thảo Hiến pháp thông qua sự tham gia của cộng đồng, chi phối việc sử dụng công nghệ từ các công ty khởi nghiệp Bitcoin được tài trợ tốt và liên kết tất cả các nhóm gặp Bitcoin cùng nhau để đóng vai trò là người
Công cụ thực thi, trang trại tài năng và nguồn gốc của những ý tưởng tuyệt vời (xem

[](https://www.youtube.com/watch?v=HMBl0ttu-Ow)

[] (https://www.youtube.com/watch?v=HMBL0TTU-W)

Social Physics

Vật lý xã hội

).

).

It's really not that hard to accomplish something great. It just takes vision, persistence, honesty and leadership. If the Foundation has it, then it should survive. If it doesn't, then don't worry it will eventually collapse.

Nó thực sự không khó để hoàn thành một cái gì đó tuyệt vời.
Nó chỉ cần tầm nhìn, kiên trì, trung thực và lãnh đạo.
Nếu nền tảng có nó, thì nó sẽ tồn tại.
Nếu không, thì đừng lo lắng cuối cùng nó sẽ sụp đổ.

## **Attachments**

## ** tệp đính kèm **

![](img/2016-01-12-how-to-save-or-destroy-bitcoin.004.png)[ How to Save (Or Destroy) the Bitcoin Foundation - Input Output HongKong](https://ucarecdn.com/797b349e-9715-475c-9915-4fc1b9ccbe45/-/inline/yes/ "How to Save (Or Destroy) the Bitcoin Foundation - Input Output HongKong")

