# Some History, Some Musings and My Take on the DAO
![](img/2016-01-12-some-history-some-musings-and-my-take.002.png) 12 January 2016![](img/2016-01-12-some-history-some-musings-and-my-take.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-01-12-some-history-some-musings-and-my-take.003.png) 8 mins read

![](img/2016-01-12-some-history-some-musings-and-my-take.004.png)[ Some History, Some Musings and My Take on the DAO - Input Output HongKong](https://ucarecdn.com/5de49375-af2f-47f2-ba41-cb98e0a8edbf/-/inline/yes/ "Some History, Some Musings and My Take on the DAO - Input Output HongKong")

![Charles Hoskinson](img/2016-01-12-some-history-some-musings-and-my-take.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-01-12-some-history-some-musings-and-my-take.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-01-12-some-history-some-musings-and-my-take.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-01-12-some-history-some-musings-and-my-take.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Some History, Some Musings and My Take on the DAO](img/2016-01-12-some-history-some-musings-and-my-take.009.jpeg)

I recall the mid-summer Virginia afternoon back in 2013 being filled with copious conversations ranging from how to achieve value stability for a cryptocurrency to this strange idea Stan Larimer had called a DAC - a decentralized autonomous company. His drafts contained terms like Steely Eyed Geeks and a nice list of rules definitely inspired by Arthur C Clarke and Isaac Asimov, but with the boyish enthusiasm only Stan could muster. The article (Bitcoin and the Three Laws of Robotics) eventually found its way to Bitcoin Magazine and the Let's Talk Bitcoin's blog as well as Vitalik's September series (

Tôi nhớ lại buổi chiều giữa mùa hè Virginia vào năm 2013, chứa đầy những cuộc trò chuyện phong phú, từ cách đạt được sự ổn định giá trị cho một loại tiền điện tử cho đến ý tưởng kỳ lạ này mà Stan Larimer đã gọi là DAC - một công ty tự trị phi tập trung.
Các bản nháp của ông chứa các thuật ngữ như Steely Eyed Geek và một danh sách các quy tắc tốt đẹp chắc chắn được lấy cảm hứng từ Arthur C Clarke và Isaac Asimov, nhưng với sự nhiệt tình nam tính, chỉ có Stan mới có thể tập hợp được.
Bài báo (Bitcoin và ba luật của robot) cuối cùng đã tìm được đường đến Tạp chí Bitcoin và blog của Let nói Bitcoin cũng như loạt phim tháng 9 của Vitalik (

[](https://bitcoinmagazine.com/articles/bootstrapping-a-decentralized-autonomous-corporation-part-i-1379644274)

[].

1

1

). I'd like to believe that we were all after the same goal in those more innocent and lower stakes days. All cryptocurrencies, and protocols for that matter, suffer from a fundamental meta problem of governance. Eventually changes will need to be made to accommodate some unforeseen complication, the burning march of ever changing technology and social pressures, or even a black swan event. Furthermore, how do you pay the selfless (sometimes not so much) people who are maintaining the protocol? How do you balance the different interests of various stakeholders from regulators to service providers such as exchanges and miners.

).
Tôi muốn tin rằng tất cả chúng ta đều sau cùng một mục tiêu trong những ngày cổ phần ngây thơ và thấp hơn đó.
Tất cả các loại tiền điện tử, và các giao thức cho vấn đề đó, phải chịu một vấn đề meta cơ bản của quản trị.
Cuối cùng, những thay đổi sẽ cần phải được thực hiện để phù hợp với một số biến chứng không lường trước, sự thi hành của công nghệ và áp lực xã hội luôn thay đổi, hoặc thậm chí là một sự kiện thiên nga đen.
Hơn nữa, làm thế nào để bạn trả tiền cho những người vô vị (đôi khi không nhiều) đang duy trì giao thức?
Làm thế nào để bạn cân bằng các lợi ích khác nhau của các bên liên quan khác nhau từ các cơ quan quản lý đến các nhà cung cấp dịch vụ như trao đổi và thợ mỏ.

The foundational premise of Bitcoin can be encapsulated succinctly as people suck so just trust a protocol. This line of thought has lead to numerous problems from a lack of recourse for theft (see MtGox and the dozen other exchanges) to dark market operators such as silk road using Bitcoin as their payment network. Furthermore, the rewards to miners are not connected to any external reality- just hard locked and unresponsive to the needs of the network. The protocol marches on like a silent, yet diligent sentinel uncaring in judgement, but utterly fair.

Tiền đề nền tảng của Bitcoin có thể được gói gọn một cách cô đọng khi mọi người hút nên chỉ cần tin tưởng một giao thức.
Dòng suy nghĩ này đã dẫn đến nhiều vấn đề từ việc thiếu sự truy tố đối với hành vi trộm cắp (xem MTGOX và hàng tá trao đổi khác) cho các nhà khai thác thị trường tối như Silk Road sử dụng Bitcoin làm mạng lưới thanh toán của họ.
Hơn nữa, phần thưởng cho người khai thác không được kết nối với bất kỳ thực tế bên ngoài nào- chỉ bị khóa cứng và không đáp ứng với nhu cầu của mạng.
Giao thức diễu hành trên như một lính gác im lặng, nhưng siêng năng không quan tâm đến sự phán xét, nhưng hoàn toàn công bằng.

We were interested in DACs because the sentinel needs some method of getting an update and if one appointed a centralized body or even a federated one, then one has completely defeated the ultimate purpose of these systems. With more time given for clarity, when one abstracts the idea, one can notice that most businesses are a collection of systems that decompose into protocols. Thus, it stands to reason they too can be transformed into sentinels and if only we had a DAC, then they too could be fair, yet dynamic. Hence, DAOs were born.

Chúng tôi quan tâm đến DACS vì Sentinel cần một số phương pháp để nhận bản cập nhật và nếu một người chỉ định một cơ quan tập trung hoặc thậm chí là một cơ quan liên kết, thì người ta đã hoàn toàn đánh bại mục đích cuối cùng của các hệ thống này.
Với nhiều thời gian hơn được đưa ra cho rõ ràng, khi một người tóm tắt ý tưởng, người ta có thể nhận thấy rằng hầu hết các doanh nghiệp là một tập hợp các hệ thống phân tách thành các giao thức.
Do đó, lý do họ cũng có thể biến thành Sentinels và nếu chỉ chúng tôi có một DAC, thì họ cũng có thể công bằng, nhưng năng động.
Do đó, Daos được sinh ra.

Back in 2013, we didn't have Ethereum. Sergio Lerner had created a wonderful turing complete system intended for gaming called Qixcoin, but it wasn't well known or funded. Thus, DAOs didn't have the requisite technology nor a clear commercial path forward. Yet with the dawn of the crowdsale and Ethereum as a platform, this reality has changed.

Trở lại năm 2013, chúng tôi không có Ethereum.
Sergio Lerner đã tạo ra một hệ thống hoàn chỉnh Turing tuyệt vời dành cho chơi game có tên Qixcoin, nhưng nó không được biết đến hoặc tài trợ.
Do đó, DAOS không có công nghệ cần thiết cũng như một con đường thương mại rõ ràng về phía trước.
Tuy nhiên, với buổi bình minh của đám đông và Ethereum như một nền tảng, thực tế này đã thay đổi.

Now up to this point, it is reasonable to assess what progress has been made. The existence of the crowdsale our space has been using for the last few years has created a funding mechanism for all kinds of interesting projects ranging from Maidsafe to Swarm. Whether these produce utility or are attractive places to store value is yet mostly unproven; however, it's truly amazing to see the amount of passion and enthusiasm. Of course, never forget that people suck so yes a lot of fraud seems to be seeping in (

Bây giờ cho đến thời điểm này, thật hợp lý để đánh giá những tiến bộ đã được thực hiện.
Sự tồn tại của đám đông không gian của chúng tôi đã sử dụng trong vài năm qua đã tạo ra một cơ chế tài trợ cho tất cả các loại dự án thú vị từ MaidSafe đến bầy đàn.
Cho dù những sản phẩm này sản xuất tiện ích hay là nơi hấp dẫn để lưu trữ giá trị vẫn chưa được chứng minh;
Tuy nhiên, thật tuyệt vời khi thấy số lượng niềm đam mê và sự nhiệt tình.
Tất nhiên, đừng bao giờ quên rằng mọi người hút nên có rất nhiều gian lận dường như đang thấm vào (

[](https://docs.google.com/document/d/1xG1hkPbk0uuavjPc_gt_eWxEUbWM1SlsxNmhGdRIUtg/edit)

[] (https:

See Hoskinson Doctrine

Xem Học thuyết Hoskinson

).

).

Ethereum has created a way of deploying distributed protocols with a host network that has known and probably strong security guarantees about the execution of the code. Whether this system can be made secure under some reasonable formal model and associated proofs and also made efficient is another story. Yet we should at least concede that it's a pretty fun sandbox to run experiments.

Ethereum đã tạo ra một cách triển khai các giao thức phân tán với một mạng máy chủ đã biết và có lẽ bảo mật mạnh mẽ đảm bảo về việc thực thi mã.
Liệu hệ thống này có thể được thực hiện an toàn theo một số mô hình chính thức hợp lý và bằng chứng liên quan và cũng làm cho hiệu quả là một câu chuyện khác.
Tuy nhiên, ít nhất chúng ta nên thừa nhận rằng đó là một hộp cát khá thú vị để chạy thử nghiệm.

The DAO is one such experiment, which brings us to the ultimate point of this article. Slock.it and their affiliates apparently wanted to create a large pool of capital that could be used to fund interesting projects (sound like any type of structure you could think of?), but make the pool a sentinel without a master. Just some helpful curators and the Ethereum network's guarantees behind it.

DAO là một thử nghiệm như vậy, đưa chúng ta đến điểm cuối cùng của bài viết này.
Slock.it và các chi nhánh của họ dường như muốn tạo ra một nhóm vốn lớn có thể được sử dụng để tài trợ cho các dự án thú vị (nghe giống như bất kỳ loại cấu trúc nào bạn có thể nghĩ ra?), Nhưng hãy biến Pool thành một Sentinel mà không có chủ.
Chỉ là một số người phụ trách hữu ích và mạng Ethereum đảm bảo đằng sau nó.

Ideally, a Surowiecki utopian wisdom would envelope the DAO making it the smartest way to allocate capital or something along those lines. To be honest, I mostly ignored the original proposal thinking that people wouldn't invest much time or money into it.

Lý tưởng nhất, một trí tuệ không tưởng Surowiecki sẽ bao bọc DAO làm cho nó trở thành cách thông minh nhất để phân bổ vốn hoặc một cái gì đó dọc theo những dòng đó.
Thành thật mà nói, tôi chủ yếu bỏ qua đề xuất ban đầu nghĩ rằng mọi người sẽ không đầu tư nhiều thời gian hoặc tiền bạc vào đó.

Common sense seems to yield a litany of concerns from the fidelity of the code controlling this concept to the creator's utter unwillingness to stand behind the DAO from a legal sense. If something goes wrong, then no one is responsible? Do we have sufficient faith in our ability to do things perfectly right the first time that we are willing to invest in a blameless system? Imagine if planes worked this way. Would you fly?

Ý thức chung dường như mang lại một loạt các mối quan tâm từ sự trung thành của mã kiểm soát khái niệm này cho sự không sẵn lòng của người sáng tạo để đứng đằng sau DAO từ ý nghĩa pháp lý.
Nếu có sự cố xảy ra, thì không ai chịu trách nhiệm?
Chúng ta có đủ niềm tin vào khả năng của chúng ta để làm mọi thứ một cách hoàn hảo ngay lần đầu tiên chúng ta sẵn sàng đầu tư vào một hệ thống đáng trách?
Hãy tưởng tượng nếu máy bay hoạt động theo cách này.
Bạn sẽ bay?

Furthermore, there was a reckless desire to maximize the size of the fundraiser without any concern to factors everyone should be wary of in some capacity. Why wasn't the DAO milestoned with the majority of the funds stored in a large multi-signature feeder contract that gradually released money into the main fund given progress and investment success? Who was responsible for maintaining, upgrading and auditing the code long term? What metrics should the DAO be held accountable for over the long term? Apparently, having a 

Hơn nữa, có một mong muốn liều lĩnh để tối đa hóa quy mô của việc gây quỹ mà không cần lo lắng cho các yếu tố mọi người nên cảnh giác trong một số khả năng.
Tại sao các cột mốc DAO không được đưa ra với phần lớn các quỹ được lưu trữ trong một hợp đồng trung chuyển đa chữ ký lớn dần dần phát hành tiền vào quỹ chính đã đưa ra sự thành công và thành công đầu tư?
Ai chịu trách nhiệm duy trì, nâng cấp và kiểm toán mã lâu dài?
Dao nên chịu trách nhiệm về số liệu nào trong thời gian dài?
Rõ ràng, có một

[](https://daohub.org/curator.html)

[] (https://daohub.org/curator.html)

dream team

Đội hình trong mơ

means that we should abandon basic due diligence and the ability to imagine bad events happening. Does anyone recall a certain other company called Theranos?

có nghĩa là chúng ta nên từ bỏ sự siêng năng cơ bản và khả năng tưởng tượng các sự kiện xấu xảy ra.
Có ai nhớ lại một công ty khác được gọi là Theranos không?

So now we are faced with the predictable nightmare scenario only yielded from grand hubristic endeavors such as the unsinkable titanic. The DAO has been looted by a hacker who potentially has enough pithy gall to claim that the theft actually conforms to the 

Vì vậy, bây giờ chúng ta phải đối mặt với kịch bản cơn ác mộng có thể dự đoán được chỉ mang lại từ những nỗ lực lớn của Hubristic như Titanic không thể đạt được.
DAO đã bị một hacker cướp phá

[](http://pastebin.com/CcGUBgDG)

[] (http://pastebin.com/ccgubgdg)

DAO's terms and conditions

Điều khoản và điều kiện của Dao

. Lawyers, please bookmark everything you find on Tual and his friends. This class action lawsuit is writing itself.

.
Luật sư, vui lòng đánh dấu mọi thứ bạn tìm thấy trên Tual và bạn bè của anh ấy.
Vụ kiện tập thể này là tự viết.

So why should Ethereum care? The point of the system is to be a sandbox for ideas to succeed or fail. It's a lab for experiments. That's why Ethereum is worth so much money as a system. Following this line of thought, Ethereum SHOULDN'T CARE.

Vậy tại sao Ethereum phải chăm sóc?
Điểm của hệ thống là là một hộp cát để các ý tưởng thành công hay thất bại.
Đó là một phòng thí nghiệm cho các thí nghiệm.
Đó là lý do tại sao Ethereum có giá trị rất nhiều tiền như một hệ thống.
Theo dòng suy nghĩ này, Ethereum không nên quan tâm.

You don't change the lab when someone performs a poorly formed experiment. You blame the chemist and move on. We can make a fair argument for better safety equipment (

Bạn không thay đổi phòng thí nghiệm khi ai đó thực hiện một thí nghiệm được hình thành kém.
Bạn đổ lỗi cho nhà hóa học và tiếp tục.
Chúng ta có thể đưa ra một lập luận công bằng cho các thiết bị an toàn tốt hơn (

[](http://publications.lib.chalmers.se/records/fulltext/234939/234939.pdf)

[] (http://publications.lib.chalmers.se/records/fulltext/234939/234939.pdf)

which has already been proposed

đã được đề xuất

), but you don't change the nature of a facility to accommodate someone who screwed up.

), nhưng bạn không thay đổi bản chất của một cơ sở để phù hợp với một người nào đó đã làm hỏng việc.

Yet Vitalik and others close to the Ethereum Foundation are advocating to do just that. They want to fork the protocol in order to prevent the theft. 

Tuy nhiên, Vitalik và những người khác gần với Quỹ Ethereum đang ủng hộ để làm điều đó.
Họ muốn đưa giao thức để ngăn chặn hành vi trộm cắp.

[](https://medium.com/@brucefenton/its-better-to-lose-your-investment-than-lose-your-blockchain-2907a59d5a40#.3wocfi9pl)

[].

Bruce Fenton

Bruce Fenton

and others have already done a good job explaining why this proposal is an extremely bad idea. It's pointless to add another argument to the pile. Rather I'd like to take this opportunity to explain what has really failed in the Ethereum ecosystem. It has a governance problem.

Và những người khác đã thực hiện một công việc tốt để giải thích lý do tại sao đề xuất này là một ý tưởng cực kỳ tồi tệ.
Thật vô nghĩa khi thêm một đối số khác vào đống.
Thay vào đó, tôi muốn nhân cơ hội này để giải thích những gì đã thực sự thất bại trong hệ sinh thái Ethereum.
Nó có một vấn đề quản trị.

Several of the Founders have scattered across the seven seas and created new commercial ventures ranging from Consensys to Ethcore. Each has its own blend of fiduciary obligations depending upon their investors and stakeholders, yet these are not directly aligned to the needs of the Ethereum ecosystem. The closest thing Ethereum should have to a neutral body ought to be the Foundation.

Một số người sáng lập đã rải rác trên bảy vùng biển và tạo ra các dự án thương mại mới, từ Consensys đến Ethcore.
Mỗi người có sự pha trộn riêng của các nghĩa vụ ủy thác tùy thuộc vào các nhà đầu tư và các bên liên quan của họ, nhưng những điều này không trực tiếp phù hợp với nhu cầu của hệ sinh thái Ethereum.
Điều gần nhất Ethereum nên có một cơ thể trung lập phải là nền tảng.

You know those bodies that don't pick winners and losers and try to just protect the protocol itself? Except for the time when its leaders join multiple ventures, plaster their name everywhere and seem to have a very comfortable relationship with companies like Deloitte and Microsoft for "Projects".

Bạn có biết những cơ thể không chọn người chiến thắng và kẻ thua cuộc và cố gắng bảo vệ giao thức không?
Ngoại trừ thời gian khi các nhà lãnh đạo của nó tham gia nhiều dự án, đăng ký tên của họ ở khắp mọi nơi và dường như có mối quan hệ rất thoải mái với các công ty như Deloitte và Microsoft cho "các dự án".

Yes helping the DAO investors get their money back is a noble knee jerk reaction. But what about Gatecoin and the theft that occurred there? What about the ether purchasers who experienced an event that prevented them from redeeming their ether they fairly purchased? What about all the ether lost to defective smart contracts? DAO gets precedence, yet the others don't? Is this because its failure would invite regulatory scrutiny to the Foundation members as they have too close a relationship to it?

Vâng, giúp các nhà đầu tư DAO lấy lại tiền của họ là một phản ứng giật đầu gối cao quý.
Nhưng những gì về Gatecoin và hành vi trộm cắp xảy ra ở đó?
Thế còn những người mua ether đã trải qua một sự kiện ngăn họ chuộc lại ether mà họ đã mua khá nhiều?
Thế còn tất cả các ether bị mất đối với các hợp đồng thông minh khiếm khuyết?
Dao được ưu tiên, nhưng những người khác thì không?
Đây có phải là vì sự thất bại của nó sẽ mời sự giám sát theo quy định cho các thành viên nền tảng vì họ có mối quan hệ quá gần với nó?

Returning to the core thesis of bitcoin and its children - people suck; trust the protocol - applied to the bailout of the DAO, we have people who are trusted to be neutral who cannot be due to whatever obligations that have encumbered upon themselves. As we should expect given human nature. They now want to change the protocol to prevent in part personal harm to themselves given the damage the DAO has done.

Trở lại với luận điểm cốt lõi của Bitcoin và con cái của nó - mọi người hút;
Tin tưởng giao thức - áp dụng cho gói cứu trợ của DAO, chúng tôi có những người được tin tưởng là trung lập, những người không thể là do bất kỳ nghĩa vụ nào đã tự buộc tội.
Như chúng ta nên mong đợi cho bản chất con người.
Bây giờ họ muốn thay đổi giao thức để ngăn chặn một phần gây tổn hại cá nhân cho chính họ do thiệt hại mà DAO đã gây ra.

The argument of wanting to help cannot be sensibly made given their lack of interest in the other thefts and bad events in the system. I honestly can't fault them for this behavior, but I have to point out how dangerous this act is for sentinel that is the Ethereum protocol.

Lập luận muốn giúp đỡ không thể được đưa ra một cách hợp lý do sự thiếu quan tâm của họ đối với các vụ trộm và các sự kiện xấu khác trong hệ thống.
Tôi thực sự không thể lỗi cho họ về hành vi này, nhưng tôi phải chỉ ra rằng hành động này nguy hiểm như thế nào đối với Sentinel đó là giao thức Ethereum.

Stan Larimer had the foresight to imagine events like this occurring, which is why he wrote his article. The ethereum community needs to embrace this tragedy and accept it as a failure we can learn from. We need a DAO, but not one to store money to make some investors rich. We need one to help us make these kinds of hard decisions in a responsible way.

Stan Larimer có tầm nhìn xa để tưởng tượng các sự kiện như thế này xảy ra, đó là lý do tại sao ông viết bài viết của mình.
Cộng đồng Ethereum cần nắm lấy bi kịch này và chấp nhận nó như một thất bại mà chúng ta có thể học hỏi.
Chúng tôi cần một DAO, nhưng không một để lưu trữ tiền để làm cho một số nhà đầu tư trở nên giàu có.
Chúng tôi cần một người để giúp chúng tôi đưa ra những quyết định khó khăn này một cách có trách nhiệm.

Ethereum is the first platform in human history that can transcend this predictable cycle of betrayal of integrity for person preservation and emerge into something far better. It won't be nice. It won't be kind. But It will be fair. That ultimately is why I signed up for this wild space. To build something beyond our nature, yet always accepting- sometimes painfully so- it won't always work out for me.

Ethereum là nền tảng đầu tiên trong lịch sử loài người có thể vượt qua chu kỳ có thể dự đoán được sự phản bội của sự chính trực để bảo tồn người và xuất hiện thành một thứ gì đó tốt hơn nhiều.
Nó sẽ không đẹp.
Nó sẽ không tử tế.
Nhưng nó sẽ công bằng.
Đó cuối cùng là lý do tại sao tôi đăng ký cho không gian hoang dã này.
Để xây dựng một cái gì đó ngoài bản chất của chúng ta, nhưng luôn luôn chấp nhận- đôi khi đau đớn- nó sẽ không luôn luôn phù hợp với tôi.

## **Attachments**

## ** tệp đính kèm **

![](img/2016-01-12-some-history-some-musings-and-my-take.004.png)[ Some History, Some Musings and My Take on the DAO - Input Output HongKong](https://ucarecdn.com/5de49375-af2f-47f2-ba41-cb98e0a8edbf/-/inline/yes/ "Some History, Some Musings and My Take on the DAO - Input Output HongKong")

