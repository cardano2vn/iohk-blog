# Ethereum Classic: An Update
![](img/2016-09-09-ethereum-classic-an-update.002.png) 9 September 2016![](img/2016-09-09-ethereum-classic-an-update.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-09-09-ethereum-classic-an-update.003.png) 8 mins read

![](img/2016-09-09-ethereum-classic-an-update.004.png)[ Ethereum Classic An Update - Input Output HongKong](https://ucarecdn.com/d030cc0e-7ade-458e-8d86-3129b200f037/-/inline/yes/ "Ethereum Classic An Update - Input Output HongKong")

![Charles Hoskinson](img/2016-09-09-ethereum-classic-an-update.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-09-09-ethereum-classic-an-update.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-09-09-ethereum-classic-an-update.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-09-09-ethereum-classic-an-update.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Ethereum Classic: An Update](img/2016-09-09-ethereum-classic-an-update.009.jpeg)

I wanted to draft a brief update on IOHK's efforts on Ethereum Classic (ETC). We've had the opportunity to schedule more than three dozen meetings with developers, community managers and academic institutions. We've also managed to have several long discussions with several of the community groups supporting ETC to get a better sense of commitments, goals and philosophy. Overall, it's been a really fun experience getting to know a completely decentralized philosophical movement. It's also been illuminating to parse the challenges ahead for the fragile movement as it charts its own path forward. I'll break the report down into what we learned and what we are going to do.

Tôi muốn soạn thảo một bản cập nhật ngắn gọn về những nỗ lực của IOHK về Ethereum Classic (v.v.).
Chúng tôi đã có cơ hội sắp xếp hơn ba chục cuộc họp với các nhà phát triển, quản lý cộng đồng và các tổ chức học thuật.
Chúng tôi cũng đã quản lý để có một số cuộc thảo luận dài với một số nhóm cộng đồng hỗ trợ vv để hiểu rõ hơn về các cam kết, mục tiêu và triết học.
Nhìn chung, đó là một trải nghiệm thực sự thú vị khi biết một phong trào triết học hoàn toàn phi tập trung.
Nó cũng được chiếu sáng để phân tích những thách thức phía trước cho phong trào mong manh khi nó vạch ra con đường của riêng mình về phía trước.
Tôi sẽ chia nhỏ báo cáo về những gì chúng tôi đã học và những gì chúng tôi sẽ làm.

**What We Learned**

** Những gì chúng ta đã học **

Carlo Vicari and I have been trying to map out the total ETC community and also get some metadata about who they are (vocation, age, geography, interests...) so we can better understand the core constituencies. We will publish some preliminary stats sometime next week, but as a rough summary there are currently several meetup groups, a telegram group, a reddit, several Chinese specific hubs, a slack with over 1,000 members and a few other lingering groups.

Carlo Vicari và tôi đã cố gắng vạch ra toàn bộ cộng đồng ETC và cũng nhận được một số siêu dữ liệu về con người họ (ơn gọi, tuổi tác, địa lý, sở thích ...) để chúng ta có thể hiểu rõ hơn về các khu vực bầu cử cốt lõi.
Chúng tôi sẽ xuất bản một số số liệu thống kê sơ bộ vào tuần tới, nhưng như một bản tóm tắt sơ bộ, hiện có một số nhóm gặp gỡ, một nhóm điện tín, Reddit, một số trung tâm cụ thể của Trung Quốc, một sự chậm chạp với hơn 1.000 thành viên và một vài nhóm nán lại khác.

Daily activity is growing and there is interest in more formal structure. With respect to developers, there are about a dozen people with development skills and knowledge of the EVM and solidity in the developer channel. They have been holding pretty deep discussions about potential directions and roadmaps. The biggest topics are currently pivoting consensus to PoW without the difficult bomb, new monetary policy and also safer smart contracts.

Hoạt động hàng ngày đang phát triển và có sự quan tâm đến cấu trúc chính thức hơn.
Đối với các nhà phát triển, có khoảng một chục người có kỹ năng phát triển và kiến thức về EVM và sự vững chắc trong kênh nhà phát triển.
Họ đã tổ chức các cuộc thảo luận khá sâu sắc về các hướng và lộ trình tiềm năng.
Các chủ đề lớn nhất hiện đang xoay quanh sự đồng thuận với POW mà không cần bom khó khăn, chính sách tiền tệ mới và các hợp đồng thông minh an toàn hơn.

There is also interest in forming a pool of capital to pay for development efforts ranging from core infrastructure to DApps on top of the system. I haven't taken a position on this effort because we still need to address some governance and legal questions. Regardless of whether this pool materializes, IOHK's commitment of three full time developers will be funded solely by IOHK.

Cũng có mối quan tâm trong việc hình thành một nhóm vốn để trả cho các nỗ lực phát triển, từ cơ sở hạ tầng cốt lõi đến DAPP trên hệ thống.
Tôi đã không đảm nhận một vị trí trong nỗ lực này vì chúng tôi vẫn cần giải quyết một số câu hỏi quản trị và pháp lý.
Bất kể liệu nhóm này có thực hiện được hay không, cam kết của IOHK về ba nhà phát triển toàn thời gian sẽ được IOHK tài trợ.

![](img/2016-09-09-ethereum-classic-an-update.010.png)

It seems that the price and trading volume of ETC has held relatively stable despite the virtual sword of damocles that is the DAO hacker and RHG funds. It seems that there is enough community interest in ETC to keep liquidity. I do think there will be tremendous volatility ahead and it's going to be impossible to predict when black swans are going to land in our laps, but I suppose that's what makes it fun?

Có vẻ như giá cả và khối lượng giao dịch của ETC đã giữ tương đối ổn định mặc dù thanh kiếm ảo của Damocles là Hacker DAO và các quỹ RHG.
Có vẻ như có đủ sự quan tâm của cộng đồng đối với ETC để giữ thanh khoản.
Tôi nghĩ rằng sẽ có sự biến động to lớn phía trước và sẽ không thể dự đoán khi nào thiên nga đen sẽ hạ cánh trong vòng đua của chúng tôi, nhưng tôi cho rằng đó là điều làm cho nó vui?

**IOHK's Commitment**

** Cam kết của Iohk **

After the initial conversations and analysis, we have determined the following serious deficits with ETC:

Sau các cuộc trò chuyện và phân tích ban đầu, chúng tôi đã xác định những thiếu sót nghiêm trọng sau đây với ETC:

1. There isn't an official or reliable channel of information about the events of the ecosystem or commitments of various actors. This reality has lead to FUD, impersonations and attempts at market manipulation in the absence of clarity.

1. Không có một kênh thông tin chính thức hoặc đáng tin cậy về các sự kiện của hệ sinh thái hoặc các cam kết của các tác nhân khác nhau.
Thực tế này đã dẫn đến FUD, mạo danh và nỗ lực trong việc thao túng thị trường trong trường hợp không có sự rõ ràng.

1. The roadmap of ETC needs to include at a minimum an emphasis on safety, sustainability and stability. There is a strong desire amongst the ETC community members we had discussions with to focus on reliable, high assurance applications that run on a network with proven fundamentals. Effectively, this needs to be the antithesis of move fast and break things.

1. Lộ trình của ETC cần bao gồm tối thiểu một sự nhấn mạnh vào sự an toàn, tính bền vững và ổn định.
Có một mong muốn mạnh mẽ giữa các thành viên cộng đồng ETC mà chúng tôi đã thảo luận để tập trung vào các ứng dụng đảm bảo cao, đáng tin cậy chạy trên mạng với các nguyên tắc cơ bản đã được chứng minh.
Thực tế, điều này cần phải là phản đề của việc di chuyển nhanh và phá vỡ mọi thứ.

1. There is a desire amongst several well capitalized actors to donate capital to a pool to fund the growth of ETC. This desire has been complicated by the lack of a clear governance structure that will avoid fraud or misuse of funds. Furthermore an open pool would allow funds to potentially become tainted by RHG or Dao hacker donating funds to it. While code is law covers the protocol level use of funds, it does not shield actors from the legal realities of their actions. It is unclear how these funds should be treated or if accepting them would constitute a crime.

1. Có một mong muốn giữa một số diễn viên được viết hoa tốt để quyên góp vốn cho một nhóm để tài trợ cho sự phát triển của ETC.
Mong muốn này đã được phức tạp bởi việc thiếu một cấu trúc quản trị rõ ràng sẽ tránh gian lận hoặc lạm dụng vốn.
Hơn nữa, một nhóm mở sẽ cho phép các quỹ có khả năng bị nhiễm độc bởi RHG hoặc DAO Hacker quyên góp tiền cho nó.
Mặc dù mã là luật bao gồm việc sử dụng cấp độ giao thức của các quỹ, nhưng nó không bảo vệ các tác nhân khỏi thực tế pháp lý của hành động của họ.
Không rõ làm thế nào các quỹ này nên được đối xử hoặc nếu chấp nhận chúng sẽ tạo thành một tội ác.

1. The media is uncertain how to report on ETC outside of a referential curiosity to ethereum itself . There needs to be a re-branding and media strategy to ensure new users enter the ecosystem with a clear understanding of what ETC is about and how it differs from ETH.

1. Các phương tiện truyền thông không chắc chắn làm thế nào để báo cáo về ETC bên ngoài sự tò mò tham chiếu đến chính Ethereum.
Cần phải có một chiến lược tái tạo thương hiệu và truyền thông để đảm bảo người dùng mới tham gia vào hệ sinh thái với sự hiểu biết rõ ràng về những gì ETC là về và nó khác với ETH.

1. Concepts like the replay attack and also new potential technology that could be adopted are not fully understood by ETC community members or general developers. There needs to be actors dedicated to education and explanation.

1. Các khái niệm như cuộc tấn công phát lại và công nghệ tiềm năng mới có thể được áp dụng không được hiểu đầy đủ bởi các thành viên cộng đồng ETC hoặc các nhà phát triển chung.
Cần phải có các diễn viên dành riêng cho giáo dục và giải thích.

1. The Ethereum Foundation owns the Ethereum trademark. Further use of this branding could provoke a trademark infringement lawsuit to companies using the Ethereum brand and name. This complicates the formation of a centralized governance entity or steering committee if it chooses to use ethereum classic as its name. It also complicates business commitments to building on the ETC chain.

1. Quỹ Ethereum sở hữu nhãn hiệu Ethereum.
Việc sử dụng thêm của thương hiệu này có thể gây ra một vụ kiện vi phạm thương hiệu cho các công ty sử dụng thương hiệu và tên Ethereum.
Điều này làm phức tạp sự hình thành của một thực thể quản trị tập trung hoặc ban chỉ đạo nếu họ chọn sử dụng Ethereum Classic làm tên của nó.
Nó cũng làm phức tạp các cam kết kinh doanh để xây dựng trên chuỗi ETC.

There are likely more problems, but these seem to be the most pressing for the time being. They are also compounded by the decentralized nature of the movement, which seems to be a boon for resilience, but a curse for agility. Given this fact, IOHK obviously cannot move unilaterally to address all of these problems; however, we can chart a course and invite the community to follow where they deem reasonable.

Có khả năng có nhiều vấn đề hơn, nhưng đây dường như là điều cấp bách nhất trong thời điểm hiện tại.
Chúng cũng được kết hợp bởi bản chất phi tập trung của phong trào, dường như là một lợi ích cho khả năng phục hồi, nhưng là một lời nguyền cho sự nhanh nhẹn.
Với thực tế này, IOHK rõ ràng không thể di chuyển đơn phương để giải quyết tất cả các vấn đề này;
Tuy nhiên, chúng tôi có thể lập biểu đồ một khóa học và mời cộng đồng theo dõi nơi họ cho là hợp lý.

Thus IOHK is in the process of doing the following:

Do đó, IOHK đang trong quá trình thực hiện như sau:

1. We have interviewed several community manager candidates and will make our final selection sometime next week. He or she will be responsible for assisting meetup group founders, managing social media channels, broadcasting accurate information, combating FUD, collecting feedback from the ETC community and dealing with media entities. My hope is this position will be defined by its interactions with the ETC community and give us a starting point for timely and credible information at the very least.

1. Chúng tôi đã phỏng vấn một số ứng cử viên quản lý cộng đồng và sẽ thực hiện lựa chọn cuối cùng của chúng tôi vào tuần tới.
Anh ấy hoặc cô ấy sẽ chịu trách nhiệm hỗ trợ các nhà sáng lập nhóm gặp gỡ, quản lý các kênh truyền thông xã hội, phát sóng thông tin chính xác, chống lại FUD, thu thập phản hồi từ cộng đồng ETC và giao dịch với các thực thể truyền thông.
Hy vọng của tôi là vị trí này sẽ được xác định bởi các tương tác của nó với cộng đồng ETC và ít nhất là cho chúng tôi một điểm khởi đầu cho thông tin kịp thời và đáng tin cậy.

1. IOHK is going to subsidize an educator to produce content on ETC ranging from the replay attack to new proposals suggested in various roadmaps. We have one candidate in mind and are finalizing the contract and duration of the relationship. All content will be released under a creative commons license and our hope is to again let this role be community driven.

1. IOHK sẽ trợ cấp cho một nhà giáo dục để sản xuất nội dung trên vv, từ cuộc tấn công phát lại đến các đề xuất mới được đề xuất trong các lộ trình khác nhau.
Chúng tôi có một ứng cử viên trong tâm trí và đang hoàn thiện hợp đồng và thời gian của mối quan hệ.
Tất cả nội dung sẽ được phát hành theo giấy phép Creative Commons và hy vọng của chúng tôi là một lần nữa để vai trò này được thúc đẩy bởi cộng đồng.

1. IOHK has had numerous discussions with academic partners about the consensus algorithm of ETC and also the smart contract model. We would like to see if the EVM can be improved to be more secure and that Typescript and Purescript could be used as ETC's smart contract languages representing both a functional and imperative approach to development that maps nicely onto the skillsets of existing developers. We are seeing what types of partnerships are possible in the next few months and will provide an update.

1. IOHK đã có nhiều cuộc thảo luận với các đối tác học thuật về thuật toán đồng thuận của ETC và cũng là mô hình hợp đồng thông minh.
Chúng tôi muốn xem liệu EVM có thể được cải thiện để an toàn hơn hay không và bản loại và purescript có thể được sử dụng làm ngôn ngữ hợp đồng thông minh của ETC đại diện cho cả cách tiếp cận chức năng và bắt buộc để phát triển ánh xạ độc đáo vào các kỹ năng của các nhà phát triển hiện tại.
Chúng tôi đang thấy những loại quan hệ đối tác có thể trong vài tháng tới và sẽ cung cấp một bản cập nhật.

1. We've also spent quite a bit of time looking at Smart contract languages on the horizon. There are some excellent ideas coming from [Synereo](https://www.synereo.com/whitepapers/synereo.pdf) and [Juno's Hopper](https://github.com/hopper-lang/hopper). IOHK has entered into a partnership with Kent University to begin an analysis of Transaction Languages used in cryptocurrencies. We will have a survey report available sometime in Q4 of 2016. This report will form the basis of our organization's understanding of the interplay of smart contracts in cryptocurrencies. Once available we will release it to the general public as a whitepaper.

1. Chúng tôi cũng đã dành khá nhiều thời gian để xem các ngôn ngữ hợp đồng thông minh trên đường chân trời.
Có một số ý tưởng tuyệt vời đến từ [Synereo] (https://www.synereo.com/whitepapers/synereo.pdf) và [Hopper của Juno] (https://github.com/hopper-lang/hopper).
IOHK đã hợp tác với Đại học Kent để bắt đầu phân tích các ngôn ngữ giao dịch được sử dụng trong tiền điện tử.
Chúng tôi sẽ có một báo cáo khảo sát có sẵn vào khoảng quý 4 năm 2016. Báo cáo này sẽ tạo thành cơ sở cho sự hiểu biết của tổ chức chúng tôi về sự tương tác của các hợp đồng thông minh trong tiền điện tử.
Khi có sẵn, chúng tôi sẽ phát hành nó cho công chúng như một whitepaper.

1. We have decided that [Scorex 2](https://github.com/ScorexFoundation/Scorex/tree/664d035d3a0f1b9580480cd29b15863e9b5cb654) will make a good base to build our ETC Main Client ([Read Alex's First Blog on It](http://chepurnoy.org/blog/2016/09/scorex-2-dot-0-a-full-node-view/)). The core is going through a massive refactoring that will be finished sometime this month. From this point, we will retain a scala specific team (our three developer commitment) to fork Scorex 2 and build a full ETC Node including a wallet with GUI. The architecture of Scorex should allow for much faster iterative improvements and also a great opportunity to test our new blockchain specific database [IODB](https://github.com/input-output-hk/iodb/blob/master/doc/authenticated_structures_and_database_layer.md) .

1. Chúng tôi đã quyết định rằng [SCORX 2] (https://github.com/scorexfoundation/scorex/tree/664d035d3a0f1b9580480cd29b15863e9b5cb654)
//chepurnoy.org/blog/2016/09/scorex-2-dot-0-a-full-node-view/)).
Cốt lõi đang trải qua một sự tái cấu trúc lớn sẽ được hoàn thành trong tháng này.
Từ thời điểm này, chúng tôi sẽ giữ lại một nhóm cụ thể của Scala (cam kết ba nhà phát triển của chúng tôi) để Fork Sulsx 2 và xây dựng một nút đầy đủ, vv bao gồm ví với GUI.
Kiến trúc của SCORX sẽ cho phép các cải tiến lặp nhanh hơn nhiều và cũng là một cơ hội tuyệt vời để kiểm tra cơ sở dữ liệu cụ thể blockchain mới của chúng tôi [IODB] (https://github.com/input-oundput-hk/iodb/blob/master/doc/authentated_structure_and_database_lays
.md).

1. With respect to the developer hires in particular, we have taken quite a few resumes already, but also want to make the process open to the general public. Our new community manager will post the job ad on the ETC reddit once he's been hired. I expect the first developer to be announced sometime in September. Quality scala developers with the requisite skills to make meaningful contributions to Ethereum are rare and require careful vetting.

1. Liên quan đến việc thuê nhà phát triển nói riêng, chúng tôi đã thực hiện khá nhiều hồ sơ, nhưng cũng muốn làm cho quá trình mở cho công chúng nói chung.
Người quản lý cộng đồng mới của chúng tôi sẽ đăng quảng cáo công việc trên vv Reddit sau khi anh ta được thuê.
Tôi hy vọng nhà phát triển đầu tiên sẽ được công bố vào khoảng tháng 9.
Các nhà phát triển SCALA chất lượng với các kỹ năng cần thiết để đóng góp có ý nghĩa cho Ethereum là rất hiếm và đòi hỏi phải kiểm tra cẩn thận.

1. With respect to a technological steering committee to guide the roadmap process, we are proposing the formation of a federated group tentatively called the smart contract engineering taskforce (after the IETF). Ideally we could develop an RFC process to propose improvement proposals from the community without the need for a formal, centralized entity. We'd love to see this form as a DAO. There could be two tracks covering changes requiring forks and changes that are iterative in nature. We will start the discussion about this group sometime in early October.

1
Lý tưởng nhất là chúng ta có thể phát triển một quy trình RFC để đề xuất các đề xuất cải tiến từ cộng đồng mà không cần một thực thể chính thức, tập trung.
Chúng tôi muốn xem hình thức này như một DAO.
Có thể có hai bản nhạc bao gồm các thay đổi yêu cầu các dĩa và thay đổi có bản chất lặp đi lặp lại.
Chúng tôi sẽ bắt đầu cuộc thảo luận về nhóm này vào đầu tháng Mười.

1. IOHK cannot resolve the trademark issue, but will make a commitment to not use the Ethereum brand or name in its repos or company assets. This said, we would like to see some form of bilateral resolution to this situation. It seems pyrrhic to seek trademark enforcement on a decentralized movement. We also understand the confusion this issue is causing the general public and developers.

1. IOHK không thể giải quyết vấn đề nhãn hiệu, nhưng sẽ thực hiện cam kết không sử dụng thương hiệu hoặc tên Ethereum trong tài sản repos hoặc công ty của mình.
Điều này nói rằng, chúng tôi muốn thấy một số hình thức giải quyết song phương cho tình huống này.
Có vẻ như Pyrrhic để tìm kiếm thực thi thương hiệu về một phong trào phi tập trung.
Chúng tôi cũng hiểu sự nhầm lẫn vấn đề này đang gây ra công chúng và nhà phát triển nói chung.

Overall, it's been a great two months and I look forward to the next few to see ETC continue to grow and become a strong, stable cryptocurrency. I'd like to thank the awesome community and all their help. I'd also like to thank the people who had enough patience to talk with Carlo and me despite the long meetings.

Nhìn chung, đó là một hai tháng tuyệt vời và tôi mong đợi một số ít tiếp theo để thấy vv tiếp tục phát triển và trở thành một loại tiền điện tử mạnh mẽ, ổn định.
Tôi muốn cảm ơn cộng đồng tuyệt vời và tất cả sự giúp đỡ của họ.
Tôi cũng muốn cảm ơn những người đã đủ kiên nhẫn để nói chuyện với Carlo và tôi bất chấp những cuộc họp dài.

====== Edit: Special Shout out to the Ethereum Classic Russian Community: 

====== Chỉnh sửa: Đặc biệt hét lên với cộng đồng người Nga cổ điển Ethereum:

[](https://ethclassic.ru/)

[] (https://ethclassic.ru/)

https://ethclassic.ru/


## **Attachments**

## ** tệp đính kèm **

![](img/2016-09-09-ethereum-classic-an-update.004.png)[ Ethereum Classic An Update - Input Output HongKong](https://ucarecdn.com/d030cc0e-7ade-458e-8d86-3129b200f037/-/inline/yes/ "Ethereum Classic An Update - Input Output HongKong")

