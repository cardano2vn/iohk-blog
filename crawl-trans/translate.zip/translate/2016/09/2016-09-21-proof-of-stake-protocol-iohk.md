# Proof-of-Stake Protocol - IOHK
![](img/2016-09-21-proof-of-stake-protocol-iohk.002.png) 21 September 2016![](img/2016-09-21-proof-of-stake-protocol-iohk.002.png)[ Bernardo David](tmp//en/blog/authors/bernardo-david/page-1/)![](img/2016-09-21-proof-of-stake-protocol-iohk.003.png) <1 min read

![](img/2016-09-21-proof-of-stake-protocol-iohk.004.png)[ 889](https://ucarecdn.com/8673f817-d83b-441a-8281-45e8ae68bbec/-/inline/yes/ "889")

![Bernardo David](img/2016-09-21-proof-of-stake-protocol-iohk.005.png)[](tmp//en/blog/authors/bernardo-david/page-1/)
### [**Bernardo David**](tmp//en/blog/authors/bernardo-david/page-1/)
![Proof-of-Stake Protocol - IOHK](img/2016-09-21-proof-of-stake-protocol-iohk.006.jpeg)

This is the regular seminar of the Input Output and Tokyo Tech/Tanaka Laboratory members. The topic this time is the Proof-of-Stake Protocol designed by Aggelos Kiayias, Ioannis Konstantinou, Alexander Russel, Bernardo David and Roman Oliynykov.

Đây là hội thảo thường xuyên của đầu ra đầu vào và các thành viên phòng thí nghiệm Tokyo Tech/Tanaka.
Chủ đề lần này là giao thức chứng minh cổ phần được thiết kế bởi Aggelos Kiayias, Ioannis Konstantinou, Alexander Russel, Bernardo David và Roman Oliynykov.

Bernardo, the presenter, divided the talk in two parts: the first reviews main topics in Cryptography which would help the viewer to understand the presentation and the protocol itself. Whereas the second is about the protocol itself.

Bernardo, người thuyết trình, đã chia bài nói chuyện thành hai phần: đánh giá đầu tiên các chủ đề chính trong mật mã sẽ giúp người xem hiểu bài thuyết trình và chính giao thức.
Trong khi đó thứ hai là về giao thức.

**First Part - Cryptography background**

** Phần đầu tiên - Bối cảnh mật mã **

- Commitments

- Cam kết

- Coin Tossing/Guaranteed Output Delivery

- Cấp đầu ra/giao hàng được đảm bảo

- Verifiable Secret Sharing

- Chia sẻ bí mật có thể xác minh

**Second Part - Proof-of-Stake Protocol**

** Phần thứ hai-Giao thức chứng minh cổ phần **

- Comparison Proof-of-Work (PoW) and Proof-of-Stake (PoS)

-So sánh bằng chứng làm việc (POW) và bằng chứng cổ phần (POS)

- Follow the Satoshi technique

- Thực hiện theo kỹ thuật Satoshi

- The protocol

- Giao thức

The paper is 

Giấy là

[](http://eprint.iacr.org/2016/889.pdf)

[] (http://eprint.iacr.org/2016/889.pdf)

A Provably Secure Proof-of-Stake Blockchain Protocol

Một giao thức blockchain bằng chứng có giá trị có giá trị

## **Attachments**

## ** tệp đính kèm **

![](img/2016-09-21-proof-of-stake-protocol-iohk.004.png)[ 889](https://ucarecdn.com/8673f817-d83b-441a-8281-45e8ae68bbec/-/inline/yes/ "889")

