# RollerChain, a Blockchain With Safely Pruneable History
![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.002.png) 7 September 2016![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.002.png)[ Alexander Chepurnoy](tmp//en/blog/authors/alexander-chepurnoy/page-1/)![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.003.png) 3 mins read

![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.004.png)[ RollerChain, a Blockchain With Safely Pruneable History - Input Output HongKong](https://ucarecdn.com/3533a9d1-140a-4752-b4ae-6a0585bb0c95/-/inline/yes/ "RollerChain, a Blockchain With Safely Pruneable History - Input Output HongKong")

![Alexander Chepurnoy](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.005.png)[](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
### [**Alexander Chepurnoy**](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
Research Fellow

Team Scorex Manager

- ![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.006.png)[](https://www.youtube.com/watch?v=Pxu4gpuVnQE "YouTube")
- ![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.007.png)[](https://twitter.com/chepurnoy "Twitter")
- ![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.008.png)[](https://github.com/kushti "GitHub")

![RollerChain, a Blockchain With Safely Pruneable History](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.009.jpeg)

When you starting a Bitcoin node it is downloading all the transactions for more than 7 years in order to check them all. People are often asking in the community resources whether it is possible to avoid that. In a more interesting formulation the question would be â€œcan we get fullnode security without going from genesis blockâ€? The question becomes even more important if we consider the following scenario. Full blocks with transactions are needed only in order to update a minimal state, that is, some common state representation enough to check whether is arbitrary transaction is valid(against the state) or not. In case of Bitcoin, minimal state is unspent outputs set (we call this state*minimal* as a node could also store some additional information also, e.g. historical transactions for selected addresses, but this information is not needed to check validity of an arbitrary transaction). Having this state (with some additional data to perform possible rollbacks) full blocks are not needed anymore and so could be removed.

Khi bạn bắt đầu một nút bitcoin, nó sẽ tải xuống tất cả các giao dịch trong hơn 7 năm để kiểm tra tất cả. Mọi người thường hỏi trong các nguồn lực cộng đồng liệu có thể tránh điều đó không. Trong một công thức thú vị hơn, câu hỏi sẽ là "Chúng ta có thể nhận được bảo mật đầy đủ mà không đi từ Genesis Block"? Câu hỏi càng trở nên quan trọng hơn nếu chúng ta xem xét kịch bản sau. Các khối đầy đủ với các giao dịch chỉ cần thiết để cập nhật trạng thái tối thiểu, nghĩa là một số đại diện trạng thái phổ biến đủ để kiểm tra xem giao dịch tùy ý có hợp lệ hay không (chống lại trạng thái) hay không. Trong trường hợp bitcoin, trạng thái tối thiểu là đầu ra chưa được đặt (chúng tôi gọi trạng thái này* tối thiểu* là nút cũng có thể lưu trữ một số thông tin bổ sung, ví dụ: giao dịch lịch sử cho các địa chỉ được chọn, nhưng thông tin này là không cần thiết để kiểm tra tính hợp lệ của một giao dịch tùy ý ). Có trạng thái này (với một số dữ liệu bổ sung để thực hiện các khối rollback có thể) không cần thiết nữa và do đó có thể được xóa.

In Bitcoin fullnodes are storing all the full blocks since genesis without a clear selfish need. This is the altruistic behavior and we can not expect nodes to follow it in the long term. But if all the nodes are rational how a new node can download and replay the history?

Trong Bitcoin Fullnodes đang lưu trữ tất cả các khối đầy đủ kể từ Genesis mà không có nhu cầu ích kỷ rõ ràng.
Đây là hành vi vị tha và chúng ta không thể mong đợi các nút sẽ theo nó trong dài hạn.
Nhưng nếu tất cả các nút là hợp lý, làm thế nào một nút mới có thể tải xuống và phát lại lịch sử?

[](http://arxiv.org/abs/1603.07926)

[] (http://arxiv.org/abs/1603.07926)

The proposal recently put on Arxiv

Đề xuất gần đây đã đưa ra arxiv

trying to solve the problems mentioned with a new Proof-of-Work consensus protocol. I very lightly list here modifications from Bitcoin, for details please read the paper.

Cố gắng giải quyết các vấn đề được đề cập với một giao thức đồng thuận bằng chứng làm việc mới.
Tôi rất nhẹ liệt kê các sửa đổi từ Bitcoin, để biết chi tiết, vui lòng đọc bài báo.

1. State is to be represented as an authenticated data structure(Merkle tree is the simple example of such a data structure) and a root value of it is to be included into a blockheader. It is the pretty old idea already implemented in Ethereum(and some other coins).

1. Trạng thái được biểu diễn dưới dạng cấu trúc dữ liệu được xác thực (cây Merkle là ví dụ đơn giản về cấu trúc dữ liệu như vậy) và giá trị gốc của nó sẽ được đưa vào một blockheader.
Đó là ý tưởng khá cũ đã được thực hiện trong Ethereum (và một số đồng tiền khác).

1. We then modify a Proof-of-Work function. A miner is choosing uniformly **k** state snapshot versions out of last **n** a (sufficiently large) network stores collectively. In order to generate a block miner needs to provide proofs of possession for all the state snapshots. On a new block arrival a miner updates **k+1** states, not one, so full blocks (since minimal value in **k**) are also needed.

1. Sau đó, chúng tôi sửa đổi một chức năng bằng chứng làm việc.
Một công cụ khai thác đang chọn các phiên bản ảnh chụp trạng thái đồng đều ** K ** cuối cùng của các cửa hàng mạng ** n ** A (đủ lớn).
Để tạo ra một công cụ khai thác khối cần cung cấp bằng chứng sở hữu cho tất cả các ảnh chụp nhanh của tiểu bang.
Trên một khối mới đến, một công cụ khai thác cập nhật ** k+1 ** trạng thái, không phải một, vì vậy các khối đầy đủ (vì giá trị tối thiểu trong ** k **) cũng cần thiết.

Thus miners store a distributed database of last **n** full blocks AND state snapshots getting rewards for that activity. A new node downloads blockheaders since genesis first (header in Bitcoin is just 80 bytes, in Rollerchain 144 bytes if a hash function with 32 bytes output is chosen). Then it could download last snapshot or from **n** blocks ago, or from somewhere in between. It is proven that this scheme achieves fullnode-going-from-genesis security with probability of failure going down exponentially with â€œnâ€ (see Theorem 2 in the paper). Full blocks not needed for mining could be removed by all the nodes. They can store them as in Bitcoin but we do not expect it anymore.

Do đó, các công ty khai thác lưu trữ một cơ sở dữ liệu phân tán của các khối đầy đủ ** n ** cuối cùng và các ảnh chụp nhanh nhận được phần thưởng cho hoạt động đó.
Một nút mới tải xuống các đầu chặn kể từ Genesis First (tiêu đề trong Bitcoin chỉ là 80 byte, trong RollerChain 144 byte nếu một hàm băm có đầu ra 32 byte được chọn).
Sau đó, nó có thể tải xuống ảnh chụp nhanh cuối hoặc từ các khối ** n ** trước đây hoặc từ một nơi nào đó ở giữa.
Người ta đã chứng minh rằng kế hoạch này đạt được bảo mật toàn diện từ Genesis với xác suất thất bại đi xuống theo cấp số nhân với "không (xem Định lý 2 trong bài báo).
Các khối đầy đủ không cần thiết để khai thác có thể được loại bỏ bởi tất cả các nút.
Họ có thể lưu trữ chúng như trong Bitcoin nhưng chúng tôi không mong đợi điều đó nữa.

The RollerChain fullnode is storing only sliding window of full blocks thus storing disk space, also less bandwidth is needed in order to feed new nodes in the network and so bandwidth saved could be repurposed for other tasks.

Fullnode của con lăn chỉ lưu trữ cửa sổ trượt của các khối đầy đủ do đó lưu trữ không gian đĩa, cũng cần ít băng thông hơn để cung cấp các nút mới trong mạng và do đó, băng thông được lưu lại có thể được sử dụng lại cho các tác vụ khác.

## **Attachments**

## ** tệp đính kèm **

![](img/2016-09-07-rollerchain-a-blockchain-with-safely-pruneable-history.004.png)[ RollerChain, a Blockchain With Safely Pruneable History - Input Output HongKong](https://ucarecdn.com/3533a9d1-140a-4752-b4ae-6a0585bb0c95/-/inline/yes/ "RollerChain, a Blockchain With Safely Pruneable History - Input Output HongKong")

