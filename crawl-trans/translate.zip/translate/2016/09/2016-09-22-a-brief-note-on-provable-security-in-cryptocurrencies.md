# A Brief Note on Provable Security in Cryptocurrencies
![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.002.png) 22 September 2016![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.002.png)[ Mario Larangeira](tmp//en/blog/authors/mario-larangeira/page-1/)![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.003.png) 5 mins read

![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.004.png)[ A Brief Note on Provable Security in Cryptocurrencies - Input Output - HongKong](https://ucarecdn.com/b0b08864-d4e2-40ed-9ea6-21f9ff33b560/-/inline/yes/ "A Brief Note on Provable Security in Cryptocurrencies - Input Output - HongKong")

![Mario Larangeira](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.005.png)[](tmp//en/blog/authors/mario-larangeira/page-1/)
### [**Mario Larangeira**](tmp//en/blog/authors/mario-larangeira/page-1/)
Research Fellow

Academic Research

- ![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.006.png)[](mailto:mario.larangeira@iohk.io "Email")
- ![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.007.png)[](https://www.youtube.com/watch?v=LUUFbGB-vyg "YouTube")
- ![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.008.png)[](https://jp.linkedin.com/in/larangeira "LinkedIn")

![A Brief Note on Provable Security in Cryptocurrencies](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.009.jpeg)

This post tries to give a short overview of provable security in cryptocurrencies.

Bài đăng này cố gắng đưa ra một cái nhìn tổng quan ngắn về bảo mật có thể chứng minh trong tiền điện tử.

### **Provable Security**

### ** Bảo mật có thể chứng minh **

Provable security is a relatively new area within the cryptography discipline. The first papers in the modern cryptography (the one that starts from the seventies until now) do not have a rigorous security analysis. That is, with the exception of citation of concrete attacks, there is no attempt to meticulously formalize the adversary power and capabilities.

Bảo mật có thể chứng minh là một lĩnh vực tương đối mới trong kỷ luật mật mã.
Các bài báo đầu tiên trong mật mã hiện đại (bản bắt đầu từ những năm bảy mươi cho đến bây giờ) không có phân tích bảo mật nghiêm ngặt.
Đó là, ngoại trừ trích dẫn các cuộc tấn công cụ thể, không có nỗ lực chính thức nào chính thức hóa sức mạnh và khả năng của đối thủ.

For example, the paper "New Directions in Cryptography" by Whitfield Diffie and Martin Hellman, which is considered by most the beginning of modern cryptography (at least the public and civilian one), does not provide such rigorous analysis.

Ví dụ, bài báo "hướng đi mới trong mật mã" của Whitfield Diffie và Martin Hellman, được coi là phần lớn sự khởi đầu của mật mã hiện đại (ít nhất là công chúng và dân sự), không cung cấp phân tích nghiêm ngặt như vậy.

The publications from the cryptographic research community of today illustrate a startling difference from that era. In almost every relevant conference or journal, it is required from the authors a security analysis. With special care when the work proposes a new cryptographic scheme or claim improvements. Today, a new scheme or protocol without a proof of security in its original publication will hardly be accepted.

Các ấn phẩm từ cộng đồng nghiên cứu mật mã ngày nay minh họa một sự khác biệt đáng kinh ngạc so với thời đại đó.
Trong hầu hết mọi hội nghị hoặc tạp chí có liên quan, nó được yêu cầu từ các tác giả phân tích bảo mật.
Với sự chăm sóc đặc biệt khi công việc đề xuất một chương trình mật mã mới hoặc cải thiện yêu cầu.
Ngày nay, một sơ đồ hoặc giao thức mới mà không có bằng chứng bảo mật trong ấn phẩm ban đầu của nó sẽ khó được chấp nhận.

In the context of cryptocurrencies such evolution can be observed too. However, before going to that topic, it is convenient to review briefly what we mean by "adversary power and capabilities" mentioned earlier.

Trong bối cảnh tiền điện tử, sự tiến hóa như vậy cũng có thể được quan sát.
Tuy nhiên, trước khi đi đến chủ đề đó, thuận tiện để xem xét ngắn gọn những gì chúng tôi muốn nói bởi "sức mạnh và khả năng bất lợi" đã đề cập trước đó.

### **Class of Attacks**

### ** Lớp tấn công **

A somewhat naive approach is to rely on the observation of the impossibility of a concrete attack. Unfortunately, provable security is a subtle topic. Such approach would just be true for that particular concrete attack. In other words, it does not necessarily tell us anything about small variants or maybe different parameter values involved in the attack.

Một cách tiếp cận hơi ngây thơ là dựa vào quan sát về sự bất khả thi của một cuộc tấn công cụ thể.
Thật không may, bảo mật có thể chứng minh là một chủ đề tinh tế.
Cách tiếp cận như vậy sẽ đúng với cuộc tấn công cụ thể cụ thể đó.
Nói cách khác, nó không nhất thiết cho chúng ta biết bất cứ điều gì về các biến thể nhỏ hoặc có thể các giá trị tham số khác nhau liên quan đến cuộc tấn công.

A more systematic, and therefore more preferable, approach is to design a formal model of the adversary capabilities. The goal of such a design is to construct a model attack as inclusive as possible. That is, a model which would capture as much concrete attacks as possible. Thereby giving us, in fact, a class of attacks.

Một cách tiếp cận có hệ thống hơn, và do đó được ưu tiên hơn là thiết kế một mô hình chính thức của các khả năng đối thủ.
Mục tiêu của một thiết kế như vậy là xây dựng một cuộc tấn công mô hình càng bao gồm càng tốt.
Đó là, một mô hình sẽ nắm bắt càng nhiều cuộc tấn công cụ thể càng tốt.
Do đó cho chúng ta, trên thực tế, một lớp tấn công.

The construction of such a model is not the end. What we actually want is to show (and prove) an upper bound in the probability of success of the adversary in that class of attacks. Needless to say, that the proof should show that such bound is small (more theoretical people should argue about what "small" means, but let skip this discussion in this post).

Việc xây dựng một mô hình như vậy không phải là kết thúc.
Những gì chúng tôi thực sự muốn là thể hiện (và chứng minh) một giới hạn trên trong xác suất thành công của kẻ thù trong lớp tấn công đó.
Không cần phải nói, bằng chứng nên cho thấy rằng ràng buộc như vậy là nhỏ (nhiều người lý thuyết nên tranh luận về ý nghĩa của "nhỏ", nhưng hãy bỏ qua cuộc thảo luận này trong bài đăng này).

The way of computing such a bound is in fact what has been developed for the past decades for numerous cryptographic schemes and it involves computation assumptions, primitive models information theory and etc (and it is better drop it here, because it deserves a post on its own right). Needless to say that in this process some degree of generalization and simplification takes place. In the end the result is often called "the model."

Cách tính toán một ràng buộc như vậy trên thực tế là những gì đã được phát triển trong những thập kỷ qua cho nhiều sơ đồ mật mã và nó liên quan đến các giả định tính toán, lý thuyết thông tin mô hình nguyên thủy và v.v.
quyền riêng).
Không cần phải nói rằng trong quá trình này, một số mức độ khái quát hóa và đơn giản hóa diễn ra.
Cuối cùng, kết quả thường được gọi là "mô hình."

The model is what ultimately is going to be analyzed not the system. Therefore, the construction of the model and the assurance that it is reasonable, i.e., is based as close as possible on reality, is of prime importance in provable security.

Mô hình là những gì cuối cùng sẽ được phân tích không phải là hệ thống.
Do đó, việc xây dựng mô hình và sự đảm bảo rằng nó là hợp lý, tức là, dựa trên càng gần càng có thể, có tầm quan trọng hàng đầu trong bảo mật có thể chứng minh.

As an example, in the case of the public-key encryption schemes, one classic attack model is named CPA, which stands for Chosen-Plaintext Attack. This class of attacks embraces all the attacks that the adversary can obtain, somehow, ciphertexts from any plaintexts of its (finite) choices. By the end of that interaction, the adversary is assumed to output some value under a certain probability. For example, the correct secret-key or a valid ciphertext.

Ví dụ, trong trường hợp của các chương trình mã hóa khóa công khai, một mô hình tấn công cổ điển được đặt tên là CPA, viết tắt của cuộc tấn công được chọn.
Lớp các cuộc tấn công này bao gồm tất cả các cuộc tấn công mà đối thủ có thể có được, bằng cách nào đó, các mã hóa từ bất kỳ sự rõ ràng nào của các lựa chọn (hữu hạn) của nó.
Đến cuối tương tác đó, đối thủ được giả định là đưa ra một số giá trị trong một xác suất nhất định.
Ví dụ: khóa bí mật chính xác hoặc một bản mã hợp lệ.

The reader should keep in mind that CPA is only one class. Other models can be devised and indeed have been proposed already, i.e., when the adversary has access to encrypted texts (instead of the plaintexts) given its choice of plaintext, as happens in the CCA (Chosen-Ciphertext Attack) a more powerful class of attacks. And there are several others.

Người đọc nên nhớ rằng CPA chỉ là một lớp.
Các mô hình khác có thể được nghĩ ra và thực sự đã được đề xuất, tức là, khi đối thủ có quyền truy cập vào các văn bản được mã hóa (thay vì các bản rõ) cho sự lựa chọn của nó về bản sắc
tấn công.
Và có một số người khác.

### **Adversary Model in Cryptocurrency**

### ** Mô hình bất lợi trong tiền điện tử **

While the public-key encryption scheme is a cryptographic primitive, a cryptocurrency is a protocol. Furthermore, a ledger based cryptocurrency imposes to the participants that they agree on the ledger state in order to validate transactions. Here, once again, to give a proper treatment in the study the security of the protocol means to explicitly model the adversary power and capabilities.

Trong khi sơ đồ mã hóa khóa công khai là một nguyên thủy mật mã, một loại tiền điện tử là một giao thức.
Hơn nữa, một loại tiền điện tử dựa trên sổ cái áp đặt cho những người tham gia rằng họ đồng ý về trạng thái sổ cái để xác nhận các giao dịch.
Ở đây, một lần nữa, để đưa ra một điều trị thích hợp trong nghiên cứu về bảo mật của giao thức có nghĩa là mô hình hóa rõ ràng sức mạnh và khả năng của đối thủ.

The comparison between protocols and primitives brings us a couple of differences, which should be taken into account. For example, a protocol requires the participants to exchange messages over the network, hence it is necessary to take a closer look on how the adversary behaves in the presence of these messages. The adversary can see the contents of the message? Can it block them for some time or indefinitely? All these particular cases translate into different constrained scenarios which ultimately gives us different capabilities of the protocol.

Việc so sánh giữa các giao thức và nguyên thủy mang đến cho chúng ta một vài khác biệt, cần được tính đến.
Ví dụ, một giao thức yêu cầu những người tham gia trao đổi tin nhắn qua mạng, do đó cần phải xem xét kỹ hơn về cách thức hoạt động của kẻ thù khi có sự hiện diện của các tin nhắn này.
Đối thủ có thể xem nội dung của tin nhắn?
Nó có thể chặn chúng trong một thời gian hoặc vô thời hạn?
Tất cả các trường hợp cụ thể này chuyển thành các tình huống bị ràng buộc khác nhau, cuối cùng cung cấp cho chúng ta các khả năng khác nhau của giao thức.

Good examples of these research variants are [The Bitcoin Backbone Protocol: Analysis and Applications](tmp//en/research/library#IPQHNW2R) and [Analysis of the Blockchain Protocol in Asynchronous Networks](tmp//en/research/library#8WP4QF65). They respectively study proof-of-work in the synchronous (the messages cannot be blocked) and asynchronous (can be blocked for some time) settings. A more recent work is about the formalization of the proof-of-stake based protocol [A Provably Secure Proof-of-Stake Blockchain Protocol](tmp//en/research/library#9BKRHCSI) in synchronous.

Các ví dụ tốt về các biến thể nghiên cứu này là [Giao thức xương sống Bitcoin: Phân tích và Ứng dụng] (TMP // EN/Nghiên cứu/Thư viện#IPQHNW2R) và [Phân tích giao thức blockchain trong mạng không đồng bộ] (TMP // EN/Nghiên cứu/Thư viện#
8WP4QF65).
Họ tương ứng nghiên cứu bằng chứng làm việc trong các thông báo đồng bộ (các tin nhắn không thể bị chặn) và không đồng bộ (có thể bị chặn trong một thời gian) cài đặt.
Một công việc gần đây hơn là về việc chính thức hóa giao thức dựa trên bằng chứng [một giao thức blockchain bằng chứng bảo đảm có thể bảo mật] (TMP // EN/Nghiên cứu/Thư viện#9BKRHCSI) đồng bộ.

For further reading on models and provable security, we refer the reader to a few more papers with a heavy load of cryptography theory.

Để đọc thêm về các mô hình và bảo mật có thể chứng minh, chúng tôi giới thiệu người đọc đến một vài bài báo với một lượng lớn lý thuyết mật mã.

[Random Oracles in Constantinople: Pratical Asynchronous Byzantine Agreement Using Cryptography](tmp//en/research/library#7A537TWI)

.

[Zero Knowledge in the Random Oracle model, Revisited](tmp//en/research/library#XTGGH9TQ)

[Không có kiến thức trong mô hình Oracle ngẫu nhiên, được xem xét lại] (TMP // EN/Research/Library#XTGGH9TQ)

## **Attachments**

## ** tệp đính kèm **

![](img/2016-09-22-a-brief-note-on-provable-security-in-cryptocurrencies.004.png)[ A Brief Note on Provable Security in Cryptocurrencies - Input Output - HongKong](https://ucarecdn.com/b0b08864-d4e2-40ed-9ea6-21f9ff33b560/-/inline/yes/ "A Brief Note on Provable Security in Cryptocurrencies - Input Output - HongKong")

