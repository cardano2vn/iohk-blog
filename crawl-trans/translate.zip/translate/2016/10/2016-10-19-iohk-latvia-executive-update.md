# IOHK | Latvia. Executive update
![](img/2016-10-19-iohk-latvia-executive-update.002.png) 19 October 2016![](img/2016-10-19-iohk-latvia-executive-update.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2016-10-19-iohk-latvia-executive-update.003.png) 3 mins read

![](img/2016-10-19-iohk-latvia-executive-update.004.png)[ IOHK | Latvia, Executive update - Input Output HongKong](https://ucarecdn.com/7b71e844-0cd2-46a6-84e8-080da1052582/-/inline/yes/ "IOHK | Latvia, Executive update - Input Output HongKong")

![Jeremy Wood](img/2016-10-19-iohk-latvia-executive-update.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2016-10-19-iohk-latvia-executive-update.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2016-10-19-iohk-latvia-executive-update.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2016-10-19-iohk-latvia-executive-update.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![IOHK | Latvia. Executive update](img/2016-10-19-iohk-latvia-executive-update.009.jpeg)

For some of the IOHK team it was their first time meeting in person when we gathered in Latvia this month for an intensive working session to push forward several of our key projects. As a distributed company we usually collaborate remotely, across time zones, so coming together to exchange ideas was inspiring. For two weeks in the beautiful capital city of Riga, we advanced our groundbreaking work implementing the first [provably secure proof-of-stake protocol](tmp//en/blog/research/Proof-of-Stake-Protocol-IOHK/). Our research fellow, [Bernardo David](tmp//en/team/bernardo-david/), gave an earlier presentation on the protocol.

Đối với một số nhóm IOHK, đây là lần gặp gỡ lần đầu tiên của họ khi chúng tôi tập trung tại Latvia trong tháng này cho một phiên làm việc chuyên sâu để thúc đẩy một số dự án chính của chúng tôi.
Là một công ty phân tán, chúng tôi thường hợp tác từ xa, theo các múi giờ, vì vậy việc cùng nhau trao đổi ý tưởng là truyền cảm hứng.
Trong hai tuần tại thành phố thủ đô xinh đẹp của Riga, chúng tôi đã nâng cao công việc đột phá của chúng tôi để thực hiện giao thức chứng minh cổ phần đầu tiên [có thể bảo đảm có thể bảo đảm] (TMP // EN/Blog/Nghiên cứu/Chứng minh-OF-OF-Protocol-IOHK/)
.
Nghiên cứu viên của chúng tôi, [Bernardo David] (TMP // EN/Team/Bernardo-David/), đã trình bày trước đó về giao thức.

Our core developer team and partner, Serokell, is preparing a version of RS|coin to be used in a production system. We published our [implementation of RS|coin](https://github.com/input-output-hk/rscoin-haskell) - the central bank cryptocurrency conceived by University College London researchers - earlier this year.

Đội ngũ phát triển cốt lõi của chúng tôi, Serokell, đang chuẩn bị một phiên bản của đồng xu RS | sẽ được sử dụng trong một hệ thống sản xuất.
Chúng tôi đã xuất bản [triển khai RS | Coin] (https://github.com/input-oundput-hk/rscoin-haskell)-Tiền điện tử trung ương được hình thành bởi các nhà nghiên cứu của Đại học College London-đầu năm nay.

Itâ€™s extremely exciting to know something we built will actually get used and be useful. Our team here in Latvia is working with our Japanese branch to help a client secure their information on the blockchain. The Serokell team, led by [Arseniy Seroka](tmp//en/team/arseniy-seroka/) and [Jonn Mostovoy](tmp//en/team/jonn-mostovoy/), includes expert developers and engineers drawn from Russia, Latvia, Croatia and Portugal. We've found exciting innovations that come from using Haskell. Serokell and the design team are putting the finishing touches to a block explorer for a major client.

Thật thú vị khi biết một cái gì đó chúng tôi xây dựng sẽ thực sự được sử dụng và có ích.
Nhóm của chúng tôi ở đây tại Latvia đang làm việc với chi nhánh Nhật Bản của chúng tôi để giúp khách hàng bảo vệ thông tin của họ trên blockchain.
Nhóm Serokell, được dẫn dắt bởi [Arseniy Seroka] (TMP // EN/Team/Arseniy-seroka/) và [Jonn Mostovoy] (TMP // EN/Team/Jonn-Mostovoy/), bao gồm các nhà phát triển và kỹ sư chuyên gia được rút ra từ Russia
, Latvia, Croatia và Bồ Đào Nha.
Chúng tôi đã tìm thấy những đổi mới thú vị đến từ việc sử dụng Haskell.
Serokell và nhóm thiết kế đang đặt các điểm hoàn thiện cho một trình thám hiểm khối cho một khách hàng lớn.

Riga has also been very much about our ScoreX project. [Alexander Chepurnoy](tmp//en/team/alexander-chepurnoy/), the director of the [ScoreX](tmp//en/projects/scorex/) project and [Dmitry Meshkov](tmp//en/team/dmitry-meshkov/), IOHK research fellow and ScoreX project developer, gave fascinating presentations on the latest developments of this pioneering framework: a prototype cryptocurrency that allows anyone to slot in and test parts of their own cryptocurrency code.

Riga cũng đã rất nhiều về dự án SCORX của chúng tôi.
.
DMITRY-MESHKOV/), Nhà phát triển dự án SCOREX nghiên cứu của IOHK, đã đưa ra các bài thuyết trình hấp dẫn về những phát triển mới nhất của khung tiên phong này: một loại tiền điện tử nguyên mẫu cho phép bất cứ ai tham gia và kiểm tra các phần của mã tiền điện tử của riêng họ.

Both presentations covered the differences and considerations between a pedagogical implementation like ScoreX, meant to be used for research and education, and actually releasing a real cryptocurrency in the wild. In addition, many on the team took the opportunity to learn more about the ScoreX 2.0 release and what progress has been made in making it even more modular and flexible. Written in Scala, the project takes forward research in the area of authenticated data structures. Their findings are due to be published in an academic paper early next year.

Cả hai bài thuyết trình đều đề cập đến sự khác biệt và cân nhắc giữa việc thực hiện sư phạm như SCOREX, có nghĩa là được sử dụng cho nghiên cứu và giáo dục, và thực sự phát hành một loại tiền điện tử thực sự trong tự nhiên.
Ngoài ra, nhiều người trong nhóm đã có cơ hội tìm hiểu thêm về bản phát hành SCORX 2.0 và những tiến bộ đã được thực hiện để làm cho nó thậm chí còn mô -đun và linh hoạt hơn.
Được viết bằng Scala, dự án đưa nghiên cứu về phía trước trong lĩnh vực cấu trúc dữ liệu được xác thực.
Phát hiện của họ là do được công bố trong một bài báo học thuật vào đầu năm tới.

Our creative team is here in Riga, and has been working to design the UI and UX for a big project coming next year. And our operations team has been hard at work laying the foundations for all our work. All in all, Riga has been extremely productive and very exciting, and we are very much looking forward to the launch of one of these projects for a major client in a few months.

Đội ngũ sáng tạo của chúng tôi ở đây tại Riga, và đã làm việc để thiết kế UI và UX cho một dự án lớn vào năm tới.
Và nhóm hoạt động của chúng tôi đã rất chăm chỉ để đặt nền móng cho tất cả các công việc của chúng tôi.
Nói chung, Riga đã cực kỳ hiệu quả và rất thú vị, và chúng tôi rất mong chờ sự ra mắt của một trong những dự án này cho một khách hàng lớn trong một vài tháng.

## **Attachments**

## ** tệp đính kèm **

![](img/2016-10-19-iohk-latvia-executive-update.004.png)[ IOHK | Latvia, Executive update - Input Output HongKong](https://ucarecdn.com/7b71e844-0cd2-46a6-84e8-080da1052582/-/inline/yes/ "IOHK | Latvia, Executive update - Input Output HongKong")

