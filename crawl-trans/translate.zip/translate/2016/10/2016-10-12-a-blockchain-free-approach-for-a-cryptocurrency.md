# A Blockchain-free Approach for a Cryptocurrency
![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.002.png) 12 October 2016![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.002.png)[ Mario Larangeira](tmp//en/blog/authors/mario-larangeira/page-1/)![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.003.png) 5 mins read

![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.004.png)[ A Blockchain-free Approach for a Cryptocurrency - Input Output HongKong](https://ucarecdn.com/3b750624-ab1b-4ede-ac73-9d04e13aaddb/-/inline/yes/ "A Blockchain-free Approach for a Cryptocurrency - Input Output HongKong")

![Mario Larangeira](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.005.png)[](tmp//en/blog/authors/mario-larangeira/page-1/)
### [**Mario Larangeira**](tmp//en/blog/authors/mario-larangeira/page-1/)
Research Fellow

Academic Research

- ![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.006.png)[](mailto:mario.larangeira@iohk.io "Email")
- ![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.007.png)[](https://www.youtube.com/watch?v=LUUFbGB-vyg "YouTube")
- ![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.008.png)[](https://jp.linkedin.com/in/larangeira "LinkedIn")

![A Blockchain-free Approach for a Cryptocurrency](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.009.jpeg)

A major technical challenge of the cryptocurrencies is to find a way to safely increase the throughput of the system in terms of number of transactions. An approach to tackle this limitation is to review the role of the blockchain, or even to take that data structure out of the picture completely. In this post, we will comment a paper by Boyen, Carr and Haines named [Blockchain-Free Cryptocurrencies: A Rational Framework for Truly Decentralized Fast Transactions](tmp//en/research/library/#FIKAA54P) which proposes the latter approach.

Một thách thức kỹ thuật lớn của tiền điện tử là tìm cách tăng cường thông lượng của hệ thống một cách an toàn về số lượng giao dịch.
Một cách tiếp cận để giải quyết giới hạn này là xem xét vai trò của blockchain, hoặc thậm chí để đưa cấu trúc dữ liệu đó ra khỏi hình ảnh hoàn toàn.
Trong bài đăng này, chúng tôi sẽ nhận xét một bài báo của Boyen, Carr và Haines có tên [tiền điện tử không có blockchain: một khung hợp lý cho các giao dịch nhanh thực sự phi tập trung] (TMP // EN/Nghiên cứu/Thư viện/#FIKAA54P) đề xuất phương pháp sau.

Before describing the idea of the paper, and where the main contribution is, it is helpful to give an overview of how we can generally split the main components of a cryptocurrency protocol, or what is commonly known as the **consensus protocol**. The three main components are:

Trước khi mô tả ý tưởng về bài báo và nơi đóng góp chính, rất hữu ích khi đưa ra một cái nhìn tổng quan về cách chúng ta có thể chia các thành phần chính của giao thức tiền điện tử hoặc những gì thường được gọi là giao thức đồng thuận ** **.
Ba thành phần chính là:

- the protocol itself, the routine that every node follows;

- Bản thân giao thức, thói quen mà mọi nút theo sau;

- the blockchain data structure; and

- Cấu trúc dữ liệu blockchain;
và

- the Proof of Work (PoW) paradigm.

- Mô hình chứng minh công việc (POW).

Here we are clearly giving the emphasis on the Bitecoin like systems which rely on the PoW idea. The reader should keep in mind that not all systems rely on it (as for example [Proof of Stake based protocol](tmp//en/research/library#9BKRHCSI)).

Ở đây chúng tôi rõ ràng đang nhấn mạnh vào các hệ thống giống như bitecoin dựa vào ý tưởng POW.
Người đọc nên nhớ rằng không phải tất cả các hệ thống đều dựa vào nó (ví dụ như [Proof of Stake Protocol] (TMP // EN/RESTUOND/LIBRARY#9BKRHCSI)).

We start by reviewing the second item above: the blockchain.

Chúng tôi bắt đầu bằng cách xem xét mục thứ hai ở trên: blockchain.

### **The Blockchain**

### ** blockchain **

The reader familiar with decentralized cryptocurrencies is aware that the blockchain is a data-structure which is kept by the network players, which are often called \*miners\* in Bitcoin jargon.

Người đọc quen thuộc với các loại tiền điện tử phi tập trung nhận thức được rằng blockchain là một cấu trúc dữ liệu được giữ bởi người chơi mạng, thường được gọi là \* Miners \* trong biệt ngữ bitcoin.

Each smallest part of such structure is called block, hence the name, which is where the transactions are described. There are different ways of building the actual structure (for example, [Bitcoin-NG](tmp//en/research/library/#BMMAH9X4) and [GHOST](tmp//en/research/library/#6GMW7WD9), however in the end, the pace of the the block generation (including its addition in the structure) is the heartbeat of the whole system.

Mỗi phần nhỏ nhất của cấu trúc như vậy được gọi là khối, do đó tên, đó là nơi các giao dịch được mô tả.
Có nhiều cách khác nhau để xây dựng cấu trúc thực tế (ví dụ: [Bitcoin-ng] (TMP // EN/Nghiên cứu/Thư viện/#BMMAH9X4) và [Ghost] (TMP // EN/Nghiên cứu/Thư viện/#6GMW7WD9), tuy nhiên
Cuối cùng, tốc độ của việc tạo khối (bao gồm cả sự bổ sung của nó trong cấu trúc) là nhịp tim của toàn bộ hệ thống.

That is, with each new added block, containing brand new transactions, we are sure that the system is "alive" and making progress. However here also lies a problem.

Đó là, với mỗi khối được thêm vào mới, chứa các giao dịch hoàn toàn mới, chúng tôi chắc chắn rằng hệ thống này "sống" và tiến bộ.
Tuy nhiên ở đây cũng là một vấn đề.

### **The Scalability of the Blockchain**

### ** Khả năng mở rộng của blockchain **

In the pace of the whole system lies the fundamental constrain of the growth speed of the blockchain. Nakamoto was aware of it as well as its implications, as stated in the Bitcoin seminal [Nakamotoâ€™s whitepaper](/research/library/#2VPKGNSS).

Trong tốc độ của toàn bộ hệ thống là sự hạn chế cơ bản của tốc độ tăng trưởng của blockchain.
Nakamoto đã nhận thức được nó cũng như ý nghĩa của nó, như đã nêu trong Bitcoin Seminal [whitepaper của Nakamoto] (/nghiên cứu/thư viện/#2VPKGNSS).

A major implication of this limitation is the regulated speed of block generation using the **difficulty level**. That is the hash value that the player needs to find in order to generate a new block in PoW. That value is carefully set within the Bitcoin network to keep just the right balance between the block generation time and the block spread time over the network.

Một hàm ý chính của giới hạn này là tốc độ quy định của việc tạo khối bằng cách sử dụng mức độ khó ** **.
Đó là giá trị băm mà người chơi cần tìm để tạo một khối mới trong POW.
Giá trị đó được đặt cẩn thận trong mạng bitcoin để giữ sự cân bằng phù hợp giữa thời gian tạo khối và thời gian lan truyền khối trên mạng.

In a different setting, say, with an arbitrarily low difficulty level, there would be a higher block generation rate for sure. However, due to the competitive nature of the PoW and the blockchain addition, the forks will become more frequent, therefore increasing the risk of attacks. One should expect this because the miners are competing against each other, in order to generate new valid blocks.

Trong một môi trường khác, giả sử, với mức độ khó thấp tùy ý, chắc chắn sẽ có tốc độ tạo khối cao hơn.
Tuy nhiên, do tính chất cạnh tranh của POW và bổ sung blockchain, các dĩa sẽ trở nên thường xuyên hơn, do đó làm tăng nguy cơ tấn công.
Người ta nên mong đợi điều này bởi vì những người khai thác đang cạnh tranh với nhau, để tạo ra các khối hợp lệ mới.

In other words, the scalability constraints derive from the blockchain centralized setting.

Nói cách khác, các ràng buộc khả năng mở rộng xuất phát từ cài đặt tập trung blockchain.

### **A Blockchain-free Approach**

### ** Một cách tiếp cận không có blockchain **

The main idea behind the study of Boyen et al. is to substitute the blockchain by a directed graph of \*\*transactions\*\*, not blocks.

Ý tưởng chính đằng sau nghiên cứu của Boyen et al.
là để thay thế blockchain bằng một biểu đồ định hướng của \*\*Giao dịch \*\*, không phải các khối.

In that setting the system is not required to make progress by the pace of a single data structure like the blockchain. In fact, there is not a notion of block in their idea. The obvious direct consequence is that there is no race among the players of the system to generate the new block. The players are allowed to choose in which point in the graph they want to expand it.

Trong cài đặt đó, hệ thống không bắt buộc phải tiến bộ theo tốc độ của một cấu trúc dữ liệu duy nhất như blockchain.
Trong thực tế, không có một khái niệm về khối trong ý tưởng của họ.
Hậu quả trực tiếp rõ ràng là không có chủng tộc nào giữa những người chơi của hệ thống để tạo ra khối mới.
Người chơi được phép chọn trong điểm nào trong biểu đồ họ muốn mở rộng nó.

Instead of the previous competitive blockchain environment, the players cooperatively expand the directed graph by adding new nodes, i.e., transactions, to it. We stress that every new node in the graph is a new transaction. And the action of attaching the transaction into the graph validates the transactions where the new one is attached to, i.e., the parent nodes (the new node has two parent nodes in the graph).

Thay vì môi trường blockchain cạnh tranh trước đó, người chơi hợp tác mở rộng biểu đồ được định hướng bằng cách thêm các nút mới, tức là, các giao dịch, vào đó.
Chúng tôi nhấn mạnh rằng mọi nút mới trong biểu đồ là một giao dịch mới.
Và hành động gắn giao dịch vào biểu đồ xác thực các giao dịch trong đó giao dịch mới được đính kèm, tức là, các nút mẹ (nút mới có hai nút cha trong biểu đồ).

In order to incentivize the players to keep the progress of the system, every new transaction specifies a fee, which is decided by the issuer of the transaction. Consequently every new node which is later attached to that transaction (as described earlier) does two actions: (1) validate the transaction represented of its two parents (the number of parents is fixed by their framework) and (2) collects the fee from its parents.

Để khuyến khích người chơi giữ tiến trình của hệ thống, mọi giao dịch mới chỉ định một khoản phí, được quyết định bởi nhà phát hành giao dịch.
Do đó, mọi nút mới sau này được đính kèm với giao dịch đó (như được mô tả trước đó) thực hiện hai hành động: (1) xác thực giao dịch được đại diện cho hai phụ huynh của nó (số lượng cha mẹ được cố định bởi khung của họ) và (2) thu phí từ
cha mẹ của nó.

Differently from the blockchain setting, there is not a notion of rounds (or epochs), i.e., the new block generation. However, due to the collection of fees, the players are incentivized to keep adding transactions to the system, therefore making the transaction history evolve. Another advantage is that the issuer of a transaction can increase the speed of the validation by offering a higher fee.

Khác với cài đặt blockchain, không có khái niệm về các vòng (hoặc kỷ nguyên), tức là, tạo khối mới.
Tuy nhiên, do việc thu phí, người chơi được khuyến khích tiếp tục thêm các giao dịch vào hệ thống, do đó làm cho lịch sử giao dịch phát triển.
Một lợi thế khác là nhà phát hành giao dịch có thể tăng tốc độ xác thực bằng cách cung cấp một khoản phí cao hơn.

This framework reverses the competitive nature of the miners to a more cooperative approach to validate transactions in the system.

Khung này đảo ngược bản chất cạnh tranh của các thợ mỏ sang cách tiếp cận hợp tác hơn để xác nhận các giao dịch trong hệ thống.

Other papers describing scalability issues within blockchain based protocols can be found here:

Các giấy tờ khác mô tả các vấn đề về khả năng mở rộng trong các giao thức dựa trên blockchain có thể được tìm thấy ở đây:

- [On Scaling Decentralized Blockchains](tmp//en/research/library/#5QAZMTGI)

- [Khi mở rộng quy mô blockchains]

- [Inclusive Block Chain Protocols](tmp//en/research/library/#3R24CD24)

- [Các giao thức chuỗi khối bao gồm] (TMP // EN/Nghiên cứu/Thư viện/#3R24CD24)

## **Attachments**

## ** tệp đính kèm **

![](img/2016-10-12-a-blockchain-free-approach-for-a-cryptocurrency.004.png)[ A Blockchain-free Approach for a Cryptocurrency - Input Output HongKong](https://ucarecdn.com/3b750624-ab1b-4ede-ac73-9d04e13aaddb/-/inline/yes/ "A Blockchain-free Approach for a Cryptocurrency - Input Output HongKong")

