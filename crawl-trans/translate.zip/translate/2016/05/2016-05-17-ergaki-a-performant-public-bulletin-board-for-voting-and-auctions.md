# Announcing Ergaki - A performant, public bulletin board for voting and auctions
![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.002.png) 17 May 2016![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.002.png)[ Alexander Chepurnoy](tmp//en/blog/authors/alexander-chepurnoy/page-1/)![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.003.png) 2 mins read

![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.004.png)[ Announcing Ergaki - A performant, public bulletin board for voting and auctions - Input Output HongKong](https://ucarecdn.com/a2b0fa9a-59f1-474a-bb33-9fd68477d23e/-/inline/yes/ "Announcing Ergaki - A performant, public bulletin board for voting and auctions - Input Output HongKong")

![Alexander Chepurnoy](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.005.png)[](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
### [**Alexander Chepurnoy**](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
Research Fellow

Team Scorex Manager

- ![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.006.png)[](https://www.youtube.com/watch?v=Pxu4gpuVnQE "YouTube")
- ![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.007.png)[](https://twitter.com/chepurnoy "Twitter")
- ![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.008.png)[](https://github.com/kushti "GitHub")

![Announcing Ergaki - A performant, public bulletin board for voting and auctions](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.009.jpeg)

The first Scorex-based testnet, Lagonaki, combines the Permacoin consensus protocol implementation with a simple, Nxt-like payments module. After Lagonaki, the next Scorex-based testnet will be *Ergaki*, a block chain system that will be used as a public and performant bulletin board for various protocols including voting and auctions. The components of Ergaki are the following:

TestNet dựa trên điểm số đầu tiên, Lagonaki, kết hợp việc triển khai giao thức đồng thuận Permacoin với mô-đun thanh toán đơn giản, giống như NXT.
Sau Lagonaki, testnet dựa trên điểm số tiếp theo sẽ là *ergaki *, một hệ thống chuỗi khối sẽ được sử dụng làm bảng thông báo công khai và hiệu suất cho các giao thức khác nhau bao gồm bỏ phiếu và đấu giá.
Các thành phần của Ergaki là như sau:

1. A new Proof-of-Work scheme based on [RollerChain](http://arxiv.org/abs/1603.07926). By default, nodes will follow a "rational behavior", and will remove blocks that are not needed for Proof-of-Work mining. Potentially, a scheme like Ghost/Spectre or Bitcoin-NG/ByzCoin will be used to increase the system's troughput.

1. Một sơ đồ chứng minh mới dựa trên [Rollerchain] (http://arxiv.org/abs/1603.07926).
Theo mặc định, các nút sẽ tuân theo "hành vi hợp lý" và sẽ loại bỏ các khối không cần thiết để khai thác bằng chứng.
Có khả năng, một sơ đồ như Ghost/Spectre hoặc Bitcoin-NG/Byzcoin sẽ được sử dụng để tăng thông lượng của hệ thống.

1. A new transactional module where state will be comprised of [boxes](http://chepurnoy.org/blog/2016/03/cryptocurrency-minimal-state-representation-boxes-vs-accounts/). This transactional model will be different from that of Bitcoin, therefore there will be no stack-language scripts. 

1. Một mô-đun giao dịch mới trong đó trạng thái sẽ bao gồm [hộp] (http://chepurnoy.org/blog/2016/03/cryptocurrency-minimal-tate-representation-boxes-vs-counts/).
Mô hình giao dịch này sẽ khác với Bitcoin, do đó sẽ không có kịch bản ngôn ngữ ngăn xếp.

1. A new fee model by which mandatory fees will not be based on transaction size but on state increment. For example, a transaction that is lowering the state size would have a minimal or no fee at all. In addition, the storage of boxes in a state will incur fees not only based on size, but also based on life timespan also, with a possible exception for a box of some minimal size. So, unlike all other blockchains, it would be not possible to store anything in the Ergaki blockchain forever by paying only once. 

1. Một mô hình phí mới theo đó các khoản phí bắt buộc sẽ không dựa trên quy mô giao dịch mà dựa trên mức tăng trạng thái.
Ví dụ, một giao dịch đang giảm quy mô trạng thái sẽ có mức phí tối thiểu hoặc không có phí.
Ngoài ra, việc lưu trữ các hộp ở trạng thái sẽ phải chịu các khoản phí không chỉ dựa trên kích thước mà còn dựa trên thời gian sống, với một ngoại lệ có thể cho một hộp có kích thước tối thiểu.
Vì vậy, không giống như tất cả các blockchain khác, sẽ không thể lưu trữ bất cứ thứ gì trong blockchain Ergaki mãi mãi bằng cách chỉ trả tiền một lần.

1. A new improved difficulty-adjustment algorithm. A white-paper on that is basically ready and will be published before the release of Ergaki.

1. Một thuật toán điều chỉnh độ khó được cải thiện mới.
Một tờ giấy trắng về cơ bản đã sẵn sàng và sẽ được xuất bản trước khi phát hành Ergaki.

The IOHK Scorex team will test the Ergaki testnet on some applications by using a large testbed against a private Ethereum network. The goal is outperform the latter by the orders of magnitude.

Nhóm IOHK Scorex sẽ kiểm tra Ergaki Testnet trên một số ứng dụng bằng cách sử dụng một thử nghiệm lớn đối với mạng Ethereum riêng.
Mục tiêu vượt trội so với sau theo thứ tự cường độ.

Ergaki is planned to be released in September, 2016.

Ergaki được lên kế hoạch phát hành vào tháng 9 năm 2016.

## **Attachments**

## ** tệp đính kèm **

![](img/2016-05-17-ergaki-a-performant-public-bulletin-board-for-voting-and-auctions.004.png)[ Announcing Ergaki - A performant, public bulletin board for voting and auctions - Input Output HongKong](https://ucarecdn.com/a2b0fa9a-59f1-474a-bb33-9fd68477d23e/-/inline/yes/ "Announcing Ergaki - A performant, public bulletin board for voting and auctions - Input Output HongKong")

