# Mario Larangeira, IOHK Research - Digital Cash
![](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.002.png) 25 July 2016![](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.002.png)[ Mario Larangeira](tmp//en/blog/authors/mario-larangeira/page-1/)![](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.003.png) <1 min read

![Mario Larangeira](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.004.png)[](tmp//en/blog/authors/mario-larangeira/page-1/)
### [**Mario Larangeira**](tmp//en/blog/authors/mario-larangeira/page-1/)
Research Fellow

Academic Research

- ![](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.005.png)[](mailto:mario.larangeira@iohk.io "Email")
- ![](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.006.png)[](https://www.youtube.com/watch?v=LUUFbGB-vyg "YouTube")
- ![](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.007.png)[](https://jp.linkedin.com/in/larangeira "LinkedIn")

![Mario Larangeira, IOHK Research - Digital Cash](img/2016-07-25-mario-larangeira-iohk-research-digital-cash.008.jpeg)
