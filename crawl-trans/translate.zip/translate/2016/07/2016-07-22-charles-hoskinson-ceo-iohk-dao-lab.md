# Charles Hoskinson, CEO, IOHK - DAO lab
![](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.002.png) 22 July 2016![](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.003.png) <1 min read

![Charles Hoskinson](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.004.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.005.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.006.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.007.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Charles Hoskinson, CEO, IOHK - DAO lab](img/2016-07-22-charles-hoskinson-ceo-iohk-dao-lab.008.jpeg)
