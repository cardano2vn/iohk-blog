# Michael Parsons FCA - Chairman of the Cardano Foundation
![](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.002.png) 22 July 2016![](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.003.png) <1 min read

![Charles Hoskinson](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.004.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.005.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.006.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.007.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Michael Parsons FCA - Chairman of the Cardano Foundation](img/2016-07-22-michael-parsons-fca-chairman-of-the-cardano-foundation.008.jpeg)
