# Alexander Chepurnoy, IOHK Research - Scorex
![](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.002.png) 22 July 2016![](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.002.png)[ Alexander Chepurnoy](tmp//en/blog/authors/alexander-chepurnoy/page-1/)![](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.003.png) <1 min read

![Alexander Chepurnoy](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.004.png)[](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
### [**Alexander Chepurnoy**](tmp//en/blog/authors/alexander-chepurnoy/page-1/)
Research Fellow

Team Scorex Manager

- ![](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.005.png)[](https://www.youtube.com/watch?v=Pxu4gpuVnQE "YouTube")
- ![](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.006.png)[](https://twitter.com/chepurnoy "Twitter")
- ![](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.007.png)[](https://github.com/kushti "GitHub")

![Alexander Chepurnoy, IOHK Research - Scorex](img/2016-07-22-alexander-chepurnoy-iohk-research-scorex.008.jpeg)
