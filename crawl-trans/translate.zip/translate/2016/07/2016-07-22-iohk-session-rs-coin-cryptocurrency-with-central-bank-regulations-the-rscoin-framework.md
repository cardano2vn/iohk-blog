# IOHK session RS|COIN: Cryptocurrency with central bank regulations: the RSCoin framework
![](img/2016-07-22-iohk-session-rs-coin-cryptocurrency-with-central-bank-regulations-the-rscoin-framework.002.png) 22 July 2016![](img/2016-07-22-iohk-session-rs-coin-cryptocurrency-with-central-bank-regulations-the-rscoin-framework.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2016-07-22-iohk-session-rs-coin-cryptocurrency-with-central-bank-regulations-the-rscoin-framework.003.png) <1 min read

![Charles Hoskinson](img/2016-07-22-iohk-session-rs-coin-cryptocurrency-with-central-bank-regulations-the-rscoin-framework.004.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2016-07-22-iohk-session-rs-coin-cryptocurrency-with-central-bank-regulations-the-rscoin-framework.005.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2016-07-22-iohk-session-rs-coin-cryptocurrency-with-central-bank-regulations-the-rscoin-framework.006.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2016-07-22-iohk-session-rs-coin-cryptocurrency-with-central-bank-regulations-the-rscoin-framework.007.png)[](tmp///twitter.com/IOHK_Charles "Twitter")
