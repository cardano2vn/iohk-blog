# Introducing The Grothendieck Team
![](img/2016-12-10-introducing-the-grothendieck-team.002.png) 10 December 2016![](img/2016-12-10-introducing-the-grothendieck-team.002.png)[ Alan McSherry](tmp//en/blog/authors/alan-mcsherry/page-1/)![](img/2016-12-10-introducing-the-grothendieck-team.003.png) 4 mins read

![Alan McSherry](img/2016-12-10-introducing-the-grothendieck-team.004.png)[](tmp//en/blog/authors/alan-mcsherry/page-1/)
### [**Alan McSherry**](tmp//en/blog/authors/alan-mcsherry/page-1/)
Solutions Architect

Engineering

- ![](img/2016-12-10-introducing-the-grothendieck-team.005.png)[](https://www.linkedin.com/in/alanmcsherry/ "LinkedIn")
- ![](img/2016-12-10-introducing-the-grothendieck-team.006.png)[](https://github.com/mcsherrylabs "GitHub")

![Introducing The Grothendieck Team](img/2016-12-10-introducing-the-grothendieck-team.007.jpeg)
## [**The Grothendieck Team**](tmp//en/projects/ethereum-classic/#team)
Hi everyone, it's my pleasure to officially announce the new team known as The Grothendieck Team! The team has been named after Alexander Grothendieck, a German-born French mathematician who became a leading figure in the creation of modern algebraic geometry. They have been committed to Ethereum Classic by [IOHK](tmp//en/) in order to build a Scala client for ETC based on IOHK's [Scorex framework](tmp//en/projects/scorex/). Plans are in place to bring the team on "Let's Talk ETC!" to discuss the roadmap and development timeframe for ETC in 2017 (after they have properly reviewed the ETC documentation). Links to the IOHK website, Scorex page, Let's Talk ETC! youtube channel and ETC blog are posted below.

Xin chào mọi người, tôi rất vui khi chính thức công bố đội mới được gọi là Đội Grothendieck!
Nhóm nghiên cứu đã được đặt theo tên của Alexander Grothendieck, một nhà toán học người Pháp gốc Đức, người đã trở thành một nhân vật hàng đầu trong việc tạo ra hình học đại số hiện đại.
Họ đã cam kết với Ethereum Classic bởi [IOHK] (TMP // EN/) để xây dựng một ứng dụng khách scala cho ETC dựa trên [framework của IOHK] (TMP // EN/Project/scorx/).
Các kế hoạch được đưa ra để đưa nhóm vào "Hãy nói chuyện, v.v."
để thảo luận về lộ trình và thời gian phát triển cho ETC vào năm 2017 (sau khi họ đã xem xét đúng tài liệu ETC).
Liên kết đến trang web IOHK, trang SCORX, hãy nói chuyện, v.v.!
Kênh YouTube và blog ETC được đăng dưới đây.

- [www.iohk.io](tmp/www.iohk.io)

- [www.iohk.io] (TMP/www.iohk.io)

- [Github.com/ScorexFoundation](tmp//en/projects/scorex/)

- [github.com/scorexfoundation West(tmp//en/projects/scorex/)

- [Let's Talk ETC! on youtube.com](https://www.youtube.com/channel/UCojbn_iTgg4BxcSphz0MGMg)

- [Hãy nói chuyện, v.v.!
trên youtube.com] (https://www.youtube.com/channel/ucojbn_itgg4bxcsphz0mgmg)

- [Ethereumclassic.github.io/blog](https://ethereumclassic.github.io/blog/2016-07-27-getting-things-done/)

-[EthereumClassic.github.io/bloggh(https://ethereumClassic.github.io/blog/2016-07-27-nging-things-done/)

Also, we would love to know more about how the community would like to get updates from the new ETC developers. Please let us know what you might like to see moving forward, post your thoughts in the brainstorming thread below or contact us on Slack, Twitter or Facebook.

Ngoài ra, chúng tôi rất muốn biết thêm về cách cộng đồng muốn nhận được cập nhật từ các nhà phát triển mới.
Vui lòng cho chúng tôi biết những gì bạn có thể muốn thấy tiến về phía trước, đăng suy nghĩ của bạn trong chủ đề động não bên dưới hoặc liên hệ với chúng tôi trên Slack, Twitter hoặc Facebook.

- [www.reddit.com](https://www.reddit.com/r/EthereumClassic/comments/5gpf3n/community_brainstorm_ideas_for_continuous/)

-]

## [**Alan McSherry : Dublin, Ireland](tmp//en/team/alan-mcsherry/) **![enter image description here](img/2016-12-10-introducing-the-grothendieck-team.008.png)**

Ethereum Classic Developer Team Grothendieck Manager

Nhà phát triển cổ điển Ethereum Đội ngũ Grothendieck Manager

Alan McSherry graduated with a degree in Computer Engineering from Limerick University In Ireland and has spent well over a decade at the cutting edge of technology as a developer, CTO, consultant, entrepreneur and everything in between. A strong interest in the nature of money and the positive disruption technology can bring means he is currently having a ball writing blockchain code in scala!

Alan McSherry tốt nghiệp với bằng kỹ sư máy tính tại Đại học Limerick ở Ireland và đã dành nhiều thập kỷ ở mức độ tiên tiến của công nghệ với tư cách là nhà phát triển, CTO, nhà tư vấn, doanh nhân và mọi thứ ở giữa.
Một mối quan tâm mạnh mẽ đến bản chất của tiền và công nghệ gián đoạn tích cực có thể mang lại có nghĩa là anh ta hiện đang có một quả bóng viết mã blockchain trong scala!

## [**Alan Verbner : Buenos Aires, Argentina](tmp//en/team/alan-verbner/) **![enter image description here](img/2016-12-10-introducing-the-grothendieck-team.008.png)**

Ethereum Classic Developer Team Grothendieck/Atix

Nhà phát triển cổ điển Ethereum Grothendieck/Atix

Alan Verbner is a computer engineer graduated from the Engineering University of Buenos Aires (Argentina). He has been developing software for about 10 years with special inerest in criptocurrency space. Four years ago he Co-Founded Atixlabs, a software lab that has been helping other companies to make their ideas come true as great high quality products. They are located in the Buenos Aires Bitcoin Embassy.

Alan Verbner là một kỹ sư máy tính tốt nghiệp Đại học Kỹ thuật Buenos Aires (Argentina).
Anh ấy đã phát triển phần mềm trong khoảng 10 năm với không gian đặc biệt nhất trong không gian criptocurrency.
Bốn năm trước, anh đồng sáng lập Atixlabs, một phòng thí nghiệm phần mềm đã giúp các công ty khác biến ý tưởng của họ thành hiện thực như những sản phẩm chất lượng cao tuyệt vời.
Họ được đặt tại Đại sứ quán Bitcoin Buenos Aires.

## [**Nicolas Tallar : Buenos Aires, Argentina](tmp//en/team/nicolas-tallar/) **![enter image description here](img/2016-12-10-introducing-the-grothendieck-team.008.png)**

Ethereum Classic Developer Team Grothendieck/Atix

Nhà phát triển cổ điển Ethereum Grothendieck/Atix

Nicolas Tallar has a background on Computer Science and he is about to get his degree from University Of Buenos Aires (Argentina). He is a passionate functional programmer with special interest in image processing and robot controlling algorithms.

Nicolas Tallar có một nền tảng về khoa học máy tính và anh sắp lấy bằng từ Đại học Buenos Aires (Argentina).
Ông là một lập trình viên chức năng đam mê với sự quan tâm đặc biệt trong việc xử lý hình ảnh và các thuật toán kiểm soát robot.

## [**Jan Ziniewicz : Warsaw, Poland](tmp//en/team/jan-ziniewicz/) **![enter image description here](img/2016-12-10-introducing-the-grothendieck-team.008.png)**

Ethereum Classic Developer Team Grothendieck

Nhà phát triển cổ điển Ethereum Grothendieck

Iâ€™ve been working in IT industry since 2004. Apart from being a functional programmer I also was a project manager, system designer and administrator. In free time I am rock climber, cyclist, RPG player, and of course Clojure / Scala coder.

Tôi đã làm việc trong ngành CNTT từ năm 2004. Ngoài việc trở thành một lập trình viên chức năng, tôi còn là người quản lý dự án, nhà thiết kế hệ thống và quản trị viên.
Trong thời gian rảnh, tôi là Rock Climber, người đi xe đạp, người chơi RPG, và tất nhiên là Clojure / Scala Coder.

## [**Lukasz Gasior : Rumia, Poland](tmp//en/team/lukasz-gasior/) **![enter image description here](img/2016-12-10-introducing-the-grothendieck-team.008.png)**

Ethereum Classic Developer Team Grothendieck/ScalaC

Nhà phát triển cổ điển Ethereum Grothendieck/Scalac

Iâ€™m a passionate Scala developer and a big fan of Domain Driven Design. For the past 3 years Iâ€™ve been working on various sized commercial (and non-commercial) Scala projects. Iâ€™m a cryptocurrency and blockchain technology enthusiast. Privately I like to travel and taste craft beer.

Tôi là một nhà phát triển Scala đam mê và là một fan hâm mộ lớn của thiết kế điều khiển miền.
Trong 3 năm qua, tôi đã làm việc trên các dự án Scala thương mại (và phi thương mại) khác nhau.
Tôi là một người đam mê công nghệ tiền điện tử và blockchain.
Riêng tôi thích đi du lịch và nếm thử bia thủ công.

## [**Adam Smolarek : Warsaw, Poland**](tmp//en/team/adam-smolarek/)

## [** Adam Smolarek: Warsaw, Ba Lan **] (TMP // EN/Team/Adam-Smolarek/)

Ethereum Classic Developer Team Grothendieck/ScalaC

Nhà phát triển cổ điển Ethereum Grothendieck/Scalac

Iâ€™ve been working as software developer since 2010, both fornt and back-end, I was also team leader and arhitect. Hobby: digital drawing, rock climbing, skateboarding, IoT (did master thesis in realated topic), cryptography (ECC).

Tôi đã làm việc với tư cách là nhà phát triển phần mềm từ năm 2010, cả Fornt và Back-End, tôi cũng là trưởng nhóm và Arhitect.
Sở thích: Vẽ kỹ thuật số, leo núi, trượt ván, IoT (đã làm luận án thạc sĩ trong chủ đề thực tế), mật mã (ECC).

## [**Radek Tkaczyk : Warsaw, Poland](tmp//en/team/radek-tkaczyk/) **![enter image description here](img/2016-12-10-introducing-the-grothendieck-team.008.png)**

Ethereum Classic Developer Team Grothendieck/ScalaC

Nhà phát triển cổ điển Ethereum Grothendieck/Scalac

Iâ€™ve been developing in Scala since 2012 for a number of commercial clients. Having started my adventure with programming at the age of 13 this was a natural choice of a career path. However Iâ€™ve always had a fondness for abstract and pure ideas which is why Iâ€™m especially keen on working in a field so heavily reliant on mathematics. Outside of work I actively enjoy various sports, especially cycling and fitness as well as those for the mind like chess and - my latest passion - cue sports.

Tôi đã phát triển ở Scala từ năm 2012 cho một số khách hàng thương mại.
Sau khi bắt đầu cuộc phiêu lưu của tôi với lập trình ở tuổi 13, đây là một lựa chọn tự nhiên của con đường sự nghiệp.
Tuy nhiên, tôi luôn luôn thích những ý tưởng trừu tượng và thuần túy, đó là lý do tại sao tôi đặc biệt quan tâm đến việc làm việc trong một lĩnh vực rất phụ thuộc vào toán học.
Ngoài công việc, tôi chủ động thích các môn thể thao khác nhau, đặc biệt là đạp xe và thể dục cũng như những người cho tâm trí như cờ vua và - niềm đam mê mới nhất của tôi - thể thao cue.

## **Links To Our Community**

## ** Liên kết đến cộng đồng của chúng tôi **

[ETC Website](https://ethereumclassic.github.io/)

[ETC trang web] (https://ethereumClassic.github.io/)

[ETC Reddit](https://www.reddit.com/r/EthereumClassic/)

[Vv Reddit] (https://www.reddit.com/r/ethereumClassic/)

[ETC Twitter](http://twitter.com/eth_classic)

[ETC Twitter] (http://twitter.com/eth_classic)

[ETC Facebook](https://www.facebook.com/EthereumClassicETC/)

[ETC Facebook] (https://www.facebook.com/EthereumClassicetc/)

[ETC Slack](https://ethereumclassic.herokuapp.com/)

[ETC Slack] (https://ethereumClassic.herokuapp.com/)

[ETC-IOHK Team](tmp//en/projects/ethereum-classic/)

[Nhóm ETC-IOHK] (TMP // EN/Dự án/Ethereum-Classic/)

