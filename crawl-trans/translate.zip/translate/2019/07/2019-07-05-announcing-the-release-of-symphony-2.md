# Announcing the release of Symphony 2.0
### **Experience the blockchain like never before**
![](img/2019-07-05-announcing-the-release-of-symphony-2.002.png) 5 July 2019![](img/2019-07-05-announcing-the-release-of-symphony-2.002.png)[ Scott Darby](tmp//en/blog/authors/scott-darby/page-1/)![](img/2019-07-05-announcing-the-release-of-symphony-2.003.png) 5 mins read

![Scott Darby](img/2019-07-05-announcing-the-release-of-symphony-2.004.png)[](tmp//en/blog/authors/scott-darby/page-1/)
### [**Scott Darby**](tmp//en/blog/authors/scott-darby/page-1/)
Creative Developer

Marketing & Communications

- ![](img/2019-07-05-announcing-the-release-of-symphony-2.005.png)[](mailto:scott.darby@iohk.io "Email")
- ![](img/2019-07-05-announcing-the-release-of-symphony-2.006.png)[](https://www.linkedin.com/in/scottdarbywebdesign/ "LinkedIn")
- ![](img/2019-07-05-announcing-the-release-of-symphony-2.007.png)[](https://twitter.com/_scottdarby "Twitter")
- ![](img/2019-07-05-announcing-the-release-of-symphony-2.008.png)[](https://github.com/scottdarby "GitHub")

![Announcing the release of Symphony 2.0](img/2019-07-05-announcing-the-release-of-symphony-2.009.jpeg)

The Symphony project began with a question: how do we represent blockchain technology in a way that is stimulating, entertaining, and audio-visually engaging for a wider audience, technical and non-technical. In other words, how do we explain the abstract and give form to the formless. Itâ€™s been over a year since we answered that question, and weâ€™re still working to make Symphony the most interactive and immersive blockchain experience available. What began as a way to visualize the blockchain has evolved into a way to experience the blockchain: an immersive journey accessible through your deviceâ€™s browser.

Dự án Symphony bắt đầu với một câu hỏi: Làm thế nào để chúng tôi đại diện cho công nghệ blockchain theo cách kích thích, giải trí và thu hút âm thanh cho đối tượng rộng hơn, kỹ thuật và phi kỹ thuật.
Nói cách khác, làm thế nào để chúng tôi giải thích sự trừu tượng và đưa ra hình thức cho vô hình.
Đã hơn một năm kể từ khi chúng tôi trả lời câu hỏi đó và chúng tôi vẫn đang làm việc để biến bản giao hưởng trở thành trải nghiệm blockchain tương tác và nhập vai nhất có sẵn.
Những gì bắt đầu như một cách để hình dung blockchain đã phát triển thành một cách để trải nghiệm blockchain: một hành trình nhập vai có thể truy cập thông qua trình duyệt của thiết bị của bạn.

The result is [Symphony 2.0](https://symphony.iohk.io/ "symphony.iohk.io"): a 3D explorer through which anyone can traverse the topographic history of the Bitcoin blockchain, from the first transaction to the most recent. Compared with the first version, Symphony 2.0 goes deeper in every way. It drills down into transaction data to create a live soundscape â€“ each block has its own unique audio signature â€“ using data-driven sound synthesis. It looks like this:

Kết quả là [Symphony 2.0] (https://symphony.iohk.io/ "Symphony.iohk.io"):
gần đây.
So với phiên bản đầu tiên, Symphony 2.0 đi sâu hơn về mọi mặt.
Nó diễn ra vào dữ liệu giao dịch để tạo ra một âm thanh trực tiếp-Mỗi khối có chữ ký âm thanh độc đáo của riêng mình bằng cách sử dụng tổng hợp âm thanh dựa trên dữ liệu.
Có vẻ như thế này:

### **How it Works**

### **Làm thế nào nó hoạt động**

As you can imagine, giving feeling to data isnâ€™t easy. Creating a sound for each block was how I wanted to represent the uniqueness and permanence of the blockchain: once added, a block is there forever, making that same sound, containing those same transactions.

Như bạn có thể tưởng tượng, mang lại cảm giác cho dữ liệu không dễ dàng.
Tạo một âm thanh cho mỗi khối là cách tôi muốn thể hiện tính độc đáo và tính lâu dài của blockchain: Sau khi thêm vào, một khối ở đó mãi mãi, tạo ra âm thanh đó, chứa các giao dịch tương tự.

I used a technique called additive synthesis to generate sound on the fly, and utilized the parallel nature of graphics cards to synthesize a unique sound for each of the thousands of transactions that can make up a block. The sound signature that plays when you visit a block consists of each transaction producing eight sine waves (a fundamental pitch and seven harmonics). The fundamental pitch is determined by the transaction value, and the amount of randomness added to the harmonics partials is controlled by the fee-to-value ratio of the transaction. 

Tôi đã sử dụng một kỹ thuật gọi là tổng hợp phụ gia để tạo ra âm thanh nhanh chóng và sử dụng bản chất song song của card đồ họa để tổng hợp một âm thanh độc đáo cho mỗi trong số hàng ngàn giao dịch có thể tạo ra một khối.
Chữ ký âm thanh phát khi bạn truy cập một khối bao gồm mỗi giao dịch tạo ra tám sóng hình sin (một sân cơ bản và bảy sóng hài).
Sân cơ bản được xác định bởi giá trị giao dịch và lượng ngẫu nhiên được thêm vào các phần hài hòa được kiểm soát bởi tỷ lệ phí trên giá trị của giao dịch.

![Symphony: The first block on the Bitcoin blockchain visually represented](img/2019-07-05-announcing-the-release-of-symphony-2.010.jpeg) 

**Each block is connected to the blockchain by a Merkle tree**

** Mỗi khối được kết nối với blockchain bằng cây merkle **

### **Design Philosophy**

### **Triết lý thiết kế**

With Symphony 2.0, the blockchainâ€™s mempool â€“ which stores unconfirmed transactions â€“ is visualized as a gravitational swell, around which confirmed transactions spiral in concentric rings. Think of Saturnâ€™s rings but, instead of particles of ice and rock, we have transactions, continuously adding to the size of the rings as they extend outwards. Then, undergirding each block are Merkle trees represented, unsurprisingly, as trees. 

Với Symphony 2.0, mempool của Blockchain - nơi lưu trữ các giao dịch chưa được xác nhận - được hình dung như một sự sưng tấp hấp dẫn, xung quanh đó đã xác nhận các giao dịch xoắn ốc trong các vòng đồng tâm.
Hãy nghĩ về những chiếc nhẫn của Saturn, nhưng thay vì các hạt băng và đá, chúng tôi có các giao dịch, liên tục thêm vào kích thước của các vòng khi chúng mở rộng ra ngoài.
Sau đó, trải qua mỗi khối là những cây merkle được đại diện, không có gì đáng ngạc nhiên, như cây.

![Symphony: Each block is connected to the blockchain by a Merkle tree](img/2019-07-05-announcing-the-release-of-symphony-2.011.png) 

**The most recent block on the Bitcoin blockchain**

** Khối gần đây nhất trên blockchain bitcoin **

On top of each block, confirmed transactions are visualized as 3D hexagons. Their height corresponds to the transaction volume, and their width (note the rotund individuals to the right of the image above) corresponds to the health of the block. The result is an unprecedented imagining of the blockchain, with its representative parts synced and manifest, explorable block-by-block or through a flight-simulator mode. 

Trên mỗi khối, các giao dịch được xác nhận được hiển thị dưới dạng hình lục giác 3D.
Chiều cao của chúng tương ứng với khối lượng giao dịch và chiều rộng của chúng (lưu ý các cá thể quay ở bên phải hình ảnh trên) tương ứng với sức khỏe của khối.
Kết quả là một sự tưởng tượng chưa từng có về blockchain, với các bộ phận đại diện của nó được đồng bộ hóa và rõ ràng, từng khối hoặc thông qua chế độ mô phỏng chuyến bay.

### **Ways to Experience Symphony**

### ** Cách để trải nghiệm Symphony **

Symphony 2.0 is now [live](https://symphony.iohk.io/ "symphony.iohk.io"). It can be accessed using any modern web browser, but is best experienced in Google Chrome. For laptop and mobile device users, itâ€™s advised to select the Medium quality option and, for those with high-performance devices or dedicated graphics support, the High quality option. Performance optimizations will continue into the future.

Symphony 2.0 hiện là [Live] (https://symphony.iohk.io/ "Symphony.iohk.io").
Nó có thể được truy cập bằng cách sử dụng bất kỳ trình duyệt web hiện đại nào, nhưng được trải nghiệm tốt nhất trong Google Chrome.
Đối với người dùng máy tính xách tay và thiết bị di động, bạn nên chọn tùy chọn chất lượng trung bình và, đối với những người có thiết bị hiệu suất cao hoặc hỗ trợ đồ họa chuyên dụng, tùy chọn chất lượng cao.
Tối ưu hóa hiệu suất sẽ tiếp tục trong tương lai.

Together with our friends at Kuva, a Bristol-based creative agency, weâ€™ve also grown the project to include events and exhibition pieces. These events â€“ one of which was held [this year in Bristol](tmp//en/blog/symphony-of-blockchains-project-comes-to-bristol/ "IOHK Blog: The Symphony of Blockchains project comes to Bristol") â€“ have included a number of exhibitions that showcase different parts of the project, including virtual reality (VR) and augmented reality (AR).

Cùng với bạn bè của chúng tôi tại Kuva, một cơ quan sáng tạo có trụ sở tại Bristol, chúng tôi cũng đã phát triển dự án để bao gồm các sự kiện và các tác phẩm triển lãm.
Những sự kiện này-một trong số đó được tổ chức [năm nay tại Bristol] (TMP // EN/Blog/Symphony-of-Blockchains-Project-Comes-to Bristol/"IOHK Blog: Dự án Symphony of Blockchains đến Bristol
")" Đã bao gồm một số triển lãm giới thiệu các phần khác nhau của dự án, bao gồm thực tế ảo (VR) và thực tế tăng cường (AR).

Using WebVR software, I built a VR experience based on the code for Symphony 2.0, which demonstrates the extensibility of the system. This will be exhibited at future events and, I hope, one day available for VR headsets at home. 

Sử dụng phần mềm WebVR, tôi đã xây dựng trải nghiệm VR dựa trên mã cho Symphony 2.0, cho thấy khả năng mở rộng của hệ thống.
Điều này sẽ được trưng bày tại các sự kiện trong tương lai và, tôi hy vọng, một ngày có sẵn cho tai nghe VR tại nhà.

### **Whatâ€™s Next**

### ** tiếp theo là gì **

Weâ€™re going on tour. We have the story, and now we need an audience. Iâ€™m also starting to build an Ethereum version using the same code base, which will feature explorable smart contracts, and, after that, Cardano. We know there are thousands of people out there who are only faintly familiar with blockchain technology and want to know more â€“ and with Symphony 2.0, theyâ€™ll be able to cut through the confusion. A picture tells a thousand words, and an interactive audio-visual experience tells many more.

Chúng tôi sẽ đi tour.
Chúng tôi có câu chuyện, và bây giờ chúng tôi cần một khán giả.
Tôi cũng bắt đầu xây dựng một phiên bản Ethereum bằng cách sử dụng cùng một cơ sở mã, sẽ có các hợp đồng thông minh đáng chú ý, và sau đó, Cardano.
Chúng tôi biết có hàng ngàn người ngoài kia chỉ quen thuộc với công nghệ blockchain và muốn biết nhiều hơn và với Symphony 2.0, họ sẽ có thể vượt qua sự nhầm lẫn.
Một bức tranh cho biết một ngàn từ, và một trải nghiệm nghe nhìn tương tác cho biết nhiều hơn nữa.

Symphony is a long-term project. Itâ€™s as much an adventure for us as our audience. We want to see how far we can take it â€“ because blockchain technology is still developing, still growing, and the opportunity for education is only just beginning. The release of Symphony 2.0 marks a significant milestone for us, and weâ€™re thrilled to be sharing it with you. Thereâ€™s a lot of opportunity for Symphony, from optimizations and incorporation of other blockchains, to events and more ways to enjoy Symphony at home. So, stay tuned for more updates and, in the meantime, enjoy the worldâ€™s first interactive blockchain experience.

Symphony là một dự án dài hạn.
Đó là một cuộc phiêu lưu đối với chúng tôi nhiều như khán giả của chúng tôi.
Chúng tôi muốn xem chúng tôi có thể đưa nó đi bao xa - vì công nghệ blockchain vẫn đang phát triển, vẫn đang phát triển và cơ hội giáo dục chỉ mới bắt đầu.
Việc phát hành Symphony 2.0 đánh dấu một cột mốc quan trọng đối với chúng tôi và chúng tôi rất vui mừng được chia sẻ nó với bạn.
Có rất nhiều cơ hội cho Symphony, từ tối ưu hóa và kết hợp các blockchain khác, đến các sự kiện và nhiều cách hơn để tận hưởng bản giao hưởng tại nhà.
Vì vậy, hãy theo dõi để cập nhật thêm và, trong khi đó, hãy tận hưởng trải nghiệm blockchain tương tác đầu tiên của thế giới.

[Experience Symphony 2.0](https://symphony.iohk.io/ "symphony.iohk.io")

[Kinh nghiệm Symphony 2.0] (https://symphony.iohk.io/ "Symphony.iohk.io")

