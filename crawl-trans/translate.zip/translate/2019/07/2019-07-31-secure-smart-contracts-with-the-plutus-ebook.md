# Secure smart contracts with the Plutus ebook
### **Q&A with the IOHK Education team authors**
![](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.002.png) 31 July 2019![](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.002.png)[ Alejandro Garcia](tmp//en/blog/authors/alejandro-garcia/page-1/)![](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.003.png) 6 mins read

![Alejandro Garcia](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.004.png)[](tmp//en/blog/authors/alejandro-garcia/page-1/)
### [**Alejandro Garcia**](tmp//en/blog/authors/alejandro-garcia/page-1/)
Project Manager

Project Management

- ![](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.005.png)[](mailto:alejandro.garcia@iohk.io "Email")
- ![](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.006.png)[](https://www.linkedin.com/in/elviejo79 "LinkedIn")
- ![](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.007.png)[](https://twitter.com/agarciafdz "Twitter")
- ![](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.008.png)[](https://github.com/elviejo79 "GitHub")

![Secure smart contracts with the Plutus ebook](img/2019-07-31-secure-smart-contracts-with-the-plutus-ebook.009.jpeg)

The IOHK education team this month released the first edition ofÂ their new Plutus ebook:Â *Plutus: Writing reliable smart contracts*. Available on [Amazon](https://www.amazon.com/Plutus-Writing-reliable-smart-contracts-ebook/dp/B07V46LWTW/ref=sr_1_1)Â andÂ [LeanPub](https://leanpub.com/plutus-smart-contracts), it's a comprehensive introductory guide toÂ [Plutus](https://testnet.iohkdev.io/plutus/),Â IOHK's Haskell-based smart contract language. Haskell is a functional programming language, which means it's easier to test and less prone to human error, so anything written in Haskell -- and by extension Plutus -- is more likely to be reliable and secure. Plutus can also be used for both on and off-chain code, simplifying the development experience and eliminating errors commonly introduced in the transition between languages on and off-chain.

Nhóm giáo dục IOHK trong tháng này đã phát hành phiên bản đầu tiên của Sách điện tử Plutus mới của họ: Â*Plutus: Viết hợp đồng thông minh đáng tin cậy*.
Có sẵn trên [Amazon] (https://www.amazon.com/plutus-writing-relleble-smart-contracts-osbook/dp/b07v46lwtw/ref=sr_1_1) â vàâ [leanpub] (https://leanpub.com
Các hợp đồng của Plutus-Smart), đó là một hướng dẫn giới thiệu toàn diện về [Plutus] (https://testnet.iohkdev.io/plutus/), ngôn ngữ hợp đồng thông minh dựa trên Haskell của IOHK.
Haskell là ngôn ngữ lập trình chức năng, có nghĩa là dễ kiểm tra hơn và ít dễ bị lỗi của con người, vì vậy bất cứ điều gì được viết bằng Haskell - và bằng cách mở rộng Plutus - có nhiều khả năng đáng tin cậy và an toàn hơn.
Plutus cũng có thể được sử dụng cho cả mã Bật và ngoài chuỗi, đơn giản hóa trải nghiệm phát triển và loại bỏ các lỗi thường được đưa ra trong quá trình chuyển đổi giữa các ngôn ngữ trên và ngoài chuỗi.

The new Plutus ebook covers everything from how smart contracts interact with the blockchain down to working code examples with line-by-line explanations.Â IÂ spoke to Lars BrÃ¼njes and Polina Vinogradova, the main authors of the book, for more details about the book and the future plans of the education team.

Sách điện tử Plutus mới bao gồm tất cả mọi thứ, từ cách các hợp đồng thông minh tương tác với blockchain xuống các ví dụ về mã làm việc với các giải thích theo từng dòng.
và các kế hoạch tương lai của nhóm giáo dục.

### **Please introduce yourselves!**

### ** Vui lòng giới thiệu chính mình! **

**Lars**:Â I am the director of education at IOHK, which means I run all our educational activities, such as Haskell courses, community videos, workshops, hackathons, books, and internal training. It's a deeply rewarding role: education is an extremely important part of our mission to bring financial services to the three billion people who don't have them. Teaching Haskell to bright young women in Ethiopia and running a Marlowe workshop in Mongolia have been unforgettable experiences for me, and I feel like I'm making a difference.Â Â Â Â Â Â Â Â 

** Lars **: Tôi là Giám đốc Giáo dục tại IOHK, có nghĩa là tôi điều hành tất cả các hoạt động giáo dục của chúng tôi, chẳng hạn như các khóa học Haskell, video cộng đồng, hội thảo, hackathons, sách và đào tạo nội bộ.
Đó là một vai trò bổ ích sâu sắc: Giáo dục là một phần cực kỳ quan trọng trong sứ mệnh của chúng tôi để mang lại các dịch vụ tài chính cho ba tỷ người không có chúng.
Dạy Haskell cho những phụ nữ trẻ tươi sáng ở Ethiopia và điều hành một hội thảo Marlowe ở Mông Cổ đã là những trải nghiệm khó quên đối với tôi, và tôi cảm thấy như mình đang tạo ra sự khác biệt.

**Polina**:Â I'm a formal methods software developer at IOHK. I've worked on the formalÂ specificationsÂ of the Cardano ledger and the wallet, but I've been doing a lot of education things recently as well. I wasÂ theÂ teaching assistant for the Haskell course in Ethiopia, and I'm looking forward to being part of other initiatives. IOHK takes education very seriously, and I've personally reaped the benefits of that when taking internal training courses this year -- I learned a lot about testing and formal specification, and could immediately apply it to my work.

** Polina **: Tôi là nhà phát triển phần mềm phương pháp chính thức tại IOHK.
Tôi đã làm việc trên các thông số kỹ thuật chính thức của sổ cái Cardano và ví, nhưng gần đây tôi cũng đã làm rất nhiều việc giáo dục.
Tôi là trợ lý giảng dạy cho khóa học Haskell ở Ethiopia, và tôi mong muốn trở thành một phần của các sáng kiến khác.
IOHK rất coi trọng việc giáo dục và cá nhân tôi đã gặt hái được những lợi ích của việc đó khi tham gia các khóa đào tạo nội bộ trong năm nay - tôi đã học được rất nhiều về thử nghiệm và đặc điểm kỹ thuật chính thức, và có thể ngay lập tức áp dụng nó vào công việc của tôi.

### **What have you been up to recently?**

### **Những gì bạn có được lên đến gần đây?**

**Polina**:Â As the co-instructor on theÂ [Haskell course in Ethiopia](https://iohk.io/blog/in-at-the-deep-end-in-addis/), I wrote and delivered several of the lectures. It was a unique experience, and it felt like I was really helping people to change their lives. After that, I took an IOHK internal training course and taught on Marlowe workshops in Mongolia and Israel. I've been writing the Plutus ebook with Lars as well. Last year, I worked on formal methods tasks, the Shelley ledger and the wallet, but because of all the traveling and writing, I haven't had much time to work on those this year.

** Polina **: Â như người đồng nghiệp trên khóa học [Haskell ở Ethiopia] (https://iohk.io/blog/in-at-the--wee-end-in-addis/), tôi đã viết và
Đã đưa ra một số bài giảng.
Đó là một trải nghiệm độc đáo, và cảm giác như tôi thực sự giúp mọi người thay đổi cuộc sống của họ.
Sau đó, tôi đã tham gia một khóa đào tạo nội bộ IOHK và giảng dạy trong các hội thảo của Marlowe ở Mông Cổ và Israel.
Tôi cũng đã viết Sách điện tử Plutus với Lars.
Năm ngoái, tôi đã làm việc về các nhiệm vụ phương pháp chính thức, The Shelley Ledger và The Wallet, nhưng vì tất cả các chuyến đi và viết lách, tôi không có nhiều thời gian để làm việc với những người trong năm nay.

**Lars**:Â I've helped set up theÂ [three-month Haskell course](https://iohk.io/blog/training-blockchain-developers-in-africa/)Â for Ethiopian and Ugandan women in Addis Ababa, run a Marlowe workshop in Ulaanbaatar, Mongolia (and rode a camel and fell off a horse in the process) and anotherÂ [workshop in Tel Aviv](https://iohk.io/blog/iohk-smart-contract-hackathon-and-meetup-in-tel-aviv/), Israel. I've been working on the ebook with Polina, as well as developing IOHK's education strategy and working on our incentives research stream, writing Haskell simulations to illustrate and support our theoretical results.

** Lars **: Â Tôi đã giúp thiết lập [khóa học ba tháng Haskell] (https://iohk.io/blog/training-lockchain-developers-in-africa/) Â dành cho phụ nữ Ethiopia và Ugandan ở
Addis Ababa, điều hành một hội thảo Marlowe ở Ulaanbaatar, Mông Cổ (và cưỡi một con lạc đà và rơi ra khỏi một con ngựa trong quá trình này) và một
Hackathon-and-beetup-in-Tel-aviv/), Israel.
Tôi đã làm việc trên Sách điện tử với Polina, cũng như phát triển chiến lược giáo dục của IOHK và làm việc trên luồng nghiên cứu ưu đãi của chúng tôi, viết mô phỏng Haskell để minh họa và hỗ trợ kết quả lý thuyết của chúng tôi.

### **What was the inspiration for the ebook?**

### ** Cảm hứng cho ebook là gì? **

**Lars**:Â The idea was to make it easier for people interested in writing high-assurance smart contracts to get started with Plutus. We tried to strike a balance between theory and practice, between background information and working code examples, to give interested readers the foundations to get started quickly. At IOHK we already know Plutus is great and we hope the book will help convince everyone else!

** Lars **: Â Ý tưởng là giúp những người quan tâm đến việc viết các hợp đồng thông minh bảo đảm cao hơn để bắt đầu với Plutus.
Chúng tôi đã cố gắng đạt được sự cân bằng giữa lý thuyết và thực tiễn, giữa thông tin cơ bản và các ví dụ mã làm việc, để cung cấp cho độc giả quan tâm các nền tảng để bắt đầu nhanh chóng.
Tại IOHK, chúng tôi đã biết Plutus là tuyệt vời và chúng tôi hy vọng cuốn sách sẽ giúp thuyết phục mọi người khác!

**Polina**:Â Besides a comprehensive step-by-step explanation of how to write Plutus smart contracts, the book also provides an overview of how accounting works in Cardano, what the benefits, goals, and challenges of smart contracts are, and where smart contracts fit into the Cardano architecture. We wrote -- and will be continuously improving and maintaining -- this book to give readers the tools not only to write the contracts but to come up with creative ways of using them.

** Polina **: Â Bên cạnh một lời giải thích từng bước toàn diện về cách viết hợp đồng thông minh Plutus, cuốn sách cũng cung cấp một cái nhìn tổng quan về cách thức hoạt động của Cardano, lợi ích, mục tiêu và thách thức của hợp đồng thông minh là gì,
và nơi hợp đồng thông minh phù hợp với kiến trúc Cardano.
Chúng tôi đã viết - và sẽ liên tục cải thiện và duy trì - cuốn sách này để cung cấp cho độc giả các công cụ không chỉ để viết các hợp đồng mà còn đưa ra những cách sáng tạo để sử dụng chúng.

### **Who is the ebook for and what will they learn from it?**

### ** Ai là ebook cho và họ sẽ học được gì từ nó? **

**Lars**:Â The book is aimed at software developers generally and smart contract developers in particular. Plutus is basically Haskell, so familiarity with Haskell or a willingness to learn the language is important. Plutus has been created as a safer and more secure way of creating smart contracts. So everybody dreaming of writing correct and reliable smart contracts is definitely in the target audience and should have a look at Plutus!

** Lars **: Â Sách nhắm vào các nhà phát triển phần mềm nói chung và các nhà phát triển hợp đồng thông minh nói riêng.
Plutus về cơ bản là Haskell, rất quen thuộc với Haskell hoặc sẵn sàng học ngôn ngữ là quan trọng.
Plutus đã được tạo ra như một cách tạo hợp đồng thông minh an toàn và an toàn hơn.
Vì vậy, mọi người mơ ước viết các hợp đồng thông minh chính xác và đáng tin cậy chắc chắn là trong đối tượng mục tiêu và nên có một cái nhìn về Plutus!

**Polina**:Â This is not just a book for developers with Haskell experience. It's also a good read for anyone interested in alternatives to relying on third parties, such as banks or the legal system, to make sure a contract is being adhered to. Plutus offers such an alternative, where trust is instead placed on high assurance, tested and documented code. If this sounds too good to be true, check out the details in the book!

** Polina **: Đây không chỉ là một cuốn sách dành cho các nhà phát triển có kinh nghiệm Haskell.
Đây cũng là một bài đọc tốt cho bất kỳ ai quan tâm đến các lựa chọn thay thế để dựa vào các bên thứ ba, chẳng hạn như các ngân hàng hoặc hệ thống pháp lý, để đảm bảo một hợp đồng đang được tuân thủ.
Plutus cung cấp một giải pháp thay thế như vậy, trong đó sự tin tưởng thay vào đó được đặt vào mã đảm bảo cao, mã được kiểm tra và ghi lại.
Nếu điều này nghe quá tốt để trở thành sự thật, hãy xem các chi tiết trong cuốn sách!

### **What is your favorite part of the ebook?**

### ** Phần yêu thích của bạn trong ebook là gì? **

**Lars**:Â Hard to say -- I think the best aspect is the balance betweenÂ the book'sÂ parts: theory and foundations on the one hand, easy-to-follow code examples on the other.

** Lars **: Kh khó để nói-Tôi nghĩ khía cạnh tốt nhất là sự cân bằng giữa các phần của cuốn sách: lý thuyết và nền tảng một mặt, mặt khác là các ví dụ về mã dễ thực hiện.

**Polina**:Â I would have to agree about the balance: the book includes both high-level explanations of how smart contracts work on the blockchain, as well as concrete examples of how to develop the code, with explanations at each line.

** Polina **: Tôi sẽ phải đồng ý về số dư: Cuốn sách bao gồm cả hai giải thích cấp cao về cách hợp đồng thông minh hoạt động trên blockchain, cũng như các ví dụ cụ thể về cách phát triển mã, với các giải thích ở mỗi dòng
.

### **What's the next step for someone who's read the ebook?**

### ** Bước tiếp theo cho ai đó đọc ebook là gì? **

**Polina**:Â I would suggest that if the reader feels confident about their Plutus skills, they need to think big -- what problem could this technology be used to solve? Perhaps there is some new functionality they wish was available as part of the Cardano system, and they could work on that? For example, the book mentions two Plutus use cases: introducing special kinds of (non-fungible) tokens onto the blockchain, and a custom policy for signing off on spending -- ideas like these.

** Polina **: Tôi sẽ đề nghị rằng nếu người đọc cảm thấy tự tin về các kỹ năng Sao Diêm Vương của họ, họ cần phải suy nghĩ lớn - công nghệ này có thể được sử dụng để giải quyết vấn đề gì?
Có lẽ có một số chức năng mới mà họ muốn có sẵn như là một phần của hệ thống Cardano và họ có thể làm việc đó?
Ví dụ, cuốn sách đề cập đến hai trường hợp sử dụng Sao Diêm Vương: Giới thiệu các loại mã thông báo đặc biệt (không phải là fun) vào blockchain và chính sách tùy chỉnh để đăng nhập vào chi tiêu-những ý tưởng như thế này.

**Lars**:Â I firmly believe that to learn something you have to actually use it and -- ideally -- teach it. So the next step should be to use Plutus, to work on an exciting project and implement a couple of smart contracts yourself. Then go one step further and try to explain Plutus to others, at a meetup, for example.

** Lars **: Tôi tin chắc rằng để học một cái gì đó bạn phải thực sự sử dụng nó và - lý tưởng - dạy nó.
Vì vậy, bước tiếp theo là sử dụng Plutus, để làm việc trong một dự án thú vị và tự mình thực hiện một vài hợp đồng thông minh.
Sau đó, tiến thêm một bước và cố gắng giải thích Sao Diêm Vương cho người khác, ví dụ như tại một cuộc gặp gỡ.

### **What other education initiatives are going on at IOHK?**

### ** Những sáng kiến giáo dục khác đang diễn ra tại IOHK? **

**Lars** and **Polina**:Â We are preparing the next Plutus and Marlowe workshops, as well as the next Haskell course and working on turning that into a MOOC. We're already thinking about the next book, and how to expand our department to be able to deliver more educational content worldwide.

** Lars ** và ** Polina **: Â Chúng tôi đang chuẩn bị các hội thảo Plutus và Marlowe tiếp theo, cũng như khóa học Haskell tiếp theo và làm việc để biến nó thành MOOC.
Chúng tôi đã suy nghĩ về cuốn sách tiếp theo và làm thế nào để mở rộng bộ phận của chúng tôi để có thể cung cấp nhiều nội dung giáo dục hơn trên toàn thế giới.

