# Kuva symphony update: more events and a 3D blockchain transaction tracker
### **Kuva discusses Symphony project updates**
![](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.002.png) 16 July 2019![](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.002.png)[ Helen Broadbridge](tmp//en/blog/authors/helen-broadbridge/page-1/)![](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.003.png) 5 mins read

![Helen Broadbridge](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.004.png)[](tmp//en/blog/authors/helen-broadbridge/page-1/)
### [**Helen Broadbridge**](tmp//en/blog/authors/helen-broadbridge/page-1/)
Producer

Kuva

- ![](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.005.png)[](https://www.linkedin.com/in/helen-suzanne-white/ "LinkedIn")
- ![](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.006.png)[](https://twitter.com/helendoes "Twitter")
- ![](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.007.png)[](https://github.com/wearekuva "GitHub")

![Kuva symphony update: more events and a 3D blockchain transaction tracker](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.008.jpeg)

Symphony is an experience unlike any other. Weâ€™ve [talked about it as an interactive, audio-visual exploration of the Bitcoin blockchain](tmp//en/blog/symphony-of-blockchains/ "Symphony blog post, iohk.io/blog/symphony-of-blockchains"), but itâ€™s becoming much more. Not just because weâ€™re not stopping with Bitcoin â€“ soon, Ethereum, then any blockchain thereafter â€“ but because weâ€™re continually optimizing and upgrading the experience, allowing the user to dive deeper into the blockchain through mixed-reality encounters. Part of what we wanted to create is a better way to absorb information. People arenâ€™t sponges. Abstract concepts donâ€™t always stick, and unfamiliarity breaks the narrative thread we need to engage with an idea. But when we can create that experience visually, interactively, weâ€™re able to ground the abstract into an unforgettable experience that is, ultimately, fun: a living story. 

Symphony là một kinh nghiệm không giống như bất kỳ khác.
Chúng tôi đã nói về nó như là một cuộc thăm dò tương tác, nghe nhìn của blockchain bitcoin] (tmp // en/blog/symphony-of-blockchain
Blockchains "), nhưng nó trở nên nhiều hơn nữa.
Không chỉ bởi vì chúng tôi không dừng lại với Bitcoin- sớm, Ethereum, sau đó bất kỳ blockchain nào sau đó- mà vì chúng tôi liên tục tối ưu hóa và nâng cấp trải nghiệm, cho phép người dùng đi sâu hơn vào blockchain thông qua hỗn hợp-
Cuộc gặp gỡ thực tế.
Một phần của những gì chúng tôi muốn tạo là một cách tốt hơn để tiếp thu thông tin.
Mọi người không phải là bọt biển.
Các khái niệm trừu tượng không luôn luôn gắn bó, và sự không quen thuộc phá vỡ chủ đề tường thuật mà chúng ta cần tham gia với một ý tưởng.
Nhưng khi chúng ta có thể tạo ra trải nghiệm đó một cách trực quan, một cách tương tác, chúng ta sẽ có thể tạo nên sự trừu tượng vào một trải nghiệm khó quên, cuối cùng, là một câu chuyện sống: một câu chuyện sống.

## **About Kuva**

## ** Giới thiệu về Kuva **

Kuva is an interactive design and creative technology studio based in Bristol, UK. Weâ€™re a collection of artists, technologists, and engineers working with companies to blend art and technology into online and physical experiences. Weâ€™ve worked with IOHK on Symphony since the launch of the award-winning Symphony website in January 2018. 

KUVA là một studio thiết kế tương tác và công nghệ sáng tạo có trụ sở tại Bristol, UK.
Chúng tôi là một bộ sưu tập các nghệ sĩ, công nghệ và kỹ sư làm việc với các công ty để kết hợp nghệ thuật và công nghệ vào các trải nghiệm trực tuyến và thể chất.
Chúng tôi đã làm việc với IOHK trên Symphony kể từ khi ra mắt trang web Giao hưởng đã giành giải thưởng vào tháng 1 năm 2018.

Our [first gallery installation for Symphony](tmp//en/blog/symphony-of-blockchains-project-comes-to-bristol/ "Symphony event, iohk.io/blog/symphony-of-blockchains-project-comes-to-bristol") was this year, in April, at the Arnolfini in Bristol and, soon after, we were in Miami for the IOHK summit. Since then, the teams at Kuva and IOHK have gone down slightly different paths, exploring different ways to expand the experience. You can learn more about IOHKâ€™s work in [this blog post](tmp//en/blog/announcing-the-release-of-symphony-2/ "Symphony 2.0 announcement, iohk.io/blog/announcing-the-release-of-symphony-2"). Here, Iâ€™ll go through what Kuva has been up to, and what the future holds for Symphony.

[Cài đặt phòng trưng bày đầu tiên của chúng tôi cho Symphony] (TMP // EN/Blog/Symphony-Of-Blockchains-Project-Comes-to-Bristol/"Symphony Event, iohk.io/blog/symphony-of-blockchains-Project-comes-
To-bristol ") là năm nay, vào tháng Tư, tại Arnolfini ở Bristol và ngay sau đó, chúng tôi đã ở Miami cho Hội nghị thượng đỉnh IOHK.
Kể từ đó, các đội tại Kuva và IOHK đã đi xuống những con đường hơi khác nhau, khám phá những cách khác nhau để mở rộng trải nghiệm.
Bạn có thể tìm hiểu thêm về tác phẩm của IOHK trong [Bài đăng trên blog này] (TMP // EN/Blog/Thông báo thông báo-of-Symphony-2/"Symphony 2.0, iohk.io/blog/announcing-the
-Release-of-symphony-2 ").
Ở đây, tôi sẽ trải qua những gì Kuva đã làm, và những gì tương lai nắm giữ cho Symphony.

![The Symphony art exhibition at the Arnolfini](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.009.png) 

**The Symphony art exhibition at the Arnolfini**

** Triển lãm nghệ thuật giao hưởng tại Arnolfini **

## **Project Updates**

## ** Cập nhật dự án **

We have a global tour planned for Symphony to introduce the blockchain to more people. For the most part, the blockchain is known in uncertain terms (the cryptocurrency market has led to a few erroneous perceptions, which weâ€™d love to correct). Elsewhere, itâ€™s barely known at all. If itâ€™s going to underpin the future â€“ which we believe it is â€“ then we have a responsibility to start education as soon as possible. And at Kuva, we believe the best way to educate is through experiential storytelling.

Chúng tôi có một tour du lịch toàn cầu được lên kế hoạch cho Symphony để giới thiệu blockchain cho nhiều người hơn.
Đối với hầu hết các phần, blockchain được biết đến trong các thuật ngữ không chắc chắn (thị trường tiền điện tử đã dẫn đến một vài nhận thức sai lầm, mà chúng tôi thích sửa chữa).
Ở những nơi khác, nó hầu như không được biết đến.
Nếu đó sẽ là nền tảng cho tương lai - mà chúng tôi tin rằng đó là "thì chúng tôi có trách nhiệm bắt đầu giáo dục càng sớm càng tốt.
Và tại Kuva, chúng tôi tin rằng cách tốt nhất để giáo dục là thông qua cách kể chuyện kinh nghiệm.

![Augmented reality posters are used to explain blockchain concepts](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.010.png) 

**Augmented reality posters are used to explain blockchain concepts**

** Áp phích thực tế tăng cường được sử dụng để giải thích các khái niệm blockchain **

This starts with our virtual reality (VR) and augmented reality (AR) projects. These experiences, which are demonstrated in this [video](https://www.youtube.com/watch?v=f0Pzg50QnI4/ "Symphony event video, youtube.com/watch?v=f0Pzg50QnI4"), are designed as educational pieces that use different approaches (such as our AR posters) to explain how the blockchain works. We take some of the most complex components underpinning blockchains and break them down into easy-to-digest, understandable elements. We want to show the usefulness of blockchains and, by extension, cryptocurrencies, by illustrating them in ways people can relate to. 

Điều này bắt đầu với các dự án thực tế ảo (VR) và thực tế tăng cường (AR) của chúng tôi.
Những trải nghiệm này, được thể hiện trong [video] này (https://www.youtube.com/watch?v=F0PZG50QNI4/ "Video sự kiện Symphony, YouTube.com/watch?v=F0PZG50QNI4")
sử dụng các cách tiếp cận khác nhau (như áp phích AR của chúng tôi) để giải thích cách thức hoạt động của blockchain.
Chúng tôi lấy một số thành phần phức tạp nhất làm nền tảng cho các blockchains và chia chúng thành các yếu tố dễ tiêu hóa, dễ hiểu.
Chúng tôi muốn hiển thị tính hữu ích của blockchain và, bằng cách mở rộng, tiền điện tử, bằng cách minh họa chúng theo cách mọi người có thể liên quan.

But the blockchain doesnâ€™t start and end with Bitcoin. Weâ€™re also working on bringing an Ethereum chapter to these events, to demonstrate the evolution of cryptocurrencies and the technology as a whole. Weâ€™ll be able to explain and illustrate smart contracts, and show how blockchains can be used for more than financial transactions. Then, in the future, weâ€™ll start looking at Cardano as a third-generation blockchain: how itâ€™s different, and what itâ€™s capable of achieving over others.

Nhưng blockchain không bắt đầu và kết thúc bằng bitcoin.
Chúng tôi cũng đang làm việc để đưa một chương Ethereum cho các sự kiện này, để chứng minh sự phát triển của tiền điện tử và toàn bộ công nghệ.
Chúng tôi sẽ có thể giải thích và minh họa các hợp đồng thông minh và cho thấy cách sử dụng blockchains cho nhiều hơn các giao dịch tài chính.
Sau đó, trong tương lai, chúng ta sẽ bắt đầu xem Cardano như một blockchain thế hệ thứ ba: nó khác biệt như thế nào và những gì nó có khả năng đạt được những người khác.

## **Mobile App**

## **Ứng dụng di động**

The most exciting update is about our mobile app, soon to be [available on Android](https://play.google.com/store/apps/details?id=com.Kuva.TransactionTracker&hl=en_GB/ "Symphony mobile app on Google Play store, play.google.com/store/apps/details?id=com.Kuva.TransactionTracker&hl=en_GB"), and later on iOS. This contains a data visualization of the Bitcoin mempool in 3D and augmented reality, to show you the congestion and health of the Bitcoin blockchain at any time.

Bản cập nhật thú vị nhất là về ứng dụng di động của chúng tôi, sẽ sớm được [có sẵn trên Android] (https://play.google.com/store/apps/details?id=com.kuva.transactiontracker&hl=EN_GB/ "Ứng dụng di động Symphony trên
Cửa hàng Google Play, play.google.com/store/apps/details?id=com.kuva.transactionTracker&hl=EN_GB ") và sau đó trên iOS.
Điều này chứa một hình ảnh dữ liệu của mempool bitcoin trong 3D và thực tế tăng cường, để cho bạn thấy sự tắc nghẽn và sức khỏe của blockchain bitcoin bất cứ lúc nào.

![The Symphony transaction tracker mobile app](img/2019-07-16-kuva-symphony-update-more-events-and-a-3d-blockchain-transaction-tracker.011.png) 

**The Symphony transaction tracker mobile app**

** Ứng dụng di động theo dõi giao dịch giao dịch Symphony **

Using the app, youâ€™ll be able to see whether itâ€™s a good time to send a transaction. Visually, the busier the mempool is â€“ ie, the more red lines it has swirling about it â€“ the busier the network is, which means a higher fee. The average fee is precisely detailed in the app. 

Sử dụng ứng dụng, bạn sẽ có thể xem liệu đó có phải là thời điểm tốt để gửi một giao dịch hay không.
Về mặt trực quan, các mempool càng bận rộn, IE, nó càng có nhiều dòng màu đỏ mà nó đã quay cuồng về nó - Mạng càng bận rộn, có nghĩa là một khoản phí cao hơn.
Phí trung bình được chi tiết chính xác trong ứng dụng.

Like our other VR and AR work, weâ€™ll soon be creating the same experience for the Ethereum and Cardano blockchains, to help users evaluate and compare fees and network traffic. We want users to have consistently up-to-date information about how best to use their cryptocurrencies â€“ bridging the gap between interest and understanding starts with clear, interactive representations of key concepts and components. 

Giống như VR và AR khác của chúng tôi hoạt động, chúng tôi sẽ sớm tạo ra trải nghiệm tương tự cho các blockchain Ethereum và Cardano, để giúp người dùng đánh giá và so sánh các khoản phí và lưu lượng mạng.
Chúng tôi muốn người dùng có thông tin cập nhật liên tục về cách sử dụng tiền điện tử của họ-thu hẹp khoảng cách giữa sự quan tâm và sự hiểu biết bắt đầu với các biểu diễn tương tác rõ ràng của các khái niệm và thành phần chính.

Weâ€™re really excited about this app. Itâ€™ll not only be an easy way to grasp whatâ€™s happening on a blockchain at any moment, but a functional tool that provides transaction data in real-time. The app is already available on Android and an augmented reality iOS version will be released this summer. Weâ€™ll also soon be announcing updates for our world tour â€“ so stay tuned, and get ready to discover the blockchain anew. 

Chúng tôi thực sự hào hứng với ứng dụng này.
Nó không chỉ là một cách dễ dàng để nắm bắt những gì xảy ra trên blockchain bất cứ lúc nào, mà là một công cụ chức năng cung cấp dữ liệu giao dịch trong thời gian thực.
Ứng dụng đã có sẵn trên Android và phiên bản iOS thực tế tăng cường sẽ được phát hành vào mùa hè này.
Chúng tôi cũng sẽ sớm công bố các bản cập nhật cho World Tour của chúng tôi - Vì vậy, hãy theo dõi và sẵn sàng khám phá blockchain một lần nữa.

To find out more about the world tour, or to see how you can play a part, [contact Kuva](https://www.kuva.io/ "Kuva's website, kuva.io/") today.

Để tìm hiểu thêm về World Tour, hoặc để xem cách bạn có thể đóng một phần, [liên hệ với Kuva] (https://www.kuva.io/ "Trang web của Kuva, Kuva.io/") ngay hôm nay.

