# Cardano reaches development milestone
### **Engineers conclude Byron phase as Shelley work progresses**
![](img/2019-03-22-cardano-reaches-development-milestone.002.png) 22 March 2019![](img/2019-03-22-cardano-reaches-development-milestone.002.png)[ Duncan Coutts](tmp//en/blog/authors/duncan-coutts/page-1/)![](img/2019-03-22-cardano-reaches-development-milestone.003.png) 6 mins read

![Duncan Coutts](img/2019-03-22-cardano-reaches-development-milestone.004.png)[](tmp//en/blog/authors/duncan-coutts/page-1/)
### [**Duncan Coutts**](tmp//en/blog/authors/duncan-coutts/page-1/)
Technical Architect

Well-Typed

- ![](img/2019-03-22-cardano-reaches-development-milestone.005.png)[](mailto:duncan.coutts@iohk.io "Email")
- ![](img/2019-03-22-cardano-reaches-development-milestone.006.png)[](https://www.youtube.com/watch?v=TZGVgNsJSnA "YouTube")
- ![](img/2019-03-22-cardano-reaches-development-milestone.007.png)[](http://www.linkedin.com/in/duncancoutts "LinkedIn")
- ![](img/2019-03-22-cardano-reaches-development-milestone.008.png)[](https://github.com/dcoutts "GitHub")

![Cardano reaches development milestone](img/2019-03-22-cardano-reaches-development-milestone.009.jpeg)

The release of Cardano 1.5 marks the start of the shift from the Cardano Byron era to the Shelley era and is an excellent opportunity to describe the ongoing work for [Shelley and how the transition will happen](https://www.youtube.com/watch?v=g82tvyj4Tik&feature=youtu.be "Cardano 1.5 Road to Shelley Episode 20 - The Cardano Effect, youtube.com"). Roughly six months ago, we switched almost all our development efforts to the Shelley code base, and work has been progressing quickly ever since. The last major work in the Byron code base was completed for Cardano 1.4, and for 1.5 we limited work to only those changes required for a smooth transition to Shelley.

Việc phát hành Cardano 1.5 đánh dấu sự khởi đầu của sự thay đổi từ kỷ nguyên Cardano Byron sang kỷ nguyên Shelley và là một cơ hội tuyệt vời để mô tả công việc đang diễn ra cho [Shelley và cách chuyển đổi sẽ xảy ra] (https://www.youtube.com
/watch?v=g82tvyj4tik&feature=youtu.be "Cardano 1.5 Road to Shelley Tập 20 - Hiệu ứng Cardano, YouTube.com").
Khoảng sáu tháng trước, chúng tôi đã chuyển gần như tất cả các nỗ lực phát triển của mình sang cơ sở mã Shelley và công việc đã được tiến hành nhanh chóng kể từ đó.
Công việc chính cuối cùng trong cơ sở mã Byron đã được hoàn thành cho Cardano 1.4 và đối với 1.5, chúng tôi giới hạn công việc chỉ những thay đổi cần thiết cho một chuyển đổi suôn sẻ sang Shelley.

The Shelley code base is not just an extension to the Byron code base, but an entirely new foundation. For the Shelley era, we have taken the opportunity to strip back and rebuild the system, as well as including the new staking and delegation functionality. As a result, we have been able to remedy a number of architectural limitations in the Byron code, as well as engage in the [semi-formal software development](https://www.youtube.com/watch?v=wW1CI9zt1tg "IOHK PlutusFest 2019, Director of Engineering - Duncan Coutts Interview") approach that I keep discussing in my videos.

Cơ sở mã Shelley không chỉ là một phần mở rộng cho cơ sở mã Byron, mà là một nền tảng hoàn toàn mới.
Đối với kỷ nguyên Shelley, chúng tôi đã có cơ hội để tước lại và xây dựng lại hệ thống, cũng như bao gồm chức năng cổ phần và phái đoàn mới.
Do đó, chúng tôi đã có thể khắc phục một số hạn chế kiến trúc trong mã Byron, cũng như tham gia vào [phát triển phần mềm bán chính thức] (https://www.youtube.com/watch?v=WW1CI9ZT1TG "
IOHK Plutusfest 2019, Giám đốc Kỹ thuật - Phỏng vấn Duncan Coutts ") cách tiếp cận mà tôi tiếp tục thảo luận trong các video của mình.

In particular, we now have formal mathematical specifications of the validation rules for the Byron and Shelley blockchain, and will present these specifications at the [IOHK summit in April](https://iohksummit.io/ "IOHK Summit 2018"). When development is complete, we will be able to provide evidence that the code correctly implements our specifications. This is an exciting step-change in system quality and will be a first for our industry.

Cụ thể, chúng tôi hiện có các thông số kỹ thuật toán học chính thức về các quy tắc xác nhận cho blockchain Byron và Shelley, và sẽ trình bày các thông số kỹ thuật này tại Hội nghị thượng đỉnh [IOHK vào tháng 4] (https://iohksummit.io/ "Hội nghị thượng đỉnh IOHK 2018").
Khi phát triển hoàn tất, chúng tôi sẽ có thể cung cấp bằng chứng cho thấy mã thực hiện chính xác các thông số kỹ thuật của chúng tôi.
Đây là một bước thay đổi thú vị về chất lượng hệ thống và sẽ là người đầu tiên cho ngành công nghiệp của chúng tôi.

## **A seamless transition**

## ** Một quá trình chuyển tiếp liền mạch **

We must, of course, manage the transition from Byron to Shelley very carefully. It is not just a significant change in the rules, but also a migration from one code base to another. We have gone to great lengths to ensure that the transition process will be as smooth as possible.

Tất nhiên, chúng ta phải quản lý quá trình chuyển đổi từ Byron sang Shelley rất cẩn thận.
Nó không chỉ là một thay đổi đáng kể trong các quy tắc, mà còn là một sự di chuyển từ cơ sở mã này sang cơ sở khác.
Chúng tôi đã cố gắng hết sức để đảm bảo rằng quá trình chuyển đổi sẽ suôn sẻ nhất có thể.

While you might expect the Shelly transition to involve a single hard fork, it will actually comprise two. It is worth emphasizing that while these are technically hard forks, they will not be disruptive in the way hard forks often are. The changes have been designed to use our existing update system and be minimally disruptive. For Daedalus users, it will be very much like any other update.

Mặc dù bạn có thể mong đợi quá trình chuyển đổi Shelly liên quan đến một hẻm cứng, nhưng nó thực sự sẽ bao gồm hai.
Điều đáng để nhấn mạnh rằng trong khi những thứ này là những chiếc dĩa kỹ thuật, nhưng chúng sẽ không gây rối theo cách khó khăn thường xuyên.
Các thay đổi đã được thiết kế để sử dụng hệ thống cập nhật hiện tại của chúng tôi và bị gián đoạn tối thiểu.
Đối với người dùng Daedalus, nó sẽ rất giống với bất kỳ bản cập nhật nào khác.

![Current Protocol](img/2019-03-22-cardano-reaches-development-milestone.010.png)

For both hard forks, we will deploy an update which includes the rules of the new era in an unactivated state, to be activated several weeks later. This is key to avoiding disruption at the hard fork: no software is updated at the moment of the hard fork itself. The software update happens earlier, and once everyone is ready we can smoothly activate the change.

Đối với cả hai hốc, chúng tôi sẽ triển khai một bản cập nhật bao gồm các quy tắc của kỷ nguyên mới ở trạng thái không hoạt động, sẽ được kích hoạt vài tuần sau đó.
Đây là chìa khóa để tránh sự gián đoạn ở hard fork: không có phần mềm nào được cập nhật tại thời điểm của hard fork.
Bản cập nhật phần mềm xảy ra sớm hơn và một khi mọi người đã sẵn sàng, chúng tôi có thể kích hoạt thay đổi một cách trơn tru.

The only difference between a hard fork and a regular update is that updating is compulsory between the software release and the hard fork activation. For Daedalus users, this happens via the standard software update system. Exchanges will have to upgrade manually, but they have several weeks to do so.

Sự khác biệt duy nhất giữa một hard fork và một bản cập nhật thông thường là việc cập nhật là bắt buộc giữa phát hành phần mềm và kích hoạt hard fork.
Đối với người dùng Daedalus, điều này xảy ra thông qua hệ thống cập nhật phần mềm tiêu chuẩn.
Trao đổi sẽ phải nâng cấp thủ công, nhưng họ có vài tuần để làm như vậy.

## **Why two hard forks?**

## ** Tại sao hai cái dĩa cứng? **

For technical reasons, the transition from Byron to Shelley is more straightforward if we go via an intermediate transitional era. There is one hard fork to enter the transitional era and then a second one to begin the Shelley era proper. The Byron era uses Ouroboros Classic, and the Shelley era uses Ouroboros Genesis (which is an extension of Ouroboros Praos). Both of these are complex protocols. For a single implementation of a full node to manage a hard fork smoothly it is necessary for it to implement the rules both before and after the hard fork. A direct hard fork from Byron to Shelley would require a single implementation to understand Ouroboros Classic, Ouroboros Genesis, and all of the other validity rules â€“ which is a very complicated prospect indeed.

Vì lý do kỹ thuật, việc chuyển đổi từ Byron sang Shelley sẽ đơn giản hơn nếu chúng ta đi qua một kỷ nguyên chuyển tiếp trung gian.
Có một hẻm khó để bước vào kỷ nguyên chuyển tiếp và sau đó là một cái thứ hai để bắt đầu thời đại Shelley.
Thời đại Byron sử dụng Ouroboros Classic và ERA Shelley sử dụng Ouroboros Genesis (là một phần mở rộng của Ouroboros PRAOS).
Cả hai đều là các giao thức phức tạp.
Đối với một triển khai duy nhất của một nút đầy đủ để quản lý một hard fork một cách trơn tru, cần thiết để thực hiện các quy tắc cả trước và sau hard fork.
Một hẻm cứng trực tiếp từ Byron đến Shelley sẽ yêu cầu một triển khai duy nhất để hiểu Ouroboros Classic, Ouroboros Genesis và tất cả các quy tắc hợp lệ khác - đó thực sự là một triển vọng rất phức tạp.

Not only that, but the Byron version of Ouroboros Classic has some additional complexity that would need to be replicated in a new implementation to preserve perfect consensus. Instead, we are using Ouroboros BFT, a simple variant of Ouroboros, for the transitional era. This means that the Byron code base only has to understand Ouroboros Classic and Ouroboros BFT, while the Shelley code base only has to understand Ouroboros BFT and Ouroboros Genesis. Neither one has to understand both Ouroboros Classic and Ouroboros Genesis. In particular, this means that the new Shelley code base does not need to replicate every detail of the Byron implementation of Ouroboros Classic, achieving a genuine reduction in complexity â€“ and in software development, complexity is the enemy.

Không chỉ vậy, mà phiên bản Byron của Ouroboros Classic có một số phức tạp bổ sung cần được nhân rộng trong một triển khai mới để duy trì sự đồng thuận hoàn hảo.
Thay vào đó, chúng tôi đang sử dụng Ouroboros BFT, một biến thể đơn giản của ouroboros, cho thời đại chuyển tiếp.
Điều này có nghĩa là cơ sở mã Byron chỉ phải hiểu Ouroboros Classic và Ouroboros BFT, trong khi cơ sở mã Shelley chỉ phải hiểu về Ouroboros BFT và Ouroboros Genesis.
Không ai phải hiểu cả Ouroboros Classic và Ouroboros Genesis.
Cụ thể, điều này có nghĩa là cơ sở mã Shelley mới không cần phải sao chép mọi chi tiết về việc triển khai Byron của Ouroboros Classic, đạt được sự giảm độ phức tạp thực sự và trong phát triển phần mềm, sự phức tạp là kẻ thù.

## **A transitional era**

## ** Một kỷ nguyên chuyển tiếp **

So this explains what the Cardano 1.5 release is really for: it is the release in which the Byron code base begins to understands Ouroboros BFT, allowing us to complete the first managed hard fork in a few weeks' time. After the hard fork, we will be in the transitional era using Ouroboros BFT and will be able to start deploying the new code base over time as it is developed. This is the new code base that will be used for the Shelley releases later, but is initially still using Ouroboros BFT for perfect compatibility during the transition.

Vì vậy, điều này giải thích những gì bản phát hành Cardano 1.5 thực sự dành cho: đó là bản phát hành trong đó cơ sở mã Byron bắt đầu hiểu Ouroboros BFT, cho phép chúng tôi hoàn thành Fork Fork được quản lý đầu tiên trong vài tuần nữa.
Sau khi khó khăn, chúng ta sẽ ở trong kỷ nguyên chuyển tiếp bằng cách sử dụng Ouroboros BFT và sẽ có thể bắt đầu triển khai cơ sở mã mới theo thời gian khi nó được phát triển.
Đây là cơ sở mã mới sẽ được sử dụng cho các bản phát hành Shelley sau đó, nhưng ban đầu vẫn sử dụng Ouroboros BFT để tương thích hoàn hảo trong quá trình chuyển đổi.

During this transitional period, we will also run [a testnet for delegation and staking](https://testnet.iohkdev.io/ "Cardano Testnets"). Initially, this testnet will use a subset of the Shelley rules, but we will update it over time until the full Shelley rules are implemented and any other issues uncovered by the testnet resolved.

Trong giai đoạn chuyển tiếp này, chúng tôi cũng sẽ chạy [một testnet cho ủy quyền và đặt cược] (https://testnet.iohkdev.io/ "Cardano Testnets").
Ban đầu, TestNet này sẽ sử dụng một tập hợp con của các quy tắc Shelley, nhưng chúng tôi sẽ cập nhật nó theo thời gian cho đến khi các quy tắc Shelley đầy đủ được thực hiện và bất kỳ vấn đề nào khác được phát hiện bởi TestNet được giải quyết.

Once we are satisfied with the full implementation of the Shelley rules, then we will deploy an update of the new code base on mainnet. A few weeks later we will activate the hard fork and then we are finally in the Shelley era on mainnet!

Khi chúng tôi hài lòng với việc thực hiện đầy đủ các quy tắc của Shelley, thì chúng tôi sẽ triển khai bản cập nhật cơ sở mã mới trên Mainnet.
Vài tuần sau, chúng tôi sẽ kích hoạt hard fork và sau đó cuối cùng chúng tôi đang ở trong thời đại Shelley trên chính!

In summary, the Cardano 1.5 release is exciting not because of any major features, or the numerous incremental improvements in Daedalus, but because it is the milestone that marks the beginning of the end for Cardano Byron and the start of the transition process into Cardano Shelley.

Tóm lại, bản phát hành Cardano 1.5 rất thú vị không phải vì bất kỳ tính năng chính nào, hay nhiều cải tiến gia tăng ở Daedalus, mà bởi vì đó là cột mốc quan trọng đánh dấu sự khởi đầu của Cardano Byron và bắt đầu quá trình chuyển đổi thành Cardano Shelley
.

Artwork, ![Creative Commons](img/2019-03-22-cardano-reaches-development-milestone.011.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")IOHK | Agency & Dimitris Ladopoulos 

