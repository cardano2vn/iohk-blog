# Explaining the Shelley Incentivized Testnet incentive model
### **Learn about Cardano’s incentive model, rewards, and our plan for the Incentivized Testnet** 
![](img/2019-12-05-explaining-the-shelley-incentivized-testnet-incentive-model.002.png) 5 December 2019![](img/2019-12-05-explaining-the-shelley-incentivized-testnet-incentive-model.002.png)[ Kevin Hammond](tmp//en/blog/authors/kevin-hammond/page-1/)![](img/2019-12-05-explaining-the-shelley-incentivized-testnet-incentive-model.003.png) 7 mins read

![Kevin Hammond](img/2019-12-05-explaining-the-shelley-incentivized-testnet-incentive-model.004.png)[](tmp//en/blog/authors/kevin-hammond/page-1/)
### [**Kevin Hammond**](tmp//en/blog/authors/kevin-hammond/page-1/)
Software Engineer

Engineering

- ![](img/2019-12-05-explaining-the-shelley-incentivized-testnet-incentive-model.005.png)[](https://twitter.com/inputoutputhk "Twitter")

![Explaining the Shelley Incentivized Testnet incentive model](img/2019-12-05-explaining-the-shelley-incentivized-testnet-incentive-model.006.jpeg)

We’ve talked a lot about incentives lately. That’s because right now we’re running the [Incentivized Testnet](https://staking.cardano.org/): a Shelley testnet that provides an opportunity for stakeholders to delegate their stake or operate a stake pool to earn real ada rewards. Later this month, anybody that had ada in either a Daedalus or Yoroi mainnet wallet during the balance snapshot (taken on November 29) will be able to participate in the Incentivized Testnet, as either a delegator or stake pool operator, or both. 

Gần đây, chúng tôi đã nói rất nhiều về các ưu đãi.
Điều đó bởi vì ngay bây giờ, chúng tôi đang chạy [Testnet được khuyến khích] (https://staking.cardano.org/): Một Testnet Shelley cung cấp cơ hội cho các bên liên quan ủy thác cổ phần của họ hoặc vận hành một nhóm cổ phần để kiếm được phần thưởng ADA thực sự.
Cuối tháng này, bất kỳ ai có ADA trong ví Daedalus hoặc Yoroi Mainnet trong ảnh chụp nhanh Balance (được thực hiện vào ngày 29 tháng 11) sẽ có thể tham gia TestNet được khuyến khích, vì một ủy viên hoặc nhà điều hành nhóm cổ phần hoặc cả hai.

One of our key goals for the Incentivized Testnet is to test – in a real-world setting – the assumptions made in the [Ouroboros incentives whitepaper](https://arxiv.org/ftp/arxiv/papers/1807/1807.11218.pdf), which uses game theory to calculate the incentives required to ensure consistent, active, and strong participation within a blockchain network.

Một trong những mục tiêu chính của chúng tôi đối với TestNet được khuyến khích là kiểm tra-trong môi trường thực tế-các giả định được đưa ra trong [Ouroboros khuyến khích whitepaper] (https://arxiv.org/ftp/arxiv/papers/1807/1807.11218.pdf
), sử dụng lý thuyết trò chơi để tính toán các ưu đãi cần thiết để đảm bảo sự tham gia nhất quán, chủ động và mạnh mẽ trong mạng blockchain.

The foundation of Cardano is mathematics; its central pillar, however, is a philosophy aimed at creating a fairer, more transparent, and more equitable system, decentralized and globally distributed.

Nền tảng của Cardano là toán học;
Tuy nhiên, trụ cột trung tâm của nó là một triết lý nhằm tạo ra một hệ thống công bằng, minh bạch hơn và công bằng hơn, phi tập trung và phân phối toàn cầu.

## **Why incentives matter**

## ** Tại sao các ưu đãi quan trọng **

Successful systems depend upon the adequate supply of incentives. Think of a company. A company must sufficiently incentivize its employees to work. This doesn’t just mean turning up to work – existing within the system – but performing a specific function to the desired standard. The same is true (and, arguably, is more crucial) for decentralized systems. Cardano is a decentralized network of global participants, each of whom must be adequately incentivized to take part and perform their roles, with the understanding that the network’s interests align with their own.

Các hệ thống thành công phụ thuộc vào việc cung cấp đầy đủ các ưu đãi.
Hãy nghĩ về một công ty.
Một công ty phải đủ khuyến khích nhân viên của mình làm việc.
Điều này không chỉ có nghĩa là bật lên để làm việc - tồn tại trong hệ thống - nhưng thực hiện một chức năng cụ thể theo tiêu chuẩn mong muốn.
Điều tương tự cũng đúng (và, có thể nói là rất quan trọng) đối với các hệ thống phi tập trung.
Cardano là một mạng lưới phi tập trung của những người tham gia toàn cầu, mỗi người trong số họ phải được khuyến khích đầy đủ để tham gia và thực hiện vai trò của họ, với sự hiểu biết rằng các lợi ích của mạng lưới phù hợp với chính họ.

## **A brief overview of the incentives mechanism**

## ** Tổng quan ngắn gọn về cơ chế ưu đãi **

Cardano’s incentives model begins with an assumption of rationality: that each player will act to maximize their own returns. These returns are the system’s incentives, and can take the form of tangible rewards – such as money – or intangible rewards, such as esteem, reputation, status, identity, or fulfilment.

Mô hình ưu đãi của Cardano, bắt đầu bằng một giả định về tính hợp lý: rằng mỗi người chơi sẽ hành động để tối đa hóa lợi nhuận của chính họ.
Những lợi nhuận này là các ưu đãi của hệ thống, và có thể có hình thức phần thưởng hữu hình - chẳng hạn như tiền - hoặc phần thưởng vô hình, chẳng hạn như lòng tự trọng, danh tiếng, địa vị, bản sắc hoặc hoàn thành.

Selfless acts are rare. As individuals, we pursue strategies that reward us, directly or indirectly. A network of participants each acting out of self-interest, however, can lead to chaos. That’s why successful systems codify – in protocols, rules, or laws – when and how much each participant will be rewarded. One of the core principles of game theory is that an ideal system is one where a selfish participant, acting in their own best interests, is also, by design, acting in the best interests of the system.

Hành vi vị tha là rất hiếm.
Là cá nhân, chúng tôi theo đuổi các chiến lược thưởng cho chúng tôi, trực tiếp hoặc gián tiếp.
Tuy nhiên, một mạng lưới những người tham gia hành động từ lợi ích cá nhân, tuy nhiên, có thể dẫn đến sự hỗn loạn.
Đó là lý do tại sao các hệ thống thành công mã hóa - trong các giao thức, quy tắc hoặc luật pháp - khi nào và mỗi người tham gia sẽ được thưởng bao nhiêu.
Một trong những nguyên tắc cốt lõi của lý thuyết trò chơi là một hệ thống lý tưởng là một trong đó một người tham gia ích kỷ, hành động vì lợi ích tốt nhất của họ, cũng là, theo thiết kế, hoạt động vì lợi ích tốt nhất của hệ thống.

This is the function of Ouroboros’ incentives mechanism: a set of instructions that specify how and when rewards are paid out, and in what proportions to reward different levels of stake contribution. It allows a distributed network of participants to coordinate and collaborate in a decentralized system and receive rewards in accordance with their self-interest, while still contributing to the long-term health of the network. 

Đây là chức năng của cơ chế ưu đãi Ouroboros, một tập hợp các hướng dẫn xác định cách thức và thời điểm phần thưởng được thanh toán, và theo tỷ lệ nào để thưởng cho các cấp độ đóng góp khác nhau.
Nó cho phép một mạng lưới người tham gia phân tán phối hợp và hợp tác trong một hệ thống phi tập trung và nhận phần thưởng theo lợi ích cá nhân của họ, trong khi vẫn đóng góp vào sức khỏe lâu dài của mạng.

## **Aims of Cardano’s incentive model**

## ** Mục đích của mô hình khuyến khích Cardano **

Equality and fairness are key to the sustainability of any future system, but can only be assured by the system itself, independent of individual goals or self-interest. Individuals must be free to exercise their ingenuity and maximize their outcomes, as long as doing so does not impede the operation of the network or restrict the possibilities of another (for example, by gaining a disproportionate amount of control). If one participant is the winner every time, other participants are disincentivized and, eventually, disenfranchised. The final implementation of Cardano’s incentives mechanism, as outlined in the [incentives whitepaper](https://arxiv.org/ftp/arxiv/papers/1807/1807.11218.pdf), incorporates these factors, ensuring that that the biggest doesn’t always win, and that not only the richest get richer.

Bình đẳng và công bằng là chìa khóa cho tính bền vững của bất kỳ hệ thống nào trong tương lai, nhưng chỉ có thể được tự đảm bảo bởi chính hệ thống, độc lập với các mục tiêu cá nhân hoặc lợi ích cá nhân.
Các cá nhân phải được tự do thực hiện sự khéo léo của họ và tối đa hóa kết quả của họ, miễn là làm như vậy không cản trở hoạt động của mạng hoặc hạn chế các khả năng của người khác (ví dụ, bằng cách đạt được một lượng kiểm soát không cân xứng).
Nếu một người tham gia là người chiến thắng mỗi lần, những người tham gia khác sẽ không bị từ chối và cuối cùng, bị tước quyền.
Việc thực hiện cuối cùng cơ chế ưu đãi của Cardano, như được nêu trong [Whitepaper] (https://arxiv.org/ftp/arxiv/papers/1807/1807.11218.pdf)
Luôn luôn giành chiến thắng, và điều đó không chỉ giàu nhất trở nên giàu có hơn.

This is one of the aims of the game theory underpinning the incentives model – to test the thresholds and parameters for exploitation and the alignment of individual and collective interest – and is similarly one of the aims of the Incentivized Testnet. Over time, we will introduce new factors to the rewards calculation and monitor the impact on participant behavior.

Đây là một trong những mục tiêu của lý thuyết trò chơi làm nền tảng cho mô hình ưu đãi - để kiểm tra các ngưỡng và thông số để khai thác và sự liên kết của lợi ích cá nhân và tập thể - và tương tự là một trong những mục tiêu của Testnet được khuyến khích.
Theo thời gian, chúng tôi sẽ giới thiệu các yếu tố mới cho tính toán phần thưởng và theo dõi tác động đến hành vi của người tham gia.

## **Testing the incentive model**

## ** Kiểm tra mô hình khuyến khích **

The incentives model we’re introducing to the Incentivized Testnet is not the final model. We plan to use this phase to test the incentives model incrementally, verifying our assumptions and exploring whether the network and participants respond in the way we anticipate. 

Mô hình ưu đãi mà chúng tôi giới thiệu cho TestNet được khuyến khích không phải là mô hình cuối cùng.
Chúng tôi dự định sử dụng giai đoạn này để kiểm tra mô hình ưu đãi tăng dần, xác minh các giả định của chúng tôi và khám phá xem mạng và người tham gia có phản hồi theo cách chúng tôi dự đoán hay không.

We will not only be testing our game theory, however. We’ll also be testing the technology, ensuring that additional factors for reward calculations are only included once a baseline model is proven to be secure and stable.

Tuy nhiên, chúng tôi sẽ không chỉ thử nghiệm lý thuyết trò chơi của chúng tôi.
Chúng tôi cũng sẽ thử nghiệm công nghệ, đảm bảo rằng các yếu tố bổ sung để tính toán phần thưởng chỉ được bao gồm một khi mô hình cơ sở được chứng minh là an toàn và ổn định.

In the beginning, various factors will not be included in the rewards calculation. These include factors to increase the number of stake pools and to better rank stake pools according to their desirability. Other factors will be included but in a limited capacity, and their function and calculation will evolve over time. This includes stake pool ranking. At first, the ranking will be based on a stake pool’s performance but, as we progress through the Incentivized Testnet, will transition to be based on desirability (a combination of cost, margin, pledged stake, and performance).

Ban đầu, các yếu tố khác nhau sẽ không được đưa vào tính toán phần thưởng.
Chúng bao gồm các yếu tố để tăng số lượng nhóm cổ phần và xếp hạng tốt hơn các nhóm cổ phần theo tính mong muốn của họ.
Các yếu tố khác sẽ được bao gồm nhưng trong một khả năng hạn chế, và chức năng và tính toán của chúng sẽ phát triển theo thời gian.
Điều này bao gồm xếp hạng nhóm cổ phần.
Lúc đầu, xếp hạng sẽ dựa trên hiệu suất của nhóm cổ phần, nhưng khi chúng tôi tiến hành thông qua TestNet khuyến khích, sẽ chuyển đổi để dựa trên mong muốn (sự kết hợp giữa chi phí, ký quỹ, cổ phần cam kết và hiệu suất).

We’ll then gradually introduce additional factors into the rewards calculation, beginning with factors to encourage growth in the number of stake pools and to ensure the system promotes the most desirable stake pools. Each of these is important, and introducing them in a staged approach will allow us to ensure they function as intended and that each has the intended effect on the network.

Sau đó, chúng tôi sẽ dần dần đưa các yếu tố bổ sung vào tính toán phần thưởng, bắt đầu với các yếu tố để khuyến khích tăng trưởng số lượng nhóm cổ phần và để đảm bảo hệ thống thúc đẩy các nhóm cổ phần mong muốn nhất.
Mỗi trong số này là quan trọng, và giới thiệu chúng theo cách tiếp cận được dàn dựng sẽ cho phép chúng tôi đảm bảo chúng hoạt động như dự định và mỗi người có tác dụng dự định trên mạng.

## **Incentivized Testnet rewards**

## ** Phần thưởng Testnet được khuyến khích **

The rewards for delegating stake or operating a stake pool on the Incentivized Testnet depend upon the percentage of network participation. An approximate 3.8 million ada will be awarded per epoch. If 50 percent of the network participates, then we estimate the annual return for delegation will be approximately 7 to 8 percent but could, if network participation is lower, be as high as 13-15 percent. These figures are subject to treasury taxes and stake pool fees. A rewards calculator is now available on the [Incentivized Testnet website](https://staking.cardano.org/) which, in addition to other variables, allows you to calculate approximate rewards relative to different levels of network participation. Here’s a sneak peek:

Phần thưởng cho việc ủy thác cổ phần hoặc vận hành nhóm cổ phần trên TestNet được khuyến khích phụ thuộc vào tỷ lệ phần trăm tham gia mạng.
Một ADA xấp xỉ 3,8 triệu ADA sẽ được trao cho mỗi Epoch.
Nếu 50 phần trăm của mạng tham gia, thì chúng tôi ước tính lợi nhuận hàng năm cho phái đoàn sẽ xấp xỉ 7 đến 8 phần trăm nhưng có thể, nếu sự tham gia của mạng thấp hơn, cao tới 13-15 phần trăm.
Những con số này phải chịu thuế ngân quỹ và phí nhóm cổ phần.
Một máy tính phần thưởng hiện có sẵn trên [trang web Testnet được khuyến khích] (https://staking.cardano.org/), ngoài các biến khác, cho phép bạn tính toán phần thưởng gần đúng so với các cấp độ tham gia mạng khác nhau.
Ở đây, một cái nhìn lén lút:

**Approximate delegation rewards calculation at 30% participation**

** Tính toán phần thưởng của phái đoàn gần đúng ở mức tham gia 30% **

**Approximate delegation rewards calculation at 50% participation**

** Tính toán phần thưởng của phái đoàn gần đúng ở mức tham gia 50% **

Meanwhile, for stake pool operators, the rewards for stake pool operation, assuming a pledged amount of 10,000,000 ada, a 10 dollar daily stake pool operating fee, 50 percent network participation in the Incentivized Testnet, and the operator margin set to 10 percent, the total return rate for stake pool delegation will be approximately 12 to 13 percent. We will be updating the calculator over time to include more sophisticated rewards calculation modelling.

Trong khi đó, đối với các nhà khai thác nhóm cổ phần, phần thưởng cho hoạt động của nhóm cổ phần, giả sử số tiền cam kết là 10.000.000 ADA, phí vận hành nhóm cổ phần 10 đô la, tham gia mạng 50 % trong Testnet được khuyến khích và biên độ của nhà điều hành được đặt thành 10 %,
Tổng tỷ lệ hoàn vốn cho phái đoàn nhóm cổ phần sẽ khoảng 12 đến 13 phần trăm.
Chúng tôi sẽ cập nhật máy tính theo thời gian để bao gồm mô hình tính toán phần thưởng tinh vi hơn.

**Approximate stake pool operation rewards calculation at 50% participation**

** Tính toán phần thưởng hoạt động của nhóm cổ phần gần đúng ở mức tham gia 50% **

## **More coming soon**

## ** Sắp có thêm **

This is a testnet, and as such involves an iterative process to reach our desired end: a complete and fully functioning incentives mechanism – as described in the Ouroboros whitepaper – that rewards network participants accurately and fairly in proportion to their contribution, while preventing any single actor from gaining a disproportionate amount of control over the network. We’ll be actively monitoring participant behavior throughout the testnet, to determine when and what additional factors may be included in the rewards calculation. 

TestNet và như vậy liên quan đến một quy trình lặp để đạt đến kết thúc mong muốn của chúng tôi: một cơ chế khuyến khích đầy đủ và đầy đủ hoạt động - như được mô tả trong whiteboros whitepap
Diễn viên từ việc đạt được một lượng kiểm soát không tương xứng đối với mạng.
Chúng tôi sẽ tích cực theo dõi hành vi của người tham gia trong toàn bộ TestNet, để xác định thời điểm và những yếu tố bổ sung nào có thể được đưa vào tính toán phần thưởng.

To learn more about the Incentivized Testnet, [visit our website](https://staking.cardano.org/). If you’re interested in running a stake pool, [register your interest](https://forms.gle/JqPjdMkR58tzj4Mn6) and explore our [testnet website](https://testnet.iohkdev.io/en/) for step-by-step instructions. And, as always, follow us on [Twitter](https://twitter.com/inputoutputhk?lang=en) or [sign up to our email list](https://staking.cardano.org/) for the latest progress updates.

Để tìm hiểu thêm về Testnet được khuyến khích, [truy cập trang web của chúng tôi] (https://staking.cardano.org/).
Nếu bạn quan tâm đến việc chạy nhóm cổ phần, [đăng ký sở thích của bạn] (https://forms.gle/jqpjdmkr58tzj4mn6) và khám phá [trang web testnet của chúng tôi] (https://testnet.iohkdev.io/en/) cho bước
-By hướng dẫn.
Và, như mọi khi, hãy theo dõi chúng tôi trên [Twitter] (https://twitter.com/inputoutputhk?lang=en) hoặc [đăng ký vào danh sách email của chúng tôi] (https://staking.cardano.org/)
Cập nhật tiến độ.

