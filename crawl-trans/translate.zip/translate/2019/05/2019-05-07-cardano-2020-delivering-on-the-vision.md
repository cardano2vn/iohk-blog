# Cardano 2020: delivering on the vision
### **New roadmap, product demos, and regular updates will highlight progress**
![](img/2019-05-07-cardano-2020-delivering-on-the-vision.002.png) 7 May 2019![](img/2019-05-07-cardano-2020-delivering-on-the-vision.002.png)[ David Esser](tmp//en/blog/authors/david-esser/page-1/)![](img/2019-05-07-cardano-2020-delivering-on-the-vision.003.png) 4 mins read

![David Esser](img/2019-05-07-cardano-2020-delivering-on-the-vision.004.png)[](tmp//en/blog/authors/david-esser/page-1/)
### [**David Esser**](tmp//en/blog/authors/david-esser/page-1/)
Senior Product Manager

Cardano

- ![](img/2019-05-07-cardano-2020-delivering-on-the-vision.005.png)[](https://www.linkedin.com/in/davidesser/ "LinkedIn")
- ![](img/2019-05-07-cardano-2020-delivering-on-the-vision.006.png)[](https://github.com/davidesser "GitHub")

![Cardano 2020: delivering on the vision](img/2019-05-07-cardano-2020-delivering-on-the-vision.007.jpeg)

Cardano is in an exciting transition stage. The project has long combined thoughtful product vision with research-driven specification and evidence-based development processes. Still committed to that rigor, weâ€™re now making the jump to a new stage of development where first-ever-in-the-world new capabilities are delivered. The rubber is starting to hit the road. As we are making this transition we recognize that we need a better way to communicate how Cardanoâ€™s 2020 vision is being delivered, and that we should do a better job keeping the community informed about our status against those goals.

Cardano đang trong một giai đoạn chuyển tiếp thú vị.
Dự án từ lâu đã kết hợp tầm nhìn sản phẩm chu đáo với đặc điểm kỹ thuật dựa trên nghiên cứu và các quy trình phát triển dựa trên bằng chứng.
Vẫn cam kết với sự nghiêm ngặt đó, chúng tôi hiện đang thực hiện bước nhảy sang giai đoạn phát triển mới, nơi các khả năng mới đầu tiên trong thế giới được phân phối.
Cao su đang bắt đầu lên đường.
Vì chúng tôi đang thực hiện quá trình chuyển đổi này, chúng tôi nhận ra rằng chúng tôi cần một cách tốt hơn để truyền đạt tầm nhìn năm 2020 của Cardano và chúng tôi nên làm một công việc tốt hơn để giữ cho cộng đồng thông báo về tình trạng của chúng tôi chống lại các mục tiêu đó.

Here is what we are doing to accomplish those things.

Đây là những gì chúng ta đang làm để hoàn thành những điều đó.

We are working on a redesign of the [Cardano roadmap website](https://cardanoroadmap.com/ "cardanoroadmap.com") that will do a better job describing our upcoming release phases, with themes and detailed functional components for each. You can expect to see it live in 2-4 weeks, with more content added over time. Aligned with the [keynote speech from CEO Charles Hoskinson](https://youtu.be/lgZ40ocb3_8 "Charles Hoskinson keynote - IOHK Summit Miami - 17 April 2019, youtube.com") at the recent IOHK Summit, the new roadmap site will provide a clear definition of delivery phases, how they fit together, and what weâ€™ll deliver when. 

Chúng tôi đang làm việc để thiết kế lại [trang web Cardano Roadmap] (https://cardanoroadmap.com/ "cardanoroadmap.com") sẽ thực hiện một công việc tốt hơn khi mô tả các giai đoạn phát hành sắp tới của chúng tôi, với các chủ đề và các thành phần chức năng chi tiết cho mỗi giai đoạn.
Bạn có thể mong đợi được thấy nó trực tiếp trong 2-4 tuần, với nhiều nội dung được thêm vào theo thời gian.
Phù hợp với [bài phát biểu quan trọng từ CEO Charles Hoskinson] (https://youtu.be/lgz40ocb3_8 "Charles Hoskinson Keynote - IOHK Summit Miami - 17 tháng 4 năm 2019, YouTube.com")
Cung cấp một định nghĩa rõ ràng về các giai đoạn phân phối, cách chúng khớp với nhau và những gì chúng ta sẽ cung cấp khi.

Regarding delivery status, Cardano has had an ethos of openness and transparency since the beginning. We want to take that further. Hereâ€™s how.

Liên quan đến tình trạng giao hàng, Cardano đã có một sự cởi mở và minh bạch kể từ đầu.
Chúng tôi muốn đưa nó đi xa hơn.
Đây là cách nào.

Weâ€™ve recently improved our organisational processes to support this phase of development where long-promised functionality becomes reality. One aspect has been a focus on how we share progress against milestones inside the Cardano team, with weekly project updates, live progress demos, and soon a new Shelley testnet.

Gần đây, chúng tôi đã cải thiện các quy trình tổ chức của mình để hỗ trợ giai đoạn phát triển này, nơi chức năng được đưa ra từ lâu trở thành hiện thực.
Một khía cạnh đã tập trung vào cách chúng tôi chia sẻ tiến trình chống lại các cột mốc trong nhóm Cardano, với các bản cập nhật dự án hàng tuần, các bản demo tiến độ trực tiếp và chẳng mấy chốc là một Shelley Testnet mới.

As a result we have greater visibility and accountability in our work. So as we enter the next stage of development, we need status reporting that properly reflects real progress, setting accurate expectations by showing exactly what weâ€™re working on and highlighting real delivery.

Kết quả là chúng tôi có tầm nhìn và trách nhiệm cao hơn trong công việc của chúng tôi.
Vì vậy, khi chúng tôi bước vào giai đoạn phát triển tiếp theo, chúng tôi cần báo cáo trạng thái phản ánh đúng tiến trình thực sự, đặt ra những kỳ vọng chính xác bằng cách hiển thị chính xác những gì chúng tôi đang làm việc và làm nổi bật việc phân phối thực.

Past versions of our roadmap had feature-level percentage complete indicators. We put a lot of effort into those, but even with all that work they fell victim to the same thing Tom Cargill at [Bell Labs](https://en.wikipedia.org/wiki/Bell_Labs "Bell Labs, wikipedia.org") described in his famous-and-funny-but-a-bit-painful-if-you-build-software quote:

Các phiên bản trong quá khứ của lộ trình của chúng tôi có các chỉ số hoàn chỉnh về tỷ lệ phần trăm tính năng.
Chúng tôi đã nỗ lực rất nhiều vào những thứ đó, nhưng ngay cả với tất cả công việc đó, họ trở thành nạn nhân của cùng một thứ Tom Cargill tại [Bell Labs] (https://en.wikipedia.org/wiki/bell_labs "Bell Labs, Wikipedia.org
") Được mô tả trong trích dẫn nổi tiếng và-funny-but-a-bit-painful-if-you-build-software:

*â€œ[The first 90 percent of the code](https://en.wikipedia.org/wiki/Ninety-ninety_rule#cite_note-Bentley1985-1 "Ninety-ninety rule, wikipedia.org") accounts for the first 90 percent of the development time. The remaining 10 percent of the code accounts for the other 90 percent of the development time.â€*

*â € œ [90 phần trăm đầu tiên của mã] (https://en.wikipedia.org/wiki/ninety-ninety_rule#cite_note-bentley1985-1 "Quy tắc Ninety-Ninety, Wikipedia.org")
90 phần trăm thời gian phát triển.
10 phần trăm còn lại của mã chiếm 90 phần trăm khác của thời gian phát triển.

Sigh. But we donâ€™t want to back off on communicating status. The best way to fulfill our ethos of transparency is to push it further and open up the process to you. We are going to record those internal development status demos, where our dev teams show their latest finished working components, and deliver them to the community. So youâ€™ll have a real understanding of our development progress, because that last 10% that sometimes becomes another 90% has to be done, really done, in order to demonstrate working functionality. 

Thở dài.
Nhưng chúng tôi không muốn lùi lại trạng thái giao tiếp.
Cách tốt nhất để thực hiện các đặc điểm minh bạch của chúng tôi là đẩy nó xa hơn và mở ra quá trình cho bạn.
Chúng tôi sẽ ghi lại những bản demo phát triển nội bộ đó, nơi các nhóm Dev của chúng tôi cho thấy các thành phần làm việc hoàn thành mới nhất của họ và cung cấp chúng cho cộng đồng.
Vì vậy, bạn sẽ có một sự hiểu biết thực sự về tiến trình phát triển của chúng tôi, bởi vì 10% cuối cùng mà đôi khi trở thành 90% khác phải được thực hiện, thực sự được thực hiện, để chứng minh chức năng làm việc.

At the same time we deliver the recorded progress demos, we will also deliver a status report summarizing the work completed, and Iâ€™ll do an Ask Me Anything (AMA) session where Iâ€™ll describe the latest results and answer questions from the community. This will happen every month or two based on progress milestones.

Đồng thời chúng tôi cung cấp các bản demo tiến độ được ghi lại, chúng tôi cũng sẽ cung cấp một báo cáo trạng thái tóm tắt công việc đã hoàn thành và tôi sẽ thực hiện một phiên hỏi tôi bất cứ điều gì (AMA) trong đó tôi sẽ mô tả các kết quả mới nhất và trả lời các câu hỏi từ
cộng đồng.
Điều này sẽ xảy ra hàng tháng hoặc hai tháng dựa trên các cột mốc tiến bộ.

Often the news will be awesome with lots of progress, but sometimes youâ€™ll see that thereâ€™s a problem we are working through. Because thatâ€™s the reality when implementing first-ever new functionality. Solving hard problems is hard. But now youâ€™ll be able to see where we are and how itâ€™s going.

Thường thì tin tức sẽ tuyệt vời với rất nhiều tiến bộ, nhưng đôi khi bạn sẽ thấy rằng đó là một vấn đề mà chúng tôi đang giải quyết.
Bởi vì đó là thực tế khi thực hiện chức năng mới đầu tiên.
Giải quyết các vấn đề khó khăn là khó khăn.
Nhưng bây giờ bạn sẽ có thể thấy chúng ta đang ở đâu và nó sẽ diễn ra như thế nào.

Youâ€™ll still be able to access the information sources you had before. Our Githubs are open. Weâ€™ll keep sharing weekly [technical reports](https://www.cardano.org/en/weekly-technical-reports/ "Weekly Technical Reports, cardano.org") on Cardano.org. Emurgo delivers monthly [Cardano reports](https://www.youtube.com/channel/UCgFQ0hHuPO1QDcyP6t9KZTQ/videos?view=0&sort=p&shelf_id=3 "Cardano Reports, youtube.com") describing what weâ€™ve been up to. The unstoppable Charles will keep doing his own AMAs. But we want to make it easy for the community to see what weâ€™re delivering, so this is a major redesign of our roadmap and reporting process, starting from our internal processes and extending out to our partners and the community. 

Bạn vẫn có thể truy cập các nguồn thông tin bạn đã có trước đây.
GitHub của chúng tôi đang mở.
Chúng tôi sẽ tiếp tục chia sẻ hàng tuần [Báo cáo kỹ thuật] (https://www.cardano.org/en/weekly-technical-reports/ "Báo cáo kỹ thuật hàng tuần, cardano.org") trên cardano.org.
Emurgo cung cấp hàng tháng [Báo cáo Cardano] (https://www.youtube.com/channel/ucgfq0hhhupo1qdcyp6t9kztq/videos?view=0&sort=p&shelf_id=3 "
Charles không thể ngăn cản sẽ tiếp tục tự làm AMA của mình.
Nhưng chúng tôi muốn làm cho cộng đồng dễ dàng xem những gì chúng tôi cung cấp, vì vậy đây là thiết kế lại chính của quá trình báo cáo và lộ trình của chúng tôi, bắt đầu từ các quy trình nội bộ của chúng tôi và mở rộng cho các đối tác và cộng đồng của chúng tôi.

The first demos, status update and AMA will come later this month. Iâ€™ll be joining the guys from the [Cardano Effect](https://www.youtube.com/channel/UCdsCDVHKVIuTlziDW7Wg3NQ "The Cardano Effect, youtube.com") within the next few weeks to talk more about our new roadmap and reporting process, so keep an ear out for that. Weâ€™ve got lots of exciting stuff in the pipeline, and Iâ€™m looking forward to sharing it with you. 

Các bản demo đầu tiên, cập nhật trạng thái và AMA sẽ đến vào cuối tháng này.
Tôi sẽ tham gia cùng những người từ [hiệu ứng cardano] (https://www.youtube.com/channel/ucdscdvhkviutlzidw7wg3nq "hiệu ứng cardano, youtube.com")
và quá trình báo cáo, vì vậy hãy giữ một tai ra cho điều đó.
Chúng tôi đã có rất nhiều thứ thú vị trong đường ống, và tôi mong muốn được chia sẻ nó với bạn.

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2019-05-07-cardano-2020-delivering-on-the-vision.008.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

