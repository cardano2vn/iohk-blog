# Mongolia - great for Atala and Cardano pilots
### **Ministers and businesses are enthusiastic about blockchain**
![](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.002.png) 16 May 2019![](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.003.png) 5 mins read

![Charles Hoskinson](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.004.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.005.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.006.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.007.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Mongolia - great for Atala and Cardano pilots](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.008.jpeg)

Think about Mongolia and the image thatâ€™s likely to spring to mind is of sweeping grasslands, mountains, freezing winters and nomads. An unlikely place you might think for ground-breaking technology, but in fact itâ€™s a great country to do blockchain pilots. The capital, Ulaanbaatar, has almost tripled in size since 1990 and now accounts for half of the countryâ€™s three million population. That growth has created problems, including what the [World Health Organization](https://www.who.int/bulletin/volumes/97/2/19-020219/en/ "Air pollution in Mongolia, who.int") has identified as some of the worst air pollution in the world.

Hãy nghĩ về Mông Cổ và hình ảnh có khả năng xuất hiện trong tâm trí là về những đồng cỏ, núi, mùa đông đóng băng và du mục.
Một nơi không thể bạn có thể nghĩ cho công nghệ đột phá, nhưng thực tế, đó là một quốc gia tuyệt vời để làm các phi công blockchain.
Thủ đô, Ulaanbaatar, đã tăng gần gấp ba lần kể từ năm 1990 và hiện chiếm một nửa số dân số của đất nước.
Sự tăng trưởng đó đã tạo ra các vấn đề, bao gồm những gì [Tổ chức Y tế Thế giới] (https://www.who.int/bulletin/volumes/97/2/19-020219/en/ "Ô nhiễm không khí ở Mongolia, WHO.INT")
đã xác định là một số ô nhiễm không khí tồi tệ nhất trên thế giới.

In the winter, temperatures can drop to âˆ’40C and most people live in gers â€“ round wood and canvas structures heated by fires. So, they turn to burning raw coal â€“ and in some cases anything they can get their hands on, from dung to car tires â€“ to stay warm. 

Vào mùa đông, nhiệt độ có thể giảm xuống mức404 và hầu hết mọi người sống trong các cấu trúc gỗ và vải tròn tròn và vải được sưởi ấm bởi các đám cháy.
Vì vậy, họ chuyển sang đốt than thô - và trong một số trường hợp, bất cứ điều gì họ có thể có được, từ lốp xe đến xe hơi - để giữ ấm.

Iâ€™ve just got back from Ulaanbaatar, where weâ€™ve been working out the potential for an internet-of-things project to assess air quality. The idea is to put sensors in place and gather the measurements using IOHKâ€™s [Atala enterprise blockchain](https://www.forbes.com/sites/rachelwolfson/2019/04/30/cardano-founder-launches-enterprise-blockchain-framework-in-collaboration-with-ethiopian-government/#91fdc644e102 "Cardano Founder Launches Enterprise Blockchain Framework In Collaboration With Ethiopian Government, forbes.com"). Once in place, such a network could generate fraud-free, time-stamped data so the authorities know where the pollution is being generated and can focus on cleaning up the worst areas. Putting thousands of sensors in place is expensive but people could be encouraged to do so, and keep them working, by being paid using Cardano as the aggregated data comes through.

Tôi vừa trở về từ Ulaanbaatar, nơi chúng tôi đã tìm ra tiềm năng cho một dự án Internet để đánh giá chất lượng không khí.
Ý tưởng là đặt các cảm biến vào vị trí và thu thập các phép đo bằng cách sử dụng blockchain của Iohk's [Atala Enterprise] (https://www.forbes.com/sites/rachelwolfson/2019/04/30/cardano
-BlockChain-framework-in-collaboring-with-ethiopian-chính phủ/#91FDC644E102 "Người sáng lập Cardano ra mắt khung blockchain doanh nghiệp hợp tác với chính phủ Ethiopia, Forbes.com").
Khi đã sẵn sàng, một mạng lưới như vậy có thể tạo ra dữ liệu không gian lận, có thời gian để các nhà chức trách biết nơi ô nhiễm đang được tạo ra và có thể tập trung vào việc làm sạch các khu vực tồi tệ nhất.
Việc đặt hàng ngàn cảm biến vào vị trí rất tốn kém nhưng mọi người có thể được khuyến khích làm như vậy, và giữ cho chúng hoạt động, bằng cách được trả tiền bằng cách sử dụng Cardano khi dữ liệu tổng hợp xuất hiện.

![IOHK Mongolia](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.009.jpeg) 

**The away team assembled by Charles Hoskinson for Mongolia included Manmeet Singh, 

** Đội khách do Charles Hoskinson tập hợp cho Mông Cổ bao gồm Manmeet Singh,

information chief of Emurgo, and Lars BrÃ¼njes, IOHKâ€™s director of education**

Giám đốc thông tin của Emurgo, và Lars BrÃ¼njes, Giám đốc Giáo dục của Iohk **

The focus in our discussions with ministers in Ulaanbaatar was on solving these sorts of problems, which occur in all fast-growing countries. Another example is that 40% of medicines in rural areas are counterfeited or adulterated or expired; the figure is 18% even in urban areas. So, we want to put a traceability project together for that using Atala. Bringing accountability and transparency to medical supply chains can help protect people from dangerous or counterfeit drugs â€“ and save lives.

Trọng tâm trong các cuộc thảo luận của chúng tôi với các bộ trưởng ở Ulaanbaatar là giải quyết các loại vấn đề này, xảy ra ở tất cả các quốc gia đang phát triển nhanh chóng.
Một ví dụ khác là 40% thuốc ở khu vực nông thôn bị giả hoặc pha trộn hoặc hết hạn;
Con số là 18% ngay cả ở khu vực thành thị.
Vì vậy, chúng tôi muốn kết hợp một dự án truy xuất nguồn gốc cùng nhau để sử dụng Atala.
Mang trách nhiệm và minh bạch cho chuỗi cung ứng y tế có thể giúp bảo vệ người dân khỏi các loại thuốc nguy hiểm hoặc giả - và cứu sống.

Then, there is the fact that almost everyone has access to a mobile phone network â€“ and 30% of the population receive government disbursements of some kind at an enormous cost. Linking those two together using our blockchain technology could save the government a lot of money and make things easier for the recipients, even villagers living on the peaks of Mongolia.

Sau đó, có một thực tế là hầu hết mọi người đều có quyền truy cập vào mạng điện thoại di động - và 30% dân số nhận được giải ngân của chính phủ một số loại với chi phí rất lớn.
Liên kết hai người đó với nhau bằng cách sử dụng công nghệ blockchain của chúng tôi có thể tiết kiệm cho chính phủ rất nhiều tiền và giúp mọi thứ dễ dàng hơn cho người nhận, thậm chí cả dân làng sống trên các đỉnh núi Mông Cổ.

Other potential areas for Atala and Cardano include two very different sectors: the cashmere industry and university accreditation. They actually make about half of the worldâ€™s cashmere in Mongolia. The wool is very expensive in the boutiques of Tokyo and Paris, but goat herders here sell to China at a very bad price, thereâ€™s a potential to improve things there with better logistics and proof of sourcing. As for the universities, there are 65 of them in Mongolia, most of which are in Ulaanbaatar. We're really interested to see if we can put graduatesâ€™ diplomas up on a blockchain so people can prove they are qualified.

Các lĩnh vực tiềm năng khác cho Atala và Cardano bao gồm hai lĩnh vực rất khác nhau: công nghiệp cashmere và công nhận đại học.
Họ thực sự kiếm được khoảng một nửa số cashmere của thế giới ở Mông Cổ.
Len rất đắt tiền trong các cửa hàng của Tokyo và Paris, nhưng những người chăn dê ở đây được bán cho Trung Quốc với giá rất tệ, có một tiềm năng để cải thiện mọi thứ ở đó với hậu cần tốt hơn và bằng chứng tìm nguồn cung ứng.
Đối với các trường đại học, có 65 người trong số họ ở Mông Cổ, hầu hết trong số đó là ở Ulaanbaatar.
Chúng tôi thực sự quan tâm để xem liệu chúng tôi có thể đưa bằng tốt nghiệp lên một blockchain để mọi người có thể chứng minh rằng họ đủ điều kiện.

When it comes to attracting investment, the Asian Development Bank has put hundreds of millions of dollars in for various projects, but the audit trail is not so good here. We can tackle that.

Khi nói đến việc thu hút đầu tư, Ngân hàng Phát triển Châu Á đã đưa hàng trăm triệu đô la vào các dự án khác nhau, nhưng đường kiểm toán không tốt ở đây.
Chúng ta có thể giải quyết điều đó.

![Frontier Fintech summit in Ulaanbaatar](img/2019-05-16-mongolia-great-for-atala-and-cardano-pilots.010.jpeg) 

**Tsogtbaatar Damdin, Mongolia's foreign affairs minister,

** Tsogtbaatar Damdin, Bộ trưởng Ngoại giao Mông Cổ,

addresses the Frontier Fintech summit in Ulaanbaatar**

Địa chỉ Hội nghị thượng đỉnh Fintech Frontier ở Ulaanbaatar **

These are real, complicated situations, and the blockchain comes in as part of these solutions. Atala can be used for processing and aggregating the data, which can then be fed through to Cardano to handle ada payments â€“ so keeping huge volumes of data off the Cardano blockchain. 

Đây là những tình huống thực tế, phức tạp, và blockchain xuất hiện như một phần của các giải pháp này.
Atala có thể được sử dụng để xử lý và tổng hợp dữ liệu, sau đó có thể được cung cấp thông qua Cardano để xử lý các khoản thanh toán ADA - vì vậy hãy giữ khối lượng dữ liệu khổng lồ khỏi blockchain Cardano.

While we were in Mongolia, we attended the Frontier Fintech summit. It was there that we announced we had taken the first step of signing a memorandum of understanding with the Mongolian Blockchain Technology and Cryptocurrency Association, and the Mongolian Fintech Association to advise on potential blockchain projects and develop blockchain education, but itâ€™s early days. Building relationships, identifying the right partners and developing the technology and infrastructure takes time, so we need to be patient â€“ projects like these are likely to take between three and seven years. Thatâ€™s why education is such a central part of our mission, training people on the ground to build solid foundations, as weâ€™ve already done with our recent [Haskell course in Ethiopia](https://www.youtube.com/watch?v=1gOajpcPCH0&t=3s "IOHK Ethiopia Haskell Course, youtube.com").

Trong khi chúng tôi ở Mông Cổ, chúng tôi đã tham dự Hội nghị thượng đỉnh Fintech Frontier.
Đó là chúng tôi đã thông báo rằng chúng tôi đã thực hiện bước đầu tiên để ký một bản ghi nhớ với Hiệp hội công nghệ blockchain và tiền điện tử Mông Cổ, và Hiệp hội Fintech của người Mông Cổ để tư vấn về các dự án blockchain tiềm năng và phát triển giáo dục blockchain, nhưng đó là
.
Xây dựng mối quan hệ, xác định đúng đối tác và phát triển công nghệ và cơ sở hạ tầng cần có thời gian, vì vậy chúng ta cần phải kiên nhẫn - các dự án như thế này có thể mất từ ba đến bảy năm.
Đó là lý do tại sao giáo dục là một phần trung tâm của nhiệm vụ của chúng tôi, đào tạo mọi người trên mặt đất để xây dựng nền tảng vững chắc, vì chúng tôi đã thực hiện với [khóa học Haskell gần đây của chúng tôi ở Ethiopia] (https://www.youtube.
com/xem? V = 1GOAJPCPCH0 & T = 3S "IOHK ETHIOPIA HASKELL, youtube.com").

But providing solutions to these pressing problems is just the beginning. If we can get just one solution in place, we provide a gateway into the cryptocurrency ecosystem for hundreds of thousands of users. That expands the Cardano world, because these people will want insurance, bank transfers, and the other financial tools that we tend to take for granted in the developed world. And that creates business for the whole blockchain world.

Nhưng cung cấp các giải pháp cho những vấn đề cấp bách này chỉ là khởi đầu.
Nếu chúng tôi có thể chỉ có một giải pháp tại chỗ, chúng tôi cung cấp một cổng vào hệ sinh thái tiền điện tử cho hàng trăm ngàn người dùng.
Điều đó mở rộng thế giới Cardano, bởi vì những người này sẽ muốn bảo hiểm, chuyển khoản ngân hàng và các công cụ tài chính khác mà chúng ta có xu hướng được cấp trong thế giới phát triển.
Và điều đó tạo ra kinh doanh cho toàn bộ thế giới blockchain.

