# IOHK brings Plutus to Wyoming's hackathon
### **Cardano engineers introduce next phase of the smart contract platform to the Cowboy State**
![](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.002.png) 12 September 2019![](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.002.png)[ Eric Czuleger](tmp//en/blog/authors/eric-czuleger/page-1/)![](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.003.png) 3 mins read

![Eric Czuleger](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.004.png)[](tmp//en/blog/authors/eric-czuleger/page-1/)
### [**Eric Czuleger**](tmp//en/blog/authors/eric-czuleger/page-1/)
Senior Content Editor

Marketing & Communications

- ![](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.005.png)[](mailto:eric.czuleger@iohk.io "Email")
- ![](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.006.png)[](https://www.linkedin.com/in/eric-czuleger-6b67a395/ "LinkedIn")
- ![](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.007.png)[](https://twitter.com/eczuleger "Twitter")

![IOHK brings Plutus to Wyoming's hackathon](img/2019-09-12-iohk-brings-plutus-to-wyomings-hackathon.008.jpeg)

The state of Wyoming is famous for being part of the American frontier, but it has also established a new reputation, with blockchain pioneers blazing trails in the Cowboy State. But why Wyoming?

Bang bang Utah nổi tiếng là một phần của biên giới Mỹ, nhưng nó cũng đã thiết lập một danh tiếng mới, với những người tiên phong blockchain những con đường mòn rực rỡ ở bang Cowboy.
Nhưng tại sao Wyoming?

The blockchain revolution in Wyoming is the result of a series of laws and regulations passed within its borders. These key pieces of legislation include exemptions from money transmitting laws for virtual assets, as well as a blockchain â€˜sandboxâ€™ bill that would allow decentralized businesses to operate free from the red tape encountered elsewhere in the US. The state is also home to the Wyoming Blockchain Coalition, headed by former Wall Street corporate financier Caitlin Long, which has worked to make Wyoming the standard-bearer of blockchain in the country.

Cuộc cách mạng blockchain ở bang Utah là kết quả của một loạt các luật và quy định được thông qua trong biên giới của nó.
Những phần pháp luật quan trọng này bao gồm miễn trừ từ các luật truyền tiền cho tài sản ảo, cũng như một hóa đơn blockchain - Sandboxâ € ™ cho phép các doanh nghiệp phi tập trung hoạt động miễn phí từ băng đỏ gặp phải ở Mỹ.
Tiểu bang cũng là nơi có liên minh Blockchain ở bang Utah, đứng đầu là cựu nhà tài chính của công ty Phố Wall Caitlin Long, đã làm việc để biến bang Utah thành người mang tiêu chuẩn của blockchain trong nước.

In 2018, IOHK relocated its headquarters to Wyoming to take advantage of the stateâ€™s legislative embracing of distributed ledger technology, making it the biggest decentralized company in the state. As a result, IOHK has become a nexus for developers, crypto enthusiasts, businesses, and government officials in the area. Events like the 2019 WyoHackathon bring these groups together to advance the cutting edge of blockchain innovation.

Vào năm 2018, IOHK đã chuyển trụ sở chính của mình đến bang Utah để tận dụng lợi thế của công nghệ sổ cái phân tán của tiểu bang, khiến nó trở thành công ty phi tập trung lớn nhất trong tiểu bang.
Do đó, IOHK đã trở thành một mối quan hệ cho các nhà phát triển, những người đam mê tiền điện tử, doanh nghiệp và các quan chức chính phủ trong khu vực.
Các sự kiện như Wyohackathon 2019 mang các nhóm này lại với nhau để thúc đẩy sự tiến bộ của sự đổi mới blockchain.

â€˜Weâ€™re thrilled to welcome the Cardano community to this special event in IOHKâ€™s home state,â€™ says Caitlin Long. The event has also inspired a group of high school students from a remote part of Wyoming to make the journey to participate in the hackathon and meet IOHK CEO, Charles Hoskinson. â€˜There is something special building between the University of Wyoming computer science department and Cardano!â€™ she adds.

Caitlin Long cho biết: "
Sự kiện này cũng đã truyền cảm hứng cho một nhóm học sinh trung học từ một phần xa xôi của bang Utah để thực hiện hành trình tham gia Hackathon và gặp Giám đốc điều hành IOHK, Charles Hoskinson.
"Có một cái gì đó đặc biệt xây dựng giữa Khoa Khoa học Máy tính Đại học bang Utah và Cardano!" Cô nói thêm.

The hackathon will see hundreds of developers participating in workshops, presenting papers, and acquainting themselves with new technology. Charles Hoskinson and Cardanoâ€™s senior product manager David Esser will be among the speakers at the event, alongside prominent leaders in the blockchain industry such as Jesse Powell of Kraken and Anthony Pompliano of Morgan Creek Digital. September marks the second anniversary of the Cardano project and is a milestone for IOHK, with several major advances to Cardano being delivered. Plutus engineers Jann MÃ¼ller and Michael Peyton Jones will be at the event to explain how work on Cardano is progressing to create the ideal environment for smart contract development and execution.

Hackathon sẽ thấy hàng trăm nhà phát triển tham gia các hội thảo, trình bày các bài báo và làm quen với công nghệ mới.
David Hoskinson và quản lý sản phẩm cao cấp của Cardano, David Esser sẽ là một trong những diễn giả tại sự kiện này, cùng với các nhà lãnh đạo nổi tiếng trong ngành công nghiệp blockchain như Jesse Powell của Kraken và Anthony Pompompi của Morgan Creek Digital.
Tháng 9 đánh dấu kỷ niệm thứ hai của dự án Cardano và là một cột mốc quan trọng đối với IOHK, với một số tiến bộ lớn đối với Cardano được giao.
Các kỹ sư của Plutus Jann MÃ¼ller và Michael Peyton Jones sẽ có mặt tại sự kiện để giải thích cách thức hoạt động trên Cardano đang tiến triển để tạo ra môi trường lý tưởng để phát triển và thực hiện hợp đồng thông minh.

Last but certainly not least, the next iteration of the Plutus framework will be released during the hackathon. Plutus is a functional programming language and smart contract platform that allows developers of all kinds to launch smart contracts on the Cardano network. While Ethereum paved the way for programmable blockchains, it also has some significant barriers to entry. IOHK aims to bring greater scalability, sustainability, and interoperability to the crypto sphere by allowing anyone to build on a distributed ledger. Ultimately, it is developers that will build the businesses which will solve local and international problems. Plutus was created to enable those developers, and is supported by an IOHK-created [programming book](<https://www.amazon.com/Plutus-Writing-reliable-smart-contracts-ebook/dp/B07V46LWTW> "Plutus ebook on Amazon, amazon.com").

Cuối cùng nhưng chắc chắn không kém phần quan trọng, lần lặp tiếp theo của khung Plutus sẽ được phát hành trong hackathon.
Plutus là một ngôn ngữ lập trình chức năng và nền tảng hợp đồng thông minh cho phép các nhà phát triển các loại khởi động hợp đồng thông minh trên mạng Cardano.
Trong khi Ethereum mở đường cho các blockchain có thể lập trình, nó cũng có một số rào cản đáng kể để nhập cảnh.
IOHK nhằm mục đích mang lại khả năng mở rộng, tính bền vững và khả năng tương tác lớn hơn cho quả cầu tiền điện tử bằng cách cho phép bất cứ ai xây dựng trên một sổ cái phân tán.
Cuối cùng, chính các nhà phát triển sẽ xây dựng các doanh nghiệp sẽ giải quyết các vấn đề địa phương và quốc tế.
Plutus được tạo ra để cho phép các nhà phát triển đó và được hỗ trợ bởi một cuốn sách lập trình được tạo ra bởi iohk) (<https://www.amazon.com/plutus-writing-r đáng tin
Ebook trên Amazon, Amazon.com ").

Both Wyoming and IOHK have aligned their interests in supporting the next generation of thinkers in distributed ledger technology. Events like the hackathon help to inspire and elevate those who will build the decentralized infrastructure of the future. We hope that the 2019 WyoHackathon will be another pioneering step on the road towards better, more comprehensive adoption and use of both blockchain and crypto technology.

Cả bang Utah và IOHK đều phù hợp với lợi ích của họ trong việc hỗ trợ thế hệ nhà tư tưởng tiếp theo trong công nghệ sổ cái phân tán.
Các sự kiện như Hackathon giúp truyền cảm hứng và nâng cao những người sẽ xây dựng cơ sở hạ tầng phi tập trung trong tương lai.
Chúng tôi hy vọng rằng Wyohackathon 2019 sẽ là một bước tiên phong khác trên con đường hướng tới việc áp dụng tốt hơn, toàn diện hơn và sử dụng cả công nghệ blockchain và crypto.

*To find out more, check out the [WyoHackathon 2019 website](<https://wyohackathon.io/> "WyoHackathon 2019 website, wyohackathon.io").*

*Để tìm hiểu thêm, hãy xem trang web [WyoHackathon 2019] (<https://wyohackathon.io/> "Trang web của Wyohackathon 2019, WyoHackathon.io").*

