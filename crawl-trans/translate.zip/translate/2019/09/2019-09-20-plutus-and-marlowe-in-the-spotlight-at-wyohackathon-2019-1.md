# Plutus and Marlowe in the spotlight at WyoHackathon 2019
### **Plutus and Marlowe, IOHK's smart contract programming languages, will have their next generations released at the 2019 WyoHackathon**
![](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.002.png) 20 September 2019![](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.002.png)[ Eric Czuleger](tmp//en/blog/authors/eric-czuleger/page-1/)![](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.003.png) 4 mins read

![Eric Czuleger](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.004.png)[](tmp//en/blog/authors/eric-czuleger/page-1/)
### [**Eric Czuleger**](tmp//en/blog/authors/eric-czuleger/page-1/)
Senior Content Editor

Marketing & Communications

- ![](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.005.png)[](mailto:eric.czuleger@iohk.io "Email")
- ![](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.006.png)[](https://www.linkedin.com/in/eric-czuleger-6b67a395/ "LinkedIn")
- ![](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.007.png)[](https://twitter.com/eczuleger "Twitter")

![Plutus and Marlowe in the spotlight at WyoHackathon 2019](img/2019-09-20-plutus-and-marlowe-in-the-spotlight-at-wyohackathon-2019-1.008.jpeg)

The Cardano network was engineered to be the best possible foundation for the future of decentralized technology â€“ but a foundation is only as good as what can be built upon it. Smart contracts are one of the most powerful ways a distributed network can generate value, allowing individuals and organizations to agree to conditions and automatically execute exchanges of information and wealth, all in a trustless way without relying on third parties. But smart contracts are still code, which means that the languages and tools theyâ€™re written with make a difference to their final level of security, efficiency, and reliability.

Mạng Cardano được thiết kế để trở thành nền tảng tốt nhất có thể cho tương lai của công nghệ phi tập trung - nhưng một nền tảng chỉ tốt như những gì có thể được xây dựng trên nó.
Hợp đồng thông minh là một trong những cách mạnh mẽ nhất mà mạng phân tán có thể tạo ra giá trị, cho phép các cá nhân và tổ chức đồng ý với các điều kiện và tự động thực hiện trao đổi thông tin và sự giàu có, tất cả đều không đáng tin cậy mà không cần dựa vào bên thứ ba.
Nhưng các hợp đồng thông minh vẫn là mã, điều đó có nghĩa là các ngôn ngữ và công cụ mà chúng được viết với sự khác biệt với mức độ bảo mật, hiệu quả và độ tin cậy cuối cùng của chúng.

That said, understanding the potential of smart contracts is different from realizing their integration and adoption. Existing smart contract languages provide the basis for a solution, but are not the final answer. Current smart contracts are complex and difficult to program, partly because theyâ€™re built with languages created at the emergence of distributed technologies, and are vulnerable to malicious actors. Blockchain technology has changed drastically since it first emerged, and the conditions that underpinned the first languages are no longer true. The first answer to a problem is rarely the best, and any enterprise-focused solution cannot be gated by complexity or threaten network security.

Điều đó nói rằng, hiểu tiềm năng của các hợp đồng thông minh khác với việc thực hiện hội nhập và áp dụng của họ.
Ngôn ngữ hợp đồng thông minh hiện tại cung cấp cơ sở cho một giải pháp, nhưng không phải là câu trả lời cuối cùng.
Các hợp đồng thông minh hiện tại rất phức tạp và khó lập trình, một phần vì chúng được xây dựng với các ngôn ngữ được tạo ra khi xuất hiện các công nghệ phân tán và dễ bị tổn thương bởi các tác nhân độc hại.
Công nghệ blockchain đã thay đổi mạnh mẽ kể từ khi nó xuất hiện lần đầu tiên và các điều kiện được củng cố các ngôn ngữ đầu tiên không còn đúng nữa.
Câu trả lời đầu tiên cho một vấn đề hiếm khi là tốt nhất và bất kỳ giải pháp tập trung vào doanh nghiệp nào cũng không thể được kiểm soát bởi sự phức tạp hoặc đe dọa bảo mật mạng.

## **Bringing functional programming to smart contracts with Plutus**

## ** Đưa lập trình chức năng vào các hợp đồng thông minh với Plutus **

Weâ€™re big fans of functional programming here at IOHK and are proud to be able to say that the code underpinning the Cardano network is written in Haskell, the worldâ€™s foremost functional programming language. Plutus is no different. Compared to their object-oriented counterparts, functional programming languages are less prone to ambiguity and human error â€“ always a good thing â€“ as well as being easier to verify and test. By using Plutus to write smart contracts on the Cardano network, developers benefit from all of the above, as well as the ability to use the same language for both on and off-chain code.

Chúng tôi là những người hâm mộ lớn của chương trình chức năng tại IOHK và tự hào có thể nói rằng mã củng cố mạng Cardano được viết bằng Haskell, ngôn ngữ lập trình chức năng hàng đầu của thế giới.
Plutus không khác.
So với các đối tác hướng đối tượng của họ, các ngôn ngữ lập trình chức năng ít bị mơ hồ và lỗi của con người-luôn luôn là một điều tốt-cũng như dễ dàng xác minh và kiểm tra.
Bằng cách sử dụng Plutus để viết các hợp đồng thông minh trên mạng Cardano, các nhà phát triển được hưởng lợi từ tất cả các điều trên, cũng như khả năng sử dụng cùng một ngôn ngữ cho cả mã trên và ngoài chuỗi.

While developers will have to wait for the Goguen era to launch smart contracts on the Cardano network, they can begin testing their smart contract skills in the [Plutus Playground](https://testnet.iohkdev.io/plutus/tools/playground/ "Plutus Playground, testnet.iohkdev.io"). IOHK has also created a [Plutus ebook](https://www.amazon.co.uk/Plutus-Writing-reliable-smart-contracts-ebook/dp/B07V46LWTW "Plutus ebook, amazon.com") and [Udemy course](https://www.udemy.com/course/plutus-reliable-smart-contracts/ "Plutus Udemy course, udemy.com") to help developers hit the ground running once Plutus is available on the Cardano mainnet.

Mặc dù các nhà phát triển sẽ phải chờ ERA Goguen ra mắt các hợp đồng thông minh trên mạng Cardano, họ có thể bắt đầu thử nghiệm các kỹ năng hợp đồng thông minh của họ trong [Plutus Playground] (https://testnet.iohkdev.io/plutus/tools/playground/
"Plutus Playground, testnet.iohkdev.io").
IOHK cũng đã tạo ra một [Sách điện tử Plutus] (https://www.amazon.co.uk/plutus-writing-relle đáng tin cậy
] (https://www.udemy.com/cference/plutus-relle đáng tin cậy-smart-contracts/"PLUTUS UDEMY AUTUCE, UDEMY.com") để giúp các nhà phát triển lên mặt đất chạy một khi Plutus có sẵn trên Cardano Mainnet.

## **And bringing Plutus to everyone with Marlowe**

## ** và mang Plutus đến với mọi người với Marlowe **

The problem with smart contracts, however, is that sometimes the people who know how to write the code donâ€™t have the industry expertise to know how to structure the contracts themselves. Enter Marlowe, IOHKâ€™s domain-specific language (DSL). Marlowe is designed for use by anyone that wants to write a financial smart contract without the programming skills to implement it. Users can try out Marlowe via the [Marlowe Playground](https://testnet.iohkdev.io/marlowe/get-started/sample-marlowe-smart-contracts/ "Marlowe Playground, testnet.iohkdev.io"), a web utility with a user-friendly GUI and drag and drop components, where they can create financial smart contracts which, when complete, will generate fully-functional, implementation-ready Plutus code.

Tuy nhiên, vấn đề với các hợp đồng thông minh là đôi khi những người biết cách viết mã không có chuyên môn trong ngành để biết cách tự cấu trúc các hợp đồng.
Nhập Marlowe, Ngôn ngữ cụ thể miền (DSL) của IOHK.
Marlowe được thiết kế để sử dụng bởi bất kỳ ai muốn viết hợp đồng thông minh tài chính mà không có kỹ năng lập trình để thực hiện nó.
Người dùng có thể dùng thử Marlowe thông qua [Sân chơi Marlowe] (https://testnet.iohkdev.io/marlowe/get-started/sample-marlowe-smart-contracts
Tiện ích với GUI thân thiện với người dùng và các thành phần kéo và thả, nơi chúng có thể tạo ra các hợp đồng thông minh tài chính, khi hoàn thành, sẽ tạo ra mã Plutus sẵn sàng thực hiện đầy đủ chức năng.

Marlowe gives anyone the ability to gain familiarity with smart contracts while protecting them from unexpected outcomes. It also protects the developer and the system by ensuring that ill-formed smart contracts cannot be run. Finally, Marlowe focuses on commitment-of-funds and time-outs. These make certain that both parties have dedicated funds in the agreement while ensuring that money will not be left in the system after a contract has concluded.

Marlowe cung cấp cho bất cứ ai khả năng làm quen với các hợp đồng thông minh trong khi bảo vệ họ khỏi những kết quả bất ngờ.
Nó cũng bảo vệ nhà phát triển và hệ thống bằng cách đảm bảo rằng các hợp đồng thông minh không được hình thành không thể được chạy.
Cuối cùng, Marlowe tập trung vào cam kết và hết thời gian.
Những điều này chắc chắn rằng cả hai bên đều có tiền chuyên dụng trong thỏa thuận trong khi đảm bảo rằng tiền sẽ không bị bỏ lại trong hệ thống sau khi kết thúc hợp đồng.

## **Laying solid foundations**

## ** Laying Solid Foundations **

Plutus, Marlowe, and the Cardano ecosystem continue to evolve to provide the safest and most efficient conditions to build decentralized applications. The next generations of Plutus and Marlowe will be announced at the WyoHackathon at the University of Wyoming on September 20, ahead of their release on mainnet at the start of the Goguen era. Marlowe advances include a high-fidelity development system that aids the writing of executable contracts and the new iteration of Plutus will allow users to access their contracts from web or mobile applications. To get the latest news from the event, you can follow the [WyoHackathonâ€™s Twitter feed](https://twitter.com/hashtag/wyohackathon?lang=en "#wyohackathon, twitter.com").

Plutus, Marlowe và hệ sinh thái Cardano tiếp tục phát triển để cung cấp các điều kiện an toàn và hiệu quả nhất để xây dựng các ứng dụng phi tập trung.
Các thế hệ tiếp theo của Plutus và Marlowe sẽ được công bố tại Wyohackathon tại Đại học Wyoming vào ngày 20 tháng 9, trước khi họ phát hành trên Mainnet khi bắt đầu kỷ nguyên Goguen.
Các tiến bộ của Marlowe bao gồm một hệ thống phát triển có độ chính xác cao hỗ trợ việc viết các hợp đồng thực thi và phép lặp mới của Plutus sẽ cho phép người dùng truy cập hợp đồng của họ từ các ứng dụng web hoặc di động.
Để nhận được tin tức mới nhất từ sự kiện này, bạn có thể theo dõi nguồn cấp dữ liệu Twitter của WyoHackathon] (https://twitter.com/hashtag/wyohackathon?lang=en "#wyohackathon, twitter.com").

At IOHK, we're focused on creating the safest, most efficient platform for the building of decentralized applications. Plutus and Marlowe will be the first building blocks to be placed on the foundation which is the Cardano network â€“ and they won't be the last. With this new suite of accessible, inclusive tools, Cardano becomes more capable of serving the diverse audiences that stand to benefit from a secure, decentralized network platform.

Tại IOHK, chúng tôi tập trung vào việc tạo ra nền tảng an toàn nhất, hiệu quả nhất để xây dựng các ứng dụng phi tập trung.
Plutus và Marlowe sẽ là khối xây dựng đầu tiên được đặt trên nền tảng là mạng Cardano - và chúng sẽ không phải là người cuối cùng.
Với bộ công cụ toàn diện, có thể truy cập mới này, Cardano trở nên có khả năng phục vụ các đối tượng đa dạng, được hưởng lợi từ một nền tảng mạng an toàn, phi tập trung.

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons") [Stephen Walker](https://unsplash.com/photos/297SaBStwnQ)

[].

