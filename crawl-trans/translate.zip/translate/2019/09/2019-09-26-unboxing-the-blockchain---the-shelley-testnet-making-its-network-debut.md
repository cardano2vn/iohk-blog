# Unboxing the blockchain – the Shelley testnet making its network debut
### **After a successful test run in London, the networked testnet is now available to the community**
![](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.002.png) 26 September 2019![](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.003.png) 5 mins read

![Tim Harrison](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.008.png)[](https://github.com/timbharrison "GitHub")

![Unboxing the blockchain – the Shelley testnet making its network debut](img/2019-09-26-unboxing-the-blockchain---the-shelley-testnet-making-its-network-debut.009.jpeg)

Last week, a team from IOHK, along with Cardano ambassadors and representatives from the Cardano Foundation, met up at a co-working space in London. After a quick presentation, laptops were switched on and a few Rock Pi computers were booted up. An hour later, we had them all connected in a peer-to-peer network of nodes. It was the first instance of the [new networked Shelley testnet](https://www.youtube.com/watch?v=KIrhqbqiNLk), available for the community to join as of today.

Tuần trước, một nhóm từ IOHK, cùng với các đại sứ Cardano và đại diện của Quỹ Cardano, đã gặp nhau tại một không gian làm việc chung ở London.
Sau khi trình bày nhanh, máy tính xách tay đã được bật và một vài máy tính rock PI đã được khởi động.
Một giờ sau, chúng tôi đã kết nối tất cả chúng trong một mạng các nút ngang hàng.
Đó là trường hợp đầu tiên của [Shelley Testnet mới mạng] (https://www.youtube.com/watch?v=Kirhqbqinlk), có sẵn cho cộng đồng tham gia vào ngày hôm nay.

A recent post about the [Shelley testnet](https://iohk.io/blog/taking-the-next-step-on-the-road-to-cardano-shelley/ "Taking the next step on the road to Cardano Shelley, iohk.io") covered the journey from the self-node phase of the testnet until now. This new phase is the first decentralized implementation of the Ouroboros Genesis consensus algorithm. While it’s still early days, this is an important milestone for the Shelley era of Cardano. 

Một bài đăng gần đây về [Shelley Testnet] (https://iohk.io/blog/taking-the-next-pre
Shelley, iohk.io ") đã bao quát cuộc hành trình từ giai đoạn tự tự của testnet cho đến bây giờ.
Giai đoạn mới này là triển khai phi tập trung đầu tiên của thuật toán đồng thuận Genesis Ouroboros.
Trong khi nó vẫn còn những ngày đầu, đây là một cột mốc quan trọng đối với kỷ nguyên Shelley của Cardano.

The networked testnet phase allows IOHK – and more importantly, the community – to test the behavior of an Ouroboros-based decentralized network before making changes to mainnet. The current Cardano mainnet operates on a federated model, with all nodes in the network controlled by either the Cardano Foundation, IOHK, or EMURGO. As a project, the ultimate goal is complete decentralization, with the majority of nodes run by the community. Not only does that goal pose an engineering challenge, but the change must be sustainable for the network to flourish in the long term, so it has to be achieved in an incremental way.

Giai đoạn TestNet được nối mạng cho phép IOHK-và quan trọng hơn là cộng đồng-để kiểm tra hành vi của một mạng phi tập trung dựa trên Ouoboros trước khi thực hiện các thay đổi đối với Mainnet.
Cardano Mainnet hiện tại hoạt động trên một mô hình được liên kết, với tất cả các nút trong mạng được điều khiển bởi Quỹ Cardano, IOHK hoặc Emurgo.
Là một dự án, mục tiêu cuối cùng là hoàn toàn phân cấp, với phần lớn các nút do cộng đồng điều hành.
Mục tiêu đó không chỉ đặt ra một thách thức kỹ thuật, mà sự thay đổi phải bền vững để mạng phát triển trong dài hạn, do đó, nó phải đạt được một cách gia tăng.

After less than a year of development, debugging, and troubleshooting, the project is close to realizing complete network decentralization – but it can’t happen all at once. Steps are being taken to ensure this is done correctly. The 'private' network we initially set up in London allowed us to see the networked testnet operating in real-time, and to capture crucial information about its behavior in a live context.

Sau chưa đầy một năm phát triển, gỡ lỗi và khắc phục sự cố, dự án gần như hiện thực hóa sự phân cấp mạng hoàn chỉnh - nhưng nó có thể xảy ra cùng một lúc.
Các bước đang được thực hiện để đảm bảo điều này được thực hiện chính xác.
Mạng 'riêng tư' mà chúng tôi ban đầu thiết lập ở London cho phép chúng tôi thấy TestNet được nối mạng hoạt động trong thời gian thực và để nắm bắt thông tin quan trọng về hành vi của nó trong bối cảnh trực tiếp.

This network is being built for the real world, but the real world is unpredictable. By testing the network capabilities in different scenarios, it’s possible to learn more and account for a broader set of variables. To derive understanding from real-world scenarios, wider community participation is required.

Mạng lưới này đang được xây dựng cho thế giới thực, nhưng thế giới thực là không thể đoán trước.
Bằng cách kiểm tra các khả năng của mạng trong các kịch bản khác nhau, nó có thể tìm hiểu thêm và giải thích cho một bộ biến rộng hơn.
Để có được sự hiểu biết từ các kịch bản trong thế giới thực, cần có sự tham gia của cộng đồng rộng lớn hơn.

That’s where you come in. With the release of the networked testnet, we're inviting the community to help Cardano take things to the next level by running your own nodes and participating in the network. We encourage everyone to take part, and to help, we've made [documentation and instructions](https://testnet.iohkdev.io/cardano/shelley/ "Shelley Testnet Introduction, testnet.iohkdev.io") available to you.

Đó là nơi bạn đến. Với việc phát hành testnet được nối mạng, chúng tôi đang mời cộng đồng giúp Cardano đưa mọi thứ lên một tầm cao mới bằng cách chạy các nút của riêng bạn và tham gia vào mạng.
Chúng tôi khuyến khích tất cả mọi người tham gia và giúp đỡ, chúng tôi đã thực hiện [tài liệu và hướng dẫn] (https://testnet.iohkdev.io/cardano/shelley/ "Giới thiệu Shelley testnet, testnet.iohkdev.io") có sẵn cho bạn
.

We've already seen a brilliant response from the community during the self-node phase of the testnet. From today, we are inviting anyone who is interested to download and install the [latest version of the testnet node](https://github.com/input-output-hk/jormungandr/releases/ "Jormungandr GitHub repository releases page, github.com") and connect to the networked testnet.

Chúng tôi đã thấy một phản hồi tuyệt vời từ cộng đồng trong giai đoạn tự tự của testnet.
Từ hôm nay, chúng tôi đang mời bất kỳ ai quan tâm đến việc tải xuống và cài đặt [phiên bản mới nhất của nút Testnet] (https://github.com/input-output
.com ") và kết nối với testnet được nối mạng.

We want to collect performance data in all circumstances and multiple use cases. So try to run a node from your local coffee shop, see if it works with their proxy. Try it from the free hotel Wi-Fi. Check out how it reacts with the firewall. All this ‘real world’ data is useful and the more communication we get from our community, the better. We are not expecting full stability at this point; by putting the network through its paces, we can get there, faster.

Chúng tôi muốn thu thập dữ liệu hiệu suất trong mọi trường hợp và nhiều trường hợp sử dụng.
Vì vậy, hãy cố gắng chạy một nút từ quán cà phê địa phương của bạn, xem nó có hoạt động với proxy của họ không.
Hãy thử nó từ khách sạn miễn phí Wi-Fi.
Kiểm tra cách nó phản ứng với tường lửa.
Tất cả dữ liệu thế giới thực này là hữu ích và chúng ta càng có nhiều giao tiếp từ cộng đồng của chúng ta thì càng tốt.
Chúng tôi không mong đợi sự ổn định đầy đủ vào thời điểm này;
Bằng cách đưa mạng qua các bước đi của nó, chúng ta có thể đến đó, nhanh hơn.

The Cardano ecosystem is built to be a community-focused decentralized network. As Shelley approaches, the ambassadors and supporters are integral to working through upcoming challenges, alongside technical support from the IOHK team. We expect instability in any testnet. There will be outages and lag in the network at the beginning, but that is inherent to all new platforms. With every iteration, we lay a stronger foundation for the future.

Hệ sinh thái Cardano được xây dựng để trở thành một mạng lưới phi tập trung tập trung vào cộng đồng.
Khi Shelley đến gần, các đại sứ và người ủng hộ không thể thiếu để làm việc thông qua các thử thách sắp tới, bên cạnh sự hỗ trợ kỹ thuật từ nhóm IOHK.
Chúng tôi mong đợi sự bất ổn trong bất kỳ testnet.
Sẽ có sự cố mất điện và tụt hậu trong mạng lúc đầu, nhưng đó là vốn có của tất cả các nền tảng mới.
Với mỗi lần lặp lại, chúng tôi đặt một nền tảng mạnh mẽ hơn cho tương lai.

There will continue to be regular updates in the [Jörmungandr GitHub repository](https://github.com/input-output-hk/jormungandr/releases/ "Jormungandr GitHub repository, github.com"), where you can download the latest release of the testnet code. This codebase will be iterated on and improved over time based on bug reports and user feedback, with the goal of making the network as robust as possible before we move towards phase three of the rollout later this year: the incentivized testnet.

Sẽ tiếp tục có các bản cập nhật thường xuyên trong kho lưu trữ [Jörmungandr GitHub] (https://github.com/input-output
Phát hành mã TestNet.
Cơ sở mã này sẽ được lặp đi lặp lại và cải thiện theo thời gian dựa trên các báo cáo lỗi và phản hồi của người dùng, với mục tiêu làm cho mạng trở nên mạnh mẽ nhất có thể trước khi chúng tôi chuyển sang giai đoạn ba của buổi giới thiệu vào cuối năm nay: Testnet được khuyến khích.

We’ll be keeping a close eye on how the network behaves over the next few days. The focus, for now, is on stabilization, so you can expect to see some ups and downs. Please make sure you continue to log issues in the [dedicated GitHub repository](https://github.com/input-output-hk/shelley-testnet/issues "Shelley testnet issues GitHub repository, github.com") and we’ll get to them. As this phase progresses, we’ll start sharing further documentation and content which will walk you through more advanced functionality, and set some tasks you can experiment with.

Chúng tôi sẽ theo dõi sát sao cách mạng hoạt động trong vài ngày tới.
Trọng tâm, hiện tại, là về sự ổn định, vì vậy bạn có thể mong đợi để thấy một số thăng trầm.
Vui lòng đảm bảo rằng bạn tiếp tục đăng nhập các vấn đề vào [Kho lưu trữ GitHub chuyên dụng] (https://github.com/input-oundput-hk/shelley-testnet
Tôi sẽ nhận được họ.
Khi giai đoạn này tiến triển, chúng tôi sẽ bắt đầu chia sẻ tài liệu và nội dung tiếp theo sẽ hướng dẫn bạn qua chức năng nâng cao hơn và đặt một số nhiệm vụ bạn có thể thử nghiệm.

Launching the first private decentralized testnet was like rolling a small snowball down a mountain. It’s only going to get bigger from here. Cardano is growing, picking up speed, and moving closer to IOHK’s vision of a decentralized future. We want you to become a part of that growth. Click [here](https://testnet.iohkdev.io/cardano/shelley/get-started/configuring-your-network/ "Configuring your network, testnet.iohkdev.io") to launch your own node and join us.

Ra mắt Testnet phi tập trung đầu tiên giống như lăn một quả cầu tuyết nhỏ xuống một ngọn núi.
Nó chỉ có thể lớn hơn từ đây.
Cardano đang phát triển, tăng tốc và tiến gần hơn đến tầm nhìn của IOHK về một tương lai phi tập trung.
Chúng tôi muốn bạn trở thành một phần của sự tăng trưởng đó.
Nhấp vào [tại đây] (https://testnet.iohkdev.io/cardano/shelley/get-started/configuring-your-network/ "Định cấu hình mạng của bạn, testnet.iohkdev.io") để khởi chạy nút của riêng bạn và tham gia chúng tôi.

