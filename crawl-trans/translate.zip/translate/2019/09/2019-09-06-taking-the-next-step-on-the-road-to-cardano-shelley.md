# Taking the next step on the road to Cardano Shelley
### **Networking coming to Jörmungandr testnet in September, paving the way for stake delegation and real ada incentives later this year. Piece written in collaboration with Eric Czuleger and Tim Harrison.**
![](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.002.png) 6 September 2019![](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.002.png)[ Nicolas Di Prima](tmp//en/blog/authors/nicolas-di-prima/page-1/)![](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.003.png) 4 mins read

![Nicolas Di Prima](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.004.png)[](tmp//en/blog/authors/nicolas-di-prima/page-1/)
### [**Nicolas Di Prima**](tmp//en/blog/authors/nicolas-di-prima/page-1/)
Software Engineer

Engineering

- ![](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.005.png)[](https://www.linkedin.com/in/nicolas-di-prima-1b97224b/?locale=en_US "LinkedIn")
- ![](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.006.png)[](https://twitter.com/nicolasdiprima "Twitter")
- ![](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.007.png)[](https://github.com/nicolasdp "GitHub")

![Taking the next step on the road to Cardano Shelley](img/2019-09-06-taking-the-next-step-on-the-road-to-cardano-shelley.008.jpeg)

Imagine a blockchain that can connect the world, yet doesn’t need to consume the same amount of energy as Denmark. A currency where the bookkeepers are also the users. A cryptocurrency that is truly decentralized. Jörmungandr is not only a [big mean serpent](https://en.wikipedia.org/wiki/J%C3%B6rmungandr), but also the serpent that in ancient myth holds the waters of the world together. It is global, and it surrounds the earth and every one of its inhabitants. Similarly, the Shelley testnet program and its Rust node (codenamed Jörmungandr) has been designed to connect people from all around the world.

Hãy tưởng tượng một blockchain có thể kết nối thế giới, nhưng không cần phải tiêu thụ cùng một lượng năng lượng như Đan Mạch.
Một loại tiền tệ mà các nhân viên kế toán cũng là người dùng.
Một loại tiền điện tử thực sự là phi tập trung.
Jörmungandr không chỉ là [con rắn trung bình lớn] (https://en.wikipedia.org/wiki/J%C3%B6rmungandr), mà còn là con rắn trong huyền thoại cổ đại giữ nước trên thế giới.
Nó là toàn cầu, và nó bao quanh trái đất và mọi cư dân của nó.
Tương tự, chương trình Shelley Testnet và Node Rust của nó (có tên mã Jörmungandr) đã được thiết kế để kết nối mọi người từ khắp nơi trên thế giới.

In June, we delivered the first testnet build of Jörmungandr. This ‘self-node’ phase was focused on the single instance implementation, to refine the codebase and ensure that it was robust. It was important to get non-network functionality right before starting the next phase, but we also wanted to provide some of the core network protocols in that early code (hence calling it ‘blockchain in a box’). We’ve had some excellent support from the community, especially the folks on the [Stakepool Telegram channel](https://t.me/CardanoStakePoolWorkgroup). Every piece of feedback has helped us improve the protocol, the ledger, and the node itself. 

Vào tháng 6, chúng tôi đã cung cấp bản dựng Testnet đầu tiên của Jörmungandr.
Giai đoạn ‘bản thân nút này đã tập trung vào việc triển khai một trường hợp duy nhất, để tinh chỉnh cơ sở mã và đảm bảo rằng nó mạnh mẽ.
Điều quan trọng là phải có chức năng không mạng ngay trước khi bắt đầu giai đoạn tiếp theo, nhưng chúng tôi cũng muốn cung cấp một số giao thức mạng cốt lõi trong mã sớm đó (do đó gọi nó là ‘blockchain trong một hộp).
Chúng tôi đã có một số hỗ trợ tuyệt vời từ cộng đồng, đặc biệt là những người trên [Kênh Telegram Stakepool] (https://t.me/cardanostakepoolworkgroup).
Mỗi phần phản hồi đã giúp chúng tôi cải thiện giao thức, sổ cái và chính nút.

It was also a good opportunity for people to test and experiment with the interfaces and the software development kit (SDK). We released the first version at the end of last month and thanks to your feedback and contribution, it is continuously being improved, adding in more features than ever. We will soon be adding new working examples to showcase what can be done with the SDK. We believe these can provide important starting points for great community-driven projects.

Đó cũng là một cơ hội tốt để mọi người kiểm tra và thử nghiệm với các giao diện và Bộ phát triển phần mềm (SDK).
Chúng tôi đã phát hành phiên bản đầu tiên vào cuối tháng trước và nhờ phản hồi và đóng góp của bạn, nó liên tục được cải thiện, thêm vào nhiều tính năng hơn bao giờ hết.
Chúng tôi sẽ sớm thêm các ví dụ làm việc mới để giới thiệu những gì có thể được thực hiện với SDK.
Chúng tôi tin rằng những điều này có thể cung cấp điểm khởi đầu quan trọng cho các dự án hướng đến cộng đồng tuyệt vời.

## **Joining up the network**

## ** Tham gia mạng **

As Charles outlined in his [recent AMA](https://youtu.be/bmkQDlhsNGc?t=104), we will soon enter Phase 2 of the testnet rollout: network implementation. Now that the node is more stable, we can challenge the network stack to see how it holds up and check how our predictions on its behavior measure up. And that means more experimentation with the community, with you.

Như Charles đã vạch ra trong [AMA gần đây] của mình (https://youtu.be/bmkqdlhsngc?t=104), chúng tôi sẽ sớm bước vào Giai đoạn 2 của TestNet Relowlout: Triển khai mạng.
Bây giờ nút ổn định hơn, chúng ta có thể thách thức ngăn xếp mạng để xem cách thức giữ và kiểm tra cách dự đoán của chúng ta về hành vi của nó đo lường.
Và điều đó có nghĩa là thử nghiệm nhiều hơn với cộng đồng, với bạn.

Throughout this testnet program, the approach has been steady and methodical. Similarly, networking rollout will start gradually, working closely with the stake pool task force to identify and address any initial bugs or code irregularities. Meanwhile, we’ll be creating some documentation to help everyone get involved. As ever, you’ll be able to track our progress via GitHub and download early code if you'd like. Once we have established a network of nodes stable enough for open experimentation, we’ll encourage everyone to join in.

Trong suốt chương trình TestNet này, cách tiếp cận đã ổn định và có phương pháp.
Tương tự, triển khai mạng sẽ bắt đầu dần dần, làm việc chặt chẽ với Lực lượng đặc nhiệm nhóm cổ phần để xác định và giải quyết bất kỳ lỗi ban đầu hoặc mã bất thường.
Trong khi đó, chúng tôi sẽ tạo ra một số tài liệu để giúp mọi người tham gia.
Như mọi khi, bạn sẽ có thể theo dõi tiến trình của chúng tôi thông qua GitHub và tải xuống mã sớm nếu bạn muốn.
Khi chúng tôi đã thiết lập một mạng lưới các nút đủ ổn định để thử nghiệm mở, chúng tôi sẽ khuyến khích mọi người tham gia.

Again, the goal here is to test and iterate until we are confident we have a stable network. Your support and feedback during this process will be invaluable – whether you are there from the beginning or choose to join the network phase later on. 

Một lần nữa, mục tiêu ở đây là kiểm tra và lặp lại cho đến khi chúng tôi tự tin rằng chúng tôi có một mạng ổn định.
Hỗ trợ và phản hồi của bạn trong quá trình này sẽ là vô giá - cho dù bạn ở đó ngay từ đầu hoặc chọn tham gia giai đoạn mạng sau này.

## **Adding incentives to the testnet**

## ** Thêm ưu đãi cho TestNet **

When Phase 2 is complete, we will have a stable network: a decentralized testnet platform running across multiple nodes. Then we will commence the third and final phase, the incentivized testnet. 

Khi giai đoạn 2 hoàn tất, chúng tôi sẽ có một mạng ổn định: một nền tảng TestNet phi tập trung chạy trên nhiều nút.
Sau đó, chúng tôi sẽ bắt đầu giai đoạn thứ ba và cuối cùng, Testnet được khuyến khích.

In reality, this is more than a testnet. Instead, it will effectively be a replica of the Cardano mainnet. We will take a UTXO snapshot of the mainnet state and migrate it to the testnet, offering Shelley era functionality within a controlled, sandboxed environment. This will be different from a typical testnet, however, since it will offer real rewards for delegating your ada stake. Jörmungandr will be decentralized, and users will be able to create stake pools or delegate their stake to a stake pool and collect their rewards. We’ll be sure to bring you further details of how this will all work a little further down the line. 

Trong thực tế, đây là nhiều hơn một testnet.
Thay vào đó, nó thực sự sẽ là một bản sao của Cardano Mainnet.
Chúng tôi sẽ chụp ảnh chụp nhanh UTXO của trạng thái chính và di chuyển nó đến TestNet, cung cấp chức năng ERA Shelley trong một môi trường được kiểm soát, hộp cát.
Tuy nhiên, điều này sẽ khác với TestNet điển hình, vì nó sẽ cung cấp phần thưởng thực sự cho việc ủy thác cổ phần ADA của bạn.
Jörmungandr sẽ được phân cấp và người dùng sẽ có thể tạo nhóm cổ phần hoặc ủy thác cổ phần của họ cho một nhóm cổ phần và thu thập phần thưởng của họ.
Chúng tôi chắc chắn sẽ mang đến cho bạn thêm chi tiết về cách tất cả điều này sẽ hoạt động xa hơn một chút.

Once we are happy the protocol is stable enough to survive the harsh competition of the real world, we will merge the incentivized testnet rewards back into the Cardano mainnet. All the rewards generated during the Jörmungandr incentivized testnet will become real, live, spendable ada on the Cardano mainnet (so don't lose the mnemonics of your stake keys!).  Doing it this way will give us a realistic test of how the incentives model drives stakeholder and stake pool behavior, not to mention that stakeholders will be able to start getting rewards for holding their ada.

Một khi chúng tôi hạnh phúc, giao thức đủ ổn định để tồn tại cuộc thi khắc nghiệt của thế giới thực, chúng tôi sẽ hợp nhất phần thưởng Testnet được khuyến khích trở lại vào Cardano Mainnet.
Tất cả các phần thưởng được tạo ra trong TestNet được khuyến khích Jörmungandr sẽ trở thành ADA có thật, trực tiếp, có thể chi tiêu trên Cardano Mainnet (vì vậy đừng mất các bản mnemonics của các khóa cổ phần của bạn!).
Làm theo cách này sẽ cho chúng ta một bài kiểm tra thực tế về cách các mô hình ưu đãi thúc đẩy các bên liên quan và hành vi của nhóm cổ phần, chưa kể rằng các bên liên quan sẽ có thể bắt đầu nhận phần thưởng cho việc giữ ADA của họ.

Cardano has a very exciting few months ahead – we’re looking forward to you joining us on the journey.

Cardano có một vài tháng rất thú vị phía trước - chúng tôi mong muốn bạn tham gia cùng chúng tôi trên hành trình.

If you are interested in running a stake pool and would like to get the very latest news on the testnet program, you can sign up for our weekly report newsletter by visiting the form [here](https://forms.gle/JqPjdMkR58tzj4Mn6). Or just visit the Cardano Forum where you’ll find [progress updates](https://forum.cardano.org/t/shelley-testnet-your-weekly-rollout-rollup-week-ten-w-e-30th-august-2019/26154) every week. 

Nếu bạn quan tâm đến việc điều hành một nhóm cổ phần và muốn nhận được tin tức mới nhất về chương trình TestNet, bạn có thể đăng ký nhận bản tin báo cáo hàng tuần của chúng tôi bằng cách truy cập biểu mẫu [tại đây] (https://forms.gle/jqpjdmkr58tzj4mn6)
.
Hoặc chỉ cần truy cập diễn đàn Cardano nơi bạn sẽ tìm thấy [Cập nhật tiến độ] (https://forum.cardano.org/t/shelley-testnet-your-weekly-rollout-rollup-week-ten-w-e30th-maugust-
2019/26154) mỗi tuần.

