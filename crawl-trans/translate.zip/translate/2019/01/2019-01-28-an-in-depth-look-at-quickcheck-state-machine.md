# An in-depth look at quickcheck-state-machine
![](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.002.png) 28 January 2019![](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.002.png)[ Edsko de Vries](tmp//en/blog/authors/edsko-de-vries/page-1/)![](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.003.png) 46 mins read

![Edsko de Vries](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.004.png)[](tmp//en/blog/authors/edsko-de-vries/page-1/)
### [**Edsko de Vries**](tmp//en/blog/authors/edsko-de-vries/page-1/)
Software Engineer

Well-Typed

- ![](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.005.png)[](http://www.linkedin.com/in/edsko-de-vries-04126b31 "LinkedIn")
- ![](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.006.png)[](https://twitter.com/EdskoDeVries "Twitter")
- ![](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.007.png)[](https://github.com/edsko "GitHub")

![An in-depth look at quickcheck-state-machine](img/2019-01-28-an-in-depth-look-at-quickcheck-state-machine.008.jpeg)

*Please note: this post originally appeared on the [Well-Typed blog](http://www.well-typed.com/blog/2019/01/qsm-in-depth/ "An in-depth look at quickcheck-state-machine, well-typed.com").* Stateful APIs are everywhere: file systems, databases, widget libraries, the list goes on. Automated testing of such APIs requires generating sequences of API calls, and when we find a failing test, ideally *shrinking* such a sequence to a minimal test case. Neither the generation nor the shrinking of such sequences is trivial. After all, it is the very nature of stateful systems that later calls may depend on earlier calls: we can only add rows to a database table after we create it, we can only write to a file after we open it, etc. Such dependencies need to be tracked carefully. Moreover, in order to verify the responses we get back from the system, the test needs to maintain some kind of internal representation of what it thinks the internal state of the system is: when we read from a file, we need to know what was in the file in order to be able to verify if the response was correct or not.

*Xin lưu ý: Bài đăng này ban đầu xuất hiện trên [blog được đánh giá tốt] (http://www.well-typed.com/blog/2019/01/qsm-in-depth/ "Một cái nhìn sâu sắc về QuickCheck- Trạng thái-machine, tốt xép.com ").* API trạng thái ở khắp mọi nơi: Hệ thống tệp, cơ sở dữ liệu, thư viện tiện ích, danh sách tiếp tục. Kiểm tra tự động các API như vậy đòi hỏi phải tạo các chuỗi các cuộc gọi API và khi chúng tôi tìm thấy một bài kiểm tra thất bại, lý tưởng là * thu hẹp * một chuỗi như vậy cho một trường hợp thử nghiệm tối thiểu. Cả thế hệ và sự thu hẹp của các chuỗi như vậy là tầm thường. Rốt cuộc, chính bản chất của các hệ thống trạng thái mà các cuộc gọi sau này có thể phụ thuộc vào các cuộc gọi trước đó: chúng ta chỉ có thể thêm các hàng vào bảng cơ sở dữ liệu sau khi chúng ta tạo nó, chúng ta chỉ có thể ghi vào một tệp sau khi chúng ta mở nó, v.v. cần được theo dõi cẩn thận. Hơn nữa, để xác minh các câu trả lời mà chúng tôi lấy lại từ hệ thống, bài kiểm tra cần duy trì một số loại biểu diễn bên trong của những gì nó nghĩ là trạng thái bên trong của hệ thống là: khi chúng ta đọc từ một tệp, chúng ta cần biết những gì Trong tệp để có thể xác minh xem phản hồi có chính xác hay không.

In this blog post we will take an in-depth look at [quickcheck-state-machine](http://hackage.haskell.org/package/quickcheck-state-machine "quickcheck-state-machine, hackage.haskell.org"), a library for testing stateful code. Our running example will be the development of a simple mock file system that should behave identically to a real file system. Although simple, the example will be large enough to give us an opportunity to discuss how we can verify that our generator is producing all test cases we need, and how we can inspect whether the shrinker is doing a good job; in both cases, test case labelling will turn out to be essential. Throughout we will also discuss design patterns for quickcheck-state-machine tests which improve separation of concerns and reduce duplication. It should probably be pointed out that this is an opinionated piece: there are other ways to set things up than we present here.

Trong bài đăng trên blog này, chúng tôi sẽ xem xét sâu về [QuickCheck-State-Machine] (http://hackage.haskell.org/package/quickcheck-tate-machine "QuickCheck-state-machine, hackage.haskell.org
"), một thư viện để kiểm tra mã trạng thái.
Ví dụ chạy của chúng tôi sẽ là sự phát triển của một hệ thống tệp giả đơn giản sẽ hoạt động giống hệt với một hệ thống tệp thực.
Mặc dù đơn giản, ví dụ sẽ đủ lớn để cho chúng ta cơ hội thảo luận về cách chúng ta có thể xác minh rằng trình tạo của chúng ta đang sản xuất tất cả các trường hợp thử nghiệm chúng ta cần và làm thế nào chúng ta có thể kiểm tra xem liệu bộ thu nhỏ có đang làm tốt công việc hay không;
Trong cả hai trường hợp, ghi nhãn trường hợp kiểm tra sẽ trở nên cần thiết.
Xuyên suốt, chúng tôi cũng sẽ thảo luận về các mẫu thiết kế cho các thử nghiệm máy ảnh phía trước của que-máy để cải thiện việc tách các mối quan tâm và giảm trùng lặp.
Có lẽ nên chỉ ra rằng đây là một phần có ý kiến: có nhiều cách khác để thiết lập mọi thứ hơn chúng ta trình bày ở đây.

We will not show the full development in this blog post, and instead focus on explaining the underlying concepts. If you want to follow along, the code is [available for download](https://github.com/well-typed/qsm-in-depth "qsm-in-depth, github.com"). We will assume [version 0.6 of quickcheck-state-machine](http://hackage.haskell.org/package/quickcheck-state-machine-0.6.0 "0.6 quickcheck-state-machine, hackage.haskell.org"), which was recently released. If you are using an older version, it is recommended to upgrade, since the newer version includes some important bug fixes, especially in the shrinker.

Chúng tôi sẽ không thể hiện sự phát triển đầy đủ trong bài đăng trên blog này, và thay vào đó tập trung vào việc giải thích các khái niệm cơ bản.
Nếu bạn muốn theo dõi, mã có sẵn để tải xuống] (https://github.com/well-typed/qsm-in-depth "Qsm-in-depth, github.com").
Chúng tôi sẽ giả sử [Phiên bản 0.6 của QuickCheck-State-Machine] (http://hackage.haskell.org/package/quickcheck-tate-machine-0.6.0 "0.6 QuickCheck-State-Machine, hackage.haskell.org")
, được phát hành gần đây.
Nếu bạn đang sử dụng một phiên bản cũ hơn, nên nâng cấp, vì phiên bản mới hơn bao gồm một số bản sửa lỗi quan trọng, đặc biệt là trong bộ thu nhỏ.

## **Introducing the running example**

## ** Giới thiệu ví dụ đang chạy **

Our running example will be the development of a simple mock file system; the intention is that its behaviour is identical to the real file system, within the confines of what it needs to support. We will represent the state of the file system as

Ví dụ chạy của chúng tôi sẽ là sự phát triển của một hệ thống tệp giả đơn giản;
Mục đích là hành vi của nó giống hệt với hệ thống tệp thực, trong giới hạn của những gì nó cần để hỗ trợ.
Chúng tôi sẽ đại diện cho trạng thái của hệ thống tệp là

data Mock = M {

data mock = m {

`    `dirs  :: Set Dir

`` Dirs :: Set Dir

`  `, files :: Map File String

``, File :: Chuỗi tệp bản đồ

`  `, open  :: Map MHandle File

``, mở :: Bản đồ tệp MHandle

`  `, next  :: MHandle

``, tiếp theo :: mhandle

`  `}

``}

type MHandle = Int

gõ mHandle = int

emptyMock :: Mock

trống rỗng :: Mock

emptyMock = M (Set.singleton (Dir [])) Map.empty Map.empty 0

trốngMock = m (set.singleton (dir [])) map.empty map.empty 0

We record which directories (folders) exist, the contents of all files on the system, the currently open handles (where mock handles are just integers), and the next available mock handle. To avoid confusion between files and directories we do not use FilePath but instead use

Chúng tôi ghi lại những thư mục (thư mục) tồn tại, nội dung của tất cả các tệp trên hệ thống, tay cầm hiện đang mở (trong đó tay cầm giả chỉ là số nguyên) và tay cầm giả tiếp theo.
Để tránh sự nhầm lẫn giữa các tệp và thư mục, chúng tôi không sử dụng filepath mà thay vào đó hãy sử dụng

data Dir  = Dir [String]

Dữ liệu DIR = DIR [Chuỗi]

data File = File {dir :: Dir, name :: String}

Tệp dữ liệu = Tệp {dir :: Dir, name :: String}

As one example, here is the mock equivalent of readFile:

Như một ví dụ, đây là sự giả tương đương của readfile:

type MockOp a = Mock -> (Either Err a, Mock)

gõ mockop a = mock -> (hoặc err a, mock)

mRead :: File -> MockOp String

Đọc :: Tệp -> Chuỗi mockup

mRead f m@(M \_ fs hs \_)

Mread F M@(M \ _ FS HS \ _)

`  `| alreadyOpen               = (Left Busy         , m)

`` |
đã open = (bận rộn, m)

`  `| Just s <- Map.lookup f fs = (Right s           , m)

`` |
Chỉ s <- map.lookup f fs = (phải s, m)

`  `| otherwise                 = (Left DoesNotExist , m)

`` |
Nếu không = (bên trái không phải là chủ nghĩa, m)

`  `where

`` Ở đâu

`    `alreadyOpen = f `List.elem` Map.elems hs

``

We first check if there is an open handle to the file; if so, we disallow reading this file (â€œresource busyâ€); if the file exists, we return its content; otherwise we report a â€œdoes not existâ€ error. The implementation of the other mock functions is similar; the full API is

Trước tiên chúng tôi kiểm tra xem có một tay cầm mở cho tệp;
Nếu vậy, chúng tôi không cho phép đọc tập tin này ("Nguồn gốc bận rộn");
Nếu tệp tồn tại, chúng tôi trả về nội dung của nó;
Nếu không, chúng tôi báo cáo một lỗi không tồn tại.
Việc thực hiện các chức năng giả khác là tương tự;
API đầy đủ là

mMkDir :: Dir               -> MockOp ()

mkdir :: dir -> mockup ()

mOpen  :: File              -> MockOp MHandle

Mở :: Tệp -> Tay cầm mockup

mWrite :: MHandle -> String -> MockOp ()

Viết :: Xử lý -> Chuỗi -> Mockup ()

mClose :: MHandle           -> MockOp ()

Đóng :: Xử lý -> mockup ()

mRead  :: File              -> MockOp String

Đọc :: Tệp -> Chuỗi mockup

Finally, we should briefly talk about errors; the errors that the mock file system can report are given by

Cuối cùng, chúng ta nên nói ngắn gọn về các lỗi;
các lỗi mà hệ thống tệp giả có thể báo cáo được đưa ra bởi

data Err = AlreadyExists | DoesNotExist | HandleClosed | Busy

Lỗi dữ liệu = đã tồn tại |
Không tồn tại |
Xử lý đóng |
Bận

and they capture a subset of the IO exceptions

và họ nắm bắt một tập hợp các ngoại lệ IO

[](#1)

[] (#1)

1

1

fromIOError :: IOError -> Maybe Err

fromioerror :: ioerror -> có thể sai lầm

fromIOError e =

Fromioerror E =

`    `case ioeGetErrorType e of

`` Case IoEGetErrortype E của

`      `GHC.AlreadyExists    -> Just AlreadyExists

`` GHC.AlReadyExists -> Chỉ là những người theo chủ nghĩa

`      `GHC.NoSuchThing      -> Just DoesNotExist

`` Ghc.nosuchthing -> chỉ là người theo chủ nghĩa

`      `GHC.ResourceBusy     -> Just Busy

`` Ghc.resourcebusy -> Chỉ bận rộn

`      `GHC.IllegalOperation -> Just HandleClosed

`` GHC.ILLEGALOPERION -> Chỉ cần xử lý

`      `\_otherwise           -> Nothing

`` \ _Therwise -> Không có gì

## **Testing**

## ** Kiểm tra **

Typically we are developing some stateful code, and then write a pure (mock) implementation of the same thing to test it, making sure that the stateful implementation and the simpler pure model compute the same things. Here we are doing the opposite: we are adjusting the model (the mock file system) to match what the real file system does. Either way, the process is the same: we write tests, execute them both in the real thing and in the model, and compare results.

Thông thường, chúng tôi đang phát triển một số mã trạng thái, và sau đó viết một triển khai thuần túy (giả) của cùng một điều để kiểm tra nó, đảm bảo rằng việc triển khai trạng thái và mô hình thuần túy đơn giản hơn tính toán những điều tương tự.
Ở đây chúng tôi đang thực hiện ngược lại: chúng tôi đang điều chỉnh mô hình (hệ thống tệp giả) để phù hợp với những gì hệ thống tệp thực làm.
Dù bằng cách nào, quá trình này là như nhau: chúng tôi viết các bài kiểm tra, thực hiện cả hai trong thực tế và trong mô hình và so sánh kết quả.

If we were writing unit tests, we might write tests such as

Nếu chúng tôi viết bài kiểm tra đơn vị, chúng tôi có thể viết các bài kiểm tra như

- Write to two different files

- Viết cho hai tệp khác nhau

- Write to a file and then read it

- Viết vào một tệp và sau đó đọc nó

- etc.

- vân vân.

However, as John Hughes of QuviQ â€“ and one of the original authors of QuickCheck â€“ [likes to point out](http://www.quviq.com/more-thorough-testing/ "quviq.com"), as systems grow, it becomes impossible to write unit tests that test the interaction between all the features of the system. So, *donâ€™t write unit tests*. Instead, *generate* tests, and verify *properties*.

Tuy nhiên, như John Hughes của Quviq-và một trong những tác giả gốc của QuickCheck-[Thích chỉ ra] (http://www.quviq.com/more-thorough-testing/ "quviq.com")
, khi các hệ thống phát triển, không thể viết các bài kiểm tra đơn vị kiểm tra sự tương tác giữa tất cả các tính năng của hệ thống.
Vì vậy, *không viết bài kiểm tra đơn vị *.
Thay vào đó, *tạo *kiểm tra *và xác minh *thuộc tính *.

To generate tests for our mock file system, we have to generate sequences of calls into the API; *â€œopen this file, open that file, write to the first file we opened, â€¦â€*. We then execute this sequence both against the mock file system and against the real thing, and compare results. If something goes wrong, we end up with a test case that we can inspect. Ideally, we should then try to reduce this test to try and construct a *minimal* test case that illustrates the bug. We have to be careful when shrinking: for example, when we remove a call to open from a test case, then any subsequent writes that used that file handle must also be removed. A library such as quickcheck-state-machine can be used both to help with generating such sequences and, importantly, with shrinking them.

Để tạo các thử nghiệm cho hệ thống tệp giả của chúng tôi, chúng tôi phải tạo các chuỗi cuộc gọi vào API;
*"Khai trương tệp này, mở tệp đó, ghi vào tệp đầu tiên chúng tôi mở," ".
Sau đó, chúng tôi thực hiện chuỗi này cả so với hệ thống tệp giả và chống lại thực tế và so sánh kết quả.
Nếu có sự cố xảy ra, chúng tôi kết thúc với một trường hợp thử nghiệm mà chúng tôi có thể kiểm tra.
Lý tưởng nhất, sau đó chúng ta nên cố gắng giảm thử nghiệm này để thử và xây dựng trường hợp thử nghiệm * tối thiểu * minh họa lỗi.
Chúng ta phải cẩn thận khi thu hẹp: ví dụ, khi chúng ta xóa cuộc gọi để mở từ trường hợp thử nghiệm, sau đó, bất kỳ ghi nào tiếp theo sử dụng xử lý tệp đó cũng phải được xóa.
Một thư viện như Quickeck-State-Machine có thể được sử dụng cả để giúp tạo ra các chuỗi như vậy và quan trọng là với việc thu hẹp chúng.

## **Reifying the API**

## ** Đổi lại API **

It is important that we generate the test *before* executing it. In other words, the test generation should not depend on any values that we only get when we run the test. Such a dependency makes it impossible to re-run the same test multiple times (no reproducible test cases) or shrink tests to obtain minimal examples. In order to do this, we need to *reify* the API: we need to define a data type whose constructors correspond to the API calls:

Điều quan trọng là chúng tôi tạo ra thử nghiệm * trước khi * thực hiện nó.
Nói cách khác, việc tạo thử nghiệm không nên phụ thuộc vào bất kỳ giá trị nào mà chúng ta chỉ nhận được khi chúng ta chạy thử nghiệm.
Sự phụ thuộc như vậy làm cho không thể chạy lại cùng một thử nghiệm nhiều lần (không có trường hợp thử nghiệm có thể tái tạo) hoặc kiểm tra co lại để có được các ví dụ tối thiểu.
Để thực hiện việc này, chúng ta cần * thống nhất * API: Chúng ta cần xác định một kiểu dữ liệu có các hàm tạo tương ứng với các cuộc gọi API:

data Cmd h =

dữ liệu cmd h =

`    `MkDir Dir

`` Mkdir dir

`  `| Open File

`` |
Mở tệp

`  `| Write h String

`` |
Viết chuỗi H.

`  `| Close h

`` |
Đóng h

`  `| Read File

`` |
Đọc tài liệu

Cmd is polymorphic in the type of handles h; this is important, because we should be able to execute commands both against the mock file system and against the real file system:

CMD là đa hình trong loại tay cầm H;
Điều này rất quan trọng, bởi vì chúng ta sẽ có thể thực thi các lệnh cả đối với hệ thống tệp giả và chống lại hệ thống tệp thực:

runMock ::       Cmd MHandle -> Mock -> (.. Mock)

runmock :: cmd mhandle -> mock -> (.. mock)

runIO   :: .. -> Cmd IO.Handle -> IO ..

chạy :: .. -> cmd to.handle -> io ..

What should the return type of these functions be? After all, different functions return different things: Open returns a new handle, Read returns a string, the other functions return unit. To solve this problem we will simply introduce a union type

Loại trả lại của các chức năng này là gì?
Rốt cuộc, các chức năng khác nhau trả về những thứ khác nhau: Mở trả về một tay cầm mới, đọc trả về một chuỗi, đơn vị trả về các chức năng khác.
Để giải quyết vấn đề này, chúng tôi sẽ chỉ giới thiệu một loại công đoàn

[](#2)

[] (#2)

2

2

for successful responses

cho các phản hồi thành công

data Success h = Unit () | Handle h | String String

Dữ liệu thành công h = đơn vị () |
Xử lý H |
Chuỗi chuỗi

A response is then either a succesful response or an error:

Sau đó, một phản hồi là một phản hồi thành công hoặc lỗi:

newtype Resp h = Resp (Either Err (Success h))

newtype resp h = resp (hoặc err (thành công h))

It is now easy to implement runMock: we just map all the constructors in Cmd to the corresponding API calls, and wrap the result in the appropriate constructor of Success:

Bây giờ thật dễ dàng để thực hiện RunMock: Chúng tôi chỉ ánh xạ tất cả các hàm tạo trong CMD cho các cuộc gọi API tương ứng và kết quả trong hàm tạo thành công thích hợp:

runMock :: Cmd MHandle -> Mock -> (Resp MHandle, Mock)

runmock :: cmd mHandle -> mock -> (resp mandle, mock)

runMock (MkDir d)   = first (Resp . fmap Unit)   . mMkDir d

runmock (mkdir d) = đầu tiên (đơn vị FMAP).
mmkdir d

runMock (Open  f)   = first (Resp . fmap Handle) . mOpen  f

runmock (mở f) = đầu tiên (resp. fmap xử lý).
Mopen f

runMock (Write h s) = first (Resp . fmap Unit)   . mWrite h s

RunMock (Viết H S) = Đầu tiên (Đơn vị FMAP).
mwrite h s

runMock (Close h)   = first (Resp . fmap Unit)   . mClose h

RunMock (Đóng H) = Đầu tiên (Đơn vị FMAP).
McLose h

runMock (Read  f)   = first (Resp . fmap String) . mRead  f

runmock (đọc f) = đầu tiên (chuỗi FMAP).
Mread f

where first :: (a -> b) -> (a, x) -> (b, x) comes from Data.Bifunctor.

trong đó đầu tiên :: (a -> b) -> (a, x) -> (b, x) đến từ dữ liệu.bifunctor.

We can write a similar interpreter for IO; it will take a FilePath as an additional argument that it will use as a prefix for all paths; we will use this to run the IO test in some temporary directory.

Chúng ta có thể viết một thông dịch viên tương tự cho IO;
Nó sẽ lấy một filepath như một lập luận bổ sung mà nó sẽ sử dụng làm tiền tố cho tất cả các đường dẫn;
Chúng tôi sẽ sử dụng điều này để chạy thử nghiệm IO trong một số thư mục tạm thời.

runIO :: FilePath -> Cmd IO.Handle -> IO (Resp IO.Handle)

RUNIO :: filepath -> cmd io.handle -> io (resp io.handle)

## **References**

## **Người giới thiệu**

Our interpreter for IO takes real IO handles as argument; but will not have any real handles until we actually run the test. We need a way to generate commands that run in IO but donâ€™t use real handles (yet). Here is where we see the first bit of infrastructure provided by quickcheck-state-machine, *references*:

Thông dịch viên của chúng tôi cho IO coi các tay cầm IO thực sự làm đối số;
Nhưng sẽ không có bất kỳ tay cầm thực tế cho đến khi chúng tôi thực sự chạy thử nghiệm.
Chúng ta cần một cách để tạo các lệnh chạy trong IO nhưng không sử dụng tay cầm thực (chưa).
Đây là nơi chúng ta thấy bit cơ sở hạ tầng đầu tiên được cung cấp bởi QuickCheck-State-Machine, *Tài liệu tham khảo *:

data Reference a r = Reference (r a)

Tham chiếu dữ liệu a r = tham chiếu (r a)

where we will instantiate that r parameter to either Symbolic or Concrete:

nơi chúng ta sẽ khởi tạo tham số R đó thành biểu tượng hoặc cụ thể:

[](#3)

[] (#3)

3

3

data Symbolic a = Symbolic Var

Dữ liệu tượng trưng cho A = Var biểu tượng

data Concrete a = Concrete a

bê tông dữ liệu a = bê tông a

In other words, a Reference a Concrete is really just a wrapper around an a; indeed, quickcheck-state-machine provides

Nói cách khác, một tài liệu tham khảo một bê tông thực sự chỉ là một trình bao bọc xung quanh A;
Thật vậy, QuickCheck-State-Machine cung cấp

reference :: a -> Reference a Concrete

Tài liệu tham khảo :: a -> Tham khảo bê tông

concrete  :: Reference a Concrete -> a

bê tông :: tham chiếu bê tông -> a

However, a Reference a Symbolic is a *variable*:

Tuy nhiên, một tham chiếu Một biểu tượng là một biến *Biến *:

newtype Var = Var Int

newtype var = var int

An example of a program using symbolic references is

Một ví dụ về một chương trình sử dụng các tài liệu tham khảo tượng trưng là

openThenWrite :: [Cmd (Reference IO.Handle Symbolic)]

OpenthenWrite :: [CMD (Tham khảo IO.Handle Biểu tượng)]

openThenWrite = [

openthenwrite = [

`      `Open (File (Dir []) "a")

`` Mở (FILE (DIR []) "A")

`    `, Open (File (Dir []) "b")

``, Mở (file (dir []) "b")

`    `, Write (Reference (Symbolic (Var 0))) "Hi"

``, Write (tham chiếu (tượng trưng (var 0))) "Hi"

`    `]

``]

This program corresponds precisely to our example from earlier: â€œopen this file, open that file, then write to the first file we openedâ€. Commands can return as many symbolic references in their result values as they want

Chương trình này tương ứng chính xác với ví dụ của chúng tôi từ trước đó: "mở tệp này, mở tệp đó, sau đó ghi vào tệp đầu tiên chúng tôi mở".
Các lệnh có thể trả về nhiều tài liệu tham khảo tượng trưng trong các giá trị kết quả của chúng như họ muốn

[](#4)

[](#4)

4

4

; in our simple example, only Open creates a new reference, and so Var 0 returns to the handle returned by the first call to Open.

;
Trong ví dụ đơn giản của chúng tôi, chỉ mở tạo ra một tài liệu tham khảo mới và do đó Var 0 trả về tay cầm được trả về bởi cuộc gọi đầu tiên để mở.

When we *execute* the test, those variables will be instantiated to their real values, turning symbolic references into concrete references. We will of course not write programs with symbolic references in them by hand; as we will see later, quickcheck-state-machine provides infrastructure for doing so.

Khi chúng tôi * thực thi * Bài kiểm tra, các biến đó sẽ được khởi tạo với các giá trị thực của chúng, biến các tài liệu tham khảo tượng trưng thành các tài liệu tham khảo cụ thể.
Tất nhiên chúng tôi sẽ không viết các chương trình với các tài liệu tham khảo tượng trưng trong chúng bằng tay;
Như chúng ta sẽ thấy sau, QuickCheck-State-Machine cung cấp cơ sở hạ tầng để làm như vậy.

Since we will frequently need to instantiate Cmd and Resp with references to handles, we will introduce some special syntax for this:

Vì chúng tôi sẽ thường xuyên cần khởi tạo CMD và RESP với các tham chiếu đến tay cầm, chúng tôi sẽ giới thiệu một số cú pháp đặc biệt cho việc này:

newtype At f r = At (f (Reference IO.Handle r))

newType tại f r = at (f (tham chiếu io.handle r)))

type    f :@ r = At f r

Loại F:@ R = AT F R

For example, here is a wrapper around runIO that we will need that executes a command with concrete references:

Ví dụ, đây là một trình bao bọc xung quanh Runio mà chúng ta sẽ cần thực hiện một lệnh với các tài liệu tham khảo cụ thể:

semantics :: FilePath -> Cmd :@ Concrete -> IO (Resp :@ Concrete)

Semantics :: FilePath -> CMD:@ Concrete -> IO (resp:@ Concrete)

semantics root (At c) = (At . fmap reference) <$>

Root Semantics (tại C) = (AT. Tham khảo FMAP) <$>

`                          `runIO root (concrete <$> c)

`` Root Root (bê tông <$> C)

This is really just a call to runIO, with some type wrapping and unwrapping.

Đây thực sự chỉ là một cuộc gọi đến Runio, với một số loại gói và mở rộng.

## **Relating the two implementations**

## ** Liên quan đến hai triển khai **

When we run our tests, we will execute the same set of commands against the mock implementation and in real IO, and compare the responses we get after each command. In order to compare, say, a command â€œwrite to this MHandleâ€ against the mock file system to a command â€œwrite to this IOHandleâ€ in IO, we need to know the relation between the mock handles and the IO handles. As it turns out, the most convenient way to store this mapping is as a mapping from *references* to the IO handles (either concrete or symbolic) to the corresponding mock handles.

Khi chúng tôi chạy các bài kiểm tra của mình, chúng tôi sẽ thực hiện cùng một bộ lệnh chống lại việc thực hiện giả và trong IO thực và so sánh các phản hồi chúng tôi nhận được sau mỗi lệnh.
Để so sánh, giả sử, một lệnh - viết với mandle này đối với hệ thống tệp giả với một lệnh - viết tắt của ioHandle này, chúng ta cần biết mối quan hệ giữa tay cầm giả và tay cầm IO
.
Hóa ra, cách thuận tiện nhất để lưu trữ ánh xạ này là một ánh xạ từ * tài liệu tham khảo * đến tay cầm IO (cụ thể hoặc tượng trưng) đến tay cầm giả tương ứng.

type HandleRefs r = [(Reference IO.Handle r, MHandle)]

Loại HandleRefs r = [(tham khảo io.handle r, mHandle)]]

(!) :: Eq k => [(k, a)] -> k -> a

(!) :: eq k => [(k, a)] -> k -> a

env ! r = fromJust (lookup r env)

Env!
r = fromjust (tra cứu r env)

Then to compare the responses from the mock file system to the responses from IO we need to keep track of the state of the mock file system and this mapping; we will refer to this as the *model* for our test:

Sau đó, để so sánh các phản hồi từ hệ thống tệp giả với các phản hồi từ IO, chúng ta cần theo dõi trạng thái của hệ thống tệp giả và ánh xạ này;
Chúng tôi sẽ gọi đây là mô hình * cho thử nghiệm của chúng tôi:

data Model r = Model Mock (HandleRefs r)

Mô hình dữ liệu r = model mock (Handlerefs r)

initModel :: Model r

initModel :: model r

initModel = Model emptyMock []

initModel = model trốngMock []

The model must be polymorphic in r: during test *generation* we will instantiate r to Symbolic, and during test *execution* we will instantiate r to Concrete.

Mô hình phải đa hình trong r: Trong quá trình thử nghiệm * tạo * chúng ta sẽ khởi động r thành tượng trưng và trong quá trình thử nghiệm * thực thi * chúng ta sẽ khởi tạo r để cụ thể.

## **Stepping the model**

## ** Bước mô hình **

We want to work towards a function

Chúng tôi muốn làm việc hướng tới một chức năng

transition :: Eq1 r => Model r -> Cmd :@ r -> Resp :@ r -> Model r

Chuyển tiếp :: eq1 r => model r -> cmd:@ r -> resp:@ r -> model r

to step the model; we will gradually build up towards this. First, we can use the model to translate from commands or responses in terms of references to the corresponding commands or responses against the mock file system:

để bước mô hình;
Chúng tôi sẽ dần dần xây dựng hướng tới điều này.
Đầu tiên, chúng ta có thể sử dụng mô hình để dịch từ các lệnh hoặc phản hồi theo các tài liệu tham khảo cho các lệnh hoặc phản hồi tương ứng đối với hệ thống tệp giả:

toMock :: (Functor f, Eq1 r) => Model r -> f :@ r -> f MHandle

tomock :: (functor f, eq1 r) => model r -> f:@ r -> f mHandle

toMock (Model \_ hs) (At fr) = (hs !) <$> fr

tomock (model \ _ hs) (tại fr) = (hs!) <$> fr

Specifically, this can be instantiated to

Cụ thể, điều này có thể được khởi tạo để

toMock :: Eq1 r => Model r -> Cmd :@ r -> Cmd MHandle

tomock :: eq1 r => model r -> cmd:@ r -> cmd mhandle

which means that if we have a command in terms of references, we can translate that command to the corresponding command for the mock file system and execute it:

Điều đó có nghĩa là nếu chúng ta có lệnh về mặt tham chiếu, chúng ta có thể dịch lệnh đó thành lệnh tương ứng cho hệ thống tệp giả và thực thi nó:

step :: Eq1 r => Model r -> Cmd :@ r -> (Resp MHandle, Mock)

Bước :: eq1 r => model r -> cmd:@ r -> (resp mhandle, mock)

step m@(Model mock \_) c = runMock (toMock m c) mock

Bước m@(mô hình giả \ _) c = runmock (tomock m c) mock

In order to construct the full new model however we also need to know how to extend the handle mapping. We can compute this by comparing the response we get from the â€œrealâ€ semantics (Resp :@ r) to the response we get from the mock semantics (from step), and simply zip the handles from both responses together to obtain the new mapping. We wrap all this up into an *event*:

Để xây dựng mô hình mới đầy đủ, tuy nhiên chúng ta cũng cần biết cách mở rộng ánh xạ tay cầm.
Chúng ta có thể tính toán điều này bằng cách so sánh phản hồi mà chúng ta nhận được từ ngữ nghĩa thực tế (resp:@ r) với phản hồi mà chúng ta nhận được từ ngữ nghĩa giả (từ bước) và chỉ đơn giản là kéo hai tay cầm từ cả hai phản hồi để có được
Bản đồ mới.
Chúng tôi bọc tất cả những điều này thành một sự kiện *:

data Event r = Event {

sự kiện dữ liệu r = sự kiện {

`    `before   :: Model  r

`` Trước :: Model R

`  `, cmd      :: Cmd :@ r

``, cmd :: cmd:@ r

`  `, after    :: Model  r

``, sau :: model r

`  `, mockResp :: Resp MHandle

``, mockresp :: resp

`  `}

``}

and we construct an event from a model, the command we executed, and the response we got from the real implementation:

và chúng tôi xây dựng một sự kiện từ một mô hình, lệnh chúng tôi đã thực thi và phản hồi chúng tôi nhận được từ việc thực hiện thực sự:

lockstep :: Eq1 r

Lockstep :: EQ1 R

`         `=> Model   r

`` => Model R

`         `-> Cmd  :@ r

``-> cmd:@ r

`         `-> Resp :@ r

``-> resp:@ r

`         `-> Event   r

``-> Sự kiện r

lockstep m@(Model \_ hs) c (At resp) = Event {

khóa m@(model \ _ hs) c (at resp) = event {

`      `before   = m

`` Trước = m

`    `, cmd      = c

``, cmd = c

`    `, after    = Model mock' (hs <> hs')

``, after = model mock '(hs <> hs')

`    `, mockResp = resp'

``, mockresp = resp '

`    `}

``}

`  `where

`` Ở đâu

`    `(resp', mock') = step m c

`` (resp ', mock') = bước m c

`    `hs' = zip (toList resp) (toList resp')

`` hs '= zip (Tolist resp) (Tolist resp

The function we mentioned at the start of this section is now easily derived:

Hàm chúng tôi đã đề cập ở đầu phần này bây giờ dễ dàng bắt nguồn:

transition :: Eq1 r => Model r -> Cmd :@ r -> Resp :@ r -> Model r

Chuyển tiếp :: eq1 r => model r -> cmd:@ r -> resp:@ r -> model r

transition m c = after . lockstep m c

Chuyển tiếp m c = sau.
khóa m c

as well as a function that compares the mock response and the response from the real file system and checks that they are the same:

cũng như một hàm so sánh phản hồi giả và phản hồi từ hệ thống tệp thực và kiểm tra xem chúng có giống nhau không:

postcondition :: Model   Concrete

Postcondition :: Bê tông mô hình

`              `-> Cmd  :@ Concrete

``-> cmd:@ bê tông

`              `-> Resp :@ Concrete

``-> resp:@ bê tông

`              `-> Logic

``-> logic

postcondition m c r = toMock (after e) r .== mockResp e

postcondition m c r = tomock (sau e) r. == mockresp e

`  `where

`` Ở đâu

`    `e = lockstep m c r

`` E = khóa m c r

We will pass this function to quickcheck-state-machine to be run after every command it executes to make sure that the model and the real system do indeed return the same responses; it therefore does not need to be polymorphic in r. (Logic is a type introduced by quickcheck-state-machine; think of it as a boolean with some additional information, somewhat similar to QuickCheckâ€™s Property type.)

Chúng tôi sẽ chuyển chức năng này cho QuickCheck State-Machine để được chạy sau mỗi lệnh mà nó thực thi để đảm bảo rằng mô hình và hệ thống thực sự thực sự trả về các phản hồi tương tự;
Do đó, nó không cần phải đa hình trong r.
.

Events will also be very useful when we label our tests; more on that later.

Các sự kiện cũng sẽ rất hữu ích khi chúng tôi dán nhãn các bài kiểm tra của chúng tôi;
nhiều hơn về điều đó sau.

## **Constructing symbolic responses**

## ** Xây dựng các phản ứng tượng trưng **

We mentioned above that we will not write programs with symbolic references in it by hand. Instead what will happen is that we execute commands in the mock file system, and then replace any of the generated handles by new variables. Most of this happens behind the scenes by quickcheck-state-machine, but we do need to give it this function to construct symbolic responses:

Chúng tôi đã đề cập ở trên rằng chúng tôi sẽ không viết các chương trình với các tài liệu tham khảo tượng trưng trong đó bằng tay.
Thay vào đó, điều sẽ xảy ra là chúng tôi thực thi các lệnh trong hệ thống tệp giả, sau đó thay thế bất kỳ tay cầm được tạo nào bằng các biến mới.
Hầu hết điều này xảy ra đằng sau hậu trường của QuickCheck-State-Machine, nhưng chúng ta cần phải cung cấp cho nó chức năng này để xây dựng các phản ứng tượng trưng:

symbolicResp :: Model Symbolic

Biểu tượng :: Mô hình tượng trưng

`             `-> Cmd :@ Symbolic

``-> CMD:@ Biểu tượng

`             `-> GenSym (Resp :@ Symbolic)

``-> gensym (resp:@ tượng trưng)

symbolicResp m c = At <$> traverse (const genSym) resp

Biểu tượng của M C = AT <$> Traverse (Const Gensym) REST

`  `where

`` Ở đâu

`    `(resp, \_mock') = step m c

`` (resp, \ _mock ') = bước m c

This function does what we just described: we use step to execute the command in the mock model, and then traverse the response, constructing a new (fresh) variable for each handle. GenSym is a monad defined in quickcheck-state-machine for the sole purpose of generating variables; we wonâ€™t use it anywhere else except in this function.

Hàm này thực hiện những gì chúng tôi vừa mô tả: Chúng tôi sử dụng bước để thực thi lệnh trong mô hình giả, sau đó đi qua phản hồi, xây dựng một biến (mới) cho mỗi tay cầm.
GENSYM là một monad được xác định trong que-máy trạng thái quickcheck cho mục đích duy nhất là tạo ra các biến;
Chúng tôi sẽ không sử dụng nó ở bất cứ nơi nào khác ngoại trừ trong chức năng này.

## **Generating commands**

## ** Các lệnh tạo **

To generate commands, quickcheck-state-machine requires a function that produces the next command given the current model; this function will be a standard QuickCheck generator. For our running example, the generator is easy to write:

Để tạo các lệnh, QuickCheck-State-Machine yêu cầu một hàm tạo ra lệnh tiếp theo được đưa ra mô hình hiện tại;
Chức năng này sẽ là một trình tạo QuickCheck tiêu chuẩn.
Đối với ví dụ đang chạy của chúng tôi, trình tạo rất dễ viết:

generator :: Model Symbolic -> Maybe (Gen (Cmd :@ Symbolic))

Trình tạo :: Model Biểu tượng -> Có thể (Gen (CMD:@ Biểu tượng)))

generator (Model \_ hs) = Just $ QC.oneof $ concat [

Trình tạo (model \ _ hs) = Just $ qc.oneof $ concat [

**This document was truncated here because it was created in the Evaluation Mode.**

** Tài liệu này đã bị cắt ngắn ở đây vì nó được tạo trong chế độ đánh giá. **

