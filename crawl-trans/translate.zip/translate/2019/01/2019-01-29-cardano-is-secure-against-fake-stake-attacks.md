# Cardano is secure against fake stake attacks
### **Peer-reviewed design means Ouroboros is free from a flaw affecting many proof-of-stake blockchains**
![](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.002.png) 29 January 2019![](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.002.png)[ Philipp Kant](tmp//en/blog/authors/philipp-kant/page-1/)![](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.003.png) 6 mins read

![Philipp Kant](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.004.png)[](tmp//en/blog/authors/philipp-kant/page-1/)
### [**Philipp Kant**](tmp//en/blog/authors/philipp-kant/page-1/)
Formal Methods Director

Engineering

- ![](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.005.png)[](https://www.linkedin.com/in/dr-philipp-kant-4972b1a3 "LinkedIn")
- ![](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.006.png)[](https://twitter.com/philipp_kant "Twitter")
- ![](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.007.png)[](https://github.com/kantp "GitHub")

![Cardano is secure against fake stake attacks](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.008.jpeg)

Ada is not among the 26 cryptocurrencies identified by US researchers last week as being vulnerable to â€˜fake stakeâ€™ attacks.

ADA không nằm trong số 26 tiền điện tử được các nhà nghiên cứu Hoa Kỳ xác định tuần trước là dễ bị tổn thương bởi các cuộc tấn công của cổ phần.

[](#1)

[] (#1)

1

1

The Cardano blockchain underlying Ada is based on proof-of-stake (PoS), but its Ouroboros protocol uses no bitcoin code and is not affected by the PoSv3 problem.

Blockchain Cardano cơ bản ADA dựa trên bằng chứng cổ phần (POS), nhưng giao thức Ouroboros của nó không sử dụng mã Bitcoin và không bị ảnh hưởng bởi vấn đề POSV3.

[](#2)

[] (#2)

2

2

This is not just good luck, but a consequence of the thorough, formally-verified approach taken during Cardanoâ€™s development.

Đây không chỉ là may mắn, mà là hậu quả của cách tiếp cận kỹ lưỡng, được xác minh chính thức được thực hiện trong quá trình phát triển của Cardano.

## **The vulnerability**

## ** lỗ hổng **

The vulnerability is explained very well in the original article. In order to understand why Cardano is not affected by it, we will summarise the essence of the vulnerability here.

Các lỗ hổng được giải thích rất tốt trong bài viết gốc.
Để hiểu tại sao Cardano không bị ảnh hưởng bởi nó, chúng tôi sẽ tóm tắt bản chất của lỗ hổng ở đây.

All the vulnerable systems are using PoSv3, a modification of the bitcoin code that aims to replace hashing power with stake for the purpose of determining who is eligible to create a block. In the original bitcoin code, the decision of who gets to create the next block is based purely on hashing power: whoever manages to find a suitable random number, and thus get a correct hash first, wins. PoSv3, however, adds an additional variable, to simulate the notion of stake.

Tất cả các hệ thống dễ bị tổn thương đang sử dụng POSV3, sửa đổi mã Bitcoin nhằm thay thế sức mạnh băm bằng cổ phần cho mục đích xác định ai đủ điều kiện để tạo một khối.
Trong mã Bitcoin ban đầu, quyết định của ai sẽ tạo ra khối tiếp theo hoàn toàn dựa trên sức mạnh băm: bất cứ ai quản lý để tìm một số ngẫu nhiên phù hợp, và do đó có được một hàm băm đúng trước, chiến thắng.
Posv3, tuy nhiên, thêm một biến bổ sung, để mô phỏng khái niệm cổ phần.

In a PoS system, the likelihood of getting to create a block is proportional to how much stake a user has in the system: the more stake a user has, the more likely it is that they get to create the next block. To mimic this functionality, PoSv3 allows users to add additional information to their candidate block, in the form of a â€˜staking transactionâ€™. The more tokens they have available to use in their staking transaction, the easier it becomes for them to get a correct hash, and thus earn the right to create the next block.

Trong một hệ thống POS, khả năng tạo ra một khối tỷ lệ thuận với số tiền người dùng có cổ phần trong hệ thống: người dùng càng có nhiều cổ phần, thì càng có nhiều khả năng họ tạo ra khối tiếp theo.
Để bắt chước chức năng này, POSV3 cho phép người dùng thêm thông tin bổ sung vào khối ứng cử viên của họ, dưới dạng giao dịch gây ra.
Càng nhiều mã thông báo họ có sẵn để sử dụng trong giao dịch đặt cược của họ, họ càng dễ dàng có được một hàm băm chính xác, và do đó kiếm được quyền tạo khối tiếp theo.

Whilst PoSv3 does successfully tie block creation rights to stake in this way, it also makes block validation more difficult. Not only does the hash of the block itself need to be verified (as in bitcoin), but so does a userâ€™s staking transaction: that is, did the user actually own the tokens they used in their staking transaction? To verify this information, a blockchain node has to be able to refer to the ledger, and â€“ if a block does not simply extend the current chain but introduces a fork â€“ also the history of the ledger. Since that is neither cached nor cheap to calculate, blocks in PoSv3 systems are not validated immediately, but are rather (at least partially) stored in memory or on disk when they pass some heuristics.

Trong khi POSV3 thực hiện thành công các quyền sáng tạo khối để đặt cược theo cách này, nó cũng khiến xác thực khối trở nên khó khăn hơn.
Không chỉ băm của khối cần phải được xác minh (như trong Bitcoin), mà giao dịch đặt cược của người dùng cũng vậy: đó là người dùng có thực sự sở hữu các mã thông báo mà họ đã sử dụng trong giao dịch đặt cược của họ không?
Để xác minh thông tin này, một nút blockchain phải có khả năng tham khảo sổ cái và nếu một khối không chỉ đơn giản là mở rộng chuỗi hiện tại mà còn giới thiệu một ngã ba cũng là lịch sử của sổ cái.
Vì đó không phải là bộ nhớ cache cũng không rẻ để tính toán, các khối trong các hệ thống POSV3 không được xác nhận ngay lập tức, mà là (ít nhất là một phần) được lưu trữ trong bộ nhớ hoặc trên đĩa khi chúng vượt qua một số heuristic.

The vulnerabilities discussed in the original article can be exploited in a number of ways, but ultimately involve fooling those heuristics and presenting lots of invalid blocks to a node, such that the node runs out of memory and crashes before it can correctly identify that the blocks are invalid.

Các lỗ hổng được thảo luận trong bài viết gốc có thể được khai thác theo một số cách, nhưng cuối cùng liên quan đến việc đánh lừa những heuristic đó và trình bày rất nhiều khối không hợp lệ cho một nút, do đó nút chạy ra khỏi bộ nhớ và gặp sự cố trước khi nó có thể xác định chính xác các khối đó
không hợp lệ.

## **Why Cardano is different**

## ** Tại sao Cardano khác nhau **

For Cardano, IOHK took a different approach. Instead of finding a minimal variation of bitcoin, we relied on world-leading academics and researchers to create a new protocol and codebase from scratch, with the requirement that it should provide equivalent (or better) security guarantees than bitcoin, but rely entirely on stake. The result is the Ouroboros protocol

Đối với Cardano, Iohk đã thực hiện một cách tiếp cận khác.
Thay vì tìm ra một biến thể tối thiểu của Bitcoin, chúng tôi đã dựa vào các học giả và nhà nghiên cứu hàng đầu thế giới để tạo ra một giao thức mới và cơ sở mã
.
Kết quả là giao thức Ouroboros

[](#3)

[] (#3)

3

3

, the first provably secure PoS protocol, upon which Cardano is built.

, giao thức POS an toàn đầu tiên có thể chứng minh được, trên đó Cardano được xây dựng.

The basic design of Ouroboros is remarkably simple: time is divided into discrete increments, called slots, and slots are grouped into longer periods, called epochs. At the start of each epoch, a lottery determines who gets to create a block for every slot. Instead of this lottery being implicit, ie whoever gets a right hash first wins, the lottery is explicit: a generated random number determines a slot leader for each slot, and the chances of winning for any given slot are proportional to the stake one controls

Thiết kế cơ bản của ouroboros rất đơn giản: thời gian được chia thành các gia số riêng biệt, được gọi là khe và khe được nhóm thành các khoảng thời gian dài hơn, được gọi là epochs.
Khi bắt đầu mỗi kỷ nguyên, xổ số xác định ai sẽ tạo ra một khối cho mỗi khe.
Thay vì xổ số này bị ngầm, tức là bất cứ ai có băm quyền chiến thắng đầu tiên, xổ số là rõ ràng: một số ngẫu nhiên được tạo xác định một vị trí lãnh đạo khe cho mỗi khe và cơ hội chiến thắng cho bất kỳ khe nào đã cho tỷ lệ thuận với Stake One Controls

[](#4)

[](#4)

4

4

.

.

In this protocol, validating that a block has been signed by the right stakeholder is also simple: it requires only the leader schedule for the current epoch (which will not change in case of a temporary fork), and the checking of a signature. This can and will be done by each node once they get the block header, in contrast to the PoSv3 systems that are vulnerable to fake stake attacks.

Trong giao thức này, xác nhận rằng một khối đã được ký bởi các bên liên quan đúng cũng rất đơn giản: nó chỉ yêu cầu lịch trình lãnh đạo cho kỷ nguyên hiện tại (sẽ không thay đổi trong trường hợp nĩa tạm thời) và kiểm tra chữ ký.
Điều này có thể và sẽ được thực hiện bởi mỗi nút một khi họ nhận được tiêu đề khối, trái ngược với các hệ thống POSV3 dễ bị tấn công cổ phần giả.

In short: Cardano is secure against fake stake attacks because itâ€™s based on a fundamentally different system. PoSv3 cryptocurrencies run on proof-of-work (PoW) systems, modified to take stake into account in the implicit leader election, and the vulnerability in question is a result of that modification, and the additional complexities it involves.

Nói tóm lại: Cardano an toàn chống lại các cuộc tấn công cổ phần giả vì nó dựa trên một hệ thống cơ bản khác nhau.
Tiền điện tử POSV3 chạy trên các hệ thống Proof-of-Work (POW), được sửa đổi để tính đến cuộc bầu cử lãnh đạo ngầm và lỗ hổng trong câu hỏi là kết quả của việc sửa đổi đó và sự phức tạp bổ sung mà nó liên quan.

Not only does Cardano have a fundamentally different foundation, but that foundation is the result of multiple peer-reviewed academic papers, and an unprecedented collaboration between researchers and developers. The formal and semi-formal methods involved in creating the upcoming Shelley release of Cardano ensure that its construction at code level evidently matches the protocol described in the peer-reviewed research papers, building in reliability and security by design â€“ and avoiding the problems of PoSv3, which have arisen as a result of modifying an existing protocol instead of creating a thoroughly proven, bespoke protocol like Ouroboros.

Cardano không chỉ có một nền tảng cơ bản khác nhau, mà nền tảng đó là kết quả của nhiều bài báo học thuật được đánh giá ngang hàng và sự hợp tác chưa từng có giữa các nhà nghiên cứu và nhà phát triển.
Các phương pháp chính thức và bán chính thức liên quan đến việc tạo ra bản phát hành Shelley sắp tới của Cardano đảm bảo rằng việc xây dựng ở cấp độ mã rõ ràng phù hợp với giao thức được mô tả trong các tài liệu nghiên cứu được đánh giá ngang hàng, xây dựng độ tin cậy và bảo mật bằng cách thiết kế và tránh các vấn đề
của POSV3, đã phát sinh do kết quả của việc sửa đổi một giao thức hiện có thay vì tạo ra một giao thức bespoke đã được chứng minh kỹ lưỡng như Ouroboros.

### **Footnotes**

### ** Chú thích **

\1. â€˜[â€œFake Stakeâ€ attacks on chain-based Proof-of-Stake cryptocurrencies](https://medium.com/@dsl_uiuc/fake-stake-attacks-on-chain-based-proof-of-stake-cryptocurrencies-b8b05723f806)â€™ by Sanket Kanjalkar, Yunqi Li, Yuguang Chen, Joseph Kuo, and Andrew Miller of the Decentralized Systems Lab at the University of Illinois at Urbana-Champaign.[â†©](#f1)

\ 1.
â € ˜ [â € œFake Stakeâ € Attacks vào các loại tiền điện tử dựa trên chuỗi dựa trên chuỗi] (https://medium.com/@dsl_uiuc/fake-de
Stake-Cryptocurrencies-B8B05723F806)

\2. To be precise, the following discussion is targeted at the upcoming Shelley release of Cardano. The currently deployed Byron release is running in a federated setting, and thereby operationally protected from this kind of attack anyway.[â†©](#f2)

\ 2.
Nói chính xác, các cuộc thảo luận sau đây được nhắm mục tiêu vào bản phát hành Shelley sắp tới của Cardano.
Bản phát hành Byron hiện đang được triển khai đang chạy trong cài đặt liên kết và do đó được bảo vệ hoạt động khỏi loại tấn công này. [Â † ©] (#F2)

\3. There are by now a number of variations of the Ouroboros protocol. We describe only the classic version of Ouroboros here, but the general argument holds for all variants â€“ in particular for Ouroboros Praos, which will be the protocol used in the Shelley release.[â†©](#f3)

\ 3.
Bây giờ có một số biến thể của giao thức Ouroboros.
Chúng tôi chỉ mô tả phiên bản cổ điển của Ouroboros ở đây, nhưng lập luận chung được giữ cho tất cả các biến thể - Đặc biệt cho Ouroboros PRAOS, sẽ là giao thức được sử dụng trong bản phát hành Shelley. [Â † ©] (#F3)

\4. To be precise, leader election for a given epoch uses the stake distribution at a point in time before the epoch starts, to prevent grinding attacks and a re-calculation of the schedule in case of a temporary fork at the epoch boundary.[â†©](#f4)

\4.
Nói chính xác, cuộc bầu cử của người lãnh đạo cho một kỷ nguyên nhất định sử dụng phân phối cổ phần tại một thời điểm trước khi thời đại bắt đầu, để ngăn chặn các cuộc tấn công nghiền và tính toán lại lịch trình trong trường hợp một ngã ba tạm thời ở ranh giới kỷ nguyên. [Â † †
©] (#f4)

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2019-01-29-cardano-is-secure-against-fake-stake-attacks.009.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](https://www.lusion.co)

[Edan Kwan](https://www.lusion.co)

[Edan Kwan] (https://www.lusion.co)

