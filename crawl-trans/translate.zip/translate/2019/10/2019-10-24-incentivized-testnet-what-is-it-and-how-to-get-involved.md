# Incentivized Testnet: what is it and how to get involved
### **Soon you’ll be able to earn real ada rewards as you support the rollout of Shelley. Here’s the lowdown**
![](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.002.png) 24 October 2019![](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.002.png)[ Dynal Patel](tmp//en/blog/authors/dynal-patel/page-1/)![](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.003.png) 6 mins read

![Dynal Patel](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.004.png)[](tmp//en/blog/authors/dynal-patel/page-1/)
### [**Dynal Patel**](tmp//en/blog/authors/dynal-patel/page-1/)
Chief Product Officer

Operations

- ![](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.005.png)[](mailto:dynal.patel@iohk.io "Email")
- ![](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.006.png)[](https://www.linkedin.com/in/dynalpatel/ "LinkedIn")
- ![](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.007.png)[](https://twitter.com/dynalpatel "Twitter")

![Incentivized Testnet: what is it and how to get involved](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.008.jpeg)

Over the past few months, we’ve been working towards a full release of the Shelley testnet. You may have been following our reports about progress on the [self-node](https://iohk.io/en/blog/posts/2019/09/06/taking-the-next-step-on-the-road-to-cardano-shelley/ "Shelley self-node testnet, testnet.iohkdev.io") and [networked](https://iohk.io/en/blog/posts/2019/09/26/unboxing-the-blockchain-%E2%80%93-the-shelley-testnet-making-its-network-debut/ "Shelley networked testnet, testnet.iohkdev.io") phases. Now, we’re on the third and final phase before the Shelley mainnet goes live: an Incentivized Testnet that all ada holders can join to earn real ada rewards.

Trong vài tháng qua, chúng tôi đã làm việc để phát hành đầy đủ Shelley Testnet.
Bạn có thể đã theo dõi các báo cáo của chúng tôi về tiến trình trên [tự do] (https://iohk.io/en/blog/posts/2019/09/06/taking-the-next-step-on-the-oad
-to-cardano-shelley/"Shelley tự Testnet, testnet.iohkdev.io") và [networked] (https://iohk.io/en/blog/posts/2019/09/26/unboxing-the-
Blockchain-%E2%80%93-the-Shelley-TestNet-caking-its-work-debut/ "Shelley nối mạng nối mạng, testnet.iohkdev.io").
Bây giờ, chúng tôi đã ở giai đoạn thứ ba và cuối cùng trước khi Shelley Mainnet ra đời: một testnet được khuyến khích mà tất cả các chủ sở hữu ADA có thể tham gia để kiếm được phần thưởng ADA thực sự.

This marks an acceleration in the Shelley testnet, and in Cardano’s development. Rewards earned from the Incentivized Testnet will be transferred to the mainnet: the ada earned from delegating your stake or operating a stake pool are real and will be transferred to the mainnet when it goes live.

Điều này đánh dấu sự tăng tốc trong Shelley Testnet và trong sự phát triển của Cardano.
Phần thưởng kiếm được từ TestNet được khuyến khích sẽ được chuyển sang Mainnet: ADA kiếm được từ việc ủy thác cổ phần của bạn hoặc vận hành một nhóm cổ phần là có thật và sẽ được chuyển đến mainnet khi nó được phát hành.

The Incentivized Testnet is the beginning of Shelley’s rollout, which will culminate in the release of the codebase to the mainnet early next year and, with that, the realization of a secure, decentralized proof-of-stake (PoS) network. Exciting, unprecedented times.

TestNet được khuyến khích là khởi đầu của việc triển khai Shelley, sẽ lên đến đỉnh điểm trong việc phát hành cơ sở mã cho Mainnet vào đầu năm tới và, với điều đó, việc thực hiện một mạng lưới chứng minh (POS) an toàn, phi tập trung.
Thời gian thú vị, chưa từng có.

## **Why the Incentivized Testnet?**

## ** Tại sao TestNet được khuyến khích? **

Cardano runs on the Ouroboros protocol: the most advanced and secure PoS protocol in development. With this innovation, however, comes complication, so, to ensure stable and robust foundations, we’ve chosen to implement it in a practical and responsible way. This is also why we’ve introduced new capability – the latest being the incentive mechanism – gradually to the Shelley testnet. Shelley is the foundation to everything yet to come; once we’ve achieved a working decentralized network, much more then becomes possible, including Goguen, which introduces smart contract functionality.

Cardano chạy trên giao thức Ouroboros: Giao thức POS tiên tiến và an toàn nhất đang được phát triển.
Tuy nhiên, với sự đổi mới này, đến sự phức tạp, vì vậy, để đảm bảo nền tảng ổn định và mạnh mẽ, chúng tôi đã chọn để thực hiện nó một cách thực tế và có trách nhiệm.
Đây cũng là lý do tại sao chúng tôi đã giới thiệu khả năng mới - mới nhất là cơ chế khuyến khích - dần dần cho Shelley Testnet.
Shelley là nền tảng cho mọi thứ chưa đến;
Khi chúng tôi đã đạt được một mạng lưới phi tập trung làm việc, nhiều hơn nữa có thể, bao gồm cả Goguen, nơi giới thiệu chức năng hợp đồng thông minh.

The Incentivized Testnet will allow us to see Cardano’s incentive mechanism operating in a near real-world context. These mechanisms are integral to the operation of the Ouroboros protocol; incentivization is how we guarantee network participation, promote growth, and ensure essential actors play their part.

TestNet được khuyến khích sẽ cho phép chúng tôi thấy cơ chế khuyến khích của Cardano, hoạt động trong bối cảnh gần như trong thế giới thực.
Các cơ chế này là không thể thiếu đối với hoạt động của giao thức Ouroboros;
khuyến khích là cách chúng tôi đảm bảo sự tham gia của mạng, thúc đẩy tăng trưởng và đảm bảo các tác nhân thiết yếu đóng vai trò của họ.

Incentivization depends upon two things we hold dear: time and money. It’s essential that we get this right, and that Cardano’s users are appropriately rewarded for their investment. This is why real incentives are necessary to test incentivization. The mechanism was designed around game theory and behavioral economics, and it is ultimately human behavior that we are testing.

Khuyến khích phụ thuộc vào hai điều chúng ta yêu quý: thời gian và tiền bạc.
Điều cần thiết là chúng tôi có được điều này đúng và người dùng Cardano, được thưởng một cách thích hợp cho khoản đầu tư của họ.
Đây là lý do tại sao các ưu đãi thực sự là cần thiết để kiểm tra khuyến khích.
Cơ chế được thiết kế xung quanh lý thuyết trò chơi và kinh tế hành vi, và cuối cùng đó là hành vi của con người mà chúng ta đang thử nghiệm.

Lastly, the Incentivized Testnet allows us to lay the foundation for Shelley on the mainnet, test its core functionality in a controlled way, and gather essential community feedback. It will also help us build a stable and qualified group of decentralized stake pool operators in preparation for the mainnet.

Cuối cùng, TestNet được khuyến khích cho phép chúng tôi đặt nền tảng cho Shelley trên mainnet, kiểm tra chức năng cốt lõi của nó theo cách được kiểm soát và thu thập phản hồi cộng đồng thiết yếu.
Nó cũng sẽ giúp chúng tôi xây dựng một nhóm các nhà điều hành nhóm cổ phần phi tập trung ổn định và có trình độ để chuẩn bị cho chính.

## **How can I take part?**

## ** Làm thế nào tôi có thể tham gia? **

This is different from our other testnets, and to most testnets. The Incentivized Testnet will begin with a UTXO snapshot of all the ada balances held across the mainnet. This snapshot will capture the value of your ada balance at the time. It is this balance value – not the ada itself – will then be transferred into the Incentivized Testnet.

Điều này khác với các bài kiểm tra khác của chúng tôi và cho hầu hết các bài kiểm tra.
TestNet được khuyến khích sẽ bắt đầu bằng ảnh chụp nhanh UTXO về tất cả các số dư ADA được tổ chức trên Mainnet.
Ảnh chụp nhanh này sẽ nắm bắt được giá trị của số dư ADA của bạn tại thời điểm đó.
Đó là giá trị cân bằng này - không phải chính ADA - sau đó sẽ được chuyển vào testnet được khuyến khích.

Anybody that holds ada at the time of the balance snapshot can participate in the Incentivized Testnet. But you’ll need to ensure that you are holding it in an approved location. For technical reasons, ada held in exchanges or on hardware wallets will not be included in the snapshot. You can find details of which wallets are supported for the balance snapshot in the chart below.

Bất cứ ai giữ ADA tại thời điểm chụp nhanh cân bằng đều có thể tham gia vào TestNet được khuyến khích.
Nhưng bạn sẽ cần phải đảm bảo rằng bạn đang giữ nó ở một địa điểm được phê duyệt.
Vì lý do kỹ thuật, ADA được tổ chức trao đổi hoặc trên ví phần cứng sẽ không được đưa vào ảnh chụp nhanh.
Bạn có thể tìm thấy chi tiết về ví được hỗ trợ cho ảnh chụp nhanh trong biểu đồ dưới đây.

Ada stored on exchanges or hardware wallets must be transferred to a supported software wallet – such as Daedalus or Yoroi – prior to the snapshot. Don’t worry. The snapshot works as a freeze-frame; ada held at the time can be freely exchanged and transferred immediately after.

ADA được lưu trữ trên các sàn giao dịch hoặc ví phần cứng phải được chuyển sang ví phần mềm được hỗ trợ - như Daedalus hoặc Yoroi - trước khi chụp nhanh.
Đừng lo.
Ảnh chụp nhanh hoạt động như một khung đóng băng;
ADA được tổ chức tại thời điểm đó có thể được trao đổi và chuyển giao tự do ngay sau đó.

The snapshot will happen during November, but we’ll also test it beforehand: to ensure everything’s working as intended and provide participants with an opportunity to check they’re able to download and configure the relevant software. Further details will be provided on when the snapshot will take place nearer the time, so you’ll be able to move your funds in advance. We don’t want anybody to miss out.

Ảnh chụp nhanh sẽ xảy ra trong tháng 11, nhưng chúng tôi cũng sẽ kiểm tra trước đó: để đảm bảo mọi thứ hoạt động như dự định và cung cấp cho người tham gia cơ hội để kiểm tra họ có thể tải xuống và định cấu hình phần mềm có liên quan.
Thông tin chi tiết sẽ được cung cấp khi ảnh chụp nhanh sẽ diễn ra gần hơn thời gian, do đó, bạn sẽ có thể di chuyển tiền của mình trước.
Chúng tôi không muốn bất cứ ai bỏ lỡ.

## **Stake delegation**

## ** Đoàn cổ phần **

No technical knowledge is required to delegate your stake. To take part, you will need to download one of the special testnet Daedalus and Yoroi wallets. To avoid any confusion, these will be visually distinct from their mainnet counterparts.

Không có kiến thức kỹ thuật được yêu cầu để ủy thác cổ phần của bạn.
Để tham gia, bạn sẽ cần tải xuống một trong những ví Testnet Daedalus và Yoroi đặc biệt.
Để tránh bất kỳ sự nhầm lẫn nào, những điều này sẽ khác biệt trực quan với các đối tác chính của họ.

After the snapshot, you’ll be able to access your testnet wallet as you would your mainnet wallet – by entering your mnemonic phrase – to view your Incentivized Testnet ada balance. The testnet wallets will feature an option to delegate your stake to one or more stake pools. You’ll be able to choose how you delegate from within the wallet.

Sau ảnh chụp nhanh, bạn sẽ có thể truy cập vào ví TestNet của mình như ví của bạn - bằng cách nhập cụm từ ghi nhớ của bạn - để xem số dư TestNet ADA được khuyến khích của bạn.
Các ví TestNet sẽ có một tùy chọn để ủy thác cổ phần của bạn cho một hoặc nhiều nhóm cổ phần.
Bạn có thể chọn cách bạn ủy thác từ trong ví.

The ada within the Incentivized Testnet can be used as it would be on the mainnet, to delegate or operate a stake pool. It cannot be spent and cannot be transferred out of the testnet. Once this phase is complete, however, the rewards accumulated within the testnet will be transferred to the mainnet, as a real, spendable payment. Ergo, the ada earned on the testnet represent a real incentive. This is real money driving real behavior, but within a controlled environment.

ADA trong TestNet được khuyến khích có thể được sử dụng vì nó sẽ có trên chính, để ủy thác hoặc vận hành một nhóm cổ phần.
Nó không thể được chi tiêu và không thể được chuyển ra khỏi testnet.
Tuy nhiên, sau khi giai đoạn này hoàn tất, phần thưởng được tích lũy trong TestNet sẽ được chuyển sang chính, dưới dạng thanh toán thực, có thể chi tiêu.
ERGO, ADA kiếm được trên TestNet đại diện cho một ưu đãi thực sự.
Đây là tiền thật thúc đẩy hành vi thực sự, nhưng trong một môi trường được kiểm soát.

## **Running a stake pool**

## ** Chạy nhóm cổ phần **

Running a stake pool requires some technical know-how. At the least, stake pool operators should be comfortable with command-line interfaces and have some system operation and server administration skills. Ideal candidates are people who have run stake pools before, but anybody may learn how to run a stake pool using our step-by-step documentation. We’ll continue to expand our documentation and guides throughout the process.

Chạy một nhóm cổ phần đòi hỏi một số bí quyết kỹ thuật.
Ít nhất, các nhà khai thác nhóm cổ phần nên thoải mái với các giao diện dòng lệnh và có một số kỹ năng vận hành hệ thống và quản trị máy chủ.
Các ứng cử viên lý tưởng là những người đã điều hành các nhóm cổ phần trước đây, nhưng bất kỳ ai cũng có thể học cách chạy nhóm cổ phần bằng tài liệu từng bước của chúng tôi.
Chúng tôi sẽ tiếp tục mở rộng tài liệu và hướng dẫn của chúng tôi trong suốt quá trình.

## **What rewards can I expect?**

## ** Tôi có thể mong đợi những phần thưởng nào? **

You will be able to work out the approximate rewards for delegating or operating a stake pool using a soon-to-be-released calculator, which will be hosted on a dedicated web page [we’re currently building](https://staking.cardano.org/en/ "Incentivized Testnet website"). Stay tuned for more news soon!

Bạn sẽ có thể thực hiện các phần thưởng gần đúng cho việc ủy thác hoặc vận hành nhóm cổ phần bằng cách sử dụng máy tính sắp phát hành, sẽ được lưu trữ trên một trang web chuyên dụng [chúng tôi hiện đang xây dựng] (https: // Staking
.cardano.org/ en/ "Trang web Testnet được khuyến khích").
Hãy theo dõi để biết thêm tin tức sớm!

## **When does the Incentivized Testnet begin and end?**

## ** Khi nào TestNet được khuyến khích bắt đầu và kết thúc? **

The precise timing of November’s balance snapshot, and the beginning of the Incentivized Testnet, will be announced closer to the time through public and social media channels. It will run until the Shelley codebase is ready to be deployed on the mainnet.

Thời gian chính xác của ảnh chụp nhanh Balance Balance tháng 11 và sự khởi đầu của Testnet được khuyến khích, sẽ được công bố gần hơn với thời gian thông qua các kênh truyền thông xã hội và công cộng.
Nó sẽ chạy cho đến khi Shelley Codebase sẵn sàng được triển khai trên Mainnet.

At the end of the Incentivized Testnet program, we’ll provide a procedure that will allow you to import your testnet rewards into your mainnet wallet. As with the start date, the completion and termination of the Incentivized Testnet will be announced well in advance.

Vào cuối chương trình TestNet được khuyến khích, chúng tôi sẽ cung cấp một quy trình cho phép bạn nhập phần thưởng TestNet của mình vào ví chính của bạn.
Như với ngày bắt đầu, việc hoàn thành và chấm dứt Testnet được khuyến khích sẽ được công bố trước.

![](img/2019-10-24-incentivized-testnet-what-is-it-and-how-to-get-involved.009.jpeg)

## **What does this mean for Cardano?**

## ** Điều này có ý nghĩa gì đối với Cardano? **

The start of the Incentivized Testnet phase marks the beginning of the Shelley era. Cardano has more commits than any other blockchain project on GitHub, and we’re close to realizing our vision of a decentralized network: one with the functionality and performance to support enterprise adoption and empower people across the world. With your help, we’re beginning to see what the Cardano network will be capable of, with sufficient incentive for enterprise and everyday users to participate, create, and interact.

Sự khởi đầu của giai đoạn TestNet khuyến khích đánh dấu sự khởi đầu của kỷ nguyên Shelley.
Cardano có nhiều cam kết hơn bất kỳ dự án blockchain nào khác trên GitHub và chúng tôi gần như nhận ra tầm nhìn của chúng tôi về một mạng lưới phi tập trung: một với chức năng và hiệu suất để hỗ trợ cho việc áp dụng doanh nghiệp và trao quyền cho mọi người trên toàn thế giới.
Với sự giúp đỡ của bạn, chúng tôi bắt đầu thấy mạng Cardano sẽ có khả năng gì, với sự khuyến khích đầy đủ cho người dùng doanh nghiệp và hàng ngày tham gia, tạo và tương tác.

