# Join the roll out of the Cardano Shelley testnet
### **Take part in our testing program**
![](img/2019-06-19-join-the-roll-out-of-the-cardano-shelley-testnet.002.png) 19 June 2019![](img/2019-06-19-join-the-roll-out-of-the-cardano-shelley-testnet.002.png)[ David Esser](tmp//en/blog/authors/david-esser/page-1/)![](img/2019-06-19-join-the-roll-out-of-the-cardano-shelley-testnet.003.png) 6 mins read

![David Esser](img/2019-06-19-join-the-roll-out-of-the-cardano-shelley-testnet.004.png)[](tmp//en/blog/authors/david-esser/page-1/)
### [**David Esser**](tmp//en/blog/authors/david-esser/page-1/)
Senior Product Manager

Cardano

- ![](img/2019-06-19-join-the-roll-out-of-the-cardano-shelley-testnet.005.png)[](https://www.linkedin.com/in/davidesser/ "LinkedIn")
- ![](img/2019-06-19-join-the-roll-out-of-the-cardano-shelley-testnet.006.png)[](https://github.com/davidesser "GitHub")

![Join the roll out of the Cardano Shelley testnet](img/2019-06-19-join-the-roll-out-of-the-cardano-shelley-testnet.007.jpeg)

Many of you will have seen us talk about our [testnets](https://testnet.iohkdev.io/), where we run the versions of Cardano and other testing simulators so we can test our products and get feedback from the community. Some of you have already been playing with the code from our GitHub repos. So as we move from the Byron to the Shelley era, we want to extend that collaboration and learn more from the great talent in our Cardano community.

Nhiều người trong số các bạn sẽ thấy chúng tôi nói về [TestNets] của chúng tôi (https://testnet.iohkdev.io/), nơi chúng tôi chạy các phiên bản của Cardano và các trình mô phỏng thử nghiệm khác để chúng tôi có thể kiểm tra sản phẩm của mình và nhận phản hồi từ cộng đồng.
Một số bạn đã chơi với mã từ các repos GitHub của chúng tôi.
Vì vậy, khi chúng tôi chuyển từ thời Byron đến thời Shelley, chúng tôi muốn mở rộng sự hợp tác đó và học hỏi nhiều hơn từ tài năng lớn trong cộng đồng Cardano của chúng tôi.

With the Rust codebase for Shelley now nearing primetime, weâ€™re asking the community to help us build out a testnet. The Shelley era is all about decentralization, so weâ€™re taking a more decentralized approach to testing and documentation. Itâ€™s an important step in expanding the Cardano technical community and ultimately preparing everyone for the day when the community takes over the blockchain. 

Với cơ sở mã Rust cho Shelley hiện đang gần Primetime, chúng tôi sẽ yêu cầu cộng đồng giúp chúng tôi xây dựng một testnet.
Thời đại Shelley là tất cả về sự phân cấp, vì vậy chúng tôi đang thực hiện một cách tiếp cận phi tập trung hơn để thử nghiệm và tài liệu.
Đây là một bước quan trọng trong việc mở rộng cộng đồng kỹ thuật Cardano và cuối cùng chuẩn bị cho mọi người trong ngày khi cộng đồng tiếp quản blockchain.

For some time, there has been a dedicated and vibrant best practice group on [Telegram](https://t.me/CardanoStakePoolWorkgroup) Â â€“ the Stake Pool Best Practices Telegram group (1,733 members). Thereâ€™s clearly a lot of talent and interest out there. We recently pinned a survey in the channel to learn more about potential stake pool operators. Weâ€™ve had a really positive response, with over 150 full responses so far.

Trong một thời gian, đã có một nhóm thực hành tốt nhất chuyên dụng và sôi động trên [Telegram] (https://t.me/cardanostakepoolworkgroup) Â € của nhóm thực hành tốt nhất của nhóm cổ phần (1.733 thành viên).
Rõ ràng có rất nhiều tài năng và sự quan tâm ngoài kia.
Gần đây chúng tôi đã ghim một cuộc khảo sát trong kênh để tìm hiểu thêm về các nhà khai thác nhóm cổ phần tiềm năng.
Chúng tôi đã có một phản ứng thực sự tích cực, với hơn 150 phản hồi đầy đủ cho đến nay.

Whatâ€™s the range of technical skills and knowledge in the community? What are peopleâ€™s particular interests in staking? Are they keen hobbyists or entrepreneurs with plans to run a stake pool as a business? What equipment are they planning to use? Would marketing or other business support be useful? We asked lots of questions to learn as much as we could. Ultimately, our goal is to find out how we can support the community in implementing Shelleyâ€™s decentralized model in the most effective way we can. It is these people whoâ€™ll be helping to kick things off.

Phạm vi kỹ năng và kiến thức kỹ thuật trong cộng đồng là gì?
Những lợi ích đặc biệt của mọi người trong việc đặt cược là gì?
Họ có thích những người có sở thích hay doanh nhân với kế hoạch điều hành một nhóm cổ phần như một doanh nghiệp không?
Họ dự định sử dụng thiết bị nào?
Tiếp thị hoặc hỗ trợ kinh doanh khác sẽ hữu ích?
Chúng tôi đã hỏi rất nhiều câu hỏi để học nhiều nhất có thể.
Cuối cùng, mục tiêu của chúng tôi là tìm hiểu làm thế nào chúng tôi có thể hỗ trợ cộng đồng trong việc thực hiện mô hình phi tập trung của Shelley theo cách hiệu quả nhất mà chúng tôi có thể.
Chính những người này sẽ giúp đỡ mọi thứ.

So, weâ€™ve started harnessing the power of the Cardano community to roll out a staking testnet. Weâ€™ll be supporting this early group along the way in a number of ways. 

Vì vậy, chúng tôi đã bắt đầu khai thác sức mạnh của cộng đồng Cardano để tung ra một Testnet đặt cược.
Chúng tôi sẽ hỗ trợ nhóm sớm này trên đường đi theo một số cách.

Thereâ€™s now a dedicated 

Bây giờ có một

[](https://github.com/input-output-hk/shelley-testnet "Shelley Testnet, github.com")

[].

code repository and log to support the test program, all open. We will soon release new Shelley 

Kho lưu trữ mã và nhật ký để hỗ trợ chương trình thử nghiệm, tất cả đều mở.
Chúng tôi sẽ sớm phát hành Shelley mới

[](https://testnet.iohkdev.io/cardano/ "testnet.iohkdev.io/cardano/")

[] (https://testnet.iohkdev.io/cardano/ "testnet.iohkdev.io/cardano/")

testnet webpages on our Cardano testnets website. Weâ€™ll publish instructions, videos, tutorials and so on explaining what to do and how to do it. We're writing a pretty good set of documentation for the Rust client. There will be instructional videos on how to install and operate the node as well as report bugs and log issues using GitHub.

Trang web TestNet trên trang web Cardano Testnet của chúng tôi.
Chúng tôi sẽ xuất bản các hướng dẫn, video, hướng dẫn, v.v. để giải thích những việc cần làm và làm thế nào để làm điều đó.
Chúng tôi đang viết một bộ tài liệu khá tốt cho khách hàng rỉ sét.
Sẽ có các video hướng dẫn về cách cài đặt và vận hành nút cũng như báo cáo các lỗi và các vấn đề nhật ký bằng GitHub.

A key part of the testing program will be working with people with mixed levels of technical experience, working across different platforms and configurations. The feedback from this group will ultimately make our technology easier to install, configure, and operate for everyone who follows.

Một phần quan trọng của chương trình thử nghiệm sẽ làm việc với những người có trình độ kinh nghiệm kỹ thuật hỗn hợp, làm việc trên các nền tảng và cấu hình khác nhau.
Phản hồi từ nhóm này cuối cùng sẽ giúp công nghệ của chúng tôi dễ dàng cài đặt, định cấu hình và vận hành cho tất cả những người theo dõi.

The testnet will have a series of releases rolling out in three main phases.

Testnet sẽ có một loạt các bản phát hành được tung ra trong ba giai đoạn chính.

## **Phase 1: The self node, aka â€˜blockchain in a boxâ€™**

## ** Giai đoạn 1: Nút tự, hay còn gọi là - ˜blockchain trong một hộp

The first stage is all about setting up and hosting a â€˜self nodeâ€™. You can think of a self node as â€˜blockchain in a boxâ€™, a minimum viable product (MVP) for testing key capabilities. This is basically a set of tools and documentation to bootstrap your own genesis block and run a multi-node environment on your own machine, where you can see how stake pools actually operate. Itâ€™s like a complete network within a single instance.

Giai đoạn đầu tiên là tất cả về việc thiết lập và lưu trữ một nút tự ".
Bạn có thể nghĩ về một nút tự như "khối trong một hộp, một sản phẩm khả thi tối thiểu (MVP) để thử nghiệm các khả năng chính.
Về cơ bản, đây là một tập hợp các công cụ và tài liệu để bootstrap khối Genesis của riêng bạn và chạy môi trường đa nút trên máy của riêng bạn, nơi bạn có thể thấy cách các nhóm cổ phần thực sự hoạt động.
Nó giống như một mạng hoàn chỉnh trong một trường hợp duy nhất.

Weâ€™ll provide instructions and invite people to run the node through various configurations and give us feedback on what they find. 

Chúng tôi sẽ cung cấp các hướng dẫn và mời mọi người chạy nút thông qua các cấu hình khác nhau và cung cấp cho chúng tôi phản hồi về những gì họ tìm thấy.

But what about the network? Isnâ€™t this supposed to be a decentralized solution weâ€™re testing? Well, although weâ€™re starting with the self node, weâ€™ve coded things so you can implement more features against this self node down the line. So, as we add more functionality â€“ namely the network and incentives components â€“ the code developed against the self node won't have to change much or at all. Thatâ€™s the plan! 

Nhưng những gì về mạng?
Đây không phải là một giải pháp phi tập trung mà chúng ta đang thử nghiệm?
Chà, mặc dù chúng tôi bắt đầu với nút tự, chúng tôi đã mã hóa mọi thứ để bạn có thể triển khai nhiều tính năng hơn so với nút tự này.
Vì vậy, khi chúng tôi thêm nhiều chức năng hơn - cụ thể là các thành phần mạng và ưu đãi - Mã được phát triển dựa trên nút tự sẽ không phải thay đổi nhiều hoặc hoàn toàn.
Đó là kế hoạch!

So, the first phase is about establishing the basic configuration for your set-up that gives a sense of how well things are working locally. The early code will contain just the core functionality, designed to explore the fundamental capabilities. Across the stake pool task force, weâ€™ll be learning about operating on different hardware, operating systems, cloud hosting environments, and technical skill levels. We'll get a much broader set of results data by collaborating with the task force. Â 

Vì vậy, giai đoạn đầu tiên là về việc thiết lập cấu hình cơ bản cho thiết lập của bạn mang lại cảm giác về việc mọi thứ đang hoạt động tốt như thế nào.
Mã ban đầu sẽ chỉ chứa chức năng cốt lõi, được thiết kế để khám phá các khả năng cơ bản.
Trên toàn bộ lực lượng đặc nhiệm nhóm cổ phần, chúng tôi sẽ tìm hiểu về việc vận hành trên các phần cứng, hệ điều hành, môi trường lưu trữ đám mây khác nhau và mức độ kỹ năng kỹ thuật.
Chúng tôi sẽ nhận được một bộ dữ liệu kết quả rộng hơn nhiều bằng cách hợp tác với lực lượng đặc nhiệm.
MỘT

## **Phase 2: Connecting the network**

## ** Giai đoạn 2: Kết nối mạng **

Once weâ€™re happy with phase 1, and have a robust set of self nodes up and running, weâ€™ll start connecting them up. The goal will be to create a single, unified testnet and to add more nodes as we go, scaling the network step by step. So, instead of experimenting within your own instance, youâ€™ll now be moving to a system where youâ€™re talking to nodes across the internet. You're gossiping, you're downloading blocks from peers. And then weâ€™ll be learning from a whole new set of behaviors and potential risk scenarios.

Khi chúng tôi hài lòng với Giai đoạn 1 và có một bộ nút tự mạnh mẽ và chạy, chúng tôi sẽ bắt đầu kết nối chúng.
Mục tiêu sẽ là tạo ra một testnet duy nhất, hợp nhất và thêm nhiều nút hơn khi chúng ta đi, mở rộng mạng từng bước.
Vì vậy, thay vì thử nghiệm trong trường hợp của riêng bạn, giờ đây bạn sẽ chuyển sang một hệ thống nơi bạn đang nói chuyện với các nút trên internet.
Bạn đang buôn chuyện, bạn đang tải xuống các khối từ các đồng nghiệp.
Và sau đó, chúng ta sẽ học hỏi từ một loạt các hành vi mới và các kịch bản rủi ro tiềm ẩn.

## **Phase 3: The incentives system**

## ** Giai đoạn 3: Hệ thống ưu đãi **

This is where we add in a networked incentive system. Moving blocks around is all very well. But Shelleyâ€™s true potential will be realized with staking. This is about demonstrating how staking rewards will go to the stake pools to encourage that.

Đây là nơi chúng tôi thêm vào một hệ thống khuyến khích được nối mạng.
Các khối di chuyển xung quanh là tất cả rất tốt.
Nhưng tiềm năng thực sự của Shelley sẽ được thực hiện với việc đặt cược.
Đây là về việc chứng minh cách các phần thưởng đặt cược sẽ đi đến các nhóm cổ phần để khuyến khích điều đó.

So, at a high level, that's what youâ€™ll see in the coming months. We'll also be working closely with the folks at EMURGO on this. Theyâ€™ll be helping with testing and also ensuring that their Yoroi wallet has all this interoperability. [Seiza, their new blockchain explorer](https://emurgo.io/#/en/blog/seiza-all-new-cardano-ada-blockchain-explorer-developed-by-emurgo), will be a great tool for visualizing a lot of the things that we do that are unique in our ecosystem.

Vì vậy, ở cấp độ cao, đó là những gì bạn sẽ thấy trong những tháng tới.
Chúng tôi cũng sẽ làm việc chặt chẽ với những người ở Emurgo về điều này.
Họ sẽ giúp thử nghiệm và cũng đảm bảo rằng ví Yoroi của họ có tất cả khả năng tương tác này.
.
Hình dung rất nhiều điều chúng ta làm là duy nhất trong hệ sinh thái của chúng ta.

This testing program is an experiment in community collaboration. Thereâ€™ll be a lot of testing, re-coding, improving documentation and training materials, tweaking, and so on along the way. Weâ€™ll be checking the integrity of individual components as well as demonstrating that those components play with each other nicely. The objective is clear, but itâ€™ll be interesting to see how we get there. Weâ€™re committed to it because it fits: a decentralized process to test a decentralized system. And a broad collaboration with the community to test a system that will be owned by the community.

Chương trình thử nghiệm này là một thử nghiệm trong sự hợp tác cộng đồng.
Có rất nhiều thử nghiệm, mã hóa lại, cải thiện tài liệu và tài liệu đào tạo, điều chỉnh, v.v.
Chúng tôi sẽ kiểm tra tính toàn vẹn của các thành phần riêng lẻ cũng như chứng minh rằng các thành phần đó chơi với nhau một cách độc đáo.
Mục tiêu là rõ ràng, nhưng thật thú vị khi xem cách chúng ta đến đó.
Chúng tôi đã cam kết với nó vì nó phù hợp: một quy trình phi tập trung để kiểm tra một hệ thống phi tập trung.
Và sự hợp tác rộng rãi với cộng đồng để kiểm tra một hệ thống sẽ thuộc sở hữu của cộng đồng.

Weâ€™ll keep you all posted. For those who choose to step up and work with us in the program, a sincere thanks in advance to you for your partnership.

Chúng tôi sẽ giữ tất cả các bạn.
Đối với những người chọn bước lên và làm việc với chúng tôi trong chương trình, một lời cảm ơn chân thành trước bạn vì sự hợp tác của bạn.

