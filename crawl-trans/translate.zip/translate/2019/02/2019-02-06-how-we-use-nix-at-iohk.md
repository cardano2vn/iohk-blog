# How we use Nix at IOHK
![](img/2019-02-06-how-we-use-nix-at-iohk.002.png) 6 February 2019![](img/2019-02-06-how-we-use-nix-at-iohk.002.png)[ Rodney Lorrimar](tmp//en/blog/authors/rodney-lorrimar/page-1/)![](img/2019-02-06-how-we-use-nix-at-iohk.003.png) 10 mins read

![Rodney Lorrimar](img/2019-02-06-how-we-use-nix-at-iohk.004.png)[](tmp//en/blog/authors/rodney-lorrimar/page-1/)
### [**Rodney Lorrimar**](tmp//en/blog/authors/rodney-lorrimar/page-1/)
Software Engineer

Engineering

- ![](img/2019-02-06-how-we-use-nix-at-iohk.005.png)[](mailto:rodney.lorrimar@iohk.io "Email")
- ![](img/2019-02-06-how-we-use-nix-at-iohk.006.png)[](https://au.linkedin.com/in/rodneylorrimar "LinkedIn")
- ![](img/2019-02-06-how-we-use-nix-at-iohk.007.png)[](https://github.com/rvl "GitHub")

![How we use Nix at IOHK](img/2019-02-06-how-we-use-nix-at-iohk.008.jpeg)

IOHK has a history of putting great research into practice. This includes the use of functional programming languages, adoption of formal methods, and â€” of course â€” implementing our own peer-reviewed research into blockchain consensus algorithms. We approach the problem of software deployment in similar vein, using ideas which have emerged from recent academic work. This system applies the principles of functional programming to the domain of software package management and system administration.

IOHK có một lịch sử đưa nghiên cứu tuyệt vời vào thực tiễn.
Điều này bao gồm việc sử dụng các ngôn ngữ lập trình chức năng, áp dụng các phương pháp chính thức và tất nhiên là thực hiện nghiên cứu được đánh giá ngang hàng của chúng tôi về các thuật toán đồng thuận blockchain.
Chúng tôi tiếp cận vấn đề triển khai phần mềm trong tĩnh mạch tương tự, sử dụng các ý tưởng xuất hiện từ công việc học tập gần đây.
Hệ thống này áp dụng các nguyên tắc lập trình chức năng cho miền quản lý gói phần mềm và quản trị hệ thống.

In this short technical article I will describe how we leverage Nix at IOHK, and share some of our plans for the future.

Trong bài viết kỹ thuật ngắn này, tôi sẽ mô tả cách chúng tôi tận dụng NIX tại IOHK và chia sẻ một số kế hoạch của chúng tôi cho tương lai.

## **What are Nix, Nixpkgs, and NixOS?**

## ** NIX, NIXPKGS và NIXOS là gì? **

[NixOS](https://nixos.org "nixos.org") is a Linux distribution built on the Nix package manager.

[NIXOS] (https://nixos.org "Nixos.org") là một phân phối Linux được xây dựng trên Trình quản lý gói NIX.

What I personally like about the Nix package manager is its ability to install multiple versions of the same package, or easily apply a source code modification to a package. For Haskell development in particular, there are binary packages for an impressive number of compilers, tools, and Hackage packages available.

Cá nhân tôi thích về trình quản lý gói NIX là khả năng cài đặt nhiều phiên bản của cùng một gói hoặc dễ dàng áp dụng sửa đổi mã nguồn cho gói.
Đối với sự phát triển của Haskell nói riêng, có các gói nhị phân cho số lượng trình biên dịch, công cụ và gói hackage ấn tượng có sẵn.

What sets NixOS apart is its configuration system. It includes a large collection of high-quality modules which are configured declaratively in a uniform way. This is a boon for system administrators who need to apply the same configuration to many systems, or integrate a wide variety of software into one system.

Điều khiến Nixos khác biệt là hệ thống cấu hình của nó.
Nó bao gồm một bộ sưu tập lớn các mô-đun chất lượng cao được cấu hình khai báo theo cách thống nhất.
Đây là một lợi ích cho các quản trị viên hệ thống cần áp dụng cùng một cấu hình cho nhiều hệ thống hoặc tích hợp nhiều phần mềm vào một hệ thống.

Underneath the Nix package manager and NixOS is the Nix language â€” a domain-specific, purely functional, lazily-evaluated language for software configuration and deployment.

Bên dưới Trình quản lý gói NIX và NIXOS là ngôn ngữ NIX-ngôn ngữ được đánh giá theo tên miền cụ thể, hoàn toàn chức năng, được đánh giá cho cấu hình phần mềm và triển khai.

The paper [NixOS: A purely functional Linux distribution](https://nixos.org/~eelco/pubs/nixos-jfp-final.pdf "NixOS: A purely functional Linux distribution, nixos.org") is an excellent introduction. It clearly sets out the problems which NixOS attempts to solve, many of which will be familiar to technical users.

Bài viết [NIXOS: Phân phối Linux chức năng thuần túy] (https://nixos.org/~eelco/pub/nixos-jfp-final.pdf "NIXOS: Phân phối Linux chức năng thuần túy, Nixos.org")
.
Nó rõ ràng đặt ra các vấn đề mà Nixos cố gắng giải quyết, nhiều trong số đó sẽ quen thuộc với người dùng kỹ thuật.

## **Who is behind the NixOS project?**

## ** Ai đứng sau dự án Nixos? **

NixOS was initially created in 2003 at Utrecht University as the research project of Eelco Dolstra, forming the main part of his [doctoral thesis](https://nixos.org/~eelco/pubs/phd-thesis.pdf). Fifteen years later, the NixOS project is run on [GitHub](https://github.com/NixOS/nixpkgs "Nix Packages collection, github.com") with hundreds of contributors involved, and the code base is currently improving at a rate of about 500 git commits per week.

Nixos ban đầu được tạo ra vào năm 2003 tại Đại học Utrecht với tư cách là dự án nghiên cứu của Eelco Dolstra, tạo thành phần chính của [luận án tiến sĩ] (https://nixos.org/~eelco/pub/phd-thesis.pdf).
Mười lăm năm sau, dự án NIXOS được chạy trên [GitHub] (https://github.com/nixos/nixpkgs "Bộ sưu tập gói Nix, GitHub.com") với hàng trăm người đóng góp liên quan và cơ sở mã hiện đang cải thiện tại một
Tỷ lệ khoảng 500 Git cam kết mỗi tuần.

The community also communicate through an active [IRC channel](javascript:void\(0\) "irc.freenode.net/#nixos") on Freenode, a [discussion board](https://discourse.nixos.org/ "discourse.nixos.org"), a (roughly) annual conference, and regular meetups.

Cộng đồng cũng giao tiếp thông qua một [kênh IRC] hoạt động (JavaScript: void \ (0 \) "IRC.Freenode.net/#nixos") trên freenode, một [bảng thảo luận] (https://discourse.nixos.org/
"Diễn ngôn.nixos.org"), một hội nghị thường niên (khoảng) và các cuộc gặp gỡ thường xuyên.

Moreover, several companies provide Nix consulting services, such as [Tweag I/O](https://www.tweag.io/ "tweag.io") and [Mayflower](https://nixos.mayflower.consulting/ "nixos.mayflower.consulting").

Hơn nữa, một số công ty cung cấp dịch vụ tư vấn NIX, chẳng hạn như [tweag I/O] (https://www.tweag.io/ "twweag.io") và [mayflower] (https://nixos.mayflower.consulting/ "
nixos.mayflower.consulting ").

## **Why Nix?**

## ** Tại sao Nix? **

There are many existing systems for software configuration management, some with far more users than Nix. However, we believe that Nix has the best available implementation of 'Infrastructure as Code', not only in terms of features, but also in its design and potential.

Có nhiều hệ thống hiện có để quản lý cấu hình phần mềm, một số có nhiều người dùng hơn NIX.
Tuy nhiên, chúng tôi tin rằng NIX có việc triển khai 'cơ sở hạ tầng dưới dạng mã' tốt nhất, không chỉ về mặt tính năng, mà còn trong thiết kế và tiềm năng của nó.

If you treat your deployment as a program written in a functional language, then you gain the advantages of functional programming like referential transparency, safe code reuse, and the ability to unit test your deployment. At its heart, the Nix 'derivation' abstracts details away and allows software modules to be built and used in more or less the same way, regardless of their source language.

Nếu bạn coi việc triển khai của mình là một chương trình được viết bằng ngôn ngữ chức năng, thì bạn sẽ đạt được những lợi thế của lập trình chức năng như minh bạch tham chiếu, tái sử dụng mã an toàn và khả năng kiểm tra việc triển khai của bạn.
Tại trung tâm của nó, NIX 'Derivation' Tóm tắt các chi tiết và cho phép các mô -đun phần mềm được xây dựng và sử dụng theo cùng một cách, bất kể ngôn ngữ nguồn của chúng.

A derivation is a function which takes source code, build tools, and library dependencies, and produces an immutable software package; because Nix is pure (in the functional programming sense), if any of the inputs change, then the result is a different software package. Alternatively, if a derivation with exactly the same inputs has already been built elsewhere (by continuous integration (CI), for example), Nix will just download that package, rather than building the derivation itself, reducing duplication of work.

Đạo hàm là một chức năng lấy mã nguồn, công cụ xây dựng và phụ thuộc thư viện và tạo ra gói phần mềm bất biến;
Bởi vì NIX là thuần túy (theo nghĩa lập trình chức năng), nếu bất kỳ đầu vào nào thay đổi, thì kết quả là một gói phần mềm khác.
Ngoài ra, nếu một đạo hàm có cùng một đầu vào đã được xây dựng ở nơi khác (ví dụ như tích hợp liên tục (CI), NIX sẽ chỉ tải xuống gói đó, thay vì xây dựng chính dẫn xuất, làm giảm sự trùng lặp của công việc.

The way Nix calculates whether a derivation input has changed is by taking its cryptographic hash. Dependencies are recursive, so this hash is actually a hash of hashes â€” a powerful concept instantly recognizable to blockchain enthusiasts.

Cách NIX tính toán liệu đầu vào đạo hàm có thay đổi hay không bằng cách lấy băm mật mã của nó.
Sự phụ thuộc là đệ quy, vì vậy băm này thực sự là một băm của băm - một khái niệm mạnh mẽ có thể nhận ra ngay lập tức đối với những người đam mê blockchain.

## **How we use Nix**

## ** Cách chúng tôi sử dụng Nix **

Here are some examples of how we are using Nix at IOHK.

Dưới đây là một số ví dụ về cách chúng tôi đang sử dụng NIX tại IOHK.

### **1. Deployment of the Cardano SL network**

### ** 1.
Triển khai mạng Cardano SL **

We run around 200 compute nodes in AWS for the [various testnets](https://testnet.iohkdev.io "Cardano Testnets, testnet.iohkdev.io"), the Cardano SL Byron mainnet, and the Cardano SL staging deployment (an environment used to test upgrades).

Chúng tôi chạy khoảng 200 nút tính toán trong AWS cho [các testnets khác nhau] (https://testnet.iohkdev.io "Cardano Testnet, Testnet.iohkdev.io"), Cardano SL Byron Mainnet và Cardano SL tổ chức
Môi trường được sử dụng để kiểm tra nâng cấp).

These are all NixOS systems deployed with [NixOps](https://nixos.org/nixops/ "nixos.org/nixops").

Đây là tất cả các hệ thống NIXOS được triển khai với [NixOps] (https://nixos.org/nixops/ "Nixos.org/nixops").

We have written a tool called [iohk-ops](https://github.com/input-output-hk/iohk-ops "iohk-ops, github.com"), which *generates* a NixOps network from an abstract topology description. The topology description describes the number of Cardano SL relay nodes, which data center they are hosted in, and static routes between peers. iohk-ops calls on NixOps to execute the deployment.

Chúng tôi đã viết một công cụ gọi là [iohk-ops] (https://github.com/input-output-hk/iohk-ops "iohk-ops, github.com")
Mô tả cấu trúc liên kết.
Mô tả cấu trúc liên kết mô tả số lượng các nút chuyển tiếp Cardano SL, trung tâm dữ liệu mà chúng được lưu trữ trong và các tuyến tĩnh giữa các đồng nghiệp.
IOHK-OPS gọi trên NixOps để thực hiện triển khai.

The same tool allows deployment of smaller 'developer clusters' which are used for testing activities. These clusters share the same deployment code, and identical software versions, but are smaller and can be started and stopped as necessary.

Công cụ tương tự cho phép triển khai 'các cụm nhà phát triển' nhỏ hơn được sử dụng cho các hoạt động thử nghiệm.
Các cụm này chia sẻ cùng một mã triển khai và các phiên bản phần mềm giống hệt nhau, nhưng nhỏ hơn và có thể được bắt đầu và dừng khi cần thiết.

The rollback features of NixOS and NixOps have already proved invaluable several times in our staging deployments: the whole network can be redeployed with a single command, or just specific nodes.

Các tính năng rollback của NIXOS và NIXOPS đã được chứng minh là vô giá nhiều lần trong việc triển khai dàn dựng của chúng tôi: toàn bộ mạng có thể được triển khai lại với một lệnh hoặc chỉ các nút cụ thể.

With NixOps we have the ability to apply configuration tweaks and code patches, then rebuild *at deploy-time*, confident that the result will be identical to what comes from CI, and can be undone without leaving a mess behind.

Với NixOps, chúng tôi có khả năng áp dụng các điều chỉnh cấu hình và bản vá mã, sau đó xây dựng lại *trong thời gian triển khai *, tự tin rằng kết quả sẽ giống hệt với những gì đến từ CI và có thể được hoàn tác mà không để lại một mớ hỗn độn.

### **2. Reproducible deployment**

### ** 2.
Triển khai có thể tái tạo **

Extreme measures such as deploy-time code modification are usually not required, because the deployment environment can be reproduced and tested locally, ensuring any problems are caught well in advance.

Các biện pháp cực đoan như sửa đổi mã thời gian triển khai thường không cần thiết, bởi vì môi trường triển khai có thể được sao chép và thử nghiệm tại địa phương, đảm bảo mọi vấn đề đều bị bắt trước.

As mentioned earlier, a Nix derivation is a pure function. The code can be run locally with exactly the same environment and libraries (up to the Linux kernel) as are used in production.

Như đã đề cập trước đó, một dẫn xuất Nix là một chức năng thuần túy.
Mã này có thể được chạy cục bộ với chính xác cùng một môi trường và thư viện (lên đến nhân Linux) như được sử dụng trong sản xuất.

### **3. Fast rebuilds of Docker images**

### ** 3.
Xây dựng lại hình ảnh docker ** nhanh chóng

Docker's strengths include its immutability, encapsulation, and reproducibility, traits shared by Nix. However, it is severely limited by its data model and restricted DSL.

Điểm mạnh của Docker bao gồm tính bất biến, đóng gói và khả năng tái tạo, các đặc điểm được chia sẻ bởi NIX.
Tuy nhiên, nó bị giới hạn nghiêm trọng bởi mô hình dữ liệu của nó và DSL bị hạn chế.

The structure of software dependencies is a tree, not a sequence of layers, as modelled by Docker. A typical annoyance when building Docker images with a Dockerfile is that if a layer near the bottom changes, then everything above must be rebuilt. Furthermore, unless steps are taken to use multiple build stages, intermediate build products from lower layers will be included in the final image.

Cấu trúc của các phụ thuộc phần mềm là một cây, không phải là một chuỗi các lớp, theo mô hình của Docker.
Một phiền toái điển hình khi xây dựng hình ảnh Docker với Dockerfile là nếu một lớp gần đáy thay đổi, thì mọi thứ trên phải được xây dựng lại.
Hơn nữa, trừ khi các bước được thực hiện để sử dụng nhiều giai đoạn xây dựng, các sản phẩm xây dựng trung gian từ các lớp thấp hơn sẽ được đưa vào hình ảnh cuối cùng.

In contrast, a Nix package will only be rebuilt if its dependencies (or their dependencies) have changed. The minimum *closure* of a Nix package contains only what is necessary to run that software.

Ngược lại, gói NIX sẽ chỉ được xây dựng lại nếu các phụ thuộc của nó (hoặc phụ thuộc của chúng) đã thay đổi.
Tối thiểu * đóng * của gói Nix chỉ chứa những gì cần thiết để chạy phần mềm đó.

Thus we can generate Docker images from the closure of Nix derivations which are minimal and fast to rebuild. The build process can also be parameterized by defining it as a function in the Nix language.

Do đó, chúng ta có thể tạo ra hình ảnh docker từ việc đóng các dẫn xuất NIX tối thiểu và nhanh chóng để xây dựng lại.
Quá trình xây dựng cũng có thể được tham số hóa bằng cách xác định nó là một hàm trong ngôn ngữ NIX.

### **4. Declarative deployment of macOS build slaves**

### **4.
Triển khai khai báo nô lệ xây dựng macOS **

To produce the macOS installer packages of [Daedalus](https://daedaluswallet.io/#download), we maintain a small collection of macOS systems (hosted by [MacinCloud](https://www.macincloud.com/ "macincloud.com")). These systems were quite tedious to maintain until we started using [nix-darwin](https://github.com/LnL7/nix-darwin "Nix Darwin, github.com"). Nix-darwin allows declarative configuration of macOS systems in a similar way to NixOS.

Để sản xuất các gói cài đặt macOS của [Daedalus] (https://daedaluswallet.io/#doad), chúng tôi duy trì một bộ sưu tập nhỏ các hệ thống macOS (được lưu trữ bởi [MacinCloud] (https://www.macincloud.com/ "Macincloud
.com ")).
Các hệ thống này khá tẻ nhạt để duy trì cho đến khi chúng tôi bắt đầu sử dụng [Nix-Darwin] (https://github.com/lnl7/nix-darwin "Nix Darwin, github.com").
Nix-Darwin cho phép cấu hình khai báo của các hệ thống MACOS theo cách tương tự như NIXOS.

We wrote [a script](https://github.com/input-output-hk/iohk-ops/tree/master/nix-darwin "iohk-ops/nix-darwin, github.com") to set up the Mac through SSH. All things are managed through Nix code, including the build environment, monitoring, and SSH access.

Chúng tôi đã viết [một tập lệnh] (https://github.com/input-output-hk/iohk-ops/tree/master/nix-darwin "
Mac thông qua SSH.
Tất cả mọi thứ được quản lý thông qua mã NIX, bao gồm môi trường xây dựng, giám sát và truy cập SSH.

### **5. Cross-compiling Cardano SL for Windows**

### ** 5.
Cardano SL cross Commiling cho Windows **

To produce the Windows installer packages of [Daedalus](https://daedaluswallet.io/#download "Daedalus Wallet, daedaluswallet.io"), we needed to rely on resource-limited build instances of CI providers, or maintain a small collection of Windows systems. The Windows CI infrastructure has been a constant source of problems for us.

Để sản xuất các gói trình cài đặt Windows của [Daedalus] (https://daedaluswallet.io/#doad "Ví Daedalus, Daedaluswallet.io"), chúng tôi cần dựa vào các trường hợp xây dựng giới hạn tài nguyên của các nhà cung cấp CI hoặc duy trì một bộ sưu tập nhỏ
của các hệ thống Windows.
Cơ sở hạ tầng Windows CI là một nguồn vấn đề liên tục cho chúng tôi.

However, we are now able to cross-compile Haskell code for Windows on Linux! The next major version of Daedalus for Windows will ship with a cardano-node.exe that was built with Nix on Linux.

Tuy nhiên, chúng tôi hiện có thể kết hợp mã Haskell chéo cho Windows trên Linux!
Phiên bản chính tiếp theo của Daedalus cho Windows sẽ gửi với một cardano node.exe được xây dựng với NIX trên Linux.

Due to the size of Cardano SL, this is quite an achievement, and the result of several months of hard work.

Do kích thước của Cardano SL, đây là một thành tích khá lớn và kết quả của một vài tháng làm việc chăm chỉ.

### **6. Development environments**

### ** 6.
Môi trường phát triển **

With nix-shell, we can provide development environments containing all tools and libraries necessary to build a project, pinned to precisely defined versions.

Với Nix-Shell, chúng tôi có thể cung cấp các môi trường phát triển chứa tất cả các công cụ và thư viện cần thiết để xây dựng một dự án, được ghim vào các phiên bản được xác định chính xác.

In [cardano-sl](https://github.com/input-output-hk/cardano-sl "Cardano SL, github.com"), the Nix shell supports either the stack workflow, or cabal new-build with Haskell pre-built dependencies downloaded from the IOHK binary cache.

Trong [cardano-sl] (https://github.com/input-output-hk
Các phụ thuộc được xây dựng trước được tải xuống từ bộ đệm nhị phân IOHK.

In [daedalus](https://github.com/input-output-hk/daedalus "Daedalus, github.com"), the Nix shell provides yarn, and a method of running a Cardano SL blockchain and wallet locally.

Trong [Daedalus] (https://github.com/input-output-hk/daedalus "Daedalus, github.com"), Nix Shell cung cấp sợi và phương pháp chạy blockchain Cardano SL và ví cục bộ.

Developers and users who are not familiar with build tools from other languages such as Cabal, Stack (Haskell), NPM, Yarn (Javascript), or Cargo (Rust), are still able to rebuild (or download a cached build from CI), just by running nix build.

Các nhà phát triển và người dùng không quen thuộc với các công cụ xây dựng từ các ngôn ngữ khác như Cabal, Stack (Haskell), NPM, Sợi (JavaScript) hoặc hàng hóa (rỉ sét), vẫn có thể xây dựng lại (hoặc tải xuống bản dựng được lưu trong bộ nhớ cache từ CI),
Chỉ bằng cách chạy Nix Build.

There are other tools for providing reproducible development environments, such as Apache Maven, or Docker, but these are not easily composable. Because Nix is a functional language, development environments are the application of functions, which can be composed. So with Nix you can write a function that combines development environments, or just the parts that you need.

Có các công cụ khác để cung cấp môi trường phát triển có thể tái tạo, chẳng hạn như Apache Maven hoặc Docker, nhưng chúng không dễ dàng kết hợp.
Bởi vì NIX là ngôn ngữ chức năng, môi trường phát triển là ứng dụng của các chức năng, có thể được sáng tác.
Vì vậy, với NIX, bạn có thể viết một chức năng kết hợp môi trường phát triển hoặc chỉ các phần bạn cần.

## **Future directions**

## ** Hướng dẫn trong tương lai **

2019 will be an exciting year for IOHK, with several ambitious projects in the pipeline. We anticipate that Nix will play a large part in the success of these projects. Some of the things we have planned are:

Năm 2019 sẽ là một năm thú vị đối với IOHK, với một số dự án đầy tham vọng trong đường ống.
Chúng tôi dự đoán rằng Nix sẽ đóng một phần lớn trong sự thành công của các dự án này.
Một số điều chúng tôi đã lên kế hoạch là:

### **Pure Daedalus build**

### ** bản dựng daedalus tinh khiết **

We currently build the Daedalus installers for Windows and macOS using a Haskell script. This is slower than necessary and needs to run on a Windows or macOS system: we would prefer to build on Linux with Nix so that software components can be cached as necessary.

Chúng tôi hiện đang xây dựng các trình cài đặt Daedalus cho Windows và MacOS bằng tập lệnh Haskell.
Điều này chậm hơn mức cần thiết và cần chạy trên hệ thống Windows hoặc MacOS: chúng tôi muốn xây dựng trên Linux với NIX để các thành phần phần mềm có thể được lưu trữ khi cần thiết.

### **iohk-nix**

### ** iohk-nix **

IOHK is splitting the Cardano SL code base into independent modules, which must be integrated into a final product build. We have started a repository of common Nix code [iohk-nix](https://github.com/input-output-hk/iohk-nix "input-output-hk/iohk-nix, github.com") that can be re-used by each Cardano SL subproject.

IOHK đang chia cơ sở mã Cardano SL thành các mô -đun độc lập, phải được tích hợp vào bản dựng sản phẩm cuối cùng.
Chúng tôi đã bắt đầu một kho lưu trữ mã NIX phổ biến [IOHK-NIX] (https://github.com/input-output-hk/iohk-nix "
được sử dụng lại bởi mỗi tiểu mục Cardano SL.

As with all languages, Nix code can be written in a beautiful or an awful way â€” and because Nix does not have a static type system, the awful code is really bad. So part of this project will be an effort to improve the legibility and documentation of our Nix code so that it's easy to understand and maintain.

Như với tất cả các ngôn ngữ, mã NIX có thể được viết một cách đẹp hoặc một cách khủng khiếp - và vì NIX không có hệ thống loại tĩnh, mã khủng khiếp thực sự xấu.
Vì vậy, một phần của dự án này sẽ là một nỗ lực để cải thiện mức độ dễ đọc và tài liệu của mã NIX của chúng tôi để dễ hiểu và duy trì.

### **Tools for deploying a node or stake pool**

### ** Các công cụ để triển khai một nút hoặc nhóm cổ phần **

In 2019, Cardano SL will be decentralized. We would like to make it super easy for technical users to deploy one or more Cardano SL nodes, or operate a stake pool.

Trong năm 2019, Cardano SL sẽ được phân cấp.
Chúng tôi muốn làm cho người dùng kỹ thuật siêu dễ dàng triển khai một hoặc nhiều nút Cardano SL hoặc vận hành nhóm cổ phần.

This will include:

Điều này sẽ bao gồm:

- Smoothing the rough corners of iohk-ops to make it ready for public use.

- Làm mịn các góc thô của iohk-ops để làm cho nó sẵn sàng để sử dụng công cộng.

- Providing a variety of build options such as Docker images, or fully statically-linked executables.

- Cung cấp nhiều tùy chọn xây dựng như hình ảnh Docker hoặc các tệp thực thi được liên kết hoàn toàn.

- Using the tools available in NixOS to provide a turn-key monitoring setup for all the necessary application-level metrics.

-Sử dụng các công cụ có sẵn trong NIXOS để cung cấp thiết lập giám sát chìa khóa quay cho tất cả các số liệu cấp ứng dụng cần thiết.

### **nix-tools Haskell Builder**

### ** Nix-tools Haskell Builder **

The Nix Haskell build infrastructure needed some significant rework in order to cross-compile Haskell to target Windows, mostly to track more information about compiler flags and dependencies.

Cơ sở hạ tầng Nix Haskell Build cần một số việc làm lại đáng kể để kết hợp chéo Haskell để nhắm mục tiêu các cửa sổ, chủ yếu để theo dõi thêm thông tin về cờ biên dịch và phụ thuộc.

The result is a more powerful Haskell builder, and a new implementation of stack2nix which runs faster, among other things. This Haskell build infrastructure is called [nix-tools](https://github.com/input-output-hk/nix-tools "input-output-hk/nix-tools, github.com"). We aim to fill in the missing parts and upstream it to Nixpkgs in the coming year.

Kết quả là một người xây dựng Haskell mạnh mẽ hơn và một triển khai mới của Stack2Nix chạy nhanh hơn, trong số những thứ khác.
Cơ sở hạ tầng Build Build Haskell này được gọi là [Nix-Tools] (https://github.com/input-output-hk/nix-tools "Input-output-hk/nix-tools, github.com").
Chúng tôi mong muốn điền vào các bộ phận bị thiếu và ngược dòng nó thành NIXPKG trong năm tới.

This subject is so interesting that it deserves its own blog post, which we are looking forward to posting soon.

Chủ đề này rất thú vị đến nỗi nó xứng đáng với bài đăng trên blog của riêng mình, mà chúng tôi mong muốn được đăng sớm.

## **Conclusion**

## **Sự kết luận**

This was a quick run-through of how we use Nix to help develop and deploy Cardano.

Đây là một cuộc chạy nhanh về cách chúng tôi sử dụng NIX để giúp phát triển và triển khai Cardano.

It's not all excellent of course. Users find that Nix has a steep learning curve, and that the community is relatively small. We also have our own wish-list of features and bug fixes for Nix that are not implemented yet.

Tất nhiên không phải tất cả đều tuyệt vời.
Người dùng thấy rằng Nix có đường cong học tập dốc và cộng đồng tương đối nhỏ.
Chúng tôi cũng có danh sách các tính năng và sửa lỗi của riêng mình cho NIX chưa được triển khai.

If you are interested in learning more about Nix, then visit the [NixOS website](https://nixos.org "nixos.org"). If you like coding or system administration, it's very easy to start contributing to the NixOS project. It takes a little while to get oriented with the Nix language, but then you'll find that pretty much everything you need to know is in a single git repository.

Nếu bạn quan tâm đến việc tìm hiểu thêm về NIX, thì hãy truy cập [trang web Nixos] (https://nixos.org "Nixos.org").
Nếu bạn thích mã hóa hoặc quản trị hệ thống, rất dễ bắt đầu đóng góp cho dự án NIXOS.
Phải mất một chút thời gian để được định hướng với ngôn ngữ Nix, nhưng sau đó bạn sẽ thấy rằng hầu hết mọi thứ bạn cần biết đều trong một kho lưu trữ Git duy nhất.

At IOHK we regularly contribute back to the NixOS project. These contributions include improvements to packages and NixOS modules, and contracting developers to make larger improvements. Additionally, simply by using NixOS at a large scale in research and commercial projects, we contribute to the ecosystem â€” by publishing our source code under a free licence, submitting bug reports, or sharing our experiences with the community.

Tại IOHK, chúng tôi thường xuyên đóng góp trở lại dự án Nixos.
Những đóng góp này bao gồm các cải tiến cho các gói và mô -đun NixOS và các nhà phát triển ký kết để thực hiện các cải tiến lớn hơn.
Ngoài ra, chỉ cần sử dụng NIXOS ở quy mô lớn trong các dự án nghiên cứu và thương mại, chúng tôi đóng góp cho hệ sinh thái - bằng cách xuất bản mã nguồn của chúng tôi theo giấy phép miễn phí, gửi báo cáo lỗi hoặc chia sẻ kinh nghiệm của chúng tôi với cộng đồng.

### **We are hiring**

### **Chúng tôi đang thuê**

The IOHK team is growing, and we are looking for the right people to join us. If helping develop a blockchain platform more advanced than any other is something that interests you, then check out our [job listings](tmp//en/careers/ "Careers, iohk.io") and get in touch!

Nhóm IOHK đang phát triển và chúng tôi đang tìm kiếm những người phù hợp để tham gia với chúng tôi.
Nếu giúp phát triển một nền tảng blockchain tiên tiến hơn bất kỳ nền tảng nào khác là điều mà bạn quan tâm, thì hãy xem [Danh sách công việc] của chúng tôi (TMP // EN/sự nghiệp/"Nghề nghiệp, iohk.io") và liên lạc!

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2019-02-06-how-we-use-nix-at-iohk.009.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

