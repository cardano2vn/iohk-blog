# Training blockchain developers in Africa
### **Women from Ethiopia and Uganda get to grips with Haskell**
![](img/2019-04-04-training-blockchain-developers-in-africa.002.png) 4 April 2019![](img/2019-04-04-training-blockchain-developers-in-africa.002.png)[ Lars Brünjes](tmp//en/blog/authors/lars-brunjes/page-1/)![](img/2019-04-04-training-blockchain-developers-in-africa.003.png) 10 mins read

![Lars Brünjes](img/2019-04-04-training-blockchain-developers-in-africa.004.png)[](tmp//en/blog/authors/lars-brunjes/page-1/)
### [**Lars Brünjes**](tmp//en/blog/authors/lars-brunjes/page-1/)
Education Director

Education

- ![](img/2019-04-04-training-blockchain-developers-in-africa.005.png)[](mailto:lars.bruenjes@iohk.io "Email")
- ![](img/2019-04-04-training-blockchain-developers-in-africa.006.png)[](https://www.linkedin.com/in/dr-lars-br%C3%BCnjes-1640993b "LinkedIn")
- ![](img/2019-04-04-training-blockchain-developers-in-africa.007.png)[](https://twitter.com/LarsBrunjes "Twitter")
- ![](img/2019-04-04-training-blockchain-developers-in-africa.008.png)[](https://github.com/brunjlar "GitHub")

When I got off the plane at Bole airport in Addis Ababa on the evening of January 4, I did not know what to expect. It was my first time in [Ethiopia](https://bitcoinmagazine.com/articles/where-coffee-just-grows-connecting-ethiopian-agritech-blockchain/ "Connecting Ethiopian Agritech to the Blockchain, bitcoinmagazine.com"), and all I knew was that my Canadian colleague Dr [Polina Vinogradova](tmp//en/team/polina-vinogradova/ "Polina Vinogradova, iohk.io"), an IOHK formal methods expert, and I were supposed to teach a three-month-long Haskell course to a class of young Ethiopian and Ugandan women. When our students graduated three months later on March 22, it was the highlight of my professional life. Words fail to describe how very proud I am of these courageous young women who sacrificed so much to attend the class, who worked tirelessly and hard, eager to start tackling some of the most pressing problems their countries face.

Khi tôi xuống máy bay tại Sân bay Bole ở Addis Ababa vào tối ngày 4 tháng 1, tôi không biết phải mong đợi điều gì.
Đây là lần đầu tiên tôi ở [Ethiopia] (https://bitcoinmagazine.com/articles/where-coffee-just-grows-connecting-ethiopian-agritech-blockchain/ "Kết nối agritech của Ethiopia với blockchain, bitcoinmagazine.com")
Và tất cả những gì tôi biết là đồng nghiệp Canada của tôi, Tiến sĩ [Polina Vinogradova] (TMP // EN/Team/Polina-Vinogradova/"Polina Vinogradova, Iohk.io"), một chuyên gia phương pháp chính thức của IOHK, và tôi được cho là dạy ba
-Khóa học Haskell dài đến một lớp phụ nữ trẻ người Ethiopia và người Uganda.
Khi các sinh viên của chúng tôi tốt nghiệp ba tháng sau đó vào ngày 22 tháng 3, đó là điểm nổi bật trong cuộc sống chuyên nghiệp của tôi.
Những từ không thể mô tả tôi rất tự hào về những người phụ nữ trẻ can đảm này đã hy sinh rất nhiều để tham dự lớp học, những người làm việc không mệt mỏi và chăm chỉ, háo hức bắt đầu giải quyết một số vấn đề cấp bách nhất mà đất nước họ gặp phải.

I stand humbled, not only by their fierce intelligence and passion, but also by their gentleness and kindness.

Tôi đứng khiêm tốn, không chỉ bởi trí thông minh và niềm đam mê mãnh liệt của họ, mà còn bởi sự dịu dàng và lòng tốt của họ.

The course had been organized by [John O'Connor](tmp//en/team/john-oconnor/ "John O'Connor, iohk.io"), IOHK's director of African operations, in co-operation with the [Ethiopian Ministry of Innovation and Technology](http://www.mcit.gov.et/ "Ethiopian Ministry of Innovation and Technology, mcit.gov.et"), and the [Ugandan government](https://www.gou.go.ug "Uganda National Web Portal, gou.go.ug"). We had 22 students, 18 from Ethiopia and four from Uganda. All the attendees had studied an IT-related subject at university, some were just graduating, others had worked for several years in software development or lecturing at university.

Khóa học đã được tổ chức bởi [John O'Connor] (TMP // EN/Team/John-Oconnor/"John O'Connor, IOHK.IO"), Giám đốc điều hành châu Phi của IOHK, hợp tác với [Ethiopia
Bộ đổi mới và công nghệ] (http://www.mcit.gov.et/ "Bộ đổi mới và công nghệ của Ethiopia, mcit.gov.et") và [Chính phủ Ugandan] (https: //www.gou.
GO.UG "Cổng thông tin web quốc gia Uganda, gou.go.ug").
Chúng tôi đã có 22 sinh viên, 18 sinh viên từ Ethiopia và bốn sinh viên từ Uganda.
Tất cả những người tham dự đã học một môn học liên quan đến CNTT tại trường đại học, một số người chỉ tốt nghiệp, những người khác đã làm việc trong nhiều năm trong phát triển phần mềm hoặc giảng dạy tại trường đại học.

Most of the Ethiopian students were from Addis Ababa, but some were from far away and had to leave their family and friends behind to attend the course. The four Ugandan students lived in a hostel, spending three months in a country strange and foreign to them, not speaking the language and unfamiliar with local customs.

Hầu hết các sinh viên người Ethiopia đến từ Addis Ababa, nhưng một số người đã ở rất xa và phải bỏ lại gia đình và bạn bè của họ để tham dự khóa học.
Bốn sinh viên Ugandan sống trong một ký túc xá, dành ba tháng ở một quốc gia lạ và xa lạ với họ, không nói ngôn ngữ và không quen thuộc với phong tục địa phương.

![The four students from Uganda were a long way from home](img/2019-04-04-training-blockchain-developers-in-africa.009.png) 

**The four students from Uganda were a long way from home.**

** Bốn học sinh từ Uganda cách nhà một chặng đường dài. **

Teaching students with such diverse backgrounds sounds challenging, but the fact that none of them had any experience with functional programming in general or Haskell in particular made it easier: knowing other programming languages does not really help much when learning Haskell, and can even be counterproductive.

Dạy học sinh có nền tảng đa dạng như vậy nghe có vẻ thách thức, nhưng thực tế là không ai trong số họ có bất kỳ kinh nghiệm nào với lập trình chức năng nói chung hoặc Haskell nói riêng làm cho nó dễ dàng hơn: biết các ngôn ngữ lập trình khác không thực sự giúp ích nhiều khi học Haskell, và thậm chí có thể phản tác dụng
.

[Haskell](https://www.haskell.org/ "haskell.org") is the most important programming language used by IOHK. It is a functional language, whereas most well-known languages are imperative and object-oriented. Haskell is high-level, mathematical, extremely flexible and expressive, not really mainstream; an ideal language for setting out our complicated protocols and cryptographic algorithms efficiently and in a provably correct way.

[Haskell] (https://www.haskell.org/ "haskell.org") là ngôn ngữ lập trình quan trọng nhất được IOHK sử dụng.
Đó là một ngôn ngữ chức năng, trong khi hầu hết các ngôn ngữ nổi tiếng là bắt buộc và hướng đối tượng.
Haskell là cấp cao, toán học, cực kỳ linh hoạt và biểu cảm, không thực sự chính thống;
Một ngôn ngữ lý tưởng để thiết lập các giao thức phức tạp và thuật toán mật mã của chúng tôi một cách hiệu quả và theo một cách chính xác có thể chứng minh được.

![Bethelhem Teka with her family](img/2019-04-04-training-blockchain-developers-in-africa.010.jpeg) 

**Bethelhem Teka with her family**

** Bethelhem teka cùng gia đình **

Haskell is difficult to teach and to learn — not because it is intrinsically more complicated than other languages, but because it forces the programmer to learn a new way of thinking, to approach problems in a way unfamiliar to developers used to Java, Python or JavaScript. Learning Haskell is a mind-opening (and mind-blowing!) experience. After learning it, even if you never use Haskell again, you have a much broader perspective and have learnt to see problems in a different light. You will be a better developer, no matter what.

Haskell rất khó dạy và học hỏi - không phải vì nó thực chất phức tạp hơn các ngôn ngữ khác, mà bởi vì nó buộc lập trình viên phải học một cách suy nghĩ mới, để tiếp cận các vấn đề theo cách xa lạ với các nhà phát triển đã sử dụng cho Java, Python hoặc JavaScript
.
Học Haskell là một trải nghiệm mở đầu tâm trí (và gây chú ý!).
Sau khi học nó, ngay cả khi bạn không bao giờ sử dụng Haskell nữa, bạn có một viễn cảnh rộng hơn nhiều và đã học cách nhìn thấy các vấn đề ở một ánh sáng khác.
Bạn sẽ là một nhà phát triển tốt hơn, bất kể điều gì.

This is what one of our Ethiopian students, Bethelhem Teka, says about Haskell and the course:

Đây là những gì một trong những sinh viên Ethiopia của chúng tôi, Bethelhem Teka, nói về Haskell và khóa học:

Despite coding on imperative programming languages for more than six years, I was a stranger to the functional programming basis of Haskell. Initially it was exciting to internalize its promises of being functional, lazy, pure, no side-effects, and so on. 

Mặc dù mã hóa trên các ngôn ngữ lập trình bắt buộc trong hơn sáu năm, tôi là người lạ đối với cơ sở lập trình chức năng của Haskell.
Ban đầu thật thú vị khi nội tâm hóa những lời hứa của nó là chức năng, lười biếng, tinh khiết, không có tác dụng phụ, v.v.

There are object-oriented concepts used in Haskell, but they are implemented differently, and it was weird to hear some facts like, no inheritance and no objects. 

Có các khái niệm hướng đối tượng được sử dụng trong Haskell, nhưng chúng được thực hiện khác nhau, và thật kỳ lạ khi nghe một số sự thật như, không thừa kế và không có đối tượng.

Obviously, there were many tough times on the course, especially when interpreting concepts into code. Being a crucial element of the language, understanding and implementing monad to achieve purity functionality was even harder. 

Rõ ràng, có nhiều thời điểm khó khăn trong khóa học, đặc biệt là khi diễn giải các khái niệm thành mã.
Trở thành một yếu tố quan trọng của ngôn ngữ, sự hiểu biết và thực hiện Monad để đạt được chức năng tinh khiết thậm chí còn khó hơn.

There were many silly questions that came into my mind at different points, like wondering how Haskell kept its purity and avoided side-effects before discovery of monad, but these were soon answered by Lars or Polina or friends. 

Có nhiều câu hỏi ngớ ngẩn xuất hiện trong tâm trí tôi ở những điểm khác nhau, như tự hỏi làm thế nào Haskell giữ được sự thuần khiết của nó và tránh các tác dụng phụ trước khi phát hiện ra Monad, nhưng những điều này đã sớm được Lars hoặc Polina hoặc bạn bè trả lời.

There are also other points that I need to take into my own assignments and dig further into for the future. 

Ngoài ra còn có những điểm khác mà tôi cần phải thực hiện các nhiệm vụ của riêng mình và đào sâu hơn cho tương lai.

Finally, I feel lucky to have learnt the functional programming language paradigm as a whole and I find all its notions amazing and promising. 

Cuối cùng, tôi cảm thấy may mắn vì đã học được toàn bộ mô hình ngôn ngữ lập trình chức năng và tôi thấy tất cả các quan niệm của nó thật tuyệt vời và đầy hứa hẹn.

I cannot say that I have understood each and every concept covered in the course, but it has given me the confidence to start working on it and read more. 

Tôi không thể nói rằng tôi đã hiểu từng khái niệm được đề cập trong khóa học, nhưng nó đã cho tôi sự tự tin để bắt đầu làm việc với nó và đọc thêm.

![Being 2,500m above sea level keeps Addis cool](img/2019-04-04-training-blockchain-developers-in-africa.011.jpeg) 

**Being 2,500m above sea level keeps Addis cool**

** Đang 2.500m so với mực nước biển giữ cho addis mát mẻ **

Circumstances were less than ideal, and we were facing problems all the time. The traffic was horrific and some of the students spent three hours every morning getting to class.

Hoàn cảnh ít hơn lý tưởng, và chúng tôi đã phải đối mặt với vấn đề mọi lúc.
Giao thông thật kinh khủng và một số sinh viên đã dành ba giờ mỗi sáng để đến lớp.

The internet was unreliable, and most of our students did not have access at home, which forced them to stay late after class to work on their assignments. Even in the classroom, we suffered many an internet failure and were forced to distribute material on USB sticks from laptop to laptop.

Internet là không đáng tin cậy và hầu hết các sinh viên của chúng tôi không có quyền truy cập ở nhà, điều này buộc họ phải ở lại muộn sau giờ học để làm bài tập của họ.
Ngay cả trong lớp học, chúng tôi đã chịu nhiều lỗi trên internet và buộc phải phân phối vật liệu trên que USB từ máy tính xách tay đến máy tính xách tay.

One evening, I got frantic messages on Telegram from those students who had stayed late to work on their assignments: they had been locked in! A security guard had decided it was time for his dinner, locked them in and left. It took some frantic phone calls, picking up a ministry employee with keys and driving to the building to free the students. They kept their good spirits, though!

Một buổi tối, tôi đã nhận được những tin nhắn điên cuồng trên Telegram từ những sinh viên đã ở lại muộn để làm nhiệm vụ của họ: họ đã bị khóa!
Một nhân viên bảo vệ đã quyết định đã đến lúc ăn tối, nhốt họ vào và rời đi.
Phải mất một số cuộc gọi điện thoại điên cuồng, chọn một nhân viên của Bộ có chìa khóa và lái xe đến tòa nhà để giải phóng các sinh viên.
Họ giữ tinh thần tốt của họ, mặc dù!

![Free at last! The students had worked late and been locked in the building](img/2019-04-04-training-blockchain-developers-in-africa.012.jpeg) 

**Free at last! The students had worked late and been locked in the building.**

**Miễn phí cuối cùng!
Các sinh viên đã làm việc muộn và bị nhốt trong tòa nhà. **

Some of our students had problems with their laptops — insufficient memory, intolerably slow processors or faulty keyboards. After a slow and painful start, IOHK eventually provided better machines.

Một số sinh viên của chúng tôi có vấn đề với máy tính xách tay của họ - bộ nhớ không đủ, bộ xử lý chậm không thể chịu đựng được hoặc bàn phím bị lỗi.
Sau khi bắt đầu chậm và đau đớn, IOHK cuối cùng đã cung cấp các máy tốt hơn.

The Ugandan students neither liked the cool climate, nor were they happy with the unfamiliar Ethiopian food. Addis is 2,500m above sea level and the second-highest capital in the world, so the climate is cooler than one would expect from an African city. Polina and I felt so sorry for the four of them during the first weeks, they always looked so miserable!

Các sinh viên ở Uganda không thích khí hậu mát mẻ, họ cũng không hài lòng với những món ăn xa lạ của người Ethiopia.
Addis cao hơn 2.500m so với mực nước biển và thủ đô cao thứ hai trên thế giới, vì vậy khí hậu mát hơn so với người ta mong đợi từ một thành phố châu Phi.
Polina và tôi cảm thấy rất tiếc cho bốn người họ trong những tuần đầu tiên, họ luôn trông rất đau khổ!

![Ethiopian food: unfamiliar to the IOHK team and the Ugandan students](img/2019-04-04-training-blockchain-developers-in-africa.013.png) 

**Ethiopian food: unfamiliar to the IOHK team and the Ugandan students.**

** Thức ăn của người Ethiopia: Không quen thuộc với đội IOHK và các sinh viên Uganda. **

Another problem, at least in the beginning, was the fact that the students were used to an education system where asking ‘stupid’ questions was frowned upon and where teachers were often unapproachable. It took patience and encouragement to convince the students to open up, to show them that it was okay to ask questions and to interrupt us when there was something they did not understand.

Một vấn đề khác, ít nhất là ngay từ đầu, là thực tế là các sinh viên đã quen với một hệ thống giáo dục, nơi hỏi những câu hỏi ngu ngốc đã được cau mày và nơi giáo viên thường không thể chấp nhận được.
Phải mất sự kiên nhẫn và khuyến khích để thuyết phục các sinh viên mở ra, để cho họ thấy rằng bạn có thể đặt câu hỏi và làm gián đoạn chúng tôi khi có điều gì đó họ không hiểu.

The students also seemed to be used to a style of teaching and learning that focuses on theory. In the beginning, they followed our lectures well enough, but did quite poorly when it came to practical exercises and to applying what they had learned to actual code.

Các sinh viên dường như cũng quen với một phong cách dạy và học tập trung vào lý thuyết.
Ban đầu, họ đã theo dõi các bài giảng của chúng tôi đủ tốt, nhưng đã làm khá kém khi nói đến các bài tập thực tế và áp dụng những gì họ đã học được để mã thực tế.

Once we realized this, we provided more examples and exercises, and had them write code as often as possible. Repeat the Haskell workflow over and over again. Write some code. Compile. Fix errors. Test. Repeat.

Khi chúng tôi nhận ra điều này, chúng tôi đã cung cấp nhiều ví dụ và bài tập hơn, và họ viết mã thường xuyên nhất có thể.
Lặp lại quy trình làm việc của Haskell nhiều lần.
Viết một số mã.
Biên dịch.
Sửa lôi.
Bài kiểm tra.
Nói lại.

![Lunch with the students](img/2019-04-04-training-blockchain-developers-in-africa.011.jpeg) 

**Lunch with the students.**

** Ăn trưa với các sinh viên. **

It is a challenging course and goes far beyond a mere introduction into Haskell. Many advanced topics and concepts are covered, and a lot of material is squeezed in. This puts pressure on the students and requires them to work hard. But it is worth it! After completing the course, the students can be proud of a solid understanding of Haskell and are prepared to work on real problems.

Đó là một khóa học đầy thách thức và vượt xa sự giới thiệu đơn thuần vào Haskell.
Nhiều chủ đề và khái niệm nâng cao được đề cập, và rất nhiều tài liệu được ép vào. Điều này gây áp lực lên các sinh viên và yêu cầu chúng phải làm việc chăm chỉ.
Nhưng nó là giá trị nó!
Sau khi hoàn thành khóa học, các sinh viên có thể tự hào về sự hiểu biết vững chắc về Haskell và sẵn sàng làm việc về các vấn đề thực sự.

For one project, the students had to implement a peer-to-peer protocol, and they were really excited to see how the abstract concepts they had learnt could be applied. In Bethelhem's words:

Đối với một dự án, các sinh viên phải thực hiện một giao thức ngang hàng và họ thực sự rất hào hứng khi thấy các khái niệm trừu tượng mà họ đã học có thể được áp dụng như thế nào.
Theo lời của Bethelhem:

Working on assignments was the most favorite task among any of the activities in the course. 

Làm việc trên các bài tập là nhiệm vụ yêu thích nhất trong số các hoạt động trong khóa học.

I was trying to understand and work on every question. Even though it was group work, each assignment had something to do with practical points and It gave me discomfort to miss one. 

Tôi đã cố gắng để hiểu và làm việc trên mọi câu hỏi.
Mặc dù đó là công việc nhóm, mỗi bài tập có liên quan đến những điểm thực tế và nó đã khiến tôi khó chịu khi bỏ lỡ một.

Therefore, if I didn’t code it, at least I discussed with the group to visualize it algorithmically. Working in a team was fun! It helped to know each other, and I do appreciate well organized and clean lecture slides. The screen recordings also helped a lot. 

Do đó, nếu tôi đã viết mã nó, ít nhất tôi đã thảo luận với nhóm để trực quan hóa nó về mặt thuật toán.
Làm việc trong một nhóm là niềm vui!
Nó giúp biết nhau, và tôi đánh giá cao các bài giảng được tổ chức tốt và sạch sẽ.
Các bản ghi màn hình cũng giúp rất nhiều.

![Philip Wadler in his Lambdaman costume with Charles Hoskinson next to him](img/2019-04-04-training-blockchain-developers-in-africa.014.jpeg) 

**Philip Wadler in his Lambdaman costume with Charles Hoskinson next to him.**

** Philip Wadler trong trang phục Lambdaman của mình với Charles Hoskinson bên cạnh anh ta. **

[One novelty in this course](http://wadler.blogspot.com/2019/03/two-weeks-of-teaching-in-ethiopia.html "Two weeks of teaching in Ethiopia, Philip Wadler - blogspot.com") was a two-week section about Plutus, taught by Professor [Philip Wadler](tmp//en/team/philip-wadler/ "Philip Wadler, iohk.io"), one of the creators of Haskell. Plutus is the smart contract language developed by IOHK for use on the Cardano blockchain; it has been implemented in Haskell and is very similar to Haskell, so our students were in an ideal position to learn about it.

.
) là một phần hai tuần về Plutus, được giảng dạy bởi Giáo sư [Philip Wadler] (TMP // EN/Team/Philip-Wadler/"Philip Wadler, Iohk.io"), một trong những người tạo ra Haskell.
Plutus là ngôn ngữ hợp đồng thông minh được IOHK phát triển để sử dụng trên blockchain Cardano;
Nó đã được thực hiện trong Haskell và rất giống với Haskell, vì vậy các sinh viên của chúng tôi đã ở một vị trí lý tưởng để tìm hiểu về nó.

Another student, Bethel Tadesse, had suggestions for the course and the Plutus part:

Một sinh viên khác, Bethel Tadesse, đã có đề xuất cho khóa học và phần Sao Diêm Vương:

About the course I really like it and it is very interesting and useful for me, also inspiring me to work more and more. It's really optimal that we can bring this relevant and efficient technology to our developing country Ethiopia and also Africa. I also proudly say that I am lucky to learn this, a life-changing and solution-making infrastructure. 

Về khóa học tôi thực sự thích nó và nó rất thú vị và hữu ích cho tôi, cũng truyền cảm hứng cho tôi làm việc ngày càng nhiều hơn.
Thật sự tối ưu là chúng ta có thể mang công nghệ có liên quan và hiệu quả này đến quốc gia đang phát triển ở Ethiopia và cả Châu Phi.
Tôi cũng tự hào nói rằng tôi may mắn khi học được điều này, một cơ sở hạ tầng thay đổi cuộc sống và tạo ra giải pháp.

It lets me see the brightest future. It is really helpful and well organized, except the time shortens and makes it stressful and more effort is needed from us. And in the smart contract session, honestly speaking, we take in only the basics not the details and in my conclusion we need a bit more clarification to work more on it further. And in the basics I found it really interesting and powerful in securing different areas which need to be handled by this technology. 

Nó cho phép tôi nhìn thấy tương lai tươi sáng nhất.
Nó thực sự hữu ích và được tổ chức tốt, ngoại trừ thời gian rút ngắn và làm cho nó căng thẳng và cần nhiều nỗ lực hơn từ chúng tôi.
Và trong phiên hợp đồng thông minh, thành thật mà nói, chúng tôi chỉ thực hiện những điều cơ bản không phải là chi tiết và trong kết luận của tôi, chúng tôi cần làm rõ hơn một chút để làm việc nhiều hơn về nó hơn nữa.
Và trong những điều cơ bản, tôi thấy nó thực sự thú vị và mạnh mẽ trong việc đảm bảo các lĩnh vực khác nhau cần được xử lý bởi công nghệ này.

As a suggestion, I want to say that it might be better with the smart contract session if we get more time to internalize and see it more in advance how it works with the powerful language Haskell than dealing with it apart from the Haskell. 

Theo gợi ý, tôi muốn nói rằng nó có thể tốt hơn với phiên hợp đồng thông minh nếu chúng ta có nhiều thời gian hơn để nội tâm hóa và xem trước đó là cách nó hoạt động với ngôn ngữ mạnh mẽ Haskell hơn là đối phó với nó ngoài Haskell.

After almost three months of hard work, many struggles, countless internet and power failures, after learning esoteric concepts like *monads* and *equational reasoning* and down-to-earth applications with web servers and databases, after disappointments about poor test results and elation about steady improvements and ‘aha!’ moments, after learning and studying and working and eating and having coffee together, after medical emergencies, family tragedies and sicknesses, after many little and larger triumphs, much laughter and much joy, after being scared of ghosts on rooftops in the night (no kidding...) and avoiding countless shoeshine boys, it finally culminated with a beautiful graduation ceremony at the [Sapphire Hotel](https://www.sapphireaddishotel.com/ "sapphireaddishotel.com") in Addis Ababa.

Sau gần ba tháng làm việc chăm chỉ, nhiều cuộc đấu tranh, vô số thất bại trên internet và sức mạnh, sau khi học các khái niệm bí truyền như * monads * và * lý luận phương trình * và các ứng dụng thực tế với các máy chủ và cơ sở dữ liệu Web, sau khi thất vọng về kết quả kiểm tra kém và
Sự phấn khích về những cải tiến ổn định và những khoảnh khắc 'AHA!'
Ghosts trên mái nhà trong đêm (không đùa ...) và tránh vô số chàng trai Shoeshine, cuối cùng nó đã lên đến đỉnh điểm với một buổi lễ tốt nghiệp tuyệt đẹp tại [Khách sạn Sapphire] (https://www.sapphireaddishotel.com/ "Sapphireaddishotel.com")
Trong Addis Ababa.

![Lars surrounded by the graduates](img/2019-04-04-training-blockchain-developers-in-africa.009.png) 

**Lars surrounded by the graduates.**

** Lars được bao quanh bởi các sinh viên tốt nghiệp. **

Watched by proud family and friends, diplomats and industry experts, and journalists and philanthropists, the students were awarded their certificates by Dr Getahun Mekuria Kuma, minister of innovation and technology, and [Charles Hoskinson](tmp//en/team/charles-hoskinson/), chief executive and co-founder of IOHK.

Được theo dõi bởi gia đình và bạn bè tự hào, các nhà ngoại giao và các chuyên gia trong ngành, và các nhà báo và nhà từ thiện, các sinh viên đã được Tiến sĩ Getahun Mekuria Kuma, Bộ trưởng Đổi mới và Công nghệ trao tặng, và [Charles Hoskinson] (TMP // EN/Team/Charles- Charles-
Hoskinson/), Giám đốc điều hành và đồng sáng lập của IOHK.

![Lars, Polina, and Getahun Mekuria Kuma, the technology minister](img/2019-04-04-training-blockchain-developers-in-africa.015.jpeg) 

**Lars, Polina, and Getahun Mekuria Kuma, the technology minister.**

** Lars, Polina và Getahun Mekuria Kuma, Bộ trưởng Công nghệ. **

Nobody was more proud, though, than me. The women were all wearing Ethiopian dresses, they were shining with excitement and joy; they looked so beautiful, I had to fight back the tears. According to my wife, ‘They had always been beautiful, but success made them gorgeous.’

Mặc dù vậy, không ai tự hào hơn tôi.
Những người phụ nữ đều mặc váy của người Ethiopia, họ tỏa sáng với sự phấn khích và niềm vui;
Trông họ thật đẹp, tôi phải chống lại những giọt nước mắt.
Theo vợ tôi, họ luôn luôn đẹp, nhưng thành công đã khiến họ tuyệt đẹp.

Read Polina Vinogradova's blog - [In at the deep end in Addis](tmp//en/blog/in-at-the-deep-end-in-addis "In at the deep end in Addis, iohk.io/blog")

Đọc blog của Polina Vinogradova-[ở phần cuối trong Addis] (TMP // EN/Blog/In-At-the-Seeep-In-Addis "ở cuối cùng ở Addis, iohk.io/blog"
)

