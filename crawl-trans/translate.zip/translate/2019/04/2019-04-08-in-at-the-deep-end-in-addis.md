# In at the deep end in Addis
### **Keen students beat challenges to discover smart contracts**
![](img/2019-04-08-in-at-the-deep-end-in-addis.002.png) 8 April 2019![](img/2019-04-08-in-at-the-deep-end-in-addis.002.png)[ Polina Vinogradova](tmp//en/blog/authors/polina-vinogradova/page-1/)![](img/2019-04-08-in-at-the-deep-end-in-addis.003.png) 4 mins read

![Polina Vinogradova](img/2019-04-08-in-at-the-deep-end-in-addis.004.png)[](tmp//en/blog/authors/polina-vinogradova/page-1/)
### [**Polina Vinogradova**](tmp//en/blog/authors/polina-vinogradova/page-1/)
Research Engineer

Engineering

- ![](img/2019-04-08-in-at-the-deep-end-in-addis.005.png)[](mailto:polina.vinogradova@iohk.io "Email")
- ![](img/2019-04-08-in-at-the-deep-end-in-addis.006.png)[](https://ca.linkedin.com/in/polina-vinogradova-62105713b "LinkedIn")
- ![](img/2019-04-08-in-at-the-deep-end-in-addis.007.png)[](https://twitter.com/polinavinovino "Twitter")
- ![](img/2019-04-08-in-at-the-deep-end-in-addis.008.png)[](https://github.com/polinavino "GitHub")

![In at the deep end in Addis](img/2019-04-08-in-at-the-deep-end-in-addis.009.jpeg)

I started with IOHK in May 2018 as a formal methods developer working on two components of Cardano, neither of which involved writing Haskell code. Because of my expertise in logic, type theory, proof assistants, and theoretical computer science, I became part of the team without having much Haskell experience, even though it is the main language we use. So, I was surprised when my name came up last summer about who would be the teaching assistant for a Haskell course in Ethiopia this year. I had thought I would be a student, but then it became clear that loftier plans were being proposed for me.

Tôi đã bắt đầu với IOHK vào tháng 5 năm 2018 với tư cách là một nhà phát triển phương pháp chính thức làm việc trên hai thành phần của Cardano, cả hai đều không liên quan đến việc viết mã Haskell.
Vì chuyên môn của tôi về logic, lý thuyết loại, trợ lý chứng minh và khoa học máy tính lý thuyết, tôi đã trở thành một phần của nhóm mà không có nhiều kinh nghiệm Haskell, mặc dù đó là ngôn ngữ chính chúng tôi sử dụng.
Vì vậy, tôi đã rất ngạc nhiên khi tên của tôi xuất hiện vào mùa hè năm ngoái về việc ai sẽ là trợ lý giảng dạy cho một khóa học Haskell ở Ethiopia năm nay.
Tôi đã nghĩ rằng tôi sẽ là một sinh viên, nhưng sau đó rõ ràng rằng các kế hoạch cao hơn đang được đề xuất cho tôi.

While there were other qualified candidates, I imagine not everyone was willing to relocate to Africa for three months. Also, the Ethiopia 2019 class was distinguished from previous versions of the course because it was only open to women. For this reason, the idea of having a female assistant seemed particularly relevant. So, I found myself getting ready to learn, present in class, and assess material that was new to both me and the cohort of students from Ethiopia and Uganda!

Trong khi có những ứng cử viên đủ điều kiện khác, tôi tưởng tượng không phải ai cũng sẵn sàng chuyển đến Châu Phi trong ba tháng.
Ngoài ra, lớp Ethiopia 2019 đã được phân biệt với các phiên bản trước của khóa học vì nó chỉ dành cho phụ nữ.
Vì lý do này, ý tưởng có một trợ lý nữ dường như đặc biệt phù hợp.
Vì vậy, tôi thấy mình đã sẵn sàng để học hỏi, trình bày trong lớp và đánh giá tài liệu mới đối với cả tôi và đoàn hệ sinh viên từ Ethiopia và Uganda!

![Addis Abbaba](img/2019-04-08-in-at-the-deep-end-in-addis.010.png) 

**Addis Ababa, where twenty-two women from Ethiopia and Uganda gathered for the course.**

** Addis Ababa, nơi hai mươi hai phụ nữ đến từ Ethiopia và Uganda đã tập trung cho khóa học. **

I was living in Canada, and had yet to meet any IOHK employees in person. I knew little about Ethiopia. So, I got my inoculations, my one-way ticket â€” I was not sure when the course was scheduled to end and how much longer I was expected to stay on afterwards â€” my visa (with my name spelt wrongly), and headed off to Africa for the first time in my life.

Tôi đang sống ở Canada và gặp trực tiếp bất kỳ nhân viên IOHK nào.
Tôi biết rất ít về Ethiopia.
Vì vậy, tôi đã nhận được sự tiêm chủng của mình, vé một chiều của tôi-Tôi không chắc khi nào khóa học dự kiến kết thúc và tôi dự kiến sẽ ở lại sau đó bao lâu nữa (với tên của tôi được đánh vần sai),
và đi đến châu Phi lần đầu tiên trong đời tôi.

Once I got to Addis Ababa, the thing that stood out was the amount of livestock in parts of the city. Donkeys, cows, and goats were grazing, carrying heavy loads, and wandering about the streets. After the first drive through Addis, Lars BrÃ¼njes, director of education at IOHK, and John Oâ€™Connor, director of Africa operations, and I sat down for a cold drink at the hotel where Lars and I were staying. We had some laughs, talked a bit about ourselves and the course, and it began to seem as if I would be very happy working with my colleagues here for three months â€” what a relief.

Khi tôi đến Addis Ababa, điều nổi bật là số lượng vật nuôi ở các khu vực của thành phố.
Những con lừa, bò và dê đang chăn thả, mang theo tải nặng và lang thang trên đường phố.
Sau lần lái xe đầu tiên qua Addis, Lars BrÃ¼njes, Giám đốc Giáo dục tại IOHK và John Oâ € ™ Connor, Giám đốc điều hành của Châu Phi, và tôi ngồi uống nước lạnh tại khách sạn nơi tôi và Lars đang ở.
Chúng tôi đã có một số tiếng cười, nói chuyện một chút về bản thân và khóa học, và có vẻ như tôi sẽ rất hạnh phúc khi làm việc với các đồng nghiệp của mình ở đây trong ba tháng - thật là một sự nhẹ nhõm.

From the first day until the last, which was almost three months, I was really engaged with both the students and the material. The course started at the Ministry of Innovation and Technology and the students showed incredible perseverance. Two had to drop out in the first week, but the rest stayed on, no matter how challenging it got â€” and no matter the transportation time to class given the crazy Addis traffic! 

Ngay từ ngày đầu tiên cho đến cuối cùng, gần ba tháng, tôi đã thực sự gắn bó với cả học sinh và tài liệu.
Khóa học bắt đầu tại Bộ đổi mới và công nghệ và các sinh viên thể hiện sự kiên trì đáng kinh ngạc.
Hai người đã phải bỏ học trong tuần đầu tiên, nhưng phần còn lại vẫn tiếp tục, bất kể nó có thách thức như thế nào và bất kể thời gian vận chuyển đến lớp với giao thông Addis điên rồ!

Most of the students had a computer science degree, some also had a masterâ€™s or work experience. However, Haskell is different from anything they would have learned or used before. There were some difficult concepts to grasp, but Lars did an awesome job breaking down the material and providing plenty of relevant examples (as many as the students wanted, which was a lot).

Hầu hết các sinh viên đều có bằng khoa học máy tính, một số cũng có kinh nghiệm làm việc hoặc làm việc.
Tuy nhiên, Haskell khác với bất cứ điều gì họ sẽ học hoặc sử dụng trước đây.
Có một số khái niệm khó nắm bắt, nhưng Lars đã làm một công việc tuyệt vời phá vỡ tài liệu và cung cấp nhiều ví dụ có liên quan (nhiều như các sinh viên muốn, rất nhiều).

![Lars, Bethel Tadesse, and Polina Volgradova](img/2019-04-08-in-at-the-deep-end-in-addis.011.jpeg) 

**Lars, Bethel Tadesse, and Polina Volgradova.**

** Lars, Bethel Tadesse và Polina Volgradova. **

There is a saying that the best way to understand something is to teach it. For me, this was true for the entire duration of the course. I learned a lot, answering questions, delivering lectures, grading work, and especially making up the questions and answers for the final test. It was a special treat to learn about smart contracts, Marlowe, and Plutus in the last two weeks, too â€” new material for me and a great addition to the course. This part was taught by Phil Wadler, one of the creators of Haskell, and at the very end he delivered a special lecture on propositions as types, which was particularly engaging and open to a wider audience than just the students â€” it was a very nice way to end the class.

Có một câu nói rằng cách tốt nhất để hiểu điều gì đó là dạy nó.
Đối với tôi, điều này đúng cho toàn bộ thời gian của khóa học.
Tôi đã học được rất nhiều, trả lời các câu hỏi, đưa ra các bài giảng, chấm điểm công việc và đặc biệt là tạo ra các câu hỏi và câu trả lời cho bài kiểm tra cuối cùng.
Đó là một điều trị đặc biệt để tìm hiểu về các hợp đồng thông minh, Marlowe và Plutus trong hai tuần qua, quá tài liệu mới cho tôi và là một bổ sung tuyệt vời cho khóa học.
Phần này được dạy bởi Phil Wadler, một trong những người tạo ra Haskell, và cuối cùng, ông đã đưa ra một bài giảng đặc biệt về các đề xuất như các loại, đặc biệt hấp dẫn và cởi mở với khán giả rộng hơn chỉ là các sinh viên - đó là một
Cách rất tốt để kết thúc lớp học.

Throughout the three months, but especially at the beautiful graduation ceremony, I really felt the importance of what we were doing â€” giving people the skills and tools to address their problems locally. The best part was getting to know the wonderfully enthusiastic students and watching them develop their skills in this unusual and interesting programming language. I look forward to having the opportunity to work with some of these women in the future. Finally, getting to know my IOHK colleagues as we arrived in Ethiopia was a real treat as well!

Trong suốt ba tháng, nhưng đặc biệt là tại buổi lễ tốt nghiệp đẹp, tôi thực sự cảm thấy tầm quan trọng của những gì chúng tôi đang làm - mang lại cho mọi người các kỹ năng và công cụ để giải quyết vấn đề của họ tại địa phương.
Phần tốt nhất là được biết các sinh viên nhiệt tình tuyệt vời và theo dõi họ phát triển các kỹ năng của họ trong ngôn ngữ lập trình bất thường và thú vị này.
Tôi mong muốn có cơ hội làm việc với một số phụ nữ trong tương lai.
Cuối cùng, làm quen với các đồng nghiệp IOHK của tôi khi chúng tôi đến Ethiopia cũng là một điều trị thực sự!

Read Lars BrÃ¼njes's blog - [Training blockchain developers in Africa](tmp//en/blog/training-blockchain-developers-in-africa "Training blockchain developers in Africa, iohk.io/blog")

Đọc blog của Lars BrÃ¼njes-[Các nhà phát triển blockchain đào tạo ở Châu Phi] (TMP // EN/Blog/đào tạo-Blockchain-Developers-in-Africa "Các nhà phát triển blockchain đào tạo ở Châu Phi, iohk.io/blog")

