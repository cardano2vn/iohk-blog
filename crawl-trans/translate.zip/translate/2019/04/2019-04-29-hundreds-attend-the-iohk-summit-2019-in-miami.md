# Hundreds attend the IOHK Summit 2019 in Miami
### **New products, Cardano progress and industry issues in focus at event**
![](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.002.png) 29 April 2019![](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.002.png)[ Amy Reeve](tmp//en/blog/authors/amy-reeve/page-1/)![](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.003.png) 7 mins read

![Amy Reeve](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.004.png)[](tmp//en/blog/authors/amy-reeve/page-1/)
### [**Amy Reeve**](tmp//en/blog/authors/amy-reeve/page-1/)
Technical Writer

Marketing and Communications

- ![](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.005.png)[](https://www.linkedin.com/in/amy-reeve-8616b248/ "LinkedIn")
- ![](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.006.png)[](https://github.com/jabbacakes "GitHub")

![Hundreds attend the IOHK Summit 2019 in Miami](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.007.jpeg)

Government ministers, industry professionals, and Cardano fans were at the IOHK Summit 2019 in Miami this month, excited to hear IOHK CEO Charles Hoskinson outline the future for Cardano and launch Atala, the companyâ€™s enterprise offering for business. Hosted at the Miami Beach Convention Center, the summit saw renowned speakers such as computer scientist Stephen Wolfram and cyberpunk author Rudy Rucker alongside government representatives, entrepreneurs, and enthusiastic community members. The summit reflected the broad appeal â€“ and potential â€“ of both blockchain technology and IOHKâ€™s research. In total, the event had over 700 attendees, including IOHK staff: a rare and enjoyable opportunity for our decentralized company to meet and collaborate in person.

![IOHK Team 2019](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.008.jpeg) 

**IOHK has grown from fewer than 20 people in 2016 to almost 200 today**

** IOHK đã tăng từ ít hơn 20 người trong năm 2016 lên gần 200 ngày hôm nay **

## **IOHK Summit 2019**

## ** Hội nghị thượng đỉnh IOHK 2019 **

To kick off the summit, IOHK CEO Charles Hoskinson discussed the goals and philosophy of IOHK: â€˜we're not just building a decentralized system, we're building a decentralized infrastructureâ€™ to invite billions of people â€“ thus far ignored and unserved by legacy finance â€“ into a new and flourishing economy.

Để khởi động hội nghị thượng đỉnh, Giám đốc điều hành của IOHK Charles Hoskinson đã thảo luận về các mục tiêu và triết lý của IOHK: "Chúng tôi không chỉ xây dựng một hệ thống phi tập trung, chúng tôi đang xây dựng một cơ sở hạ tầng phi tập trung để mời hàng tỷ người cho đến nay cho đến nay
Bị bỏ qua và không được bảo quản bởi tài chính di sản - thành một nền kinh tế mới và hưng thịnh.

IOHK holds a summit every year, but this was the first year that the event was open to the public. Attendees gathered between talks to network and discuss all aspects of blockchain and cryptocurrency, with stands from [Emurgo](https://emurgo.io/#/en "emurgo.io"), the [Cardano Foundation](https://cardanofoundation.org/en/ "cardanofoundation.org"), the [Cardano Effect](https://thecardanoeffect.libsyn.com/ "thecardanoeffect.libsyn.com") podcast and more lining the walls for attendees to visit.

IOHK tổ chức một hội nghị thượng đỉnh mỗi năm, nhưng đây là năm đầu tiên sự kiện này mở cửa cho công chúng.
Những người tham dự đã tập trung giữa các cuộc đàm phán đến mạng và thảo luận về tất cả các khía cạnh của blockchain và tiền điện tử, với các khán đài từ [Emurgo] (https://emurgo.io/#/en "Emurgo.io"), [Quỹ Cardano] (https: //
cardanofoundation.org/en/ "cardanofoundation.org"), [hiệu ứng cardano] (https://thecardanoeffect.libsyn.com/ "thecardanoeffect.libsyn.com")

![IOHK Team 2019](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.009.jpeg) 

**IOHK CEO Charles Hoskinson during his keynote speech**

** Giám đốc điều hành IOHK Charles Hoskinson trong bài phát biểu quan trọng của mình **

## **Atala: our enterprise product**

## ** Atala: Sản phẩm doanh nghiệp của chúng tôi **

Atala, the new Cardano enterprise offering, was a major piece of news from the summit. The enterprise-grade product will blend blockchain with new and existing technologies, providing a holistic, best-in-class offering for those with large and potentially complex use cases. Like everything else we do, Atala will be underpinned by IOHK's world-leading research. During his presentation, IOHK director of engineering Bruno Woltzenlogel Paleo outlined the fundamental vision for Atala: â€˜to do for all data what bitcoin did for moneyâ€™.

Atala, cung cấp doanh nghiệp Cardano mới, là một tin tức chính từ hội nghị thượng đỉnh.
Sản phẩm cấp doanh nghiệp sẽ pha trộn blockchain với các công nghệ mới và hiện có, cung cấp một sản phẩm toàn diện, tốt nhất trong lớp cho những người có trường hợp sử dụng lớn và có khả năng phức tạp.
Giống như mọi thứ khác mà chúng tôi làm, Atala sẽ được củng cố bởi nghiên cứu hàng đầu thế giới của IOHK.
Trong buổi thuyết trình của mình, Giám đốc Kỹ thuật IOHK Bruno Woltzenlogel Paleo đã phác thảo tầm nhìn cơ bản cho Atala: "Để làm cho tất cả dữ liệu về những gì Bitcoin đã làm cho tiền.

![To celebrate the launch of Atala - named after a butterfly - one hundred live native butterflies were released outside the convention center](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.010.jpeg) 

**To celebrate the launch of Atala 

** Để ăn mừng sự ra mắt của Atala

\- named after a butterfly - one hundred

\ - Được đặt tên theo một con bướm - một trăm

live native butterflies were released 

Những con bướm bản địa sống đã được phát hành

outside the convention center.**

bên ngoài trung tâm hội nghị. **

## **Cardano development**

## ** Phát triển Cardano **

With the [formal specifications for Shelley](tmp//en/blog/new-shelley-formal-specifications-complete/ "New Shelley Formal Specifications Complete, iohk.io") released just days before the summit, progress on Cardano development was in the spotlight too. There were talks from senior Cardano development team members Duncan Coutts, Philipp Kant, and Bruno Woltzenlogel Paleo, as well as open panel discussions about how blockchain â€“ and Cardano, of course â€“ will interact with future law and monetary policy. IOHK engineers have been working hard on the development of Shelley, and Charles took the opportunity to reiterate that the ultimate goal of Cardano isnâ€™t just to ship a technology product, but to create a means of improving quality of life for millions of people around the world.

Với [Thông số kỹ thuật chính thức cho Shelley] (TMP // EN/Blog/New-Shelley-Formal Specifications-Toàn bộ/"Thông số kỹ thuật chính thức mới của Shelley, IOHK.IO") được phát hành chỉ vài ngày trước khi hội nghị thượng đỉnh, tiến trình phát triển Cardano là
Trong ánh đèn sân khấu quá.
Có những cuộc đàm phán từ các thành viên nhóm phát triển Cardano cao cấp Duncan Coutts, Philipp Kant và Bruno Woltzenlogel Paleo, cũng như các cuộc thảo luận của hội thảo mở về cách blockchain - và Cardano, tất nhiên sẽ tương tác với chính sách luật pháp và luật pháp trong tương lai.
Các kỹ sư của IOHK đã làm việc chăm chỉ cho việc phát triển Shelley và Charles đã có cơ hội nhắc lại rằng mục tiêu cuối cùng của Cardano không chỉ để vận chuyển một sản phẩm công nghệ, nhưng để tạo ra một phương tiện để cải thiện chất lượng cuộc sống cho hàng triệu người
vòng quanh thế giới.

## **Government engagement**

## ** Sự tham gia của chính phủ **

Other exciting news from the event included the first public announcement of an MoU between IOHK and the Ethiopian government, with IOHK set to design and create a cryptocurrency for Ethiopian citizens. John O'Connor, IOHK director of African operations, announced the joint venture during his presentation about IOHK's recent [success running a Haskell course in the Ethiopian capital](tmp//en/blog/training-blockchain-developers-in-africa/ "Training Blockchain Developers in Africa, iohk.io") Addis Ababa. Meanwhile Lars BrÃ¼njes, IOHKâ€™s director of education, discussed the human impact of the initiative: not only is it a huge step forward for the industry to be engaged with government organizations, but leveraging blockchain technology in the developing world will improve the everyday lives of millions of people.

Các tin tức thú vị khác từ sự kiện này bao gồm thông báo công khai đầu tiên về MOU giữa IOHK và chính phủ Ethiopia, với IOHK được thiết kế và tạo ra một loại tiền điện tử cho công dân Ethiopia.
John O'Connor, Giám đốc điều hành châu Phi của IOHK, đã công bố liên doanh trong bài trình bày về khóa học Gần đây của IOHK [Running A Haskell ở thủ đô Ethiopia] (TMP // EN/Blog/Huấn luyện-Blockchain-Devenes
"Huấn luyện các nhà phát triển blockchain ở Châu Phi, iohk.io") Addis Ababa.
Trong khi đó, Lars BrÃ¼njes, Giám đốc Giáo dục của Iohk, đã thảo luận về tác động của con người của sáng kiến: không chỉ là một bước tiến lớn để ngành công nghiệp tham gia vào các tổ chức chính phủ, mà còn tận dụng công nghệ blockchain trong thế giới đang phát triển sẽ cải thiện hàng ngày
cuộc sống của hàng triệu người.

It isnâ€™t just the Ethiopian government that IOHK is engaging with either: also at the summit were Caitlin Long and Tyler Lindholm, both members of the Wyoming legislature, discussing how the state is making huge strides to become a haven for the emerging markets of blockchain and cryptocurrency. Delegates from the Mongolian government were at the summit as well, including the minister of foreign affairs, along with CEO and entrepreneur Gerelmaa Batchuluun, explaining how â€˜Mongolia is the next destination for the blockchain revolutionâ€™.

Nó không chỉ là chính phủ Ethiopia mà IOHK đang tham gia vào một trong hai: cũng tại hội nghị thượng đỉnh là Caitlin Long và Tyler Lindholm, cả hai thành viên của cơ quan lập pháp bang Utah, thảo luận về cách nhà nước có những bước tiến lớn để trở thành thiên đường cho các thị trường mới nổi
của blockchain và tiền điện tử.
Các đại biểu từ chính phủ Mông Cổ cũng có mặt tại Hội nghị thượng đỉnh, bao gồm cả Bộ trưởng Bộ Ngoại giao, cùng với CEO và doanh nhân Gerelmaa Batchuluun, giải thích làm thế nào "Mông Cổ là điểm đến tiếp theo cho cuộc cách mạng blockchain.

## **Community projects**

## **Dự án cộng đồng**

The summit was also an opportunity for members of our dedicated community to meet and collaborate directly with IOHK, and one of the most popular workshop sessions was run by two community members who only met a few months ago at the inaugural [PlutusFest](tmp//en/blog/launching-plutus-and-marlowe-at-the-inaugural-plutusfest/ "Launching Plutus and MArlowe at the Inagural Plutusfest, iohk.io") event in Edinburgh, UK. In their talk, Cardano on the rocks, Markus Gufler and Robert Kornacki presented undeniable evidence of the potential reach of Cardano. They demonstrated how a full Cardano node can run on low-cost open-source hardware using less than ten watts of power, potentially provided by a solar panel, opening up the world of Cardano to anyone, anywhere. Not only that, but Markus and Robert run a free, community-driven education portal, [Clio.1](https://edu.clio.one/ "edu.clio.one"), where theyâ€™ll soon be sharing the details of their work for everyone to benefit from.

Hội nghị thượng đỉnh cũng là cơ hội cho các thành viên của cộng đồng tận tụy của chúng tôi gặp gỡ và hợp tác trực tiếp với IOHK, và một trong những buổi hội thảo phổ biến nhất được điều hành bởi hai thành viên cộng đồng chỉ gặp vài tháng trước tại lễ khai mạc [Plutusfest] (TMP/
.
Trong bài nói chuyện của họ, Cardano trên The Rocks, Markus Gufler và Robert Kornacki đã đưa ra bằng chứng không thể phủ nhận về tầm với tiềm năng của Cardano.
Họ đã chứng minh làm thế nào một nút Cardano đầy đủ có thể chạy trên phần cứng nguồn mở chi phí thấp bằng cách sử dụng ít hơn mười watt điện, có khả năng được cung cấp bởi một bảng điều khiển năng lượng mặt trời, mở ra thế giới của Cardano cho bất kỳ ai, ở bất cứ đâu.
Không chỉ vậy, mà Markus và Robert điều hành một cổng thông tin giáo dục miễn phí, dựa trên cộng đồng, [clio.1] (https://edu.clio.one/ "edu.clio.one"), nơi họ sẽ sớm được
Chia sẻ chi tiết công việc của họ cho mọi người được hưởng lợi.

![Robert Kornacki and Markus Gufler](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.011.jpeg) 

**Robert Kornacki and Markus Gufler, two Cardano community members, at the summit with their open-source hardware solution for Cardano**

** Robert Kornacki và Markus Gufler, hai thành viên cộng đồng Cardano, tại hội nghị với giải pháp phần cứng nguồn mở của họ cho Cardano **

## **Thatâ€™s not all**

## ** Đó không phải là tất cả **

Also at the summit was the [Symphony of Blockchains project](tmp//en/blog/symphony-of-blockchains-project-comes-to-bristol/ "Symphony of Blockchains Project Comes to Bristol, iohk.io"), beginning its much-anticipated world tour in Miami. The full virtual reality blockchain experience was available for attendees to explore, with augmented reality posters scattered around the summit, waiting to be discovered. Visitors to the exhibition described being â€˜blown awayâ€™ by the simulated blockchain.

Cũng tại hội nghị thượng đỉnh là [Dự án Symphony of Blockchains] (TMP // EN/Blog/Symphony-Of-Blockchains-Project-Comes-to-Bristol/"Symphony of Blockchains Project đến Bristol, iohk.io"), bắt đầu
Chuyến lưu diễn thế giới rất được mong đợi của nó ở Miami.
Trải nghiệm blockchain thực tế ảo đầy đủ đã có sẵn cho những người tham dự để khám phá, với các áp phích thực tế tăng cường nằm rải rác xung quanh hội nghị, chờ đợi để được phát hiện.
Du khách đến triển lãm được mô tả là "blockchain mô phỏng.

In addition to the talks, stands, workshops, and exhibits, summit attendees also had the option to take part in a [cryptopuzzle](https://forum.cardano.org/t/iohk-summit-cryptopuzzle/22567 "forum.cardano.org") with a $10,000 USD prize - won by a team of three community members working together - as well as a collaborative hackathon providing Plutus and Marlowe training.

Ngoài các cuộc đàm phán, khán đài, hội thảo và triển lãm, những người tham dự hội nghị thượng đỉnh cũng có tùy chọn tham gia vào [Cryptopuzzzz] (https://forum.cardano.org/t/iohk-summit-cryptopuzz/22567 "Diễn đàn.
cardano.org ") với giải thưởng trị giá 10.000 USD - giành được bởi một nhóm ba thành viên cộng đồng làm việc cùng nhau - cũng như một hackathon hợp tác cung cấp đào tạo Sao Diêm Vương và Marlowe.

## **Internal summit**

## ** Hội nghị thượng đỉnh nội bộ **

Before the public event, IOHK staff also took part in two days of internal presentations. As a decentralized company, the annual summit is a unique opportunity for IOHK employees to meet each other in person. Many IOHK employees arrived early to enjoy the beautiful Miami weather, spending time together on the beach and taking a trip to the Everglades before getting down to business.

Trước sự kiện công khai, nhân viên IOHK cũng tham gia hai ngày thuyết trình nội bộ.
Là một công ty phi tập trung, Hội nghị thượng đỉnh hàng năm là một cơ hội duy nhất để nhân viên IOHK gặp nhau trực tiếp.
Nhiều nhân viên của IOHK đã đến sớm để tận hưởng thời tiết Miami xinh đẹp, dành thời gian cho nhau trên bãi biển và thực hiện một chuyến đi đến Everglades trước khi xuống kinh doanh.

![IOHK employees enjoyed a few days of well-earned rest on beautiful Miami Beach](img/2019-04-29-hundreds-attend-the-iohk-summit-2019-in-miami.012.jpeg) 

**IOHK employees enjoyed a few days of well-earned rest on beautiful Miami Beach**

** Nhân viên IOHK đã tận hưởng một vài ngày nghỉ ngơi kiếm được nhiều tiền trên bãi biển Miami xinh đẹp **

â€˜As a company,â€™ IOHK CEO Charles Hoskinson began his internal address, â€˜we've touched and tackled every fundamental problem in the cryptocurrency spaceâ€™. He spoke of the company's history, and its unprecedented growth from just a dozen employees in 2016 to almost two hundred now in 2019. As the blockchain industry matures, and IOHK with it, Charles discussed the challenges of 'being able to keep your principles while embracing pragmatism'.

"Là một công ty, CEO của IOHK, Charles Hoskinson bắt đầu địa chỉ nội bộ của mình, chúng tôi đã chạm vào và giải quyết mọi vấn đề cơ bản trong không gian tiền điện tử.
Ông đã nói về lịch sử của công ty, và sự tăng trưởng chưa từng có của nó từ chỉ một chục nhân viên trong năm 2016 lên gần hai trăm bây giờ vào năm 2019. Khi ngành công nghiệp blockchain trưởng thành, và IOHK với nó, Charles đã thảo luận về những thách thức của việc 'có thể giữ nguyên tắc của bạn trong khi
ôm lấy chủ nghĩa thực dụng '.

Other internal talks covered everything from IOHK's educational efforts in Africa to the latest updates from the engineering team. Throughout the two company-only days, groups of IOHK employees could be seen all around the Loews Hotel location, hunched over laptops, deep in discussion. The mood was passionate and enthusiastic, no one wanting to waste the chance to collaborate, and meetings continued into the evening, spilling out into local bars and restaurants.

Các cuộc nói chuyện nội bộ khác bao gồm tất cả mọi thứ, từ các nỗ lực giáo dục của IOHK ở châu Phi đến các bản cập nhật mới nhất từ nhóm kỹ thuật.
Trong suốt hai ngày chỉ dành cho công ty, các nhóm nhân viên IOHK có thể được nhìn thấy xung quanh địa điểm khách sạn Loews, gù lưng trên máy tính xách tay, thảo luận sâu.
Tâm trạng rất đam mê và nhiệt tình, không ai muốn lãng phí cơ hội hợp tác, và các cuộc họp tiếp tục vào buổi tối, tràn ra các quán bar và nhà hàng địa phương.

The IOHK Summit 2019 was an incredible event, not just for IOHK but for the industry, bringing together members of the blockchain community with politicians, legislators, and thinkers, all poised to define the future of this revolutionary technology. The event made it clear just how far IOHK has come - and how much further we're going to go.

Hội nghị thượng đỉnh IOHK 2019 là một sự kiện đáng kinh ngạc, không chỉ dành cho IOHK mà còn cho ngành công nghiệp, tập hợp các thành viên của cộng đồng blockchain với các chính trị gia, nhà lập pháp và nhà tư tưởng, tất cả đã sẵn sàng để xác định tương lai của công nghệ cách mạng này.
Sự kiện này cho thấy rõ IOHK đã đi được bao xa - và chúng ta sẽ đi xa hơn bao nhiêu.

