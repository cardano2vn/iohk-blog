# A Brief Update on Cardano Development
### **Processes are evolving under the project management team**
![](img/2018-04-09-a-brief-update-on-cardano.002.png) 9 April 2018![](img/2018-04-09-a-brief-update-on-cardano.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2018-04-09-a-brief-update-on-cardano.003.png) 10 mins read

![Charles Hoskinson](img/2018-04-09-a-brief-update-on-cardano.004.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2018-04-09-a-brief-update-on-cardano.005.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2018-04-09-a-brief-update-on-cardano.006.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2018-04-09-a-brief-update-on-cardano.007.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![A Brief Update on Cardano Development](img/2018-04-09-a-brief-update-on-cardano.008.jpeg)

After returning from my yearly global sojourn, I wanted to update the Cardano community on the status of the project. Since the beginning of the year a lot has happened. Cardano continues to grow at a rapid pace and the project is evolving into a new stage. The Byron release back in September of 2017 was an experiment for IOHK. It's the first cryptocurrency we have launched as a company. It's the first time we've had to manage public release cycles, segregated stakeholders (the general public, exchanges, developers, etc). Furthermore, the Cardano project has half a dozen software companies collaborating on it, thus we have to invest a huge amount of time in coordinating, communication and timezone overheads.

Sau khi trở về từ toàn cầu hàng năm của tôi, tôi muốn cập nhật cộng đồng Cardano về tình trạng của dự án.
Kể từ đầu năm, rất nhiều điều đã xảy ra.
Cardano tiếp tục phát triển với tốc độ nhanh chóng và dự án đang phát triển thành một giai đoạn mới.
Bản phát hành Byron trở lại vào tháng 9 năm 2017 là một thử nghiệm cho IOHK.
Đó là tiền điện tử đầu tiên chúng tôi đã ra mắt như một công ty.
Đây là lần đầu tiên chúng tôi phải quản lý các chu kỳ phát hành công khai, các bên liên quan tách biệt (công chúng, trao đổi, nhà phát triển, v.v.).
Hơn nữa, dự án Cardano có nửa tá công ty phần mềm hợp tác với nó, do đó chúng tôi phải đầu tư một lượng lớn thời gian vào việc điều phối, giao tiếp và chi phí thời gian.

Since the September release, we've learned a huge amount about all of these processes and also in dealing with the needs of our broader community. We certainly haven't achieved a Nirvana-like state of perfection, but processes have definitely improved.

Kể từ khi phát hành tháng 9, chúng tôi đã học được một số tiền rất lớn về tất cả các quy trình này và cũng trong việc giải quyết các nhu cầu của cộng đồng rộng lớn hơn của chúng tôi.
Chúng tôi chắc chắn đã không đạt được trạng thái hoàn hảo giống như Nirvana, nhưng các quá trình chắc chắn đã được cải thiện.

I'd like to share some of these improvements as they are mostly hidden from the general public, yet have a huge impact on our ability to deliver a long-term roadmap. First, since September, IOHK has built a tremendous amount of [project management capacity](tmp//en/team/#pmo "PMO team, IOHK"), led by [Elieen Fitzgerald](tmp//en/team/eileen-fitzgerald/ "Eileen Fitzgerald").

Tôi muốn chia sẻ một số cải tiến này vì chúng hầu như bị ẩn khỏi công chúng, nhưng có tác động rất lớn đến khả năng của chúng tôi để đưa ra một lộ trình dài hạn.
Đầu tiên, kể từ tháng 9, IOHK đã xây dựng một số lượng lớn [năng lực quản lý dự án] (TMP // EN/TEAM/#PMO "Nhóm PMO, IOHK"), dẫn đầu bởi [Elieen Fitzgerald] (TMP // EN/Team/Eileen
-fitzgerald/ "Eileen Fitzgerald").

Under her department, Eileen has managed to capture business requirements, draft project charters, improve our resource allocation and budgeting processes, improve development estimates, get better weekly reporting and manage the inter-dependencies between projects. We have also had an increasingly easier time managing third-party relationships, like our [partnership with Runtime Verification](https://www.youtube.com/watch?v=iavSKtqjVNA "Grigore Rosu, Runtime Verification, youtube.com") for the K framework, IELE, and smart contract research.

Theo bộ phận của cô, Eileen đã quản lý để nắm bắt các yêu cầu kinh doanh, dự thảo điều lệ dự án, cải thiện quy trình phân bổ tài nguyên và ngân sách của chúng tôi, cải thiện ước tính phát triển, báo cáo tốt hơn hàng tuần và quản lý các phụ thuộc giữa các dự án.
Chúng tôi cũng đã có một thời gian ngày càng dễ dàng hơn để quản lý các mối quan hệ bên thứ ba, như [quan hệ đối tác của chúng tôi với xác minh thời gian chạy] (https://www.youtube.com/watch?v=IVSKTQJVNA "Grigore Rosu, RunTime xác minh, YouTube.com")
Đối với Khung K, IELE và nghiên cứu hợp đồng thông minh.

Some of the outputs of these processes are that we are moving to regular release cycles for Cardano, with the first cycle starting next week on Friday. Our hope is to cutÂ a develop branchÂ for release and then run the release through a rigorous QA cycle currently planned for one month. Over time, this cycle can be shortened through automation and parallel processes speeding up delivery. Updates will become more frequent, higher quality and encumber less user disruptions.

Một số đầu ra của các quy trình này là chúng tôi sẽ chuyển sang các chu kỳ phát hành thường xuyên cho Cardano, với chu kỳ đầu tiên bắt đầu vào tuần tới vào thứ Sáu.
Hy vọng của chúng tôi là cắt giảm một chi nhánh phát triển để phát hành và sau đó chạy bản phát hành thông qua một chu kỳ QA nghiêm ngặt hiện đang được lên kế hoạch trong một tháng.
Theo thời gian, chu kỳ này có thể được rút ngắn thông qua tự động hóa và các quy trình song song tăng tốc giao hàng.
Cập nhật sẽ trở nên thường xuyên hơn, chất lượng cao hơn và làm cho ít sự gián đoạn của người dùng hơn.

The goal of the project management department is to ensure when we give a date for delivering a feature, a release or a major update that the date and quality are delivered. This goal is one of the hardest to achieve for a software company and much more so given the nature of the software we build, but it's also incredibly important for those who rely upon us for their own commercial interests.

Mục tiêu của bộ phận quản lý dự án là đảm bảo khi chúng tôi đưa ra một ngày để cung cấp một tính năng, một bản phát hành hoặc một bản cập nhật lớn mà ngày và chất lượng được cung cấp.
Mục tiêu này là một trong những khó khăn nhất để đạt được đối với một công ty phần mềm và nhiều hơn nữa với bản chất của phần mềm chúng tôi xây dựng, nhưng nó cũng cực kỳ quan trọng đối với những người dựa vào chúng tôi vì lợi ích thương mại của riêng họ.

Over time our project management methodology will become increasingly public and eventually will be ported into a public GitHub repository. We'd like IOHK to follow a creative commons process that other software companies and projects in our space can benefit from, and add to, as they pursue their own projects. We'd like to explore lighter weight versions of the processes for DApp development so that our developer community can follow best practices.

Theo thời gian, phương pháp quản lý dự án của chúng tôi sẽ ngày càng trở nên công khai và cuối cùng sẽ được chuyển vào một kho lưu trữ công khai.
Chúng tôi muốn IOHK tuân theo quy trình Creative Commons mà các công ty và dự án phần mềm khác trong không gian của chúng tôi có thể hưởng lợi và thêm vào, khi họ theo đuổi các dự án của riêng họ.
Chúng tôi muốn khám phá các phiên bản trọng lượng nhẹ hơn của các quy trình để phát triển DAPP để cộng đồng nhà phát triển của chúng tôi có thể tuân theo các thực tiễn tốt nhất.

Second, working with exchanges and others, such as Ledger, we've been systematically redesigning Cardano's architecture, APIs and other components to be more friendly for those who wish to use our software. For example, you can see our new APIsÂ [here](https://cardanodocs.com/technical/wallet/api/v1/ "cardanodocs.com").

Thứ hai, làm việc với các trao đổi và những người khác, chẳng hạn như sổ cái, chúng tôi đã thiết kế lại một cách có hệ thống kiến trúc của Cardano, API và các thành phần khác để thân thiện hơn cho những người muốn sử dụng phần mềm của chúng tôi.
Ví dụ: bạn có thể thấy API mới của chúng tôi [tại đây] (https://cardanodocs.com/technical/wallet/api/v1/ "cardanodocs.com").

Another output has been moving our development towards a specification-driven process. The first component of the Cardano Settlement Layer to be ported into this process is our wallet backend, with the following formal specification:

Một đầu ra khác đã chuyển sự phát triển của chúng tôi sang một quy trình định hướng đặc điểm kỹ thuật.
Thành phần đầu tiên của lớp giải quyết Cardano được chuyển vào quy trình này là phụ trợ ví của chúng tôi, với đặc điểm kỹ thuật chính thức sau:

**Figure 1: Cardano SL's Formal Wallet Specification**

** Hình 1: Thông số kỹ thuật ví chính thức của Cardano SL **

![Figure 1: Cardano SL](img/2018-04-09-a-brief-update-on-cardano.009.jpeg)

The goal is that each part of Cardano will be specified in a format similar to the one above. These specifications are implementation independent, will eventually be analyzed using formal methods and can be used as a basis for test suites and improvement proposals.Â 

Mục tiêu là mỗi phần của Cardano sẽ được chỉ định ở định dạng tương tự như ở trên.
Các thông số kỹ thuật này được thực hiện độc lập, cuối cùng sẽ được phân tích bằng các phương pháp chính thức và có thể được sử dụng làm cơ sở cho các bộ thử nghiệm và đề xuất cải tiến.

We are aware that many want to build their own mobile clients or modified software. To this end, we've been exploring the best way of discussing aÂ [unified backend architecture](https://github.com/input-output-hk/cardano-sl/blob/c68f3873658c00cbe0bffa6866ce8b36eea4bb13/docs/proposals/unified-backend-architecture/tech-spec.md "Unified Backend Architecture Tech Spec, Cardano SL, github.com"). I would personally like to see dozens of wallets and great user experiences materialize for Cardano, but I'd also like to make sure that these experiences are useful, secure and easy to deploy.Â Â 

Chúng tôi biết rằng nhiều người muốn xây dựng khách hàng di động của riêng họ hoặc phần mềm sửa đổi.
Để kết thúc này, chúng tôi đã khám phá cách tốt nhất để thảo luận về Aâ [Kiến trúc phụ trợ thống nhất] (https://github.com/input-output-hk/cardano-sl/blob/c68f3873658c00cbe0bff
-Charchitecture/Tech-spec.md "Kiến trúc phụ trợ thống nhất Thông số kỹ thuật Kiến trúc, Cardano SL, github.com").
Cá nhân tôi muốn xem hàng tá ví và trải nghiệm người dùng tuyệt vời thành hiện thực cho Cardano, nhưng tôi cũng muốn đảm bảo rằng những trải nghiệm này hữu ích, an toàn và dễ triển khai.

Over the coming months, large chunks of Cardano's code will be ported over to, or replaced with, these specification-driven designs. This likely won't be directly noticed by our users. Rather, users will experience indirect symptoms, for example things getting faster, like wallet recovery from seed, fewer issues connecting to the network, a smaller memory and disk footprint as well as other improvements.

Trong những tháng tới, các phần lớn mã của Cardano sẽ được chuyển sang hoặc thay thế bằng các thiết kế dựa trên đặc điểm kỹ thuật này.
Điều này có khả năng sẽ không được người dùng của chúng tôi chú ý trực tiếp.
Thay vào đó, người dùng sẽ trải qua các triệu chứng gián tiếp, ví dụ như mọi thứ trở nên nhanh hơn, như phục hồi ví từ hạt giống, ít vấn đề kết nối với mạng, bộ nhớ nhỏ hơn và dấu chân đĩa cũng như các cải tiến khác.

As we now have the talent, processes and [clear roadmap](https://cardanoroadmap.com "cardanoroadmap.com"), Byron will continue to rapidly improve and become more feature-rich. The release we are cutting next week to QA will include paper wallets, much faster wallet restoration and numerous fixes. We expect it to clear QA in mid-May and for updates to be released to our users monthly thereafter.Â 

Khi chúng ta có tài năng, quy trình và [Lộ trình rõ ràng] (https://cardanoroadmap.com "cardanoroadmap.com"), Byron sẽ tiếp tục nhanh chóng cải thiện và trở nên giàu tính năng hơn.
Bản phát hành chúng tôi sẽ cắt vào tuần tới để QA sẽ bao gồm ví giấy, phục hồi ví nhanh hơn nhiều và nhiều bản sửa lỗi.
Chúng tôi hy vọng nó sẽ xóa QA vào giữa tháng Năm và để cập nhật được phát hành cho người dùng của chúng tôi hàng tháng sau đó.

Third, the most anticipated [upcoming release is Shelley](https://www.youtube.com/watch?v=GLciKKGPeTg "Duncan Coutts,  Cardano: Shelley Update. March 2018, youtube.com"). Shelley is a massive project with many workstreams and scientific dependencies. It also contains many social processes involving community coordination and management. Effectively, Shelley is about turning over the network fully to the users thereby decentralizing as much as possible.Â 

Thứ ba, bản phát hành được mong đợi nhất là Shelley] (https://www.youtube.com/watch?v=GlcikKGpetg "Duncan Coutts, Cardano: Shelley Update. Tháng 3 năm 2018, YouTube.com").
Shelley là một dự án lớn với nhiều truyền phát công trình và phụ thuộc khoa học.
Nó cũng chứa nhiều quy trình xã hội liên quan đến phối hợp và quản lý cộng đồng.
Thực tế, Shelley đang chuyển mạng hoàn toàn cho người dùng do đó phân cấp càng nhiều càng tốt.

The work we have done with Byron has given us a great deal of knowledge operationally, about the best way of iterating towards Shelley; however, special care has to be placed on consensus. IOHK has developed a custom, proof of stake protocol called Ouroboros for Cardano. It has never been used in a cryptocurrency before and has a completely original design.Â 

Công việc chúng tôi đã thực hiện với Byron đã cho chúng tôi rất nhiều kiến thức hoạt động, về cách lặp đi lặp lại tốt nhất đối với Shelley;
Tuy nhiên, sự chăm sóc đặc biệt phải được đặt vào sự đồng thuận.
IOHK đã phát triển một tùy chỉnh, bằng chứng về giao thức cổ phần được gọi là ouroboros cho Cardano.
Nó chưa bao giờ được sử dụng trong một loại tiền điện tử trước đây và có một thiết kế hoàn toàn nguyên bản.

Thus we have been extremely focused on a proper deployment of Ouroboros to the general public. Byron is running a version of Ouroboros with delegation locked to core nodes under the control of IOHK, the Cardano Foundation and Emurgo, and block rewards turned off, but when Shelley comes this cannot continue. Staking rights will be returned to Ada holders and delegation will be fully under their control.Â 

Do đó, chúng tôi đã cực kỳ tập trung vào việc triển khai hợp lý Ouroboros cho công chúng.
Byron đang điều hành một phiên bản của Ouroboros với phái đoàn bị khóa vào các nút cốt lõi dưới sự kiểm soát của IOHK, Quỹ Cardano và Emurgo, và phần thưởng khối đã tắt, nhưng khi Shelley đến điều này không thể tiếp tục.
Quyền đặt cược sẽ được trả lại cho chủ sở hữu ADA và phái đoàn sẽ hoàn toàn nằm dưới sự kiểm soát của họ.

To be clear, Ouroboros isn't a forced, delegated, proof of stake protocol like EOS or Bitshares. It's a pure, proof of stake protocol where for epoch elections every active Ada account is factored in. Anyone who holds Ada in a normal address in the global UTXO has a probability of being elected as a slot leader regardless of the amount of Ada they hold.Â  Â 

Để rõ ràng, Ouroboros không phải là một bằng chứng bắt buộc, được ủy thác, bằng chứng về giao thức cổ phần như EOS hoặc Bitshares.
Đó là một giao thức bằng chứng thuần túy, bằng chứng về cuộc bầu cử kỷ nguyên, mọi tài khoản ADA hoạt động đều được tính đến. Bất cứ ai giữ ADA trong một địa chỉ bình thường trong UTXO toàn cầu đều có khả năng được bầu làm người lãnh đạo khe
.Â Â

However, the reality is that most will not want or have the ability to host consensus nodes and consistently show up to fill the slots they have been elected to commit. Thus, we developed a delegation system and the concept of stake pools for those users.Â 

Tuy nhiên, thực tế là hầu hết sẽ không muốn hoặc có khả năng lưu trữ các nút đồng thuận và liên tục hiển thị để lấp đầy các vị trí mà họ đã được bầu để cam kết.
Do đó, chúng tôi đã phát triển một hệ thống ủy quyền và khái niệm về nhóm cổ phần cho những người dùng đó.

Briefly, anyone can runÂ a stake pool. There isn't a minimum threshold of Ada or a special club. Rather, there will be a blockchain-based registration system and a special transaction type to register a stake pool on-chain. Registered pools will be listed in the delegation center of Daedalus and pulled directed from the Cardano blockchain thereby preventing censorship or bias.Â 

Tóm lại, bất cứ ai cũng có thể chạy một nhóm cổ phần.
Không có ngưỡng tối thiểu của ADA hoặc một câu lạc bộ đặc biệt.
Thay vào đó, sẽ có một hệ thống đăng ký dựa trên blockchain và loại giao dịch đặc biệt để đăng ký nhóm cổ phần trên chuỗi.
Các hồ bơi đã đăng ký sẽ được liệt kê trong Trung tâm phái đoàn của Daedalus và được rút ra từ Blockchain Cardano do đó ngăn chặn kiểm duyệt hoặc BIA.â

Over the last few months, we've had to invest a huge amount of careful design and security thought into the process of delegation. There are dozens of factors and scenarios to consider, from cold staking to automation of rewards. But we have converged on a reasonable design for the Shelley release, and a paper will be released soon on [eprint](https://eprint.iacr.org/index.html "ePrint, IACR").

Trong vài tháng qua, chúng tôi đã phải đầu tư một lượng lớn suy nghĩ thiết kế và bảo mật cẩn thận vào quá trình ủy quyền.
Có hàng tá yếu tố và kịch bản để xem xét, từ đặt cược lạnh đến tự động hóa phần thưởng.
Nhưng chúng tôi đã hội tụ trên một thiết kế hợp lý cho việc phát hành Shelley và một bài báo sẽ sớm được phát hành trên [ePrint] (https://eprint.iacr.org/index.html "eprint, IACR").

The summary is that Ada holders can create a delegation certificate for the Ada they hold and register it on the Cardano blockchain. This process in effect separates stake rights from the spending keys for their Ada addresses. Thus the delegation certificates can live in Daedalus, but the spending keys could be kept offline on a paper wallet or ledger device for example.Â 

Tóm tắt là chủ sở hữu ADA có thể tạo chứng chỉ ủy quyền cho ADA mà họ nắm giữ và đăng ký trên blockchain Cardano.
Quá trình này có hiệu lực tách các quyền cổ phần với các khóa chi tiêu cho các địa chỉ ADA của họ.
Do đó, các chứng chỉ phái đoàn có thể sống ở Daedalus, nhưng các khóa chi tiêu có thể được giữ ngoại tuyến trên ví giấy hoặc thiết bị sổ cái chẳng hạn.

Delegation will be done through a special transaction and from a user experience viewpoint, via the delegation center in Daedalus. A user can find a stake pool they wish to delegate to, select it, and click a "delegate" button. It's just that simple. As we launch Shelley testnets, we'll experiment with different user experience flows, from length of delegation to partial delegation (splitting stake between pools).

Phái đoàn sẽ được thực hiện thông qua một giao dịch đặc biệt và từ quan điểm trải nghiệm người dùng, thông qua Trung tâm ủy quyền ở Daedalus.
Người dùng có thể tìm thấy một nhóm cổ phần mà họ muốn ủy thác, chọn nó và nhấp vào nút "Đại biểu".
Nó chỉ đơn giản.
Khi chúng tôi ra mắt Shelley Testnets, chúng tôi sẽ thử nghiệm các luồng trải nghiệm người dùng khác nhau, từ thời gian phái đoàn đến phái đoàn một phần (chia cổ phần giữa các nhóm).

Another advantage of this process is that unlike Bitcoin mining pools, as our protocol natively understands delegation, it can automatically pay rewards to those who delegated without having to trust the pool operator. At the end of each epoch, our goal is to close the reward pool through a special transaction, paying all those who delegated proportionally to their delegation amounts.

Một lợi thế khác của quá trình này là không giống như các nhóm khai thác bitcoin, vì giao thức của chúng tôi hiểu một cách tự nhiên, nó có thể tự động trả phần thưởng cho những người được ủy quyền mà không phải tin tưởng vào nhà điều hành nhóm.
Vào cuối mỗi kỷ nguyên, mục tiêu của chúng tôi là đóng phần thưởng thông qua một giao dịch đặc biệt, trả tất cả những người ủy thác theo tỷ lệ thuận với số tiền ủy quyền của họ.

Some benchmarks and threshold will have to be conducted over the coming months to optimize for space and prevent penny-flooding attacks. We will also need to explore different user experiences including notifications and other user interface considerations.Â 

Một số điểm chuẩn và ngưỡng sẽ phải được tiến hành trong những tháng tới để tối ưu hóa không gian và ngăn chặn các cuộc tấn công bằng xu.
Chúng tôi cũng sẽ cần khám phá các trải nghiệm người dùng khác nhau bao gồm thông báo và các cân nhắc giao diện người dùng khác.

There are natural questions to ask. How will we ensure that when Shelley launches there will be enough stake pools to ensure a reasonable amount of decentralization? How will these pools establish their brand and reputation? We considered these concerns and decided to open enrollment for a collection of beta testing stake pool operators.Â 

Có những câu hỏi tự nhiên để hỏi.
Làm thế nào chúng ta sẽ đảm bảo rằng khi Shelley ra mắt, sẽ có đủ nhóm cổ phần để đảm bảo một lượng phân cấp hợp lý?
Làm thế nào các nhóm này sẽ thiết lập thương hiệu và danh tiếng của họ?
Chúng tôi đã xem xét những mối quan tâm này và quyết định mở đăng ký cho một bộ sưu tập các nhà điều hành nhóm cổ phần thử nghiệm beta.

The goal with this process is to identify a set of 50 to 100 independent entities that are geographically well distributed who would like to run a stake pool as a business. The process will progress as follows:

Mục tiêu với quy trình này là xác định một bộ từ 50 đến 100 thực thể độc lập được phân phối tốt về mặt địa lý, những người muốn điều hành một nhóm cổ phần như một doanh nghiệp.
Quá trình sẽ tiến triển như sau:

1. Collect as many applications as possible atÂ <https://staking.cardano.org/> until the end of April

1. Thu thập càng nhiều ứng dụng càng tốt tại <https://staking.cardano.org/> cho đến cuối tháng 4

1. Process and winnow applications until we have a good set of 50 to 100 candidates

1. Quy trình và các ứng dụng Winnow cho đến khi chúng tôi có một bộ tốt từ 50 đến 100 ứng cử viên

1. Invite the candidates into the IOHK slack and begin discussions about hardware configurations, deployment strategy, docker images, etc

1. Mời các ứng cử viên vào IOHK Slack và bắt đầu thảo luận về cấu hình phần cứng, chiến lược triển khai, hình ảnh docker, v.v.

1. When the Shelley testnet is launched, invite the stake pools to register and work closely with them to beta test various scenarios and experiencesÂ  

1. Khi Shelley Testnet được ra mắt, hãy mời các nhóm cổ phần đăng ký và hợp tác chặt chẽ với họ để thử nghiệm các kịch bản và kinh nghiệm khác nhau

These beta testers will not get a special advantage or consideration when Shelley launches. They are necessary to test Shelley's design and ensure our assumptions and choices are reasonable as well as improve deployment strategy and documentation. When Shelley launches, there will be a grace period where all those who desire to register a stake pool can do so and Ada holders will be free to choose to delegate to anyone they want.Â 

Những người thử nghiệm beta này sẽ không nhận được một lợi thế đặc biệt hoặc xem xét khi Shelley ra mắt.
Chúng là cần thiết để kiểm tra thiết kế của Shelley và đảm bảo các giả định và lựa chọn của chúng tôi là hợp lý cũng như cải thiện chiến lược và tài liệu triển khai.
Khi Shelley ra mắt, sẽ có một khoảng thời gian ân hạn mà tất cả những người muốn đăng ký một nhóm cổ phần có thể làm như vậy và những người nắm giữ Ada sẽ được tự do chọn ủy thác cho bất kỳ ai họ muốn.

Once the grace period expires, auto-delegation will be turned off and rewards turned on: Cardano will be fully decentralized.Â 

Khi thời gian ân hạn hết hạn, tự động gửi sẽ bị tắt và phần thưởng được bật: Cardano sẽ được phân cấp hoàn toàn.

In closing, Cardano is a huge project. There are so many brilliant minds, great engineers and parallel efforts that it's difficult to capture all of it in a single post, much less just convey our progress. What's amazing to me is that we have really great processes established and are daily moving forward (a fan made a great website showing our daily commits:Â <https://cardanoupdates.com/>).Â 

Kết thúc, Cardano là một dự án lớn.
Có rất nhiều tâm trí xuất sắc, các kỹ sư tuyệt vời và những nỗ lực song song đến nỗi khó nắm bắt được tất cả trong một bài đăng, ít chỉ truyền đạt tiến trình của chúng tôi.
Điều đáng kinh ngạc đối với tôi là chúng tôi có những quy trình thực sự tuyệt vời được thiết lập và đang tiến về phía trước hàng ngày (một người hâm mộ đã tạo ra một trang web tuyệt vời cho thấy các cam kết hàng ngày của chúng tôi: Â <https://cardanoupdates.com/>).

What's also amazing to me is how quickly our scientific research is moving from the lab to code. Ouroboros has gone through over a dozen revisions and now is converging to a state where we can bootstrap from the genesis block without a checkpoint (an industry first for proof of stake). Our sidechains research is state of the art and a paper is coming in May.Â 

Điều tuyệt vời đối với tôi là nghiên cứu khoa học của chúng tôi đang chuyển từ phòng thí nghiệm này sang phòng thí nghiệm nhanh như thế nào.
Ouroboros đã trải qua hơn một chục sửa đổi và hiện đang hội tụ đến một tiểu bang nơi chúng ta có thể bootstrap từ khối Genesis mà không cần kiểm tra (trước tiên là một ngành để chứng minh cổ phần).
Nghiên cứu Sidechains của chúng tôi là trạng thái của nghệ thuật và một bài báo đang đến vào tháng 5.

We have also brought game theorists and programming language theory experts together. The output has been incredibly innovative with new accounting languages like Marlowe and an increasingly richer theory for incentives for stake pools, network maintenance and other topics requiring an honest majority for cryptocurrencies to run properly.

Chúng tôi cũng đã đưa các nhà lý thuyết trò chơi và các chuyên gia lý thuyết ngôn ngữ lập trình lại với nhau.
Đầu ra đã rất sáng tạo với các ngôn ngữ kế toán mới như Marlowe và một lý thuyết ngày càng phong phú hơn cho các ưu đãi cho nhóm cổ phần, bảo trì mạng và các chủ đề khác đòi hỏi đa số trung thực để tiền điện tử chạy đúng.

**Figure 2a: The Marlowe Programming Language** 

** Hình 2a: Ngôn ngữ lập trình Marlowe **

![Figure 2a: The Marlowe Programming Language](img/2018-04-09-a-brief-update-on-cardano.010.jpeg)

**Figure 2b: The Marlowe Programming Language** 

** Hình 2b: Ngôn ngữ lập trình Marlowe **

![Figure 2b: The Marlowe Programming Language](img/2018-04-09-a-brief-update-on-cardano.010.jpeg)

I'm astounded how we are able to think in systems now and by the quality of the people on the Cardano project. It's taken years to build this team and go from dream to regular status reports. I look forward to achieving our milestones and seeing Cardano change the world.Â 

Tôi kinh ngạc về cách chúng ta có thể suy nghĩ trong các hệ thống bây giờ và bằng chất lượng của những người trong dự án Cardano.
Phải mất nhiều năm để xây dựng đội ngũ này và đi từ giấc mơ đến các báo cáo tình trạng thường xuyên.
Tôi mong muốn đạt được các cột mốc của chúng tôi và thấy Cardano thay đổi thế giới.

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2018-04-09-a-brief-update-on-cardano.011.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

