# Daedalus Mantis 1.1 Released for Ethereum Classic
### **Software update delivers performance improvements**
![](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.002.png) 30 April 2018![](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.003.png) 5 mins read

![Jeremy Wood](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.004.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.005.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.006.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.007.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![Daedalus Mantis 1.1 Released for Ethereum Classic](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.008.jpeg)

It's the end of April and it already feels like a long time since February, when we announced version 1.0 of Mantis, our Ethereum Classic client built in Scala. After the success of [Mantis 1.0](tmp//en/blog/mantis-ethereum-classic-beta-release/ "Mantis release") some of the Grothendieck team got temporarily drafted onto other projects. That, coupled with the two-month full-time Haskell training course some of the team were on earlier this year, meant that Team Grothendieck has been short-handed recently. In fact, internally this release is sometimes called "The Konrad Release" as it was developer [Konrad Staniec](tmp//en/team/konrad-staniec/ "Konrad Staniec, IOHK") who kept the 1.1 candle burning and the performance pull requests (PRs) coming. 

Đó là vào cuối tháng 4 và nó đã cảm thấy như một thời gian dài kể từ tháng 2, khi chúng tôi công bố phiên bản 1.0 của Mantis, khách hàng cổ điển Ethereum của chúng tôi được xây dựng tại Scala.
Sau thành công của [Mantis 1.0] (TMP // EN/Blog/Mantis-Ethereum-Classic-Beta-Release/"Mantis Release") Một số nhóm Grothendieck đã tạm thời được soạn thảo cho các dự án khác.
Điều đó, cùng với khóa đào tạo Haskell toàn thời gian hai tháng, một số đội đã tham gia vào đầu năm nay, có nghĩa là Team Grothendieck đã ngắn gần đây.
Trên thực tế, bên trong bản phát hành này đôi khi được gọi là "Bản phát hành Konrad" vì nó là nhà phát triển [Konrad Staniec] (TMP // EN/Team/Konrad-Staniec/"Konrad Staniec, Iohk")
Kéo yêu cầu (PRS) sắp tới.

For review of the PRs we did of course leverage the expertise of the whole team, and special mention to [Alan Verbner](tmp//en/blog/iohk-spotlight-alan-verbner/ "IOHK Spotlight - Alan Verbner") and [Nico Taller](tmp//en/team/nicolas-tallar/ "Nicolas Tallar, IOHK") for their efforts in review and testing of the performance improvements to the complex pruning functionality. 

Để xem xét các PR, tất nhiên chúng tôi đã tận dụng chuyên môn của toàn đội, và đề cập đặc biệt đến [Alan Verbner] (TMP // EN/Blog/IOHK-Spotlight-Alan-Verbner/"IOHK Spotlight-Alan Verbner") và
[Nico cao hơn] (TMP // EN/Team/Nicolas-Tallar/"Nicolas Tallar, IOHK") vì những nỗ lực của họ trong việc xem xét và thử nghiệm các cải tiến hiệu suất đối với chức năng cắt tỉa phức tạp.

While I'm listing contributors, many thanks to [Lukasz Gasior](tmp//en/team/lukasz-gasior/ "Lukasz Gasior, IOHK") and [Radek Tkaczyk](tmp//en/team/radek-tkaczyk/ "Radek Tkaczyk, IOHK") for taking time to review PRs early on and especially to Carlos Montero and Jeremy Townsend, two new IOHK developers who jumped head first into the Mantis code just as the test cycle was starting and were invaluable in reviewing PRs and testing the JSON RPC API. Also the testing team's Alan McNicholas for giving the release candidate a whirl and finding an installer bug! That's quite a lot of shoulders to the wheel. 

Trong khi tôi liệt kê những người đóng góp, rất cảm ơn [Lukasz Gasior] (TMP // EN/Team/Lukasz-Gasior/"Lukasz Gasior, IOHK") và [Radek Tkaczyk] (TMP // EN/TEAM/RADEK
"Radek Tkaczyk, iohk") để dành thời gian để xem xét PRS sớm và đặc biệt là với Carlos Montero và Jeremy Townsend, hai nhà phát triển IOHK mới đã nhảy đầu vào mã Mantis khi chu kỳ thử nghiệm bắt đầu và không hợp lệ trong việc xem xét PRS và
Kiểm tra API RPC JSON.
Ngoài ra, Alan McNicholas của nhóm thử nghiệm đã cho ứng cử viên phát hành một vòng xoáy và tìm một lỗi cài đặt!
Đó là khá nhiều vai với bánh xe.

The objective of the 1.0 release was to create a working product, while the 1.1 release aimed to take the working code and find and remove the performance bottlenecks. The most painful bottleneck identified was in synchronizing the blockchain. This was complicated by the fact that tuning that performance depends on quite a few factors, the speed of the network, the type of hard disk on the machine and the number and type of peers at the time of synchronizing. 

Mục tiêu của bản phát hành 1.0 là tạo ra một sản phẩm hoạt động, trong khi bản phát hành 1.1 nhằm lấy mã làm việc và tìm và xóa các tắc nghẽn hiệu suất.
Các nút thắt đau đớn nhất được xác định là trong việc đồng bộ hóa blockchain.
Điều này rất phức tạp bởi thực tế là điều chỉnh hiệu suất phụ thuộc vào khá nhiều yếu tố, tốc độ của mạng, loại đĩa cứng trên máy và số lượng và loại đồng nghiệp tại thời điểm đồng bộ hóa.

For example on MacOs with an SSD and 8Gb of RAM Konrad was consistently getting about 17 hours for a full synchronization, whereas on an "small" EC2 instance this could take over a week! One of the reasons for this is AWS t2.small instances can be "limited" or "unlimited" referring to their CPU credits per hour. Once the limit of CPU credits has been reached, the synchronization slows down considerably. Our developer Jeremy Townsend wrote this up and it turns out this can be improved by using a "compute optimised" EC2 instance because the software now spends most of its time actually verifying blocks of transactions and those crypto functions are compute expensive!

Ví dụ, trên MacOS với SSD và 8GB Ram Konrad luôn nhận được khoảng 17 giờ để đồng bộ hóa đầy đủ, trong khi trên một ví dụ EC2 "nhỏ" này có thể mất hơn một tuần!
Một trong những lý do cho điều này là các trường hợp AWS T2.small có thể bị "giới hạn" hoặc "không giới hạn" đề cập đến tín dụng CPU của họ mỗi giờ.
Khi đã đạt được giới hạn của các khoản tín dụng CPU, việc đồng bộ hóa sẽ chậm lại đáng kể.
Nhà phát triển Jeremy Townsend của chúng tôi đã viết điều này và hóa ra điều này có thể được cải thiện bằng cách sử dụng phiên bản EC2 được tối ưu hóa "tính toán" vì phần mềm hiện dành phần lớn thời gian thực sự xác minh các khối giao dịch và các chức năng tiền điện tử đó rất tốn kém!

Apart from performance, the "difficulty bomb" ECIP 1041 has been disabled â€“ just in time too as the block where this becomes important rolls around in early May. 

Ngoài hiệu suất, "bom khó khăn" ECIP 1041 đã bị vô hiệu hóa - đúng lúc khi khối mà điều này trở nên quan trọng vào đầu tháng Năm.

There have been no changes to the wallet interface in this release. A couple of fairly minor changes were considered but the Daedalus team is flat out and while they are on the teamâ€™s backlog list they did not rise sufficiently in priority for inclusion in this release. The only real implication of that in this release is how the block download progress is reported. It was quite confusing for users to see a 0.0% progress bar for such a long time. The reason is the synchronization for ETC is different to the synchronization for ADA, in that ETC implements 'fast sync' and ADA does not. 

Không có thay đổi nào đối với giao diện ví trong bản phát hành này.
Một vài thay đổi khá nhỏ đã được xem xét nhưng nhóm Daedalus đã thẳng thắn và trong khi họ nằm trong danh sách tồn đọng của đội, họ không tăng đủ ưu tiên để đưa vào bản phát hành này.
Hàm ý thực sự duy nhất của điều đó trong bản phát hành này là cách thức tiến trình tải xuống khối được báo cáo.
Thật khó hiểu khi người dùng nhìn thấy một thanh tiến độ 0,0% trong một thời gian dài như vậy.
Lý do là sự đồng bộ hóa cho ETC khác với sự đồng bộ hóa cho ADA, trong đó, vv thực hiện 'đồng bộ nhanh' và ADA thì không.

Fast sync downloads the state trie and the blocks in the blockchain. Ada has no fast sync and downloads only the blocks. In 1.0 the state trie was downloaded *before* the blockchain and when the state trie was fully downloaded the blocks began to download. The progress bar is only aware of the blocks and so continued to show "0.0%" while the state trie was being downloaded. In 1.1 the situation is better but not perfect. In 1.1, as a result of performance testing and improvements the block downloading begins straight away and the state trie downloads towards the end of the synchronization. The user will see the progress bar update as expected, however towards the end of the synchronization the progress will appear to stall. This happens while the state trie downloads. While this is not perfect and needs to be fixed, on the plus side the whole process is faster and so the frustration should be less. Thank you in advance for your patience with this.

Sync nhanh chóng tải xuống Trie trạng thái và các khối trong blockchain.
ADA không đồng bộ hóa nhanh và chỉ tải xuống các khối.
Trong 1.0, Trie trạng thái đã được tải xuống * Trước * blockchain và khi Trie trạng thái được tải xuống đầy đủ, các khối bắt đầu tải xuống.
Thanh tiến độ chỉ nhận thức được các khối và do đó tiếp tục hiển thị "0,0%" trong khi Trie nhà nước đang được tải xuống.
Trong 1.1 tình hình tốt hơn nhưng không hoàn hảo.
Trong 1.1, do kết quả của việc kiểm tra và cải tiến hiệu suất, việc tải xuống khối bắt đầu ngay lập tức và các tải xuống Trie trạng thái cho đến cuối của đồng bộ hóa.
Người dùng sẽ thấy bản cập nhật thanh tiến trình như mong đợi, tuy nhiên vào cuối quá trình đồng bộ hóa, tiến trình sẽ xuất hiện để ngăn chặn.
Điều này xảy ra trong khi tải xuống Trie.
Mặc dù điều này không hoàn hảo và cần được sửa chữa, nhưng về mặt tích cực, toàn bộ quá trình này nhanh hơn và do đó sự thất vọng nên ít hơn.
Cảm ơn bạn trước vì sự kiên nhẫn của bạn với điều này.

![Ethereum Classic Roadmap](img/2018-04-30-daedalus-mantis-1-1-released-for-ethereum-classic.009.png)

The next release will be Mantis 2.0, currently slated for the end of the year, around Q4. This will be a significant release with significant new functionality. The Project Manager for this release, Ravi Patel, and a full-strength team will be introducing this functionality as it is prioritized.

Bản phát hành tiếp theo sẽ là Mantis 2.0, hiện đang dự kiến vào cuối năm nay, vào khoảng quý 4.
Đây sẽ là một bản phát hành đáng kể với chức năng mới đáng kể.
Người quản lý dự án cho bản phát hành này, Ravi Patel và một nhóm đầy đủ sức mạnh sẽ giới thiệu chức năng này vì nó được ưu tiên.

On a general note, I feel the progress in ETC is picking up pace. Observing the external ETC community it seems there has been a lot of good organisational work done and dedicated people involved. I'm more optimistic than ever about the future!

Trên một lưu ý chung, tôi cảm thấy sự tiến bộ trong ETC đang tăng tốc.
Quan sát cộng đồng bên ngoài ETC, dường như đã có rất nhiều công việc tổ chức tốt được thực hiện và những người tận tâm tham gia.
Tôi lạc quan hơn bao giờ hết về tương lai!

