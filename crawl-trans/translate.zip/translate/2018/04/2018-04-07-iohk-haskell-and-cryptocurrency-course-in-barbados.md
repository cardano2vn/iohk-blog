# Haskell and Cryptocurrency Course in Barbados
### **Two graduates share their experience of IOHK's functional programming course**
![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.002.png) 7 April 2018![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.002.png)[ Lars Brünjes](tmp//en/blog/authors/lars-brunjes/page-1/)![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.003.png) 7 mins read

![Lars Brünjes](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.004.png)[](tmp//en/blog/authors/lars-brunjes/page-1/)
### [**Lars Brünjes**](tmp//en/blog/authors/lars-brunjes/page-1/)
Education Director

Education

- ![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.005.png)[](mailto:lars.bruenjes@iohk.io "Email")
- ![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.006.png)[](https://www.linkedin.com/in/dr-lars-br%C3%BCnjes-1640993b "LinkedIn")
- ![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.007.png)[](https://twitter.com/LarsBrunjes "Twitter")
- ![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.008.png)[](https://github.com/brunjlar "GitHub")

![Haskell and Cryptocurrency Course in Barbados](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.009.jpeg)

The IOHK Haskell and Cryptocurrency course in Barbados brought together students and professionals who were interested in learning the Haskell programming language. The course ran for eight weeks at the University of West Indies. Barbados was the second time the programme was offered, after a successful inaugural course held in Athens last year. The goal of the course is to extend the computer science training of participants and introduce them to Haskell, an elegant functional programming language, [in the context of the cryptocurrency industry](https://www.nasdaq.com/article/fostering-the-next-generation-a-growing-need-for-crypto-education-cm937830 "Fostering the Next Generation A Growing Need for Crypto Education, nasdaq.com"). Haskell is the language used in the Cardano cryptocurrency, and it was chosen because of the security benefits it offers.

Khóa học IOHK Haskell và tiền điện tử ở Barbados đã tập hợp các sinh viên và chuyên gia, những người quan tâm đến việc học ngôn ngữ lập trình Haskell.
Khóa học diễn ra trong tám tuần tại Đại học Tây Ấn.
Barbados là lần thứ hai chương trình được cung cấp, sau khi một khóa học khai mạc thành công được tổ chức tại Athens năm ngoái.
Mục tiêu của khóa học là mở rộng đào tạo khoa học máy tính của những người tham gia và giới thiệu họ với Haskell, một ngôn ngữ lập trình chức năng thanh lịch, [trong bối cảnh ngành công nghiệp tiền điện tử] (https://www.nasdaq.com/article/fostering-
Các thế hệ hiện đại-a-A-A-for-Crypto-CRYPTO-CM937830 "Fostering Thế hệ tiếp theo Nhu cầu ngày càng tăng đối với giáo dục tiền điện tử, nasdaq.com").
Haskell là ngôn ngữ được sử dụng trong tiền điện tử Cardano và nó được chọn vì lợi ích bảo mật mà nó mang lại.

The course was designed and taught by Haskell and functional programming experts, including [myself](tmp//en/team/lars-brunjes/ "Lars Brϋnjes, iohk.io"), and Dr. Andres Löh of Well Typed and [Dr. Marcin Szamotulski](tmp//en/team/marcin-szamotulski/ "Marcin Szamotulski, iohk.io"), Haskell Developer at IOHK. Visiting lecturers included [Prof. Philip Wadler](tmp//en/team/philip-wadler/ "Philip Wadler, iohk.io"), one of the creators of Haskell, and IOHK Area Leader in Programming Languages, and Cardano SL developer, [Darryl McAdams](tmp//en/team/darryl-mcadams/ "Darryl McAdams, iohk.io"). The instructors aimed to strike a balance between theory and practice, teaching the students both theoretical background of functional programming in Haskell in particular (Lambda Calculus, System F, Category Theory, etc), but also introducing them to popular libraries and important techniques for solving real-world problems (networking, parsing, resource handling, and more). At the end of each course, students are given the opportunity to apply for positions at IOHK and continue their professional career in Haskell.

Khóa học được thiết kế và giảng dạy bởi các chuyên gia lập trình chức năng và Haskell, bao gồm [Bản thân] (TMP // EN/Team/Lars-Brunjes/"Lars Brϋnjes, Iohk.io"), và Tiến sĩ Andres Löh của Gõ tốt và [dr . Marcin Szamotulski] (TMP // EN/Team/Marcin-Szamotulski/"Marcin Szamotulski, iohk.io"), nhà phát triển Haskell tại IOHK. Các giảng viên tham quan bao gồm [Giáo sư. Philip Wadler] (TMP // EN/Team/Philip-Wadler/"Philip Wadler, Iohk.io"), một trong những người tạo TMP // EN/TEAM/DARRYL-MCADAMS/"DARRYL MCADAMS, IOHK.IO"). Các giảng viên nhằm mục đích đạt được sự cân bằng giữa lý thuyết và thực hành, dạy cho các sinh viên cả nền tảng lý thuyết của lập trình chức năng trong Haskell nói riêng (tính toán Lambda, hệ thống F, lý thuyết danh mục, v.v.) Các vấn đề trong thế giới thực (kết nối mạng, phân tích cú pháp, xử lý tài nguyên, v.v.). Vào cuối mỗi khóa học, sinh viên được trao cơ hội đăng ký các vị trí tại IOHK và tiếp tục sự nghiệp chuyên nghiệp của họ ở Haskell.

Here are the stories of two students who attended the IOHK Haskell and Cryptocurrency course in Barbados:

Dưới đây là những câu chuyện của hai sinh viên đã tham dự khóa học IOHK Haskell và tiền điện tử ở Barbados:

![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.010.png)

**Jordan Millar - Jordan is currently a chemist with an M.Sc. in organic chemistry from Oxford University.**

** Jordan Millar - Jordan hiện là một nhà hóa học với một ThS.
trong Hóa học hữu cơ từ Đại học Oxford. **

Upon hearing that IOHK was offering a free Haskell and Cryptocurrency course in Barbados I decided it would be foolish to not enroll. The stars aligned for me as Barbados is a stone’s throw away from Trinidad and Tobago, my home, and I was acutely aware of IOHK’s approach to cryptocurrency.

Khi nghe tin IOHK đang cung cấp một khóa học miễn phí và tiền điện tử ở Barbados, tôi quyết định sẽ thật ngu ngốc khi không đăng ký.
Các ngôi sao phù hợp với tôi khi Barbados là một hòn đá ném từ Trinidad và Tobago, nhà tôi, và tôi nhận thức sâu sắc về cách tiếp cận của IOHK đối với tiền điện tử.

My programming experience prior to this course was limited; I predominantly had written scripts in Python over the last two years. Only a few weeks prior to the course, I had become interested in Haskell through a functional programmer I happened to meet.

Kinh nghiệm lập trình của tôi trước khóa học này bị hạn chế;
Tôi chủ yếu đã viết kịch bản bằng Python trong hai năm qua.
Chỉ vài tuần trước khóa học, tôi đã trở nên quan tâm đến Haskell thông qua một lập trình viên chức năng mà tôi tình cờ gặp.

![Learning in Barbados](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.011.jpeg) 

Haskell students in class

Học sinh Haskell trong lớp

IOHK piqued my curiosity because at the time, they were the only company in the cryptocurrency space driven by research. This resonated with me as I had first-hand experience with research and development, albeit in a different field. I work in organic chemistry, and am currently working with a cleaning product manufacturer on their formulations. I appreciate the importance of developing a model, trying to break it yourself, and then having people smarter than you also trying to break it. In particular, if these networks are destined to hold hundreds of billions of dollars, you cannot afford to construct these networks in the ad hoc manner we have often seen before. With this in mind, I set off to Barbados to learn more about Haskell and IOHK’s methodology.

IOHK đã khơi dậy sự tò mò của tôi bởi vì vào thời điểm đó, họ là công ty duy nhất trong không gian tiền điện tử do nghiên cứu thúc đẩy.
Điều này cộng hưởng với tôi khi tôi có kinh nghiệm đầu tay với nghiên cứu và phát triển, mặc dù trong một lĩnh vực khác.
Tôi làm việc trong Hóa học hữu cơ, và hiện đang làm việc với một nhà sản xuất sản phẩm làm sạch trên các công thức của họ.
Tôi đánh giá cao tầm quan trọng của việc phát triển một mô hình, cố gắng tự phá vỡ nó, và sau đó có người thông minh hơn bạn cũng cố gắng phá vỡ nó.
Cụ thể, nếu các mạng này được định sẵn để nắm giữ hàng trăm tỷ đô la, bạn không thể đủ khả năng để xây dựng các mạng này theo cách ad hoc mà chúng ta thường thấy trước đây.
Với suy nghĩ này, tôi đã lên đường đến Barbados để tìm hiểu thêm về phương pháp của Haskell và Iohk.

The course was a whirlwind tour of Haskell starting with data types all the way to type families and everything in between. We charged through a series of topics and on a weekly basis were given a problem sheet to complete. Dr. Lars Brünjes and Dr. Marcin Szamotulski were exceptional teachers. They delivered the content effectively and gave additional clarification when required.

Khóa học là một chuyến tham quan gió lốc của Haskell bắt đầu với các loại dữ liệu cho đến khi gõ các gia đình và mọi thứ ở giữa.
Chúng tôi đã tính phí thông qua một loạt các chủ đề và trên cơ sở hàng tuần đã được đưa ra một bảng vấn đề để hoàn thành.
Tiến sĩ Lars Brünjes và Tiến sĩ Marcin Szamotulski là những giáo viên đặc biệt.
Họ cung cấp nội dung hiệu quả và làm rõ thêm khi được yêu cầu.

The course was challenging, especially because I had missed the first week due to logistical issues. That being said, I came to find that Haskell is an elegant and concise programming language. IOHK flew Philip Wadler to Barbados to give a couple of lectures! What stood out to me the most was his demonstration of the Curry-Howard correspondence. It was fascinating to see the link between mathematical proofs and programs. IOHK’s Darryl McAdams also visited us in Barbados and took us through compilers in Haskell. The elegance of Haskell really shone here in my opinion as she effortlessly created a simply typed programming language during class.

Khóa học là một thách thức, đặc biệt là vì tôi đã bỏ lỡ tuần đầu tiên do các vấn đề hậu cần.
Điều đó đang được nói, tôi đã tìm thấy rằng Haskell là một ngôn ngữ lập trình thanh lịch và súc tích.
Iohk đã bay Philip Wadler đến Barbados để giảng bài một vài bài giảng!
Điều nổi bật với tôi nhất là cuộc biểu tình của anh ấy về sự tương ứng của Hoàng sát.
Thật thú vị khi thấy mối liên hệ giữa các bằng chứng và chương trình toán học.
IOHK sườn Darryl McAdams cũng đã đến thăm chúng tôi ở Barbados và đưa chúng tôi qua các trình biên dịch ở Haskell.
Sự thanh lịch của Haskell thực sự tỏa sáng ở đây theo ý kiến của tôi khi cô ấy dễ dàng tạo ra một ngôn ngữ lập trình được đánh máy đơn giản trong lớp.

It wasn’t all work and no play; IOHK sponsored many dinners and outings while we were in Barbados. This rounded off the course nicely as everybody had time to socialize outside of the classroom. To top it off, Charles Hoskinson took time out of his incredibly busy schedule to come and see us in Barbados. Having only seen Charles in YouTube videos, it was a privilege to hear him share his future plans and vision for IOHK in person. If you thought his conviction transmitted effectively through his interviews online, wait until you hear him in person.

Đó là tất cả các công việc và không chơi;
IOHK tài trợ cho nhiều bữa tối và đi chơi khi chúng tôi ở Barbados.
Điều này đã kết thúc khóa học một cách độc đáo vì mọi người đã có thời gian để giao tiếp bên ngoài lớp học.
Trên hết, Charles Hoskinson đã dành thời gian ra khỏi lịch trình cực kỳ bận rộn của mình để đến và gặp chúng tôi ở Barbados.
Chỉ nhìn thấy Charles trong các video trên YouTube, thật vinh dự khi được nghe anh ấy chia sẻ kế hoạch và tầm nhìn tương lai của anh ấy cho IOHK trực tiếp.
Nếu bạn nghĩ rằng niềm tin của anh ấy đã truyền đi một cách hiệu quả thông qua các cuộc phỏng vấn của anh ấy trực tuyến, hãy đợi cho đến khi bạn nghe thấy anh ấy trực tiếp.

All in all, it was a great experience. To anybody reading this, I highly recommend enrolling in this course if you get the chance to!

Du sao thi đo cung la một trải nghiệm tuyệt vơi.
Đối với bất kỳ ai đọc điều này, tôi đặc biệt khuyên bạn nên đăng ký vào khóa học này nếu bạn có cơ hội!

![](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.010.png)

**Rob Cohen - Rob divides his time between his information security consulting firm Callidus Security and serving in the cyber security field in the US military. He graduated from Columbia University in 2015 with a BA in Computer Science and Mathematics.**

** Rob Cohen - Rob chia thời gian của mình giữa công ty tư vấn an ninh thông tin Callidus Security và phục vụ trong lĩnh vực an ninh mạng trong quân đội Hoa Kỳ.
Ông tốt nghiệp Đại học Columbia năm 2015 với bằng Cử nhân Khoa học máy tính và Toán học. **

I was fortunate to be invited to attend IOHK's eight-week course, "Haskell and Cryptocurrency" in Barbados in early 2018. Prior to the course, my only experience with functional programming had been in a Compilers course I had taken in college and some toy projects I had built as experiments. As a result I knew this course would be challenging, and it turned out to be exactly the kind of deep-dive crash course on Haskell and functional programming that I was hoping for. This course was demanding, requiring dedication in the classroom and diligence in applying those concepts in our assigned homeworks and group projects.

Tôi đã may mắn được mời tham dự khóa học kéo dài tám tuần của IOHK, "Haskell và tiền điện tử" ở Barbados vào đầu năm 2018. Trước khi khóa học, kinh nghiệm duy nhất của tôi với chương trình chức năng đã tham gia khóa học trình biên dịch mà tôi đã tham gia vào trường đại học và một số đồ chơi
Các dự án tôi đã xây dựng như các thí nghiệm.
Kết quả là tôi biết khóa học này sẽ là một thách thức, và hóa ra đó chính xác là loại khóa học về sự cố sâu sắc trên Haskell và lập trình chức năng mà tôi đang hy vọng.
Khóa học này đã được yêu cầu, đòi hỏi sự cống hiến trong lớp học và sự siêng năng trong việc áp dụng các khái niệm đó trong các dự án HomeWorks và nhóm được giao của chúng tôi.

![Fishing in Barbados](img/2018-04-07-iohk-haskell-and-cryptocurrency-course-in-barbados.011.jpeg) 

Haskell students going fishing

Học sinh Haskell đi câu cá

The course covered a variety of topics, from the basics of IO and higher-order functions, to lambda calculus, optics, free monads, GADTS and Generic Programming concepts (and much more). Beyond the theory, what I found most rewarding in the course was working with my fellow classmates on our group projects. One project my team worked on involved building the early stages of a working Bitcoin client in Haskell! Working on larger-scale projects like that really helped Haskell come alive for me. Furthermore, guest lectures by Phil Wadler and Darryl McAdams from IOHK's Plutus team were pleasant surprises as well.

Khóa học bao gồm một loạt các chủ đề, từ những điều cơ bản của IO và các chức năng bậc cao, đến tính toán Lambda, quang học, các đơn vị miễn phí, GADT và các khái niệm lập trình chung (và nhiều hơn nữa).
Ngoài lý thuyết, những gì tôi thấy bổ ích nhất trong khóa học là làm việc với các bạn cùng lớp của tôi trong các dự án nhóm của chúng tôi.
Một dự án mà nhóm của tôi đã làm việc liên quan đến việc xây dựng giai đoạn đầu của một khách hàng Bitcoin đang hoạt động ở Haskell!
Làm việc trên các dự án quy mô lớn như thế thực sự đã giúp Haskell trở nên sống động đối với tôi.
Hơn nữa, các bài giảng của khách mời của Phil Wadler và Darryl McAdams từ nhóm Plutus của Iohk cũng rất bất ngờ.

This course was not easy; there were times where I really felt my mettle was challenged. However, I stuck with it and pushed through. Now I not only have a deeper understanding and appreciation of the theoretical underpinnings of Haskell, but I came out as a developer with a stronger constitution as well. I am grateful to Lars and Marcin (the course instructor and teacher assistant) for all their hard work on the course. They put a tremendous amount of effort into the course materials and it showed. There were frequently times where their diagrams and explanations were better than Haskell's own official documentation!

Khóa học này không dễ dàng;
Có những lúc tôi thực sự cảm thấy khí phách của mình bị thách thức.
Tuy nhiên, tôi bị mắc kẹt với nó và đẩy qua.
Bây giờ tôi không chỉ có một sự hiểu biết và đánh giá cao hơn về nền tảng lý thuyết của Haskell, mà tôi cũng đã trở thành một nhà phát triển với một hiến pháp mạnh mẽ hơn.
Tôi biết ơn Lars và Marcin (người hướng dẫn khóa học và trợ lý giáo viên) cho tất cả các công việc khó khăn của họ trong khóa học.
Họ đặt một lượng lớn nỗ lực vào các tài liệu khóa học và nó cho thấy.
Thường có những lúc các sơ đồ và giải thích của họ tốt hơn so với tài liệu chính thức của Haskell!

The highlight of the course was the opportunity to work closely with such incredible developers from all around the world. My classmates hailed from Japan, Ireland, Argentina, Poland, Germany, Sweden, the USA, and the Caribbean. It was truly remarkable to have so many people from all over the world working together in one room trying to figure out how to learn Haskell. To my fellow classmates, I am deeply grateful for your support and camaraderie during the course. I salute you all for your dedication and hard work. I also look forward to our (spearfishing) reunion someday!

Điểm nổi bật của khóa học là cơ hội hợp tác chặt chẽ với các nhà phát triển đáng kinh ngạc như vậy từ khắp nơi trên thế giới.
Các bạn cùng lớp của tôi đến từ Nhật Bản, Ireland, Argentina, Ba Lan, Đức, Thụy Điển, Hoa Kỳ và Caribbean.
Thật đáng chú ý khi có rất nhiều người từ khắp nơi trên thế giới làm việc cùng nhau trong một phòng cố gắng tìm ra cách học Haskell.
Đối với các bạn cùng lớp của tôi, tôi vô cùng biết ơn sự hỗ trợ và tình bạn của bạn trong suốt khóa học.
Tôi chào tất cả các bạn vì sự cống hiến và làm việc chăm chỉ của bạn.
Tôi cũng mong chờ cuộc hội ngộ (Spearfishing) của chúng tôi vào một ngày nào đó!

I can safely say that I've been bitten by the Haskell bug, and I look forward to being a member of the Haskell/functional programming community for years to come. I highly recommend this course to anyone who is interested in learning about Haskell and functional programming.

Tôi có thể nói một cách an toàn rằng tôi đã bị lỗi Haskell và tôi mong muốn trở thành thành viên của cộng đồng lập trình Haskell/chức năng trong nhiều năm tới.
Tôi đánh giá cao khóa học này cho bất cứ ai quan tâm đến việc tìm hiểu về Haskell và lập trình chức năng.

