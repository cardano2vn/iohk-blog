# The hotel that became the world’s first business to accept Ada
### **I visited Hotel Ginebra in Barcelona to stay a night and meet the manager**
![](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.002.png) 5 January 2018![](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.002.png)[ Olga González](tmp//en/blog/authors/olga-gonzalez/page-1/)![](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.003.png) 7 mins read

![](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.004.png)[ The hotel that became the world’s first business to accept Ada - Input Output](https://ucarecdn.com/48bf767c-3bf7-4298-bf60-b85e3bb0bd03/-/inline/yes/ "The hotel that became the world’s first business to accept Ada - Input Output")

![Olga González](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.005.png)[](tmp//en/blog/authors/olga-gonzalez/page-1/)
### [**Olga González**](tmp//en/blog/authors/olga-gonzalez/page-1/)
Guest Blogger

![The hotel that became the world’s first business to accept Ada](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.006.jpeg)

[Hotel Ginebra](https://www.hotelginebra.com.es/ "Hotel Ginebra, Barcelona") is a boutique hotel in [Catalunya Square](https://en.wikipedia.org/wiki/Pla%C3%A7a_de_Catalunya "Pla%C3%A7a de Catalunya, Wikipedia"), which if you have visited Barcelona you will know is a prime location in the heart of the city. Guests can wake up in the morning to a great view of the city, but what they may not know is that the hotel has earned its place in history. It recently became the first business in the world to accept Ada, the Cardano cryptocurrency [launched at the end of September](https://bitcoinmagazine.com/articles/iohk-launches-cardano-blockchain-ada-now-trading-bittrex/ "IOHK Launches Cardano Blockchain with Ada Now Trading on Bittrex, Bitcoin Magazine"). I went to check out the hotel, to meet the manager, and to learn the story of how it came to [accept Ada](https://www.hotelginebra.com.es/welcome/ada/ "Hotel Ginebra, Ada as Payment"). Alfred Moesker is one of those who fell in love with this city. Born in the Netherlands, he had owned a hotel in Rome for years before he came to Barcelona and with his partner Yvonne Daniels took over Hotel Ginebra in 2013. Alfred and Yvonne are innovative managers who believe Ada can bring big benefits to the hotel industry, as well as to the wider world. I decided to make use of the offer to pay in Ada and found it was easy and efficient: the first of many transactions to be done, I am sure about that!

[Khách sạn Ginebra] (https://www.hotelginebra.com.es/ "Khách sạn Ginebra, Barcelona") là một khách sạn cửa hàng ở [Quảng trường Catalunya] (https://en.wikipedia.org/wiki/Pla A7A_DE_CATALUNYA "PLA%C3%a7a de Catalunya, Wikipedia"), mà nếu bạn đã đến thăm Barcelona, bạn sẽ biết là một vị trí đắc địa ở trung tâm thành phố. Khách có thể thức dậy vào buổi sáng với một cái nhìn tuyệt vời của thành phố, nhưng điều họ có thể không biết là khách sạn đã giành được vị trí của mình trong lịch sử. Gần đây, nó đã trở thành công việc đầu tiên trên thế giới chấp nhận ADA, tiền điện tử Cardano [ra mắt vào cuối tháng 9] (https://bitcoinmagazine.com/articles/iohk . Tôi đã đi kiểm tra khách sạn, để gặp người quản lý và tìm hiểu câu chuyện về cách nó đến [Chấp nhận ADA] (https://www.hotelginebra.com.es/welcome/ada/ "Khách sạn Ginebra, Ada là Thanh toán"). Alfred Moesker là một trong những người đã yêu thành phố này. Sinh ra ở Hà Lan, anh đã sở hữu một khách sạn ở Rome trong nhiều năm trước khi đến Barcelona và với đối tác của anh Yvonne Daniels đã tiếp quản khách sạn Ginebra vào năm 2013. Alfred và Yvonne là những người quản lý sáng tạo tin rằng ADA có thể mang lại lợi ích lớn cho ngành công nghiệp khách sạn, cũng như thế giới rộng lớn hơn. Tôi quyết định sử dụng lời đề nghị để trả tiền trong ADA và thấy rằng nó rất dễ dàng và hiệu quả: lần đầu tiên trong số nhiều giao dịch được thực hiện, tôi chắc chắn về điều đó!

I asked Alfred what he felt about being the first business to [accept Ada in payment](https://www.cardanohub.org/en/shop-with-cardano/ "Shop with Cardano, cardanohub.org").

Tôi đã hỏi Alfred những gì anh ấy cảm thấy khi trở thành doanh nghiệp đầu tiên [chấp nhận ADA trong thanh toán] (https://www.cardanohub.org/en/shop-with-cardano/ "Cửa hàng với Cardano, cardanohub.org").

“Incredibly proud,” he said. “For reasons we even fail to completely understand ourselves, we are more proud about it as we have been about anything else we have done for a long time. But working with Ada just feels right to us and it is a project that we feel we can identify with, not just something we just use and then throw away later. 

Anh ấy nói vô cùng tự hào, anh ấy nói.
Vì những lý do, chúng tôi thậm chí không hoàn toàn hiểu bản thân, chúng tôi tự hào hơn về điều đó vì chúng tôi đã làm bất cứ điều gì khác mà chúng tôi đã làm trong một thời gian dài.
Nhưng làm việc với ADA chỉ cảm thấy đúng với chúng tôi và đó là một dự án mà chúng tôi cảm thấy chúng tôi có thể xác định, không chỉ là thứ chúng tôi chỉ sử dụng và sau đó vứt bỏ sau đó.

In the short time since my visit, Alfred says quite a few people – including from Japan – have walked into the hotel inquiring if they can pay with Ada if they were to book a room. In a follow-up email he said: “To see how excited they get when we tell them ‘yes, you can’ is fantastic to witness.”

Trong thời gian ngắn kể từ chuyến thăm của tôi, Alfred nói khá nhiều người - bao gồm cả từ Nhật Bản - đã bước vào khách sạn hỏi xem họ có thể trả tiền với ADA nếu họ đặt phòng.
Trong một email tiếp theo, anh ấy nói: Để xem họ cảm thấy phấn khích như thế nào khi chúng tôi nói với họ ‘Vâng, bạn có thể rất tuyệt vời khi chứng kiến.

The hotel is in a typically Catalan building, with a regal style on the outside and a modernist feeling once you go in. It has been completely reformed on the inside and the rooms are cozy and quiet; they range from small, single rooms to big suites, so the hotel is very versatile. There are also great common spaces for guests (the use of which is included in the room price), computers with internet access, break rooms with tables and sofas, and snack rooms with tea, coffee and pastries available at all times. The staff are wonderful, kind and efficient, there’s a 24-hour reception service and they will greet you with a nice glass of wine and a chocolate once you’re settled in your room. If the location and the well-kept inside wasn’t enough to make it a great stay, the staff totally top it!

Khách sạn nằm trong một tòa nhà Catalan điển hình, với phong cách vương giả ở bên ngoài và cảm giác hiện đại một khi bạn đi vào. Nó đã được cải cách hoàn toàn ở bên trong và các phòng ấm cúng và yên tĩnh;
Chúng bao gồm từ các phòng nhỏ, đơn đến các bộ lớn, vì vậy khách sạn rất linh hoạt.
Ngoài ra còn có những không gian phổ biến tuyệt vời cho khách (việc sử dụng được bao gồm trong giá phòng), máy tính có truy cập internet, phòng nghỉ với bàn và ghế sofa, và phòng ăn nhẹ với trà, cà phê và bánh ngọt có sẵn mọi lúc.
Các nhân viên rất tuyệt vời, tốt bụng và hiệu quả, có một dịch vụ tiếp tân 24 giờ và họ sẽ chào đón bạn với một ly rượu vang đẹp và sô cô la một khi bạn đã định cư trong phòng.
Nếu vị trí và người được bảo quản bên trong là đủ để làm cho nó trở thành một kỳ nghỉ tuyệt vời, các nhân viên hoàn toàn đứng đầu nó!

![View from Hotel Ginebra, Barcelona](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.007.jpeg) 

View of Catalunya Square from Hotel Ginebra

Quan điểm của Quảng trường Catalunya từ khách sạn Ginebra

It’s not hard to see why Alfred and Yvonne moved to Barcelona. The hotel overlooks Plaça de Catalunya’s famous fountains and the main streets: La Rambla, where there are restaurants, museums, and shops, before you finally get to the beach; Passeig de Gràcia, if you love haute couture or want to have a taste of fancy Barcelona take a stroll around here, and Portal de l’Àngel, which leads to Barcelona Cathedral and the gothic district, and where you will find the famous Santa Llúcia fair if you’re visiting in winter). What all these places have in common, aside from being Barcelona’s heart and soul, is that they’re a three-minute walk from Hotel Ginebra.

Nó không khó để hiểu tại sao Alfred và Yvonne chuyển đến Barcelona.
Khách sạn nhìn ra Plaça de Catalunya, đài phun nước nổi tiếng và đường phố chính: La Rambla, nơi có nhà hàng, bảo tàng và cửa hàng, trước khi cuối cùng bạn đến bãi biển;
Passeig de gràcia, nếu bạn yêu thích couture hoặc muốn có một hương vị của Barcelona lạ mắt, hãy đi dạo ở đây, và Portal de l'Ar
Công bằng nếu bạn đến thăm vào mùa đông).
Những gì tất cả những nơi này có điểm chung, ngoài việc là trái tim và tâm hồn của Barcelona, đó là họ cách khách sạn Ginebra ba phút đi bộ.

Alfred came across Ada after reading an online article. He was just learning about Bitcoin at the time and was put off by its huge price volatility, fluctuating values not being nice and predictable for a business. He wondered instead whether alt coins might have a role to play in his business. A friend warned him that cryptocurrency was “like the wild west” because it was an emerging technology, but he preserved with his research and came across [Cardano](https://cardanohub.org "cardanohub.org") and the [whiteboard videos](https://www.youtube.com/playlist?list=PLnPTB0CuBOBxDBrD4-ZflYF6y3L3jMUOs "IOHK Whiteboard Videos, YouTube"). 

Alfred tình cờ gặp ADA sau khi đọc một bài viết trực tuyến.
Anh ta chỉ tìm hiểu về Bitcoin vào thời điểm đó và bị loại bỏ bởi sự biến động về giá khổng lồ của nó, các giá trị biến động không phải là tốt đẹp và có thể dự đoán được cho một doanh nghiệp.
Thay vào đó, anh tự hỏi liệu đồng tiền alt có thể có vai trò trong công việc kinh doanh của mình hay không.
Một người bạn đã cảnh báo anh ta rằng tiền điện tử là giống như miền tây hoang dã vì đó là một công nghệ mới nổi, nhưng anh ta bảo tồn với nghiên cứu của mình và bắt gặp [cardano] (https://cardanohub.org "cardanohub.org") và [bảng trắng
Video] (https://www.youtube.com/playlist?list=PLNPTB0CUBOBXDBRD4-ZFLYF6Y3L3JMUOS "Video Whiteboard IOHK, YouTube").

“I liked the idea behind cryptocurrency,” he said. The peer to peer principle definitely is very attractive to us personally. We have had our share of bad experiences with banks and the idea that there is something else out there that can make the system a bit fairer just sounded all too appealing.

Tôi thích ý tưởng đằng sau tiền điện tử, anh ấy nói.
Nguyên tắc ngang hàng chắc chắn rất hấp dẫn đối với cá nhân chúng ta.
Chúng tôi đã có những chia sẻ về những trải nghiệm tồi tệ với các ngân hàng và ý tưởng rằng có một cái gì đó khác ngoài kia có thể làm cho hệ thống công bằng hơn một chút nghe có vẻ quá hấp dẫn.

“Then I read about the Cardano project which seemed the opposite of exciting. It featured a photo of Jeremy Wood and Charles Hoskinson, both clearly the academic type – bordering on "nerdy" in a good way! When we read how they had been carefully constructing this project in order to take out the flaws of other cryptocurrencies and offer a much more "balanced" product, we thought ‘bingo’!!!”

Sau đó, tôi đọc về dự án Cardano có vẻ trái ngược với sự thú vị.
Nó có một bức ảnh của Jeremy Wood và Charles Hoskinson, cả hai đều rõ ràng là loại học thuật - giáp với "Nerdy" một cách tốt!
Khi chúng tôi đọc cách họ đã xây dựng cẩn thận dự án này để loại bỏ những sai sót của các loại tiền điện tử khác và cung cấp một sản phẩm "cân bằng" hơn nhiều, chúng tôi nghĩ rằng ‘Bingo, !!!

Alfred liked the fact that Ada had been designed to be used as a cryptocurrency and also that it was part of Cardano, a system that would “lay the foundations for many projects in the crypto industry for many years to come”. “We get a strong sense that Ada is a product that will do good in the world and that has been set up for the right reasons,” he said.

Alfred thích thực tế rằng ADA đã được thiết kế để sử dụng như một loại tiền điện tử và đó cũng là một phần của Cardano, một hệ thống sẽ đặt nền móng cho nhiều dự án trong ngành công nghiệp tiền điện tử trong nhiều năm tới.
Chúng tôi có một cảm giác mạnh mẽ rằng ADA là một sản phẩm sẽ làm tốt trên thế giới và điều đó đã được thiết lập vì những lý do chính đáng, ông nói.

Ada could also bring big benefits to the hotel industry in Alfred’s view.

ADA cũng có thể mang lại lợi ích lớn cho ngành công nghiệp khách sạn theo quan điểm của Alfred.

“Accepting a cryptocurrency in general opens up a new segment of the travelling global population,” he said. “Accepting Ada will very importantly give us a chance to also go back to peer to peer relations with our potential customers. Nowadays the big reservation portals have so much commercial power that you are pretty much at their mercy.”

Chấp nhận một loại tiền điện tử nói chung mở ra một phân khúc mới của dân số toàn cầu du lịch, ông nói.
Chấp nhận ADA sẽ rất quan trọng cho chúng tôi cơ hội cũng quay trở lại với mối quan hệ ngang hàng với khách hàng tiềm năng của chúng tôi.
Ngày nay, các cổng bảo lưu lớn có rất nhiều sức mạnh thương mại đến nỗi bạn khá thương xót.

“Imagine if and when Ada has been distributed globally. A lot more people, that now do not have a credit card or have credit rating problems and can’t easily make a hotel reservation, by using ADA will be able to make a reservation in one minute. In our opinion it will promote financial global equality, at least that seems very likely from what we see happening with the hotel reservation process and hotel industry.”

Hãy tưởng tượng nếu và khi ADA được phân phối trên toàn cầu.
Nhiều người hơn, bây giờ không có thẻ tín dụng hoặc có vấn đề xếp hạng tín dụng và có thể dễ dàng đặt chỗ khách sạn, bằng cách sử dụng ADA sẽ có thể đặt chỗ trong một phút.
Theo chúng tôi, nó sẽ thúc đẩy sự bình đẳng toàn cầu tài chính, ít nhất điều đó dường như rất có thể từ những gì chúng ta thấy xảy ra với quy trình đặt phòng khách sạn và ngành công nghiệp khách sạn.

![Alfred and Yvonne](img/2018-01-05-the-hotel-that-became-the-worlds-first-business-to-accept-ada.007.jpeg) 

Alfred and Yvonne at Hotel Ginebra

Alfred và Yvonne tại khách sạn Ginebra

All in all, visiting the hotel and meeting Alfred was a very positive experience. I spent a wonderful night in a nice hotel with kind staff in the center of the city, waking up in Barcelona’s heart at a good price and used a safe, direct form of payment. Either if you’re travelling for business or on holiday, alone or with friends or family, I can totally recommend it.

Nói chung, đến thăm khách sạn và gặp Alfred là một trải nghiệm rất tích cực.
Tôi đã trải qua một đêm tuyệt vời trong một khách sạn đẹp với nhân viên tốt bụng ở trung tâm thành phố, thức dậy trong trái tim Barcelona với một mức giá tốt và sử dụng một hình thức thanh toán trực tiếp, an toàn.
Hoặc nếu bạn đi du lịch để kinh doanh hoặc đi nghỉ, một mình hoặc với bạn bè hoặc gia đình, tôi hoàn toàn có thể giới thiệu nó.

Alfred was very excited about Cardano’s potential and proud to be a part of the community. 

Alfred rất hào hứng với tiềm năng của Cardano, và tự hào là một phần của cộng đồng.

His words about what attracted him to [Cardano and its community](https://forum.cardanohub.org/ "Cardano Community Forum, forum.cardanohub.org") were:

Những lời của anh ấy về những gì đã thu hút anh ấy [Cardano và cộng đồng của nó] (https://forum.cardanohub.org/ "Diễn đàn cộng đồng Cardano, Forum.cardanohub.org") là:

“It is hard to define…it is just one of those things you come across in your life sometimes and you just know it’s right, even when you only understand a fraction of the “why” at the time. 

Thật khó để định nghĩa, đó chỉ là một trong những điều bạn gặp phải trong cuộc sống của bạn và bạn chỉ biết điều đó đúng, ngay cả khi bạn chỉ hiểu một phần của tại sao tại sao đó.

“What we do know is that it seems to connect us also on a personal level to what is apparently a pretty special group of people who also like this project and what more can you wish for in life?”

Những gì chúng ta biết là nó dường như cũng kết nối chúng ta ở cấp độ cá nhân với những gì rõ ràng là một nhóm người khá đặc biệt cũng thích dự án này và bạn có thể mong muốn điều gì hơn trong cuộc sống?

*This article was contributed by a guest blogger and you can show appreciation for this blog by donating Ada to Olga at the following address:*

*Bài viết này được đóng góp bởi một blogger khách và bạn có thể thể hiện sự đánh giá cao cho blog này bằng cách tặng ADA cho Olga tại địa chỉ sau:*

DdzFFzCqrhtD7LSVkenGw1e14Tb86TS1PsFiTZDL9LPbz8sX7D1ZspzKPn5XmkbrxBhb7BpJrHqtNjgECYrJVw3LwWAF98LUQwiaMUfC

Ddzffzcqrhtd7lsvkengw1e14tb86ts1psfitzdl9lpbz8sx7d1zspzkpn5xmkbrxbhb7bpjrhqtnjgecyrjvw3lw

