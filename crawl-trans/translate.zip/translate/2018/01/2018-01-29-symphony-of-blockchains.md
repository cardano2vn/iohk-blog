# Symphony of Blockchains
![](img/2018-01-29-symphony-of-blockchains.002.png) 29 January 2018![](img/2018-01-29-symphony-of-blockchains.002.png)[ Rouska Lundin](tmp//en/blog/authors/rouska-lundin/page-1/)![](img/2018-01-29-symphony-of-blockchains.003.png) 4 mins read

![](img/2018-01-29-symphony-of-blockchains.004.png)[ Symphony of Blockchains - Input Output](https://ucarecdn.com/92e6b86f-f0cb-4f2c-89ca-c184d270e0a2/-/inline/yes/ "Symphony of Blockchains - Input Output")

![Rouska Lundin](img/2018-01-29-symphony-of-blockchains.005.png)[](tmp//en/blog/authors/rouska-lundin/page-1/)
### [**Rouska Lundin**](tmp//en/blog/authors/rouska-lundin/page-1/)
Production Director

Kuva

- ![](img/2018-01-29-symphony-of-blockchains.006.png)[](https://www.linkedin.com/in/rouskalundin/ "LinkedIn")
- ![](img/2018-01-29-symphony-of-blockchains.007.png)[](https://twitter.com/rouska "Twitter")
- ![](img/2018-01-29-symphony-of-blockchains.008.png)[](https://github.com/wearekuva "GitHub")

[The Symphony of Blockchains](https://iohk.io "iohk.io") is an interactive, visual and auditory exploration of Bitcoin, cryptocurrency and the blockchain. It is an ongoing research initiative with a singular aim: to help bring about greater understanding of both blockchain technology and the ever expanding (and contracting) cryptocurrency marketplace. The term â€˜blockchainâ€™ is being increasingly found in everyday language, with little explanation or understanding of the technology and its implication for the future. This work aims to explain both blockchain technology and its most visible applicationâ€Šâ€”â€Šcryptocurrencies. Through this visualisation we explain the concept underpinning blockchain as well as the individual transactional detail and ultimately the health of any cryptocurrency.

[Bản giao hưởng của blockchain] (https://iohk.io "iohk.io") là một cuộc thăm dò tương tác, thị giác và thính giác của bitcoin, tiền điện tử và blockchain.
Đây là một sáng kiến nghiên cứu đang diễn ra với mục đích đơn lẻ: giúp mang lại sự hiểu biết nhiều hơn về cả công nghệ blockchain và thị trường tiền điện tử ngày càng mở rộng (và hợp đồng).
Thuật ngữ - ˜blockchainâ € ™ ngày càng được tìm thấy trong ngôn ngữ hàng ngày, với rất ít lời giải thích hoặc hiểu biết về công nghệ và hàm ý của nó đối với tương lai.
Công việc này nhằm mục đích giải thích cả công nghệ blockchain và ứng dụng dễ thấy nhất của nó - š € Šcryptocurrecies của nó.
Thông qua hình dung này, chúng tôi giải thích khái niệm làm nền tảng cho blockchain cũng như chi tiết giao dịch cá nhân và cuối cùng là sức khỏe của bất kỳ loại tiền điện tử nào.

As the technology becomes more pervasive and it impacts on everyday life more, itâ€™s important that we attempt to [explain it in a meaningful way](https://thenextweb.com/distract/2018/01/17/bitcoin-as-art-this-breath-taking-visualization-might-distract-you-from-the-dip/ "The Next Web - Bitcoin as Art").

Khi công nghệ trở nên phổ biến hơn và nó tác động đến cuộc sống hàng ngày nhiều hơn, điều quan trọng là chúng tôi cố gắng [giải thích nó một cách có ý nghĩa] (https://thenextweb.com/distract/2018/01/17/bitcoin-
art-art-bole-beath-ataking-risualization-might-distract-you-from-the-dip/ "The Next Web-Bitcoin As Art").

At [Kuva](https://kuva.io "kuva.io"), a design studio of artists, designers and technologists, we help define new metaphors through which to understand these technologies.

Tại [Kuva] (https://kuva.io "kuva.io"), một studio thiết kế gồm các nghệ sĩ, nhà thiết kế và công nghệ, chúng tôi giúp xác định các phép ẩn dụ mới thông qua đó để hiểu các công nghệ này.

![Symphony of Blockchains](img/2018-01-29-symphony-of-blockchains.009.png)

In Symphony we explore the blockchain of Bitcoin as a physical structure. We examine its inherent underlying qualities by encapsulating data as crystalline forms connected in space, that are immutable and persistent. Using this as a metaphor provides a means to understand the Bitcoin blockchain. Blocks take on the properties of the data, their size, colour and orientation represent various qualities. Blocks are orientated in a spiral tracing back through time, each periodic rotation representing a day in the life of the blockchain. Their size and colour represent the total value of transactions made.

Trong Symphony, chúng tôi khám phá blockchain của Bitcoin như một cấu trúc vật lý.
Chúng tôi kiểm tra các phẩm chất cơ bản vốn có của nó bằng cách đóng gói dữ liệu như các dạng tinh thể được kết nối trong không gian, là bất biến và bền bỉ.
Sử dụng điều này như một phép ẩn dụ cung cấp một phương tiện để hiểu blockchain bitcoin.
Các khối đảm nhận các thuộc tính của dữ liệu, kích thước, màu sắc và định hướng của chúng đại diện cho các phẩm chất khác nhau.
Các khối được định hướng trong một dấu vết xoắn ốc trở lại theo thời gian, mỗi vòng quay định kỳ đại diện cho một ngày trong cuộc sống của blockchain.
Kích thước và màu sắc của chúng đại diện cho tổng giá trị của các giao dịch được thực hiện.

![Symphony of Blockchains - Visualisation](img/2018-01-29-symphony-of-blockchains.010.jpeg)

Symphony also explores the blockchain as an auditory experience. We ask a simple question: â€˜what does the blockchain sound like?â€™. Using the frequency and timing of Bitcoin transactions as a foundation, the audio extends the crystalling structures by encoding as an sound based entity.

Symphony cũng khám phá blockchain như một trải nghiệm thính giác.
Chúng tôi hỏi một câu hỏi đơn giản: "Blockchain nghe như thế nào? Â € ™.
Sử dụng tần suất và thời gian của các giao dịch bitcoin làm nền tảng, âm thanh mở rộng các cấu trúc kết tinh bằng cách mã hóa như một thực thể dựa trên âm thanh.

The background sound is an ambient soundscape created from real recordings of computer power supplies and fans to emulate the sound of Bitcoin mining.The intensity of the sound varies with the hashrate of the network.

Âm thanh nền là một âm thanh xung quanh được tạo ra từ các bản ghi thực của nguồn cung cấp năng lượng máy tính và quạt để mô phỏng âm thanh của việc khai thác bitcoin. Cường độ của âm thanh thay đổi theo băm của mạng.

The audio of the Merkle tree is based on the transactions of the block. A repeating loop is set to run every musical measure (a segment of time corresponding to a specific number of beats in which each beat is represented by a particular note value) Transactions are arranged in ascending order based on the time they were made. The timescale of a block from the earliest to the latest mined, is mapped from 0 to 30 seconds.

Âm thanh của cây Merkle dựa trên các giao dịch của khối.
Một vòng lặp lặp lại được đặt để chạy mọi biện pháp âm nhạc (một phân đoạn thời gian tương ứng với một số lượng nhịp cụ thể trong đó mỗi nhịp được biểu thị bằng một giá trị ghi chú cụ thể) Các giao dịch được sắp xếp theo thứ tự tăng dần dựa trên thời gian chúng được thực hiện.
Thời gian của một khối từ sớm nhất đến khai thác mới nhất, được ánh xạ từ 0 đến 30 giây.

![Symphony of Blockchains - Block](img/2018-01-29-symphony-of-blockchains.010.jpeg)

Each transaction sound is triggered and set to loop based on the mapped time value (quantized to the nearest 32nd note). As the master loop repeats, notes accumulate and build up a pattern.

Mỗi âm thanh giao dịch được kích hoạt và đặt thành vòng lặp dựa trên giá trị thời gian được ánh xạ (được định lượng thành ghi chú 32 gần nhất).
Khi vòng lặp chính lặp đi lặp lại, ghi chú tích lũy và xây dựng một mẫu.

The note of each transaction sound is based on the position on the y-axis, to the nearest note in the Aeolian mode.

Ghi chú của mỗi âm thanh giao dịch dựa trên vị trí trên trục y, đến ghi chú gần nhất trong chế độ Aeilian.

When it came to the user experience we wanted to ensure it was effortless to explore. The concepts and technologies weâ€™re attempting to explain are complex enough. We didnâ€™t want users having to fathom out a complex navigation system on top of it all.

Khi nói đến trải nghiệm người dùng, chúng tôi muốn đảm bảo rằng nó rất dễ khám phá.
Các khái niệm và công nghệ mà chúng ta đang cố gắng giải thích là đủ phức tạp.
Chúng tôi không muốn người dùng phải tìm ra một hệ thống điều hướng phức tạp trên tất cả.

Once the blockchain is loaded users simply scroll up or down to move forward or back in time through the blockchain. Using their pointer (or finger on mobile devices) they can easily select an individual node or block in the chain to investigate it further. Once accessed, the user is presented with a view of the unique Merkle tree that identifies that specific block. In addition to the Merkle tree view, the user is presented with a plethora of information giving detail about the transaction the selected block represents. To exit the block view the user simply clicks away.

Khi blockchain được tải, người dùng chỉ cần cuộn lên hoặc xuống để di chuyển về phía trước hoặc trở lại đúng thời gian thông qua blockchain.
Sử dụng con trỏ của họ (hoặc ngón tay trên thiết bị di động), chúng có thể dễ dàng chọn một nút riêng lẻ hoặc chặn trong chuỗi để điều tra thêm.
Sau khi được truy cập, người dùng được trình bày với chế độ xem của cây Merkle duy nhất xác định khối cụ thể đó.
Ngoài chế độ xem cây Merkle, người dùng còn được trình bày với rất nhiều thông tin cung cấp chi tiết về giao dịch mà khối được chọn đại diện.
Để thoát khỏi Chế độ xem khối, người dùng chỉ cần nhấp vào.

A walkthrough of the experience

Hướng dẫn trải nghiệm

## **Attachments**

## ** tệp đính kèm **

![](img/2018-01-29-symphony-of-blockchains.004.png)[ Symphony of Blockchains - Input Output](https://ucarecdn.com/92e6b86f-f0cb-4f2c-89ca-c184d270e0a2/-/inline/yes/ "Symphony of Blockchains - Input Output")

