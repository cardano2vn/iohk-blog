# Telescopic Proof Refinement
![](img/2018-01-02-telescopic-proof-refinement.002.png) 2 January 2018![](img/2018-01-02-telescopic-proof-refinement.002.png)[ Rebecca Valentine](tmp//en/blog/authors/rebecca-valentine/page-1/)![](img/2018-01-02-telescopic-proof-refinement.003.png) 12 mins read

![](img/2018-01-02-telescopic-proof-refinement.004.png)[ Telescopic Proof Refinement - Input Output](https://ucarecdn.com/e9b6cb0a-339d-4286-8960-98f98614cfcf/-/inline/yes/ "Telescopic Proof Refinement - Input Output")

![Rebecca Valentine](img/2018-01-02-telescopic-proof-refinement.005.png)[](tmp//en/blog/authors/rebecca-valentine/page-1/)
### [**Rebecca Valentine**](tmp//en/blog/authors/rebecca-valentine/page-1/)
Cardano SL Developer Team

Plutus Manager

- ![](img/2018-01-02-telescopic-proof-refinement.006.png)[](https://github.com/psygnisfive "GitHub")

![Telescopic Proof Refinement](img/2018-01-02-telescopic-proof-refinement.007.jpeg)

In the third post in this series ([part 1](tmp//en/blog/proof-refinement-basics/ "Proof Refinement Basics, iohk.io"), [part 2](tmp//en/blog/bidirectional-proof-refinement/ "Bidirectional Proof Refinement, iohk.io")) on proof refinement, I'm going to show you how to properly handle bidirectionality in an elegant way. The technique we'll use is the replacement of lists and functions with a data structure called a telescope. This post will use Haskell exclusively, because of the limitations of JavaScript in presenting these things elegantly. I've put together [repl.it](https://repl.it/ "repl.it") REPLs for this blog post so you can play around with the code. You can find them here: [Addition 1](https://repl.it/@psygnisfive/TelescopicProofRefinement-Addition1 "Addition 1"), [Addition 2](https://repl.it/@psygnisfive/TelescopicProofRefinement-Addition2 "Addition 2"), [Addition 3](https://repl.it/@psygnisfive/TelescopicProofRefinement-Addition3 "Addition 3"), [Lambda Calculus](https://repl.it/@psygnisfive/ProofRefinement-LambdaCalculus "Lambda Calculus").

Trong bài viết thứ ba trong loạt bài này ([Phần 1] (TMP // EN/Blog/Proof-Refinement-Basics/"Basical Refinement Basics, IOHK.IO"), [Phần 2] (TMP // EN/Blog/hai chiều -Prooof-Refinement/ "Tinh chỉnh bằng chứng hai chiều, IOHK.IO")) Khi sàng lọc bằng chứng, tôi sẽ chỉ cho bạn cách xử lý đúng chiều một cách thanh lịch. Kỹ thuật chúng tôi sẽ sử dụng là việc thay thế các danh sách và chức năng bằng cấu trúc dữ liệu gọi là kính viễn vọng. Bài đăng này sẽ sử dụng độc quyền Haskell, vì những hạn chế của JavaScript trong việc trình bày những điều này một cách thanh lịch. Tôi đã kết hợp với nhau [repl.it] (https://repl.it/ "repl.it") REPLS cho bài đăng trên blog này để bạn có thể phát xung quanh với mã. Bạn có thể tìm thấy chúng ở đây: [Bổ sung 1] (https://repl.it/@psygnisfive/telescopicproofrefinement-ddition1 "Bổ sung 1"), [Bổ sung 2] (https://repl.it/@psynisfive "Bổ sung 2"), [Bổ sung 3] (https://repl.it/@psygnisfive/telescopicplofrefinement-addition3 "Bổ sung 3"), [Tính toán Lambda] "Tính toán Lambda").

Consider the type that represented a successful decomposition of a problem judgment into subproblems, when working in the proof system for addition: ([Judgment], [Nat] -> Nat). The list of judgments represents the subproblems, and the function represents how to compute the result of the main problem from the results of the subproblems. This was problematic to generalize though, because it meant that all of the subproblems had to be independent. You couldn't use the result of solving an earlier subproblem to state what a later problem was. Information flowed strictly from subproblems out to main problems, never into other subproblems.

Hãy xem xét loại đại diện cho sự phân hủy thành công của một vấn đề phán đoán thành các vấn đề phụ, khi làm việc trong hệ thống chứng minh để thêm: ([phán đoán], [Nat] -> Nat).
Danh sách các phán đoán đại diện cho các vấn đề phụ và hàm đại diện cho cách tính kết quả của vấn đề chính từ kết quả của các vấn đề phụ.
Điều này có vấn đề để khái quát hóa, bởi vì nó có nghĩa là tất cả các vấn đề phụ phải độc lập.
Bạn không thể sử dụng kết quả của việc giải quyết vấn đề nhỏ trước đó để nêu rõ vấn đề sau này là gì.
Thông tin chảy nghiêm ngặt từ các bài toán con ra các vấn đề chính, không bao giờ vào các bài toán con khác.

This of course was because the subproblems were all given at the same time, and the results were all simultaneous arguments to the function that computed the main result. For instance, we might have a decomposition that looked like ([j0,j1,j2], f) where f = \[r0,r1,r2] -> ..., and we would solve these basically as f [solve j0, solve j1, solve j2]. What could we do to make it possible to have dependence of later problems are earlier results, though? Well, we could produce subproblems and consume results one at a time. In fact, instead of the above pair, why not have (j0, \r0 -> (j1, \r1 -> (r2, \r2 -> ...))). This has the type (Judgment, Nat -> (Judgment, Nat -> (Judgment, Nat -> Nat))), which is specific to the case where the list of subproblems has exactly three subproblems in it. This doesn't generalize well, but we can notice the obvious recursive pattern and instead define

Điều này tất nhiên là do các vấn đề phụ đều được đưa ra cùng một lúc và kết quả đều là những lập luận đồng thời cho hàm tính toán kết quả chính.
Chẳng hạn, chúng ta có thể có một sự phân hủy trông giống như ([J0, J1, J2], F) trong đó F = \ [R0, R1, R2] -> ..., và chúng ta sẽ giải quyết những điều này về cơ bản là F [giải J0
, giải J1, giải J2].
Chúng ta có thể làm gì để làm cho nó có thể có sự phụ thuộc của các vấn đề sau này là kết quả sớm hơn?
Vâng, chúng tôi có thể tạo ra các vấn đề phụ và tiêu thụ kết quả cùng một lúc.
Trong thực tế, thay vì cặp trên, tại sao không có (j0, \ r0 -> (j1, \ r1 -> (r2, \ r2 -> ...))).
Điều này có loại (Phán quyết, Nat -> (Phán quyết, Nat -> (Phán quyết, Nat -> Nat))), cụ thể cho trường hợp danh sách các bài toán con có chính xác ba vấn đề phụ trong đó.
Điều này không khái quát tốt, nhưng chúng ta có thể nhận thấy mô hình đệ quy rõ ràng và thay vào đó xác định

data Problems = Done Nat

vấn đề dữ liệu = xong NAT

`              `| SubProblem Judgment (Nat -> Problems)

`` |
Phán quyết phụ (NAT -> Các vấn đề)

Here, we're either done, and we have a resulting number, or we have a subproblem to solve, and a way of getting from the result of solving it to some more problems. Now of course, decomposing actually produced a Maybe ([Judgment], [Nat] -> Nat), so we really ought to define this type to account for the Nothing case as well:

Ở đây, chúng tôi đã hoàn thành và chúng tôi có một số kết quả, hoặc chúng tôi có một vấn đề phụ để giải quyết, và một cách nhận được từ kết quả của việc giải quyết nó đến một số vấn đề khác.
Bây giờ tất nhiên, việc phân hủy thực sự đã tạo ra một ([phán đoán], [nat] -> nat), vì vậy chúng tôi thực sự nên xác định loại này để giải thích cho trường hợp không có gì:

data Problems = Fail

vấn đề dữ liệu = không thành công

`              `| Done Nat

`` |
Xong Nat

`              `| SubProblem Judgment (Nat -> Problems)

`` |
Phán quyết phụ (NAT -> Các vấn đề)

Our decompositions now will look mostly the same, but slightly different:

Sự phân hủy của chúng tôi bây giờ sẽ trông chủ yếu giống nhau, nhưng hơi khác nhau:

decomposePlus12 :: Nat -> Nat -> Problems

decomposeplus12 :: nat -> nat -> các vấn đề

decomposePlus12 Zero    y = Done y

decomposeplus12 zero y = xong y

decomposePlus12 (Suc x) y = SubProblem (Plus12 x y) (\z -> Done (Suc z))

DEST

decomposePlus13 :: Nat -> Nat -> Problems

Decomposeplus13 :: Nat -> Nat -> Các vấn đề

decomposePlus13 Zero z = Done z

decomposeplus13 zero z = xong z

decomposePlus13 (Suc x) (Suc z) = SubProblem (Plus13 x z) (\z -> Done z)

DEST

decomposePlus13 \_ \_ = Fail

decomposeplus13 \ _ \ _ = FAIL

decompose :: Judgment -> Problems

Phá hủy :: Phán quyết -> Vấn đề

decompose (Plus12 x y) = decomposePlus12 x y

phân hủy (cộng 12 x y) = decomposeplus12 x y

decompose (Plus13 x z) = decomposePlus13 x z

phân hủy (plus13 x z) = decomposeplus13 x z

Finding a proof is pretty easy now too, because we can just define it in in terms of a second function that handles problems more generally. Dropping the reconstruction of a proof tree, we have:

Tìm một bằng chứng bây giờ cũng khá dễ dàng, bởi vì chúng tôi chỉ có thể xác định nó theo chức năng thứ hai xử lý các vấn đề nói chung hơn.
Bỏ việc tái thiết của một cây chứng minh, chúng tôi có:

findProof :: Judgment -> Maybe Nat

findproof :: phán xét -> có lẽ Nat

findProof j = solveProblems (decompose j)

Tìm bằng chứng I = giải quyết vấn đề (phân hủy J)

solveProblems :: Problems -> Maybe Nat

Giải quyết vấn đề :: Vấn đề -> Có thể Nat

solveProblems Fail = Nothing

giải quyết thất bại = không có gì

solveProblems (Done x) = return x

SolveProbols (xong x) = return x

solveProblems (SubProblem j f) =

SolveProbols (Subprobst

`  `do x <- findProof j

`` làm x <- findproof j

`     `solveProblems (f x)

`` SolveProbols (f x)

The interesting thing here is how we solve problems. If we fail, well, we've failed, so there's nothing to return. If we've finished, we've finished and so there's a number to return. But what if we have a subproblem? Well, we simply find a proof for it, computing the result as x, and then use the result of that to get more problems to solve, and solve those.

Điều thú vị ở đây là cách chúng tôi giải quyết vấn đề.
Nếu chúng tôi thất bại, tốt, chúng tôi đã thất bại, vì vậy không có gì để trở lại.
Nếu chúng tôi đã hoàn thành, chúng tôi đã hoàn thành và vì vậy có một số để trở lại.
Nhưng điều gì sẽ xảy ra nếu chúng ta có một vấn đề gì?
Chà, chúng tôi chỉ cần tìm một bằng chứng cho nó, tính toán kết quả là X, và sau đó sử dụng kết quả của điều đó để có nhiều vấn đề hơn để giải quyết và giải quyết chúng.

## **Generalizing**

## ** Chung **

Having established the general shape of this approach, we can now move on to generalizing the pattern involved. The first move we'll make is to observe that we might want to generalize the type of judgments to index for the type of their result. After all, we might also want to include predicates in the class of possible judgments, where there are no useful return values at all, just (). So we can generalize Judgment, and in term, Problems, like so:

Sau khi thiết lập hình dạng chung của phương pháp này, giờ đây chúng ta có thể chuyển sang khái quát hóa mô hình liên quan.
Động thái đầu tiên chúng ta sẽ thực hiện là quan sát rằng chúng ta có thể muốn khái quát loại phán đoán để lập chỉ mục cho loại kết quả của chúng.
Rốt cuộc, chúng tôi cũng có thể muốn đưa các vị từ trong lớp các phán đoán có thể xảy ra, trong đó không có giá trị trả lời hữu ích nào, chỉ ().
Vì vậy, chúng ta có thể khái quát hóa sự phán xét, và về thuật ngữ, các vấn đề, như vậy:

data Judgment r where

đánh giá dữ liệu r ở đâu

`  `Plus12 :: Nat -> Nat -> Judgment Nat

`` Plus12 :: Nat -> Nat -> Phán quyết Nat

`  `Plus13 :: Nat -> Nat -> Judgment Nat

`` Plus13 :: Nat -> Nat -> Phán quyết Nat

data Problems r where

vấn đề dữ liệu r ở đâu

`  `Fail :: Problems r

`` Thất bại :: vấn đề r

`  `Done :: r -> Problems r

`` Xong :: r -> Vấn đề r

`  `SubProblem :: Judgment s -> (s -> Problems r) -> Problems r

`` Subrobstem :: JUDGM

As soon as we do this, we discover that Problems looks an awful lot like a monad, and indeed, it is!

Ngay khi chúng tôi làm điều này, chúng tôi phát hiện ra rằng các vấn đề trông rất giống như một monad, và thực sự, nó là như vậy!

instance Functor Problems where

Các vấn đề về chức năng functor trong đó

`  `fmap f Fail = Fail

`` FMAP F FAIL = FAIL

`  `fmap f (Done x) = Done (f x)

`` FMAP F (Xong x) = DOME (F X)

`  `fmap f (SubProblem p g) = SubProblem p (fmap f . g)

`` FMAP F (Subprobol P g) = Subprobst

instance Applicative Problems where

Các vấn đề ứng dụng ở ví dụ trong đó

`  `pure = Done

`` tinh khiết = xong

`  `pf <\*> px = pf >>= \f -> px >>= \x -> return (f x)

`` pf <\*> px = pf >> = \ f -> px >> = \ x -> return (f x)

instance Monad Problems where

ví dụ các vấn đề về monad trong đó

`  `return = Done

`` return = xong

`  `Fail >>= g = Fail

`` FAIL >> = G = FAIL

`  `Done x >>= g = g x

`` Xong x >> = g = g x

`  `SubProblem p f >>= g = SubProblem p (\x -> f x >>= g)

`` Subprobstem p f >> = g = subprobol p (\ x -> f x >> = g)

This monad instance basically just codes up concatenation of problems. With lists of judgments, we can just concatenate them, but what to do with the functions that construct results? Here instead we say that if we have one sequence of problems that produces some result, and from that result, we can compute another sequence of problems, well we can just dig around in the first sequence and replace its Done node (which ends the sequence of problems with the result) by the problems we would get. We thus get a single big sequence of problems.

Ví dụ Monad này về cơ bản chỉ mã hóa các vấn đề.
Với danh sách các phán đoán, chúng ta chỉ có thể kết hợp chúng, nhưng phải làm gì với các chức năng xây dựng kết quả?
Thay vào đây, chúng tôi nói rằng nếu chúng tôi có một chuỗi các vấn đề tạo ra một số kết quả và từ kết quả đó, chúng tôi có thể tính toán một chuỗi vấn đề khác, chúng tôi chỉ có thể đào xung quanh trong chuỗi đầu tiên và thay thế nút đã thực hiện của nó (kết thúc chuỗi
về các vấn đề với kết quả) bởi các vấn đề chúng tôi sẽ nhận được.
Do đó, chúng tôi có được một chuỗi vấn đề lớn.

This monadic interfaces also gives us a really elegant way of writing these telescopes:

Các giao diện đơn độc này cũng cung cấp cho chúng ta một cách thực sự thanh lịch để viết những kính viễn vọng này:

subProblem :: Judgment r -> Problems r

Subprobst

subProblem j = SubProblem j (\x -> Done x)

Subprobst

decomposePlus12 :: Nat -> Nat -> Problems Nat

decomposeplus12 :: nat -> nat -> vấn đề nat

decomposePlus12 Zero    y = return y

decomposeplus12 zero y = return y

decomposePlus12 (Suc x) y =

decomposeplus12 (suc x) y =

`  `do z <- subProblem (Plus12 x y) 

`` Do Z <- SubProblem (Plus12 x y)

`     `return (Suc z)

`` Trả lại (Suc Z)

decomposePlus13 :: Nat -> Nat -> Problems Nat

decomposeplus13 :: nat -> nat -> vấn đề nat

decomposePlus13 Zero z = return z

decomposeplus13 zero z = return z

decomposePlus13 (Suc x) (Suc z) =

decomposeplus13 (suc x) (suc z) =

`  `subProblem (Plus13 x z)

`` Subroblem (Plus13 X Z)

decomposePlus13 \_ \_ = Fail

decomposeplus13 \ _ \ _ = FAIL

Let's add in a full ternary predicate version of our Plus to see how this works with other kinds of returned values:

Chúng ta hãy thêm vào một phiên bản vị ngữ ternary đầy đủ của Plus của chúng tôi để xem cách thức hoạt động với các loại giá trị được trả về khác:

data Judgment r where

đánh giá dữ liệu r ở đâu

`  `Plus12 :: Nat -> Nat -> Judgment Nat

`` Plus12 :: Nat -> Nat -> Phán quyết Nat

`  `Plus13 :: Nat -> Nat -> Judgment Nat

`` Plus13 :: Nat -> Nat -> Phán quyết Nat

`  `Plus123 :: Nat -> Nat -> Nat -> Judgment ()

`` Plus123 :: Nat -> Nat -> Nat -> JUDGN ()

decomposePlus123 :: Nat -> Nat -> Nat -> Problems ()

decomposeplus123 :: nat -> nat -> nat -> vấn đề ()

decomposePlus123 Zero y z =

decomposeplus123 zero y z =

`  `if y == z

`` Nếu y == z

`     `then return ()

`` Sau đó trở lại ()

`     `else Fail

`` khác thất bại

decomposePlus123 (Suc x) y (Suc z) =

DEST

`  `subProblem (Plus123 x y z)

`` Subroblem (plus123 x y z)

Readers who are especially familiar with functional programming idioms will observe that this is a variety of free monad construct, namely, the call-response tree variety.

Những người đọc đặc biệt quen thuộc với các thành ngữ lập trình chức năng sẽ quan sát rằng đây là một loạt các cấu trúc monad miễn phí, cụ thể là giống cây trả lời cuộc gọi.

And now, what parts of this really depend on the problem domain of addition? Well, clearly Judgment, because that defines what the problems are in the first place. And of course, as a result of that, the various decomposition functions. But not much else, provided we have some means of abstracting over those. Namely: the Problems type can be generalized away from Judgment, and findProof can be generalized away from the implementation of decompose, by way of a type class.

Và bây giờ, những phần nào của điều này thực sự phụ thuộc vào miền vấn đề bổ sung?
Vâng, rõ ràng đánh giá, bởi vì điều đó xác định những gì các vấn đề ở nơi đầu tiên.
Và tất nhiên, là kết quả của điều đó, các chức năng phân tách khác nhau.
Nhưng không nhiều thứ khác, miễn là chúng tôi có một số phương tiện trừu tượng hóa những điều đó.
Cụ thể: loại vấn đề có thể được khái quát hóa khỏi sự phán xét và tìm thấy có thể được khái quát từ việc thực hiện phân tách, bằng cách của một loại loại.

data Problems (j :: \* -> \*) (r :: \*) where

Các vấn đề về dữ liệu (j :: \* -> \*) (r :: \*) ở đâu

`  `Fail :: Problems j r

`` FAIL :: Vấn đề J R

`  `Done :: r -> Problems j r

`` Xong :: R -> Vấn đề J R

`  `SubProblem :: j s -> (s -> Problems j r) -> Problems j r

`` Subprobol :: j s -> (s -> vấn đề j r) -> vấn đề j r

subProblem :: j r -> Problems j r

Subprobst :: J R -> Vấn đề J R

subProblem j = SubProblem j (\x -> Done x)

Subprobst

class Decomposable j where

lớp phân hủy j ở đâu

`  `decompose :: j r -> Problems j r

`` Decompose :: J R -> Vấn đề J R

findProof :: Decomposable j => j r -> Maybe r

findproof :: có thể phân hủy j => j r -> có thể r r

findProof j = solveProblems (decompose j)

Tìm bằng chứng I = giải quyết vấn đề (phân hủy J)

solveProblems :: Decomposable j => Problems j r -> Maybe r

SolveProbols :: Decomposable J => Vấn đề J R -> Có thể r r

solveProblems Fail = Nothing

giải quyết thất bại = không có gì

solveProblems (Done x) = Just x

giải quyết vấn đề (xong x) = chỉ x

solveProblems (SubProblem j f) =

SolveProbols (Subprobst

`  `do x <- findProof j

`` làm x <- findproof j

`     `solveProblems (f x)

`` SolveProbols (f x)

Having abstracted this far, we now can extract this into a little library and use this for bidirectional proof systems in general. Let's now tackle the simply typed lambda calculus.

Đã trừu tượng hóa đến nay, bây giờ chúng ta có thể trích xuất điều này vào một thư viện nhỏ và sử dụng điều này cho các hệ thống chứng minh hai chiều nói chung.
Bây giờ chúng ta hãy giải quyết tính toán Lambda được gõ đơn giản.

## **Simply Typed LC**

## ** Đơn giản chỉ cần gõ lc **

Because we've extracted out the proof refinement toolkit, we need to only give definitions for the judgments and decomposition of our lambda calculus. This is a great simplification from the setting before. We can now express that type checking is a judgment that produces no interesting information, but that type synthesis will give us some type information:

Bởi vì chúng tôi đã trích xuất bộ công cụ sàng lọc bằng chứng, chúng tôi chỉ cần chỉ đưa ra các định nghĩa cho các phán đoán và phân tách tính toán Lambda của chúng tôi.
Đây là một đơn giản hóa tuyệt vời từ cài đặt trước đây.
Bây giờ chúng ta có thể thể hiện rằng kiểm tra loại là một phán đoán không tạo ra thông tin thú vị, nhưng tổng hợp loại đó sẽ cung cấp cho chúng ta một số thông tin loại:

data Judgment r where

đánh giá dữ liệu r ở đâu

`  `Check :: [(String,Type)] -> Program -> Type -> Judgment ()

`` Kiểm tra :: [(chuỗi, loại)] -> Chương trình -> Loại -> phán xét ()

`  `Synth :: [(String,Type)] -> Program -> Judgment Type

`` Synth :: [(chuỗi, loại)] -> Chương trình -> Loại phán đoán

Our decompositions are now more interesting as well, and hopefully a bit more insightful:

Sự phân hủy của chúng tôi bây giờ cũng thú vị hơn, và hy vọng một chút sâu sắc hơn:

decomposeCheck :: [(String,Type)] -> Program -> Type -> Problems Judgment ()

DECOMPOSECHECK :: [(chuỗi, loại)] -> Chương trình -> Loại -> Vấn đề phán đoán ()

decomposeCheck g (Pair m n) (Prod a b) =

DepoMposecheck g (cặp m n) (prod a b) =

`  `do subProblem (Check g m a)

`` Do Subrobstem (kiểm tra g m a)

`     `subProblem (Check g n b)

`` Subroblem (kiểm tra g n b)

decomposeCheck g (Lam x m) (Arr a b) =

Decomposecheck g (lam x m) (mảng a b) =

`  `subProblem (Check ((x,a):g) m b)

`` Subroblem (kiểm tra ((x, a): g) m b)

decomposeCheck g m a =

phân hủy g m a =

`  `do a2 <- subProblem (Synth g m)

`` Do A2 <- Subprobol (synth g m)

`     `if a == a2

`` Nếu a == A2

`        `then return ()

`` Sau đó trở lại ()

`        `else Fail

`` khác thất bại

decomposeSynth :: [(String,Type)] -> Program -> Problems Judgment Type

Phá hủy :: [(chuỗi, loại)] -> Chương trình -> Các vấn đề Loại phán đoán

decomposeSynth g (Var x) =

phân hủy g (var x) =

`  `case lookup x g of

`` Tra cứu trường hợp x g của

`    `Nothing -> Fail

`` Không có gì -> thất bại

`    `Just a -> return a

`` Chỉ là một -> trả về một

decomposeSynth g (Ann m a) =

phân hủy g (ann m a) =

`  `do subProblem (Check g m a)

`` Do Subrobstem (kiểm tra g m a)

`     `return a

`` Trả lại một

decomposeSynth g (Fst p) =

phân hủy g (fst p) =

`  `do t <- subProblem (Synth g p)

`` do t <- subprobol (synth g p)

`     `case t of

`` Trường hợp T của

`       `Prod a b -> return a

`` Prod a b -> return a

`       `\_ -> Fail

`` \ _ -> thất bại

decomposeSynth g (Snd p) =

phân hủy synth g (và p) =

`  `do t <- subProblem (Synth g p)

`` do t <- subprobol (synth g p)

`     `case t of

`` Trường hợp T của

`       `Prod a b -> return b

`` Prod a b -> return b

`       `\_ -> Fail

`` \ _ -> thất bại

decomposeSynth g (App f x) =

phân hủy g (Ứng dụng f x) =

`  `do t <- subProblem (Synth g f)

`` do t <- subprobol (synth g f)

`     `case t of

`` Trường hợp T của

`       `Arr a b ->

`` Mảng a b ->

`         `do subProblem (Check g x a)

`` Do Subrobstem (Kiểm tra G X A)

`            `return b

`` Trả lại B

`       `\_ -> Fail

`` \ _ -> thất bại

decomposeSynth g m = Fail

phân hủy g m = fail

instance Decomposable Judgment where

Phán quyết có thể phân hủy ở đâu

`  `decompose (Check g m a) = decomposeCheck g m a

`` phân hủy (kiểm tra g m a) = phân hủy g m a a a

`  `decompose (Synth g m) = decomposeSynth g m

`` phân hủy (synth g m) = phân hủy g m m m

And we're done! That is the full definition of the type checker for the simply typed lambda calculus with pairs and functions! It has the benefit of being fairly straightforward to read.

Và chúng tôi đã hoàn thành!
Đó là định nghĩa đầy đủ của trình kiểm tra loại cho phép tính Lambda được gõ đơn giản với các cặp và chức năng!
Nó có lợi ích là khá đơn giản để đọc.

## **Conclusion**

## **Sự kết luận**

This wraps up the series of blog posts on proof refinement. One limitation to this approach is that errors are uninformative, but we can actually modify this toolkit to provide not just informative errors (**Either** instead of **Maybe**), but highly informative context-aware errors that know what subproblems are being worked on. Another limitation is that the above toolkit only works for when there is at most one result from the bottom-up direction. That is to say, either a judgment has no proofs, and so there's no bottom-up result, or it has exactly one proof and thus one bottom-up result. But we might have multiple such results, for instance, we might have instead built a system for addition that has the first two arguments of **Plus** as the bottom-up results (i.e. solutions for Plus3 c), and we'd like to be able to get out all pairs (x,y) such that x + y = c for fixed c. There are plenty of those pairs, so we had better be able to get some kind of list-like results. We also might imagine some other kind of system where in the course of constructing a proof we need to invent something out of thin air, such as a new name for a variable. In that kind of setting we'd like to have a proof system that could make use of some state for the collection of generated names. I'll look at both of these limitations in future blog posts.

Điều này kết thúc một loạt các bài đăng trên blog về sàng lọc bằng chứng. Một hạn chế đối với phương pháp này là các lỗi không chính xác, nhưng chúng tôi thực sự có thể sửa đổi bộ công cụ này để cung cấp không chỉ các lỗi thông tin (** ** thay vì ** có thể đang được làm việc trên. Một giới hạn khác là bộ công cụ trên chỉ hoạt động khi có nhiều nhất một kết quả từ hướng từ dưới lên. Điều đó có nghĩa là, một bản án không có bằng chứng, và do đó không có kết quả từ dưới lên, hoặc nó có chính xác một bằng chứng và do đó một kết quả từ dưới lên. Nhưng chúng ta có thể có nhiều kết quả như vậy, ví dụ, thay vào đó chúng ta có thể đã xây dựng một hệ thống để bổ sung có hai đối số đầu tiên của ** cộng ** làm kết quả từ dưới lên (tức là các giải pháp cho plus3 c) và chúng ta sẽ giống như có thể thoát ra tất cả các cặp (x, y) sao cho x + y = c cho cố định c. Có rất nhiều cặp đó, vì vậy chúng tôi tốt hơn có thể có được một số loại kết quả giống như danh sách. Chúng tôi cũng có thể tưởng tượng một số loại hệ thống khác trong quá trình xây dựng một bằng chứng chúng tôi cần phát minh ra một cái gì đó ngoài không khí mỏng, chẳng hạn như một tên mới cho một biến. Trong loại cài đặt đó, chúng tôi muốn có một hệ thống bằng chứng có thể sử dụng một số trạng thái cho việc thu thập các tên được tạo. Tôi sẽ xem xét cả hai hạn chế này trong các bài đăng trên blog trong tương lai.

If you have comments or questions, get it touch. I'm [@psygnisfive](https://twitter.com/psygnisfive "Darryl McAdams, Twitter") on Twitter, augur on freenode (in #cardano and #haskell).

Nếu bạn có ý kiến hoặc câu hỏi, hãy chạm vào nó.
Tôi [@psygnisfive] (https://twitter.com/psygnisfive "Darryl McAdams, Twitter") trên Twitter, Augur trên Freenode (trong #Cardano và #Haskell).

*This post is the third part of a three part series, the first post is [Proof Refinement Basics](tmp//en/blog/proof-refinement-basics/ "Proof Refinement Basics, iohk.io"), and the second post is [Bidirectional Proof Refinement](tmp//en/blog/bidirectional-proof-refinement/ "Bidirectional Proof Refinement, iohk.io").*

*Bài đăng này là phần thứ ba của chuỗi ba phần, bài viết đầu tiên là [Khái niệm cơ bản về tinh chỉnh bằng chứng] (TMP // EN/Blog/Proof-Refinement-Basics/"Khái niệm về sàng lọc bằng chứng, iohk.io") và phần thứ hai
Bài đăng là [sàng lọc bằng chứng hai chiều] (TMP // EN/Blog/Bid-Proof-Profinement/"Tinh chỉnh bằng chứng hai chiều, IOHK.IO").*

## **Attachments**

## ** tệp đính kèm **

![](img/2018-01-02-telescopic-proof-refinement.004.png)[ Telescopic Proof Refinement - Input Output](https://ucarecdn.com/e9b6cb0a-339d-4286-8960-98f98614cfcf/-/inline/yes/ "Telescopic Proof Refinement - Input Output")

