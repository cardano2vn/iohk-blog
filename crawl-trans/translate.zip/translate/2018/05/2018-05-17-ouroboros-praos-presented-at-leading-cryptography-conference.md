# Ouroboros Praos presented at leading cryptography conference, Eurocrypt
### **Proof-of-stake protocol offers same security guarantees as Bitcoin**
![](img/2018-05-17-ouroboros-praos-presented-at-leading-cryptography-conference.002.png) 17 May 2018![](img/2018-05-17-ouroboros-praos-presented-at-leading-cryptography-conference.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2018-05-17-ouroboros-praos-presented-at-leading-cryptography-conference.003.png) 4 mins read

![Jane Wild](img/2018-05-17-ouroboros-praos-presented-at-leading-cryptography-conference.004.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2018-05-17-ouroboros-praos-presented-at-leading-cryptography-conference.005.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2018-05-17-ouroboros-praos-presented-at-leading-cryptography-conference.006.png)[](https://twitter.com/jane_wild_ "Twitter")

In the area of blockchain research proof of stake has long posed many questions for cryptographers and the subject has been of primary importance for IOHK researchers over the past two years. [Professor Aggelos Kiayias](tmp//en/team/aggelos-kiayias/ "Aggelos Kiayias, iohk.io"), Chief Scientist at IOHK, has led work with a team of cryptographers to formalise a family of protocols called [Ouroboros](tmp//en/research/papers/#9BKRHCSI "Ouroboros, iohk.io"). It is a great distinction for their efforts that their paper describing the protocol was accepted to [Crypto 2017](tmp//en/blog/ouroboros-at-crypto-2017/ "Ouroboros at Crypto 2017, iohk.io"), the foremost cryptographic event, and another paper was heard this month at sister event Eurocrypt. [Eurocrypt](https://eurocrypt.iacr.org/2018/ "eurocrypt.iacr.org") is the flagship European conference of the main international community of cryptographers, the International Association for Cryptologic Research. About 370 delegates from countries worldwide arrived in Tel Aviv, Israel, to hear cutting edge research being presented from across the spectrum of cryptography. In all, there were about 70 presentations across four days.

Trong lĩnh vực nghiên cứu blockchain bằng chứng về cổ phần từ lâu đã đặt ra nhiều câu hỏi cho các nhà mật mã và chủ đề này có tầm quan trọng hàng đầu đối với các nhà nghiên cứu IOHK trong hai năm qua. [Giáo sư Aggelos Kiayias] (TMP // EN/Team/Aggelos-Kiayias/"Aggelos Kiayias, IOHK.IO"), nhà khoa học trưởng tại IOHK, đã lãnh đạo công việc với một nhóm mật mã để chính thức hóa một gia đình của các giao thức được gọi là [Opoboros] (TMP // EN/Nghiên cứu/Giấy tờ/#9BKRHCSI " Đó là một sự khác biệt lớn cho những nỗ lực của họ rằng bài báo của họ mô tả giao thức đã được chấp nhận cho [Crypto 2017] (TMP // EN/Blog/OuroBoros-AT-Crypto-2017/"OuroBoros tại Crypto 2017, IOHK.IO") Sự kiện mật mã hàng đầu, và một bài báo khác đã được nghe trong tháng này tại sự kiện chị em Eurocrypt. [Eurocrypt] (https://eurocrypt.iacr.org/2018/ "Eurocrypt.iacr.org") là hội nghị hàng đầu châu Âu của cộng đồng mật mã quốc tế chính, Hiệp hội nghiên cứu mật mã quốc tế. Khoảng 370 đại biểu từ các quốc gia trên toàn thế giới đã đến Tel Aviv, Israel, để nghe nghiên cứu tiên tiến được trình bày từ khắp các phổ của mật mã. Trong tất cả, có khoảng 70 bài thuyết trình trong bốn ngày.

This year, blockchain was more prominent than it had ever been at Eurocrypt. There were four papers presented during a dedicated blockchain morning session on the second day. The following day there was a talk on the 30-year history of cryptocurrencies, given by [Matthew Green](https://isi.jhu.edu/~mgreen/ "Matthew Green, isi.jhu.edu"), a cryptographer at Johns Hopkins Information Security Institute. Three best papers were selected for an award at Eurocrypt, and one of them was on blockchain, [Simple Proofs of Sequential Work](https://eprint.iacr.org/2018/183 "Simple Proofs of Sequential Work, eprint.iacr.org") by Bram Cohen and Krzysztof Pietrzak. 

Năm nay, Blockchain nổi bật hơn bao giờ hết tại Eurocrypt.
Có bốn bài báo được trình bày trong một phiên buổi sáng blockchain chuyên dụng vào ngày thứ hai.
Ngày hôm sau đã có một cuộc nói chuyện về lịch sử 30 năm của tiền điện tử, được đưa ra bởi [Matthew Green] (https://isi.jhu.edu/~mgreen/ "Matthew Green, isi.jhu.edu")
tại Viện bảo mật thông tin Johns Hopkins.
Ba bài báo hay nhất đã được chọn cho một giải thưởng tại Eurocrypt, và một trong số đó là trên blockchain, [bằng chứng đơn giản về công việc tuần tự] (https://eprint.iacr.org/2018/183 "Bằng chứng đơn giản về công việc tuần tự, eprint.iacr
.org ") của Bram Cohen và Krzysztof Pietrzak.

Academic interest in the area has nowhere near matched the rapid proliferation of blockchain projects during the past few years, and the increased focus of cryptographers at events like Eurocrypt brings a welcome professionalisation to the industry.

Mối quan tâm học tập trong khu vực không có nơi nào phù hợp với sự phổ biến nhanh chóng của các dự án blockchain trong vài năm qua, và sự tập trung tăng lên của các nhà mật mã học tại các sự kiện như Eurocrypt mang đến sự chuyên nghiệp hóa được chào đón cho ngành công nghiệp.

To be heard at the conference, papers must be submitted for consideration in a process called peer review. This notoriously tough sifting process can typically involve three or four people reviewing the paper, and it passing a programme committee of three dozen or more people, to ensure it makes a novel contribution to the scientific literature that advances computer science. Most papers are rejected. A double-blind admission procedure where both authors and reviewers are anonymous adds objectivity.

Để được nghe tại hội nghị, các giấy tờ phải được gửi để xem xét trong một quy trình gọi là đánh giá ngang hàng.
Quá trình sàng lọc khét tiếng này thường có thể liên quan đến ba hoặc bốn người xem xét bài báo, và nó thông qua một ủy ban chương trình gồm ba chục người trở lên, để đảm bảo nó đóng góp mới cho tài liệu khoa học thúc đẩy khoa học máy tính.
Hầu hết các giấy tờ bị từ chối.
Một thủ tục nhập học mù đôi trong đó cả tác giả và người đánh giá đều ẩn danh thêm tính khách quan.

The novel feature of [Ouroboros Praos](tmp//en/research/papers/#XJ6MHFXX "Ouroboros Praos, iohk.io") is that it is the first proof-of-stake blockchain to be able to scale for widespread use and provide security against adaptive attackers. These are attackers that can instantly corrupt protocol participants, and the only restriction is that only a minority of the total stake can be in corrupted hands. A Distributed Denial of Service (DDoS) attack is a real-world example of such an instant attack.

Tính năng mới của [Ouroboros PRAOS] (TMP // EN/Nghiên cứu/Giấy tờ/#XJ6MHFXX "
Cung cấp bảo mật chống lại những kẻ tấn công thích ứng.
Đây là những kẻ tấn công có thể tham nhũng ngay lập tức những người tham gia giao thức và hạn chế duy nhất là chỉ có một số ít trong tổng số cổ phần có thể nằm trong tay bị hỏng.
Một cuộc tấn công từ chối dịch vụ phân tán (DDoS) là một ví dụ trong thế giới thực về một cuộc tấn công tức thời như vậy.

Ouroboros Praos offers the same security guarantees as Bitcoin in that it can withstand attacks from stronger adversaries in harsh network conditions, such as where an attacker has some control over network delays affecting messages sent by all participants. 

Ouroboros PRAOS cung cấp các đảm bảo bảo mật tương tự như Bitcoin ở chỗ nó có thể chịu được các cuộc tấn công từ các đối thủ mạnh hơn trong các điều kiện mạng khắc nghiệt, chẳng hạn như nơi kẻ tấn công có một số quyền kiểm soát sự chậm trễ mạng ảnh hưởng đến tin nhắn được gửi bởi tất cả người tham gia.

No other proof-of-stake protocol that has been peer reviewed at this level can provably offer this level of security guarantee under these conditions.

Không có giao thức chứng minh cổ phần nào khác đã được xem xét ngang hàng ở cấp độ này có thể cung cấp mức độ bảo đảm bảo mật này trong các điều kiện này.

[Peter GaÅ¾i](tmp//en/team/peter-gazi/ "Peter GaÅ¾i, iohk.io"), who presented: â€œEurocrypt is one of the premier venues for presenting cryptoglogic research and itâ€™s an honour for us to present our work here. The fact that we were invited serves as evidence the broader academic community is showing more interest in this topic.â€

.
Chúng tôi trình bày công việc của chúng tôi ở đây.
Thực tế là chúng tôi được mời đóng vai trò là bằng chứng mà cộng đồng học thuật rộng lớn đang thể hiện sự quan tâm nhiều hơn đến chủ đề này.

Aside from Peter and Aggelos, the other researchers on the Ouroboros team are [Bernardo David](tmp//en/team/bernardo-david/ "Bernardo David, iohk.io"), Alexander Russell, [Roman Oliynykov](tmp//en/team/roman-oliynykov/ "Roman Oliynykov, iohk.io"), Christian Badertscher, and [Vassilis Zikas](tmp//en/team/vassilis-zikas "Vassilis Zikas, iohk.io"). The previous Ouroboros paper, first in this line of research, is the first proof-of-stake protocol to be provably secure and peer reviewed at a leading cryptographic event. Ouroboros has a real-world implementation in [Cardano](https://www.cardano.org/en/home/ "cardano.org"), the top 10 cryptocurrency built by IOHK.

Ngoài Peter và Aggelos, các nhà nghiên cứu khác trong nhóm Ouroboros là [Bernardo David] (TMP // EN/Team/Bernardo-David/"Bernardo David, Iohk.io"), Alexander Russell, [Roman Oliynykov] (TMP/
.
Bài viết trước đây của Ouroboros, đầu tiên trong dòng nghiên cứu này, là giao thức chứng minh đầu tiên được bảo mật và được xem xét ngang hàng tại một sự kiện mật mã hàng đầu.
Ouroboros có một triển khai trong thế giới thực ở [Cardano] (https://www.cardano.org/en/home/ "cardano.org"), 10 loại tiền điện tử hàng đầu được xây dựng bởi IOHK.

