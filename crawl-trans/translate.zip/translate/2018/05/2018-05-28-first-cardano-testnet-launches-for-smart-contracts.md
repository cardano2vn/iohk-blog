# First Cardano smart contracts testnet launches
### **KEVM software supports applications that run on Ethereum Virtual Machine**
![](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.002.png) 28 May 2018![](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.002.png)[ Gerard Moroney](tmp//en/blog/authors/gerard-moroney/page-1/)![](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.003.png) 3 mins read

![Gerard Moroney](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.004.png)[](tmp//en/blog/authors/gerard-moroney/page-1/)
### [**Gerard Moroney**](tmp//en/blog/authors/gerard-moroney/page-1/)
Chief Operating Officer

Operations

- ![](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.005.png)[](mailto:gerard.moroney@iohk.io "Email")
- ![](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.006.png)[](https://ie.linkedin.com/in/gmoroney "LinkedIn")
- ![](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.007.png)[](https://twitter.com/gmanroney "Twitter")
- ![](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.008.png)[](https://github.com/gmanroney "GitHub")

The first Cardano smart contracts testnet [launches today](https://testnet.iohkdev.io/goguen/ "https://testnet.iohkdev.io/goguen/"), the KEVM testnet, a correct by construction version of the Ethereum Virtual Machine (EVM) specified in the K framework. This technology, produced by Runtime Verification with the support of IOHK, is the first time that a complete formal semantics of the EVM have been produced. This is an important first in cryptocurrency that is a necessary step towards the promise of third-generation blockchains. A smart contract allows you to exchange something of value - money, property, shares - by means of a software protocol. The terms of exchange are agreed upon by the parties involved in the same way as a traditional contract, and the contract is executed automatically on the blockchain.

Testnet hợp đồng thông minh Cardano đầu tiên [ra mắt hôm nay] (https://testnet.iohkdev.io/goguen/ "https://testnet.iohkdev.io/goguen/")
Máy ảo Ethereum (EVM) được chỉ định trong khung K.
Công nghệ này, được sản xuất bằng cách xác minh thời gian chạy với sự hỗ trợ của IOHK, là lần đầu tiên một ngữ nghĩa chính thức hoàn chỉnh của EVM đã được sản xuất.
Đây là một điều quan trọng đầu tiên trong tiền điện tử là một bước cần thiết để hứa hẹn về các blockchain thế hệ thứ ba.
Hợp đồng thông minh cho phép bạn trao đổi một cái gì đó có giá trị - tiền, tài sản, cổ phiếu - bằng giao thức phần mềm.
Các điều khoản trao đổi được các bên liên quan đồng ý theo cách tương tự như một hợp đồng truyền thống và hợp đồng được thực hiện tự động trên blockchain.

Developers will be able to take any application that runs on the EVM and execute it on the KEVM, which can also be used to rigorously prove that smart contracts work correctly. This is done by formally specifying a contract's desired properties in K, combining the contract with the KEVM specification, and then using the K framework to verify those properties.

Các nhà phát triển sẽ có thể thực hiện bất kỳ ứng dụng nào chạy trên EVM và thực hiện nó trên KEVM, điều này cũng có thể được sử dụng để chứng minh nghiêm ngặt rằng các hợp đồng thông minh hoạt động chính xác.
Điều này được thực hiện bằng cách chính thức chỉ định các thuộc tính mong muốn của hợp đồng trong K, kết hợp hợp đồng với đặc tả KEVM và sau đó sử dụng khung K để xác minh các thuộc tính đó.

Our second Cardano testnet to launch will be IELE, which is a new virtual machine for Cardano. IELE will be launched in July and is a register-based virtual machine similar to LLVM with an unbounded number of registers, that supports unbounded integers. With IELE, developers can write, compile and execute smart contracts, with improved security and performance compared to the KEVM testnet.

Cardano testnet thứ hai của chúng tôi sẽ ra mắt sẽ là IELE, đây là một máy ảo mới cho Cardano.
IELE sẽ được ra mắt vào tháng 7 và là một máy ảo dựa trên đăng ký tương tự như LLVM với số lượng thanh ghi không giới hạn, hỗ trợ các số nguyên không giới hạn.
Với IELE, các nhà phát triển có thể viết, biên dịch và thực hiện các hợp đồng thông minh, với bảo mật và hiệu suất được cải thiện so với Kevm Testnet.

For now, we recommend that developers use the Solidity language on both testnets. However, the vision is that eventually smart contracts will be written in high-level languages that translate to IELE, such as new languages like Plutus ([being developed by IOHK](https://youtu.be/YMkFBw9F4rI?t=34m17s "IOHK Developers meetup for Cardano, University College London, youtube.com")), but also existing languages such as Java or Python, and then IELE-to-IELE translators ensure the resulting code is optimal.

Hiện tại, chúng tôi khuyên các nhà phát triển nên sử dụng ngôn ngữ vững chắc trên cả hai bài kiểm tra.
Tuy nhiên, tầm nhìn là cuối cùng các hợp đồng thông minh sẽ được viết bằng các ngôn ngữ cấp cao chuyển thành IELE, chẳng hạn như các ngôn ngữ mới như Plutus ([được phát triển bởi IOHK] (https://youtu.be/ymkfbw9f4RI?t=34M17S "
Các nhà phát triển IOHK gặp gỡ Cardano, Đại học College London, YouTube.com ")), nhưng cũng có các ngôn ngữ hiện có như Java hoặc Python, và sau đó các dịch giả IELE-TO-IELE đảm bảo mã kết quả là tối ưu.

![Cardano Testnets Website](img/2018-05-28-first-cardano-testnet-launches-for-smart-contracts.009.png) Cardano Testnets Website

K was developed by Runtime Verification in collaboration with Professor Grigore Rosu's Formal Systems Laboratory at the University of Illinois at Urbana-Champaign during the past 15 years, and incorporates the state of the art in language design, semantics and formal methods. Read more about the K framework [in this blog](https://runtimeverification.com/blog/k-framework-an-overview/ "Runtime Verification blog") from Prof Rosu, founder of Runtime Verification. A blog about formal verification and what this means for smart contracts will follow soon.

K được phát triển bằng cách xác minh thời gian chạy phối hợp với Phòng thí nghiệm Hệ thống chính thức của Giáo sư Rosu tại Đại học Illinois tại Urbana-Champaign trong suốt 15 năm qua, và kết hợp trạng thái nghệ thuật trong thiết kế ngôn ngữ, ngữ nghĩa và phương pháp chính thức.
Đọc thêm về khung K [trong blog này] (https://runtimeverification.com/blog/k-framework-an-overview/ "Blog xác minh thời gian chạy") từ Giáo sư Rosu, người sáng lập Xác minh thời gian chạy.
Một blog về xác minh chính thức và điều này có nghĩa là gì cho các hợp đồng thông minh sẽ sớm theo sau.

Smart contracts must be formally verified, so they run exactly as specified and are free from bugs or flaws. Only then can they be widely adopted as financial infrastructure that can be relied upon by billions of people.

Hợp đồng thông minh phải được xác minh chính thức, vì vậy chúng chạy chính xác như được chỉ định và không có lỗi hoặc lỗ hổng.
Chỉ sau đó, họ mới có thể được áp dụng rộng rãi như cơ sở hạ tầng tài chính có thể được dựa vào hàng tỷ người.

We look forward to receiving your valuable feedback about using the testnets which will help us make Cardano best in class.

Chúng tôi mong muốn nhận được phản hồi có giá trị của bạn về việc sử dụng TestNets sẽ giúp chúng tôi làm cho Cardano tốt nhất trong lớp.

