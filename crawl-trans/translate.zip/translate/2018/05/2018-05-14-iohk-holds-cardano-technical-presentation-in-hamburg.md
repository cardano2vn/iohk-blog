# A Cardano technical talk in Hamburg
### **Philipp Kant and Lars Brünjes explain incentives, stake pools and formal methods**
![](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.002.png) 14 May 2018![](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.003.png) 8 mins read

![Jane Wild](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.004.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.005.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.006.png)[](https://twitter.com/jane_wild_ "Twitter")

Cardano is a project that is unique in its vision, scope and design, and its world-class team is working at the frontier of computer science. As development progresses we're contacted on a daily basis by people from all around the world who want to learn more, and so IOHK was pleased to make its first trip to Germany recently to talk about Cardano. [Dr Lars Brünjes](tmp//en/team/lars-brunjes/ "Lars Brünjes, iohk.io") and [Dr Philipp Kant](tmp//en/team/philipp-kant/ "Philipp Kant, iohk.io") are senior members of the Cardano team and they were invited to the monthly Hamburg meetup Blockchain Mania last month to give a technical talk. Lars is Director of Education at IOHK and leads work on incentives, a key part of Cardano, while Philipp is Director of Formal Methods, the robust development approach that is the gold standard for IOHK development.

Cardano là một dự án độc đáo trong tầm nhìn, phạm vi và thiết kế của nó, và nhóm đẳng cấp thế giới của nó đang làm việc tại biên giới của khoa học máy tính.
Khi sự phát triển tiến triển, chúng tôi liên hệ hàng ngày bởi những người từ khắp nơi trên thế giới muốn tìm hiểu thêm, và vì vậy IOHK rất vui khi thực hiện chuyến đi đầu tiên đến Đức gần đây để nói về Cardano.
.
IO ") là thành viên cao cấp của nhóm Cardano và họ đã được mời tham dự Hamburg Meetup Blockchain Mania hàng tháng vào tháng trước để nói chuyện kỹ thuật.
Lars là Giám đốc Giáo dục tại IOHK và lãnh đạo các ưu đãi, một phần quan trọng của Cardano, trong khi Philipp là giám đốc phương pháp chính thức, phương pháp phát triển mạnh mẽ là tiêu chuẩn vàng cho sự phát triển của IOHK.

In the year since this Hamburg meetup launched its audience numbers have blossomed from 20 to well over 100 under the direction of founders Omri Erez, an android developer by background who now has a blockchain startup, and Kiriakos Krastillis, who is Head of Software Engineering at PwC Digispace in Hamburg. The crowd was keen and knowledgeable, including entrepreneurs and developers (and some Haskellers). They wanted a deep dive into technical aspects of Cardano, with a Q&A after each presentation.

Trong năm kể từ khi cuộc gặp gỡ Hamburg này ra mắt số lượng khán giả của mình đã nở rộ từ 20 đến hơn 100 dưới sự chỉ đạo của những người sáng lập Omri Erez, một nhà phát triển Android bằng nền tảng hiện đang có một công ty khởi nghiệp blockchain và Kiriakos Krastillis, người đứng đầu kỹ thuật phần mềm tại
PWC Digispace ở Hamburg.
Đám đông rất quan tâm và hiểu biết, bao gồm cả các doanh nhân và nhà phát triển (và một số haskeller).
Họ muốn đi sâu vào các khía cạnh kỹ thuật của Cardano, với một câu hỏi và trả lời sau mỗi bài thuyết trình.

Philipp took the audience through an introduction to Cardano, highlighting a few of the key features in development. [Plutus](https://github.com/input-output-hk/plutus-prototype "Plutus Prototype. github.com") and the [IELE Virtual Machine](https://github.com/runtimeverification/iele-semantics "IELE Semantics, github.com") are essential components of smart contracts, while sidechains will help the system scale. A treasury will secure future development by giving users a mechanism to decide upon and pay for changes. At the heart of Cardano is [Ouroboros](tmp//en/research/papers/#9BKRHCSI "Ouroboros: A Provably Secure Proof-of-Stake Blockchain Protocol, iohk.io"), the algorithm that underpins the Ada cryptocurrency. Developed by a team of researchers led by [Professor Aggelos Kiayias](tmp//en/team/aggelos-kiayias/ "Aggelos Kiayias, iohk.io") of the University of Edinburgh, Ouroboros is the first proof-of-stake algorithm to be provably secure and was accepted to the leading cryptography conference, Crypto 2017. It is an efficient alternative to the energy-intensive proof-of-work protocol that underpins Bitcoin.

Philipp đã đưa khán giả giới thiệu về Cardano, làm nổi bật một vài tính năng chính trong phát triển. . Semantics "IELE Semantics, github.com") là những thành phần thiết yếu của hợp đồng thông minh, trong khi sidechains sẽ giúp hệ thống mở rộng quy mô. Kho bạc sẽ đảm bảo sự phát triển trong tương lai bằng cách cung cấp cho người dùng một cơ chế để quyết định và trả tiền cho các thay đổi. Trọng tâm của Cardano là [Ouroboros] (TMP // EN/Nghiên cứu/Giấy tờ/#9BKRHCSI " Được phát triển bởi một nhóm các nhà nghiên cứu do [Giáo sư Aggelos Kiayias] (TMP // EN/Team/Aggelos-Kiayias/"Aggelos Kiayias, iohk.io") của Đại học Edinburgh, OuroBoros là thuật toán đầu tiên của Đại học Edinburgh, là thuật toán chứng minh đầu tiên bằng chứng cổ phần đầu tiên Để được an toàn và được chấp nhận vào hội nghị mật mã hàng đầu, Crypto 2017. Đây là một sự thay thế hiệu quả cho giao thức làm việc sử dụng nhiều năng lượng, làm nền tảng cho Bitcoin.

Producing excellent research is the first objective. The next is to take that cryptographic research, which is expressed in academic language, mathematical formulae and proofs, and turn it into another language – Haskell code that a computer can understand. Additionally, the research papers will not account for factors that arise during real-world operation, issues relating to databases or networking for example.

Sản xuất nghiên cứu tuyệt vời là mục tiêu đầu tiên.
Tiếp theo là thực hiện nghiên cứu mật mã đó, được thể hiện bằng ngôn ngữ học thuật, công thức toán học và bằng chứng, và biến nó thành một ngôn ngữ khác - mã Haskell mà máy tính có thể hiểu.
Ngoài ra, các tài liệu nghiên cứu sẽ không tính đến các yếu tố phát sinh trong hoạt động trong thế giới thực, các vấn đề liên quan đến cơ sở dữ liệu hoặc mạng chẳng hạn.

Turning the papers into machine-executable code is a lengthy and precise process, and one it is highly desirable to conduct carefully. IOHK is adopting formal methods in its development process to create software that is robust and reliable. This is an approach used in areas such as medicine and aerospace, where improperly implemented code could result in casualties. In the area of cryptocurrency, we've repeatedly seen flaws in code exploited and losses in the hundreds of millions of dollars.

Biến các giấy tờ thành mã có thể thực hiện bằng máy là một quá trình dài và chính xác, và một quy trình rất mong muốn được tiến hành cẩn thận.
IOHK đang áp dụng các phương pháp chính thức trong quá trình phát triển của mình để tạo ra phần mềm mạnh mẽ và đáng tin cậy.
Đây là một cách tiếp cận được sử dụng trong các lĩnh vực như y học và hàng không vũ trụ, trong đó mã được thực hiện không đúng cách có thể dẫn đến thương vong.
Trong lĩnh vực tiền điện tử, chúng tôi đã nhiều lần nhìn thấy những sai sót trong mã bị khai thác và tổn thất trong hàng trăm triệu đô la.

The process of moving from paper to code is done in a series of small steps, rather than any big leap, Philipp explained. 

Quá trình chuyển từ giấy sang mã được thực hiện trong một loạt các bước nhỏ, thay vì bất kỳ bước nhảy vọt lớn nào, Philipp giải thích.

The first step is transcribing the paper into an executable specification, and further steps refine this specification, adding all the necessary details.

Bước đầu tiên là sao chép bài báo thành một đặc điểm kỹ thuật thực thi và các bước tiếp theo tinh chỉnh thông số kỹ thuật này, thêm tất cả các chi tiết cần thiết.

Attention is paid to each design decision, and each step can be tested to make sure the code is correct. IOHK does this by using psi calculus. This is a family of process calculi that is a toolbox we are using to formulate Ouroboros Praos. We can embed psi calculus into Haskell, which allows us to run simulations and export code to a proof assistant such as Coq or Isabelle so proofs can be checked.

Chú ý được trả cho mỗi quyết định thiết kế và mỗi bước có thể được kiểm tra để đảm bảo mã là chính xác.
IOHK thực hiện điều này bằng cách sử dụng tính toán PSI.
Đây là một gia đình tính toán quy trình là một hộp công cụ mà chúng tôi đang sử dụng để xây dựng Ouroboros Praos.
Chúng tôi có thể nhúng phép tính PSI vào Haskell, cho phép chúng tôi chạy mô phỏng và xuất mã sang một trợ lý chứng minh như Coq hoặc Isabelle để có thể kiểm tra bằng chứng.

It is important that we have a good handle on the performance of the system. Before the launch of Cardano, Philipp oversaw benchmarking, tuning the parameters of the system to ensure it could perform well under various conditions. While this process is helpful to ensure the system is set up in a way that ensures stable operation, it is preferable to have a method for predicting the performance early on.

Điều quan trọng là chúng tôi có một xử lý tốt về hiệu suất của hệ thống.
Trước khi ra mắt Cardano, Philipp giám sát điểm chuẩn, điều chỉnh các tham số của hệ thống để đảm bảo nó có thể hoạt động tốt trong các điều kiện khác nhau.
Mặc dù quá trình này là hữu ích để đảm bảo hệ thống được thiết lập theo cách đảm bảo hoạt động ổn định, nhưng tốt nhất là có một phương pháp để dự đoán hiệu suất sớm.

To achieve this, we use the Delta Q formalism, where each atomic operation carries is assigned a probability distribution for delay and failure. Those can be combined, either through simulation, or algebraically, to determine the expected overall performance of the system. Adding Delta Q annotations to the executable specification right at the start of the development process will show performance impacts of design decisions, and also provide a baseline for the benchmarks: instead of just measuring the performance, and trying optimisations to improve it, we can compare the results of benchmarks against a prediction, and tell whether we have a performance bug. If we additionally measure the Delta Q of individual parts of the program, we can even see which parts behave unexpectedly and should be optimised.

Để đạt được điều này, chúng tôi sử dụng chủ nghĩa hình thức Delta Q, trong đó mỗi hoạt động nguyên tử được thực hiện được chỉ định phân phối xác suất cho sự chậm trễ và thất bại.
Chúng có thể được kết hợp, thông qua mô phỏng, hoặc đại số, để xác định hiệu suất tổng thể dự kiến của hệ thống.
Thêm các chú thích Delta Q vào đặc tả thực thi ngay khi bắt đầu quá trình phát triển sẽ cho thấy các tác động hiệu suất của các quyết định thiết kế và cũng cung cấp một đường cơ sở cho các điểm chuẩn: thay vì chỉ đo lường hiệu suất và thử tối ưu hóa để cải thiện nó, chúng ta có thể so sánh
Kết quả của điểm chuẩn so với dự đoán và cho biết liệu chúng tôi có lỗi hiệu suất hay không.
Nếu chúng ta đo thêm Delta Q của các phần riêng lẻ của chương trình, chúng ta thậm chí có thể thấy phần nào hoạt động bất ngờ và nên được tối ưu hóa.

![Lars and Philipp after the presentation](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.007.jpeg) Philipp Kant (left) and Lars Brünjes (right) at the Hamburg event

Incentives are core to the design of Cardano and the related topic of staking has been one of the most keenly discussed among the community. Lars is leading work on Incentives, and the team includes Professor Aggelos Kiayias and Professor Elias Koutsoupias, at Edinburgh and Oxford universities respectively. Lars explained how well-designed incentives shepherd users through the system and encourage them to make choices that are not only in their best interests but lead to the smooth operation of the cryptocurrency as a whole.

Các ưu đãi là cốt lõi cho thiết kế của Cardano và chủ đề liên quan đến việc đặt cược là một trong những chủ đề được thảo luận sâu sắc nhất trong cộng đồng.
Lars là công việc hàng đầu về các ưu đãi, và nhóm nghiên cứu bao gồm Giáo sư Aggelos Kiayias và Giáo sư Elias Koutsoupias, tại các trường đại học Edinburgh và Oxford.
Lars giải thích cách các ưu đãi được thiết kế tốt mà người dùng chăn cừu thông qua hệ thống và khuyến khích họ đưa ra các lựa chọn không chỉ vì lợi ích tốt nhất của họ mà còn dẫn đến hoạt động trơn tru của toàn bộ tiền điện tử.

In Cardano it is important that stake holders are online so they can be part of the election for who gets to create the next block in the blockchain, and to create that block if they win. The incentive for taking part in Cardano is Ada, as a reward for being part of the process and creating a block. By comparison, in Bitcoin's proof-of-work system, stakeholders compete to solve cryptographic puzzles, with one winner taking a reward for creating a block. However, in Cardano, users may not have the time to be online or take part in the election process, so they can delegate their stake to others who can do it for them. Those who do take part then pay a share of the reward back to the users who did not participate. Simply holding Ada gives you stake, and if you delegate your stake, you still retain the monetary value of Ada and can spend it as you wish.

Trong Cardano, điều quan trọng là các chủ sở hữu cổ phần đang trực tuyến để họ có thể là một phần của cuộc bầu cử cho những người được tạo ra khối tiếp theo trong blockchain và tạo ra khối đó nếu họ thắng.
Ưu đãi để tham gia Cardano là ADA, như một phần thưởng cho việc là một phần của quá trình và tạo ra một khối.
Để so sánh, trong hệ thống bằng chứng làm việc của Bitcoin, các bên liên quan cạnh tranh để giải các câu đố mật mã, với một người chiến thắng nhận phần thưởng cho việc tạo ra một khối.
Tuy nhiên, ở Cardano, người dùng có thể không có thời gian để trực tuyến hoặc tham gia vào quá trình bầu cử, vì vậy họ có thể ủy thác cổ phần của họ cho những người khác có thể làm điều đó cho họ.
Những người tham gia sau đó trả một phần phần thưởng cho người dùng không tham gia.
Đơn giản chỉ cần giữ ADA cung cấp cho bạn cổ phần và nếu bạn ủy thác cổ phần của mình, bạn vẫn giữ lại giá trị tiền tệ của ADA và có thể chi tiêu như bạn muốn.

![Lars Brünjes presenting on delegation in Cardano](img/2018-05-14-iohk-holds-cardano-technical-presentation-in-hamburg.008.jpeg) 

Lars Brünjes on incentives in Cardano

Lars Brünjes về các ưu đãi ở Cardano

Lars explained that about 80% of stake should be delegated to stake pools, that optimally number about 100. Stake pools must be online, and provide infrastructure for the network in the form of relay nodes. The leftover 20% of stake would belong to small stakeholders who either participate on their own or decide not to. 

Lars giải thích rằng khoảng 80% cổ phần nên được giao cho các nhóm cổ phần, số lượng tối ưu khoảng 100. Bể cổ phần phải trực tuyến và cung cấp cơ sở hạ tầng cho mạng dưới dạng các nút chuyển tiếp.
20% cổ phần còn sót lại sẽ thuộc về các bên liên quan nhỏ, những người tự mình tham gia hoặc quyết định không.

There are three types of address in staking, each associated with two cryptographic key pairs: one for payment, one for staking. A base address has a staking key linked directly to it; a pointer address links to a delegation certificate on the blockchain, and an enterprise address is for exchanges, who may not use the funds entrusted to them to stake.

Có ba loại địa chỉ trong đặt cược, mỗi loại liên kết với hai cặp khóa mật mã: một cho thanh toán, một để đặt cọc.
Một địa chỉ cơ sở có khóa đặt cược được liên kết trực tiếp với nó;
Một liên kết địa chỉ con trỏ đến chứng chỉ ủy quyền trên blockchain và địa chỉ doanh nghiệp là dành cho các trao đổi, những người không thể sử dụng các khoản tiền được giao cho họ để đặt cược.

Delegation of staking rights from one staking key to another is done by means of a delegation certificate, which can be published on the blockchain as part of the metadata of a transaction, in which case a pointer address can refer to it. Such a published certificate is called a heavyweight. In case of conflicting certificates, later in the blockchain wins. The fees for creating a heavyweight delegation certificate are the transaction fees for the contained transaction. A lightweight certificate is not published on the blockchain, but instead included in block headers to prove staking rights for the address that was elected slot leader. It also contains a "serial number" to break ties.

Phái đoàn về quyền đặt cược từ khóa cổ phần này sang khóa khác được thực hiện bằng chứng chỉ ủy quyền, có thể được công bố trên blockchain như một phần của siêu dữ liệu của giao dịch, trong trường hợp đó một địa chỉ con trỏ có thể đề cập đến nó.
Một chứng chỉ được công bố như vậy được gọi là một hạng nặng.
Trong trường hợp chứng chỉ mâu thuẫn, sau đó trong blockchain thắng.
Các khoản phí để tạo chứng chỉ ủy quyền nặng nề là phí giao dịch cho giao dịch chứa.
Một chứng chỉ nhẹ không được công bố trên blockchain, mà thay vào đó được bao gồm trong các tiêu đề khối để chứng minh quyền đặt cược cho địa chỉ được bầu chọn là người lãnh đạo khe.
Nó cũng chứa một "số sê -ri" để phá vỡ mối quan hệ.

To set up a stake pool a registration certificate is created and embedded in a transaction that pays the pool registration fees to a special address. The certificate contains the staking key of the pool leader. People wishing to delegate to the pool must create (heavyweight) delegation certificates delegating their stake to that key. And using combinations of base and pointer addresses and "chains" of delegation certificates, a large number of scenarios can be covered, including: regular user wallets; offline user wallets with cold staking; wallets with enhanced privacy; staking pool wallets, and enterprise wallets for exchanges.

Để thiết lập một nhóm cổ phần, chứng chỉ đăng ký được tạo và nhúng trong một giao dịch trả phí đăng ký nhóm vào một địa chỉ đặc biệt.
Giấy chứng nhận chứa khóa đặt cược của người lãnh đạo nhóm.
Mọi người muốn ủy thác cho nhóm phải tạo chứng chỉ ủy quyền (hạng nặng) ủy thác cổ phần của họ cho chìa khóa đó.
Và sử dụng kết hợp các địa chỉ cơ sở và con trỏ và "chuỗi" chứng chỉ ủy quyền, một số lượng lớn các kịch bản có thể được bảo hiểm, bao gồm: ví người dùng thông thường;
ví người dùng ngoại tuyến với cổ phần lạnh;
ví với quyền riêng tư nâng cao;
Ví hồ bơi, và ví doanh nghiệp để trao đổi.

Transaction fees are an important part of Cardano's incentive scheme. When Ada is sent, a small fee is paid for the transition, to validate it. These fees help prevent Distributed Denial of Service (DDoS) attacks by imposing a financial barrier for any adversary intending to flood the network with spam transactions. The fees also provide funds for Cardano's incentives.

Phí giao dịch là một phần quan trọng trong chương trình khuyến khích của Cardano.
Khi ADA được gửi, một khoản phí nhỏ được trả cho quá trình chuyển đổi, để xác nhận nó.
Những khoản phí này giúp ngăn chặn các cuộc tấn công từ chối dịch vụ phân tán (DDoS) bằng cách áp đặt rào cản tài chính cho bất kỳ đối thủ nào có ý định tràn vào mạng với các giao dịch spam.
Các khoản phí cũng cung cấp tiền cho các ưu đãi của Cardano.

Incentives are distributed each epoch, the operation of Cardano's Ouroboros algorithm being divided into epochs that each last five days. Transaction fees are collected for the blocks created during each epoch, pooled along with Ada from monetary expansion, and the total is distributed to stakeholders, according to the stake they own. 

Các ưu đãi được phân phối mỗi kỷ nguyên, hoạt động của thuật toán Ouroboros của Cardano được chia thành các kỷ nguyên mà mỗi năm ngày qua.
Phí giao dịch được thu cho các khối được tạo ra trong mỗi epoch, được gộp chung với ADA từ việc mở rộng tiền tệ và tổng số được phân phối cho các bên liên quan, theo cổ phần mà họ sở hữu.

For more details on incentives, transaction fees and staking, Lars' presentation is available in full: [Incentives in Cardano](https://ucarecdn.com/ae552456-38d0-4da3-9ae5-0c658588df82/-/inline/yes/ "Incentives in Cardano Presentation").

Để biết thêm chi tiết về các ưu đãi, phí giao dịch và đặt cược, trình bày của Lars có sẵn đầy đủ: [ưu đãi ở Cardano] (https://ucarecdn.com/ae552456-38d0-4da3-9ae5-0c65858df82/-inline/yes
Ưu đãi trong bài thuyết trình Cardano ").

Follow [IOHK](https://twitter.com/InputOutputHK "IOHK Twitter") online for more details of progress on Cardano development, and watch out for a forthcoming video from the first Cardano developer meetup in London.

Theo dõi [IOHK] (https://twitter.com/inputoutputhk "IOHK Twitter") trực tuyến để biết thêm chi tiết về tiến trình phát triển của Cardano và xem video sắp tới từ cuộc gặp gỡ của nhà phát triển Cardano đầu tiên ở London.

