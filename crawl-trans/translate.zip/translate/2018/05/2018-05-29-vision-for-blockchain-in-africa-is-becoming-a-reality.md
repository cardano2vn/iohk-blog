# Vision for blockchain in Africa is becoming a reality
### **Ethiopia and Rwanda keen to realise promise of the technology**
![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.002.png) 29 May 2018![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.002.png)[ John O'Connor](tmp//en/blog/authors/john-oconnor/page-1/)![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.003.png) 7 mins read

![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.004.png)[ Vision for blockchain in Africa is becoming a reality - Input Output](https://ucarecdn.com/ffc4b9ae-32dd-4755-a6a8-fa8407414d0b/-/inline/yes/ "Vision for blockchain in Africa is becoming a reality - Input Output")

![John O'Connor](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.005.png)[](tmp//en/blog/authors/john-oconnor/page-1/)
### [**John O'Connor**](tmp//en/blog/authors/john-oconnor/page-1/)
African Operations Director

Commercial

- ![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.006.png)[](mailto:john.oconnor@iohk.io "Email")
- ![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.007.png)[](https://www.linkedin.com/in/jjtoconnor/ "LinkedIn")
- ![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.008.png)[](https://twitter.com/jjtoconnor "Twitter")
- ![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.009.png)[](https://github.com/staircaseJapes "GitHub")

The hope of bringing the benefits of blockchain to Africa has been around even longer than IOHK itself. Founder Charles Hoskinson talked about the promise of the technology driving financial inclusion on the continent in a [TEDx](https://www.youtube.com/watch?v=97ufCT6lQcY/ "The future will be decentralized, Charles Hoskinson, TEDxBermuda") speech in 2014. The vision encouraged me to join the Cardano project. This month, IOHK signed an MoU with the Ethiopian government to train and hire junior software developers and use Cardano in its agriculture industry, a step towards this promise being realised. Now the real work begins, as we look to use Cardano to solve real problems in Ethiopia and beyond.

Hy vọng mang lại những lợi ích của blockchain đến châu Phi đã tồn tại lâu hơn IOHK.
Người sáng lập Charles Hoskinson đã nói về lời hứa về công nghệ thúc đẩy sự bao gồm tài chính vào lục địa trong [TEDx] (https://www.youtube.com/watch?v=97ufct6lqcy/ "Tương lai sẽ được phân cấp, Charles Hoskinson
) Bài phát biểu năm 2014. Tầm nhìn khuyến khích tôi tham gia dự án Cardano.
Trong tháng này, IOHK đã ký hợp đồng với chính phủ Ethiopia để đào tạo và thuê các nhà phát triển phần mềm cơ sở và sử dụng Cardano trong ngành nông nghiệp của mình, một bước để thực hiện lời hứa này.
Bây giờ công việc thực sự bắt đầu, khi chúng tôi tìm cách sử dụng Cardano để giải quyết các vấn đề thực sự ở Ethiopia và hơn thế nữa.

The IOHK team flew into Addis Ababa, the capital, on May 3 for Ethiopiaâ€™s first blockchain forum, which we jointly organised with the Ethiopian Ministry of Science and Technology. As Director of African Operations, my last two months in Ethiopia have been a whirlwind of interaction with government, universities and the local technology scene. It was a pleasure to have those that Iâ€™ve met join us on stage to discuss what blockchain can do for Ethiopia.

Nhóm IOHK đã bay vào Addis Ababa, thủ đô, vào ngày 3 tháng 5 cho Diễn đàn Blockchain đầu tiên của Ethiopia, mà chúng tôi đã cùng nhau tổ chức với Bộ Khoa học và Công nghệ Ethiopia.
Là giám đốc hoạt động của châu Phi, hai tháng qua của tôi ở Ethiopia là một cơn lốc tương tác với chính phủ, trường đại học và bối cảnh công nghệ địa phương.
Thật vui khi có những người mà tôi đã gặp nhau tham gia cùng chúng tôi trên sân khấu để thảo luận về những gì blockchain có thể làm cho Ethiopia.

We did not arrive with solutions, but with a commitment to find them. IOHKâ€™s Alan McSherry who leads the Cardano Enterprise team, came out to gather business requirements for permissioned applications of Cardano, as did 13 other members of the IOHK team. Seeing the ideas that emerged from the dialogue between IOHK and the ministry validated our launch in Ethiopia, and our belief in a productive and mutually beneficial relationship. This belief is enshrined in the MoU Charles signed with the Minister of Science and Technology, Dr Getahun.

Chúng tôi đã không đến với các giải pháp, nhưng với cam kết tìm thấy chúng.
Alan McSherry của IOHK, người dẫn đầu nhóm Cardano Enterprise, đã đưa ra các yêu cầu kinh doanh cho các ứng dụng được phép của Cardano, cũng như 13 thành viên khác của nhóm IOHK.
Nhìn thấy những ý tưởng xuất hiện từ cuộc đối thoại giữa IOHK và Bộ đã xác nhận sự ra mắt của chúng tôi ở Ethiopia và niềm tin của chúng tôi vào một mối quan hệ hiệu quả và cùng có lợi.
Niềm tin này được lưu giữ trong MoU Charles đã ký hợp đồng với Bộ trưởng Bộ Khoa học và Công nghệ, Tiến sĩ Getahun.

![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.010.jpeg)

MoUâ€™s are non-binding but are taken seriously in Ethiopia, because they represent a required first step before entering into contractual obligations. In the MoU, we stated our intent to train and hire Haskell developers from a new office in Addis Ababa. The Ethiopian government stated its intent to help us to deploy [Cardano in Ethiopian agriculture](https://bitcoinmagazine.com/articles/where-coffee-just-grows-connecting-ethiopian-agritech-blockchain/ "Where Coffee Just Grows: Connecting Ethiopian Agritech to the Blockchain, Bitcoin magazine"). This training course is the first of its kind in Africa. We expect to start in September 2018 with an inaugural class of 30 women developers. All of our trainees will leave with the ability to create blockchain applications to help drive tech-enabled growth in Ethiopia. Those who excel will be hired by IOHK and not only contribute to Cardano code, but help build the blockchain agriculture applications we are exploring in partnership with the government. With 80 million Ethiopians working in this industry, the opportunity for blockchain to make an impact is huge. Coffee is Ethiopiaâ€™s largest export, and there are many sophisticated companies along the supply chain who have a deep understanding of the product.

Mou's không ràng buộc nhưng được thực hiện nghiêm túc ở Ethiopia, bởi vì chúng đại diện cho bước đầu tiên cần thiết trước khi tham gia vào các nghĩa vụ hợp đồng. Trong MOU, chúng tôi đã tuyên bố ý định đào tạo và thuê các nhà phát triển Haskell từ một văn phòng mới ở Addis Ababa. Chính phủ Ethiopia tuyên bố ý định giúp chúng tôi triển khai [Cardano trong nông nghiệp Ethiopia] (https://bitcoinmagazine.com/articles/where-coffee-just-grows-connecting-ethiopian-agritech-blockchain/"nơi cà phê chỉ phát triển: Kết nối Agritech của Ethiopia với Blockchain, Tạp chí Bitcoin "). Khóa đào tạo này là lần đầu tiên thuộc loại này ở Châu Phi. Chúng tôi hy vọng sẽ bắt đầu vào tháng 9 năm 2018 với một lớp khai mạc gồm 30 nhà phát triển nữ. Tất cả các thực tập sinh của chúng tôi sẽ rời đi với khả năng tạo các ứng dụng blockchain để giúp thúc đẩy tăng trưởng công nghệ ở Ethiopia. Những người Excel sẽ được IOHK thuê và không chỉ đóng góp cho mã Cardano, mà còn giúp xây dựng các ứng dụng nông nghiệp blockchain mà chúng tôi đang khám phá hợp tác với chính phủ. Với 80 triệu người Ethiopia làm việc trong ngành này, cơ hội cho blockchain tạo ra ảnh hưởng là rất lớn. Cà phê là xuất khẩu lớn nhất của Ethiopia và có nhiều công ty tinh vi trong chuỗi cung ứng có hiểu biết sâu sắc về sản phẩm.

We are in active discussions with many such companies to develop, refine, and implement the technology. Proving the origin of coffee is one such application. Iâ€™m also excited about using smart contracts to incentivise smallholder coffee farmers to adopt more productive farming practices (Iâ€™ll be writing more about some of our projects like this in the coming weeks). Some 80% of Ethiopiaâ€™s population is under the age of 30, and GDP growth is 10% a year. With the right support from government, Ethiopia could transform into an incredibly powerful, technology-enabled economy. Ethiopiaâ€™s national animal is the lion, and if that lion has been sleeping, it is now waking up.

Chúng tôi đang thảo luận tích cực với nhiều công ty như vậy để phát triển, tinh chỉnh và thực hiện công nghệ.
Chứng minh nguồn gốc của cà phê là một ứng dụng như vậy.
Tôi cũng hào hứng sử dụng các hợp đồng thông minh để khuyến khích nông dân trồng cà phê nhỏ áp dụng các hoạt động canh tác năng suất hơn (tôi sẽ viết thêm về một số dự án của chúng tôi như thế này trong vài tuần tới).
Khoảng 80% dân số của Ethiopia dưới 30 tuổi và tăng trưởng GDP là 10% một năm.
Với sự hỗ trợ đúng đắn từ chính phủ, Ethiopia có thể biến thành một nền kinh tế cực kỳ mạnh mẽ, hỗ trợ công nghệ.
Động vật quốc gia của Ethiopia là con sư tử, và nếu con sư tử đó đang ngủ, thì giờ nó đang thức dậy.

### **Community day**

### ** Ngày cộng đồng **

The day after the conference IOHK spent time with many of Ethiopiaâ€™s most promising entrepreneurs and the tech community. IOHK worked with Ethiopian accelerators ICE Addis and Bluemoon to have local startups pitch their existing startups, and how they were planning on leveraging blockchain technology. The judge was, of course, Charles.

Một ngày sau hội nghị IOHK đã dành thời gian với nhiều doanh nhân hứa hẹn nhất của Ethiopia và cộng đồng công nghệ.
IOHK đã làm việc với các máy gia tốc Ethiopia Ice Addis và Bluemoon để có các công ty khởi nghiệp địa phương tham gia các công ty khởi nghiệp hiện tại của họ và cách họ lên kế hoạch tận dụng công nghệ blockchain.
Thẩm phán, tất nhiên, Charles.

![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.011.jpeg) Charles meeting entrepreneurs in Addis

This was a highlight of the trip for me. After a pitch Charles would mischievously state that he had a few questions, before delivering a grilling that would have a Harvard MBA looking for the nearest exit. The startups held up fantastically.

Đây là một điểm nổi bật của chuyến đi đối với tôi.
Sau một sân, Charles sẽ tuyên bố một cách tinh nghịch rằng anh ta có một vài câu hỏi, trước khi đưa ra một món nướng có MBA Harvard tìm kiếm lối ra gần nhất.
Các công ty khởi nghiệp đã tổ chức tuyệt vời.

SÂÂince I began talking to local entrepreneurs in Addis two months ago Iâ€™ve received many messages from local companies interested in learning more about the technology. The first [Cardano Addis meetup](https://twitter.com/InputOutputHK/status/981138485846466561 "Excited to announce that @cardanocom's first meetup in Africa took place in Ethiopia..., twitter.com/InputOutputHK") was the beginning of a process of fostering understanding and adoption of the technology. The pitches showed me that these startups have not only begun looking at blockchain, but have puzzled out how it can add value to their businesses. Our colleagues in Cardanoâ€™s commercial entity Emurgo shared my view, and are in discussions about investing in a cohort of blockchain-enabled Ethiopian technology startups.

SÂINCE Tôi bắt đầu nói chuyện với các doanh nhân địa phương ở Addis hai tháng trước, tôi đã nhận được nhiều tin nhắn từ các công ty địa phương quan tâm đến việc tìm hiểu thêm về công nghệ.
[Cuộc gặp gỡ Addano Addis đầu tiên) (https://twitter.com/inputoutputhk/status/981138485846466561
của một quá trình thúc đẩy sự hiểu biết và áp dụng công nghệ.
Các sân cho tôi thấy rằng những công ty khởi nghiệp này không chỉ bắt đầu nhìn vào blockchain, mà còn bối rối làm thế nào nó có thể tăng thêm giá trị cho doanh nghiệp của họ.
Các đồng nghiệp của chúng tôi trong thực thể thương mại của Cardano đã chia sẻ quan điểm của tôi và đang thảo luận về việc đầu tư vào một nhóm các công ty khởi nghiệp công nghệ Ethiopia hỗ trợ blockchain.

### **Rwanda**

### ** rwanda **

The next leg of the trip for the IOHK team took us to Kigali, Rwanda, where Charles was talking at the Transform Africa Summit.

Chặng tiếp theo của chuyến đi cho đội IOHK đã đưa chúng tôi đến Kigali, Rwanda, nơi Charles đang nói chuyện tại Hội nghị thượng đỉnh Transform Africa.

![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.012.jpeg) Charles speaking at the Transform Africa Summit in Kigali

The summit aimed to bring together global and regional leaders from government, business and international organizations to collaborate on new ways of shaping, accelerating and sustaining Africaâ€™s digital revolution. Blockchain was a key focus for the conference organisers, and we were honoured to have been invited and recognised for the efforts we are beginning to make in the region. Rwanda is truly a miraculous example of what can be accomplished when a country is united in its purpose and its government has embraced the principles of accountability, efficiency and openness.

Hội nghị thượng đỉnh nhằm tập hợp các nhà lãnh đạo toàn cầu và khu vực từ các tổ chức chính phủ, kinh doanh và quốc tế để hợp tác về những cách định hình mới, tăng tốc và duy trì cuộc cách mạng kỹ thuật số của Châu Phi.
Blockchain là một trọng tâm chính cho các nhà tổ chức hội nghị, và chúng tôi đã vinh dự được mời và công nhận cho những nỗ lực mà chúng tôi bắt đầu làm trong khu vực.
Rwanda thực sự là một ví dụ kỳ diệu về những gì có thể đạt được khi một quốc gia được thống nhất trong mục đích của nó và chính phủ của nó đã chấp nhận các nguyên tắc trách nhiệm, hiệu quả và cởi mở.

The opportunity for IOHK to help enable this transformation is incredibly exciting. There are many countries where the promise of a technology that can bring transparency to government processes would be met with trepidation. It is huge credit to Rwanda that they seek to not only participate, but promote the technologyâ€™s adoption through the Transform Africa Summit.

Cơ hội cho IOHK để giúp cho phép chuyển đổi này là vô cùng thú vị.
Có nhiều quốc gia nơi lời hứa về một công nghệ có thể mang lại sự minh bạch cho các quy trình của chính phủ sẽ được đáp ứng với sự lo lắng.
Đó là tín dụng rất lớn đối với Rwanda là họ tìm cách không chỉ tham gia, mà còn thúc đẩy việc áp dụng công nghệ thông qua Hội nghị thượng đỉnh Transform Africa.

And so on to strategy. Whilst we expect to have operations across many African countries in the future, focusing our initial efforts on Ethiopia and Rwanda will be a powerful start. Ethiopia has a government that is eager to engage in digital transformation and though early in that process, has the ability to deploy the technology across the country. The applications we are discussing could benefit tens of millions of people. Rwanda on the other hand has a population a tenth the size of Ethiopia. However they are leading Africa in their commitment to support innovative technologies. Ideas can be tried and tested. If they fail, lessons will be learnt and the next attempt will be better. This principle is the central driver of innovation, and Rwanda has embraced it.

Và như vậy để chiến lược.
Trong khi chúng tôi hy vọng sẽ có các hoạt động trên nhiều quốc gia châu Phi trong tương lai, tập trung những nỗ lực ban đầu của chúng tôi vào Ethiopia và Rwanda sẽ là một khởi đầu mạnh mẽ.
Ethiopia có một chính phủ mong muốn tham gia vào việc chuyển đổi kỹ thuật số và mặc dù sớm trong quá trình đó, có khả năng triển khai công nghệ trên toàn quốc.
Các ứng dụng chúng tôi đang thảo luận có thể có lợi cho hàng chục triệu người.
Mặt khác, Rwanda có dân số có quy mô thứ mười của Ethiopia.
Tuy nhiên, họ đang dẫn đầu châu Phi trong cam kết hỗ trợ các công nghệ sáng tạo.
Ý tưởng có thể được thử và thử nghiệm.
Nếu họ thất bại, các bài học sẽ được học và nỗ lực tiếp theo sẽ tốt hơn.
Nguyên tắc này là động lực trung tâm của sự đổi mới, và Rwanda đã chấp nhận nó.

![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.013.jpeg) Charles and John with Dr Getahun, Minister of Science and Technology

After a whirlwind few weeks Iâ€™d like to thank everyone who has allowed us to reach this point. I thank ICE Addis, Bluemoon capital, as well as Impact hub in Kigali for hosting events with us and connecting me with the local entrepreneurship. I thank the IOHK and Emurgo teams who flew out to be on the ground and help us establish our work. But most importantly, Iâ€™d like to thank Yodahe Zemichael from the Science Technology and Information Centre and Dr Getahun Mekuria, Minister of Science and Technology. You have been more agile, proactive, and enthusiastic partners than we could have hoped for. We look forward to working with you.

Sau một vài tuần gió lốc, tôi muốn cảm ơn tất cả những người đã cho phép chúng tôi đạt được điểm này.
Tôi cảm ơn Ice Addis, Bluemoon Capital, cũng như Impact Hub ở Kigali vì đã tổ chức các sự kiện với chúng tôi và kết nối tôi với tinh thần kinh doanh địa phương.
Tôi cảm ơn các đội IOHK và Emurgo đã bay ra để ở trên mặt đất và giúp chúng tôi thiết lập công việc của chúng tôi.
Nhưng quan trọng nhất, tôi muốn cảm ơn Yodahe Zemichael từ Trung tâm thông tin và công nghệ khoa học và Tiến sĩ Getahun Mekuria, Bộ trưởng Bộ Khoa học và Công nghệ.
Bạn đã đối tác nhanh nhẹn, chủ động và nhiệt tình hơn những gì chúng ta có thể hy vọng.
Chúng tôi mong được làm việc với bạn.

## **Attachments**

## ** tệp đính kèm **

![](img/2018-05-29-vision-for-blockchain-in-africa-is-becoming-a-reality.004.png)[ Vision for blockchain in Africa is becoming a reality - Input Output](https://ucarecdn.com/ffc4b9ae-32dd-4755-a6a8-fa8407414d0b/-/inline/yes/ "Vision for blockchain in Africa is becoming a reality - Input Output")

