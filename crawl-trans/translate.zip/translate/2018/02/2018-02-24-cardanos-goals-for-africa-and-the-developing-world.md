# Cardano’s goals for Africa and the developing world
### **Charles Hoskinson addresses packed crowd at LSE**
![](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.002.png) 24 February 2018![](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.002.png)[ Jane Wild](tmp//en/blog/authors/jane-wild/page-1/)![](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.003.png) 6 mins read

![](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.004.png)[ Cardano’s goals for Africa and the developing world - Input Output](https://ucarecdn.com/e55a2505-75b9-45c2-bf4d-ea18c06d02df/-/inline/yes/ "Cardano’s goals for Africa and the developing world - Input Output")

![Jane Wild](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.005.png)[](tmp//en/blog/authors/jane-wild/page-1/)
### [**Jane Wild**](tmp//en/blog/authors/jane-wild/page-1/)
Content Director

- ![](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.006.png)[](https://www.linkedin.com/in/jane-wild-7898389 "LinkedIn")
- ![](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.007.png)[](https://twitter.com/jane_wild_ "Twitter")

[The London School of Economics](http://www.lse.ac.uk/ "London School of Economics") has a long history of links to Africa. Founded in 1895 four years before the outbreak of the [Boer War](https://en.wikipedia.org/wiki/Second_Boer_War "Second Boer War, Wikipedia"), the school launched into the debates of the era. Some of the first leaders of newly independent African nations studied at LSE and its progressive and anti-imperialist stance saw the school play a part in the anti-apartheid movement. With that history, the university was an apt location for Charles Hoskinson to introduce Cardano’s next steps - for its technology to serve the developing world, starting with Africa. The talk, organised by the [Cardano Foundation](https://cardanofoundation.org/ "cardanofoundation.org") and the LSE blockchain association at the school’s Saw Swee Hock Centre, was twice oversubscribed. 

[Trường Kinh tế Luân Đôn] (http://www.lse.ac.uk/ "Trường Kinh tế London") có một lịch sử lâu dài về các liên kết đến Châu Phi.
Được thành lập vào năm 1895 bốn năm trước khi [Chiến tranh Boer] bùng nổ (https://en.wikipedia.org/wiki/second_boer_war "Chiến tranh Boer thứ hai, Wikipedia"), trường đã phát động vào các cuộc tranh luận về thời đại.
Một số nhà lãnh đạo đầu tiên của các quốc gia châu Phi mới độc lập được nghiên cứu tại LSE và lập trường tiến bộ và chống đế quốc của nó đã thấy trường đóng vai trò trong phong trào chống phân biệt chủng tộc.
Với lịch sử đó, trường đại học là một địa điểm thích hợp để Charles Hoskinson giới thiệu các bước tiếp theo của Cardano, - vì công nghệ của mình để phục vụ thế giới đang phát triển, bắt đầu với Châu Phi.
Cuộc nói chuyện, được tổ chức bởi [Quỹ Cardano] (https://cardanofoundation.org/ "cardanofoundation.org") và Hiệp hội blockchain LSE tại trường trung tâm Saw Saw Hock, đã được đăng ký quá mức.

Before the doors opened on Tuesday evening there was a buzz of anticipation in the long queue of hundreds of people, mostly in their twenties and thirties.

Trước khi các cánh cửa mở cửa vào tối thứ ba, có một tiếng vang dự đoán trong hàng dài của hàng trăm người, chủ yếu ở độ tuổi hai mươi và ba mươi.

To the packed crowd, Charles set out the vision for Cardano that will begin to unfold in Africa this year. 

Đối với đám đông chật cứng, Charles đã đặt ra tầm nhìn cho Cardano sẽ bắt đầu mở ra ở Châu Phi trong năm nay.

"You have to go to talk to people in the countries you want to help. The only way you are going to the change the world is you have to go there. You’re not going to be the one doing it, you have to be humble enough to let the people there do it."

"Bạn phải đi nói chuyện với mọi người ở các quốc gia bạn muốn giúp đỡ. Cách duy nhất bạn sẽ thay đổi thế giới là bạn phải đến đó. Bạn sẽ không phải là người làm điều đó, bạn phải
Đủ khiêm tốn để cho những người ở đó làm điều đó. "

Using a model already tested during the past year with [pilot courses in Athens and Barbados](https://cryptocoin.news/news/more-blockchain-ready-developers-needed-iohk-trains-students-in-haskell-code-3491/ "More Blockchain Ready Developers Needed. IOHK Trains Students In Haskell Code, cryptocoin.news"), IOHK will bring skills to the region. Training in the programming language Haskell, in which Cardano is built, will be provided to budding developers. At the end of the course they will either be hired to contribute to Cardano, or will plough their talents back into the local economy. As an example of IOHK’s approach, the Barbados course was held in association with the University of the West Indies and was the first time that Haskell was taught in the country. The classes were even attended by Professor Philip Wadler, one of the creators of Haskell, who is helping to develop Cardano.

Sử dụng một mô hình đã được thử nghiệm trong năm qua với [các khóa học thí điểm ở Athens và Barbados] (https://cryptocoin.news/news/more-blockchain-ready-developers
-3491/ "Cần thêm các nhà phát triển sẵn sàng blockchain. IOHK đào tạo sinh viên trong mã Haskell, CryptoCoin.News"), IOHK sẽ mang lại các kỹ năng cho khu vực.
Đào tạo về ngôn ngữ lập trình Haskell, trong đó Cardano được xây dựng, sẽ được cung cấp cho các nhà phát triển vừa chớm nở.
Vào cuối khóa học, họ sẽ được thuê để đóng góp cho Cardano, hoặc sẽ đưa tài năng của họ trở lại nền kinh tế địa phương.
Như một ví dụ về cách tiếp cận của IOHK, khóa học Barbados đã được tổ chức kết hợp với Đại học Tây Ấn và là lần đầu tiên Haskell được dạy ở nước này.
Các lớp học thậm chí còn có sự tham gia của Giáo sư Philip Wadler, một trong những người tạo ra Haskell, người đang giúp phát triển Cardano.

![Charles Hoskinson with Michael Parsons](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.008.jpeg) 

Charles Hoskinson with Michael Parsons, 

Charles Hoskinson với Michael Parsons,

Chairman of the Cardano Foundation

Chủ tịch Quỹ Cardano

"The next class will probably be done in Ethiopia, we are already in negotiations to do that," Charles said. "You have to create a base of people in the country who have an incentive to care and actually understand how the tech works."

"Lớp tiếp theo có thể sẽ được thực hiện ở Ethiopia, chúng tôi đã đàm phán để làm điều đó", Charles nói.
"Bạn phải tạo ra một cơ sở của những người trong nước có động lực để chăm sóc và thực sự hiểu cách thức hoạt động của công nghệ."

Just as important will be to engage local government and explore opportunities for working together. Pilot schemes using Cardano could test potential applications, for example relating to land registry, identity, or voting.

Cũng quan trọng không kém sẽ tham gia chính quyền địa phương và khám phá các cơ hội làm việc cùng nhau.
Các chương trình thí điểm sử dụng Cardano có thể kiểm tra các ứng dụng tiềm năng, ví dụ liên quan đến đăng ký đất đai, danh tính hoặc bỏ phiếu.

The key to enabling blockchain use in Africa is to run successful trial projects, showcasing blockchain technology as a cheaper and more efficient method of doing things. "A proof of concept can show why it’s faster and better. It can show it can be rolled out, show people can make a lot money from it, then everyone says ‘me too’, and competition drives a tsunami wave of people in, including my blockchain competitors," Charles said.

Chìa khóa để cho phép sử dụng blockchain ở châu Phi là chạy các dự án dùng thử thành công, giới thiệu công nghệ blockchain như một phương pháp làm việc rẻ hơn và hiệu quả hơn.
"Một bằng chứng về khái niệm có thể cho thấy lý do tại sao nó nhanh hơn và tốt hơn. Nó có thể cho thấy nó có thể được tung ra, cho thấy mọi người có thể kiếm được nhiều tiền từ nó, sau đó mọi người nói 'tôi cũng vậy', và cạnh tranh thúc đẩy một làn sóng sóng thần của mọi người,
Bao gồm cả các đối thủ cạnh tranh blockchain của tôi, "Charles nói.

There was a powerful case for blockchain in Africa, he argued. Blockchain technology has great potential to unlock the wealth of countries through the tokenisation of natural resources, labour or property. "Tokens aren’t just good for CryptoKitties, it turns out you can do real things with these platforms, so let’s go try that."

Có một trường hợp mạnh mẽ cho blockchain ở châu Phi, ông lập luận.
Công nghệ blockchain có tiềm năng lớn để mở khóa sự giàu có của các quốc gia thông qua việc thông báo về tài nguyên thiên nhiên, lao động hoặc tài sản.
"Tokens aren chỉ tốt cho tiền điện tử, hóa ra bạn có thể làm những điều thực sự với các nền tảng này, vì vậy hãy để đi thử điều đó."

"If you count the locked up liquidity in these countries it’s in the trillions of dollars. It’s a great paradox that there’s tremendous potential value in places and if only it could be accessed and given to the people in some fair way then poverty would melt away and these would become some of the wealthiest countries."

"Nếu bạn đếm thanh khoản bị khóa ở các quốc gia này, thì đó là hàng nghìn tỷ đô la. Đó là một nghịch lý tuyệt vời rằng có giá trị tiềm năng to lớn ở những nơi và nếu chỉ có thể truy cập và trao cho mọi người theo cách nào đó thì nghèo sẽ tan biến
Và những điều này sẽ trở thành một trong những quốc gia giàu có nhất. "

It would not be easy, but blockchain adoption would inevitably take place, Charles said. Local politicians would have to receive a financial incentive to support the technology, perhaps through a pre-mine. Then there are other hurdles to cross in Africa, such as patchy internet coverage that hampers connectivity to the blockchain. To address this, IOHK is exploring satellite coverage and estimates the cost at $50 to $100 million. Trusted hardware offers a second solution, by allowing offline, offchain transactions through Bluetooth that can register on the blockchain when connectivity is regained. 

Nó sẽ không dễ dàng, nhưng việc áp dụng blockchain chắc chắn sẽ diễn ra, Charles nói.
Các chính trị gia địa phương sẽ phải nhận được một động lực tài chính để hỗ trợ công nghệ, có lẽ thông qua một loại thuốc tiền.
Sau đó, có những rào cản khác để vượt qua châu Phi, chẳng hạn như phạm vi bảo hiểm Internet chắp vá cản trở kết nối với blockchain.
Để giải quyết vấn đề này, IOHK đang khám phá phạm vi bảo hiểm vệ tinh và ước tính chi phí ở mức 50 đến 100 triệu đô la.
Phần cứng đáng tin cậy cung cấp một giải pháp thứ hai, bằng cách cho phép các giao dịch ngoại tuyến, Offchain thông qua Bluetooth có thể đăng ký trên blockchain khi kết nối được lấy lại.

Another hurdle is to provide points where local currency can be cashed in or out. To this end, IOHK is looking at how a network of ATM terminals could be installed at affordable cost and which can operate off grid. And finally, a longheld aim of cryptocurrency has been to develop a value stable currency, which is pegged to fiat such as the dollar, and offers businesses stability and protection against the price volatility of cryptocurrency. Charles announced that IOHK was starting a research agenda into value stable currencies, and although there would be "no silver bullet", he promised a series of experiments and hard work on the subject. 

Một rào cản khác là cung cấp các điểm mà đồng địa phương có thể được rút tiền mặt trong hoặc ngoài.
Cuối cùng, IOHK đang xem xét làm thế nào một mạng lưới các thiết bị đầu cuối ATM có thể được cài đặt với chi phí giá cả phải chăng và có thể hoạt động ngoài lưới.
Và cuối cùng, một mục tiêu dài hạn của tiền điện tử là phát triển một loại tiền tệ ổn định giá trị, được gắn với các fiat như đồng đô la, và cung cấp cho các doanh nghiệp ổn định và bảo vệ chống lại sự biến động của tiền điện tử.
Charles tuyên bố rằng IOHK đang bắt đầu một chương trình nghiên cứu về các loại tiền tệ ổn định giá trị, và mặc dù sẽ có "không có viên đạn bạc", ông đã hứa với một loạt các thí nghiệm và công việc chăm chỉ về chủ đề này.

"So that’s what Cardano is doing for the developing world," said Charles. "We have a moral obligation to try and explore this tech and get it to as many people as possible."

"Vì vậy, những gì Cardano đang làm cho thế giới đang phát triển," Charles nói.
"Chúng tôi có nghĩa vụ đạo đức để thử và khám phá công nghệ này và đưa nó đến càng nhiều người càng tốt."

The talk was followed by a wide-ranging question and answer session, with questions on everything from the future of blockchain in China, to transaction fees on Cardano, to establishing regulated cryptocurrency businesses.

Cuộc nói chuyện được theo sau bởi một câu hỏi và trả lời trên phạm vi rộng, với các câu hỏi về mọi thứ, từ tương lai của blockchain ở Trung Quốc, đến phí giao dịch trên Cardano, để thiết lập các doanh nghiệp tiền điện tử được quy định.

The audience had a mix of backgrounds, from serious Cardano fans who had watched hours of videos online, to the cryptocurrency curious.

Khán giả đã có một sự kết hợp của nền tảng, từ những người hâm mộ Cardano nghiêm túc, những người đã xem hàng giờ video trực tuyến, đến Cryptocurrency tò mò.

Timo, 27, is a student from Salzburg at Regent’s Business School in London. Having been interested in cryptocurrency for more than a year, he says he’d watched [Charles’s Ted talk](https://www.youtube.com/watch?v=97ufCT6lQcY "The future will be decentralized, YouTube"), seen his interviews and and then bought Ada. "The project is very serious compared to others, it’s evident from the team, the web presence and the many interviews Charles has given."

Timo, 27 tuổi, là một sinh viên từ Salzburg tại Trường Kinh doanh Regent, ở London.
Đã quan tâm đến tiền điện tử trong hơn một năm, anh nói rằng anh đã xem [TED Talk của Charles] (https://www.youtube.com/watch?v=97ufct6lqcy "Tương lai sẽ được phân cấp, YouTube")
Các cuộc phỏng vấn của anh ấy và sau đó mua ADA.
"Dự án rất nghiêm trọng so với những người khác, nó rõ ràng từ nhóm, sự hiện diện trên web và nhiều cuộc phỏng vấn Charles đã đưa ra."

![Charles speaking at LSE](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.008.jpeg) 

Charles Hoskinson speaking at LSE

Charles Hoskinson phát biểu tại LSE

"Blockchain is the most revolutionary technology since the internet," said his friend, Thomas, 23, from Antwerp, who first learnt about cryptocurrency last year from his father during a marathon three-hour, late evening conversation. "That sparked my interest, and I then came across Charles’s videos and found him a brilliant mind. I like the approach that Cardano is taking to tackling the problems blockchain is having right now - it’s also academic and involves people from universities, there is objective option there."

"Blockchain là công nghệ mang tính cách mạng nhất kể từ Internet", người bạn của anh, Thomas, 23 tuổi, đến từ Antwerp, người đầu tiên biết về tiền điện tử năm ngoái từ cha anh trong cuộc trò chuyện buổi tối ba giờ, cuối buổi tối.
"Điều đó làm tôi quan tâm, và sau đó tôi đã bắt gặp các video của Charles và tìm thấy anh ấy một tâm trí tuyệt vời. Tôi thích cách tiếp cận mà Cardano đang thực hiện để giải quyết các vấn đề blockchain đang gặp phải
tùy chọn ở đó. "

Others were there to find out more about cryptocurrency. Ana, 24, is a postgraduate student of law at LSE who came along to the talk. She is interested in writing her dissertation about smart contracts because she sees blockchain as an newly emerging discipline within law. "I want to understand more about blockchain," she said. "The legal aspect is very interesting and there are a lot of issues to tackle. For example, is it legitimate to have contracts that self-execute, if you don’t have a court or a judge involved?"

Những người khác đã ở đó để tìm hiểu thêm về tiền điện tử.
Ana, 24 tuổi, là một sinh viên sau đại học của Luật tại LSE, người đã đi cùng buổi nói chuyện.
Cô ấy quan tâm đến việc viết luận án của mình về các hợp đồng thông minh vì cô ấy xem blockchain là một kỷ luật mới nổi trong pháp luật.
"Tôi muốn hiểu thêm về blockchain," cô nói.
"Khía cạnh pháp lý rất thú vị và có rất nhiều vấn đề cần giải quyết. Ví dụ, có hợp pháp không khi có hợp đồng tự thực hiện, nếu bạn không có tòa án hay thẩm phán nào liên quan?"

More information is coming soon on IOHK and Africa strategy, and will be outlined by the Director of African Operations, [John O’Connor](tmp//en/team/john-oconnor/ "John O'Connor, iohk.io").

Thông tin thêm sẽ sớm xuất hiện trên chiến lược IOHK và Châu Phi, và sẽ được giám đốc hoạt động châu Phi vạch ra, [John O'Connor] (TMP // EN/Team/John-Oconnor/"John O'Connor, Iohk.io"
).

## **Attachments**

## ** tệp đính kèm **

![](img/2018-02-24-cardanos-goals-for-africa-and-the-developing-world.004.png)[ Cardano’s goals for Africa and the developing world - Input Output](https://ucarecdn.com/e55a2505-75b9-45c2-bf4d-ea18c06d02df/-/inline/yes/ "Cardano’s goals for Africa and the developing world - Input Output")

