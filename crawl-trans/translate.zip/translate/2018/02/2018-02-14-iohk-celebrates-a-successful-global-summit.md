# IOHK celebrates a successful Global Summit
### **Cardano development in focus at Lisbon**
![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.002.png) 14 February 2018![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.002.png)[ Jeremy Wood](tmp//en/blog/authors/jeremy-wood/page-1/)![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.003.png) 8 mins read

![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.004.png)[ IOHK celebrates a successful Global Summit - Input Output](https://ucarecdn.com/32cfa852-a7cc-46a8-a601-d0fea14aeb7c/-/inline/yes/ "IOHK celebrates a successful Global Summit - Input Output")

![Jeremy Wood](img/2018-02-14-iohk-celebrates-a-successful-global-summit.005.png)[](tmp//en/blog/authors/jeremy-wood/page-1/)
### [**Jeremy Wood**](tmp//en/blog/authors/jeremy-wood/page-1/)
Founder

- ![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.006.png)[](tmp///www.youtube.com/watch?v=E2G9xLYpR1c "YouTube")
- ![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.007.png)[](tmp///jp.linkedin.com/in/jeremykwood "LinkedIn")
- ![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.008.png)[](tmp///twitter.com/iohk_jeremy "Twitter")

![IOHK celebrates a successful Global Summit](img/2018-02-14-iohk-celebrates-a-successful-global-summit.009.jpeg)

January got off to a busier start than normal for IOHK because on top of all the usual research and development being carried out, pretty much the entire company traveled to Lisbon for our latest meetup. These week-long events are always hectic and challenging â€“ where everyone comes together to push forward work on projects - but they are also fun, allowing people to meet face to face, sit down over a meal, and get to know each other. Now that we've had time to take stock of the week, what strikes me most is the tremendous amount of energy and effort going into all the work IOHK is doing. We made leaps forward on the [various components of Cardano](https://cardanoroadmap.com/ "cardanoroadmap.com"), such as the [treasury](https://www.youtube.com/watch?v=Hyh3h_yX-S0 "Bingsheng Zhang, Cardano Whiteboard, Treasuries, YouTube") and delegation. During the week there was a planned schedule of talks, workshops and meetings, organized in the style of a conference, but aside from that program, there were an incredible number of spontaneous discussions taking place. There were continual requests to book meeting rooms, or for 15-minute pow-wows in coffee breaks. Walking around the hotel, you'd always stumble upon small groups of IOHK people sitting around laptops in deep discussion.

![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.010.jpeg) 

Lisbon was a great opportunity to hear about the enormous strides being made by IOHK Research. Professor Aggelos Kiayias, IOHK Chief Scientist, set out plans for [Ouroboros](tmp//en/research/papers/#9BKRHCSI "Ouroboros: A Provably Secure Proof-of-Stake Blockchain Protocol, iohk.io"), the proof of stake protocol that underpins Cardano, which has been been rigorously constructed based on first principles and has undergone academic peer review. Further development of the protocol aims to speed it up, offer sharding, and eventually allow assets to flow between connected sidechains. 

Lisbon là một cơ hội tuyệt vời để nghe về những bước tiến lớn được thực hiện bởi IOHK Research.
Giáo sư Aggelos Kiayias, nhà khoa học trưởng của IOHK, đã đặt ra các kế hoạch cho [ouroboros] (TMP // EN/Nghiên cứu/Giấy tờ/#9BKRHCSI "
Giao thức cổ phần làm nền tảng cho Cardano, đã được xây dựng nghiêm ngặt dựa trên các nguyên tắc đầu tiên và đã trải qua đánh giá ngang hàng học tập.
Sự phát triển hơn nữa của giao thức nhằm mục đích tăng tốc nó, cung cấp Sharding và cuối cùng cho phép các tài sản chảy giữa các sidechain được kết nối.

Aggelos says: "It was a very work-intensive week where almost all of the IOHK work threads converged under a single roof here in Lisbon. In terms of research, substantial progress was made on all our high priority objectives including incentives, delegation, wallet security, multi-sig capabilities, sidechains and smart contract support."

Aggelos nói: "Đó là một tuần rất tốn công việc, nơi mà hầu hết các chủ đề công việc của IOHK hội tụ dưới một mái nhà duy nhất ở Lisbon. Về mặt nghiên cứu, tiến bộ đáng kể đã được thực hiện trên tất cả các mục tiêu ưu tiên cao của chúng tôi bao gồm các ưu đãi, ủy quyền, ví
Bảo mật, khả năng đa sig, sidechains và hỗ trợ hợp đồng thông minh. "

The development of Cardano took centre stage during the week. Delegation, a core mechanism of Cardano, was a subject of much discussion in three major meetings that were a continuation of discussions held in Edinburgh last year. Delegation is a mechanism that allows stakeholders to delegate their stake to other parties, such as stake pools, and in return receive some reward for doing so. It fulfils an equivalent function to mining in proof of work protocols and so must offer some benefit to those who delegate their stake. The considerations for creating a delegation scheme are complex and great care must be taken to ensure requirements are balanced fairly, from user privacy to the incentives offered.

Sự phát triển của Cardano đã chiếm vị trí trung tâm trong tuần.
Phái đoàn, một cơ chế cốt lõi của Cardano, là một chủ đề của nhiều cuộc thảo luận trong ba cuộc họp lớn là sự tiếp nối của các cuộc thảo luận được tổ chức tại Edinburgh năm ngoái.
Phái đoàn là một cơ chế cho phép các bên liên quan ủy thác cổ phần của họ cho các bên khác, chẳng hạn như nhóm cổ phần và đổi lại nhận được một số phần thưởng cho việc đó.
Nó đáp ứng một chức năng tương đương để khai thác trong các giao thức làm việc và do đó phải cung cấp một số lợi ích cho những người ủy thác cổ phần của họ.
Các cân nhắc để tạo ra một chương trình ủy quyền rất phức tạp và phải cẩn thận để đảm bảo các yêu cầu được cân bằng công bằng, từ quyền riêng tư của người dùng đến các ưu đãi được cung cấp.

![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.010.jpeg) 

Dr Philipp Kant, Director of Formal Methods, said the team is making progress so delegation can move beyond its initial description in a research paper to operation in real life. "In the last weeks we've had various meetings, where we reviewed the mechanisms that we have for delegation in Cardano, to make sure that we can fulfill all the requirements, including rewards for stakeholders who delegate. This week, having everyone in one room, we got to the point where we have a proposal," he says. "What I think we gained is that we've converged on good a scheme to use."

Tiến sĩ Philipp Kant, giám đốc phương pháp chính thức, cho biết nhóm đang tiến bộ để phái đoàn có thể vượt ra ngoài mô tả ban đầu trong một bài nghiên cứu để vận hành trong cuộc sống thực.
"Trong những tuần qua, chúng tôi đã có nhiều cuộc họp khác nhau, nơi chúng tôi đã xem xét các cơ chế mà chúng tôi có cho phái đoàn ở Cardano, để đảm bảo rằng chúng tôi có thể đáp ứng tất cả các yêu cầu, bao gồm cả phần thưởng cho các bên liên quan.
Phòng, chúng tôi đã đến điểm mà chúng tôi có một đề xuất, "ông nói.
"Những gì tôi nghĩ rằng chúng tôi đã đạt được là chúng tôi đã hội tụ một kế hoạch tốt để sử dụng."

The delicate task of working through tricky problems was also highlighted by Dr Neil Davies, who along with Peter Thompson is leading work on Cardano's network layer, to make sure that its distributed system can deliver high performance even when scaled to millions of users. "There are complex issues when you're trying to construct a new way of organizing how people exchange value, to ensure it will be sustainable in the long term," he says. "This week was the quickest way of getting everybody up to speed, to see everyone's progress and review it among peers. We took a few knotty technical problems and had technical discussion to agree the way forward."

Nhiệm vụ tinh tế là làm việc thông qua các vấn đề khó khăn cũng được Tiến sĩ Neil Davies, người cùng với Peter Thompson dẫn đầu công việc trên lớp mạng của Cardano, để đảm bảo rằng hệ thống phân tán của nó có thể mang lại hiệu suất cao ngay cả khi được chia tỷ lệ lên hàng triệu người dùng.
"Có những vấn đề phức tạp khi bạn đang cố gắng xây dựng một cách tổ chức mới về cách mọi người trao đổi giá trị, để đảm bảo nó sẽ bền vững trong dài hạn", ông nói.
"Tuần này là cách nhanh nhất để giúp mọi người tăng tốc, để thấy sự tiến bộ của mọi người và xem xét nó giữa các đồng nghiệp.

Everyone who came along to Lisbon said meeting in person had real benefits. Professor Philip Wadler, IOHK area leader for programming languages, is working on [Plutus](https://github.com/input-output-hk/plutus-prototype "Plutus Prototype, Github"), a new language for programming smart contracts on Cardano that is inspired by Haskell, the language he pioneered and in which Cardano is built. Phil says: "Getting everyone in one place has been a real aid to kickstarting what we're doing with Plutus. We've considerably upped the person power involved and I'm excited to see what happens."

Tất cả những người đến cùng Lisbon đều nói cuộc họp trực tiếp đều có lợi ích thực sự.
Giáo sư Philip Wadler, lãnh đạo khu vực IOHK về ngôn ngữ lập trình, đang làm việc trên [Plutus] (https://github.com/input-output
Trên Cardano được truyền cảm hứng từ Haskell, ngôn ngữ mà anh tiên phong và trong đó Cardano được xây dựng.
Phil nói: "Đưa mọi người ở một nơi là một trợ giúp thực sự để khởi động những gì chúng tôi đang làm với Plutus.

Phil also believes that IOHK's championing of peer reviewed research could have profound implications for the cryptocurrency field. "I found Charles's opening talk to be really inspiring, he says. "It's amazing that peer reviewed research isn't the standard in the industry but it's really exciting how IOHK has made that work and turned that into part of the value proposition. If that does nothing else but get others to pick that up, that would be fantastic."

Phil cũng tin rằng việc vô địch nghiên cứu đánh giá ngang hàng của IOHK có thể có ý nghĩa sâu sắc đối với lĩnh vực tiền điện tử.
"Tôi đã tìm thấy cuộc nói chuyện mở đầu của Charles để thực sự truyền cảm hứng, anh ấy nói." Thật đáng kinh ngạc khi nghiên cứu đánh giá ngang hàng không phải là tiêu chuẩn trong ngành nhưng thật thú vị khi IOHK đã thực hiện công việc đó và biến điều đó thành một phần của đề xuất giá trị.
Nếu điều đó không có gì khác ngoài việc khiến người khác chọn nó, điều đó thật tuyệt vời. "

It wasn't just Cardano development that was pushed forwards in Lisbon. 

Đó không chỉ là sự phát triển của Cardano đã được đẩy về phía trước ở Lisbon.

Partners were also present, including [ZenCash](https://zensystem.io/ "zensystem.io"), the [Cardano Foundation](https://cardanofoundation.org/ "cardanofoundation.org"), and representatives from [Emurgo](https://emurgo.io/ "emurgo.io"). 

Các đối tác cũng có mặt, bao gồm [Zencash] (https://zensystem.io/ "Zensystem.io"), [Quỹ Cardano] (https://cardanofoundation.org/ "cardanofoundation.org") và đại diện từ [[
Emurgo] (https://emurgo.io/ "Emurgo.io").

Michael Parsons, chairman of the Cardano Foundation, says: "Coming to Lisbon for the IOHK Global Summit was a rewarding experience on many levels, work, social, and cultural. I had great conversations with many IOHK executives and technology leads and enjoyed participating in a group Cardano webcast. IOHK organized a scenic Lisbon city tour followed by a chance to sample the local Portuguese cuisine, the fresh sea bass was spectacular! All in all, an impressive and worthwhile event expertly coordinated by IOHK, our development partners; I look forward to the next one."

Michael Parsons, Chủ tịch Quỹ Cardano, nói: "Đến Lisbon cho Hội nghị thượng đỉnh toàn cầu IOHK là một kinh nghiệm bổ ích ở nhiều cấp độ, công việc, xã hội và văn hóa. Tôi đã có những cuộc trò chuyện tuyệt vời với nhiều giám đốc điều hành và công nghệ IOHK và thích tham gia
Một nhóm webcast của Cardano. IOHK đã tổ chức một chuyến lưu diễn Lisbon City tuyệt đẹp, sau đó là cơ hội để nếm thử các món ăn Bồ Đào Nha địa phương, The Fresh Sea Bass thật ngoạn mục!
Chuyển tiếp đến cái tiếp theo. "

Emurgo had two representatives present in Lisbon. One of them, Shunsuke Murasaki, said it was a chance to talk to the software developers working on Cardano and provide a bridge to development teams in Vietnam and Taiwan working on future applications. "I found this week to be very educational and inspiring," he says. "Emurgo has good partnerships and we will provide technical updates to our partners on Cardano development to accelerate their activity."

Emurgo có hai đại diện có mặt tại Lisbon.
Một trong số họ, Shunuke Murasaki, cho biết đó là cơ hội để nói chuyện với các nhà phát triển phần mềm làm việc trên Cardano và cung cấp một cầu nối cho các nhóm phát triển ở Việt Nam và Đài Loan làm việc trên các ứng dụng trong tương lai.
"Tôi thấy trong tuần này là rất giáo dục và truyền cảm hứng", ông nói.
"Emurgo có quan hệ đối tác tốt và chúng tôi sẽ cung cấp các bản cập nhật kỹ thuật cho các đối tác của chúng tôi về phát triển Cardano để tăng tốc hoạt động của họ."

For Eileen Fitzgerald, Head of Programs, the week focused on everything from looking at software development methodology to having conversations with new people. "It was great to have everyone finally agreeing on where we are going, consolidating on how we are moving Plutus forward and the K Framework, the Daedalus roadmap, resources, and the direction for the next year," she says. She spent time developing the project management office, which she believes is the only project management office in the world focusing on blockchain development. 

Đối với Eileen Fitzgerald, người đứng đầu các chương trình, tuần này tập trung vào tất cả mọi thứ, từ nhìn vào phương pháp phát triển phần mềm đến có cuộc trò chuyện với những người mới.
"Thật tuyệt vời khi mọi người cuối cùng đồng ý về nơi chúng tôi sẽ đến, củng cố cách chúng tôi di chuyển Plutus về phía trước và khung K, lộ trình Daedalus, tài nguyên và hướng đi cho năm tới," cô nói.
Cô đã dành thời gian phát triển văn phòng quản lý dự án, mà cô tin là văn phòng quản lý dự án duy nhất trên thế giới tập trung vào phát triển blockchain.

Of course, the week was a lovely reminder of how far we've come in the little over two years since the company was founded. More than 100 people working on IOHK projects were in Lisbon. That compares to about 35 people who were at the last meet up, in Malta. And the time before that, in Riga, we numbered fewer than 20 people. IOHK is now a much bigger organization and has recently been doing a lot of work to reshape its structure to adapt to having more people, more moving parts, and more projects. 

Tất nhiên, tuần là một lời nhắc nhở đáng yêu về việc chúng ta đã đi được bao xa trong hơn hai năm kể từ khi công ty được thành lập.
Hơn 100 người làm việc trong các dự án IOHK đã ở Lisbon.
Điều đó so sánh với khoảng 35 người ở lần gặp cuối cùng, ở Malta.
Và thời gian trước đó, ở Riga, chúng tôi đã đánh số ít hơn 20 người.
IOHK hiện là một tổ chức lớn hơn nhiều và gần đây đã làm rất nhiều việc để định hình lại cấu trúc của nó để thích nghi với việc có nhiều người hơn, nhiều bộ phận cảm động hơn và nhiều dự án hơn.

![IOHK Team in Riga](img/2018-02-14-iohk-celebrates-a-successful-global-summit.011.jpeg) IOHK in Riga 2016

![IOHK Team in Malta](img/2018-02-14-iohk-celebrates-a-successful-global-summit.011.jpeg) IOHK in Malta 2017

![IOHK Team in Lisbon](img/2018-02-14-iohk-celebrates-a-successful-global-summit.011.jpeg) IOHK in Lisbon 2018

And in the presentation from Charles Hoskinson, he set out business objectives for the next year and for the long term. Highlighting IOHK's pioneering approach to open source software development and high assurance methods he laid out how IOHK has led the way in the cryptocurrency industry. 

Và trong phần trình bày từ Charles Hoskinson, ông đã đặt ra các mục tiêu kinh doanh trong năm tới và trong dài hạn.
Làm nổi bật phương pháp tiên phong của IOHK đối với phát triển phần mềm nguồn mở và các phương pháp đảm bảo cao, ông đã đưa ra cách IOHK dẫn đầu trong ngành công nghiệp tiền điện tử.

"We broke new ground by being first to embrace peer review, transforming cryptocurrency from something regarded as amateur and suspect by the academic community into a rapidly emerging area of study within cryptography."

"Chúng tôi đã phá vỡ nền tảng mới bằng cách đầu tiên nắm lấy đánh giá ngang hàng, biến tiền điện tử từ một thứ được coi là nghiệp dư và nghi ngờ bởi cộng đồng học thuật thành một lĩnh vực nghiên cứu đang nổi lên nhanh chóng trong mật mã."

And Cardano's position as IOHK's flagship product was acknowledged.

Và vị trí của Cardano là sản phẩm hàng đầu của IOHK đã được thừa nhận.

"If we pull it off, it becomes the financial stack for the developing world capable of handling three billion users. That's the goal of Cardano," he said. "That will require an enormous amount of good technology. We had to bring all these people together to build a project like this. Cardano is the best protocol in the world. In the coming months, Cardano will get better, feature richness will come, and it will be an incredible product."

"Nếu chúng tôi thực hiện nó, nó trở thành ngăn xếp tài chính cho thế giới đang phát triển có khả năng xử lý ba tỷ người dùng. Đó là mục tiêu của Cardano," ông nói.
"Điều đó sẽ đòi hỏi một lượng lớn công nghệ tốt. Chúng tôi đã phải kết hợp tất cả những người này lại với nhau để xây dựng một dự án như thế này. Cardano là giao thức tốt nhất trên thế giới. Trong những tháng tới, Cardano sẽ trở nên tốt hơn, sự phong phú tính năng sẽ đến,
Và nó sẽ là một sản phẩm đáng kinh ngạc. "

There was also time for relaxation, with several social outings, group dinners and a visit to the beautiful national park of [Sintra](https://en.wikipedia.org/wiki/Sintra "Sintra, Wikipedia"), all expertly organized along with the general program by Leonidas Tsagkalias, Costas Saragkas and Tamara Haasen. Conversations about work were never far away though! 

Cũng có thời gian để thư giãn, với một số buổi đi chơi xã hội, bữa tối nhóm và chuyến thăm công viên quốc gia xinh đẹp của [Sintra] (https://en.wikipedia.org/wiki/Sintra "Sintra, Wikipedia")
Cùng với chương trình chung của Leonidas Tsagkalias, Costas Saragkas và Tamara Haasen.
Cuộc trò chuyện về công việc không bao giờ xa!

I'm looking forward to the next IOHK company meet up where I'm sure there will be even more people in attendance, and we will be able to look back and take stock of even more groundbreaking research and development. IOHK has already begun to set the standard for cryptocurrencies and reshape the way the industry works, so get ready for more exciting developments during the year ahead.

Tôi đang mong chờ công ty IOHK tiếp theo gặp nhau, nơi tôi chắc chắn sẽ có nhiều người tham dự hơn, và chúng tôi sẽ có thể nhìn lại và lấy lại nghiên cứu và phát triển đột phá hơn nữa.
IOHK đã bắt đầu thiết lập tiêu chuẩn cho tiền điện tử và định hình lại cách thức hoạt động của ngành công nghiệp, vì vậy hãy sẵn sàng cho những phát triển thú vị hơn trong năm tới.

## **Attachments**

## ** tệp đính kèm **

![](img/2018-02-14-iohk-celebrates-a-successful-global-summit.004.png)[ IOHK celebrates a successful Global Summit - Input Output](https://ucarecdn.com/32cfa852-a7cc-46a8-a601-d0fea14aeb7c/-/inline/yes/ "IOHK celebrates a successful Global Summit - Input Output")

