# Research program to work on hardening Cardano against quantum computers
![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.002.png) 1 February 2018![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.003.png) 5 mins read

![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.004.png)[ Research program to work on hardening C](https://ucarecdn.com/86547eeb-3106-4ed6-8c90-f64997ec079c/-/inline/yes/ "Research program to work on hardening C")

![Charles Hoskinson](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.005.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.006.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.007.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.008.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Research program to work on hardening Cardano against quantum computers](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.009.jpeg)

At its heart, cryptography is the science of secure communication. We have all secrets, expectations of privacy and assertions of truth about messages we receive that require some notion of verification or quantification of trust. Cryptography provides us with a toolbox to better understand how to transmit and verify these artifacts of communication in the presence of an adversary. The challenge is that transmission mediums change and the capabilities of an adversary change with them. The earliest days of secret communication ranging from Caesar to the American Confederacy involved substitution ciphers and elegant physical devices to accommodate the decryption of messages.

![Caesar Cipher](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.010.png) 

A Caesar cipher substitution ([See Wiki for more details](https://en.wikipedia.org/wiki/Caesar_cipher "Caesar cipher, Wikipedia"))

Một sự thay thế mật mã Caesar ([xem wiki để biết thêm chi tiết] (https://en.wikipedia.org/wiki/caesar_codes "Caesar Mật mã, Wikipedia"))

The apex of these approaches was the Enigma machine used by the Nazis during World War Two.

Đỉnh cao của những cách tiếp cận này là cỗ máy bí ẩn được Đức quốc xã sử dụng trong Thế chiến thứ hai.

![Confederate Cipher](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.011.jpeg) 

A Confederate cipher wheel

Một bánh xe mật mã liên minh

As with all cryptographic algorithms, the security of such techniques is always dependent upon assumptions about the capabilities of the adversary. For example, interception of encrypted messages was a deeply personal affair involving finding the spy or messenger moving the scroll. With the invention of wireless communication, listening posts could easily collect all messages transmitted without the sender even knowing. 

Như với tất cả các thuật toán mật mã, tính bảo mật của các kỹ thuật như vậy luôn phụ thuộc vào các giả định về khả năng của đối thủ.
Ví dụ, việc đánh chặn các tin nhắn được mã hóa là một vấn đề cá nhân sâu sắc liên quan đến việc tìm kiếm gián điệp hoặc người đưa tin di chuyển cuộn giấy.
Với việc phát minh ra giao tiếp không dây, các bài nghe có thể dễ dàng thu thập tất cả các tin nhắn được truyền mà không cần người gửi thậm chí biết.

Decryption without the trusted hardware device, would require the adversary to have special knowledge and the ability to perform enormous amounts of calculations. The creation of the [Bombe](https://en.wikipedia.org/wiki/Bombe "Bombe, Wikipedia") at Bletchley Park made this task automated for the first time in human history.

Giải mã mà không có thiết bị phần cứng đáng tin cậy, sẽ yêu cầu kẻ thù có kiến thức đặc biệt và khả năng thực hiện một lượng lớn tính toán.
Việc tạo ra [Bombe] (https://en.wikipedia.org/wiki/bombe "Bombe, Wikipedia") tại Bletchley Park đã tự động nhiệm vụ này trong lịch sử loài người.

![Enigma Machine](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.012.jpeg) 

An Enigma machine

Một máy bí ẩn

The invention of computers and later the internet has fundamentally changed the entire field of cryptography. Human and transmission limitations as well as knowledge transfer are now such that cryptography had to transform from clever algorithms and [security through obscurity](https://en.wikipedia.org/wiki/Security_through_obscurity "Security through obscurity, Wikipedia") to a science assuming an increasingly more sophisticated adversary that is usually only constrained by physics and [mathematically hard problems](https://en.wikipedia.org/wiki/Computational_hardness_assumption "Computational hardness assumption, Wikipedia"). 

Việc phát minh ra máy tính và sau đó là internet đã thay đổi cơ bản toàn bộ lĩnh vực mật mã.
Hạn chế của con người và truyền tải cũng như chuyển giao kiến thức hiện nay là mật mã phải chuyển đổi từ các thuật toán thông minh và [bảo mật thông qua che khuất] (https://en.wikipedia.org/wiki/security_through_obscurity "
Khoa học giả định rằng một kẻ thù ngày càng tinh vi hơn thường chỉ bị hạn chế bởi vật lý và [các vấn đề khó khăn về mặt toán học] (https://en.wikipedia.org/wiki/computational_hardness_assime "Giả định độ cứng tính toán, wikipedia").

For the past few decades, weâ€™ve been converging into a reasonable model of security that is comfortable for internet connected devices. Usually security is no longer compromised by an unknown weakness in our ciphers, but rather a flaw in their use or implementation in software. 

Trong vài thập kỷ qua, chúng tôi đã hội tụ thành một mô hình bảo mật hợp lý thoải mái cho các thiết bị kết nối internet.
Thông thường bảo mật không còn bị tổn hại bởi một điểm yếu chưa biết trong các mật mã của chúng tôi, mà là một lỗ hổng trong việc sử dụng hoặc thực hiện trong phần mềm.

As much of a triumph this convergence is for the field of cryptography, like Bombe in the 1940s, we are now forced to contend with a new adversary capability: [quantum computation](https://www.youtube.com/watch?v=BYx04e35Xso "Quantum Computing Magic, YouTube"). 

Như một chiến thắng, sự hội tụ này dành cho lĩnh vực mật mã, như Bombe vào những năm 1940, chúng ta hiện đang buộc phải tranh luận với khả năng đối thủ mới: [Tính toán lượng tử] (https://www.youtube.com/watch?v
= BYX04E35XSO "Phép thuật điện toán lượng tử, YouTube").

![Bombe Computer](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.013.jpeg) 

Alan Turingâ€™s Bombe Computer at Bletchley Park

Máy tính Bombe của Alan Turing tại Công viên Bletchley

![Part of Google](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.012.jpeg) 

Part of [Googleâ€™s Quantum Computer](https://www.technologyreview.com/s/602283/googles-quantum-dream-may-be-just-around-the-corner/ "Google's Quantum Dream May Be Just Around the Corner, MIT Technology Review")

Một phần của máy tính lượng tử của [https://www.technologyreview.com/s/602283/googles-quantum-dream-may-be-just-around-the-corner/ "Giấc mơ lượng tử của Google có thể chỉ là
Xung quanh góc, Tạp chí Công nghệ MIT ")

Quantum computers seem to present the challenge that fundamentally hard problems which secure our modern cryptographic algorithms [may not be hard anymore](https://en.wikipedia.org/wiki/Shor%27s_algorithm "Shor's algorithm, Wikipedia"). Should this occur, most of the modern algorithms we use will have to be phased out and replaced with fundamentally different ones. Cryptocurrencies are consumers of these modern cryptographic algorithms from the simple, such as public key systems and hash functions, to the complex, such as zero knowledge proofs and multiparty computation. As there is an explicit and ever increasing bounty for breaking the security behind a cryptocurrency, the challenge for IOHK is to imagine how to provide long-term security in the face of future adversaries, including ones that possess quantum computers. 

Máy tính lượng tử dường như đưa ra thách thức về cơ bản các vấn đề khó khăn trong việc bảo vệ thuật toán mật mã hiện đại của chúng tôi [có thể không còn khó nữa]
Nếu điều này xảy ra, hầu hết các thuật toán hiện đại chúng ta sử dụng sẽ phải được loại bỏ và thay thế bằng các thuật toán khác nhau về cơ bản.
Tiền điện tử là người tiêu dùng của các thuật toán mật mã hiện đại này từ các hệ thống khóa công khai và các hàm băm, cho đến phức tạp, như bằng chứng kiến thức bằng không và tính toán nhiều bên.
Vì có một tiền thưởng rõ ràng và ngày càng tăng để phá vỡ sự bảo mật đằng sau một loại tiền điện tử, thách thức đối với IOHK là tưởng tượng làm thế nào để cung cấp bảo mật lâu dài khi đối mặt với các đối thủ trong tương lai, bao gồm cả những đối thủ sở hữu máy tính lượng tử.

Therefore, we have launched a long-term research agenda to gradually harden all algorithms used in Cardanoâ€™s protocol stack against an adversary who possesses a quantum computer. The first part of this agenda is to harden our consensus algorithm Ouroboros. 

Do đó, chúng tôi đã đưa ra một chương trình nghiên cứu dài hạn để dần dần làm cứng tất cả các thuật toán được sử dụng trong ngăn xếp giao thức của Cardano chống lại một kẻ thù sở hữu một máy tính lượng tử.
Phần đầu tiên của chương trình nghị sự này là làm cứng thuật toán đồng thuận của chúng tôi.

All good research agendas need strong leaders who have a proven record and thus we are extremely fortunate to anticipate the inclusion of Professor Alexander Russell of University of Connecticut, USA as a senior research fellow in IOHK research and an external collaboration with Assistant [Professor Peter Schwabe](https://cryptojedi.org/peter/index.shtml "cryptojedi.org") of Radboud University. They will play key roles in our first attempt at hardening the Ouroboros protocol for the post quantum setting.

Tất cả các chương trình nghiên cứu tốt đều cần các nhà lãnh đạo mạnh mẽ, những người có thành tích đã được chứng minh và do đó chúng tôi rất may mắn khi dự đoán được sự bao gồm của Giáo sư Alexander Russell của Đại học Connecticut, Hoa Kỳ là một nghiên cứu cao cấp trong nghiên cứu IOHK và hợp tác bên ngoài với Trợ lý [Giáo sư Peter Schwabe
] (https://cryptojedi.org/peter/index.shtml "cryptojedi.org") của Đại học Radboud.
Họ sẽ đóng vai trò quan trọng trong nỗ lực đầu tiên của chúng tôi trong việc làm cứng giao thức OuroBoros cho cài đặt lượng tử POST.

Professor Russell (Ph.D. MIT 1996) has a deep understanding of quantum computation that spans over two decades. His work on quantum computing has focused on algorithms for algebraic problems, intractability results, and quantum-secure cryptography. He was also one of the co-authors of the Ouroboros papers and thus the combination of his deep understanding of blockchain protocol security and his expertise of quantum computation and post-quantum security put him at a unique position to lead the effort of projecting Ouroboros to the post-quantum setting.

Giáo sư Russell (Tiến sĩ MIT 1996) có sự hiểu biết sâu sắc về tính toán lượng tử kéo dài hơn hai thập kỷ.
Công việc của ông về điện toán lượng tử đã tập trung vào các thuật toán cho các vấn đề đại số, kết quả khả năng gây khó chịu và mật mã an toàn lượng tử.
Anh ấy cũng là một trong những đồng tác giả của các bài báo Ouroboros và do đó, sự kết hợp giữa sự hiểu biết sâu sắc của anh ấy về bảo mật giao thức blockchain và chuyên môn về tính toán lượng tử và bảo mật sau Quartum đã đưa anh ấy vào một vị trí duy nhất để dẫn đầu nỗ lực dự kiến Ouroboros đến
Các thiết lập sau Quantum.

Professor Schwabe (Ph.D. Eindhoven 2011) is one of the rising stars of the field with contributions from his work on SPHINCS to lattice signatures such as Tesla and Dilithium. He is also participating in [NISTâ€™s competition](https://csrc.nist.gov/Projects/Post-Quantum-Cryptography "Post Quantum Cryptography, csrc.nist.gov") to harden the cryptographic algorithms used by the United States government against quantum computers.

Giáo sư Schwabe (Tiến sĩ Eindhoven 2011) là một trong những ngôi sao đang lên của lĩnh vực này với sự đóng góp từ công việc của ông về cơ thể cho các chữ ký mạng như Tesla và Dilithium.
Anh ấy cũng đang tham gia vào cuộc thi [https://csrc.nist.gov/projects/post-quantum-cryptography "Cryptography Post Quantum, CSRC.Nist.gov")
Chính phủ Hoa Kỳ chống lại máy tính lượng tử.

As this is long arc research, the output will be many papers, conference discussions and iterations; however, we are excited to start the process and conversation. It is our belief that over the next 50 years cryptocurrencies will become the standard way of representing and transacting value. 

Vì đây là nghiên cứu vòng cung dài, đầu ra sẽ là nhiều bài báo, thảo luận hội nghị và lặp lại;
Tuy nhiên, chúng tôi rất vui mừng để bắt đầu quá trình và cuộc trò chuyện.
Chúng tôi tin rằng trong 50 năm tiếp theo, tiền điện tử sẽ trở thành cách tiêu chuẩn để thể hiện và giao dịch giá trị.

Therefore, it is essential for us to proactively prepare our protocols against the threats of the future with the hope that Cardano can enjoy the durability that TCP/IP and other long-lived protocols have demonstrated. We also believe it is essential to structure the conversation within the cryptocurrency community to involve university partners and domain experts as soon as possible in order to avoid common mistakes, incomplete solutions, and have access to the best available knowledge. 

Do đó, điều cần thiết là chúng ta phải chủ động chuẩn bị các giao thức chống lại các mối đe dọa của tương lai với hy vọng Cardano có thể tận hưởng độ bền mà TCP/IP và các giao thức tồn tại lâu dài khác đã thể hiện.
Chúng tôi cũng tin rằng việc cấu trúc cuộc trò chuyện trong cộng đồng tiền điện tử là điều cần thiết là liên quan đến các đối tác và chuyên gia tên miền đại học càng sớm càng tốt để tránh những sai lầm phổ biến, giải pháp không đầy đủ và có quyền truy cập vào kiến thức tốt nhất.

In the short term, the first output of this workstream will be to choose and properly parameterize a post-quantum signature scheme for Ouroboros Praos as well as examining our protocol against the capabilities of an adversary in possession of a quantum computer. Our hope is that this work will be finished and implemented before the end of 2018 in Shelleyâ€™s first major upgrade.

Trong ngắn hạn, đầu ra đầu tiên của chương trình công trình này sẽ là chọn và tham số chính xác một sơ đồ chữ ký sau tứ chi cho Ouroboros PRAOS cũng như kiểm tra giao thức của chúng tôi đối với khả năng của một đối thủ trong việc sở hữu máy tính lượng tử.
Hy vọng của chúng tôi là công việc này sẽ được hoàn thành và thực hiện trước cuối năm 2018 trong bản nâng cấp lớn đầu tiên của Shelley.

## **Attachments**

## ** tệp đính kèm **

![](img/2018-02-01-research-program-to-work-on-hardening-cardano-against-quantum-computers.004.png)[ Research program to work on hardening C](https://ucarecdn.com/86547eeb-3106-4ed6-8c90-f64997ec079c/-/inline/yes/ "Research program to work on hardening C")

