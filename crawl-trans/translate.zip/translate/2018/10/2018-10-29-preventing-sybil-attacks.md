# Preventing Sybil attacks
![](img/2018-10-29-preventing-sybil-attacks.002.png) 29 October 2018![](img/2018-10-29-preventing-sybil-attacks.002.png)[ Lars Brünjes](tmp//en/blog/authors/lars-brunjes/page-1/)![](img/2018-10-29-preventing-sybil-attacks.003.png) 8 mins read

![Lars Brünjes](img/2018-10-29-preventing-sybil-attacks.004.png)[](tmp//en/blog/authors/lars-brunjes/page-1/)
### [**Lars Brünjes**](tmp//en/blog/authors/lars-brunjes/page-1/)
Education Director

Education

- ![](img/2018-10-29-preventing-sybil-attacks.005.png)[](mailto:lars.bruenjes@iohk.io "Email")
- ![](img/2018-10-29-preventing-sybil-attacks.006.png)[](https://www.linkedin.com/in/dr-lars-br%C3%BCnjes-1640993b "LinkedIn")
- ![](img/2018-10-29-preventing-sybil-attacks.007.png)[](https://twitter.com/LarsBrunjes "Twitter")
- ![](img/2018-10-29-preventing-sybil-attacks.008.png)[](https://github.com/brunjlar "GitHub")

![Preventing Sybil attacks](img/2018-10-29-preventing-sybil-attacks.009.jpeg)

Building on last week’s [post by Professor Aggelos Kiayias](tmp//en/blog/stake-pools-in-cardano/ "Stake pools in Cardano, iohk.io"), IOHK’s chief scientist, I want to use this post to discuss another choice we made when [designing Cardano’s reward mechanism](https://arxiv.org/pdf/1807.11218.pdf "Reward Sharing Schemes for Stake Pools, arxiv.org"). The mechanism is designed to give an [incentive to stakeholders](https://www.youtube.com/watch?v=2pdkIXDU1no&list=PLFLTrdAG7xRbAqhF3Tg8BeAea7Ard-ttn "Incentive Paper Lecture Series (Part 1), youtube.com") to ‘do the right thing’ and participate in the protocol in a way that ensures its smooth, efficient and secure operation. As was explained last week, to ensure fairness and decentralization, the rewards mechanism follows three principles:

Xây dựng trên bài tuần trước [bài của Giáo sư Aggelos Kiayias] (TMP // EN/Blog/Stake-Pools-in-Cardano/"Pools ở Cardano, Iohk.io"), Nhà khoa học trưởng của IOHK, tôi muốn sử dụng bài đăng này để
Thảo luận về một lựa chọn khác mà chúng tôi đã thực hiện khi [thiết kế cơ chế phần thưởng của Cardano] (https://arxiv.org/pdf/1807.11218.pdf "các chương trình chia sẻ phần thưởng cho nhóm cổ phần, arxiv.org").
Cơ chế được thiết kế để cung cấp [khuyến khích cho các bên liên quan] (https://www.youtube.com/watch?v=2PDKIXDU1NO&LIST=PLFLTRDAG7XRBAQHF3TG8BEAEA7
Điều đúng đắn 'và tham gia vào giao thức theo cách đảm bảo hoạt động trơn tru, hiệu quả và an toàn của nó.
Như đã được giải thích vào tuần trước, để đảm bảo sự công bằng và phân cấp, cơ chế phần thưởng tuân theo ba nguyên tắc:

- Total rewards for a stake pool should be proportional to the size of the pool until the pool reaches saturation.

- Tổng phần thưởng cho một nhóm cổ phần phải tỷ lệ thuận với kích thước của hồ bơi cho đến khi hồ bơi đạt đến độ bão hòa.

- Rewards inside a pool should be proportional to a pool member’s stake.

- Phần thưởng bên trong một hồ bơi phải tỷ lệ thuận với cổ phần của thành viên hồ bơi.

- Pool operators should get higher rewards for their efforts.

- Các nhà khai thác hồ bơi nên nhận được phần thưởng cao hơn cho những nỗ lực của họ.

One necessary modification deals with pool performance. If a pool operator neglects his ‘duties’ and does not create the blocks he is supposed to create, the pool rewards will decrease accordingly.

Một giao dịch sửa đổi cần thiết với hiệu suất nhóm.
Nếu một nhà điều hành hồ bơi bỏ qua nhiệm vụ của mình và không tạo ra các khối mà anh ta được cho là tạo ra, phần thưởng bể bơi sẽ giảm theo.

Take the example of Alice and Bob who run pools of equal sizes. They are both elected as slot leaders with 100 slots each. Alice dutifully creates all 100 blocks in the 100 slots she leads, whereas Bob misses 20 slots and only creates 80 blocks. In this case, Alice’s pool will get full rewards, whereas Bob’s pool will get less. How much less exactly is controlled by a parameter.

Lấy ví dụ về Alice và Bob, người điều hành các nhóm có kích thước bằng nhau.
Cả hai đều được bầu làm lãnh đạo khe với 100 khe.
Alice nghiêm túc tạo ra tất cả 100 khối trong 100 khe mà cô dẫn đầu, trong khi Bob bỏ lỡ 20 khe và chỉ tạo ra 80 khối.
Trong trường hợp này, hồ bơi Alice Alice sẽ nhận được phần thưởng đầy đủ, trong khi nhóm Bob Bob sẽ nhận được ít hơn.
Bao nhiêu ít chính xác được kiểm soát bởi một tham số.

## **The challenge**

## **Các thách thức**

In this post, I want to concentrate on another potential challenge to the Cardano principles and explain how we decided to overcome it. The challenge was mentioned at the end of last week’s post: *How do we prevent one person from creating dozens or even hundreds of small pools?*

Trong bài đăng này, tôi muốn tập trung vào một thử thách tiềm năng khác đối với các nguyên tắc Cardano và giải thích cách chúng tôi quyết định vượt qua nó.
Thử thách đã được đề cập vào cuối tuần trước, bài viết: *Làm thế nào để chúng ta ngăn chặn một người tạo ra hàng chục hoặc thậm chí hàng trăm hồ bơi nhỏ? *

Note that for very large stakeholders it is perfectly legitimate to split their stake into several pools to get a fair share of the rewards.

Lưu ý rằng đối với các bên liên quan rất lớn, việc chia cổ phần của họ thành một số hồ bơi là hoàn toàn hợp pháp để có được phần thưởng công bằng.

#### **An example of a Sybil attack**

#### ** Một ví dụ về một cuộc tấn công Sybil **

Let’s assume that we are aiming for 100 pools and therefore cap rewards at 1%. Let us further assume that Alice holds a 3.6% stake. If Alice does not split her stake, she will only get 1% of total rewards. If, however, Alice splits her stake, putting 0.9% into four different pools, her reward from each pool will not be capped.

Hãy để cho rằng chúng tôi đang nhắm đến 100 nhóm và do đó phần thưởng giới hạn ở mức 1%.
Chúng ta hãy giả sử thêm rằng Alice nắm giữ 3,6% cổ phần.
Nếu Alice không chia cổ phần của mình, cô sẽ chỉ nhận được 1% tổng phần thưởng.
Tuy nhiên, nếu Alice chia cổ phần của mình, đặt 0,9% vào bốn nhóm khác nhau, phần thưởng của cô ấy từ mỗi hồ bơi sẽ không được giới hạn.

The challenge arises if a small but devious stakeholder is allowed to create a large number of pools (possibly under assumed identities). If he manages to attract people to these pools (for example by lying about his costs and promising high rewards to pool members), he might end up controlling a majority stake with very little personal stake in the system. How could this happen? 

Thách thức phát sinh nếu một bên liên quan nhỏ nhưng lệch lạc được phép tạo ra một số lượng lớn các hồ bơi (có thể theo danh tính giả định).
Nếu anh ta quản lý để thu hút mọi người vào các nhóm này (ví dụ bằng cách nói dối về chi phí của anh ta và hứa hẹn nhiều phần thưởng cho các thành viên nhóm), anh ta có thể kiểm soát phần lớn cổ phần với rất ít cổ phần cá nhân trong hệ thống.
Làm sao điều này xảy ra được?

Let’s imagine that there are about 100 legitimate, honest pools. If we didn’t guard against it, a malicious player could relatively cheaply create 100, 200 or even 500 pools under false names and claim low operational costs and a low profit margin. Many honest stakeholders would then be tempted to stop delegating to one of the 100 honest pools and instead delegate their stake to one of themalicious pools, which might outnumber the honest pools. As a consequence, the operator of those malicious pools would be selected slot leader for a majority of blocks and so gain control over the blockchain, opening it up to all kinds of mischief and criminal activities, such as double-spending attacks! He would, of course, have to pay for the operation of hundreds of nodes, but that cost pales in comparison with the cost of acquiring a majority stake by buying the majority of all the Ada in existence, which would be in the range of hundreds of millions to billions of dollars.

Hãy để tưởng tượng rằng có khoảng 100 hồ bơi trung thực, hợp pháp.
Nếu chúng tôi không bảo vệ chống lại nó, một người chơi độc hại có thể tạo ra 100, 200 hoặc thậm chí 500 nhóm dưới tên giả và yêu cầu chi phí hoạt động thấp và tỷ suất lợi nhuận thấp.
Nhiều bên liên quan trung thực sau đó sẽ bị cám dỗ ngừng ủy thác cho một trong 100 hồ bơi trung thực và thay vào đó ủy thác cổ phần của họ cho một trong những nhóm chủ đề, có thể vượt xa các hồ bơi trung thực.
Kết quả là, nhà điều hành các nhóm độc hại đó sẽ được chọn là người lãnh đạo khe trong phần lớn các khối và do đó có được quyền kiểm soát blockchain, mở ra tất cả các loại hoạt động phạm tội và tội phạm, chẳng hạn như các cuộc tấn công chi tiêu kép!
Tất nhiên, anh ta sẽ phải trả tiền cho hoạt động của hàng trăm nút, nhưng chi phí đó so với chi phí mua lại phần lớn cổ phần bằng cách mua phần lớn tất cả các ADA tồn tại, trong phạm vi hàng trăm
của hàng triệu đến hàng tỷ đô la.

This would be disastrous because the security of a proof-of-stake system like Cardano relies on the idea that people with a lot of influence over the system should hold a lot of stake and therefore have every reason to help the system run smoothly.

Điều này sẽ là thảm họa vì sự bảo mật của một hệ thống chứng minh như Cardano dựa vào ý tưởng rằng những người có nhiều ảnh hưởng đối với hệ thống nên nắm giữ rất nhiều cổ phần và do đó có mọi lý do để giúp hệ thống hoạt động trơn tru.

## **Our solution**

## ** Giải pháp của chúng tôi **

This type of attack, where the attacker assumes many identities, is called a Sybil attack, named after the 1973 novel Sybil by Flora Rheta Schreiber about a woman suffering from multiple personality disorder.

Kiểu tấn công này, trong đó kẻ tấn công giả định nhiều danh tính, được gọi là một cuộc tấn công của Sybil, được đặt theo tên của tiểu thuyết Sybil năm 1973 của Flora Rheta Schreiber về một người phụ nữ mắc chứng rối loạn đa nhân cách.

How can we prevent Sybil attacks?

Làm thế nào chúng ta có thể ngăn chặn các cuộc tấn công Sybil?

One idea might be to make pool registration very expensive. But to prevent attacks, such fees would need to be extremely high and would prevent honest people from creating legitimate pools. Such a hurdle would be bad for decentralization; we want to encourage members of our community to start their own pools and not hinder their entry! There does have to be a modest fee for the simple reason that each registration certificate has to be stored on the blockchain and will consume resources, which have to be paid for.

Một ý tưởng có thể là làm cho đăng ký hồ bơi rất tốn kém.
Nhưng để ngăn chặn các cuộc tấn công, các khoản phí như vậy sẽ cần phải cực kỳ cao và sẽ ngăn chặn những người trung thực tạo ra các hồ bơi hợp pháp.
Một rào cản như vậy sẽ là xấu cho sự phân cấp;
Chúng tôi muốn khuyến khích các thành viên trong cộng đồng của chúng tôi bắt đầu nhóm của riêng họ và không cản trở mục nhập của họ!
Phải có một khoản phí khiêm tốn vì lý do đơn giản là mỗi chứng chỉ đăng ký phải được lưu trữ trên blockchain và sẽ tiêu thụ tài nguyên, phải được thanh toán.

Our [game theoretical analysis](https://arxiv.org/pdf/1807.11218.pdf "Reward Sharing Schemes for Stake Pools, arxiv.org") led us to a different solution, one that won’t bar ‘small’ stakeholders from starting their own pools by burdening them with prohibitively high fees and a high financial risk.

[Phân tích lý thuyết trò chơi của chúng tôi] (https://arxiv.org/pdf/1807.11218.pdf "Các chương trình chia sẻ phần thưởng cho nhóm cổ phần, arxiv.org") đã đưa chúng tôi đến một giải pháp khác
Từ việc bắt đầu hồ bơi của riêng họ bằng cách gánh nặng cho họ với mức phí cao và rủi ro tài chính cao.

*When registering a pool, the pool operator can decide to ‘pledge’ some of his personal stake to the pool. Pledging more will slightly increase the potential rewards of his pool.*

*Khi đăng ký một hồ bơi, nhà điều hành hồ bơi có thể quyết định ‘cam kết một số cổ phần cá nhân của mình vào hồ bơi.
Cam kết nhiều hơn sẽ làm tăng nhẹ phần thưởng tiềm năng của hồ bơi của anh ấy.*

This means that pools whose operators have pledged a lot of stake will be a little bit more attractive. So, if an attacker wants to create dozens of pools, he will have to split his personal stake into many parts, making all of his many pools less attractive, thereby causing people to delegate to pools run by honest stakeholders instead.

Điều này có nghĩa là các hồ bơi có nhà khai thác đã cam kết rất nhiều cổ phần sẽ hấp dẫn hơn một chút.
Vì vậy, nếu một kẻ tấn công muốn tạo ra hàng chục hồ bơi, anh ta sẽ phải chia cổ phần cá nhân của mình thành nhiều phần, khiến tất cả các hồ bơi của anh ta trở nên kém hấp dẫn hơn, do đó khiến mọi người phải ủy thác các nhóm được điều hành bởi các bên liên quan trung thực.

In other words, an attacker who creates a large number of pools will have to spread himself too thinly. He can’t make all of his many pools attractive, because he has to split his stake into too many parts. Honest pool operators will bundle all their personal stake into their one pool, thus having a much better chance of attracting members.

Nói cách khác, một kẻ tấn công tạo ra một số lượng lớn các hồ bơi sẽ phải tự lan rộng quá mỏng.
Anh ấy có thể làm cho tất cả các hồ bơi của mình hấp dẫn, bởi vì anh ấy phải chia cổ phần của mình thành quá nhiều phần.
Các nhà khai thác hồ bơi trung thực sẽ gói tất cả cổ phần cá nhân của họ vào một nhóm của họ, do đó có cơ hội thu hút các thành viên tốt hơn nhiều.

The degree of influence a pool operator’s pledged stake has on pool rewards can be fine-tuned by a configurable parameter. Being a bunch of mathematicians with little imagination, we called this parameter ‘a0’. (A colleague suggested the Greek letter phi because it sounds like part of the nasty giant’s chant in Jack and the Beanstalk – ‘Fee-fo-fi-fum’ – and we’re trying to ward off harmful stake pool giants, but we’d be grateful to any member of the community who can come up with a good name!).

Mức độ ảnh hưởng của một nhà điều hành hồ bơi, cổ phần đã cam kết trên các phần thưởng nhóm có thể được điều chỉnh bằng một tham số có thể định cấu hình.
Là một nhóm các nhà toán học với rất ít trí tưởng tượng, chúng tôi đã gọi tham số này ‘A0.
.
D Hãy biết ơn bất kỳ thành viên nào trong cộng đồng, những người có thể nghĩ ra một cái tên tốt!).

Setting a0 to zero would mean: ‘Pool rewards do not depend on the operator’s pledged stake.’ Picking a high value for a0 would result in a strong advantage for pool operators who pledge a lot of stake to their pools.

Đặt A0 thành 0 có nghĩa là: Phần thưởng Pool không phụ thuộc vào người vận hành, đã cam kết cổ phần. Việc chọn giá trị cao cho A0 sẽ mang lại lợi thế mạnh mẽ cho các nhà khai thác nhóm cam kết nhiều cổ phần cho nhóm của họ.

We have a classical trade-off here, between fairness and an even playing field on the one hand (a0 = 0) and security and Sybil-attack protection on the other hand (a0 is large).

Chúng tôi có một sự đánh đổi cổ điển ở đây, giữa sự công bằng và một sân chơi thậm chí một mặt (A0 = 0) và mặt khác là bảo vệ an ninh và sybil-tấn công (A0 là lớn).

To demonstrate the effect of a0, let’s look at the three graphs in Figure 1.

Để chứng minh ảnh hưởng của A0, hãy để Lôi nhìn vào ba biểu đồ trong Hình 1.

![](img/2018-10-29-preventing-sybil-attacks.010.png) 

Figure 1. How a pool operator’s pledged stake affects pool rewards.

Hình 1. Làm thế nào một nhà điều hành hồ bơi đã cam kết cổ phần ảnh hưởng đến phần thưởng bể bơi.

In the graphs, we are aiming for ten pools, so rewards will be capped at 10%. The size of the pool stake is plotted on the horizontal axis and the vertical axis shows pool rewards. Each graph depicts three hypothetical pools, where the operators have pledged 0%, 5% and 8% respectively to their pools (the pledged amount is called s in the graphs).

Trong các biểu đồ, chúng tôi đang nhắm đến mười nhóm, vì vậy phần thưởng sẽ được giới hạn ở mức 10%.
Kích thước của cổ phần hồ bơi được vẽ trên trục ngang và trục dọc hiển thị phần thưởng Pool.
Mỗi biểu đồ mô tả ba nhóm giả thuyết, trong đó các nhà khai thác đã cam kết lần lượt là 0%, 5% và 8% với nhóm của họ (số lượng cam kết được gọi là S trong biểu đồ).

The first graph uses a0 = 0, so the pledged stake has no influence on pool rewards, and the three pools behave in the same way: rewards keep climbing as the pool size grows until they are capped when the pool controls 10% of the stake.

Biểu đồ đầu tiên sử dụng A0 = 0, do đó, cổ phần đã cam kết không ảnh hưởng đến phần thưởng bể bơi và ba hồ bơi hoạt động theo cùng một cách: phần thưởng tiếp tục leo lên khi kích thước hồ bơi phát triển cho đến khi chúng được giới hạn khi hồ bơi kiểm soát 10% cổ phần
.

In the second graph, we see the effect of a0 = 0.1. The three pools are still similar, especially for small sizes, but they are capped at slightly different values. Pools with more pledged stake enjoy slightly higher rewards when they grow bigger.

Trong biểu đồ thứ hai, chúng ta thấy hiệu ứng của A0 = 0,1.
Ba nhóm vẫn giống nhau, đặc biệt là đối với các kích thước nhỏ, nhưng chúng được giới hạn ở các giá trị hơi khác nhau.
Các hồ bơi với cổ phần cam kết nhiều hơn được hưởng phần thưởng cao hơn một chút khi chúng phát triển lớn hơn.

Finally, the third graph shows the effect of a0 = 0.5. It is similar to the second graph, but the differences between the three pools are more pronounced. We still have to choose a “good” value for a0. This choice will depend on quantities such as expected operational pool costs, total rewards and – most importantly – the desired level of security.

Cuối cùng, biểu đồ thứ ba cho thấy hiệu ứng của A0 = 0,5.
Nó tương tự như biểu đồ thứ hai, nhưng sự khác biệt giữa ba nhóm rõ rệt hơn.
Chúng tôi vẫn phải chọn một giá trị tốt của người Viking cho A0.
Sự lựa chọn này sẽ phụ thuộc vào số lượng như chi phí nhóm hoạt động dự kiến, tổng phần thưởng và - quan trọng nhất - mức độ bảo mật mong muốn.

We will want to keep a0 as small as possible, while still guaranteeing high levels of security against Sybil attacks.

Chúng tôi sẽ muốn giữ A0 càng nhỏ càng tốt, trong khi vẫn đảm bảo mức độ bảo mật cao chống lại các cuộc tấn công của Sybil.

In any case, it is important to keep in mind that the introduction of a0 does not prevent ‘small’ stakeholders from running successful pools because somebody with a great idea can always reach out to the community, convince others and invite them to work together and pool resources to pledge to the pool. In the end, running a solid, reliable pool and working closely with the community will be more important than just owning a lot of stake.

Trong mọi trường hợp, điều quan trọng là phải nhớ rằng việc giới thiệu A0 không ngăn cản các bên liên quan 'nhỏ' điều hành các nhóm thành công vì ai đó có ý tưởng tuyệt vời luôn có thể tiếp cận với cộng đồng, thuyết phục người khác và mời họ làm việc cùng nhau và
Tài nguyên hồ bơi để cam kết với hồ bơi.
Cuối cùng, điều hành một nhóm vững chắc, đáng tin cậy và hợp tác chặt chẽ với cộng đồng sẽ quan trọng hơn là chỉ sở hữu rất nhiều cổ phần.

We have also started thinking about replacing the dependency of rewards on the pool leader’s stake with a reputation system. This would allow people with little stake to make their pools more attractive by running their pools reliably and efficiently over a long period of time. This won’t be implemented in the first iteration, but is on the table for future versions of Cardano.

Chúng tôi cũng đã bắt đầu suy nghĩ về việc thay thế sự phụ thuộc của phần thưởng vào cổ phần của người lãnh đạo nhóm bằng một hệ thống danh tiếng.
Điều này sẽ cho phép những người có ít cổ phần để làm cho hồ bơi của họ hấp dẫn hơn bằng cách điều hành hồ bơi của họ một cách đáng tin cậy và hiệu quả trong một thời gian dài.
Điều này đã được thực hiện trong lần lặp đầu tiên, nhưng nằm trên bàn cho các phiên bản tương lai của Cardano.

You might also like to read the IOHK technical report [‘Design Specification for Delegation and Incentives in Cardano’](https://hydra.iohk.io/build/790053/download/1/delegation_design_spec.pdf "Delegation Design Spec, iohk.io") for a broader, more detailed description of the system.

Bạn cũng có thể muốn đọc Báo cáo kỹ thuật IOHK ['Đặc tả thiết kế cho phái đoàn và ưu đãi trong Cardano'] (https://hydra.iohk.io/build/790053/doad/1/delegation_design_spec.pdf "
.io ") cho một mô tả rộng hơn, chi tiết hơn về hệ thống.

*On Monday, 5 November, IOHK will hold an AMA (Ask Me Anything) on staking in Cardano, where anyone will have the opportunity to put questions to the IOHK team. Details of the AMA will be announced soon.*

*Vào thứ Hai, ngày 5 tháng 11, IOHK sẽ tổ chức một AMA (hỏi tôi bất cứ điều gì) về việc đặt chỗ ở Cardano, nơi bất cứ ai sẽ có cơ hội đặt câu hỏi cho nhóm IOHK.
Chi tiết về AMA sẽ sớm được công bố.*

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2018-10-29-preventing-sybil-attacks.011.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

