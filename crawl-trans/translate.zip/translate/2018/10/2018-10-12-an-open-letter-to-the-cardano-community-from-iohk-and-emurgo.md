# An Open Letter to the Cardano Community from IOHK and Emurgo
### **A joint statement from Charles Hoskinson and Ken Kodama**
![](img/2018-10-12-an-open-letter-to-the-cardano-community-from-iohk-and-emurgo.002.png) 12 October 2018![](img/2018-10-12-an-open-letter-to-the-cardano-community-from-iohk-and-emurgo.002.png)[ IOHK and Emurgo](tmp//en/blog/authors/iohk-emurgo/page-1/)![](img/2018-10-12-an-open-letter-to-the-cardano-community-from-iohk-and-emurgo.003.png) 14 mins read

![IOHK and Emurgo](img/2018-10-12-an-open-letter-to-the-cardano-community-from-iohk-and-emurgo.004.png)[](tmp//en/blog/authors/iohk-emurgo/page-1/)
### [**IOHK and Emurgo**](tmp//en/blog/authors/iohk-emurgo/page-1/)
To the Cardano Community, Cardano is an amazingly diverse and vibrant project that is rightfully being recognised throughout the world. Our community contains tens of thousands of engaged and passionate volunteers, advocates, contributors and fans in countries ranging from Argentina to Zimbabwe. This growth is due to our commitment to innovation, transparency, balance of power and embracing the scientific community. To IOHK and Emurgo, [Cardano](https://github.com/input-output-hk/cardano-sl "Cardano SL, github.com") is so much more than a product we work on. Cardano is a mission to deliver a financial operating system to the three billion people who do not have one.

Đối với cộng đồng Cardano, Cardano là một dự án đa dạng và sôi động đáng kinh ngạc đang được công nhận trên toàn thế giới.
Cộng đồng của chúng tôi chứa hàng chục ngàn tình nguyện viên, người ủng hộ, người đóng góp và người hâm mộ tham gia và đam mê từ Argentina đến Zimbabwe.
Sự tăng trưởng này là do cam kết của chúng tôi đối với sự đổi mới, minh bạch, cân bằng quyền lực và nắm lấy cộng đồng khoa học.
Đến IOHK và Emurgo, [Cardano] (https://github.com/input-oundput-hk/cardano-sl "cardano sl, github.com") không chỉ là một sản phẩm chúng tôi làm việc.
Cardano là một nhiệm vụ cung cấp một hệ điều hành tài chính cho ba tỷ người không có.

As with all movements, occasionally issues occur that require careful and rational discussion. When the Cardano movement began in 2015, instead of launching an all-powerful foundation that would raise funds, manage development, encourage adoption and address the concerns of the community, we diligently split the governance of Cardano into three legal entities: [IOHK](https://iohk.io "iohk.io"), [Emurgo](https://emurgo.io "emurgo.io") and the [Cardano Foundation](https://cardanofoundation.org "cardanofoundation.org"). This separation of powers was to ensure that the failure of one legal entity, if any, could not jeopardise or destroy the [Cardano project](https://cardanoroadmap.com "Cardano Roadmap").

Như với tất cả các phong trào, đôi khi các vấn đề xảy ra đòi hỏi thảo luận cẩn thận và hợp lý.
Khi phong trào Cardano bắt đầu vào năm 2015, thay vì ra mắt một nền tảng toàn năng sẽ gây quỹ, quản lý phát triển, khuyến khích việc áp dụng và giải quyết các mối quan tâm của cộng đồng, chúng tôi siêng năng chia quản trị của Cardano thành ba thực thể pháp lý: [IOHK] (
https://iohk.io "iohk.io"), [Emurgo] (https://emurgo.io "Emurgo.io") và [Quỹ Cardano] (https://cardanofoundation.org "Cardanofound.org"
).
Sự tách biệt của quyền hạn này là để đảm bảo rằng sự thất bại của một thực thể pháp lý, nếu có, không thể gây nguy hiểm hoặc phá hủy [dự án Cardano] (https://cardanoroadmap.com "Lộ trình Cardano").

### **IOHK and Emurgo**

### ** iohk và emurgo **

IOHKâ€™s primary responsibility was and continues to be, developing the core collection of protocols that compose [Cardano](https://cardano.org "cardano.org"), from academic inception to applying formal methods to verify correct implementation. This task is enormous in scope and has led to the creation of three research centers, many peer reviewed papers, engagement with half a dozen development firms and one of the most active cryptocurrency GitHub repositories.

Trách nhiệm chính của IOHK là và tiếp tục, phát triển bộ sưu tập các giao thức cốt lõi sáng tác [Cardano] (https://cardano.org "cardano.org"), từ khi bắt đầu học tập đến áp dụng các phương pháp chính thức để xác minh chính xác.
Nhiệm vụ này là rất lớn về phạm vi và đã dẫn đến việc tạo ra ba trung tâm nghiên cứu, nhiều bài báo đánh giá ngang hàng, tham gia với nửa tá công ty phát triển và là một trong những kho lưu trữ github tiền điện tử tích cực nhất.

As a company that accepts its critical role in this effort, IOHK has attempted to be as transparent and focused as possible. That acceptance is why we launched the Cardano Roadmap website, produce many videos on our [IOHK YouTube channel](https://www.youtube.com/channel/UCBJ0p9aCW-W82TwNM-z3V2w "IOHK, youtube.com"), publish a weekly technical report, have dedicated project managers who produce videos on progress, hold special events and have AMA (Ask Me Anything) sessions.

Là một công ty chấp nhận vai trò quan trọng của mình trong nỗ lực này, IOHK đã cố gắng trở nên minh bạch và tập trung nhất có thể.
Sự chấp nhận đó là lý do tại sao chúng tôi đã ra mắt trang web Lộ trình Cardano, tạo ra nhiều video trên [Kênh YouTube [iohk] của chúng tôi (https://www.youtube.com/channel/ucbj0p9acw-w82twnm-z3v2w "
Báo cáo kỹ thuật hàng tuần, có các nhà quản lý dự án chuyên dụng sản xuất video về tiến trình, tổ chức các sự kiện đặc biệt và có các phiên AMA (hỏi tôi bất cứ điều gì).

Emurgo has been responsible for building partnerships with developers and instigating projects for the Cardano protocol around the world. Emurgo has grown from a small entity of just a few employees to a multinational effort with an ever-increasing investment portfolio.

Emurgo đã chịu trách nhiệm xây dựng quan hệ đối tác với các nhà phát triển và xúi giục các dự án cho giao thức Cardano trên toàn thế giới.
Emurgo đã phát triển từ một thực thể nhỏ chỉ một vài nhân viên thành một nỗ lực đa quốc gia với một danh mục đầu tư ngày càng tăng.

Emurgo has been collaborating with IOHK on products such as the [Yoroi wallet](https://yoroiwallet.com/ "yoroiwallet.com"), improving the developer experience for smart contracts and DApps, and holding discussions on high-value markets to drive adoption, as well as other efforts within its mandate. These collaborations will continue to grow and become even more meaningful as we move into 2019, with Cardano achieving decentralization, multi-asset accounting and full smart contract support.

Emurgo đã hợp tác với IOHK trên các sản phẩm như [ví Yoroi] (https://yoroiwallet.com/ "yoroiwallet.com"), cải thiện trải nghiệm của nhà phát triển đối với các hợp đồng thông minh và DAPPS và tổ chức các cuộc thảo luận trên thị trường có giá trị cao để đến với các thị trường cao cấp cao để đến thị trường có giá trị cao để
thúc đẩy việc áp dụng, cũng như các nỗ lực khác trong nhiệm vụ của nó.
Những sự hợp tác này sẽ tiếp tục phát triển và thậm chí còn trở nên có ý nghĩa hơn khi chúng ta chuyển sang năm 2019, với Cardano đạt được sự phân cấp, kế toán đa tài sản và hỗ trợ hợp đồng thông minh đầy đủ.

This acceptance of its role is also why IOHK has retained firms such as [Quviq](tmp//en/blog/functional-correctness-with-the-haskell-masters/ "Functional Correctness with the Haskell Masters"), [Tweag](https://www.tweag.io/ "tweag.io") and [Runtime Verification](https://paymentweek.com/2018-7-30-iohk-launches-iele-virtual-machine-testnet-cardano-blockchain/ "VM Testnet, paymentweek.com") to help build Cardano, refine processes and speed up development. Our collective development efforts have resulted in three codebases (Scala, Haskell and Rust), some of the first examples of applied formal methods with our new wallet backend and incredibly sophisticated techniques for modeling performance and reliability with deployed distributed systems.

Sự chấp nhận vai trò của nó cũng là lý do tại sao IOHK đã giữ lại các công ty như [Quviq] (TMP // EN/Blog/Chức năng-Sửa đổi-với-The Haskell-Masters/"Chức năng chính xác với các chủ đề Haskell"), [Tweag]
.
-Blockchain/ "VM testnet, payaguchweek.com") để giúp xây dựng cardano, tinh chỉnh các quy trình và tăng tốc độ phát triển.
Những nỗ lực phát triển tập thể của chúng tôi đã dẫn đến ba cơ sở mã (Scala, Haskell và Rust), một số ví dụ đầu tiên về các phương pháp chính thức được áp dụng với phụ trợ ví mới của chúng tôi và các kỹ thuật cực kỳ tinh vi để mô hình hóa hiệu suất và độ tin cậy với các hệ thống phân tán được triển khai.

Finally, our protocols are based on scientific inquiry. Such work should be done by scientists who have the requisite domain experience and wisdom. Thus we have directly engaged leaders in their respective fields with years to decades of experience to write our foundational papers. We have also vetted these papers through the peer review process accepted by the computer science community.

Cuối cùng, các giao thức của chúng tôi dựa trên yêu cầu khoa học.
Công việc như vậy nên được thực hiện bởi các nhà khoa học có kinh nghiệm và trí tuệ cần thiết.
Do đó, chúng tôi đã trực tiếp tham gia các nhà lãnh đạo trong các lĩnh vực tương ứng của họ với nhiều năm kinh nghiệm để viết các bài báo nền tảng của chúng tôi.
Chúng tôi cũng đã xem xét các bài báo này thông qua quy trình đánh giá ngang hàng được chấp nhận bởi cộng đồng khoa học máy tính.

Like every other project, IOHKâ€™s efforts arenâ€™t without their flaws and setbacks. The initial release of Cardano wasnâ€™t perfect. There were many issues ranging from some users having difficulty connecting to peers, to exchanges having trouble with the Cardano wallet. These teething problems are expected to be solved with all new codebases. However, the most important observation is that IOHK has never accepted any status quo and continues to work diligently to improve the code, the userâ€™s experience and broaden the utility of Cardano.

Giống như mọi dự án khác, những nỗ lực của IOHK không có sai sót và thất bại của họ.
Bản phát hành ban đầu của Cardano không hoàn hảo.
Có nhiều vấn đề từ một số người dùng gặp khó khăn trong việc kết nối với các đồng nghiệp, đến việc trao đổi gặp rắc rối với ví Cardano.
Những vấn đề mọc răng này dự kiến sẽ được giải quyết với tất cả các cơ sở mã mới.
Tuy nhiên, quan sát quan trọng nhất là IOHK chưa bao giờ chấp nhận bất kỳ hiện trạng nào và tiếp tục hoạt động siêng năng để cải thiện mã, trải nghiệm của người dùng và mở rộng tiện ích của Cardano.

Like IOHK, Emurgo has had its own challenges. Navigating 2017 â€“ during a period of utterly irrational valuations, ICO mania, many poorly led ventures as well as continued regulatory uncertainty â€“ was difficult. As with all ventures, staffing a great executive team is also a tremendous task. But as 2018 comes to a close, Emurgo has retained some [great talent](https://emurgo.io/about/ "emurgo.io") such as their CTO Nicolas Arqueros, chief investment officer Manmeet Singh, and one of our communityâ€™s best educators, Sebastien Guillemot. Emurgoâ€™s collaborations with IOHK have been both meaningful and productive.

Giống như IOHK, Emurgo đã có những thử thách riêng.
Điều hướng năm 2017 - Trong một thời gian định giá hoàn toàn không hợp lý, ICO Mania, nhiều dự án liên doanh được dẫn dắt kém cũng như tiếp tục không chắc chắn theo quy định - rất khó khăn.
Như với tất cả các dự án, nhân viên một đội ngũ điều hành tuyệt vời cũng là một nhiệm vụ to lớn.
Nhưng khi năm 2018 kết thúc, Emurgo đã giữ lại một số [tài năng lớn] (https://emurgo.io/about/ "Emurgo.io") như CTO Nicolas Arqueros của họ, Giám đốc đầu tư Manmeet Singh và một trong những
Các nhà giáo dục giỏi nhất của cộng đồng, Sebastien Guillemot.
Sự hợp tác của Emurgo với IOHK vừa có ý nghĩa và hiệu quả.

### **Cardano Foundation**

### ** Quỹ Cardano **

The Cardano Foundation was created to promote the Cardano protocol, to grow and inform our community and address the needs of the community. These are broad aims and cross demographics and borders.

Quỹ Cardano được tạo ra để quảng bá giao thức Cardano, để phát triển và thông báo cho cộng đồng của chúng tôi và giải quyết các nhu cầu của cộng đồng.
Đây là những mục tiêu rộng và nhân khẩu học chéo và biên giới.

Being more specific about the needs of the Cardano community, all cryptocurrency communities need accurate, timely and comprehensive information about events, technology and progress of the ecosystem. All cryptocurrency communities need stable and moderated forums to discuss their ideas, concerns and projects. All cryptocurrency communities need liquidity and thus require access to exchanges.

Cụ thể hơn về nhu cầu của cộng đồng Cardano, tất cả các cộng đồng tiền điện tử cần thông tin chính xác, kịp thời và toàn diện về các sự kiện, công nghệ và tiến trình của hệ sinh thái.
Tất cả các cộng đồng tiền điện tử cần các diễn đàn ổn định và được kiểm duyệt để thảo luận về ý tưởng, mối quan tâm và dự án của họ.
Tất cả các cộng đồng tiền điện tử cần thanh khoản và do đó yêu cầu truy cập vào các sàn giao dịch.

The Cardano protocol also requires community-led efforts to gradually decentralize the protocol beyond what Bitcoin and Ethereum have achieved. A core focus outlined in the [Why Cardano](https://whycardano.com "whycardano.com") white paper is the desire to establish a treasury and a blockchain-based voting system for ratifying Cardano improvement proposals.

Giao thức Cardano cũng đòi hỏi các nỗ lực do cộng đồng lãnh đạo để dần dần phân cấp giao thức vượt ra ngoài những gì Bitcoin và Ethereum đã đạt được.
Một trọng tâm cốt lõi được nêu trong [Tại sao Cardano] (https://whycardano.com "WhyCardano.com") Sách trắng là mong muốn thiết lập một hệ thống bỏ phiếu dựa trên kho bạc và một hệ thống bỏ phiếu dựa trên blockchain để phê chuẩn các đề xuất cải tiến Cardano.

This effort cannot just rely on technological and scientific innovation. Rather, it requires a well-organized and informed community that is representative of the users of Cardano and is geographically diverse. Among other things, it is the Foundationâ€™s responsibility to invest in the creation of this community.

Nỗ lực này không thể chỉ dựa vào đổi mới công nghệ và khoa học.
Thay vào đó, nó đòi hỏi một cộng đồng được tổ chức tốt và có hiểu biết, đại diện cho người dùng Cardano và đa dạng về mặt địa lý.
Trong số những thứ khác, trách nhiệm đầu tư của nền tảng là đầu tư vào việc tạo ra cộng đồng này.

### **Lack of performance by the Cardano Foundation**

### ** Thiếu hiệu suất của Quỹ Cardano **

For more than two years there has been great frustration in the Cardano community and ecosystem. This has been caused by a lack of activity and progress on the assigned responsibilities of the Cardano Foundation and its council. Furthermore, there has been no clear indication of improvement, despite many fruitless attempts and approaches to the Foundationâ€™s chairman and council to change this.

Trong hơn hai năm, đã có sự thất vọng lớn trong cộng đồng Cardano và hệ sinh thái.
Điều này đã được gây ra bởi sự thiếu hoạt động và tiến bộ đối với các trách nhiệm được giao của Quỹ Cardano và hội đồng của nó.
Hơn nữa, không có dấu hiệu rõ ràng về sự cải thiện, mặc dù có nhiều nỗ lực và cách tiếp cận không có kết quả đối với Chủ tịch và Hội đồng của Quỹ để thay đổi điều này.

Dissatisfaction and frustrations about the Foundationâ€™s performance stem primarily from:

Sự không hài lòng và thất vọng về hiệu suất của nền tảng chủ yếu từ:

1. A lack of strategic vision from the council. There are no KPIs or public strategy documents outlining how the Foundation will accomplish the above goals or any discernible goal. 

1. Thiếu tầm nhìn chiến lược từ hội đồng.
Không có KPI hoặc các tài liệu chiến lược công cộng phác thảo cách nền tảng sẽ hoàn thành các mục tiêu trên hoặc bất kỳ mục tiêu rõ ràng nào.

1. The absence of a clear public plan for how the Foundation will spend its funds to benefit the community. 

1. Sự vắng mặt của một kế hoạch công khai rõ ràng về cách nền tảng sẽ chi tiêu tiền của mình để mang lại lợi ích cho cộng đồng.

1. The lack of transparency in the Foundationâ€™s operations (for example publication of its board minutes and director remuneration). 

1. Sự thiếu minh bạch trong các hoạt động của nền tảng (ví dụ: xuất bản biên bản hội đồng quản trị và thù lao giám đốc).

1. Material misrepresentations and wrongful statements by the Foundationâ€™s council including a claim that it owned the trademark in Cardano. The council has even tried to assume the power to decide who speaks for the protocol, what should be deployed on the protocol and how the press should represent relationships between Emurgo, IOHK, the Foundation and third party projects. 

1. Sự xuyên tạc vật chất và tuyên bố sai của Hội đồng Quỹ bao gồm một tuyên bố rằng nó sở hữu nhãn hiệu tại Cardano.
Hội đồng thậm chí đã cố gắng nắm quyền quyết định ai nói cho giao thức, những gì nên được triển khai trên giao thức và cách báo chí nên đại diện cho mối quan hệ giữa EMURGO, IOHK, các dự án của bên thứ ba và bên thứ ba.

   Having identified the legal dubiousness and profound consequences of the Foundationâ€™s claims in respect of trademark ownership, IOHK ceased collaboration with the Foundation until it published a fair use policy for the trademark. This process took weeks. 

Đã xác định được sự ngờ vực pháp lý và hậu quả sâu sắc của các khiếu nại của nền tảng đối với quyền sở hữu nhãn hiệu, IOHK đã ngừng hợp tác với Quỹ cho đến khi nó công bố chính sách sử dụng hợp lý cho nhãn hiệu.
Quá trình này mất nhiều tuần.

   The unpredictable conduct and lack of action by the board of the Foundation has been puzzling. For example, when IOHK went to Ethiopia to [sign an MOU with the Ministry of Science and Technology](https://bitcoinmagazine.com/articles/where-coffee-just-grows-connecting-ethiopian-agritech-blockchain/), the Foundation originally agreed to attend and jointly sign. Unexpectedly, the Foundation decided to back out the week before and claimed in an email to IOHKâ€™s communications director that it â€“ without any basis or underlying agreement â€“ was to be the single guardian of the Cardano brand and protocols. 

Hành vi không thể đoán trước và thiếu hành động của hội đồng quản trị đã gây khó hiểu.
Ví dụ: khi IOHK đến Ethiopia để [ký một MoU với Bộ Khoa học và Công nghệ] (https://bitcoinmagazine.com/articles/where-coffee-just-grows-connecting-ethiopian-agritech-blockchain/),
Quỹ ban đầu đồng ý tham dự và cùng ký.
Thật bất ngờ, nền tảng đã quyết định sao lưu tuần trước và tuyên bố trong một email cho Giám đốc truyền thông của IOHK rằng họ không có bất kỳ cơ sở hay thỏa thuận cơ bản nào - là người bảo vệ duy nhất của thương hiệu và giao thức Cardano.

   [Read the email from the Foundation to IOHK here](https://ucarecdn.com/8cdaa61b-6725-4fd7-b135-134dd1263a6d/-/inline/yes/). 

[Đọc email từ nền tảng đến IOHK tại đây] (https://ucarecdn.com/8cdaa61b-6725-4fd7-b135-134dd1263a6d//-inline/yes/).

1. Lack of financial transparency. As of October, despite several requests the Foundation has still refused to publish the addresses holding its allocation of Ada. Neither has the Foundation published audited financial statements. And, the Foundation has not provided any information on remuneration of directors and officers. 

1. Thiếu tính minh bạch tài chính.
Tính đến tháng 10, mặc dù có một số yêu cầu, nền tảng vẫn từ chối xuất bản các địa chỉ nắm giữ ADA.
Không có nền tảng được công bố báo cáo tài chính đã kiểm toán.
Và, Quỹ đã không cung cấp bất kỳ thông tin nào về thù lao của giám đốc và cán bộ.

1. The lack of a complete and diverse Foundation council. At its incorporation (September 2016) the council consisted of 4 members, with Michael Parsons as chairman. Ten days after his appointment, a council member (Mr Parsonsâ€™ stepson, Bruce Milligan) resigned. Instead, Mr Milligan became the general manager of the Foundation. His vacancy on the council, however, was never filled. Ten months after the Foundationâ€™s incorporation, the third council member resigned, thus reducing the council from the 4 members as intended by its founders to only 2 (Mr Parsons and a professional Swiss council representative). 

1. Việc thiếu một hội đồng nền tảng hoàn chỉnh và đa dạng.
Tại thành lập (tháng 9 năm 2016), hội đồng bao gồm 4 thành viên, với Michael Parsons làm chủ tịch.
Mười ngày sau cuộc hẹn, một thành viên hội đồng (con trai riêng của ông Parsons, Bruce Milligan) đã từ chức.
Thay vào đó, ông Milligan trở thành tổng giám đốc của Quỹ.
Vị trí tuyển dụng của ông trong hội đồng, tuy nhiên, không bao giờ được lấp đầy.
Mười tháng sau khi thành lập của Tổ chức, thành viên Hội đồng thứ ba đã từ chức, do đó giảm hội đồng từ 4 thành viên theo dự định của những người sáng lập chỉ còn 2 (ông Parsons và một đại diện của Hội đồng Thụy Sĩ chuyên nghiệp).

   The vacancies have not been filled by the remaining council members. As a consequence, since 14 July, 2017, the Foundation has, in effect, been controlled by Mr Parsons. He has been acting as the Foundationâ€™s de facto sole decision-maker in respect of the day-to-day business of the Foundation and ruling its staff like a monarch. For more than 15 months, there appear to have been no reasonable attempts to fill the 2 council vacancies. There appears to be no oversight and there appear to be no checks and balances beyond those required by Swiss law. 

Các vị trí tuyển dụng chưa được lấp đầy bởi các thành viên hội đồng còn lại.
Kết quả là, kể từ ngày 14 tháng 7 năm 2017, tổ chức này, có hiệu lực, đã được kiểm soát bởi ông Parsons.
Ông đã đóng vai trò là người ra quyết định duy nhất thực tế của nền tảng đối với việc kinh doanh hàng ngày của Quỹ và cai trị nhân viên của mình như một quốc vương.
Trong hơn 15 tháng, dường như không có nỗ lực hợp lý nào để lấp đầy 2 vị trí tuyển dụng của hội đồng.
Dường như không có sự giám sát và dường như không có kiểm tra và cân bằng vượt quá những yêu cầu của luật pháp Thụy Sĩ.

   A sound council board in the opinion of the ecosystem should consist of several active and competent and independent members. These should be domain experts from the cryptocurrency community who fairly represent the holders of Ada and users of the Cardano protocol. They should be committed to maintaining reasonable checks and balances. Although not imposed under Swiss law, the council appointment process should ideally be open to the community and include their feedback and suggestions. 

Một hội đồng hội đồng âm thanh theo ý kiến của hệ sinh thái nên bao gồm một số thành viên hoạt động và có năng lực và độc lập.
Đây phải là các chuyên gia tên miền từ cộng đồng tiền điện tử, những người đại diện cho những người nắm giữ ADA và người dùng của giao thức Cardano.
Họ nên cam kết duy trì kiểm tra và số dư hợp lý.
Mặc dù không được áp dụng theo luật Thụy Sĩ, quá trình hẹn hội đồng nên được mở cho cộng đồng và bao gồm phản hồi và đề xuất của họ.

   Despite over 90 percent of the original Ada voucher purchasers residing in Japan, the Cardano Foundation has yet to appoint anyone from Japan into a position of power. Also, the Foundation has yet to engage a lobbyist to assist with getting Ada listed on Japanese exchanges. And, the Foundation has no significant presence or personnel from Japan or even Asia. 

Mặc dù có hơn 90 phần trăm người mua chứng từ ADA ban đầu cư trú tại Nhật Bản, Quỹ Cardano vẫn chưa bổ nhiệm bất kỳ ai từ Nhật Bản vào vị trí quyền lực.
Ngoài ra, nền tảng vẫn chưa tham gia một nhà vận động hành lang để hỗ trợ nhận được ADA được liệt kê trên các sàn giao dịch Nhật Bản.
Và, nền tảng không có sự hiện diện hoặc nhân sự đáng kể từ Nhật Bản hoặc thậm chí châu Á.

1. Lack of any concept of how the millions of dollars committed to the Foundation will benefit the Cardano community. Instead of working on meaningful projects such as law and policy research for ICO and STO standards for assets that will be issued on Cardano, thereby offering an alternative to Ethereumâ€™s tokens, or studying ways to deploy Cardanoâ€™s improvement proposal process, the Foundationâ€™s council has decided to invest its provided research capital in the [Distributed Futures](https://cardanofoundation.org/en/distributed-futures/) program. 

1. Thiếu bất kỳ khái niệm nào về cách hàng triệu đô la cam kết với nền tảng sẽ có lợi cho cộng đồng Cardano.
Thay vì làm việc trên các dự án có ý nghĩa như nghiên cứu luật pháp và chính sách cho các tiêu chuẩn ICO và STO đối với các tài sản sẽ được phát hành trên Cardano, từ đó cung cấp một giải pháp thay thế cho các mã thông báo của Ethereum, hoặc nghiên cứu các cách để triển khai quy trình đề xuất cải tiến của Cardano,
Hội đồng nền tảng đã quyết định đầu tư vốn nghiên cứu được cung cấp vào chương trình [tương lai phân tán] (https://cardanofoundation.org/en/distributed-futures/).

   No explicit case has been made as to how the Distributed Futures research will benefit the Cardano protocol or the ecosystem. No funds have been committed to commercialize the research. No apparent effort has been made by council members of the Foundation to annotate the Distributed Futures reports with specifics on how the findings will be applied to our community. 

Không có trường hợp rõ ràng nào được thực hiện về cách nghiên cứu tương lai phân tán sẽ có lợi cho giao thức Cardano hoặc hệ sinh thái.
Không có quỹ đã được cam kết thương mại hóa nghiên cứu.
Không có nỗ lực rõ ràng nào được thực hiện bởi các thành viên hội đồng của Quỹ để chú thích các báo cáo tương lai phân tán với các chi tiết cụ thể về cách áp dụng các phát hiện cho cộng đồng của chúng tôi.

   Furthermore, members of the ecosystem worry about potential conflicts of interest because both Robert McDowall, an adviser and contributor to Distributed Futures research, and Michael Mainelli, leader of Distributed Futures, have pre-existing relationships with Mr Parsons. Indeed, we are not aware of any process within the Cardano Foundation to analyze potential conflicts of interest and require recusal where necessary. 

Hơn nữa, các thành viên của hệ sinh thái lo lắng về các xung đột lợi ích tiềm năng vì cả Robert McDowall, một cố vấn và đóng góp cho nghiên cứu tương lai phân tán, và Michael Mainelli, lãnh đạo của tương lai phân tán, có mối quan hệ trước đó với ông Parsons.
Thật vậy, chúng tôi không nhận thức được bất kỳ quá trình nào trong Quỹ Cardano để phân tích các xung đột lợi ích tiềm năng và yêu cầu từ chối khi cần thiết.

1. Absence/unawareness of any meaningful internal governance system at the Cardano Foundation. In our many interactions with Foundation staff, it has never become clear how decisions are made and reviewed. It has also never been clear how the chain of command operates beyond Chairman Parsons. 

1. Sự vắng mặt/không nhận thức của bất kỳ hệ thống quản trị nội bộ có ý nghĩa nào tại Quỹ Cardano.
Trong nhiều tương tác của chúng tôi với đội ngũ nhân viên nền tảng, nó chưa bao giờ trở nên rõ ràng làm thế nào các quyết định được đưa ra và xem xét.
Nó cũng chưa bao giờ rõ ràng làm thế nào chuỗi chỉ huy vận hành ngoài Chủ tịch Parsons.

### **Our call for action**

### ** Lời kêu gọi hành động của chúng tôi **

Emurgo and IOHK are calling for the Foundation council: to voluntarily subject itself to the Swiss authorities; for a complete audit of all of the Foundation's financial transactions and major decisions to be conducted; and for the results to be released to the general public. This audit should include direct and indirect remuneration paid (in the light of actual and agreed performance or services delivered for the benefit of the Foundation) to Mr Parsons; his stepson Bruce Milligan who acted as a general manager; and his wife, Julie Milligan, who acted as an assistant to Mr Parsons.

Emurgo và IOHK đang kêu gọi Hội đồng Quỹ: tự nguyện tuân theo chính quyền Thụy Sĩ;
để kiểm toán đầy đủ tất cả các giao dịch tài chính của nền tảng và các quyết định chính được thực hiện;
và để kết quả được phát hành cho công chúng.
Kiểm toán này nên bao gồm tiền thù lao trực tiếp và gián tiếp được trả (theo ánh sáng của hiệu suất hoặc dịch vụ đã được thỏa thuận thực tế và được cung cấp vì lợi ích của Quỹ) cho Mr Parsons;
Con trai riêng của ông Bruce Milligan, người đóng vai trò là tổng giám đốc;
và vợ ông, Julie Milligan, người đóng vai trò là trợ lý cho ông Parsons.

The Cardano Foundation is an independent legal entity governed by its council, thus the Cardano community, IOHK and Emurgo cannot force the chairman to resign. Nevertheless, we can only hope that reason will persuade Mr Parsons to voluntarily step down. This would allow for regulatory oversight and avoid the Foundation continuing to be an ineffective entity.

Quỹ Cardano là một thực thể pháp lý độc lập được điều hành bởi hội đồng của nó, do đó cộng đồng Cardano, IOHK và Emurgo không thể buộc chủ tịch phải từ chức.
Tuy nhiên, chúng ta chỉ có thể hy vọng rằng lý do sẽ thuyết phục ông Parsons tự nguyện từ chức.
Điều này sẽ cho phép giám sát quy định và tránh nền tảng tiếp tục là một thực thể không hiệu quả.

### **Offer of IOHK & Emurgo**

### ** Ưu đãi của IOHK & Emurgo **

The Foundation and its council have not been able to execute their purpose in promoting and supporting the Cardano ecosystem. So, to provide the Cardano ecosystem with the support and services it requires and deserves, in the Foundationâ€™s stead, IOHK and Emurgo are committed to the following actions until at least 2020:

Quỹ và hội đồng của nó đã không thể thực hiện mục đích của họ trong việc thúc đẩy và hỗ trợ hệ sinh thái Cardano.
Vì vậy, để cung cấp cho hệ sinh thái Cardano các hỗ trợ và dịch vụ mà nó yêu cầu và xứng đáng, trong nền tảng của Foundation, IOHK và Emurgo cam kết với các hành động sau cho đến ít nhất là năm 2020:

1. IOHK and Emurgo will begin hiring dedicated community managers for the Cardano ecosystem and assign them to growing and informing our community through meetup groups, events, educational efforts and other metrics that can be tracked.

1. IOHK và Emurgo sẽ bắt đầu tuyển dụng các nhà quản lý cộng đồng chuyên dụng cho hệ sinh thái Cardano và giao chúng phát triển và thông báo cho cộng đồng của chúng tôi thông qua các nhóm gặp gỡ, sự kiện, nỗ lực giáo dục và các số liệu khác có thể được theo dõi.

1. IOHK is willing to hire, subject to reasonable due diligence and negotiations, Cardano Foundation personnel directly engaged in community management should they desire to leave the Foundation.

1. IOHK sẵn sàng thuê, phải chịu sự siêng năng và đàm phán hợp lý, nhân viên của Cardano Foundation trực tiếp tham gia vào quản lý cộng đồng nếu họ muốn rời khỏi nền tảng.

1. IOHK will work with Emurgo to start efforts in Japan to improve exchange access and community understanding of Cardano.

1. IOHK sẽ làm việc với Emurgo để bắt đầu các nỗ lực ở Nhật Bản để cải thiện quyền truy cập trao đổi và hiểu biết cộng đồng về Cardano.

1. IOHK and Emurgo will scale up its educational and marketing efforts to include more content about the Cardano protocols, developer resources and USPs of our ecosystem.

1. IOHK và Emurgo sẽ mở rộng các nỗ lực giáo dục và tiếp thị của mình để bao gồm nhiều nội dung hơn về các giao thức Cardano, tài nguyên nhà phát triển và USPS của hệ sinh thái của chúng tôi.

1. IOHK has hired an open source community manager to draft the Cardano improvement proposal process and begin its rollout.

1. IOHK đã thuê một người quản lý cộng đồng nguồn mở để soạn thảo quy trình đề xuất cải tiến Cardano và bắt đầu triển khai.

1. IOHK has expanded its research scope to include the areas originally forseen for the Cardano Foundation.

1. IOHK đã mở rộng phạm vi nghiên cứu của mình để bao gồm các khu vực ban đầu được đặt trước cho Quỹ Cardano.

1. IOHK will start a research agenda to design a decentralized Foundation built as a DAO to be deployed on the Cardano computation layer. We will announce a dedicated research center at a later date.

1. IOHK sẽ bắt đầu một chương trình nghiên cứu để thiết kế một nền tảng phi tập trung được xây dựng dưới dạng DAO để được triển khai trên lớp tính toán Cardano.
Chúng tôi sẽ công bố một trung tâm nghiên cứu chuyên dụng vào một ngày sau đó.

### **Final thoughts**

### ** Suy nghĩ cuối cùng **

First, IOHK and Emurgoâ€™s funding for the Cardano project is fully secured, independent, and not connected to the Cardano Foundation. The Foundation is not in a position to mandate or compel changes in the operations of the Cardano platform, IOHK, or Emurgo.

Đầu tiên, tài trợ của IOHK và Emurgo cho dự án Cardano được bảo đảm hoàn toàn, độc lập và không kết nối với Quỹ Cardano.
Nền tảng không ở vị trí để bắt buộc hoặc bắt buộc các thay đổi trong hoạt động của nền tảng Cardano, IOHK hoặc Emurgo.

Second, the original intention of separating powers within the Cardano ecosystem was to ensure that the failure of one entity would not destroy the project. This resilience has allowed us to thrive, despite the Foundationâ€™s lack of progress and vision.

Thứ hai, ý định ban đầu là phân tách các quyền lực trong hệ sinh thái Cardano là để đảm bảo rằng sự thất bại của một thực thể sẽ không phá hủy dự án.
Khả năng phục hồi này đã cho phép chúng ta phát triển mạnh, mặc dù sự thiếu tiến bộ và tầm nhìn của nền tảng.

Third, the real strength of Cardano stems from its exceptional community, which continues to grow and impress us. The Foundationâ€™s role is similar to the Bitcoin Foundationâ€™s, in that its purpose is to add value to the community. Like the Bitcoin Foundation for Bitcoin, the Cardano Foundation is not necessary for Cardano to succeed as a project.

Thứ ba, sức mạnh thực sự của Cardano bắt nguồn từ cộng đồng đặc biệt của nó, tiếp tục phát triển và gây ấn tượng với chúng ta.
Vai trò của nền tảng tương tự như Bitcoin Foundation, trong đó mục đích của nó là tăng thêm giá trị cho cộng đồng.
Giống như Bitcoin Foundation cho Bitcoin, Quỹ Cardano không cần thiết để Cardano thành công như một dự án.

And last, but not least, for IOHK, Cardano is more than a product. Cardano is a mission to deliver a financial operating system to the three billion people who need a new one. Our personnel have been to more than 50 countries over the past three years representing Cardano. We will continue to do so over the coming years because we see the power of this technology and the people it can help.

Và cuối cùng, nhưng không kém phần quan trọng, đối với IOHK, Cardano không chỉ là một sản phẩm.
Cardano là một nhiệm vụ cung cấp một hệ điều hành tài chính cho ba tỷ người cần một hệ điều hành mới.
Nhân viên của chúng tôi đã đến hơn 50 quốc gia trong ba năm qua đại diện cho Cardano.
Chúng tôi sẽ tiếp tục làm như vậy trong những năm tới bởi vì chúng tôi thấy sức mạnh của công nghệ này và những người mà nó có thể giúp đỡ.

As the CEOs of IOHK and Emurgo, we are deeply disappointed that we have not been able to activate and increase the performance of the Foundation. We have not been able to resolve the above outstanding matters in another way. We are also deeply disappointed that our community has been repeatedly let down by the Foundation, yet we are determined to ensure that the community will be served in the manner it deserves to be served.

Là CEO của IOHK và Emurgo, chúng tôi vô cùng thất vọng rằng chúng tôi đã không thể kích hoạt và tăng hiệu suất của nền tảng.
Chúng tôi đã không thể giải quyết các vấn đề nổi bật trên theo một cách khác.
Chúng tôi cũng vô cùng thất vọng rằng cộng đồng của chúng tôi đã nhiều lần bị nền tảng thất vọng, nhưng chúng tôi quyết tâm đảm bảo rằng cộng đồng sẽ được phục vụ theo cách mà nó xứng đáng được phục vụ.

Regardless of the above, we believe our best days are ahead of us. We believe Cardano will become the best technology to deliver financial infrastructure to the billions who lack it.

Bất kể những điều trên, chúng tôi tin rằng những ngày tốt nhất của chúng tôi đang ở phía trước chúng tôi.
Chúng tôi tin rằng Cardano sẽ trở thành công nghệ tốt nhất để cung cấp cơ sở hạ tầng tài chính cho hàng tỷ người thiếu nó.

![](img/2018-10-12-an-open-letter-to-the-cardano-community-from-iohk-and-emurgo.005.png)

Charles Hoskinson,

Charles Hoskinson,

Chief Executive Officer,

Giám đốc điều hành,

Input Output HK Ltd. 

Đầu vào đầu vào HK Ltd.

![](img/2018-10-12-an-open-letter-to-the-cardano-community-from-iohk-and-emurgo.005.png)

Ken Kodama,

Ken Kodama,

Chief Executive Officer,

Giám đốc điều hành,

Emurgo 

Emurgo

*This article has been corrected to reflect the fact that Bruce Milligan is Michael Parsonâ€™s stepson, rather than son-in-law, as previously stated.*

*Bài viết này đã được sửa chữa để phản ánh thực tế rằng Bruce Milligan là con trai riêng của Michael Parson, chứ không phải là con rể, như đã nêu trước đây.*

Artwork, ![Creative Commons](img/2018-10-12-an-open-letter-to-the-cardano-community-from-iohk-and-emurgo.006.png)[ ](https://creativecommons.org/licenses/by/4.0/)[Mike Beeple](http://www.beeple-crap.com)

