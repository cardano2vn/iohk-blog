# Cardano 1.1.0 software update
### **A major package of improvements and fixes is ready for users**
![](img/2018-03-07-cardano-1-1-0-software-update.002.png) 7 March 2018![](img/2018-03-07-cardano-1-1-0-software-update.002.png)[ Duncan Coutts](tmp//en/blog/authors/duncan-coutts/page-1/)![](img/2018-03-07-cardano-1-1-0-software-update.003.png) 4 mins read

![](img/2018-03-07-cardano-1-1-0-software-update.004.png)[ Cardano 1](https://ucarecdn.com/81358a2c-cff8-449d-b2ad-2c4bb3ef2a1c/-/inline/yes/ "Cardano 1")

![Duncan Coutts](img/2018-03-07-cardano-1-1-0-software-update.005.png)[](tmp//en/blog/authors/duncan-coutts/page-1/)
### [**Duncan Coutts**](tmp//en/blog/authors/duncan-coutts/page-1/)
Technical Architect

Well-Typed

- ![](img/2018-03-07-cardano-1-1-0-software-update.006.png)[](mailto:duncan.coutts@iohk.io "Email")
- ![](img/2018-03-07-cardano-1-1-0-software-update.007.png)[](https://www.youtube.com/watch?v=TZGVgNsJSnA "YouTube")
- ![](img/2018-03-07-cardano-1-1-0-software-update.008.png)[](http://www.linkedin.com/in/duncancoutts "LinkedIn")
- ![](img/2018-03-07-cardano-1-1-0-software-update.009.png)[](https://github.com/dcoutts "GitHub")

![Cardano 1.1.0 software update](img/2018-03-07-cardano-1-1-0-software-update.010.jpeg)

The software update today is the first major release for Cardano since the mainnet was launched at the end of September and it consists of a great deal of work from the development team. The release contains a few new features that are aimed at improving the user experience. And it also contains a set of important fixes for many of the bugs that were identified since the last release, Cardano SL 1.0.3. Here is [Charles Hoskinson, CEO of IOHK](https://www.pscp.tv/w/1dRJZeyZOagGB "Update on the Update from IOHK_Charles, pscp.tv"), with a video update about this release, and below we outline the most significant changes delivered. Users will notice the changes take effect tomorrow.

Bản cập nhật phần mềm hôm nay là bản phát hành lớn đầu tiên cho Cardano kể từ khi Mainnet được ra mắt vào cuối tháng 9 và nó bao gồm rất nhiều công việc từ nhóm phát triển.
Bản phát hành chứa một vài tính năng mới nhằm cải thiện trải nghiệm người dùng.
Và nó cũng chứa một tập hợp các bản sửa lỗi quan trọng cho nhiều lỗi đã được xác định kể từ lần phát hành cuối cùng, Cardano SL 1.0.3.
Đây là [Charles Hoskinson, CEO của IOHK] (https://www.pscp.tv/w/1drjzeyzoaggb "Cập nhật bản cập nhật từ iohk_charles, pscp.tv")
Những thay đổi quan trọng nhất được cung cấp.
Người dùng sẽ nhận thấy những thay đổi có hiệu lực vào ngày mai.

The team has been working hard to address the issues some users have experienced with Daedalus and this update contains fixes for some of the problems.

Nhóm đã làm việc chăm chỉ để giải quyết các vấn đề mà một số người dùng đã trải qua với Daedalus và bản cập nhật này chứa các bản sửa lỗi cho một số vấn đề.

With this release, Daedalus will detect when the time on a user's machine is out of sync with the global time and will display an error message asking the user to fix the issue. Before this feature was added when there was a time difference of 20 seconds or more, the Cardano node was unable to connect to the network and validate the blockchain, and Daedalus would be held on the loading screen with the "Connecting to network" message. This feature will eliminate the problem of users being held on the loading screen because of the time difference issue.

Với bản phát hành này, Daedalus sẽ phát hiện khi thời gian trên máy của người dùng không đồng bộ với thời gian toàn cầu và sẽ hiển thị thông báo lỗi yêu cầu người dùng khắc phục sự cố.
Trước khi tính năng này được thêm vào khi có chênh lệch thời gian từ 20 giây trở lên, nút Cardano không thể kết nối với mạng và xác nhận blockchain và Daedalus sẽ được giữ trên màn hình tải với thông báo "Kết nối với mạng".
Tính năng này sẽ loại bỏ vấn đề người dùng bị giữ trên màn hình tải vì vấn đề chênh lệch thời gian.

Several other instances of the user being stuck on the "Connecting to network" screen were fixed. Many issues that can lead to this have been partially or completely fixed. Problem areas include node shutdown, networking and block retrieval mechanisms.

Một số trường hợp khác của người dùng bị kẹt trên màn hình "Kết nối với mạng" đã được sửa.
Nhiều vấn đề có thể dẫn đến điều này đã được cố định một phần hoặc hoàn toàn.
Các khu vực có vấn đề bao gồm tắt nút, kết nối mạng và chặn các cơ chế truy xuất.

A new "Support request" feature enables users to report a problem directly from Daedalus. This will automatically include log files along with the problem report. By always including log files, this feature will help the development team to investigate and solve the problems that users are experiencing. This feature is accessible from the main user interface and from the loading screen when there is a delay while connecting to the network or when blockchain syncing stops.

Tính năng "Yêu cầu hỗ trợ" mới cho phép người dùng báo cáo vấn đề trực tiếp từ Daedalus.
Điều này sẽ tự động bao gồm các tệp nhật ký cùng với báo cáo sự cố.
Bằng cách luôn bao gồm các tệp nhật ký, tính năng này sẽ giúp nhóm phát triển điều tra và giải quyết các vấn đề mà người dùng đang gặp phải.
Tính năng này có thể truy cập từ giao diện người dùng chính và từ màn hình tải khi có độ trễ trong khi kết nối với mạng hoặc khi đồng bộ hóa blockchain dừng.

Blockchain retrieval performance and reliability has been gradually improved, in particular bugs have been fixed that caused significant slowdown in syncing to the network after reaching 99.9%, and caused occasional network disconnections. Handling of whether Daedalus is connected or disconnected is improved, and a lost internet connection is now detected and brings the user to the loading screen to indicate that wallet is not currently operational.

Hiệu suất và độ tin cậy thu hồi blockchain đã dần được cải thiện, đặc biệt là các lỗi đã được sửa chữa gây ra sự chậm lại đáng kể trong việc đồng bộ hóa mạng sau khi đạt 99,9%và gây ra ngắt kết nối mạng không thường xuyên.
Xử lý liệu Daedalus có được kết nối hay ngắt kết nối có được cải thiện hay không và kết nối Internet bị mất hiện được phát hiện và đưa người dùng đến màn hình tải để cho biết rằng ví hiện không hoạt động.

In addition to individual fixes, importantly, this major release is the first time-based release containing significant new code, and represents an improvement in our development process. All previous releases of Cardano were scope-based, i.e. the goal was to deliver a particular scope and often the release was repeatedly postponed because of inaccurate estimations on having the scope ready for release.

Ngoài các bản sửa lỗi riêng lẻ, quan trọng là, bản phát hành chính này là bản phát hành dựa trên thời gian đầu tiên chứa mã mới đáng kể và thể hiện sự cải thiện trong quá trình phát triển của chúng tôi.
Tất cả các bản phát hành trước đó của Cardano đều dựa trên phạm vi, tức là mục tiêu là cung cấp một phạm vi cụ thể và thường việc phát hành đã được hoãn lại vì các ước tính không chính xác về việc có phạm vi sẵn sàng để phát hành.

There is much debate among software developers on which release process is preferable. As was outlined in our [previous blog post](tmp//en/blog/what-is-our-release-strategy-for-cardano/ "Cardano release strategy"), the Cardano team has chosen time-based releases. We had a significant backlog of work to resolve to be able to release our development branch to the mainnet â€“ a substantial amount of testing had to be performed because of large amount of new code. But with the release of 1.1.0, we have made a major step forward.

Có nhiều cuộc tranh luận giữa các nhà phát triển phần mềm về quá trình phát hành là thích hợp hơn.
Như đã được nêu trong [Bài đăng trên blog trước đây của chúng tôi] (TMP // EN/Blog/What-is-Of phát hành-Chiến lược-For-Cardano/"Chiến lược phát hành Cardano"), nhóm Cardano đã chọn phát hành dựa trên thời gian.
Chúng tôi đã có một hoạt động tồn đọng đáng kể để quyết tâm có thể phát hành nhánh phát triển của chúng tôi ra Mainnet - Một lượng thử nghiệm đáng kể phải được thực hiện vì một lượng lớn mã mới.
Nhưng với việc phát hành 1.1.0, chúng tôi đã có một bước tiến lớn.

There will be two more time-based releases in the next couple of months containing more improvements, fixes and new features for Cardano. New features for the Shelley phase of development will begin to be released in Q2 and continue through Q3. For more information see the [Cardano Roadmap](https://cardanoroadmap.com "Cardano roadmap").

Sẽ có hai bản phát hành dựa trên thời gian hơn trong vài tháng tới có chứa nhiều cải tiến, sửa chữa và tính năng mới cho Cardano.
Các tính năng mới cho giai đoạn phát triển Shelley sẽ bắt đầu được phát hành trong quý 2 và tiếp tục qua quý 3.
Để biết thêm thông tin, hãy xem [Lộ trình Cardano] (https://cardanoroadmap.com "Lộ trình Cardano").

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2018-03-07-cardano-1-1-0-software-update.011.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

## **Attachments**

## ** tệp đính kèm **

![](img/2018-03-07-cardano-1-1-0-software-update.004.png)[ Cardano 1](https://ucarecdn.com/81358a2c-cff8-449d-b2ad-2c4bb3ef2a1c/-/inline/yes/ "Cardano 1")

