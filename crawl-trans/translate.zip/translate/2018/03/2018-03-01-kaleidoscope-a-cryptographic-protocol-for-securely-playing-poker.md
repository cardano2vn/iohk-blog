# Kaleidoscope – a cryptographic protocol for securely playing poker
### **Bernardo David presents the research paper at Financial Cryptography 2018**
![](img/2018-03-01-kaleidoscope-a-cryptographic-protocol-for-securely-playing-poker.002.png) 1 March 2018![](img/2018-03-01-kaleidoscope-a-cryptographic-protocol-for-securely-playing-poker.002.png)[ Bernardo David](tmp//en/blog/authors/bernardo-david/page-1/)![](img/2018-03-01-kaleidoscope-a-cryptographic-protocol-for-securely-playing-poker.003.png) 5 mins read

![](img/2018-03-01-kaleidoscope-a-cryptographic-protocol-for-securely-playing-poker.004.png)[ Kaleidoscope – a cryptographic protocol](https://ucarecdn.com/aa487d9f-2087-4db4-a94e-d54d8ff5291b/-/inline/yes/ "Kaleidoscope – a cryptographic protocol")

![Bernardo David](img/2018-03-01-kaleidoscope-a-cryptographic-protocol-for-securely-playing-poker.005.png)[](tmp//en/blog/authors/bernardo-david/page-1/)
### [**Bernardo David**](tmp//en/blog/authors/bernardo-david/page-1/)
Poker is arguably one of the most popular card games in the world, both in casinos and on the internet. Online poker has become increasingly popular after a boom in the early 2000s, fueling a growing market with revenues estimated in the tens of billions of dollars. However, the current model of online gambling forces users to blindly trust the online casinos, who could easily rig games or suffer attacks from disgruntled employees who aim to make easy money. In fact, this state of affairs not only represents a threat but has resulted in real-world [attacks](https://en.wikipedia.org/wiki/Online_poker "Online poker, Wikipedia"). A clear alternative to using online casinos consists of using cryptographic protocols for securely playing poker over a network without trusting any third party. In fact, constructing such protocols has been a research topic since the early days of modern cryptography. Shamir, Rivest and Adleman proposed the first candidate protocol to this end only a few years after publishing the famous RSA public key encryption scheme. Their seminal effort initiated a long line of research that has produced countless results over the years. However, no cryptographic poker protocol has ever been adopted for real applications, mainly due to the following issues:

Poker được cho là một trong những trò chơi bài phổ biến nhất trên thế giới, cả trong sòng bạc và trên internet. Poker trực tuyến đã ngày càng trở nên phổ biến sau khi bùng nổ vào đầu những năm 2000, thúc đẩy một thị trường đang phát triển với các khoản thu được ước tính trong hàng chục tỷ đô la. Tuy nhiên, mô hình hiện tại của cờ bạc trực tuyến buộc người dùng phải tin tưởng một cách mù quáng các sòng bạc trực tuyến, những người có thể dễ dàng gian lận các trò chơi hoặc bị tấn công từ những nhân viên bất mãn, những người nhằm kiếm tiền dễ dàng. Trên thực tế, tình trạng này không chỉ đại diện cho một mối đe dọa mà còn dẫn đến [các cuộc tấn công thực tế] (https://en.wikipedia.org/wiki/online_poker "Poker trực tuyến, Wikipedia"). Một giải pháp thay thế rõ ràng cho việc sử dụng sòng bạc trực tuyến bao gồm sử dụng các giao thức mật mã để chơi bài xì phé một cách an toàn trên mạng mà không tin tưởng bất kỳ bên thứ ba nào. Trên thực tế, việc xây dựng các giao thức như vậy là một chủ đề nghiên cứu kể từ những ngày đầu của mật mã hiện đại. Shamir, Rivest và Adman đã đề xuất giao thức ứng cử viên đầu tiên cho kết thúc này chỉ một vài năm sau khi xuất bản chương trình mã hóa khóa công khai RSA nổi tiếng. Nỗ lực bán kết của họ đã khởi xướng một dòng nghiên cứu dài đã tạo ra vô số kết quả trong những năm qua. Tuy nhiên, không có giao thức poker mật mã nào từng được áp dụng cho các ứng dụng thực, chủ yếu là do các vấn đề sau:

1 - Security: The security guarantees of existing poker protocols are not clearly defined, so it is hard to understand the level of security that these protocols actually provide and how reliable they are.

1 - Bảo mật: Các bảo đảm bảo mật của các giao thức poker hiện có không được xác định rõ ràng, vì vậy thật khó để hiểu mức độ bảo mật mà các giao thức này thực sự cung cấp và mức độ đáng tin cậy của chúng.

2 - Efficiency: Most of the existing poker protocols rely on costly cryptographic techniques that incur high computational and communication overheads, which in the real world result in boring games with long delays.

2 - Hiệu quả: Hầu hết các giao thức poker hiện có đều dựa vào các kỹ thuật mật mã tốn kém, phát sinh các chi phí tính toán và giao tiếp cao, trong thế giới thực dẫn đến các trò chơi nhàm chán với độ trễ dài.

3 - Financial considerations: Previous poker protocols could not ensure that winners received their financial rewards, even though classic cryptographic techniques could ensure that a game of poker was played honestly (i.e. without allowing players to cheat or learn each other’s private data).

3 - Cân nhắc tài chính: Các giao thức poker trước đây không thể đảm bảo rằng người chiến thắng nhận được phần thưởng tài chính của họ, mặc dù các kỹ thuật mật mã cổ điển có thể đảm bảo rằng một trò chơi poker được chơi một cách trung thực (tức là mà không cho phép người chơi gian lận hoặc tìm hiểu dữ liệu riêng tư của nhau).

In a recent paper to be presented at the [Financial Cryptography 2018 conference](http://fc18.ifca.ai/program.html "Financial Cryptography 2018"), we construct [Kaleidoscope](https://eprint.iacr.org/2017/899 "Kaleidoscope, eprint, IACR"), the first cryptographic poker protocol to address all three issues above. Kaleidoscope is the first protocol to be proven secure according to a comprehensive security model that formally and clearly captures all the properties and guarantees commonly required from a poker protocol. Moreover, Kaleidoscope employs blockchain techniques to ensure that winners receive their rewards and that cheaters are financially penalized. Even though it is mathematically proven to achieve security while providing financial rewards and penalty enforcements, Kaleidoscope achieves very high efficiency in comparison to existing solutions (which have not been formally proven secure). 

Trong một bài báo gần đây sẽ được trình bày tại Hội nghị [Cryptography 2018] (http://fc18.ifca.ai/program.html "Cryptography 2018"), chúng tôi xây dựng [Kaleidoscope] (https: //eprint.iacr.
org/2017/899 "Kính vạn hoa, Eprint, IARC"), Giao thức poker mật mã đầu tiên để giải quyết cả ba vấn đề ở trên.
Kính vạn hoa là giao thức đầu tiên được chứng minh an toàn theo mô hình bảo mật toàn diện, chính thức và rõ ràng nắm bắt tất cả các thuộc tính và đảm bảo thường được yêu cầu từ một giao thức poker.
Hơn nữa, kính vạn hoa sử dụng các kỹ thuật blockchain để đảm bảo rằng người chiến thắng nhận được phần thưởng của họ và những kẻ gian lận bị phạt tài chính.
Mặc dù đã được chứng minh về mặt toán học để đạt được bảo mật trong khi cung cấp các phần thưởng tài chính và thực thi hình phạt, Kaleidoscope đạt được hiệu quả rất cao so với các giải pháp hiện có (chưa được chính thức chứng minh an toàn).

The first step in designing Kaleidoscope was formally defining the security guarantees that a poker protocol should achieve. Since such formal definitions are missing from current literature, we provide the first security definitions for poker in the so-called simulation paradigm, which is the gold standard for cryptographic protocol security. Our security definitions take into consideration all phases of a poker game, modeling the security guarantees obtained for each of them and the conditions under which they hold. Namely, we model security against very powerful adversaries who can attack all but one player. This worst case scenario also captures the case where many players in a game collude in order to cheat against one single player.

Bước đầu tiên trong việc thiết kế kính vạn hoa là chính thức xác định các đảm bảo bảo mật mà một giao thức poker nên đạt được.
Vì các định nghĩa chính thức như vậy bị thiếu trong tài liệu hiện tại, chúng tôi cung cấp các định nghĩa bảo mật đầu tiên cho poker trong mô hình mô phỏng được gọi là, là tiêu chuẩn vàng cho bảo mật giao thức mật mã.
Các định nghĩa bảo mật của chúng tôi xem xét tất cả các giai đoạn của một trò chơi poker, mô hình hóa các bảo đảm bảo mật thu được cho mỗi trong số chúng và các điều kiện mà chúng giữ.
Cụ thể, chúng tôi mô hình hóa bảo mật chống lại những kẻ thù rất mạnh mẽ, những người có thể tấn công tất cả trừ một người chơi.
Kịch bản trường hợp xấu nhất này cũng nắm bắt được trường hợp nhiều người chơi trong một trò chơi thông đồng để lừa dối một người chơi.

With a proper formal model in place, we developed Kaleidoscope, a highly efficient protocol that can be proven to realize our security definitions. Our protocol builds on cutting-edge zero knowledge proofs of shuffle correctness and is carefully crafted to achieve the best possible efficiency in terms of computation and communication. In fact, as shown in an [upcoming work](https://eprint.iacr.org/2018/157 "Royale, ePrint, IACR"), Kaleidoscope achieves high security guarantees while requiring three times less computation and eight times less communication than the best previous protocols (without formal security guarantees).

Với một mô hình chính thức thích hợp, chúng tôi đã phát triển Kính vạn hoa, một giao thức hiệu quả cao có thể được chứng minh để nhận ra các định nghĩa bảo mật của chúng tôi.
Giao thức của chúng tôi xây dựng dựa trên các bằng chứng kiến thức không tiên tiến về tính chính xác của sự xáo trộn và được chế tạo cẩn thận để đạt được hiệu quả tốt nhất có thể về mặt tính toán và giao tiếp.
Trên thực tế, như thể hiện trong một [tác phẩm sắp tới] (https://eprint.iacr.org/2018/157 "Royale, Eprint, IACR"), Kính vạn hoa đạt được bảo đảm bảo mật cao trong khi yêu cầu tính toán ít hơn ba lần và giao tiếp ít hơn tám lần tám lần hơn tám lần
hơn các giao thức tốt nhất trước đây (không đảm bảo bảo mật chính thức).

Another important feature of Kaleidoscope is that it ensures that winners will receive their rewards, and that cheaters will be financially penalized as well as kicked out of the game. The basic idea is that, before a game starts all players send to a smart contract the funds they will be using for betting and an amount of "collateral" funds. At the end of the game, the smart contract ensures that the betting funds are distributed to the players according to the outcome of the game and that the collateral funds are returned. In case a player is caught cheating (which is ensured by our protocol), the smart contract confiscates the cheater’s collateral funds and distributes those among the honest players as compensation. Moreover, we show that the communication with the smart contract and the on-chain storage requirements are minimal.

Một tính năng quan trọng khác của Kính vạn hoa là nó đảm bảo rằng người chiến thắng sẽ nhận được phần thưởng của họ, và những kẻ gian lận sẽ bị phạt tài chính cũng như bị loại khỏi trò chơi.
Ý tưởng cơ bản là, trước khi một trò chơi bắt đầu, tất cả người chơi gửi đến một hợp đồng thông minh, các khoản tiền họ sẽ sử dụng để đặt cược và số tiền "tài sản thế chấp".
Vào cuối trò chơi, hợp đồng thông minh đảm bảo rằng các quỹ cá cược được phân phối cho người chơi theo kết quả của trò chơi và các quỹ tài sản thế chấp được trả lại.
Trong trường hợp người chơi bị bắt gặp gian lận (được đảm bảo bởi giao thức của chúng tôi), hợp đồng thông minh tịch thu các quỹ tài sản thế chấp của kẻ lừa đảo và phân phối những người trong số những người chơi trung thực là bồi thường.
Hơn nữa, chúng tôi cho thấy rằng giao tiếp với hợp đồng thông minh và các yêu cầu lưu trữ trên chuỗi là tối thiểu.

Although Kaleidoscope successfully addresses the three issues described above in the context of poker protocols, it can only be used to play poker games. There is a false common sense notion that poker protocols can be used for playing any other card games, which would actually lead to serious security issues. However, in the case of Kaleidoscope we were able to extend our formal security model, protocol and proofs to general card games. In doing so, we have obtained [Royale](https://eprint.iacr.org/2018/157 "Royale, ePrint, IACR"), a protocol that can be securely used to play any card game with the same efficiency as Kaleidoscope. We will be describing Royale’s features and techniques in an upcoming series of videos and blog posts.

Mặc dù kính vạn hoa giải quyết thành công ba vấn đề được mô tả ở trên trong bối cảnh giao thức poker, nhưng nó chỉ có thể được sử dụng để chơi các trò chơi poker.
Có một khái niệm thông thường sai lầm rằng các giao thức poker có thể được sử dụng để chơi bất kỳ trò chơi bài nào khác, điều này thực sự sẽ dẫn đến các vấn đề bảo mật nghiêm trọng.
Tuy nhiên, trong trường hợp của kính vạn hoa, chúng tôi có thể mở rộng mô hình bảo mật chính thức, giao thức và bằng chứng cho các trò chơi thẻ chung.
Khi làm như vậy, chúng tôi đã có được [Royale] (https://eprint.iacr.org/2018/157 "Royale, Eprint, IACR"), một giao thức có thể được sử dụng một cách an toàn để chơi bất kỳ trò chơi thẻ nào có cùng hiệu quả như
Kính vạn hoa.
Chúng tôi sẽ mô tả các tính năng và kỹ thuật của Royale trong một loạt các video và bài đăng trên blog sắp tới.

## **Attachments**

## ** tệp đính kèm **

![](img/2018-03-01-kaleidoscope-a-cryptographic-protocol-for-securely-playing-poker.004.png)[ Kaleidoscope – a cryptographic protocol](https://ucarecdn.com/aa487d9f-2087-4db4-a94e-d54d8ff5291b/-/inline/yes/ "Kaleidoscope – a cryptographic protocol")

