# Semi-Formal Development: The Cardano Wallet
![](img/2018-06-04-semi-formal-development-the-cardano-wallet.002.png) 4 June 2018![](img/2018-06-04-semi-formal-development-the-cardano-wallet.002.png)[ Edsko de Vries](tmp//en/blog/authors/edsko-de-vries/page-1/)![](img/2018-06-04-semi-formal-development-the-cardano-wallet.003.png) 17 mins read

![Edsko de Vries](img/2018-06-04-semi-formal-development-the-cardano-wallet.004.png)[](tmp//en/blog/authors/edsko-de-vries/page-1/)
### [**Edsko de Vries**](tmp//en/blog/authors/edsko-de-vries/page-1/)
Software Engineer

Well-Typed

- ![](img/2018-06-04-semi-formal-development-the-cardano-wallet.005.png)[](http://www.linkedin.com/in/edsko-de-vries-04126b31 "LinkedIn")
- ![](img/2018-06-04-semi-formal-development-the-cardano-wallet.006.png)[](https://twitter.com/EdskoDeVries "Twitter")
- ![](img/2018-06-04-semi-formal-development-the-cardano-wallet.007.png)[](https://github.com/edsko "GitHub")

![Semi-Formal Development: The Cardano Wallet](img/2018-06-04-semi-formal-development-the-cardano-wallet.008.jpeg)

*Please note: this post originally appeared on the [Well-Typed blog](http://www.well-typed.com/blog/2018/05/semi-formal-development/ "well-typed.com").*

*Xin lưu ý: Bài đăng này ban đầu xuất hiện trên [blog được loại tốt] (http://www.well-typed.com/blog/2018/05/semi-formal-development/ "well-yped.com").
*

**TL;DR:** A combination of formal modelling and testing using QuickCheck is a powerful tool in the design and implementation of high assurance software. Consistency of the model can be checked by testing invariants, and the real implementation can be tested by comparing it against the model. 

** TL; DR: ** Một sự kết hợp giữa mô hình và thử nghiệm chính thức bằng QuickCheck là một công cụ mạnh mẽ trong việc thiết kế và triển khai phần mềm đảm bảo cao.
Tính nhất quán của mô hình có thể được kiểm tra bằng cách kiểm tra bất biến và việc triển khai thực sự có thể được kiểm tra bằng cách so sánh nó với mô hình.

As part of our consulting work for IOHK, Well-Typed have been working with IOHK on the design and implementation of the new version of the Cardano cryptocurrency wallet. As a crucial component of this process, we have written a [semi-formal specification of the wallet](https://cardanodocs.com/files/formal-specification-of-the-cardano-wallet.pdf "Formal Specification of the Cardano Wallet, cardanodocs.com"): a mathematical model of the wallet along with invariants and lemmas about how it behaves.

Là một phần của công việc tư vấn của chúng tôi cho IOHK, được gõ tốt đã làm việc với IOHK về thiết kế và thực hiện phiên bản mới của ví tiền điện tử Cardano.
Là một thành phần quan trọng của quá trình này, chúng tôi đã viết một [đặc điểm kỹ thuật bán chính thức của ví] (https://cardanodocs.com/files/formal-specification-of-the-cardano-wallet.pdf "Đặc điểm chính thức của
Ví Cardano, cardanodocs.com "): Một mô hình toán học của ví cùng với bất biến và bổ đề về cách cư xử của nó.

We refer to this specification as â€œsemi-formalâ€ because while it states many of the walletâ€™s properties, and proves some of them, it by no means proves *all* of them. As we will see, however, we can use QuickCheck to test such properties, producing counter-examples where they fail to hold. Not only is this an invaluable tool during the development of the specification itself, it also gives us a very principled way of testing the real implementation, even if later we *do* prove all the remaining properties as well.

Chúng tôi đề cập đến đặc điểm kỹ thuật này là "semi-formal" bởi vì trong khi nó nêu rõ các thuộc tính của ví và chứng minh một số trong số chúng, nó không có nghĩa là tất cả * trong số chúng.
Tuy nhiên, như chúng ta sẽ thấy, chúng ta có thể sử dụng QuickCheck để kiểm tra các thuộc tính như vậy, tạo ra các ví dụ đối lập khi chúng không giữ được.
Đây không chỉ là một công cụ vô giá trong quá trình phát triển thông số kỹ thuật, nó còn cung cấp cho chúng ta một cách rất nguyên tắc để kiểm tra việc thực hiện thực sự, ngay cả khi sau này chúng ta * làm * chứng minh tất cả các thuộc tính còn lại.

In this blog post we will take a look at the specification and see how it drives the design and testing of the new wallet. We will show parts of the formal development, but only to give some idea about what it looks like; we will not really discuss any of its details. The goal of this blog post is not to describe the mathematics but rather the approach and its advantages.

Trong bài đăng trên blog này, chúng tôi sẽ xem xét đặc điểm kỹ thuật và xem cách nó thúc đẩy thiết kế và thử nghiệm ví mới.
Chúng tôi sẽ hiển thị các phần của sự phát triển chính thức, nhưng chỉ để đưa ra một số ý tưởng về những gì nó trông như thế nào;
Chúng tôi sẽ không thực sự thảo luận về bất kỳ chi tiết của nó.
Mục tiêu của bài đăng trên blog này không phải là để mô tả toán học mà là cách tiếp cận và lợi thế của nó.

Note: all figure, invariant and section numbers used in this blog post refer to [version 1.1 of the specification](https://cardanodocs.com/files/formal-specification-of-the-cardano-wallet.pdf "Formal Specification of the Cardano Wallet, cardanodocs.com").

Lưu ý: Tất cả các số, bất biến và các số phần được sử dụng trong bài đăng trên blog này Tham khảo [Phiên bản 1.1 của đặc điểm kỹ thuật] (https://cardanodocs.com/files/formal-specification-of-the-cardano-wallet.pdf "Đặc điểm chính thức
của ví Cardano, cardanodocs.com ").

## **Background: UTxO-style Accounting**

## ** Bối cảnh: Kế toán theo phong cách UTXO **

Regular bank transactions transfer from and to bank accounts. For example, a transaction might transfer $100 from Alice to Bob. Transactions in cryptocurrencies such as Cardano or Bitcoin are a little different. The to part is similar, except that there might be multiple â€œoutputsâ€; for example, a transaction might transfer $70 to Bob and $30 to Carol. The *from* part however works in quite a distinct way; transaction inputs are not accounts but *other transactions*. For example, letâ€™s call the transaction that transfers $70 to Bob and $30 to Carol â€œt1â€.

Giao dịch ngân hàng thường xuyên chuyển từ và vào tài khoản ngân hàng.
Ví dụ, một giao dịch có thể chuyển 100 đô la từ Alice sang Bob.
Các giao dịch trong tiền điện tử như Cardano hoặc Bitcoin có một chút khác nhau.
Một phần là tương tự, ngoại trừ việc có thể có nhiều â € œOutputsâ €;
Ví dụ, một giao dịch có thể chuyển $ 70 cho Bob và $ 30 cho Carol.
Tuy nhiên, phần * từ * hoạt động theo một cách khá khác biệt;
Đầu vào giao dịch không phải là tài khoản mà là *các giao dịch khác *.
Ví dụ: hãy gọi giao dịch chuyển 70 đô la cho Bob và 30 đô la cho Carol - T1â €.

t1 	inputs:	â€¦

T1

`	`outputs:	$70 to Bob, $30 to Carol

`

Now suppose Bob wants to transfer $50 to Dave. He can create a new transaction that says â€œtake the first output of transaction t1, transfer $50 to Dave and transfer $20 back to meâ€

Bây giờ giả sử Bob muốn chuyển $ 50 cho Dave.
Anh ta có thể tạo một giao dịch mới cho biết "đầu ra đầu tiên của giao dịch T1, chuyển 50 đô la cho Dave và chuyển 20 đô la trở lại cho tôi"

[](#1)

[] (#1)

1

1

.

.

t2	inputs:	first output of t1

T2

`	`outputs:	$50 to Dave, $20 to Bob

`

It is important that Bob transfers the $20 â€œchangeâ€ back to himself, because a transaction output can be â€œspentâ€ (that is, used as an input) only once. This style of transactions is called â€œUTxOâ€ style; UTxO stands for â€œUnspent Transaction (Tx) Outputsâ€.

Điều quan trọng là Bob chuyển đổi 20 đô la - trở lại với chính mình, bởi vì một đầu ra giao dịch có thể là - œSpentâ € (nghĩa là được sử dụng làm đầu vào) chỉ một lần.
Phong cách giao dịch này được gọi là phong cách â € œutxoâ €;
UTXO là viết tắt của đầu ra giao dịch â € œSpent (TX).

The *blockchain* is basically a long list of such transactions. The corresponding formal definition looks something like this.

* Blockchain * về cơ bản là một danh sách dài các giao dịch như vậy.
Các định nghĩa chính thức tương ứng trông giống như thế này.

![Figure 1](img/2018-06-04-semi-formal-development-the-cardano-wallet.009.png)

## **Wallet**

## **Cái ví**

The cryptocurrencyâ€™s *wallet* is a piece of software that monitors the state of the blockchain, keeps track of the userâ€™s funds (more precisely, their UTxO) and enables them to create new transactions to be included into the blockchain. The wallet is the primary means by which users interact with the blockchain. Note that the verification of these new transactions and the decision whether or not to include them into the global blockchain is not up to the wallet; how this happens is beyond the scope of this blog post.

Ví tiền điện tử * là một phần mềm theo dõi trạng thái của blockchain, theo dõi các quỹ của người dùng (chính xác hơn là UTXO của họ) và cho phép họ tạo các giao dịch mới được đưa vào blockchain
.
Ví là phương tiện chính để người dùng tương tác với blockchain.
Lưu ý rằng việc xác minh các giao dịch mới này và quyết định có nên đưa chúng vào blockchain toàn cầu không phải là ví hay không;
Làm thế nào điều này xảy ra là vượt quá phạm vi của bài đăng trên blog này.

A formal specification of the wallet is a mathematical abstraction that strips away all irrelevant detail and just focuses on the core functionality of the wallet. In the basic model of the Cardano wallet, we stripped down the wallet state to just the walletâ€™s UTxO and its set of pending transactions; the specification is small enough to fit on a single page.

Một đặc điểm kỹ thuật chính thức của ví là một sự trừu tượng toán học, loại bỏ tất cả các chi tiết không liên quan và chỉ tập trung vào chức năng cốt lõi của ví.
Trong mô hình cơ bản của ví Cardano, chúng tôi đã tước bỏ trạng thái ví để chỉ UTXO của ví và tập hợp các giao dịch đang chờ xử lý của nó;
Các đặc điểm kỹ thuật đủ nhỏ để phù hợp với một trang.

![Figure 3](img/2018-06-04-semi-formal-development-the-cardano-wallet.010.png)

Such a model is simple enough to be studied in-depth and support mathematical proofs of its properties. Yet it is accurate enough to be an invaluable guide in the design of the wallet and be the base for unit tests that drive the real implementation. It can also be used to study where we most need to worry about performance and how we can address those concerns.

Một mô hình như vậy đủ đơn giản để được nghiên cứu chuyên sâu và hỗ trợ bằng chứng toán học về các thuộc tính của nó.
Tuy nhiên, nó đủ chính xác để trở thành một hướng dẫn vô giá trong thiết kế ví và là cơ sở cho các bài kiểm tra đơn vị thúc đẩy việc thực hiện thực sự.
Nó cũng có thể được sử dụng để nghiên cứu nơi chúng ta cần lo lắng nhất về hiệu suất và làm thế nào chúng ta có thể giải quyết những mối quan tâm đó.

## **Balance**

## **THĂNG BẰNG**

As an example of one of the trickier aspects of the walletâ€™s design, we will discuss reporting balance in a bit more detail. It may be surprising that reporting balance is non-trivial, but even for regular bank accounts we already have two notions of balance. After Alice transfers $100 to Bob, her online bank account might tell her

Như một ví dụ về một trong những khía cạnh khó khăn hơn trong thiết kế của ví, chúng tôi sẽ thảo luận về số dư báo cáo chi tiết hơn một chút.
Có thể đáng ngạc nhiên là số dư báo cáo là không tầm thường, nhưng ngay cả đối với các tài khoản ngân hàng thông thường, chúng tôi đã có hai khái niệm về số dư.
Sau khi Alice chuyển 100 đô la cho Bob, tài khoản ngân hàng trực tuyến của cô ấy có thể cho cô ấy biết

- Your **current balance** is $1000.

- Số dư hiện tại ** của bạn ** là $ 1000.

- There is a pending transaction of $100, so your available balance is $900.

- Có một giao dịch đang chờ xử lý 100 đô la, vì vậy số dư khả dụng của bạn là 900 đô la.

Unlike regular bank transactions, UTxO-style transactions involve *change*; this leads naturally to *three* notions of balance. If we take as example transaction t2 above, Bobâ€™s balance might be reported as

Không giống như các giao dịch ngân hàng thông thường, các giao dịch kiểu UTXO liên quan đến *thay đổi *;
Điều này dẫn đến * ba * khái niệm về sự cân bằng.
Nếu chúng ta lấy làm giao dịch ví dụ T2 ở trên, số dư của Bob có thể được báo cáo là

- Your **UTxO balance** is $1070.

- Số dư ** UTXO của bạn ** là $ 1070.

- There is a pending transaction t2, so your **available balance** is $1000.

- Có một giao dịch đang chờ xử lý T2, vì vậy số dư có sẵn ** của bạn ** là $ 1000.

- However, transaction t2 returns $20 in change, so your **total balance** is $1020.

- Tuy nhiên, giao dịch T2 trả về 20 đô la thay đổi, vì vậy tổng số dư ** của bạn ** là $ 1020.

Note that the change from t2 becomes available only when transaction t2 has been included into the blockchain.

Lưu ý rằng sự thay đổi từ T2 chỉ có sẵn khi giao dịch T2 đã được đưa vào blockchain.

Although there are user interface questions here (how should we report these different kinds of balance to the user?), from the wallet design perspective this is not yet particularly difficult. The real complexity comes from the fact that there may be temporary disagreement about which transactions are included in the blockchain (such disagreements are known as â€œforksâ€; how they arise and are resolved is again well beyond the scope of this blog post).

Mặc dù có những câu hỏi giao diện người dùng ở đây (làm thế nào chúng ta nên báo cáo các loại cân bằng khác nhau này cho người dùng?), Từ góc độ thiết kế ví, điều này vẫn chưa đặc biệt khó khăn.
Sự phức tạp thực sự xuất phát từ thực tế là có thể có sự bất đồng tạm thời về các giao dịch nào được đưa vào blockchain (những bất đồng như vậy được gọi là "Lỗi - cách chúng phát sinh và được giải quyết một lần nữa vượt quá phạm vi của bài đăng trên blog này)
.

Letâ€™s stick to the above example, and suppose that t2 is pending, but there was disagreement about t1. After the disagreement got resolved the wallet discovers that t1 is not actually present in the blockchain after all (perhaps it will be later). The walletâ€™s *available* balance is now still $1000, but would it really make sense to report its *total* balance as $1020? It would be strange to have the total balance be *larger* than the UTxO balance; not wrong per se, but confusing nonetheless.

Hãy đề cập đến ví dụ trên và giả sử rằng T2 đang chờ xử lý, nhưng có sự bất đồng về T1.
Sau khi sự bất đồng đã được giải quyết, ví phát hiện ra rằng T1 không thực sự có mặt trong blockchain sau tất cả (có lẽ sẽ là sau này).
Số dư * có sẵn * của ví hiện vẫn là $ 1000, nhưng có thực sự có ý nghĩa khi báo cáo số dư * tổng * của nó là $ 1020 không?
Sẽ thật kỳ lạ khi có tổng số dư là * lớn hơn * so với số dư UTXO;
Không sai mỗi se, nhưng dù sao cũng khó hiểu.

In the specification we therefore define the concept of *minimum* balance: the minimum (UTxO) balance of the user â€œacross all possible futuresâ€; this is the only balance the user can be certain of. In the example, this is the future in which neither t1 nor t2 ever make it into the blockchain, and hence we report $1000 as the minimum balance (note that it can never happen that t2 is included but t1 is not, since t2 depends on t1). While this concept makes intuitive sense, in order to make it precise and be able to compute it we needed to introduce the concept of â€œexpected UTxOâ€: unspent transaction outputs that the wallet *expects* will become available in the future but havenâ€™t yet.

Do đó, trong thông số kỹ thuật, chúng tôi xác định khái niệm về số dư * tối thiểu *: số dư tối thiểu (UTXO) của người dùng - tất cả các tương lai có thể có - tương lai có thể có;
Đây là số dư duy nhất mà người dùng có thể chắc chắn.
Trong ví dụ, đây là tương lai mà cả T1 và T2 không bao giờ đưa nó vào blockchain và do đó chúng tôi báo cáo $ 1000 là số dư tối thiểu (lưu ý rằng nó không bao giờ có thể xảy ra rằng T2 được bao gồm nhưng T1 không, vì T2 phụ thuộc vào
T1).
Mặc dù khái niệm này có ý nghĩa trực quan, để làm cho nó chính xác và có thể tính toán nó, chúng tôi cần phải giới thiệu khái niệm về các sản phẩm giao dịch không được mong đợi: ví mà ví * mong đợi * sẽ trở nên có sẵn trong tương lai nhưng Havenâ
€ ™ chưa.

![Figure 8](img/2018-06-04-semi-formal-development-the-cardano-wallet.011.png)

Of course, even without a formal specification it is possible that we could have come up with this concept of minimum balance and a way to compute it. But having the formal model allows us to think much more clearly about the problems, remove all the clutter that surrounds a â€œrealâ€ implementation of the wallet and focus only on the core ideas.

Tất nhiên, ngay cả khi không có một đặc điểm kỹ thuật chính thức, có thể chúng ta có thể đưa ra khái niệm cân bằng tối thiểu này và một cách để tính toán nó.
Nhưng có mô hình chính thức cho phép chúng ta suy nghĩ rõ ràng hơn nhiều về các vấn đề, loại bỏ tất cả sự lộn xộn bao quanh việc thực hiện ví và chỉ tập trung vào các ý tưởng cốt lõi.

## **Internal consistency: invariants**

## ** Tính nhất quán nội bộ: bất biến **

When we introduce a novel concept such as â€œexpected UTxOâ€ into the specification, there is a tricky question: how do we know that what we specified is right? Actually, since we introduced the concept ourselves, the question of whether it was â€œrightâ€ or not is not particularly meaningful. Instead we ask: is what we specified *useful*?

Khi chúng tôi giới thiệu một khái niệm mới lạ như "UTXO được dự kiến vào đặc điểm kỹ thuật, có một câu hỏi khó: Làm thế nào để chúng tôi biết rằng những gì chúng tôi đã chỉ định là đúng?
Trên thực tế, vì chúng tôi đã tự mình giới thiệu khái niệm này, câu hỏi liệu đó có phải là không đúng hay không phải là đặc biệt có ý nghĩa.
Thay vào đó chúng tôi hỏi: những gì chúng tôi đã chỉ định *hữu ích *?

One way to answer this question is by stating invariants. Invariants are properties that we expect to be true at all times. For example, for the basic model shown above (Figure 3) we have the following invariant:

Một cách để trả lời câu hỏi này là bằng cách nêu bất biến.
Bất biến là những thuộc tính mà chúng ta mong đợi sẽ đúng mọi lúc.
Ví dụ: đối với mô hình cơ bản được hiển thị ở trên (Hình 3), chúng ta có bất biến sau:

Invariant 3.4. txins pending âŠ† dom utxo

Bất biến 3.4.
TXIN đang chờ xử lý â † dom utxo

What this invariant says is that the pending transactions can only spend from the walletâ€™s unspent outputs. Intuitively, this makes a lot of sense: the wallet should not allow the user to spend funds they donâ€™t have. As we have seen however in the previous section, this invariant does not always hold when we take disagreements about the blockchain into account! When Bob submits transaction t2, spending an output of transaction t1, and only later discovers that actually t1 should not have been included in the blockchain after all, he will have spent an output that is not in his UTxO.

Điều bất biến này nói là các giao dịch đang chờ xử lý chỉ có thể chi tiêu từ các đầu ra chưa được sử dụng của ví.
Theo trực giác, điều này rất có ý nghĩa: ví không nên cho phép người dùng chi tiêu tiền mà họ không có.
Tuy nhiên, như chúng ta đã thấy trong phần trước, sự bất biến này không phải lúc nào cũng giữ được khi chúng ta bất đồng về blockchain vào tài khoản!
Khi Bob gửi giao dịch T2, chi tiêu đầu ra của giao dịch T1 và chỉ sau đó phát hiện ra rằng thực sự T1 không nên được đưa vào blockchain, sau tất cả, anh ta sẽ dành một đầu ra không có trong UTXO của mình.

The concept of expected UTxO comes to the rescue, again. The invariant for the full model is instead:

Khái niệm UTXO dự kiến sẽ đến giải cứu, một lần nữa.
Thay vào đó, bất biến cho mô hình đầy đủ là:

Invariant 7.8. txins pending âŠ† dom (utxo âˆª expected)

Bất biến 7.8.
TXIN đang chờ xử lý â † DOM (UTXO ª dự kiến)

In other words, pending transactions can only spend available outputs or outputs that we expect to become available (because they were previously).

Nói cách khác, các giao dịch đang chờ xử lý chỉ có thể chi tiêu các đầu ra hoặc đầu ra có sẵn mà chúng tôi mong đợi sẽ có sẵn (vì trước đây chúng).

Another useful invariant that helps further solidify our intuition about what we mean by expected UTxO says that an output can never be in *both* the actual UTxO and the expected UTxO

Một bất biến hữu ích khác giúp củng cố thêm trực giác của chúng tôi về ý nghĩa của UTXO dự kiến nói rằng một đầu ra không bao giờ có thể ở * cả * UTXO thực tế và UTXO dự kiến

Invariant 7.6. dom utxo âˆ© dom expected = âˆ…

Bất biến 7.6.
DOM UTXO âˆ © DOM dự kiến = Âˆ

After all, it would be strange to say that an output is expected if we already have it in our wallet. Stating invariants like this allows us to make our intuitions about the concepts we introduce precise, and proving them gives us strong guarantees that our specification makes sense and is internally consistent.

Rốt cuộc, sẽ thật lạ khi nói rằng một đầu ra được mong đợi nếu chúng ta đã có nó trong ví của chúng ta.
Nói những bất biến như thế này cho phép chúng ta thực hiện trực giác về các khái niệm chúng ta giới thiệu chính xác và chứng minh chúng cho chúng ta đảm bảo mạnh mẽ rằng đặc điểm kỹ thuật của chúng ta có ý nghĩa và phù hợp trong nội bộ.

## **Semi-formal development**

## ** Phát triển bán chính thức **

Formally proving invariants such as the ones discussed above can be time consuming and requires mathematical training. Naturally, doing the proofs would be ideal, but the main point of this blog post is that we push this approach a long way even if we donâ€™t. After all, we program in Haskell precisely because we can easily translate back and forth between Haskell and mathematics.

Chính thức chứng minh những bất biến như những người được thảo luận ở trên có thể tốn thời gian và yêu cầu đào tạo toán học.
Đương nhiên, làm bằng chứng sẽ là lý tưởng, nhưng điểm chính của bài đăng trên blog này là chúng tôi thúc đẩy cách tiếp cận này một chặng đường dài ngay cả khi chúng tôi không.
Rốt cuộc, chúng tôi lập trình trong Haskell chính xác bởi vì chúng tôi có thể dễ dàng dịch qua lại giữa Haskell và Toán học.

To translate the various wallet models from the specification, we use the approach we described in a previous blog on [Object Oriented Programming](http://www.well-typed.com/blog/2018/03/oop-in-haskell/ "OOP in Haskell, well-typed.com") in Haskell (indeed, we developed that approach specifically for this purpose). For instance, here is the Haskell translation of the basic model:

Để dịch các mô hình ví khác nhau từ đặc điểm kỹ thuật, chúng tôi sử dụng cách tiếp cận mà chúng tôi đã mô tả trong một blog trước trên [Lập trình hướng đối tượng] (http://www.well-typed.com/blog/2018/03/oop-in-Haskell
.
Chẳng hạn, đây là bản dịch Haskell của mô hình cơ bản:

mkWallet :: (Hash h a, Ord a, Buildable st)

MKWALLET :: (Hash H A, Ord A, Buildable St)

`         `=> Ours a -> Lens' st (State h a) -> WalletConstr h a st

`` => Của chúng tôi A -> Lens 'St (State H A) -> WalletConst

mkWallet ours l self st =

mkwallet của chúng tôi L self st =

`  `(mkDefaultWallet (l . statePending) self st) {

``

`      `utxo       = st ^. l . stateUtxo

`` utxo = st ^.
l.
Stateutxo

`    `, ours       = ours

``, của chúng tôi = của chúng tôi

`    `, applyBlock = \b -> self (st & l %~ applyBlock' ours b)

``, applicationBlock = \ b -> self (st & l %

`    `}

``}

applyBlock' :: Hash h a

Áp dụng ':: Hash H A

`            `=> Ours a -> Block h a -> State h a -> State h a

`` => Của chúng tôi a -> khối h a -> trạng thái h a -> trạng thái h a

applyBlock' ours b State{..} = State {

Ứng dụng 'của chúng tôi b trạng thái {..} = state {

`    `\_stateUtxo    = updateUtxo ours b \_stateUtxo

ings

`  `, \_statePending = updatePending   b \_statePending

``, \ _statepending = updatePending b \ _statepending

`  `}

``}

updateUtxo :: forall h a. Hash h a

UpdateUTXO :: forall h a.
Băm h a

`           `=> Ours a -> Block h a -> Utxo h a -> Utxo h a

`` => Của chúng tôi a -> khối h a -> utxo h a -> utxo h a

updateUtxo p b = remSpent . addNew

UpdateUtXO P B = remspent.
thêm mới

`  `where

`` Ở đâu

`    `addNew, remSpent :: Utxo h a -> Utxo h a

`` addNew, remspent :: utxo h a -> utxo h a

`    `addNew   = utxoUnion (utxoRestrictToOurs p (txOuts b))

`trên

`    `remSpent = utxoRemoveInputs (txIns b)

`` remspent = utxoremoveInputs (txins b)

updatePending :: Hash h a

UpdatePpend :: Hash H A

`              `=> Block h a -> Pending h a -> Pending h a

`` => Khối h a -> đang chờ h a -> đang chờ h a

updatePending b = Map.filter $ \t -> disjoint (trIns t) (txIns b)

UpdatePending b = map.filter $ \ t -> Disjoint (trins t) (txins b)

It deals with more details than the specification; for instance, it explicitly abstracts away from a specific choice of hash h, as well the types of addresses a. It is therefore a bit more complicated than the spec, but it nonetheless follows the specification very closely. In particular, it is still a model: it does not deal with any networking issues or persistent storage, may not be particularly performant, etc. In other words, this is not intended to be the design of the *real* wallet. Having this model is nonetheless incredibly useful, for two reasons. The first is that we can use it to *test* the real wallet; we will discuss that in the next section.

Nó liên quan đến nhiều chi tiết hơn đặc điểm kỹ thuật;
Ví dụ, nó tóm tắt rõ ràng từ một lựa chọn cụ thể của băm H, cũng như các loại địa chỉ a.
Do đó, nó phức tạp hơn một chút so với thông số kỹ thuật, nhưng dù sao nó cũng tuân theo đặc điểm kỹ thuật rất chặt chẽ.
Cụ thể, nó vẫn là một mô hình: nó không giải quyết bất kỳ vấn đề mạng nào hoặc lưu trữ liên tục, có thể không đặc biệt hiệu quả, v.v. Nói cách khác, đây không phải là thiết kế của ví * thực *.
Có mô hình này dù sao cũng vô cùng hữu ích, vì hai lý do.
Đầu tiên là chúng ta có thể sử dụng nó để * kiểm tra * ví thật;
Chúng tôi sẽ thảo luận điều đó trong phần tiếp theo.

The second reason is that we can use the model to test the invariants. For example, here is the translation of Invariants 7.8 and 7.6 from the previous section to Haskell:

Lý do thứ hai là chúng ta có thể sử dụng mô hình để kiểm tra các bất biến.
Ví dụ, đây là bản dịch của bất biến 7.8 và 7.6 từ phần trước sang Haskell:

pendingInUtxoOrExpected :: WalletInv h a

pandinginutxoorexpected :: walletinv h a

pendingInUtxoOrExpected l e =

PendingInutXoorExpected l e =

`  `invariant (l <> "/pendingInUtxoOrExpected") e $ \w ->

`` bất biến (l <> "/pandinginutxoorexpected") e $ \ w ->

`   `checkSubsetOf

`` Checksubsetof

`    `("txins pending",

`` ("Txins đang chờ xử lý",

`      `txIns (pending w))

`` TXIN (đang chờ W))

`    `("utxo âˆª expected",

`` ("Utxo âˆª dự kiến",

`      `utxoDomain (utxo w) `Set.union` utxoDomain (expectedUtxo w))

`` utxodomain (utxo w) `set.union` utxodomain (mong đợixo w))

utxoExpectedDisjoint :: WalletInv h a

utxoexpecteddisjoint :: walletinv h a

utxoExpectedDisjoint l e =

utxoexpecteddisjoint l e =

`  `invariant (l <> "/utxoExpectedDisjoint") e $ \w ->

`` bất biến (l <> "/utxoExpectedDisjoint") e $ \ w ->

`   `checkDisjoint

`` Checkdisjoint

`    `("dom utxo",

`` ("dom utxo",

`      `utxoDomain (utxo w))

`` Utxodomain (UTXO W))

`    `("dom expected",

`` ("dom dự kiến",

`      `utxoDomain (expectedUtxo w))

`` utxodomain (mong đợixo w))

As for the wallet implementation, the Haskell translation of the invariants deals with more details than the spec; in this case, one of the main differences is that the infrastructure for these invariants is designed to give detailed error reports when the invariants do *not* hold. Nonetheless, the main part of the invariant is again a direct translation of the specification.

Đối với việc thực hiện ví, bản dịch Haskell của các bất biến liên quan đến nhiều chi tiết hơn thông số kỹ thuật;
Trong trường hợp này, một trong những khác biệt chính là cơ sở hạ tầng cho các bất biến này được thiết kế để đưa ra các báo cáo lỗi chi tiết khi các bất biến làm * không * giữ.
Tuy nhiên, phần chính của bất biến một lần nữa là một bản dịch trực tiếp của đặc điểm kỹ thuật.

The big gain is that we can now use QuickCheck to test these invariants. We generate random (but valid) events for the wallet (â€œapply this blockâ€, â€œsubmit this new transactionâ€, â€œswitch to a different forkâ€) and then check that the invariants hold at each point. For example, in the first release of the wallet specification there was a silly mistake: when the wallet was notified of a new block, it removed the *inputs* of that block from the expected UTxO, rather than the *outputs*. A silly mistake, but easy to miss when just reviewing the specification by hand. A proof would have found the mistake, of course, but so can QuickCheck:

Mức tăng lớn là bây giờ chúng ta có thể sử dụng QuickCheck để kiểm tra các bất biến này.
Chúng tôi tạo ra các sự kiện ngẫu nhiên (nhưng hợp lệ) cho ví ("Ứng dụng khối này", hãy thông báo giao dịch mới này "," "
Ví dụ, trong bản phát hành đầu tiên của đặc tả ví, có một sai lầm ngớ ngẩn: khi ví được thông báo về một khối mới, nó đã loại bỏ *đầu vào *của khối đó khỏi UTXO dự kiến, thay vì *đầu ra *.
Một sai lầm ngớ ngẩn, nhưng dễ bỏ lỡ khi chỉ xem xét các đặc điểm kỹ thuật bằng tay.
Một bằng chứng sẽ tìm thấy sai lầm, tất nhiên, nhưng QuickCheck cũng vậy:

Wallet unit tests

Bài kiểm tra đơn vị ví

`  `Test pure wallets

`` Kiểm tra ví tinh khiết

`    `Using Cardano model FAILED [1]

`` Sử dụng mô hình Cardano không thành công [1]

Failures:

Thất bại:

`  `test/unit/Test/Spec/Models.hs:36:

`` Kiểm tra/Đơn vị/Test/Spec/Model.HS: 36:

`  `1) Wallet unit tests, Test pure wallets, Using Cardano model

`` 1) Bài kiểm tra đơn vị ví, kiểm tra ví tinh khiết, sử dụng mô hình Cardano

`       `predicate failed on: Invalid [] InvariantViolation {

`` vị từ không thành công trên: không hợp lệ [] bất biếnTViolation {

`           `name:     full/utxoExpectedDisjoint

`` Tên: Full/UTXoExpectedDisjoint

`         `, evidence: NotSubsetOf {

``, Bằng chứng: notsubsetof {

`                 `dom utxo: ..

`` Dom utxo: ..

`               `, dom expected: ..

``, dom mong đợi: ..

`               `, dom utxo `intersection` dom expected: ..

``, dom utxo `intersection` dom mong đợi: ..

`             `}

``}

`         `, events:   {

``, Sự kiện: {

`                 `state: ..

`` Trạng thái: ..

`               `, action: ApplyBlock ..

``, Hành động: Áp dụng ..

`               `, state: ..

``, trạng thái: ..

`               `, action: NewPending Transaction{ .. }

``, Hành động: Giao dịch mới {..}

`               `, state: ..

``, trạng thái: ..

`               `..

`` ..

`               `, action: Rollback

``, hành động: rollback

`               `..

`` ..

`             `}

``}

`         `}

``}

Not only does this tell us that the invariant did not hold; it actually gives us the specific sequence of events that lead to the wallet state in which the invariant does not hold (as well as all the intermediate wallet states), and it tells what the domain of the UTxO and the expected UTxOs are in that state as well as their intersection (which should have been empty but wasnâ€™t).

Điều này không chỉ cho chúng ta biết rằng bất biến không giữ được;
Nó thực sự cung cấp cho chúng ta chuỗi các sự kiện cụ thể dẫn đến trạng thái ví trong đó bất biến không giữ (cũng như tất cả các trạng thái ví trung gian), và nó cho biết miền của UTXO và UTXO dự kiến ở trạng thái đó là gì trong trạng thái đó
cũng như giao điểm của họ (đáng lẽ phải trống nhưng không phải là).

## **Testing the real implementation**

## ** Kiểm tra triển khai thực sự **

As mentioned, the Haskell translation of the wallet specification is still a model which ignores a lot of the real world complexity that the full wallet implementation must deal with. Even the datatypes that the model works with are simplified versions of the real thing: transactions donâ€™t include signatures, blocks are not real blocks but just lists of transactions, etc.

Như đã đề cập, bản dịch Haskell của đặc tả ví vẫn là một mô hình bỏ qua rất nhiều sự phức tạp trong thế giới thực mà việc triển khai ví đầy đủ phải đối phó.
Ngay cả các kiểu dữ liệu mà mô hình hoạt động với các phiên bản đơn giản hóa của thực tế: các giao dịch không bao gồm chữ ký, các khối không phải là khối thực mà chỉ là danh sách các giao dịch, v.v.

Nonetheless, we can use the model to test the real implementation also. We can *translate* the simplified types of the model to their real counterparts. Since we have QuickCheck generators for the simplified types *and* we can test the model because we have an implementation of it, we can test the real wallet as shown in the following commuting diagram:

Tuy nhiên, chúng ta cũng có thể sử dụng mô hình để kiểm tra việc triển khai thực sự.
Chúng ta có thể * dịch * các loại mô hình đơn giản hóa sang các đối tác thực sự của chúng.
Vì chúng tôi có trình tạo QuickCheck cho các loại đơn giản hóa * và * chúng tôi có thể kiểm tra mô hình vì chúng tôi có việc triển khai nó, chúng tôi có thể kiểm tra ví thực như trong sơ đồ đi lại sau:

![Commute](img/2018-06-04-semi-formal-development-the-cardano-wallet.012.png)

In words, what this means is that we use the QuickCheck generator to generate wallet events using the simplified model types and then do two things:

Theo lời, điều này có nghĩa là chúng tôi sử dụng trình tạo QuickCheck để tạo các sự kiện ví bằng cách sử dụng các loại mô hình đơn giản hóa và sau đó thực hiện hai điều:

- We execute the model on the simplified types and translate *after*.

- Chúng tôi thực thi mô hình trên các loại đơn giản hóa và dịch *sau *.

- We translate *first* and then execute the real wallet on the translated input.

- Chúng tôi dịch * Đầu tiên * và sau đó thực thi ví thực trên đầu vào được dịch.

Either way, we end up with two final answers (both in terms of the real Cardano types), one executed in the model and one executed in the real wallet. We can compare these two, and if they match we can conclude that the real wallet implements the model correctly. Since we check this property at each step and we know that the invariants hold in the model at each step, we can then also conclude that the invariants hold in the real implementation at each step.

Dù bằng cách nào, chúng tôi kết thúc với hai câu trả lời cuối cùng (cả về loại Cardano thực), một câu được thực hiện trong mô hình và một câu được thực hiện trong ví Real.
Chúng ta có thể so sánh hai điều này và nếu chúng phù hợp, chúng ta có thể kết luận rằng ví thực thực thực hiện mô hình một cách chính xác.
Vì chúng tôi kiểm tra thuộc tính này ở mỗi bước và chúng tôi biết rằng các bất biến giữ trong mô hình ở mỗi bước, sau đó chúng tôi cũng có thể kết luận rằng các bất biến nắm giữ trong quá trình thực hiện thực sự ở mỗi bước.

For example, when a bug in the full wallet meant that change from pending transactions was sometimes double-counted (in the case where pending transactions use the change of other pending transactions as inputs, a case that can only happen in the presence of forks), the generator will be able to find a counter-example to the above commuting diagram, and then give us the exact sequence of wallet events that leads to a wallet state in which the real wallet and the model disagree as well as the precise value that they disagree on.

Ví dụ: khi một lỗi trong ví đầy đủ có nghĩa là thay đổi từ các giao dịch đang chờ xử lý đôi khi được tính gấp đôi (trong trường hợp các giao dịch đang chờ xử lý sử dụng sự thay đổi của các giao dịch đang chờ xử lý khác làm đầu vào, một trường hợp chỉ có thể xảy ra khi có Fork)
, Trình tạo sẽ có thể tìm thấy một ví dụ đối với sơ đồ đi lại ở trên, và sau đó cung cấp cho chúng tôi chuỗi các sự kiện ví chính xác dẫn đến trạng thái ví trong đó ví thực và mô hình không đồng ý cũng như giá trị chính xác mà giá trị mà
Họ không đồng ý.

## **Conclusions**

## ** Kết luận **

Software specifications, where they exist at all, are often informal documents that describe the features that the software is intended to have in natural language. Such specifications do not lend themselves easily to verification or even testing. At the other end of the spectrum, fully formal specifications where every property is verified mathematically are costly and time consuming to produce and require specialized expertise. They are of course the golden standard, but there is also a useful middle-ground: by specifying the model and its properties formally, we can test its properties using QuickCheck. Moreover, we get a model in which we can reason about the core functionality of the application and which we can then *compare* against the real implementation.

Thông số kỹ thuật phần mềm, nơi chúng tồn tại, thường là các tài liệu không chính thức mô tả các tính năng mà phần mềm dự định có bằng ngôn ngữ tự nhiên.
Thông số kỹ thuật như vậy không cho vay dễ dàng để xác minh hoặc thậm chí thử nghiệm.
Ở đầu kia của quang phổ, các thông số kỹ thuật chính thức hoàn toàn trong đó mọi tài sản được xác minh về mặt toán học đều tốn kém và tốn thời gian để sản xuất và yêu cầu chuyên môn chuyên môn.
Tất nhiên chúng là tiêu chuẩn vàng, nhưng cũng có một trung gian hữu ích: bằng cách chỉ định mô hình và tính chất của nó một cách chính thức, chúng ta có thể kiểm tra các thuộc tính của nó bằng QuickCheck.
Hơn nữa, chúng ta có được một mô hình trong đó chúng ta có thể lý luận về chức năng cốt lõi của ứng dụng và sau đó chúng ta có thể * so sánh * với việc thực hiện thực.

IOHKâ€™s development of the new wallet is open source and can be found on GitHub. Excitingly, IOHK have recently hired someone to start work on the Coq formalization of the wallet specification, which will put the whole specification on an even stronger footing. Of course, that does not make any of the existing work useless: although it will become less important to test the invariants in the model, having the QuickCheck generators available to check the real implementation is still very valuable. Moreover, having the QuickCheck tests validate the invariants before we attempt to prove them formally can also save valuable time if we discover early that an invariant is not, in fact, true.

Sự phát triển của IOHK của ví mới là nguồn mở và có thể được tìm thấy trên GitHub.
Thật thú vị, IOHK gần đây đã thuê một người nào đó bắt đầu công việc chính thức hóa CoQ của đặc tả ví, điều này sẽ đưa toàn bộ đặc điểm kỹ thuật lên một bước chân thậm chí còn mạnh mẽ hơn.
Tất nhiên, điều đó không làm cho bất kỳ công việc hiện tại nào trở nên vô dụng: mặc dù việc kiểm tra các chất bất biến trong mô hình sẽ trở nên ít quan trọng hơn trong mô hình, việc có sẵn các trình tạo QuickCheck để kiểm tra triển khai thực sự vẫn rất có giá trị.
Hơn nữa, việc các bài kiểm tra QuickCheck xác nhận các bất biến trước khi chúng tôi cố gắng chứng minh chúng chính thức cũng có thể tiết kiệm thời gian có giá trị nếu chúng ta phát hiện ra sớm rằng một bất biến trên thực tế không phải là sự thật.

## **References**

## **Người giới thiệu**

[](https://cardanodocs.com/files/formal-specification-of-the-cardano-wallet.pdf)

[] (https://cardanodocs.com/files/formal-specification-of nào

"Formal specification for a Cardano walletâ€, Duncan Coutts and Edsko de Vries 

"Đặc điểm kỹ thuật chính thức cho ví Cardano, Duncan Coutts và Edsko de Vries

[](https://github.com/input-output-hk/cardano-sl/tree/develop/wallet-new)

[] (https:

GitHub repository for the new wallet

Kho lưu trữ GitHub cho ví mới

-----

-----

\1. We ignore transaction fees for the sake of simplicity.

\ 1.
Chúng tôi bỏ qua phí giao dịch vì sự đơn giản.

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2018-06-04-semi-formal-development-the-cardano-wallet.013.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

