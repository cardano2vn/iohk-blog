# A major brand refresh for Cardano *
### **How IOHK Creative redesigned the brand with form following function**
![](img/2018-06-07-a-major-brand-refresh-for-cardano.002.png) 7 June 2018![](img/2018-06-07-a-major-brand-refresh-for-cardano.002.png)[ Richard Wild](tmp//en/blog/authors/richard-wild/page-1/)![](img/2018-06-07-a-major-brand-refresh-for-cardano.003.png) 9 mins read

![Richard Wild](img/2018-06-07-a-major-brand-refresh-for-cardano.004.png)[](tmp//en/blog/authors/richard-wild/page-1/)
### [**Richard Wild**](tmp//en/blog/authors/richard-wild/page-1/)
Creative Director

Creative

- ![](img/2018-06-07-a-major-brand-refresh-for-cardano.005.png)[](https://uk.linkedin.com/in/richard-wild-a0552026 "LinkedIn")
- ![](img/2018-06-07-a-major-brand-refresh-for-cardano.006.png)[](https://twitter.com/IOHK_Richard "Twitter")

![A major brand refresh for Cardano \*](img/2018-06-07-a-major-brand-refresh-for-cardano.007.png)

In January, [Charles Hoskinson](https://www.youtube.com/watch?v=Ja9D0kpksxw "Charles Hoskinson Whiteboard, youtube.com") messaged to say heâ€™d come across an online video that he wanted us to check out. I took a look at the link he sent, and found that it was indeed eye catching. A cryptocurrency fan had studied Cardano, and had made an animation of its [development history](https://www.youtube.com/watch?v=YtSfJqP04cQ "History of Cardano, Git vizualisation"). The data visualisation showed each piece of Cardano code appear on the screen as a brightly coloured node, at the time it had been written over the past two or so years. From only a handful in number, over time they mushroomed on the screen, resulting in a complex structure with many interconnecting parts.

Vào tháng 1, [Charles Hoskinson] (https://www.youtube.com/watch?v=JA9D0KPKSXW "Charles Hoskinson Whiteboard, YouTube.com")
Thủ tục thanh toán.
Tôi đã xem xét liên kết anh ấy gửi, và thấy rằng đó thực sự là bắt mắt.
Một người hâm mộ tiền điện tử đã nghiên cứu Cardano, và đã thực hiện một hoạt hình về [lịch sử phát triển] của nó (https://www.youtube.com/watch?v=YTSFJQP04CQ "Lịch sử của Cardano, Git Vizualisation").
Trực quan hóa dữ liệu cho thấy từng đoạn mã Cardano xuất hiện trên màn hình dưới dạng một nút có màu sắc rực rỡ, tại thời điểm nó đã được viết trong hai năm qua.
Chỉ từ một số ít về số lượng, theo thời gian chúng mọc lên trên màn hình, dẫn đến một cấu trúc phức tạp với nhiều bộ phận kết nối.

This sparked an idea at IOHK. Weâ€™ve had our fair share of trolls, making false accusations online that Cardano is "vapourware", i.e. that we have no product. This animation wasnâ€™t just beautiful, it was functional, because it destroyed those claims completely. Using data freely available from the development website [GitHub](tmp//en/projects/cardano/ "Cardano, GitHub"), where Cardano developers had registered each piece of code as it was written, you could not only see how active they had been, but that Cardano was for a long period the most intensely developed cryptocurrency of all. We wanted to see where we could take this idea.

Điều này đã gây ra một ý tưởng tại IOHK.
Chúng tôi đã có phần troll công bằng của chúng tôi, đưa ra những lời buộc tội sai lầm trên mạng rằng Cardano là "Vapourware", tức là chúng tôi không có sản phẩm.
Hoạt hình này không chỉ đẹp, nó có chức năng, bởi vì nó đã phá hủy hoàn toàn những tuyên bố đó.
Sử dụng dữ liệu có sẵn miễn phí từ trang web phát triển [GitHub] (TMP // EN/Dự án/Cardano/"Cardano, GitHub"), nơi các nhà phát triển Cardano đã đăng ký từng đoạn mã như đã viết, bạn không chỉ thấy họ hoạt động như thế nào
đã được, nhưng Cardano trong một thời gian dài là tiền điện tử phát triển mạnh mẽ nhất trong tất cả.
Chúng tôi muốn xem nơi chúng tôi có thể lấy ý tưởng này.

The visualisation made by a user named Crypto Gource 

Trực quan hóa được thực hiện bởi người dùng có tên Crypto Gource

The design team had recently started a project to refresh our brand across the portfolio of Cardano websites. We would overhaul the design of each website and the information it displayed. We would make the websites more intuitive to use and convey data more effectively and in an information-rich way. This would give users the big picture but also allow them to drill down to understand details in a way that had not been done before with any cryptocurrency project.

Nhóm thiết kế gần đây đã bắt đầu một dự án để làm mới thương hiệu của chúng tôi trên danh mục các trang web Cardano.
Chúng tôi sẽ đại tu thiết kế của từng trang web và thông tin nó hiển thị.
Chúng tôi sẽ làm cho các trang web trực quan hơn để sử dụng và truyền tải dữ liệu hiệu quả hơn và theo một cách giàu thông tin.
Điều này sẽ cung cấp cho người dùng bức tranh lớn nhưng cũng cho phép họ đi sâu vào để hiểu chi tiết theo cách chưa được thực hiện trước đây với bất kỳ dự án tiền điện tử nào.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.008.jpeg)

![](img/2018-06-07-a-major-brand-refresh-for-cardano.009.jpeg)

Scott Darby and Juli Sudi from IOHK Creative

Scott Darby và Juli Sudi từ IOHK Creative

Because the animation had been so captivating but also served a useful purpose, we decided to make it an intrinsic part of our design refresh and [Scott Darby](tmp//en/team/scott-darby/ "Scott Darby, IOHK Team"), IOHK creative coder, got to work. Meanwhile, visual designer [Juli Sudi](tmp//en/team/juli-sudi/ "Juli Sudi, IOHK Team") would lead the rest of the work, and create a recognisable look and feel for the brand. 

Bởi vì hoạt hình đã rất quyến rũ nhưng cũng phục vụ một mục đích hữu ích, chúng tôi quyết định biến nó thành một phần nội tại của việc làm mới thiết kế của chúng tôi và [Scott Darby] (TMP // EN/Team/Scott-Darby/"Scott Darby, IOHK Team"
), IOHK Creative Coder, đã làm việc.
Trong khi đó, nhà thiết kế trực quan [Juli Sudi] (TMP // EN/Team/Juli-Sudi/"Juli Sudi, IOHK Team") sẽ dẫn dắt phần còn lại của tác phẩm và tạo ra một cái nhìn và cảm nhận dễ nhận biết cho thương hiệu.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.010.jpeg)[ ](https://ucarecdn.com/3a84f7d1-6ddf-4cbe-8d89-e45c5fed8d19/)Evolution of the initial designs

## **Groundwork**

## ** Nền tảng **

Juli says: "The first steps for me were finding a style direction and creating core visual elements that could be shared across the pages and serve as a backbone of further design efforts." 

Juli nói: "Những bước đầu tiên đối với tôi là tìm ra một hướng phong cách và tạo ra các yếu tố hình ảnh cốt lõi có thể được chia sẻ trên các trang và phục vụ như một xương sống của những nỗ lực thiết kế tiếp theo."

She chose iconography and experimented with colour pallets and layout styles. For each potential direction she created a test design using the base theme in different ways, such as varying the icon style, typography, spacing, colour swatches and gradient options. The test versions were shared with the team to gather feedback and to choose the elements to be taken further. 

Cô chọn biểu tượng và thử nghiệm các pallet màu và kiểu bố trí.
Đối với mỗi hướng tiềm năng, cô đã tạo ra một thiết kế thử nghiệm bằng cách sử dụng chủ đề cơ sở theo các cách khác nhau, chẳng hạn như thay đổi kiểu biểu tượng, kiểu chữ, khoảng cách, swatch màu và tùy chọn độ dốc.
Các phiên bản thử nghiệm đã được chia sẻ với nhóm để thu thập phản hồi và chọn các yếu tố sẽ được thực hiện xa hơn.

After many experiments and ideas, we landed on the principle that the design should be very functional. Colours would represent something rather than be chosen just because they were pleasing. The form should follow the function. We approved a direction that was still a rough concept, but was an agreed starting point for building up the new design.

Sau nhiều thí nghiệm và ý tưởng, chúng tôi đã đưa ra nguyên tắc rằng thiết kế nên rất chức năng.
Màu sắc sẽ đại diện cho một cái gì đó hơn là được chọn chỉ vì chúng được làm hài lòng.
Hình thức nên tuân theo hàm.
Chúng tôi đã phê duyệt một hướng mà vẫn là một khái niệm sơ bộ, nhưng là điểm khởi đầu đã được thống nhất để xây dựng thiết kế mới.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.011.jpeg) 

Felix Koutchinski

Felix Koutchinski

## **Community Involvement**

## ** Sự tham gia của cộng đồng **

Next, Juli began a discussion with a community member and graphic designer from Stuttgart, Germany, named Felix Koutchinski. He had come to our attention after he wrote a [blog about the Cardano roadmap](https://www.koutchinski.de/blog/2018/3/12/cardano-roadmap "Cardano roadmap blog") design. His feedback became important and we worked with him closely. The community should be involved in everything we do because ultimately this technology is theirs.

Tiếp theo, Juli bắt đầu một cuộc thảo luận với một thành viên cộng đồng và nhà thiết kế đồ họa từ Stuttgart, Đức, được đặt tên là Felix Koutchinski.
Anh ấy đã thu hút sự chú ý của chúng tôi sau khi anh ấy viết một [blog về lộ trình Cardano] (https://www.koutchinski.de/blog/2018/3/12/cardano-roadmap "Blog Roadmap Cardano").
Phản hồi của anh ấy trở nên quan trọng và chúng tôi đã làm việc chặt chẽ với anh ấy.
Cộng đồng nên tham gia vào mọi thứ chúng tôi làm bởi vì cuối cùng công nghệ này là của họ.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.012.jpeg) 

Chatting to Felix in an external Skype group

Trò chuyện với Felix trong một nhóm Skype bên ngoài

Discussion with Felix highlighted many points that we had overlooked about the roadmap. Without a filtering function, it was hard to find the information you were looking for. Sorting the tasks by progress or recent update was a high priority for visitors to the site. The development milestones did not follow each other chronologically but progressed in parallel, which called for a different style of navigation saving users' time moving down the page. We should show completed development more clearly. There should be a summary explaining each part of the project. Users should be able to filter content by category, such as development phase (Shelley, Goguen etc) or by whether the work was complete or not, or by who carried out the work (IOHK, Cardano Foundation, Emurgo).

Thảo luận với Felix nhấn mạnh nhiều điểm mà chúng tôi đã bỏ qua về lộ trình.
Không có chức năng lọc, thật khó để tìm thấy thông tin bạn đang tìm kiếm.
Sắp xếp các nhiệm vụ theo tiến trình hoặc cập nhật gần đây là ưu tiên cao đối với khách truy cập vào Trang web.
Các cột mốc phát triển không theo dõi nhau về mặt thời gian mà tiến triển song song, kêu gọi một phong cách khác nhau của việc tiết kiệm thời gian của người dùng di chuyển xuống trang.
Chúng ta nên cho thấy sự phát triển hoàn thành rõ ràng hơn.
Cần có một bản tóm tắt giải thích từng phần của dự án.
Người dùng có thể lọc nội dung theo danh mục, chẳng hạn như giai đoạn phát triển (Shelley, Goguen, v.v.) hoặc bằng cách hoàn thành công việc hay không, hoặc bằng cách thực hiện công việc (IOHK, Cardano Foundation, Emurgo).

Below, you can see three layouts. The first is the roadmap as it was, the second is Felixâ€™s design, and the third is the new layout we settled upon. 

Dưới đây, bạn có thể thấy ba bố cục.
Đầu tiên là lộ trình như nó là, thứ hai là thiết kế của Felix, và thứ ba là bố cục mới mà chúng tôi đã giải quyết.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.013.jpeg)[ ](https://ucarecdn.com/b4158529-36eb-4903-8acf-eb330336be2a/)

As these ideas were developing, Juli was also working on a colour pallet and style guide, below.

Khi những ý tưởng này đang phát triển, Juli cũng đang làm việc trên một pallet màu và hướng dẫn phong cách, bên dưới.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.014.jpeg)[ ](https://ucarecdn.com/dff565db-0bfd-42e5-8f16-e37eca1c7948/)

## **Medusa**

## ** Medusa **

[](#note)

[](#Ghi chú)

\*

\*

Meanwhile, Scott had been working on a proof of concept for Medusa. He studied the main source of the [repository](https://github.com/acaudwell/Gource "GitHub, Gource"). Crypto Gource's original video was offline, however we decided that Medusa would show updates as they were made in real time. Scott says: "This is a dynamic, living artwork, created from a Git repository directory structure. The visualisation is continually evolving in real time based on developer commits. Each time a commit is made, the edited files light up."

Trong khi đó, Scott đã làm việc trên một bằng chứng về khái niệm cho Medusa.
Ông đã nghiên cứu nguồn chính của [kho lưu trữ] (https://github.com/acaudwell/gource "Github, Gource").
Video gốc của Crypto Gource đã ngoại tuyến, tuy nhiên chúng tôi đã quyết định rằng Medusa sẽ hiển thị các bản cập nhật khi chúng được thực hiện trong thời gian thực.
Scott nói: "Đây là một tác phẩm nghệ thuật sống động, được tạo ra từ cấu trúc thư mục kho lưu trữ Git. Trực quan hóa liên tục phát triển theo thời gian thực dựa trên các cam kết của nhà phát triển. Mỗi lần thực hiện cam kết, các tệp được chỉnh sửa sáng lên."

![Medusa](img/2018-06-07-a-major-brand-refresh-for-cardano.015.jpeg)[ ](https://ucarecdn.com/cb587154-8185-43bc-b0b2-11e34e4ae5db/)

Files that have been recently edited are coloured red and dormant files are blue. We chose to make our visualisation 3D in contrast to the original 2D animation. We also found great ideas that we borrowed from [cardanoupdates.com](https://cardanoupdates.com/ "cardanoupdates.com"), a website produced by a community member.

Các tệp gần đây đã được chỉnh sửa là các tệp màu đỏ và không có màu xanh lam.
Chúng tôi đã chọn làm cho hình ảnh 3D của chúng tôi trái ngược với hoạt hình 2D gốc.
Chúng tôi cũng tìm thấy những ý tưởng tuyệt vời mà chúng tôi đã mượn từ [cardanoupdates.com] (https://cardanoupdates.com/ "cardanoupdates.com"), một trang web được sản xuất bởi một thành viên cộng đồng.

![Medusa](img/2018-06-07-a-major-brand-refresh-for-cardano.016.jpeg)[ ](https://ucarecdn.com/346b89f5-d95d-470e-868b-252545476e16/)

Medusa will feature on each Cardano website. For the best experience view Medusa on desktop with the latest version of Google Chrome, Mozilla Firefox, Opera, or Safari. Every development project has a different GitHub file structure, and Medusa will represent this and act as a unique fingerprint for each one. The full-screen view with rich interactive functionality is available by clicking on the glowing button in the header of the Cardano roadmap. In future we will include more features. These will offer viewers a means to explore the code, and understand more about the development in a way that is not only useful, but beautiful too. 

Medusa sẽ có trên mỗi trang web Cardano.
Để có trải nghiệm tốt nhất, hãy xem Medusa trên máy tính để bàn với phiên bản mới nhất của Google Chrome, Mozilla Firefox, Opera hoặc Safari.
Mỗi dự án phát triển đều có cấu trúc tệp GitHub khác nhau và Medusa sẽ đại diện cho điều này và hoạt động như một dấu vân tay duy nhất cho mỗi cái.
Chế độ xem toàn màn hình với chức năng tương tác phong phú có sẵn bằng cách nhấp vào nút phát sáng trong tiêu đề của lộ trình Cardano.
Trong tương lai, chúng tôi sẽ bao gồm nhiều tính năng hơn.
Những điều này sẽ cung cấp cho người xem một phương tiện để khám phá mã và hiểu thêm về sự phát triển theo cách không chỉ hữu ích, mà còn đẹp.

![Medusa Design](img/2018-06-07-a-major-brand-refresh-for-cardano.007.png)[ ](https://ucarecdn.com/ab8ff741-942c-46ab-9410-031d91f4da69/)

## **Bringing it all together**

## ** Mang tất cả lại với nhau **

At this point, senior full-stack developer [Tomas Vrana](tmp//en/team/tomas-vrana/ "Tomas Vrana, IOHK Team") began to work with Juli on bringing the designs to life in production. Tom helped refine the designs so they would work well in practice. One example was that if a user filtered content by the partner responsible for the work, it would not make sense to have a column displaying developer commits because Emurgo and the Cardano Foundation do not produce code. Medusa is still very much in its infancy, and at best a working proof of concept. Over time, we will be rolling it out across all devices, and bringing more functionality and intuitive widgets to the UX.

Tại thời điểm này, nhà phát triển đầy đủ cao cấp [Tomas Vrana] (TMP // EN/Team/Tomas-Vrana/"Tomas Vrana, nhóm IOHK") bắt đầu làm việc với Juli để đưa các thiết kế vào cuộc sống trong sản xuất.
Tom đã giúp tinh chỉnh các thiết kế để chúng sẽ hoạt động tốt trong thực tế.
Một ví dụ là nếu người dùng lọc nội dung bởi đối tác chịu trách nhiệm cho công việc, thì sẽ không có ý nghĩa gì khi có một cột hiển thị nhà phát triển cam kết vì EMURGO và Quỹ Cardano không tạo mã.
Medusa vẫn còn rất nhiều trong giai đoạn trứng nước, và tốt nhất là bằng chứng làm việc về khái niệm.
Theo thời gian, chúng tôi sẽ triển khai nó trên tất cả các thiết bị và mang lại nhiều chức năng và các vật dụng trực quan hơn cho UX.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.017.png)

![](img/2018-06-07-a-major-brand-refresh-for-cardano.008.jpeg)

Tomas Vrana and Alexander Rukin

Tomas Vrana và Alexander Rukin

The Cardano roadmap wasnâ€™t the first time we deployed the new designs â€“ they were used on the [Symphony of Blockchains](https://symphony.iohk.io "Symphony of Blockchains, iohk.io") and [Cardano Testnets](https://testnets.iohk.io "Cardano Testnets") websites that recently launched.

Lộ trình Cardano không phải là lần đầu tiên chúng tôi triển khai các thiết kế mới - Chúng được sử dụng trên [Giao hưởng của Blockchains] (https://symphony.iohk.io "Giao hưởng của blockchains, iohk.io").
Cardano Testnets] (https://testnets.iohk.io "Cardano Testnets")) mà gần đây đã ra mắt.

![Daedalus website redesign](img/2018-06-07-a-major-brand-refresh-for-cardano.018.jpeg)[ ](https://ucarecdn.com/286e9859-5122-491d-941f-ef5709a0a101/)New Daedalus website design with Medusa, coming soon

[Alexander Rukin](tmp//en/team/alexander-rukin/ "Alexander Rukin, IOHK Team") took Juliâ€™s designs and very quickly built the new [Cardano testnet](https://testnet.iohkdev.io/goguen/ "Cardano testnets") website that launched at the end of May. The wonderful thing about these new designs is that you can take and translate them for various uses. The content of the testnet website is very different from the roadmap and Alexander did a great job adapting the designs. Alexander is also responsible for the design of Daedalus. 

.
/ goguen/ "cardano testnets") trang web ra mắt vào cuối tháng 5.
Điều tuyệt vời về những thiết kế mới này là bạn có thể thực hiện và dịch chúng cho các mục đích sử dụng khác nhau.
Nội dung của trang web Testnet rất khác với lộ trình và Alexander đã làm rất tốt việc điều chỉnh các thiết kế.
Alexander cũng chịu trách nhiệm thiết kế của Daedalus.

![Cardano Testnets website](img/2018-06-07-a-major-brand-refresh-for-cardano.019.png)[ New Cardano testnet website](https://ucarecdn.com/b364183e-8d12-46d2-8688-347384476514/)

![](img/2018-06-07-a-major-brand-refresh-for-cardano.020.jpeg)

![](img/2018-06-07-a-major-brand-refresh-for-cardano.008.jpeg)

![](img/2018-06-07-a-major-brand-refresh-for-cardano.021.png)

Full-stack developers Jonathan Smillie, George Clark, and project manager Robert Moore

Các nhà phát triển đầy đủ Jonathan Smillie, George Clark, và quản lý dự án Robert Moore

[George Clark](tmp//en/team/george-clark/ "George Clark, IOHK Team") and [Jonathan Smillie](tmp//en/team/jonathan-smillie/ "Jonathan Smillie, IOHK Team"), who are full-stack web developers and designers, teamed up to give extra firepower to the testnet website launch. For the first time, Cardano is offering smart contract functionality for testing, and George and Jonny pulled long hours to ensure the website was successfully launched. An added challenge was that the new designs were delivered under a tight deadline, and project manager [Robert Moore](tmp//en/team/robert-moore/ "Robert Moore, IOHK Team") helped enormously to get us to the finishing line.

.
Ai là nhà phát triển và thiết kế web đầy đủ, đã hợp tác để cung cấp thêm hỏa lực để ra mắt trang web TestNet.
Lần đầu tiên, Cardano đang cung cấp chức năng hợp đồng thông minh để thử nghiệm, và George và Jonny đã kéo dài nhiều giờ để đảm bảo trang web được ra mắt thành công.
Một thách thức bổ sung là các thiết kế mới đã được thực hiện theo thời hạn chặt chẽ và người quản lý dự án [Robert Moore] (TMP // EN/Team/Robert-Moore/"Robert Moore, nhóm IOHK") đã giúp chúng tôi hoàn thiện
hàng.

![](img/2018-06-07-a-major-brand-refresh-for-cardano.022.jpeg)[ ](https://ucarecdn.com/7e92c06d-13a5-4bf8-ae36-97dd46525962/)

![Cardano Roadmap with Medusa](img/2018-06-07-a-major-brand-refresh-for-cardano.023.jpeg)[ ](https://ucarecdn.com/ecdfcd86-85dc-4dd2-8b30-9be1fe0ebcd0/)New Cardano roadmap with Medusa

Today, we launch the refreshed [Cardano roadmap](https://cardanoroadmap.com "cardanoroadmap.com"), where you can see the result of all the work described above. You can view the new features, from exploring the list of developer commits, to receiving notifications when the roadmap is released each month. 

Hôm nay, chúng tôi ra mắt [Lộ trình Cardano] được làm mới (https://cardanoroadmap.com "cardanoroadmap.com"), nơi bạn có thể thấy kết quả của tất cả các công việc được mô tả ở trên.
Bạn có thể xem các tính năng mới, từ việc khám phá danh sách các nhà phát triển cam kết, đến nhận thông báo khi lộ trình được phát hành mỗi tháng.

Weâ€™d love to hear your feedback, please let us know what you think. We may even end up working with you as we have done with other community members. 

Chúng tôi rất thích nghe phản hồi của bạn, xin vui lòng cho chúng tôi biết bạn nghĩ gì.
Chúng tôi thậm chí có thể kết thúc việc làm việc với bạn như chúng tôi đã làm với các thành viên khác trong cộng đồng.

Now for the first time Cardano has a real brand identity that exactly represents the project in a visual way. We will be rolling out this restyle across the rest of our assets, including [Why Cardano](https://whycardano.com/ "Why Cardano") and [Cardano docs](https://cardanodocs.com/ "Cardano docs"). Follow IOHKâ€™s [Twitter](https://twitter.com/InputOutputHK "IOHK, Twitter") and [YouTube](https://www.youtube.com/channel/UCBJ0p9aCW-W82TwNM-z3V2w "IOHK, YouTube") to stay updated. The redesign will completely redefine how you understand IOHK projects, and evolves how we communicate as a company. 

Bây giờ lần đầu tiên Cardano có một bản sắc thương hiệu thực sự đại diện chính xác cho dự án một cách trực quan.
Chúng tôi sẽ triển khai lại phần còn lại của tài sản còn lại, bao gồm [Tại sao Cardano] (https://whycardano.com/ "Tại sao Cardano") và [Cardano Docs] (https://cardanodocs.com/ "Cardano Docs Docs
").
Theo dõi [Twitter] (https://twitter.com/inputoutputhk "iohk, twitter") và [youtube] (https://www.youtube.com/channel/ucbj0p9acw-w82twnm
") Để cập nhật.
Thiết kế lại sẽ xác định lại hoàn toàn cách bạn hiểu các dự án IOHK và phát triển cách chúng tôi giao tiếp như một công ty.

At IOHK we believe that Cardano is not just a development project: it is distributed systems, it is social science, it is a political movement, and among other things, it is also a design challenge.

Tại IOHK, chúng tôi tin rằng Cardano không chỉ là một dự án phát triển: đó là các hệ thống phân phối, nó là khoa học xã hội, nó là một phong trào chính trị, và trong số những thứ khác, nó cũng là một thách thức thiết kế.

![Intuitive Roadmap navigation](img/2018-06-07-a-major-brand-refresh-for-cardano.024.png)[ ](https://ucarecdn.com/9ed82c63-531f-4f2c-8893-24cd338979f1/)New intuitive navigation 

![New Cardano Roadmap layout](img/2018-06-07-a-major-brand-refresh-for-cardano.025.png)[ ](https://ucarecdn.com/a7461b99-6368-44f0-8558-348672581a1c/)New layout gives a better perspective to the information presented

Join in the discussion about the [redesign project on the Cardano Forum](https://forum.cardano.org/t/iohk-announces-a-major-brand-refresh-for-cardano-and-reveal-new-gource-visualisation/12861 "IOHK announces major brand refresh for Cardano, forum.cardano.org").

Tham gia vào cuộc thảo luận về [dự án thiết kế lại trên Diễn đàn Cardano] (https://forum.cardano.org/t/iohk-announces-a-major-Brand-refresh-for-cardano-and-reveal-new-pource
-Visualisation/12861 "IOHK công bố làm mới thương hiệu lớn cho cardano, forum.cardano.org").

\*This blog has been edited to reflect the change of name for the project from Gource to Medusa.

\*Blog này đã được chỉnh sửa để phản ánh sự thay đổi tên cho dự án từ Gource sang Medusa.

