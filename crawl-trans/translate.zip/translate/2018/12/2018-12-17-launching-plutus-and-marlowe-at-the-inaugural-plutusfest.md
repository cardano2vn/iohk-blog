# Launching Plutus and Marlowe at the inaugural PlutusFest
### **IOHK’s new smart contract tools for developers and financiers**
![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.002.png) 17 December 2018![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.002.png)[ Amy Reeve](tmp//en/blog/authors/amy-reeve/page-1/)![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.003.png) 3 mins read

![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.004.png)[ Launching Plutus and Marlowe at the inaugural PlutusFest - Input Output](https://ucarecdn.com/83c2ef93-c19a-4c4b-b796-239c959fb849/-/inline/yes/ "Launching Plutus and Marlowe at the inaugural PlutusFest - Input Output")

![Amy Reeve](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.005.png)[](tmp//en/blog/authors/amy-reeve/page-1/)
### [**Amy Reeve**](tmp//en/blog/authors/amy-reeve/page-1/)
Technical Writer

Marketing and Communications

- ![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.006.png)[](https://www.linkedin.com/in/amy-reeve-8616b248/ "LinkedIn")
- ![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.007.png)[](https://github.com/jabbacakes "GitHub")

Last week IOHK hosted the inaugural PlutusFest at the University of Edinburgh. Members of the IOHK team flew in from around the world, with interested academics, developers, financiers, and members of the press also in attendance.

![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.008.jpeg) Professor Philip Wadler reprises his role 
as Lambda Man, PlutusFest style.
IOHK research fellow Philip Wadler opened the event - and his shirt, in traditional Lambda Man style - followed by a keynote from CEO and co-founder Charles Hoskinson, discussing the social nature of money, and why IOHK’s rigorous formal verification methods are even more important in the face of increasing decentralization.

Nghiên cứu viên IOHK Philip Wadler đã mở sự kiện - và áo sơ mi của anh ấy, theo phong cách Lambda Man truyền thống - tiếp theo là một bài phát biểu quan trọng từ CEO và đồng sáng lập Charles Hoskinson, thảo luận về bản chất xã hội của tiền bạc và tại sao các phương pháp xác minh chính thức nghiêm ngặt của IOHK thậm chí còn quan trọng hơn
khi đối mặt với sự phân cấp ngày càng tăng.

Professor Aggelos Kiayias also spoke about the work of the Edinburgh Blockchain Technology Lab (BTL), and how they are working in tandem with IOHK to accelerate the transition of new ideas from academia to real-world applications. During 2017 - 2018, 21 academic papers have been published or co-authored by IOHK and BTL researchers, with a further 20 already submitted and awaiting peer review.

Giáo sư Aggelos Kiayias cũng đã nói về công việc của Phòng thí nghiệm Công nghệ Blockchain (BTL) của Edinburgh, và cách họ làm việc song song với IOHK để tăng tốc chuyển đổi các ý tưởng mới từ học viện sang các ứng dụng trong thế giới thực.
Trong năm 2017 - 2018, 21 bài báo học thuật đã được xuất bản hoặc đồng tác giả bởi các nhà nghiên cứu IOHK và BTL, với thêm 20 người đã gửi và chờ đánh giá ngang hàng.

IOHK’s language architect Manuel Chakravarty introduced Plutus itself, a general-purpose Haskell-based functional programming language, designed for simplicity and longevity. It can be used to write both on- and off-chain applications, improving data transfer, code re-use, and developer experience when writing smart contracts, and minimizing the need for hard forks in the future.

Kiến trúc sư ngôn ngữ của IOHK, Manuel Chakravarty đã giới thiệu Plutus, một ngôn ngữ lập trình chức năng dựa trên Haskell có mục đích chung, được thiết kế cho sự đơn giản và tuổi thọ.
Nó có thể được sử dụng để viết cả các ứng dụng trên và ngoài chuỗi, cải thiện truyền dữ liệu, sử dụng lại mã và trải nghiệm nhà phát triển khi viết hợp đồng thông minh và giảm thiểu nhu cầu về các bản dựng khó khăn trong tương lai.

Like all functional programming languages, Plutus ensures secure, high assurance code by its very nature. During the design process, it was decided that the core semantics of Plutus should be concise and elegant enough to fit on a napkin - and sure enough, all attendees of PlutusFest received a limited edition Plutus napkin, along with Plutus t-shirts (and optional capes).

Giống như tất cả các ngôn ngữ lập trình chức năng, Plutus đảm bảo mã đảm bảo an toàn, cao theo bản chất của nó.
Trong quá trình thiết kế, người ta đã quyết định rằng ngữ nghĩa cốt lõi của Plutus phải ngắn gọn và đủ thanh lịch để phù hợp với khăn ăn - và chắc chắn, tất cả những người tham dự Plutusfest đã nhận được một chiếc áo choàng Plutus phiên bản giới hạn, cùng với áo phông Sao Diêm Vương (và tùy chọn
áo choàng).

![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.009.jpeg) Proof that the core semantics of Plutus fit on a (very fancy) napkin.

Professor Simon Thompson of the University of Kent also presented on IOHK’s Marlowe, a new user-focused domain-specific language designed to enable non-technical financiers to easily write on-chain smart contracts. The Marlowe research team have been working with business analysts to design smart contract templates, opening up the use of Cardano smart contracts directly to non-programmers in banks and other businesses, who will be able to automate financial transactions using cryptocurrency technology to save time and reduce costs.

Giáo sư Simon Thompson của Đại học Kent cũng đã trình bày về IOHK, Marlowe, một ngôn ngữ cụ thể do miền tập trung vào người dùng mới được thiết kế để cho phép các nhà tài chính phi kỹ thuật dễ dàng viết các hợp đồng thông minh trên chuỗi.
Nhóm nghiên cứu của Marlowe đã làm việc với các nhà phân tích kinh doanh để thiết kế các mẫu hợp đồng thông minh, mở ra việc sử dụng các hợp đồng thông minh Cardano trực tiếp cho các nhà lập trình trong các ngân hàng và các doanh nghiệp khác, những người sẽ có thể tự động hóa các giao dịch tài chính bằng công nghệ tiền điện tử để tiết kiệm thời gian và
giảm chi phí.

Plutus and Marlowe are being launched now to allow interested developers and financiers to experiment ahead of the Cardano Shelley release in 2019. You can try out Plutus in the [Plutus Playground](https://prod.playground.plutus.iohkdev.io/ "Plutus Playground"), a lightweight, web-based emulator for writing and executing smart contracts in Plutus. For Marlowe, there is the [Meadow](https://testnet.iohkdev.io/marlowe/tools/meadow/ "Meadow") emulator to try out as well, find out more [here](https://testnet.iohkdev.io/marlowe/ "Marlowe").

Diêm Plutus và Marlowe hiện đang được ra mắt để cho phép các nhà phát triển và tài chính quan tâm thử nghiệm trước khi phát hành Cardano Shelley vào năm 2019. Bạn có thể dùng thử Plutus trong [Plutus Playground] (https://prod.playground.plutus.iohkdev.io/
"Plutus Playground"), một trình giả lập dựa trên web nhẹ để viết và thực hiện các hợp đồng thông minh trong Plutus.
Đối với Marlowe, có [đồng cỏ] (https://testnet.iohkdev.io/marlowe/tools/meadow/ "đồng cỏ") để thử, hãy tìm hiểu thêm [tại đây] (https: // testnet.
iohkdev.io/marlowe/ "Marlowe").

Other talks during the event included a discussion of formal verification from IOHK’s director of engineering Duncan Coutts, as well as a series of academic talks covering System F-Omega and using Agda to formalize Plutus metatheory.

Các cuộc nói chuyện khác trong sự kiện này bao gồm một cuộc thảo luận về xác minh chính thức từ Giám đốc Kỹ thuật của IOHK, Duncan Coutts, cũng như một loạt các cuộc đàm phán học thuật bao gồm hệ thống F-OMEGA và sử dụng AGDA để chính thức hóa Plutus Metutitory.

The event also provided an opportunity for the IOHK team, who are based all around the world, to meet and work together in person. The Plutus and Marlowe teams spent some time discussing future development directions - and in some cases, meeting each other for the first time - while the broader IOHK team took the chance to talk strategy, planning, and goals for 2019.

Sự kiện này cũng cung cấp một cơ hội cho nhóm IOHK, những người có trụ sở trên toàn thế giới, để gặp gỡ và làm việc cùng nhau.
Các đội Plutus và Marlowe đã dành một chút thời gian để thảo luận về các hướng phát triển trong tương lai - và trong một số trường hợp, lần đầu tiên gặp nhau - trong khi nhóm IOHK rộng lớn hơn đã có cơ hội nói chuyện chiến lược, lập kế hoạch và mục tiêu cho năm 2019.

![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.009.jpeg) From left, Grigore Rosu of Runtime Verification, Stewart Mackenzie of Fractalide, community member Robert Kornacki, and IOHK’s Lars Brünjes hard at work before PlutusFest.

If you’re interested in hearing the presentations from PlutusFest, subscribe to the [IOHK YouTube channel](https://www.youtube.com/channel/UCBJ0p9aCW-W82TwNM-z3V2w "IOHK YouTube channel") where high quality, re-recorded versions of the talks will be posted soon. A more in-depth recap is also available on the [Cardano forum](https://forum.cardano.org/t/recap-plutusfest-2018-in-edinburgh-scotland/18560 "Cardano forum").

Nếu bạn muốn nghe các bài thuyết trình từ Plutusfest, hãy đăng ký vào [Kênh YouTube IOHK] (https://www.youtube.com/channel/ucbj0p9acw-w82twnm-z3v2w "
Các phiên bản được ghi lại của các cuộc đàm phán sẽ sớm được đăng.
Một bản tóm tắt chuyên sâu hơn cũng có sẵn trên [Diễn đàn Cardano] (https://forum.cardano.org/t/recap-plutusfest-2018-in-edinburgh-scotland/18560 "Diễn đàn Cardano").

## **Attachments**

## ** tệp đính kèm **

![](img/2018-12-17-launching-plutus-and-marlowe-at-the-inaugural-plutusfest.004.png)[ Launching Plutus and Marlowe at the inaugural PlutusFest - Input Output](https://ucarecdn.com/83c2ef93-c19a-4c4b-b796-239c959fb849/-/inline/yes/ "Launching Plutus and Marlowe at the inaugural PlutusFest - Input Output")

