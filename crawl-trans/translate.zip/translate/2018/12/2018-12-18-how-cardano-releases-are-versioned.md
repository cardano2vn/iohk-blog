# A guide to how Cardano is versioned
### **Tatyana Valkevych, Darko Mijić, and Jacob Mitchell explain**
![](img/2018-12-18-how-cardano-releases-are-versioned.002.png) 18 December 2018![](img/2018-12-18-how-cardano-releases-are-versioned.002.png)[ Tatyana Valkevych](tmp//en/blog/authors/tatyana-valkevych/page-1/)![](img/2018-12-18-how-cardano-releases-are-versioned.003.png) 6 mins read

![](img/2018-12-18-how-cardano-releases-are-versioned.004.png)[ Simplicity and Michelson - Input Output](https://ucarecdn.com/cb0054f1-4e81-4617-82c2-6a6a363270c7/-/inline/yes/ "Simplicity and Michelson - Input Output")

![Tatyana Valkevych](img/2018-12-18-how-cardano-releases-are-versioned.005.png)[](tmp//en/blog/authors/tatyana-valkevych/page-1/)
### [**Tatyana Valkevych**](tmp//en/blog/authors/tatyana-valkevych/page-1/)
Release Manager

Development

- ![](img/2018-12-18-how-cardano-releases-are-versioned.006.png)[](https://www.linkedin.com/in/tatyanavalkevych/ "LinkedIn")
- ![](img/2018-12-18-how-cardano-releases-are-versioned.007.png)[](https://twitter.com/tatyanavych "Twitter")
- ![](img/2018-12-18-how-cardano-releases-are-versioned.008.png)[](https://github.com/tatyanavych/ "GitHub")

![A guide to how Cardano is versioned](img/2018-12-18-how-cardano-releases-are-versioned.009.jpeg)

Cardano, the third-generation blockchain, is evolving. Cardano changes are planned as product increments within [Cardano development phases](https://cardanoroadmap.com/), and are implemented and released as Cardano software. In this blog, [product manager Darko Mijic](tmp//en/team/darko-mijic/), [release manager Tatyana Valkevych](tmp//en/team/tatyana-valkevych) and [devOps lead Jacob Mitchell](tmp//en/team/jacob-mitchell/) clarify how Cardano is versioned as a blockchain product and as software, and the correspondence between them.

Cardano, blockchain thế hệ thứ ba, đang phát triển.
Thay đổi Cardano được lên kế hoạch khi tăng sản phẩm trong [giai đoạn phát triển Cardano] (https://cardanoroadmap.com/) và được triển khai và phát hành dưới dạng phần mềm Cardano.
Trong blog này, [Trình quản lý sản phẩm Darko Mijic] (TMP // EN/Team/Darko-Mijic/), [Quản lý phát hành Tatyana Valkevych] (TMP // EN/Team/Tatyana-Valkevych) và [DevOps dẫn đầu Jacob Mitchell] (
TMP // EN/TEAM/JACOB-MITCHELL/) làm rõ cách Cardano được phiên bản như một sản phẩm blockchain và là phần mềm, và sự tương ứng giữa chúng.

## **Versioning Cardano as a product and as software**

## ** Phiên bản cardano như một sản phẩm và là phần mềm **

The Cardano *product* version reflects the evolution of Cardano as a sequence of new feature set deployments within a Cardano development phase, and uses the following versioning scheme of three numbers separated with dots:

Phiên bản Cardano * Sản phẩm * phản ánh sự phát triển của Cardano như một chuỗi các triển khai tập hợp tính năng mới trong giai đoạn phát triển Cardano và sử dụng sơ đồ phiên bản sau gồm ba số được phân tách bằng các dấu chấm:

**development\_phase.feature\_set-1.refinement**

** Phát triển \ _Phase.Feature \ _set-1.Refinement **

where the refinement part can be omitted. For example, the Cardano version in production at the time of writing this article is 1.3.2, which means it is the second refinement of the fourth feature set for the first development phase.

nơi phần hoàn thiện có thể được bỏ qua.
Ví dụ, phiên bản Cardano trong sản xuất tại thời điểm viết bài viết này là 1.3.2, điều đó có nghĩa là nó là sự tinh chỉnh thứ hai của tính năng thứ tư được đặt cho giai đoạn phát triển đầu tiên.

Cardano is currently approaching the end of its first development phase called Byron.

Cardano hiện đang tiếp cận kết thúc giai đoạn phát triển đầu tiên được gọi là Byron.

Cardano development phases are:

Các giai đoạn phát triển Cardano là:

1. **Byron (Cardano 1.N)** In the Byron phase a completely new cryptocurrency technology stack was designed and built, including entirely new code and the implementation of the first generation of Ouroboros, a provably secure proof of stake protocol (PoS) at its core. The settlement layer (Cardano SL) of Cardano was launched in a federated fashion with the system operated by [IOHK](tmp//en/), [Cardano Foundation](https://cardanofoundation.org/en/), and [Emurgo](https://emurgo.io/). It enabled the launch of ada cryptocurrency and allowed users to transfer and trade ada.

1. ** Byron (Cardano 1.n) ** Trong giai đoạn Byron, ngăn xếp công nghệ tiền điện tử hoàn toàn mới được thiết kế và xây dựng, bao gồm mã hoàn toàn mới và thực hiện thế hệ đầu tiên của Ouoboros, một bằng chứng an toàn về giao thức cổ phần (
Pos) ở cốt lõi của nó.
Lớp giải quyết (Cardano SL) của Cardano đã được ra mắt theo kiểu liên kết với hệ thống được vận hành bởi [IOHK] (TMP // EN/), [Cardano Foundation] (https://cardanofoundation.org/en/), và [và [và [
Emurgo] (https://emurgo.io/).
Nó cho phép ra mắt tiền điện tử ADA và cho phép người dùng chuyển và giao dịch ADA.

1. **Shelley (Cardano 2.N)** The Shelley phase will transition the settlement layer of Cardano from a federated to a completely decentralized system which will allow all users to participate in the protocol, and get rewards for producing blocks by staking individually or within stake pools.

1. ** Shelley (Cardano 2.N) ** Giai đoạn Shelley sẽ chuyển lớp giải quyết của Cardano từ một hệ thống liên kết sang một hệ thống phi tập trung hoàn toàn cho phép tất cả người dùng tham gia giao thức và nhận phần thưởng cho việc sản xuất các khối bằng cách đặt cược
cá nhân hoặc trong nhóm cổ phần.

1. **Goguen (Cardano 3.N)** The Goguen phase will bring the second collection of protocols with the computation layer (Cardno CL) deployed as side-chains to Cardano with support for smart contracts.

1. ** Goguen (Cardano 3.n) ** Pha Goguen sẽ mang lại bộ sưu tập giao thức thứ hai với lớp tính toán (CardNO CL) được triển khai dưới dạng chuỗi bên cho Cardano với sự hỗ trợ cho các hợp đồng thông minh.

1. **Basho (Cardano 4.N)** The Basho phase will be focused on performance, security, and scalability improvements. It will enable Cardano to scale to millions and billions of users.

1. ** Basho (Cardano 4.n) ** Pha Basho sẽ tập trung vào hiệu suất, bảo mật và cải thiện khả năng mở rộng.
Nó sẽ cho phép Cardano mở rộng quy mô lên hàng triệu và hàng tỷ người dùng.

1. **Voltaire (Cardano 5.N)** The final development phase, Voltaire, will add a treasury system and governance, enabling sustainability and self-sufficiency for Cardano.

1. ** Voltaire (Cardano 5.N) ** Giai đoạn phát triển cuối cùng, Voltaire, sẽ thêm một hệ thống kho bạc và quản trị, cho phép bền vững và tự cung cấp cho Cardano.

So far we have released four main stable Byron releases, which are referred to as Cardano 1.0, Cardano 1.1, Cardano 1.2, and Cardano 1.3.

Cho đến nay chúng tôi đã phát hành bốn bản phát hành Byron ổn định chính, được gọi là Cardano 1.0, Cardano 1.1, Cardano 1.2 và Cardano 1.3.

A new feature set implementation is delivered through a main stable release. In this case a release version may be represented by the first two numbers only: for example, Cardano 1.3 is the same as Cardano 1.3.0. Every main release may have subsequent refinement releases that include bug fixes and other improvements, but no new features. So far all main Cardano releases have been followed by refinement releases. It is important to stress that although a full Cardano product version consists of three numbers it does not follow [semantic versioning](http://semver.org).

Một triển khai bộ tính năng mới được cung cấp thông qua một bản phát hành ổn định chính.
Trong trường hợp này, một phiên bản phát hành có thể được biểu diễn bằng hai số đầu tiên: ví dụ, Cardano 1.3 giống như Cardano 1.3.0.
Mỗi bản phát hành chính có thể có các bản phát hành sàng lọc tiếp theo bao gồm các sửa lỗi và các cải tiến khác, nhưng không có tính năng mới.
Cho đến nay tất cả các bản phát hành Cardano chính đã được theo sau bởi các bản phát hành sàng lọc.
Điều quan trọng là nhấn mạnh rằng mặc dù phiên bản sản phẩm Cardano đầy đủ bao gồm ba số, nó không theo [phiên bản ngữ nghĩa] (http://semver.org).

The live Cardano product is represented by the latest software release, deployed on the Cardano mainnet. When a Cardano release is discussed on public channels it is the Cardano product version that is used by default. When we release a Cardano product increment we specify its software component versions in Release Notes on [daedaluswallet.io](https://daedaluswallet.io/release-notes/) and on GitHub [[Daedalus releases](https://github.com/input-output-hk/daedalus/releases), [Cardano SL releases](https://github.com/input-output-hk/cardano-sl/releases)]. Below we clarify the correspondence between Cardano product and Cardano software versions.

Sản phẩm Cardano trực tiếp được thể hiện bằng bản phát hành phần mềm mới nhất, được triển khai trên Cardano Mainnet.
Khi một bản phát hành Cardano được thảo luận trên các kênh công khai, đó là phiên bản sản phẩm Cardano được sử dụng theo mặc định.
Khi chúng tôi phát hành mức tăng sản phẩm Cardano, chúng tôi chỉ định các phiên bản thành phần phần mềm của nó trong các ghi chú phát hành trên [Daedaluswallet.io] (https://daedaluswallet.io/release-notes/) và trên github [
.com/input-output-hk/daedalus/release), [Cardano SL phát hành] (https://github.com/input-output-hk/cardano-sl/releases)].
Dưới đây chúng tôi làm rõ sự tương ứng giữa các phiên bản phần mềm sản phẩm Cardano và Cardano.

At the time of writing Cardano consists of the following two software components:

Tại thời điểm viết Cardano bao gồm hai thành phần phần mềm sau:

- [Cardano settlement layer (CSL)](tmp//en/projects/cardano/) is a backend software component and its code lives in [Cardano SL repository](https://github.com/input-output-hk/cardano-sl). It is the implementation of the Cardano node with all required components such as networking and also the implementation of Cardano wallet and its API. Cardano SL is deployed on Cardano core and relay blockchain nodes, and it is also shipped as a backend software component with Daedalus frontend.

-[Lớp giải quyết Cardano (CSL)] (TMP // EN/Project/Cardano/) là thành phần phần mềm phụ trợ và mã của nó sống trong kho lưu trữ [Cardano SL] (https://github.com/input-output-hk/
cardano-sl).
Đó là việc triển khai nút Cardano với tất cả các thành phần cần thiết như kết nối mạng và cả việc triển khai ví Cardano và API của nó.
Cardano SL được triển khai trên Cardano Core và Relay Blockchain, và nó cũng được vận chuyển như một thành phần phần mềm phụ trợ với Frontend Daedalus.

- [Daedalus](tmp//en/projects/daedalus/) software component (D) is a desktop application for personal computers running Windows, Mac and Linux and its code lives in [Daedalus repository](https://github.com/input-output-hk/daedalus). It is a frontend for Cardano end users, and it ships with CLS component as its backend.

- [Daedalus] (TMP // EN/Project/Daedalus/) Thành phần phần mềm (D) là ứng dụng máy tính để bàn cho máy tính cá nhân chạy Windows, Mac và Linux và mã của nó sống trong [Kho lưu trữ Daedalus] (https://github.com
/đầu vào-đầu ra-hk/daedalus).
Nó là một frontend cho người dùng cuối Cardano và nó được vận chuyển với thành phần CLS làm phụ trợ của nó.

These software components are versioned according to the [semantic versioning](https://semver.org/) scheme most software follows, which consists of the three numbers **major.minor.patch** where:

Các thành phần phần mềm này được phiên bản theo chương trình [Phiên bản ngữ nghĩa] (https://semver.org/) Hầu hết các phần mềm theo sau, bao gồm ba số ** Major.minor.patch ** Trong đó:

- **major** is incremented when code changes are backwards incompatible

- ** chính ** được tăng lên khi thay đổi mã không tương thích

- **minor** is incremented when added functionality is backwards compatible 

- ** Minor ** được tăng lên khi chức năng thêm vào tương thích ngược

- **patch** is incremented when only bugs are fixed in a backwards compatible manner

- ** Bản vá ** được tăng lên khi chỉ có lỗi được sửa theo cách tương thích ngược

The Cardano 1.3.0 main release consisted of Cardano SL 1.3.0 and Daedalus 0.11.0, or symbolically can be written as:

Bản phát hành chính của Cardano 1.3.0 bao gồm Cardano SL 1.3.0 và Daedalus 0.11.0, hoặc có thể viết một cách tượng trưng như:

C\_1.3.0 = CSL\_1.3.0 + D\_0.11.0

C \ _1.3.0 = CSL \ _1.3.0 + D \ _0.11.0

The Cardano 1.3.2 refinement release bundles Cardano SL 1.3.2 and Daedalus 0.11.2:

Bản phát hành tinh chỉnh Cardano 1.3.2 Các gói Cardano SL 1.3.2 và Daedalus 0.11.2:

C\_1.3.2 = CSL\_1.3.2 + D\_0.11.2

C \ _1.3.2 = CSL \ _1.3.2 + D \ _0.11.2

Cardano SL and Daedalus software releases are tagged with their version tags in the [IOHK GitHub repository](https://github.com/input-output-hk/) (see [Cardano SL tags](https://github.com/input-output-hk/cardano-sl/tags) and [Daedalus tags](https://github.com/input-output-hk/daedalus/tags)).

Các bản phát hành phần mềm Cardano SL và Daedalus được gắn thẻ các thẻ phiên bản của họ trong kho lưu trữ [iohk GitHub] (https://github.com/input-out-hk/) (xem [thẻ Cardano SL] (https://github.com
/input-output-hk/cardano-sl/tags) và [thẻ daedalus] (https://github.com/input-output-hk/daedalus/tags)).

Cardano SL and Daedalus software release versions are also currently reflected in the Daedalus installer file name and in the download link on the <https://daedaluswallet.io/download> page, for example, the Cardano 1.3.2 Windows installer has the name

Các phiên bản phát hành phần mềm Cardano SL và Daedalus hiện cũng được phản ánh trong tên tệp trình cài đặt Daedalus và trong liên kết tải xuống trên trang <https://daedaluswallet.io/doad>, ví dụ: Trình cài đặt Windows Cardano 1.3.2 có tên

**daedalus-0.11.2-cardano-sl-1.3.2-mainnet-windows-10311.exe**

** Daedalus-0.11.2-Cardano-SL-1.3.2-MainNet-Windows-10311.exe **

which includes Daedalus version, Cardano SL version, network, OS, and the build number.

bao gồm phiên bản Daedalus, phiên bản Cardano SL, mạng, HĐH và số bản dựng.

While so far the Cardano product version and Cardano SL version have coincided, this is not the case for the Cardano 1.4 release due to [backwards incompatible changes in the Cardano wallet API](tmp//en/blog/backwards-incompatible-changes-in-cardano-1-4-wallet-api/). The wallet API is part of Cardano SL, and therefore due to these incompatible changes the *major* number of Cardano SL version has been incremented, and this resulted in [Cardano SL 2.0.0](https://github.com/input-output-hk/cardano-sl/blob/release/2.0.0/CHANGELOG.md). So, Cardano 1.4 consists of Cardano SL 2.0.0 and Daedalus 0.12.0:

Mặc dù cho đến nay, phiên bản sản phẩm Cardano và phiên bản Cardano SL đã trùng khớp, nhưng đây không phải là trường hợp phát hành Cardano 1.4 do [những thay đổi không tương thích ngược trong API ví Cardano] (TMP // EN/Blog/Backwards không tương thích-
In-Cardano-1-4 tường-API/).
API ví là một phần của Cardano SL, và do đó do những thay đổi không tương thích này, số lượng * chính * của phiên bản cardano sl đã được tăng lên và điều này dẫn đến [Cardano SL 2.0.0] (https://github.com/input
-Output-hk/cardano-sl/blob/release/2.0.0/changelog.md).
Vì vậy, Cardano 1.4 bao gồm Cardano SL 2.0.0 và Daedalus 0.12.0:

**C\_1.4.0 = CSL\_2.0.0 + D\_0.12.0**

** C \ _1.4.0 = CSL \ _2.0.0 + D \ _0.12.0 **

### **Conclusion**

### **Sự kết luận**

There is a distinction between the Cardano product version and versions of the Cardano software components. While this has always been the case, Cardano 1.4 is the first release where the distinction is evident, so we wanted to explain exactly how the versioning works.

Có một sự khác biệt giữa phiên bản sản phẩm Cardano và phiên bản của các thành phần phần mềm Cardano.
Mặc dù điều này luôn luôn như vậy, Cardano 1.4 là bản phát hành đầu tiên trong đó sự khác biệt là rõ ràng, vì vậy chúng tôi muốn giải thích chính xác cách thức hoạt động của phiên bản.

Cardano 1.4 release is the fifth main release of the Byron phase and consists of the two software components Cardano SL 2.0.0 and Daedalus 0.12.0 versioned according to the [semantic versioning](https://semver.org/). In the future, Cardano will include more components that will follow their own versioning schemes. For example, Cardano wallet is being rewritten as a standalone software component. The following phase in Cardano development Shelley will be versioned as Cardano 2.N.

Phát hành Cardano 1.4 là bản phát hành chính thứ năm của giai đoạn Byron và bao gồm hai thành phần phần mềm Cardano SL 2.0.0 và Daedalus 0.12.0 được phiên bản theo phiên bản [phiên bản ngữ nghĩa] (https://semver.org/).
Trong tương lai, Cardano sẽ bao gồm nhiều thành phần sẽ tuân theo các chương trình phiên bản của riêng họ.
Ví dụ, ví Cardano đang được viết lại như một thành phần phần mềm độc lập.
Giai đoạn sau trong phát triển Cardano Shelley sẽ được phiên bản là Cardano 2.n.

Artwork, 

Tác phẩm nghệ thuật,

[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

[] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons"))

![Creative Commons](img/2018-12-18-how-cardano-releases-are-versioned.010.png)

[](http://www.beeple-crap.com)

[] (http://www.beeple-crap.com)

Mike Beeple

Mike Beeple

## **Attachments**

## ** tệp đính kèm **

![](img/2018-12-18-how-cardano-releases-are-versioned.004.png)[ Simplicity and Michelson - Input Output](https://ucarecdn.com/cb0054f1-4e81-4617-82c2-6a6a363270c7/-/inline/yes/ "Simplicity and Michelson - Input Output")

