# Marlowe: financial contracts on blockchain
![](img/2018-12-11-marlowe-financial-contracts-on-blockchain.002.png) 11 December 2018![](img/2018-12-11-marlowe-financial-contracts-on-blockchain.002.png)[ Prof Simon Thompson](tmp//en/blog/authors/simon-thompson/page-1/)![](img/2018-12-11-marlowe-financial-contracts-on-blockchain.003.png) 4 mins read

![Prof Simon Thompson](img/2018-12-11-marlowe-financial-contracts-on-blockchain.004.png)[](tmp//en/blog/authors/simon-thompson/page-1/)
### [**Prof Simon Thompson**](tmp//en/blog/authors/simon-thompson/page-1/)
Technical Project Director

Research

- ![](img/2018-12-11-marlowe-financial-contracts-on-blockchain.005.png)[](mailto:simon.thompson@iohk.io "Email")
- ![](img/2018-12-11-marlowe-financial-contracts-on-blockchain.006.png)[](https://github.com/simonjohnthompson "GitHub")

![Marlowe: financial contracts on blockchain](img/2018-12-11-marlowe-financial-contracts-on-blockchain.007.jpeg)

The first computers were programmed in â€œmachine codeâ€. Each kind of system had a different code, and these codes were low-level and inexpressive: programs were long sequences of very simple instructions, incompressible to anyone who had not written them. Nowadays we are able to use higher-level languages like C, Java and Haskell to program systems. The same languages can be used on widely different machines, and the programsâ€™ structures reflects what they do; on blockchain, their equivalents are languages like Solidity and Simplicity. These modern higher-level languages are general purpose â€“ they can be used to solve all sorts of different problems â€“ but the solutions they express are still programs, and they still require programming skills to use them effectively. In contrast, Marlowe is a domain-specific language (DSL) which is designed to be usable by someone who is expert in a particular field: in the case of [Marlowe](https://github.com/input-output-hk/marlowe "Marlowe, github.com"), financial contracts, rather than requiring programming skills to use it.

Các máy tính đầu tiên đã được lập trình trong "Mã tháng. Mỗi loại hệ thống có một mã khác nhau, và các mã này là cấp thấp và không thể áp dụng: các chương trình là các chuỗi dài của các hướng dẫn rất đơn giản, không thể nén được cho bất kỳ ai chưa viết chúng. Ngày nay, chúng tôi có thể sử dụng các ngôn ngữ cấp cao hơn như C, Java và Haskell cho các hệ thống chương trình. Các ngôn ngữ tương tự có thể được sử dụng trên các máy khác nhau và các cấu trúc của các chương trình phản ánh những gì chúng làm; Trên blockchain, tương đương của chúng là các ngôn ngữ như sự vững chắc và đơn giản. Các ngôn ngữ cấp cao hiện đại này là mục đích chung-chúng có thể được sử dụng để giải quyết tất cả các loại vấn đề khác nhau-nhưng các giải pháp mà chúng thể hiện vẫn là chương trình và chúng vẫn yêu cầu kỹ năng lập trình để sử dụng chúng một cách hiệu quả. Ngược lại, Marlowe là ngôn ngữ cụ thể về miền (DSL) được thiết kế để có thể sử dụng được bởi một người chuyên gia trong một lĩnh vực cụ thể: trong trường hợp của [Marlowe] (https://github.com/input-output-hk /Marlowe "Marlowe, github.com"), hợp đồng tài chính, thay vì yêu cầu các kỹ năng lập trình để sử dụng nó.

Using a DSL has many advantages beyond its use by non-programmers:

Sử dụng DSL có nhiều lợi thế ngoài việc sử dụng bởi những người không lập trình:

- We can ensure that certain sorts of bad programs cannot even be written by designing those possibilities out of the language, and by doing this we can aim to avoid some of the unanticipated exploits which have been a problem for existing blockchains.

- Chúng tôi có thể đảm bảo rằng một số loại chương trình xấu nhất định thậm chí không thể được viết bằng cách thiết kế các khả năng đó từ ngôn ngữ và bằng cách này, chúng tôi có thể hướng đến một số khai thác không lường trước được là một vấn đề cho các blockchain hiện có.

- We can also more easily check that programs have the properties that we want: for example, in the case of a financial contract we might want to make sure that the contract can never fail to make a payment that it should.

- Chúng tôi cũng có thể dễ dàng kiểm tra xem các chương trình có các thuộc tính mà chúng tôi muốn không: ví dụ, trong trường hợp hợp đồng tài chính, chúng tôi có thể muốn đảm bảo rằng hợp đồng không bao giờ có thể không thanh toán.

- Because it is a DSL, we can build special-purpose tools to help people write programs in the language. In the case of Marlowe we can emulate how a contract will behave before it is run for real on the system; this helps us to make sure that the contract we have written is doing what it is intended to.

- Bởi vì đó là DSL, chúng tôi có thể xây dựng các công cụ có mục đích đặc biệt để giúp mọi người viết các chương trình bằng ngôn ngữ.
Trong trường hợp của Marlowe, chúng ta có thể mô phỏng cách một hợp đồng sẽ hoạt động trước khi nó được thực hiện thực sự trên hệ thống;
Điều này giúp chúng tôi đảm bảo rằng hợp đồng chúng tôi đã viết là làm những gì nó dự định.

Marlowe is modelled on financial contract DSLs popularised in the last decade or so by academics and enterprises such as LexiFi, which provides contract software in the financial sector. In developing Marlowe we have adapted these languages to work on blockchain. Marlowe is implemented on the settlement layer (SL) of the Cardano blockchain, but could equally well be implemented on Ethereum/Solidity or other blockchain platforms; in this respect it is â€œplatform agnosticâ€ just like modern programming languages like Java and C++. The Meadow online emulator tool allows you to experiment with, develop and interact with Marlowe contracts in your web browser, without having to install any software for yourself.

Marlowe được mô hình hóa trên các DSL hợp đồng tài chính được phổ biến trong thập kỷ qua bởi các học giả và doanh nghiệp như Lexifi, nơi cung cấp phần mềm hợp đồng trong lĩnh vực tài chính.
Khi phát triển Marlowe, chúng tôi đã điều chỉnh các ngôn ngữ này để hoạt động trên blockchain.
Marlowe được triển khai trên lớp giải quyết (SL) của blockchain Cardano, nhưng cũng có thể được triển khai trên Ethereum/Sollity hoặc các nền tảng blockchain khác;
Về mặt này, đó là "Platform Agnostic" giống như các ngôn ngữ lập trình hiện đại như Java và C ++.
Công cụ Trình mô phỏng trực tuyến Meadow cho phép bạn thử nghiệm, phát triển và tương tác với các hợp đồng Marlowe trong trình duyệt web của bạn mà không phải tự cài đặt bất kỳ phần mềm nào.

What does a Marlowe contract look like? It is built by combining a small number of building blocks that describe making a payment, making an observation of something in the â€œreal worldâ€, waiting until a certain condition becomes true, and so on. Where we differ from earlier approaches is in how we make sure that the contract is followed. This means not only that the instructions of the contract are not disobeyed, but also that the participants donâ€™t walk away early, leaving money locked up in the contract forever. We do this using two tools, commitments and timeouts: a commitment requires a participant to â€œput their money on the tableâ€, and through timeouts we make sure that this commitment happens in a timely manner or remedial action is taken. Putting these constructs together we are able to incentivise participants to continue with the contract once they have committed to it.

Hợp đồng Marlowe trông như thế nào?
Nó được xây dựng bằng cách kết hợp một số lượng nhỏ các khối xây dựng mô tả việc thanh toán, thực hiện một quan sát về một cái gì đó trong thế giới thực tế, chờ đợi cho đến khi một điều kiện nhất định trở thành đúng, v.v.
Trường hợp chúng tôi khác với các phương pháp trước đó là cách chúng tôi đảm bảo rằng hợp đồng được tuân thủ.
Điều này có nghĩa là không chỉ các hướng dẫn của hợp đồng không được không tuân theo, mà cả những người tham gia không bỏ đi sớm, khiến tiền bị khóa trong hợp đồng mãi mãi.
Chúng tôi thực hiện việc này bằng cách sử dụng hai công cụ, cam kết và thời gian chờ: Một cam kết đòi hỏi người tham gia phải truyền tiền của họ trên bảng, và thông qua thời gian chờ chúng tôi đảm bảo rằng cam kết này xảy ra kịp thời hoặc hành động khắc phục được thực hiện.
Đặt các cấu trúc này lại với nhau, chúng tôi có thể khuyến khích người tham gia tiếp tục với hợp đồng một khi họ đã cam kết với nó.

Weâ€™re working on a full release of Marlowe for mid-2019, when it will be available on Cardano SL. From today, you're able to explore Marlowe for yourself using [Meadow](https://input-output-hk.github.io/marlowe/ "Meadow: online emulation and visualisation of Marlowe contracts, input-output-hk.github.io"), and find out much more detail from our [online paper](tmp//en/research/papers/#2WHKDRA8 "Research paper on Marlowe: Financial contracts on blockchain, iohk.io"). In the next six months weâ€™ll be polishing the language design itself and developing a set of templates for popular financial instruments, as well as using formal logic tools to prove properties of Marlowe contracts, giving users the highest level of assurance that their contracts behave as intended.

Chúng tôi đang làm việc với việc phát hành đầy đủ Marlowe vào giữa năm 2019, khi nó sẽ có sẵn trên Cardano SL.
Từ hôm nay, bạn có thể khám phá Marlowe cho chính mình bằng cách sử dụng [Meadow] (https://input-output-hk.github.io/marlowe/ "Meadow: mô phỏng trực tuyến và trực quan hóa các hợp đồng Marlowe, đầu vào đầu ra-hk.
GitHub.io "), và tìm hiểu thêm chi tiết từ [bài báo trực tuyến] của chúng tôi (TMP // EN/Nghiên cứu/Giấy tờ/#2WHKDRA8" Tài liệu nghiên cứu về Marlowe: Hợp đồng tài chính trên blockchain, iohk.io ").
Trong sáu tháng tới, chúng tôi sẽ đánh bóng chính thiết kế ngôn ngữ và phát triển một bộ mẫu cho các công cụ tài chính phổ biến, cũng như sử dụng các công cụ logic chính thức để chứng minh các thuộc tính của hợp đồng Marlowe, cung cấp cho người dùng mức độ đảm bảo cao nhất rằng hợp đồng của họ
hành xử như dự định.

