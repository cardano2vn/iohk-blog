# Backwards-incompatible changes in Cardano 1.4 Wallet API
### **Matthias Benkort and Jacob Mitchell cover what's new**
![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.002.png) 18 December 2018![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.002.png)[ Matthias Benkort](tmp//en/blog/authors/matthias-benkort/page-1/)![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.003.png) 4 mins read

![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.004.png)[ Simplicity and Michelson - Input Output](https://ucarecdn.com/cb0054f1-4e81-4617-82c2-6a6a363270c7/-/inline/yes/ "Simplicity and Michelson - Input Output")

![Matthias Benkort](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.005.png)[](tmp//en/blog/authors/matthias-benkort/page-1/)
### [**Matthias Benkort**](tmp//en/blog/authors/matthias-benkort/page-1/)
Software Engineering Lead

Engineering

- ![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.006.png)[](https://www.linkedin.com/in/matthias-benkort-47186a57/ "LinkedIn")
- ![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.007.png)[](https://twitter.com/MBenkort "Twitter")
- ![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.008.png)[](https://github.com/KtorZ "GitHub")

![Backwards-incompatible changes in Cardano 1.4 Wallet API](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.009.jpeg)

In this blog, [wallet API lead Matthias Benkort](tmp//en/team/matthias-benkort "Matthias Benkort's profile") explains backwards-incompatible Cardano wallet API changes that are coming in Cardano 1.4, and [devOps lead Jacob Mitchell](tmp//en/team/jacob-mitchell/ "Jacob Mitchell's profile") shows how to build a Cardano client with both the old V0 wallet API and the new V1 wallet API, instead of the default option providing only the new API. This blog post is mainly intended for current users of the Cardano wallet API; in particular, those who have already integrated with the beta release of the V1 API prior to Cardano 1.4.

Trong blog này, [ví API API Matthias Benkort] (TMP // EN/Team/Matthias-Benkort "Hồ sơ của Matthias Benkort") giải thích thay đổi API ví Cardano không tương thích ngược đang đến trong Cardano 1.4 và [DevOps dẫn Jacob Mitchell]]
.
Bài đăng trên blog này chủ yếu dành cho người dùng hiện tại của API ví Cardano;
Cụ thể, những người đã tích hợp với bản phát hành Beta của API V1 trước Cardano 1.4.

The Cardano wallet API has its own versioning. As of Cardano 1.4 the previous V0 wallet API will become obsolete. All V0 API REST endpoints have been ported to [V1 API](https://cardanodocs.com/technical/wallet/api/v1/), and the wallet rewrite gave the wallet team an opportunity to correct and improve the Cardano wallet semantics. As a result, there have been four breaking changes as described below. The V1 wallet API will become the default wallet API in Cardano 1.4.

API ví Cardano có phiên bản riêng.
Kể từ Cardano 1.4, API ví V0 trước đó sẽ trở nên lỗi thời.
Tất cả các điểm cuối REST API V0 đã được chuyển đến [API V1] (https://cardanodocs.com/technical/wallet/api/v1/), và ví viết lại cho nhóm ví có cơ hội sửa chữa và cải thiện ngữ nghĩa ví Cardano
.
Kết quả là, đã có bốn thay đổi phá vỡ như được mô tả dưới đây.
API ví V1 sẽ trở thành API ví mặc định trong Cardano 1.4.

1. The diagnostic structure of the **NotEnoughMoney** error has been changed to accommodate more cases.

1. Cấu trúc chẩn đoán của lỗi ** notenoughmoney ** đã được thay đổi để phù hợp với nhiều trường hợp hơn.

1. The diagnostic structure of the **WalletAlreadyExists** error has been modified to provide the extra field **walletId** for the ID of the pre-existing wallet.

1. Cấu trúc chẩn đoán của ** WalletalReadyExists ** Lỗi đã được sửa đổi để cung cấp trường bổ sung ** WalletId ** cho ID của ví đã tồn tại trước.

1. The behavior of **/api/v1/addresses/{address}** has been adjusted to more accurately reflect the semantics of ownership regarding addresses. The previous version of this endpoint failed with an HTTP error when the given address was unknown to the wallet. This was misleading, since an address that is unknown to the wallet could still belong to it. To reflect this, the V1 endpoint no longer fails, and instead when an address is not recognised it returns a new field **isOurs**, which indicates either that the address is ours, or that it is not recognised.

1. Hành vi của **/API/V1/Địa chỉ/{Địa chỉ} ** đã được điều chỉnh để phản ánh chính xác hơn các ngữ nghĩa của quyền sở hữu liên quan đến địa chỉ.
Phiên bản trước của điểm cuối này không thành công với lỗi HTTP khi không biết địa chỉ đã cho.
Điều này là sai lệch, vì một địa chỉ không được biết đến ví vẫn có thể thuộc về nó.
Để phản ánh điều này, điểm cuối V1 không còn thất bại nữa, và thay vào đó khi một địa chỉ không được công nhận, nó sẽ trả về một trường mới ** isours **, cho thấy địa chỉ đó là của chúng tôi hoặc nó không được công nhận.

1. A DELETE request to **/api/v1/wallets/{wallet}** now correctly fails with a 404 HTTP response code if the wallet doesn't exist. Previously, it incorrectly responded with 204.

1
Trước đây, nó đã trả lời không chính xác với 204.

Regardless of whether the old or new data layer runs, the V1 API will have the changes described above. The first two changes are mostly intended so that developers can understand what's going on. If exchanges or other parties were using it to build a specific error message for their API or front end, then it may break.

Bất kể lớp dữ liệu cũ hay mới chạy, API V1 sẽ có những thay đổi được mô tả ở trên.
Hai thay đổi đầu tiên chủ yếu nhằm mục đích để các nhà phát triển có thể hiểu những gì đang diễn ra.
Nếu trao đổi hoặc các bên khác đang sử dụng nó để xây dựng một thông báo lỗi cụ thể cho API hoặc mặt trước của họ, thì nó có thể bị hỏng.

The third change is more subtle and is actually a bug fix. The old behavior of the GET address endpoint was sending wrong information to nodes, so we have fixed it to improve its accuracy. In doing so, we had to introduce a new **isOurs** field and review what HTTP statuses were being sent - should exchanges have been relying on this for any business logic, they will need to update it.

Thay đổi thứ ba là tinh tế hơn và thực sự là một sửa lỗi.
Hành vi cũ của điểm cuối địa chỉ đã gửi thông tin sai đến các nút, vì vậy chúng tôi đã sửa nó để cải thiện độ chính xác của nó.
Khi làm như vậy, chúng tôi đã phải giới thiệu một trường ** isours ** mới và xem xét những trạng thái HTTP nào được gửi - nên trao đổi đã dựa vào điều này cho bất kỳ logic kinh doanh nào, họ sẽ cần cập nhật nó.

The default installation of Cardano 1.4 will come with the V1 wallet API only. 

Việc cài đặt mặc định của Cardano 1.4 sẽ chỉ đi kèm với API ví V1.

Generally, exchanges and other integrators use stable releases to build a Cardano client using a shell script that launches a Cardano wallet against mainnet:

Nói chung, các trao đổi và các nhà tích hợp khác sử dụng các bản phát hành ổn định để xây dựng ứng dụng khách Cardano bằng cách sử dụng tập lệnh shell khởi chạy ví Cardano chống lại Mainnet:

**nix-build -A connectScripts.mainnet.wallet**

** Nix -Build -a Connectscripts.mainnet.wallet **

In this case there is no roll back - Cardano wallet is upgraded to V1.

Trong trường hợp này không có cuộn trở lại - ví Cardano được nâng cấp lên V1.

In order to have both V0 and V1 functionality developers should use **useLegacyDataLayer** in the **custom-wallet-config.nix** file as described in our [documentation for exchanges](https://github.com/input-output-hk/cardano-sl/blob/master/docs/exchange-onboarding.md#generate-custom-configuration). **Caution!** In this mode, despite making V1 endpoints available, the API won't utilize the newly developed data layer. As a consequence, developers may experience limitations known of the legacy data layer. This mode is therefore deprecated and we strongly recommend users to run nodes without it.

Để có cả hai nhà phát triển chức năng V0 và V1 nên sử dụng ** UselegacyDatalayer ** trong tệp **-Wallet-config.nix ** như được mô tả trong [Tài liệu cho trao đổi] (https://github.com/input
-Output-hk/cardano-sl/blob/master/docs/exchange-onboarding.md#tạo cấu hình-custom-configuration).
** THẬN TRỌNG! ** Trong chế độ này, mặc dù có sẵn các điểm cuối V1, API sẽ không sử dụng lớp dữ liệu mới được phát triển.
Do đó, các nhà phát triển có thể trải nghiệm những hạn chế được biết đến của lớp dữ liệu kế thừa.
Do đó, chế độ này không được chấp nhận và chúng tôi khuyên người dùng nên chạy các nút mà không có nó.

We have described backwards-incompatible changes coming with the wallet API in Cardano 1.4. Should anyone have trouble upgrading to 1.4, seek help through either an already established communication channel, or our [support portal](https://iohk.zendesk.com).

Chúng tôi đã mô tả những thay đổi không tương thích ngược đi kèm với API ví trong Cardano 1.4.
Nếu bất cứ ai gặp khó khăn khi nâng cấp lên 1.4, hãy tìm kiếm sự giúp đỡ thông qua kênh truyền thông đã được thiết lập hoặc [Cổng hỗ trợ] của chúng tôi (https://iohk.zendesk.com).

Artwork, 

Tác phẩm nghệ thuật,

[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

[] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons"))

![Creative Commons](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.010.png)

[](http://www.beeple-crap.com)

[] (http://www.beeple-crap.com)

Mike Beeple

Mike Beeple

## **Attachments**

## ** tệp đính kèm **

![](img/2018-12-18-backwards-incompatible-changes-in-cardano-1-4-wallet-api.004.png)[ Simplicity and Michelson - Input Output](https://ucarecdn.com/cb0054f1-4e81-4617-82c2-6a6a363270c7/-/inline/yes/ "Simplicity and Michelson - Input Output")

