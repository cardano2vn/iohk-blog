# IOHK releases Icarus to the Cardano community
### **Developers can now build their own light wallets**
![](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.002.png) 15 August 2018![](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.002.png)[ Brian McKenna](tmp//en/blog/authors/brian-mckenna/page-1/)![](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.003.png) 7 mins read

![Brian McKenna](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.004.png)[](tmp//en/blog/authors/brian-mckenna/page-1/)
### [**Brian McKenna**](tmp//en/blog/authors/brian-mckenna/page-1/)
Product Manager

Operations

- ![](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.005.png)[](https://www.linkedin.com/in/brian-mckenna-a284341a/ "LinkedIn")
- ![](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.006.png)[](https://twitter.com/BrianMc36431138 "Twitter")
- ![](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.007.png)[](https://github.com/brian-mckenna "GitHub")

![IOHK releases Icarus to the Cardano community](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.008.jpeg)

Today IOHK releases Icarus, a reference implementation for a lightweight wallet developed by the IOHK engineering team. We hope that this code base will be used as a point of reference to enable developers to create their own secure light and mobile wallets for Cardano. [Icarus](https://github.com/input-output-hk/project-icarus "Project Icarus, github.com") is a fully open source code base that will be the first step in a range of open source initiatives to provide developers with a suite of tools for Cardano.

Hôm nay IOHK phát hành ICARUS, một triển khai tham khảo cho một ví nhẹ được phát triển bởi nhóm Kỹ thuật IOHK.
Chúng tôi hy vọng rằng cơ sở mã này sẽ được sử dụng làm điểm tham chiếu để cho phép các nhà phát triển tạo ví nhẹ và di động của riêng họ cho Cardano.
[ICARUS] (https://github.com/input-output
Để cung cấp cho các nhà phát triển một bộ công cụ cho Cardano.

Icarus was born out of a series of proof of concepts which began back in March of this year. A small section of the IOHK engineering team were interested to find out if they could demonstrate that it would be possible to create a lightweight Cardano wallet with all the features of [Daedalus](https://daedaluswallet.io/ "Daedalus Wallet, daedaluswallet.io") but that was easy to use and fast to set up. Whilst we are improving Daedalus synchronization speeds all the time, notably in the recent 1.3 release, we wanted to see if we could build something fast for Ada users who might not require the full features of Daedalus, or might not have the bandwidth or machine requirements to easily run Daedalus. 

Icarus được sinh ra từ một loạt các bằng chứng về các khái niệm bắt đầu vào tháng 3 năm nay.
Một phần nhỏ của nhóm Kỹ thuật IOHK đã quan tâm để tìm hiểu xem họ có thể chứng minh rằng có thể tạo một ví Cardano nhẹ với tất cả các tính năng của [Daedalus] (https://daedaluswallet.io/ "Ví Daedalus, Daedaluswallet
.io ") nhưng điều đó rất dễ sử dụng và nhanh chóng để thiết lập.
Trong khi chúng tôi đang cải thiện tốc độ đồng bộ hóa Daedalus mọi lúc, đáng chú ý là trong bản phát hành 1.3 gần đây, chúng tôi muốn xem liệu chúng tôi có thể xây dựng một cái gì đó nhanh chóng cho người dùng ADA không yêu cầu các tính năng đầy đủ của Daedalus hay không có băng thông hoặc yêu cầu máy
để dễ dàng chạy Daedalus.

Therefore, investigating whether it would be possible to build a wallet where the user did not have to download the whole blockchain â€“ and could run in a browser or on a mobile device â€“ was worth the effort of a small dedicated team. 

Do đó, việc điều tra xem liệu có thể xây dựng ví mà người dùng không phải tải xuống toàn bộ blockchain hay không và có thể chạy trong trình duyệt hoặc trên thiết bị di động - đáng để nỗ lực của một nhóm chuyên dụng nhỏ.

To build a wallet like this, we would need to prove that we could safely and securely store private keys and execute client-side cryptographic operations in the browser. In tandem, we would need to communicate with the Cardano nodes to provide users with their current UTxO state. If this could be accomplished, it would be no mean feat, hence the name Icarus â€“ from the beginning we knew we would be flying close to the sun.

Để xây dựng một ví như thế này, chúng tôi sẽ cần chứng minh rằng chúng tôi có thể lưu trữ các khóa riêng một cách an toàn và an toàn và thực hiện các hoạt động mật mã phía máy khách trong trình duyệt.
Tandem, chúng tôi sẽ cần liên lạc với các nút Cardano để cung cấp cho người dùng trạng thái UTXO hiện tại của họ.
Nếu điều này có thể được thực hiện, nó sẽ không có nghĩa là kỳ công, do đó cái tên Icarus - ngay từ đầu, chúng tôi biết rằng chúng tôi sẽ bay gần mặt trời.

The team set out in at the beginning of March with ambitious goals to see if, within a month, we could build a skeleton Chrome extension application and verify that Cardano cryptography could be run in the browser using WebAssembly compiled from Rust. The Rust library of Cardano primitives has been developed by Vincent Hanquez and Nicolas Di Prima, IOHK Specialised Cryptographic Engineers, and has already been used for the paper wallet certificate feature in Daedalus. 

Nhóm nghiên cứu đã đặt ra vào đầu tháng 3 với các mục tiêu đầy tham vọng để xem, trong vòng một tháng, chúng tôi có thể xây dựng một ứng dụng mở rộng bộ xương Chrome và xác minh rằng mật mã Cardano có thể được chạy trong trình duyệt bằng cách sử dụng WebAssugging được biên dịch từ Rust.
Thư viện Rust của Cardano Primitives đã được phát triển bởi Vincent Hanquez và Nicolas di Prima, các kỹ sư mật mã chuyên dụng của IOHK, và đã được sử dụng cho tính năng chứng chỉ ví giấy ở Daedalus.

To build this Chrome extension, we would need to successfully demonstrate we could import and track a wallet balance. Of course, we would have to do all this without sacrificing the IOHK engineering principles of quality and security. 

Để xây dựng tiện ích mở rộng Chrome này, chúng tôi sẽ cần chứng minh thành công chúng tôi có thể nhập và theo dõi cân bằng ví.
Tất nhiên, chúng tôi sẽ phải làm tất cả những điều này mà không phải hy sinh các nguyên tắc kỹ thuật IOHK về chất lượng và bảo mật.

The demo at the end of March went well and produced a functional prototype that we could develop. Once each demo had been given, the wider IOHK engineering team had a chance to review, critique and provide feedback about the design decisions the Icarus project team was taking, which proved invaluable to the process. After proof of concept 1, it was felt that good progress was being made and another monthâ€™s effort from the team would be worthwhile.

Bản demo vào cuối tháng 3 đã diễn ra tốt đẹp và tạo ra một nguyên mẫu chức năng mà chúng ta có thể phát triển.
Khi mỗi bản demo được đưa ra, nhóm Kỹ thuật IOHK rộng hơn đã có cơ hội xem xét, phê bình và cung cấp phản hồi về các quyết định thiết kế mà nhóm dự án ICARUS đang thực hiện, điều này đã chứng minh vô giá cho quá trình này.
Sau khi chứng minh khái niệm 1, người ta cảm thấy rằng tiến bộ tốt đã được thực hiện và nỗ lực của một tháng nữa từ nhóm sẽ rất đáng giá.

Proof of concept 2 was delivered in mid-April. The Rust engineers had spent the intervening time extending the Rust library to support the Cardano primitives for the creation, signing, and broadcast of transactions, and providing an API so that these could be run in the browser. On the application side, we wanted to see if we could reuse the UX/UI components of Daedalus to provide a smooth user experience. Luckily, the IOHK Daedalus development team has maintained a high-quality, portable UI framework for React, called React-Polymorph, which we found to be easily portable to the Chrome extension.

Bằng chứng về khái niệm 2 đã được đưa ra vào giữa tháng Tư.
Các kỹ sư rỉ sét đã dành thời gian can thiệp để mở rộng thư viện rỉ sét để hỗ trợ các nguyên thủy Cardano để tạo, ký và phát các giao dịch và cung cấp API để có thể chạy trong trình duyệt.
Về phía ứng dụng, chúng tôi muốn xem liệu chúng tôi có thể sử dụng lại các thành phần UX/UI của Daedalus để cung cấp trải nghiệm người dùng suôn sẻ hay không.
May mắn thay, nhóm phát triển IOHK Daedalus đã duy trì khung giao diện người dùng di động chất lượng cao cho React, được gọi là React-Polymorph, mà chúng tôi thấy dễ dàng di động cho phần mở rộng Chrome.

Proof of concept 3 in late May involved making Icarus fully interoperable with the Daedalus wallet. The team worked to develop a new Hierarchical Deterministic (HD) address scheme that Daedalus will use in future and will ensure ongoing compatibility. One important feature we built at this point was to allow the user to enter their Daedalus wallet recovery phrase in Icarus, and for their Ada in Daedalus to be transferred to the Icarus wallet. In effect, this allows users to retrieve their Ada without using the Daedalus wallet. We also optimised wallet restoration times. Finally, after only three months and three demoâ€™s we had a fully functional prototype lightweight Cardano wallet!

Bằng chứng về khái niệm 3 vào cuối tháng 5 liên quan đến việc làm cho Icarus hoàn toàn có thể tương tác với ví Daedalus.
Nhóm nghiên cứu đã làm việc để phát triển chương trình địa chỉ xác định phân cấp mới (HD) mà Daedalus sẽ sử dụng trong tương lai và sẽ đảm bảo khả năng tương thích liên tục.
Một tính năng quan trọng mà chúng tôi đã xây dựng tại thời điểm này là cho phép người dùng nhập cụm từ phục hồi ví Daedalus của họ ở Icarus và để ADA của họ ở Daedalus được chuyển sang ví Icarus.
Trên thực tế, điều này cho phép người dùng lấy lại ADA của họ mà không cần sử dụng ví Daedalus.
Chúng tôi cũng tối ưu hóa thời gian phục hồi ví.
Cuối cùng, chỉ sau ba tháng và ba bản demo, chúng tôi đã có một chiếc ví Cardano hạng nhẹ đầy đủ chức năng!

Before we could ensure this was a reference implementation we could release to the community, we wanted to ensure that it performed at scale. This, along with some code clean-up, was the main task of the final proof of concept 4 in early June. We called upon the experience of Philipp Kant, in IOHK benchmarking, and Neil Davies, leading networking, and successfully conducted a series of rigorous stress and failover tests on the architecture. 

Trước khi chúng tôi có thể đảm bảo đây là một triển khai tham chiếu mà chúng tôi có thể phát hành cho cộng đồng, chúng tôi muốn đảm bảo rằng nó được thực hiện ở quy mô.
Điều này, cùng với một số việc làm sạch mã, là nhiệm vụ chính của bằng chứng cuối cùng của khái niệm 4 vào đầu tháng 6.
Chúng tôi kêu gọi kinh nghiệm của Philipp Kant, trong điểm chuẩn của IOHK và Neil Davies, kết nối mạng, và đã thực hiện thành công một loạt các bài kiểm tra căng thẳng và chuyển đổi nghiêm ngặt về kiến trúc.

The code base has been quality assured by Allied Testing, a leading quality assurance and testing company. We also engaged Kudelski Security, a cybersecurity consultancy, to perform a full security audit of the code â€“ their report will be published soon.

Cơ sở mã đã được đảm bảo chất lượng bằng cách kiểm tra đồng minh, một công ty thử nghiệm và đảm bảo chất lượng hàng đầu.
Chúng tôi cũng tham gia Kudelski Security, một công ty tư vấn an ninh mạng, để thực hiện kiểm toán bảo mật đầy đủ của Bộ luật - Báo cáo của họ sẽ sớm được công bố.

![emurgo trip](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.009.jpeg) 

L-R: NicolÃ¡s Arqueros, Alan Verbner, Brian McKenna, Sebastien Guillemot

L-R: NicolÃ¡s Arqueros, Alan Verbner, Brian McKenna, Sebastien Guillemot

We knew that Emurgo, the organisation that supports new Cardano ventures, was interested in releasing the first implementation of Icarus to the community. To that end, we invited two Emurgo staff â€“ NicolÃ¡s Arqueros, chief technology officer, and Sebastien Guillemot, technical manager â€“ to Buenos Aires to meet lead Icarus developer Alan Verbner and his team in July. The goal of this trip was to see if the code could be understood and deployed by open source community members. Emurgo provided feedback on how we could make the reference implementation ready to release as a product and they wrote a technical specification for the code base. We are excited that 

Chúng tôi biết rằng Emurgo, tổ chức hỗ trợ New Cardano Ventures, đã quan tâm đến việc phát hành triển khai đầu tiên của Icarus cho cộng đồng.
Cuối cùng, chúng tôi đã mời hai nhân viên của Emurgo - Nicolã arqueros, giám đốc công nghệ và Sebastien Guillemot, giám đốc kỹ thuật - đến Buenos Aires để gặp nhà phát triển chính của Icarus Alan Verbner và nhóm của anh ấy vào tháng 7.
Mục tiêu của chuyến đi này là xem liệu mã có thể được hiểu và triển khai bởi các thành viên cộng đồng nguồn mở hay không.
Emurgo cung cấp phản hồi về cách chúng tôi có thể thực hiện triển khai tham chiếu sẵn sàng phát hành dưới dạng sản phẩm và họ đã viết một đặc điểm kỹ thuật cho cơ sở mã.
Chúng tôi rất vui mừng rằng

[](https://www.youtube.com/watch?time_continue=9&=&v=GLNgpr-3t2E)

[] (https://www.youtube.com/watch?time_continue=9&=&v=gngPR

Emurgo

Emurgo

will soon be launching their implementation of Icarus, the Yoroi wallet, and look forward to seeing how they carry through their vision for the product.

Sẽ sớm ra mắt triển khai Icarus, ví Yoroi và mong muốn được xem cách họ mang theo tầm nhìn của họ cho sản phẩm.

In mid-July, Hayley McCool Smith, IOHK Product Marketing Manager, visited Emurgo at their offices in Tokyo. One of the purposes of the trip was to take part in a naming workshop which would help Emurgo bring their product to life. After spending a day working through a plethora of contenders that Emurgo had shortlisted, it was decided that â€œYoroiâ€ was the perfect fit. In Japanese, Yoroi means â€œgreat armourâ€ and is a prominent example of the type of secure armament that Samurais would wear to protect themselves. With the name decided, it was up to the team to create a logo that would reflect a new lightweight wallet, while also incorporating the traditional Samurai meaning of the word.

Vào giữa tháng 7, Hayley McCool Smith, giám đốc tiếp thị sản phẩm của IOHK, đã đến thăm Emurgo tại các văn phòng của họ ở Tokyo.
Một trong những mục đích của chuyến đi là tham gia một hội thảo đặt tên sẽ giúp Emurgo đưa sản phẩm của họ vào cuộc sống.
Sau khi dành một ngày làm việc thông qua rất nhiều ứng cử viên mà Emurgo lọt vào danh sách, người ta đã quyết định rằng "Yoroi" là sự phù hợp hoàn hảo.
Trong tiếng Nhật, Yoroi có nghĩa là "Armour" và là một ví dụ nổi bật về loại vũ khí an toàn mà Samurais sẽ mặc để tự bảo vệ mình.
Với cái tên được quyết định, tùy thuộc vào nhóm để tạo ra một logo sẽ phản ánh một ví nhẹ mới, đồng thời kết hợp ý nghĩa samurai truyền thống của từ này.

![emurgo tokyo](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.010.jpeg) 

Emurgo team in Tokyo

Đội Emurgo ở Tokyo

The Rust library that was used to bring the Cardano cryptography into the browser has spawned another IOHK project, the Cardano Rust project. (This has been known as Project Prometheus internally.) IOHK will be releasing more information on this in due course. The Cardano Rust project will maintain the open source spirit of Icarus and further extend the toolbox of Rust modules. The project will be made available to the open source community to easily build high-quality applications using Cardano. The first product of the project will be a full command line interface wallet, which you can expect to see in September.

Thư viện rỉ sét được sử dụng để đưa mật mã Cardano vào trình duyệt đã sinh ra một dự án IOHK khác, Dự án Cardano Rust.
(Điều này đã được gọi là Project Prometheus trong nội bộ.) IOHK sẽ phát hành thêm thông tin về điều này trong khóa học do.
Dự án Rust Cardano sẽ duy trì tinh thần nguồn mở của Icarus và tiếp tục mở rộng hộp công cụ của các mô -đun Rust.
Dự án sẽ được cung cấp cho cộng đồng nguồn mở để dễ dàng xây dựng các ứng dụng chất lượng cao bằng Cardano.
Sản phẩm đầu tiên của dự án sẽ là ví giao diện dòng lệnh đầy đủ mà bạn có thể mong đợi sẽ thấy vào tháng Chín.

The segmented development team and rapid iteration approach to software development has worked well on Project Icarus and we will be employing this strategy again. We are happy that Ada holders will have the ability to store their Ada in the really cool Yoroi wallet and that developers have a high-quality reference implementation on which to base their own new light and mobile wallets for Cardano. The project has also given rise to Project Prometheus which is the natural evolution of the spirit of Icarus.

Nhóm phát triển được phân đoạn và cách tiếp cận lặp lại nhanh chóng để phát triển phần mềm đã hoạt động tốt trên Project Icarus và chúng tôi sẽ sử dụng chiến lược này một lần nữa.
Chúng tôi rất vui vì những người nắm giữ ADA sẽ có khả năng lưu trữ ADA của họ trong ví Yoroi thực sự tuyệt vời và các nhà phát triển có triển khai tham chiếu chất lượng cao để dựa trên các ví ánh sáng và di động mới của riêng họ cho Cardano.
Dự án cũng đã dẫn đến dự án Prometheus, sự phát triển tự nhiên của tinh thần Icarus.

We feel that we have developed, in quite a short time, a very useful quality assured and security audited reference implementation for a lightweight Cardano wallet. We encourage the open source community to fork the Icarus code base, compile it, and maybe even build your own wallet for Cardano. We welcome contributions and hope that this effort will benefit the entire community.

Chúng tôi cảm thấy rằng chúng tôi đã phát triển, trong một thời gian khá ngắn, một triển khai tham chiếu kiểm toán bảo mật và chất lượng rất hữu ích cho một ví Cardano nhẹ.
Chúng tôi khuyến khích cộng đồng nguồn mở để đưa cơ sở mã Icarus, biên dịch nó và thậm chí có thể xây dựng ví của riêng bạn cho Cardano.
Chúng tôi hoan nghênh những đóng góp và hy vọng rằng nỗ lực này sẽ có lợi cho toàn bộ cộng đồng.

*This blog has been amended to update the name of the Cardano Rust project from Project Prometheus.*

*Blog này đã được sửa đổi để cập nhật tên của Dự án Rust Cardano từ Project Prometheus.*

Artwork, 

Tác phẩm nghệ thuật,

[](https://creativecommons.org/licenses/by/4.0/)

[] (https://creativecommons.org/licenses/by/4.0/)

![Creative Commons](img/2018-08-15-iohk-release-icarus-to-the-cardano-community.011.png)

[](http://www.beeple-crap.com)

[] (http://www.beeple-crap.com)

Mike Beeple

Mike Beeple

