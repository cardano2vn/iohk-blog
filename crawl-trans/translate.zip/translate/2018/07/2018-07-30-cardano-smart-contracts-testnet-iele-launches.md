# Cardano smart contracts testnet IELE launches
### **Developers can run programs with increased confidence**
![](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.002.png) 30 July 2018![](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.002.png)[ Gerard Moroney](tmp//en/blog/authors/gerard-moroney/page-1/)![](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.003.png) 4 mins read

![Gerard Moroney](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.004.png)[](tmp//en/blog/authors/gerard-moroney/page-1/)
### [**Gerard Moroney**](tmp//en/blog/authors/gerard-moroney/page-1/)
Chief Operating Officer

Operations

- ![](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.005.png)[](mailto:gerard.moroney@iohk.io "Email")
- ![](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.006.png)[](https://ie.linkedin.com/in/gmoroney "LinkedIn")
- ![](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.007.png)[](https://twitter.com/gmanroney "Twitter")
- ![](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.008.png)[](https://github.com/gmanroney "GitHub")

![Cardano smart contracts testnet IELE launches](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.009.jpeg)

Today we launch the second Cardano testnet, which is for the IELE virtual machine (VM) and follows our recent launch of the KEVM testnet. The technology is not only an important step on the Cardano roadmap, but also for the industry â€“ in offering robust and reliable financial infrastructure. Developers now have the opportunity to explore the smart contracts technology that will be offered as part of Cardano, and to give us their feedback, which we look forward to receiving over the coming months.

Hôm nay chúng tôi ra mắt Cardano Testnet thứ hai, dành cho máy ảo IELE (VM) và theo dõi sự ra mắt gần đây của chúng tôi về Kevm Testnet.
Công nghệ này không chỉ là một bước quan trọng trên lộ trình Cardano, mà còn cho ngành công nghiệp - trong việc cung cấp cơ sở hạ tầng tài chính mạnh mẽ và đáng tin cậy.
Các nhà phát triển hiện có cơ hội khám phá công nghệ hợp đồng thông minh sẽ được cung cấp như một phần của Cardano và để cung cấp cho chúng tôi phản hồi của họ, mà chúng tôi mong muốn nhận được trong những tháng tới.

### **Why smart contracts?**

### ** Tại sao hợp đồng thông minh? **

In many business processes that involve the exchange of value (including money, property or shares) intermediaries are involved in checking that the terms of the agreements are complete and unambiguous as well as satisfied before the exchange can take place. These intermediaries add to the cost of a transaction. The technology of smart contracts (also known as self-executing contracts or blockchain contracts) has emerged as a way of addressing the need for this verification by reducing the time, third-party involvement, and cost of reliably executing an agreement.

Trong nhiều quy trình kinh doanh liên quan đến việc trao đổi giá trị (bao gồm tiền, tài sản hoặc cổ phiếu) trung gian có liên quan đến việc kiểm tra xem các điều khoản của các thỏa thuận có hoàn chỉnh và không rõ ràng cũng như hài lòng trước khi trao đổi có thể diễn ra.
Những trung gian này thêm vào chi phí của một giao dịch.
Công nghệ của các hợp đồng thông minh (còn được gọi là hợp đồng tự thực hiện hoặc hợp đồng blockchain) đã xuất hiện như một cách giải quyết nhu cầu xác minh này bằng cách giảm thời gian, sự tham gia của bên thứ ba và chi phí thực hiện đáng tin cậy.

Smart contracts are software programs that are immutably stored on the blockchain. They are executed by virtual machines and store their data in that same immutable infrastructure. Smart contracts offer great benefits to businesses looking to optimize their operations. Many industries â€“ including automotive, supply chain, real estate and healthcare â€“ are investing in research to understand how this technology can make them more competitive.

Hợp đồng thông minh là các chương trình phần mềm được lưu trữ bất động trên blockchain.
Chúng được thực hiện bởi các máy ảo và lưu trữ dữ liệu của họ trong cùng một cơ sở hạ tầng bất biến đó.
Hợp đồng thông minh cung cấp lợi ích tuyệt vời cho các doanh nghiệp đang tìm cách tối ưu hóa hoạt động của họ.
Nhiều ngành công nghiệp - bao gồm cả ô tô, chuỗi cung ứng, bất động sản và chăm sóc sức khỏe - đang đầu tư vào nghiên cứu để hiểu làm thế nào công nghệ này có thể làm cho chúng cạnh tranh hơn.

### **What smart contracts technology is currently available?**

### ** Công nghệ hợp đồng thông minh nào hiện có sẵn? **

There are a few players on the market that offer smart contract capabilities including Hyperledger, NEO and Ethereum. The technology is evolving to meet the marketâ€™s demand for platforms that are fast, secure, accurate and can be trusted. Many businesses have tried to deploy broad-scale applications on these platforms and have run into problems (DAO hack, Parity bug and POWH coin to name a few) with these evolving platforms. Despite widespread publicity the most serious bugs [continue to reappear](https://arxiv.org/pdf/1802.06038.pdf "Finding The Greedy, Prodigal, and Suicidal Contracts at Scale") in smart contracts. There is a lot of room for innovation here and IOHK is working hard to become a leader in this technology.

Có một vài người chơi trên thị trường cung cấp các khả năng hợp đồng thông minh bao gồm Hyperledger, Neo và Ethereum.
Công nghệ đang phát triển để đáp ứng nhu cầu của thị trường đối với các nền tảng nhanh chóng, an toàn, chính xác và có thể được tin cậy.
Nhiều doanh nghiệp đã cố gắng triển khai các ứng dụng quy mô rộng trên các nền tảng này và gặp vấn đề (DAO Hack, Parity Bug và Powh Coin để đặt tên cho một số) với các nền tảng phát triển này.
Mặc dù công khai rộng rãi, các lỗi nghiêm trọng nhất [vẫn tiếp tục xuất hiện trở lại] (https://arxiv.org/pdf/1802.06038.pdf "Tìm các hợp đồng tham lam, hoang đàng và tự tử ở quy mô") trong các hợp đồng thông minh.
Có rất nhiều chỗ cho sự đổi mới ở đây và IOHK đang làm việc chăm chỉ để trở thành một nhà lãnh đạo trong công nghệ này.

### **What Is IELE?**

### ** iele là gì? **

IELE (pronounced YELL-eh) is a virtual machine, with an attendant low-level language, designed to execute smart contracts on the Cardano blockchain. It has been developed by Runtime Verification in partnership with IOHK, which provided funding for the project. The word IELE refers to nymphs in Romanian mythology.

IELE (phát âm là Yell-EH) là một máy ảo, với ngôn ngữ cấp thấp tiếp viên, được thiết kế để thực hiện các hợp đồng thông minh trên blockchain Cardano.
Nó đã được phát triển bằng cách xác minh thời gian chạy hợp tác với IOHK, nơi cung cấp tài trợ cho dự án.
Từ iele đề cập đến các nữ thần trong thần thoại Rumani.

### **How does IELE improve on smart contracts platforms?**

### ** IELE cải thiện trên nền tảng hợp đồng thông minh như thế nào? **

IELE is designed to meet the evolving needs of the market for smart contracts by:

IELE được thiết kế để đáp ứng nhu cầu phát triển của thị trường cho các hợp đồng thông minh bằng cách:

- Serving as a uniform, lower-level platform for translating and executing smart contracts from higher-level languages. It supports compilation from Solidity and many more languages are set to come.

-Phục vụ như một nền tảng cấp thấp, thống nhất để dịch và thực hiện các hợp đồng thông minh từ các ngôn ngữ cấp cao hơn.
Nó hỗ trợ biên dịch từ sự vững chắc và nhiều ngôn ngữ khác được thiết lập.

- Providing a uniform gas model, across all languages.

- Cung cấp một mô hình khí đồng đều, trên tất cả các ngôn ngữ.

- Making it easier to write secure smart contracts. IELE is '[correct by construction](https://testnet.iohkdev.io/goguen/iele/about/semantics-based-compilation/ "testnet.iohkdev.io")' so many errors discovered after the fact (during code execution) in other VMs are not possible in IELE.

- Làm cho nó dễ dàng hơn để viết các hợp đồng thông minh an toàn.
IELE là '[đúng bằng cách xây dựng] (https://testnet.iohkdev.io/goguen/iele/about/semantics dựa trên compilation/ "testnet.iohkdev.io")
thực thi) trong các máy ảo khác là không thể trong iele.

- Using a register-based as opposed to stack-based architecture.

-Sử dụng dựa trên đăng ký trái ngược với kiến trúc dựa trên ngăn xếp.

### **What can I do with IELE that I could not do before?**

### ** Tôi có thể làm gì với iele mà tôi không thể làm trước đây? **

IELE contains two parts: a correct-by-construction VM designed using the K framework, and a correct by construction, Solidity-to-IELE compiler, also designed using the K framework. When you write your Solidity program and try to compile it using the Solidity-to-IELE compiler, it will catch many of the errors that previously would have been missed and that have caused many smart contracts to fail or be exploited.

IELE chứa hai phần: một VM chính xác được thiết kế bằng khung K và trình biên dịch chính xác bằng cách xây dựng, sollity-ely, cũng được thiết kế sử dụng khung K.
Khi bạn viết chương trình vững chắc của mình và cố gắng biên dịch nó bằng trình biên dịch Solidity-iele, nó sẽ bắt gặp nhiều lỗi mà trước đây đã bị bỏ lỡ và điều đó đã khiến nhiều hợp đồng thông minh bị thất bại hoặc bị khai thác.

In addition, as IELE development progresses, we plan to deliver 'surface languages' allowing programmers proficient in Javascript, Python and other languages to have an easy way to integrate smart contracts into their applications.

Ngoài ra, khi IELE phát triển tiến triển, chúng tôi dự định cung cấp 'Ngôn ngữ bề mặt' cho phép các lập trình viên thành thạo JavaScript, Python và các ngôn ngữ khác có cách dễ dàng để tích hợp các hợp đồng thông minh vào các ứng dụng của họ.

### **What do I do next?**

### **Tôi làm gì tiếp theo?**

The IELE language and its VM are completed. It is now in the process of being integrated into Cardano, which will provide a blockchain to store and retrieve data. While the integration is taking place, developers have the opportunity to use the IELE VM along with the Mallet and Remix tools to create and execute smart contracts on the [IOHK testnet site](https://testnet.iohkdev.io/ "testnet.iohkdev.io").

Ngôn ngữ IELE và VM của nó được hoàn thành.
Bây giờ nó đang trong quá trình tích hợp vào Cardano, sẽ cung cấp một blockchain để lưu trữ và truy xuất dữ liệu.
Trong khi việc tích hợp đang diễn ra, các nhà phát triển có cơ hội sử dụng IELE VM cùng với các công cụ Mallet và Remix để tạo và thực hiện các hợp đồng thông minh trên trang [trang IOHK Testnet] (https://testnet.iohkdev.io/ "Testnet.
iohkdev.io ").

You can also start getting a feel for the capabilities of both IELE and its VM â€“ and even learn to write IELE code directly!

Bạn cũng có thể bắt đầu cảm nhận về khả năng của cả IELE và VM của nó và thậm chí học cách viết mã IELE trực tiếp!

##### [**Join the conversation!**](https://forum.cardano.org/t/iohk-statement-cardano-smart-contracts-testnet-iele-launches/14432 "IOHK Statement: Cardano smart contracts testnet IELE launches")

##### [** Tham gia cuộc trò chuyện! **] (https://forum.cardano.org/t/iohk-statement-cardano-smart-contracts-testnet
Hợp đồng thông minh Testnet IELE ra mắt ")

Â 

MỘT

##### **Related video updates**

##### ** Cập nhật video liên quan **

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2018-07-30-cardano-smart-contracts-testnet-iele-launches.010.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

