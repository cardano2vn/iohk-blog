# Self Organisation in Coin Selection
![](img/2018-07-03-self-organisation-in-coin-selection.002.png) 3 July 2018![](img/2018-07-03-self-organisation-in-coin-selection.002.png)[ Edsko de Vries](tmp//en/blog/authors/edsko-de-vries/page-1/)![](img/2018-07-03-self-organisation-in-coin-selection.003.png) 18 mins read

![Edsko de Vries](img/2018-07-03-self-organisation-in-coin-selection.004.png)[](tmp//en/blog/authors/edsko-de-vries/page-1/)
### [**Edsko de Vries**](tmp//en/blog/authors/edsko-de-vries/page-1/)
Software Engineer

Well-Typed

- ![](img/2018-07-03-self-organisation-in-coin-selection.005.png)[](http://www.linkedin.com/in/edsko-de-vries-04126b31 "LinkedIn")
- ![](img/2018-07-03-self-organisation-in-coin-selection.006.png)[](https://twitter.com/EdskoDeVries "Twitter")
- ![](img/2018-07-03-self-organisation-in-coin-selection.007.png)[](https://github.com/edsko "GitHub")

![Self Organisation in Coin Selection](img/2018-07-03-self-organisation-in-coin-selection.008.jpeg)

The term "self organisation" refers to the emergence of complex behaviour (typically in biological systems) from simple rules and random fluctuations. In this blog post we will see how we can take advantage of self organisation to design a simple yet effective coin selection algorithm. Coin selection is the process of selecting unspent outputs in a user's wallet to satisfy a particular payment request (for a recap of UTxO style accounting, see section "Background: UTxO-style Accounting" of my [previous blog post](tmp//en/blog/semi-formal-development-the-cardano-wallet/ "Semi-Formal Development: The Cardano Wallet")). As Jameson Lopp points out in his blog post [The Challenges of Optimizing Unspent Output Selection](https://medium.com/@lopp/the-challenges-of-optimizing-unspent-output-selection-a3e5d05d13ef "The Challenges of Optimizing Unspent Output Selection, medium.com"), coin selection is thorny problem. Moreover, there is a surprising lack of academic publications on the topic; indeed, the only scientific study of coin selection appears to be Mark Erhardt's masters thesis [An Evaluation of Coin Selection Strategies](http://murch.one/wp-content/uploads/2016/11/erhardt2016coinselection.pdf "erhardt2016coinselection.pdf, murch.one").

Thuật ngữ "tổ chức tự" đề cập đến sự xuất hiện của hành vi phức tạp (thường là trong các hệ thống sinh học) từ các quy tắc đơn giản và biến động ngẫu nhiên. Trong bài đăng trên blog này, chúng tôi sẽ thấy làm thế nào chúng tôi có thể tận dụng lợi thế của tổ chức tự để thiết kế một thuật toán lựa chọn đồng tiền đơn giản nhưng hiệu quả. Lựa chọn tiền xu là quá trình chọn đầu ra chưa được sử dụng trong ví của người dùng để đáp ứng yêu cầu thanh toán cụ thể (để tóm tắt lại kế toán kiểu UTXO, xem phần "Bối cảnh: Kế toán theo kiểu UTXO" /blog/bán chính thức-phát triển-the-cardano-wallet/"Phát triển bán chính thức: ví Cardano")). Như Jameson Lopp chỉ ra trong bài đăng trên blog của mình [những thách thức trong việc tối ưu hóa lựa chọn đầu ra không có cơ hội] (https://medium.com/@lopp/the-stallenges-of-optimizing-unspent-output-selection Lựa chọn đầu ra chưa được, Medium.com "), Lựa chọn tiền xu là vấn đề gai góc. Hơn nữa, có một sự thiếu đáng ngạc nhiên thiếu các ấn phẩm học thuật về chủ đề này; Thật vậy, nghiên cứu khoa học duy nhất về lựa chọn tiền xu dường như là luận điểm thạc sĩ của Mark Erhardt [đánh giá các chiến lược lựa chọn tiền xu] (http://murch.one/wp-content/uploads/2016/11/erhardt2016coinselection.pdf "Erhardt2016 , Murch.one ").

Note: by a slight abuse of nomenclature, throughout this blog post we will refer to a user's set of unspent outputs as that user's UTxO.

Lưu ý: Bằng một chút lạm dụng danh pháp, trong suốt bài đăng trên blog này, chúng tôi sẽ đề cập đến bộ đầu ra không có cơ sở của người dùng như UTXO của người dùng.

## **Dust**

## **Bụi bặm**

An obvious strategy that many coin selection algorithms use in some form or other is "try to get as close to the requested value as possible". The problem with such an approach is that it tends to create a lot of dust: small unspent outputs that remain unused in the user's wallet because they're not particularly useful. For example, consider the "largest first" algorithm: a simple algorithm which considers all unspent outputs of the wallet in order of size, adding them to a running total until it has covered the requested amount. Here's an animation of the effect of this algorithm:

Một chiến lược rõ ràng mà nhiều thuật toán lựa chọn tiền xu sử dụng ở dạng này hoặc hình thức khác là "cố gắng đạt được gần với giá trị được yêu cầu nhất có thể".
Vấn đề với cách tiếp cận như vậy là nó có xu hướng tạo ra nhiều bụi: đầu ra nhỏ không được sử dụng trong ví của người dùng vì chúng không đặc biệt hữu ích.
Ví dụ, hãy xem xét thuật toán "lớn nhất đầu tiên": một thuật toán đơn giản xem xét tất cả các đầu ra chưa được sử dụng của ví theo thứ tự kích thước, thêm chúng vào tổng số chạy cho đến khi nó bao gồm số tiền được yêu cầu.
Đây là hình ảnh động về hiệu ứng của thuật toán này:

![Figure 1](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 1-1](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 1.** Simulation of largest-first coin selection. Main histogram shows UTxO entries; inset graph shows UTxO balance in blue and UTxO size in red, histogram top-right shows number of inputs per transaction, graph bottom right shows the change:payment ratio (more on that below). Graph at the bottom shows the distribution of deposits (blue, left axis) versus payments (red, right axis). In this case, both are normally distributed with a mean of 1000 and 3000 respectively, and we have a deposit:payment ratio of 3:1; modelling a situation where we have frequent smaller deposits, and less frequent but larger payments (withdrawals). The wallet starts with an initial balance of 1M.

** Hình 1. ** Mô phỏng lựa chọn đồng xu đầu tiên lớn nhất.
Biểu đồ chính cho thấy các mục UTXO;
Biểu đồ Inset hiển thị số dư UTXO với kích thước màu xanh và utxo màu đỏ, biểu đồ trên cùng bên phải hiển thị số lượng đầu vào trên mỗi giao dịch, biểu đồ dưới cùng bên phải cho thấy sự thay đổi: tỷ lệ thanh toán (nhiều hơn ở bên dưới).
Đồ thị ở phía dưới cho thấy phân phối tiền gửi (màu xanh, trục trái) so với thanh toán (màu đỏ, trục phải).
Trong trường hợp này, cả hai đều được phân phối thường với giá trị trung bình lần lượt là 1000 và 3000 và chúng tôi có một khoản tiền gửi: tỷ lệ thanh toán là 3: 1;
Mô hình hóa một tình huống mà chúng tôi có các khoản tiền gửi nhỏ hơn thường xuyên và ít thường xuyên hơn nhưng các khoản thanh toán lớn hơn (rút tiền).
Ví bắt đầu với số dư ban đầu là 1m.

There are various things to see in this animation, but for now we want to focus on the UTxO histogram and its size. Note that as time passes, the size of the UTxO increases and increases, up to about 60k entries after about 1M cycles (with 3 deposits and 1 payment per cycle). A wallet with 60k entries is huge, and looking at the UTxO histogram we can see why this happens: virtually all of these entries are dust. We get more and more small outputs, and those small outputs are getting smaller and smaller.

Có nhiều thứ khác nhau để xem trong hoạt hình này, nhưng bây giờ chúng tôi muốn tập trung vào biểu đồ UTXO và kích thước của nó.
Lưu ý rằng khi thời gian trôi qua, kích thước của UTXO tăng và tăng, lên tới khoảng 60k mục sau khoảng 1M chu kỳ (với 3 khoản tiền gửi và 1 thanh toán mỗi chu kỳ).
Một ví với các mục 60k là rất lớn và nhìn vào biểu đồ UTXO, chúng ta có thể thấy tại sao điều này xảy ra: Hầu như tất cả các mục này là bụi.
Chúng ta ngày càng có nhiều đầu ra nhỏ, và những đầu ra nhỏ đó ngày càng nhỏ hơn.

## **Cleaning up**

## **Dọn dẹp**

Erhardt makes the following very astute observation:

Erhardt làm cho những quan sát rất sắc bén sau:

If 90% of the UTxO is dust, then if we pick an unspent output randomly, we have a 90% change of picking a dust output. 

Nếu 90% UTXO là bụi, thì nếu chúng ta chọn một đầu ra không sử dụng ngẫu nhiên, chúng ta có thay đổi 90% khi chọn đầu ra bụi.

He concludes that this means that a coin selection algorithm that simply picks unspent outputs at random might be pretty effective; in particular, effective at collecting dust. Indeed, it is. Consider the following simulation:

Ông kết luận rằng điều này có nghĩa là một thuật toán lựa chọn tiền xu chỉ đơn giản là chọn các đầu ra chưa được sử dụng một cách ngẫu nhiên có thể khá hiệu quả;
Đặc biệt, hiệu quả trong việc thu thập bụi.
Thật vậy, nó là.
Xem xét mô phỏng sau:

![Figure 2](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 2-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 2.** Same distribution and ratio as in Figure 1; we run the largest-first algorithm for 1M cycles, and then random coin selection for another 150k cycles. 

** Hình 2. ** Phân phối và tỷ lệ tương tự như trong Hình 1;
Chúng tôi chạy thuật toán lớn nhất đầu tiên cho các chu kỳ 1M và sau đó lựa chọn đồng xu ngẫu nhiên cho các chu kỳ 150k khác.

Notice quite how rapidly the random coin selection reduces the size of the UTxO once it kicks in. If you watch the inputs-per-transaction histogram, you can see that when the random input selection takes over, it first creates a bunch of transactions with 10 inputs (we limited transaction size to 10 for this simulation), rapidly collecting dust. Once the dust is gone, the number of inputs shrinks to about 3 or 4, which makes perfect sense given the 3:1 ratio of deposits and withdrawals.

Lưu ý khá nhanh, việc lựa chọn đồng xu ngẫu nhiên sẽ giảm kích thước của UTXO sau khi nó khởi động. Nếu bạn xem biểu đồ đầu vào cho mỗi lần chuyển đổi, bạn có thể thấy rằng khi lựa chọn đầu vào ngẫu nhiên chiếm lấy, trước tiên nó sẽ tạo ra một loạt các giao dịch với
10 đầu vào (chúng tôi giới hạn kích thước giao dịch ở 10 cho mô phỏng này), nhanh chóng thu thập bụi.
Khi bụi đã biến mất, số lượng đầu vào sẽ giảm xuống còn khoảng 3 hoặc 4, điều này có ý nghĩa hoàn hảo với tỷ lệ 3: 1 của tiền gửi và rút tiền.

We will restate Erhardt's observation as our first self organisation principle:

Chúng tôi sẽ phục hồi quan sát của Erhardt như là nguyên tắc tự tổ chức đầu tiên của chúng tôi:

**Self organisation principle 1.** Random selection has a high priobability of picking dust outputs precisely when there is a lot of dust in the UTxO. 

** Nguyên tắc tự tổ chức 1. ** Lựa chọn ngẫu nhiên có khả năng chọn đầu ra bụi chính xác khi có nhiều bụi trong UTXO.

It provides a very promising starting point for an effective coin selection algorithm, but there are some improvements we can make.

Nó cung cấp một điểm khởi đầu rất hứa hẹn cho một thuật toán lựa chọn tiền xu hiệu quả, nhưng có một số cải tiến chúng ta có thể thực hiện.

## **Active UTxO management**

## ** Quản lý UTXO hoạt động **

Consider the following simulation of a pure "select randomly until we reach the target value" coin selection algorithm:

Hãy xem xét mô phỏng sau đây của "Chọn ngẫu nhiên cho đến khi chúng ta đạt được giá trị đích" Thuật toán lựa chọn đồng xu:

![Figure 3](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 3-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 3.** Random-until-value-reached, for a 1:1 ratio of deposits and withdrawals, both drawn from a normal distribution with mean 1000. 

** Hình 3. ** Random-Until-Value-Reached, với tỷ lệ 1: 1 của tiền gửi và rút tiền, cả hai được rút ra từ phân phối bình thường với trung bình 1000.

The first observation is that this algorithm is doing much better than the largest-first policy in terms of the size of the UTxO, which is about 2 orders of magnitude smaller: a dramatic improvement. However, if we look at the UTxO histogram, we can see that there is room for improvement: although this algorithm is good at collecting dust, it's also still generating quite a bit of dust. The UTxO histogram has two peaks. The first one is approximately normally distributed around 1000, which are the deposits that are being made. The second one is near 0, which are all the dust outputs that are being created.

Quan sát đầu tiên là thuật toán này đang hoạt động tốt hơn nhiều so với chính sách lớn nhất đầu tiên về quy mô của UTXO, có khoảng 2 đơn đặt hàng nhỏ hơn: cải thiện đáng kể.
Tuy nhiên, nếu chúng ta nhìn vào biểu đồ UTXO, chúng ta có thể thấy rằng có chỗ để cải thiện: mặc dù thuật toán này rất tốt trong việc thu thập bụi, nhưng nó vẫn tạo ra khá nhiều bụi.
Biểu đồ UTXO có hai đỉnh.
Cái đầu tiên được phân phối khoảng bình thường khoảng 1000, đó là các khoản tiền gửi đang được thực hiện.
Cái thứ hai là gần 0, đó là tất cả các đầu ra bụi đang được tạo ra.

This brings us to the topic of active UTxO management. In an ideal case, coin selection algorithms should, over time, create a UTxO that has "useful" outputs; that is, outputs that allow us to process future payments with a minimum number of inputs. We can take advantage of self organisation again:

Điều này đưa chúng ta đến chủ đề quản lý UTXO hoạt động.
Trong một trường hợp lý tưởng, các thuật toán lựa chọn tiền xu, theo thời gian, sẽ tạo ra một UTXO có đầu ra "hữu ích";
Đó là, các đầu ra cho phép chúng tôi xử lý các khoản thanh toán trong tương lai với số lượng đầu vào tối thiểu.
Chúng ta có thể tận dụng lợi thế của tổ chức bản thân một lần nữa:

**Self organisation principle 2.** If for each payment request for value x we create a change output roughly of the same value x, then we will end up with a lot of change outputs in our UTxO of size x precisely when we have a lot of payment requests of size x. 

** Nguyên tắc tự tổ chức 2. ** Nếu đối với mỗi yêu cầu thanh toán cho giá trị x, chúng tôi tạo ra một đầu ra thay đổi gần đúng với giá trị x, thì chúng tôi sẽ kết thúc với rất nhiều đầu ra thay đổi trong UTXO của chúng tôi
Rất nhiều yêu cầu thanh toán có kích thước x.

We will consider some details of how to achieve this in the next section. For now see what the effect of this is on the UTxO:

Chúng tôi sẽ xem xét một số chi tiết về cách đạt được điều này trong phần tiếp theo.
Bây giờ hãy xem ảnh hưởng của điều này đối với UTXO:

![Figure 4](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 4-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 4.** Same deposits and withdrawals as in Figure 3, but now using the "pick randomly until we have a change output roughly equal to the payment" algorithm. 

** Hình 4. ** Cùng một khoản tiền gửi và rút tiền như trong Hình 3, nhưng bây giờ sử dụng "Chọn ngẫu nhiên cho đến khi chúng tôi có đầu ra thay đổi gần bằng với thuật toán thanh toán".

The graph at the bottom right, which we've ignored so far, records the change:payment ratio. A value near zero means a very small change output (i.e., dust); a very high value would be the result of using a huge UTxO entry for a much smaller payment. A value around 1 is perfect, and means that we are generating change outputs of equal value as the payments.

Biểu đồ ở phía dưới bên phải, mà chúng tôi đã bỏ qua cho đến nay, ghi lại sự thay đổi: tỷ lệ thanh toán.
Giá trị gần bằng không có nghĩa là đầu ra thay đổi rất nhỏ (nghĩa là bụi);
Một giá trị rất cao sẽ là kết quả của việc sử dụng một mục UTXO khổng lồ để thanh toán nhỏ hơn nhiều.
Một giá trị khoảng 1 là hoàn hảo và có nghĩa là chúng tôi đang tạo ra các đầu ra thay đổi có giá trị bằng nhau như các khoản thanh toán.

Note that the UTxO now follows precisely the distribution of payment requests, and we're not generating dust anymore. One advantage of this is that because we have no dust, the average number of inputs per transaction can be lower than in the basic algorithm.

Lưu ý rằng UTXO hiện tuân theo chính xác việc phân phối các yêu cầu thanh toán và chúng tôi sẽ không tạo ra bụi nữa.
Một lợi thế của điều này là vì chúng tôi không có bụi, số lượng đầu vào trung bình trên mỗi giao dịch có thể thấp hơn trong thuật toán cơ bản.

Just to illustrate this again, here is the result of the algorithm but now with a 3:1 ratio of deposits and withdrawals:

Chỉ để minh họa điều này một lần nữa, đây là kết quả của thuật toán nhưng bây giờ với tỷ lệ 3: 1 của tiền gửi và rút tiền:

![Figure 5](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 5-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 5.** Same algorithm as in Figure 4, but now with 3:1 deposits:payments (i.e., many small deposits, fewer but larger payments). 

** Hình 5. ** Tương tự thuật toán như trong Hình 4, nhưng bây giờ với các khoản tiền gửi 3: 1: Thanh toán (tức là, nhiều tiền gửi nhỏ, thanh toán ít hơn nhưng lớn hơn).

We have two bumps now: one normally distributed around 1000, corresponding to the the deposits, and one normally distributed around 3000, corresponding to the payment requests that are being made. As before, the median change:payment ratio is a satisfying round 1.0.

Bây giờ chúng tôi có hai va chạm: một lần phân phối bình thường khoảng 1000, tương ứng với các khoản tiền gửi và một lần được phân phối bình thường khoảng 3000, tương ứng với các yêu cầu thanh toán đang được thực hiện.
Như trước đây, thay đổi trung bình: Tỷ lệ thanh toán là một vòng thỏa mãn 1.0.

## **The "Random-Improve" algorithm**

# Ch

We are now ready to present the coin selection algorithm we propose. The basic idea is simple: we will randomly pick UTxO entries until we have reached the required value, and then continue randomly picking UTxO entries to try and reach a total value such that the the change value is roughly equal to the payment.

Bây giờ chúng tôi đã sẵn sàng để trình bày thuật toán lựa chọn tiền xu mà chúng tôi đề xuất.
Ý tưởng cơ bản rất đơn giản: Chúng tôi sẽ chọn ngẫu nhiên các mục UTXO cho đến khi chúng tôi đạt được giá trị cần thiết, và sau đó tiếp tục chọn các mục UTXO ngẫu nhiên để thử và đạt được tổng giá trị sao cho giá trị thay đổi gần bằng với khoản thanh toán.

This presents a dilemma though. Suppose we have already covered the minimum value required, and we're trying to improve the change output. We pick an output from the UTxO, and it turns out to be huge. What do we do? One option is to discard it and continue searching, but this would result in coin selection frequently traversing the entire UTxO, resulting in poor performance.

Điều này trình bày một vấn đề nan giải mặc dù.
Giả sử chúng ta đã đề cập đến giá trị tối thiểu cần thiết và chúng ta đang cố gắng cải thiện đầu ra thay đổi.
Chúng tôi chọn một đầu ra từ UTXO, và hóa ra là rất lớn.
Chúng ta làm gì?
Một tùy chọn là loại bỏ nó và tiếp tục tìm kiếm, nhưng điều này sẽ dẫn đến việc lựa chọn tiền xu thường xuyên đi qua toàn bộ UTXO, dẫn đến hiệu suất kém.

Fortunately, self organisation comes to the rescue again. We can set an upper bound on the size of the change output we still consider acceptable (we will set it to twice the payment value). Then we take advantage of the following property.

May mắn thay, tổ chức tự đến giải cứu một lần nữa.
Chúng tôi có thể đặt giới hạn trên trên kích thước của đầu ra thay đổi mà chúng tôi vẫn xem xét chấp nhận được (chúng tôi sẽ đặt nó thành hai lần giá trị thanh toán).
Sau đó, chúng tôi tận dụng tài sản sau.

**Self organisation principle 3.** Searching the UTxO for additional entries to improve our change output is only useful if the UTxO contains entries that are sufficiently small enough. But precisely when the UTxO contains many small entries, it is less likely that a randomly chosen UTxO entry will push the total above the upper bound we set.

** Nguyên tắc tự tổ chức 3. ** Tìm kiếm UTXO cho các mục bổ sung để cải thiện đầu ra thay đổi của chúng tôi chỉ hữu ích nếu UTXO chứa các mục đủ nhỏ.
Nhưng chính xác khi UTXO chứa nhiều mục nhỏ, ít có khả năng là một mục UTXO được chọn ngẫu nhiên sẽ đẩy tổng số trên giới hạn trên mà chúng tôi đặt.

In other words, our answer to "what do we do when we happen to pick a huge UTxO entry?" is "we stop trying to improve our selection". We can now describe the algorithm:

Nói cách khác, câu trả lời của chúng tôi cho "Chúng tôi phải làm gì khi chúng tôi chọn một mục UTXO khổng lồ?"
là "chúng tôi ngừng cố gắng cải thiện lựa chọn của chúng tôi".
Bây giờ chúng ta có thể mô tả thuật toán:

1. Randomly select outputs from the UTxO until the payment value is covered. (In the rare case that this fails because the maximum number of transaction inputs has been exceeded, fall-back on the largest-first algorithm for this step.)

1. Chọn ngẫu nhiên đầu ra từ UTXO cho đến khi giá trị thanh toán được bảo hiểm.
.

1. Randomly select outputs from the UTxO, considering for each output if that output is an improvement. If it is, add it to the transaction, and keep going. An output is considered an improvement when:

1. Chọn ngẫu nhiên đầu ra từ UTXO, xem xét cho mỗi đầu ra nếu đầu ra đó là một cải tiến.
Nếu có, thêm nó vào giao dịch, và tiếp tục.
Một đầu ra được coi là một cải tiến khi:

   1. It doesn't exceed the specified upper limit

1. Nó không vượt quá giới hạn trên được chỉ định

   1. Adding the new output gets us closer to the ideal change value

1. Thêm đầu ra mới giúp chúng tôi gần hơn với giá trị thay đổi lý tưởng

   1. It doesn't exceed the maximum number of transaction inputs.

1. Nó không vượt quá số lượng đầu vào giao dịch tối đa.

**Figure 6.** The Random-Improve algorithm. Side note for point (2a): we use twice the value of the payment as the upper limit. Side note for point (2b): it might be that without the new output we are slightly below the ideal value, and with the new output we are slightly above; that is fine, as long as the absolute distance decreases.

** Hình 6. ** Thuật toán cải thiện ngẫu nhiên.
Lưu ý bên cho điểm (2A): Chúng tôi sử dụng hai lần giá trị của khoản thanh toán làm giới hạn trên.
Lưu ý bên cho điểm (2B): Có thể là nếu không có đầu ra mới, chúng ta hơi thấp hơn giá trị lý tưởng và với đầu ra mới, chúng ta hơi ở trên;
Điều đó là tốt, miễn là khoảng cách tuyệt đối giảm.

## **Evaluation**

## **Sự đánh giá**

The algorithm from Figure 6 is deceptively simple. Do the self organisation principles we isolated really mean that order will emerge from chaos? Simulations suggest, yes, it does. We already mentioned how random input selection does a great job at cleaning up dust in Figure 2; what we didn't emphasize in that section is that the algorithm we simulated there is actually our Random-Improve algorithm. Notice how the median change:payment ratio is initially very low (indicative of a coin selection algorithm that is generating a lot of dust outputs), but climbs rapidly back to 1 as soon as Random-Improve kicks in. We already observed that it does indeed do an excellent job at cleaning up the dust, quickly reducing the size of the UTxO. The simulations in Figures 4 and 5 are also the result of the Random-Improve algorithm.

Thuật toán từ Hình 6 rất đơn giản.
Các nguyên tắc tự tổ chức mà chúng ta đã cô lập thực sự có nghĩa là trật tự sẽ xuất hiện từ sự hỗn loạn?
Mô phỏng đề xuất, vâng, nó làm.
Chúng tôi đã đề cập làm thế nào lựa chọn đầu vào ngẫu nhiên thực hiện một công việc tuyệt vời trong việc làm sạch bụi trong Hình 2;
Điều chúng tôi không nhấn mạnh trong phần đó là thuật toán chúng tôi mô phỏng thực sự có thuật toán cải thiện ngẫu nhiên của chúng tôi.
Lưu ý cách thay đổi trung bình: Tỷ lệ thanh toán ban đầu rất thấp (cho thấy thuật toán lựa chọn đồng xu đang tạo ra nhiều đầu ra bụi), nhưng leo lên nhanh chóng trở lại ngay khi tôi bắt đầu.
Thật vậy, làm một công việc tuyệt vời trong việc làm sạch bụi, nhanh chóng giảm kích thước của UTXO.
Các mô phỏng trong Hình 4 và 5 cũng là kết quả của thuật toán cải thiện ngẫu nhiên.

That said, of course the long term effects of a coin selection algorithm can depend strongly on the nature of the distribution of deposits and payments. It is therefore important that we evaluate the algorithm against a number of different distributions.

Điều đó nói rằng, tất nhiên các tác động lâu dài của thuật toán lựa chọn tiền xu có thể phụ thuộc mạnh mẽ vào bản chất của phân phối tiền gửi và thanh toán.
Do đó, điều quan trọng là chúng tôi đánh giá thuật toán đối với một số phân phối khác nhau.

### **Normal distribution, 10:1 deposit:payment ratio**

### ** Phân phối bình thường, tiền gửi 10: 1: Tỷ lệ thanh toán **

We already evaluated "Random-Improve" against normally distributed payments and deposits with a 1:1 ratio and a 3:1 ratio; perhaps more typical for exchange nodes might be even higher ratios. Here is a 10:1 ratio:

Chúng tôi đã đánh giá "tác giả ngẫu nhiên" đối với các khoản thanh toán và tiền gửi được phân phối bình thường với tỷ lệ 1: 1 và tỷ lệ 3: 1;
Có lẽ điển hình hơn cho các nút trao đổi có thể thậm chí là tỷ lệ cao hơn.
Đây là tỷ lệ 10: 1:

![Figure 7](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 7-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 7.** Simulation of largest-first coin selection. Main histogram shows UTxO entries; inset graph shows UTxO balance in blue and UTxO size in red, histogram top-right shows number of inputs per transaction, graph bottom right shows the change:payment ratio (more on that below). Graph at the bottom shows the distribution of deposits (blue, left axis) versus payments (red, right axis). In this case, both are normally distributed with a mean of 1000 and 3000 respectively, and we have a deposit:payment ratio of 3:1; modelling a situation where we have frequent smaller deposits, and less frequent but larger payments (withdrawals). The wallet starts with an initial balance of 1M.

** Hình 7. ** Mô phỏng lựa chọn đồng xu đầu tiên lớn nhất.
Biểu đồ chính cho thấy các mục UTXO;
Biểu đồ Inset hiển thị số dư UTXO với kích thước màu xanh và utxo màu đỏ, biểu đồ trên cùng bên phải hiển thị số lượng đầu vào trên mỗi giao dịch, biểu đồ dưới cùng bên phải cho thấy sự thay đổi: tỷ lệ thanh toán (nhiều hơn ở bên dưới).
Đồ thị ở phía dưới cho thấy phân phối tiền gửi (màu xanh, trục trái) so với thanh toán (màu đỏ, trục phải).
Trong trường hợp này, cả hai đều được phân phối thường với giá trị trung bình lần lượt là 1000 và 3000 và chúng tôi có một khoản tiền gửi: tỷ lệ thanh toán là 3: 1;
Mô hình hóa một tình huống mà chúng tôi có các khoản tiền gửi nhỏ hơn thường xuyên và ít thường xuyên hơn nhưng các khoản thanh toán lớn hơn (rút tiền).
Ví bắt đầu với số dư ban đầu là 1m.

We see a very similar picture as we did in Figure 5. Since the deposits and payments are randomly drawn (from normal distributions), the UTxO balance naturally fluctuates up and down. What is satisfying to see however is that the size of the UTxO tracks the balance rather precisely; this is about as good as we can hope for. Notice also that the change:payment ratio is a nice round 1, and the average number of transaction inputs covers around 10 or 11, which is what we'd expect for a 10:1 ratio of deposits:payments.

Chúng tôi thấy một bức tranh rất giống nhau như chúng tôi đã làm trong Hình 5. Vì các khoản tiền gửi và thanh toán được rút ngẫu nhiên (từ các phân phối bình thường), cân bằng UTXO tự nhiên dao động lên xuống.
Tuy nhiên, điều thỏa mãn để thấy là kích thước của UTXO theo dõi sự cân bằng khá chính xác;
Điều này là tốt như chúng ta có thể hy vọng.
Cũng lưu ý rằng thay đổi: Tỷ lệ thanh toán là vòng 1 đẹp và số lượng đầu vào giao dịch trung bình bao gồm khoảng 10 hoặc 11, đó là những gì chúng tôi mong đợi cho tỷ lệ tiền gửi 10: 1: Thanh toán.

### **Exponential distribution, 1:1 deposit:payment ratio**

### ** Phân phối theo cấp số nhân, tiền gửi 1: 1: Tỷ lệ thanh toán **

What if the payments and deposits are not normally distributed? Here is Random-Improve on exponentially distributed inputs:

Điều gì sẽ xảy ra nếu các khoản thanh toán và tiền gửi thường không được phân phối?
Dưới đây là tác động ngẫu nhiên trên các đầu vào phân bố theo cấp số nhân:

![Figure 8](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 8-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 8.** Random-Improve, 1:1 deposit:payment ratio, deposits and payments both drawn from an exponential distribution with scale 1000.

** Hình 8. ** Ăn ngẫu nhiên, 1: 1 Tiền gửi: Tỷ lệ thanh toán, tiền gửi và thanh toán cả được rút ra từ phân phối theo cấp số nhân với tỷ lệ 1000.

In an exponential distribution we have a lot of values near 0; for such values it will be hard to achieve a "good" change output, as we are likely to overshoot the range. Partly due to this reason the algorithm isn't quite achieving a 1.0 change:payment ratio, but at 1.5 it is still generating useful change outputs. Furthermore, we can see that the size of the UTxO tracks the UTxO balance nicely, and the average number of transaction inputs is low, with roughly 53% having just one input.

Trong phân phối theo cấp số nhân, chúng ta có rất nhiều giá trị gần 0;
Đối với các giá trị như vậy, sẽ rất khó để đạt được đầu ra thay đổi "tốt", vì chúng ta có khả năng vượt quá phạm vi.
Một phần vì lý do này, thuật toán không hoàn toàn đạt được sự thay đổi 1.0: tỷ lệ thanh toán, nhưng ở mức 1.5, nó vẫn tạo ra các đầu ra thay đổi hữu ích.
Hơn nữa, chúng ta có thể thấy rằng kích thước của UTXO theo dõi số dư UTXO một cách độc đáo và số lượng đầu vào giao dịch trung bình thấp, với khoảng 53% chỉ có một đầu vào.

Moreover, when we increase the deposit:payment ratio to 3:1 and then 10:0, the change:payment ratio drops to about 1.1 and then back to 1.0 (graphs omitted).

Hơn nữa, khi chúng tôi tăng tỷ lệ tiền gửi: Tỷ lệ thanh toán lên 3: 1 và sau đó 10: 0, tỷ lệ thay đổi: Tỷ lệ thanh toán giảm xuống còn khoảng 1,1 và sau đó trở lại 1.0 (đồ thị bị bỏ qua).

### **Erlang**

### ** erlang **

The exponential distribution results in many very small deposits and payments. The algorithm does better on slightly more realistic distributions such as the Erlang-k distributions (for k > 1). Here we show the animation for the 3:1 deposit:payment ratio using the Erlang-3 distribution; the results for other ratios (including 1:1) and other values of k (we additionally simulated for k = 2 and k = 10) are similar.

Phân phối theo cấp số nhân dẫn đến nhiều khoản tiền gửi và thanh toán rất nhỏ.
Thuật toán hoạt động tốt hơn trên các phân phối thực tế hơn một chút như phân phối Erlang-K (cho K> 1).
Ở đây chúng tôi hiển thị hoạt hình cho khoản tiền gửi 3: 1: Tỷ lệ thanh toán bằng cách sử dụng phân phối ERLANG-3;
Các kết quả cho các tỷ lệ khác (bao gồm 1: 1) và các giá trị khác của K (chúng tôi cũng mô phỏng cho K = 2 và K = 10) là tương tự nhau.

![Figure 9](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 9-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 9.** Random-Improve, 3:1 deposit:payment ratio, deposits drawn from an Erlang-3 distribution with scale 1000 and payments drawn from Erlang-3 distributio with scale 3000.

** Hình 9. ** Ăn kèm ngẫu nhiên, Tiền gửi 3: 1: Tỷ lệ thanh toán, Tiền gửi được rút ra từ phân phối Erlang-3 với tỷ lệ 1000 và các khoản thanh toán được rút ra từ Erlang-3 Distributio với tỷ lệ 3000.

### **More payments than deposits**

### ** Thanh toán nhiều hơn tiền gửi **

We have been focusing on the case where we have more deposits and fewer (but larger) payments. What happens if the ratio is reversed?

Chúng tôi đã tập trung vào trường hợp chúng tôi có nhiều tiền gửi và ít hơn (nhưng lớn hơn).
Điều gì xảy ra nếu tỷ lệ bị đảo ngược?

![Figure 10](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 10-2](img/2018-07-03-self-organisation-in-coin-selection.010.png) 

**Figure 10.** Random-Improve, 1:10 deposit:payment ratio, deposits and payments drawn from a normal distribution with mean 10k and 1k, respectively. 1M cycles.

** Hình 10. ** Ăn tiền ngẫu nhiên, 1:10 Tiền gửi: Tỷ lệ thanh toán, tiền gửi và thanh toán được rút ra từ phân phối bình thường với trung bình 10K và 1K, tương ứng.
Chu kỳ 1m.

In this case we are unable to achieve that perfect 1.0 change:payment ratio, but this is expected: when we have large deposits, then we frequently have no choice but to use those, leading to large change outputs. We can see this more clearly when we slow things right down, and remove any source of randomness; here is the same 1:10 ratio again, but now only the first 100 cycles, and all deposits exactly 10k and all payments exactly 1k:

Trong trường hợp này, chúng tôi không thể đạt được thay đổi 1.0 hoàn hảo đó: tỷ lệ thanh toán, nhưng điều này được mong đợi: khi chúng tôi có tiền gửi lớn, thì chúng tôi thường không có lựa chọn nào khác ngoài việc sử dụng chúng, dẫn đến đầu ra thay đổi lớn.
Chúng ta có thể thấy điều này rõ ràng hơn khi chúng ta làm chậm mọi thứ ngay lập tức và loại bỏ bất kỳ nguồn ngẫu nhiên nào;
Đây là cùng một tỷ lệ 1:10 một lần nữa, nhưng bây giờ chỉ có 100 chu kỳ đầu tiên và tất cả các khoản tiền gửi chính xác là 10k và tất cả các khoản thanh toán chính xác 1K:

![Figure 11](img/2018-07-03-self-organisation-in-coin-selection.009.png) 

**Figure 11.** Random-Improve, 1:10 deposit:payment ratio, all deposits exactly 10k, all payments exactly 1k (no randomness). First 100 cycles only.

** Hình 11. ** Random-unprove, 1:10 Tiền gửi: Tỷ lệ thanh toán, tất cả các khoản tiền gửi chính xác 10k, tất cả các khoản thanh toán chính xác 1K (không ngẫu nhiên).
Chỉ 100 chu kỳ đầu tiên.

We can see the large value being deposited, and then shifting to the left in the histogram as it is getting used for deposits, each time decreasing that large output by 1k. Indeed, this takes 10 slots on average, which makes sense given the 10:1 ratio; moreover, the average value of the "large output" in such a 10-slot cycle is 5k, explaining why we are getting 5.0 change:payment ratio.

Chúng ta có thể thấy giá trị lớn được lắng đọng, và sau đó chuyển sang bên trái trong biểu đồ vì nó được sử dụng cho tiền gửi, mỗi lần giảm sản lượng lớn đó 1K.
Thật vậy, điều này mất trung bình 10 vị trí, điều này có ý nghĩa với tỷ lệ 10: 1;
Hơn nữa, giá trị trung bình của "đầu ra lớn" trong chu kỳ 10 khe như vậy là 5K, giải thích lý do tại sao chúng tôi nhận được thay đổi 5.0: tỷ lệ thanh toán.

The algorithm however is not creating dust outputs; the 1k change outputs it is generating are getting used, and the size of the UTxO is perfectly stable. Indeed, back in Figure 12 we can see that the size of the UTxO tracks the balance perfectly; moreover, the vast majority of transactions only use a single input, which is what we'd expect for a 10:0 deposit:payment ratio.

Tuy nhiên, thuật toán không tạo ra đầu ra bụi;
Đầu ra thay đổi 1K mà nó đang tạo ra đang được sử dụng và kích thước của UTXO hoàn toàn ổn định.
Thật vậy, trở lại trong Hình 12, chúng ta có thể thấy rằng kích thước của UTXO theo dõi sự cân bằng một cách hoàn hảo;
Hơn nữa, phần lớn các giao dịch chỉ sử dụng một đầu vào duy nhất, đó là những gì chúng tôi mong đợi cho khoản tiền gửi 10: 0: Tỷ lệ thanh toán.

### **Real data**

### ** Dữ liệu thực **

#### **MoneyPot.com**

#### ** Moneypot.com **

Ideally, of course, we run the simulation against real event streams from existing wallets. Unfortunately, such data is hard to come by. Erhardt was able to find one such dataset, provided by [MoneyPot.com](https://www.moneypot.com/ "MoneyPot.com"). When we run our algorithm on this dataset we get

Lý tưởng nhất, tất nhiên, chúng tôi chạy mô phỏng chống lại các luồng sự kiện thực từ ví hiện có.
Thật không may, dữ liệu như vậy là khó có thể đến.
Erhardt đã có thể tìm thấy một bộ dữ liệu như vậy, được cung cấp bởi [moneypot.com] (https://www.moneypot.com/ "MoneyPot.com").
Khi chúng tôi chạy thuật toán của chúng tôi trên bộ dữ liệu này, chúng tôi nhận được

![Figure 12](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 12-2](img/2018-07-03-self-organisation-in-coin-selection.011.png) 

**Figure 12.** Random-Improve, using the MoneyPot data set. There is a rougly 2:1 deposit:payment ratio. Values have been scaled. NOTE: log scale on the x-axis.

** Hình 12. ** Ăn kèm ngẫu nhiên, sử dụng bộ dữ liệu MoneyPot.
Có một khoản tiền gửi 2: 1: Tỷ lệ thanh toán.
Các giá trị đã được chia tỷ lệ.
LƯU Ý: Thang nhật ký trên trục x.

A few observations are in order here. First, there are quite a few deposits and payments close to 0, just like in an exponential distribution. Moreover, although we have many values close to 0, we also have some huge outliers; the payments are closely clustered together, but there is a 10xE9 difference between the smallest and largest deposit, and moreover a 10xE5 difference between the largest deposit and the largest payment. It is therefore not surprising that we end up with a relatively large change:payment ratio. Nonetheless, the algorithm is behaving well, with the size of the UTxO tracking the balance nicely, with an average UTxO size of 130 entries. The average number of outputs is 3.03, with 50% of transactions using just one input, and 90% using 6 or fewer.

Một vài quan sát là theo thứ tự ở đây.
Đầu tiên, có khá nhiều tiền gửi và thanh toán gần 0, giống như trong phân phối theo cấp số nhân.
Hơn nữa, mặc dù chúng tôi có nhiều giá trị gần với 0, chúng tôi cũng có một số ngoại lệ lớn;
Các khoản thanh toán được tập hợp chặt chẽ với nhau, nhưng có sự khác biệt 10XE9 giữa khoản tiền gửi nhỏ nhất và lớn nhất, và hơn nữa là sự khác biệt 10XE5 giữa khoản tiền gửi lớn nhất và khoản thanh toán lớn nhất.
Do đó, không có gì đáng ngạc nhiên khi chúng tôi kết thúc với một thay đổi tương đối lớn: tỷ lệ thanh toán.
Tuy nhiên, thuật toán đang hoạt động tốt, với kích thước của UTXO theo dõi số dư một cách độc đáo, với kích thước UTXO trung bình là 130 mục.
Số lượng đầu ra trung bình là 3,03, với 50% giao dịch chỉ sử dụng một đầu vào và 90% sử dụng 6 hoặc ít hơn.

#### **Cardano Exchange**

#### ** Trao đổi Cardano **

One of the large Cardano exchange nodes has also helped us with some anonymised data (deposits and payments), similar in nature to the MoneyPot dataset albeit significantly larger. Coming from an exchange node, however, this dataset is very much skewed towards deposits, with a deposit:payment ratio of roughly 30:1. Under these circumstances, of course, coin selection alone cannot keep the UTxO size small.

Một trong những nút trao đổi Cardano lớn cũng đã giúp chúng tôi với một số dữ liệu ẩn danh (tiền gửi và thanh toán), tương tự về bản chất với bộ dữ liệu MoneyPot lớn hơn đáng kể.
Tuy nhiên, đến từ một nút trao đổi, bộ dữ liệu này bị sai lệch rất nhiều đối với tiền gửi, với một khoản tiền gửi: tỷ lệ thanh toán khoảng 30: 1.
Trong những trường hợp này, tất nhiên, việc lựa chọn tiền xu một mình không thể giữ cho kích thước UTXO nhỏ.

![Figure 13](img/2018-07-03-self-organisation-in-coin-selection.009.png) ![Figure 13-2](img/2018-07-03-self-organisation-in-coin-selection.011.png) 

**Figure 13.** Random-Improve, using data set from a large Cardano exchange. There is a rougly 30:1 deposit:payment ratio. Values have been scaled. NOTE: log scale on the x-axis.

** Hình 13. ** Ăn kèm ngẫu nhiên, sử dụng tập dữ liệu từ một trao đổi Cardano lớn.
Có một khoản tiền gửi 30: 1: Tỷ lệ thanh toán.
Các giá trị đã được chia tỷ lệ.
LƯU Ý: Thang nhật ký trên trục x.

## **Conclusions**

## ** Kết luận **

The choice of coin selection algorithm has far reaching consequences on the long term behaviour of a cryptocurrency wallet. To a large extent the coin selection algorithm determines, over time, the shape of the UTxO. Moreover, the performance of the algorithm can be of crucial importance to high-traffic wallets such as exchange nodes.

Việc lựa chọn thuật toán lựa chọn tiền xu có hậu quả tiếp cận sâu rộng đối với hành vi lâu dài của ví tiền điện tử.
Ở một mức độ lớn, thuật toán lựa chọn đồng xu xác định, theo thời gian, hình dạng của UTXO.
Hơn nữa, hiệu suất của thuật toán có thể có tầm quan trọng quan trọng đối với các ví có lưu lượng truy cập cao như các nút trao đổi.

In his thesis, Erhardt proposes "Branch and Bound" as his preferred coin selection algorithm. Branch and Bound in essence is a limited backtracking algorithm that tries to find an exact match, so that no change output needs to be generated at all. When the backtracking cannot find an exact match within its bounds, the algorithm then falls back on random selection. It does not, however, attempt our "improvement" step, and instead just attempts to reach a minimum but fixed change size, to avoid generating dust. It is hard to compare the two algorithms directly, but on the MoneyPot dataset at least the results are comparable; Erhardt ends up with a slightly smaller average UTxO (109 versus our 130), and a slightly smaller average number of inputs (2.7 versus our 3.0). In principle we could modify our Random-Improve algorithm to start with bounded backtracking to find an exact match, just like Erhardt does; we have not done this however because it adds complexity to the algorithm and reduces performance. Erhardt reports that his algorithm is able to find exact matches in 30% of the time. This is very high, and at least partly explains why his UTxO and average number of change outputs is lower; in the Cardano blockchain, we would not expect that there exist exact matches anywhere near that often (never mind finding them).

Trong luận án của mình, Erhardt đề xuất "chi nhánh và ràng buộc" là thuật toán lựa chọn đồng tiền ưa thích của ông. Chi nhánh và ràng buộc về bản chất là một thuật toán quay lại giới hạn, cố gắng tìm một trận đấu chính xác, do đó không cần phải tạo ra đầu ra thay đổi. Khi việc quay lại không thể tìm thấy một khớp chính xác trong giới hạn của nó, thuật toán sau đó rơi trở lại với lựa chọn ngẫu nhiên. Tuy nhiên, nó không cố gắng bước "cải tiến" của chúng tôi và thay vào đó chỉ cố gắng đạt được kích thước thay đổi tối thiểu nhưng cố định, để tránh tạo ra bụi. Thật khó để so sánh trực tiếp hai thuật toán, nhưng trên bộ dữ liệu MoneyPot ít nhất là kết quả có thể so sánh được; Erhardt kết thúc với UTXO trung bình nhỏ hơn một chút (109 so với 130 của chúng tôi) và số lượng đầu vào trung bình nhỏ hơn một chút (2.7 so với 3.0 của chúng tôi). Về nguyên tắc, chúng tôi có thể sửa đổi thuật toán cải tiến ngẫu nhiên của chúng tôi để bắt đầu với việc quay lại giới hạn để tìm một trận đấu chính xác, giống như Erhardt; Tuy nhiên, chúng tôi đã không thực hiện điều này vì nó thêm sự phức tạp cho thuật toán và giảm hiệu suất. Erhardt báo cáo rằng thuật toán của ông có thể tìm thấy các trận đấu chính xác trong 30% thời gian. Điều này rất cao, và ít nhất một phần giải thích tại sao UTXO của anh ấy và số lượng đầu ra thay đổi trung bình của anh ấy thấp hơn; Trong blockchain Cardano, chúng tôi sẽ không hy vọng rằng tồn tại các kết quả chính xác ở bất cứ đâu gần đó (không bao giờ bận tâm đến việc tìm kiếm chúng).

Instead our proposed Random-Improve does no search at all, instead purely relying on self organisation principles, the first of which was stated by Erhardt, and the other two we identified as part of this research. Although in the absence of more real data it is hard to evaluate any coin selection algorithm, we have shown that the algorithm performs well across a large variety of different distributions and deposit:payment ratios. Moreover it is straight-forward to implement and has high performance.

Thay vào đó, tác động ngẫu nhiên được đề xuất của chúng tôi không tìm kiếm nào cả, thay vào đó hoàn toàn dựa vào các nguyên tắc tự tổ chức, trong số đó được Erhardt tuyên bố và hai điều còn lại mà chúng tôi xác định là một phần của nghiên cứu này.
Mặc dù trong trường hợp không có dữ liệu thực hơn, thật khó để đánh giá bất kỳ thuật toán lựa chọn tiền xu nào, chúng tôi đã chỉ ra rằng thuật toán thực hiện tốt trên nhiều loại phân phối và tiền gửi khác nhau: tỷ lệ thanh toán.
Hơn nữa, nó là thẳng để thực hiện và có hiệu suất cao.

One improvement we may wish to consider is that when there are very large deposits, we could occassionally issue a "reorganisation transaction" that splits those large deposits into smaller chunks. This would bring the change:payment ratio down, which would improve the evolution of the UTxO over time and is beneficial also for other, more technical reasons (it reduces the need for what we call "dependent transactions" in the [wallet specification](https://cardanodocs.com/technical/formal-specification-for-a-cardano-wallet/ "Formal specification for a Cardano wallet, cardanodocs.com")). Such reorganisation is largely orthogonal to this algorithm, however, and can be implemented independently.

Một cải tiến mà chúng tôi có thể muốn xem xét là khi có các khoản tiền gửi rất lớn, chúng tôi có thể phát hành một "giao dịch tái tổ chức" một cách thường xuyên, chia các khoản tiền gửi lớn đó thành các khối nhỏ hơn.
Điều này sẽ làm giảm sự thay đổi: Tỷ lệ thanh toán xuống, điều này sẽ cải thiện sự phát triển của UTXO theo thời gian và cũng có lợi cho các lý do kỹ thuật khác, khác (nó làm giảm nhu cầu về những gì chúng ta gọi là "giao dịch phụ thuộc" trong [Đặc điểm kỹ thuật ví] (
https://cardanodocs.com/technical/formal-specification-for-a-cardano-wallet/ "Thông số kỹ thuật chính thức cho ví Cardano, cardanodocs.com")).
Tuy nhiên, việc tái tổ chức như vậy phần lớn là trực giao với thuật toán này và có thể được thực hiện độc lập.

