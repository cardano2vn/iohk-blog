# Functional correctness with the Haskell masters
### **Training to build quality code on scientific excellence**
![](img/2018-09-26-functional-correctness-with-the-haskell-master.002.png) 26 September 2018![](img/2018-09-26-functional-correctness-with-the-haskell-master.002.png)[ Lars Brünjes](tmp//en/blog/authors/lars-brunjes/page-1/)![](img/2018-09-26-functional-correctness-with-the-haskell-master.003.png) 6 mins read

![Lars Brünjes](img/2018-09-26-functional-correctness-with-the-haskell-master.004.png)[](tmp//en/blog/authors/lars-brunjes/page-1/)
### [**Lars Brünjes**](tmp//en/blog/authors/lars-brunjes/page-1/)
Education Director

Education

- ![](img/2018-09-26-functional-correctness-with-the-haskell-master.005.png)[](mailto:lars.bruenjes@iohk.io "Email")
- ![](img/2018-09-26-functional-correctness-with-the-haskell-master.006.png)[](https://www.linkedin.com/in/dr-lars-br%C3%BCnjes-1640993b "LinkedIn")
- ![](img/2018-09-26-functional-correctness-with-the-haskell-master.007.png)[](https://twitter.com/LarsBrunjes "Twitter")
- ![](img/2018-09-26-functional-correctness-with-the-haskell-master.008.png)[](https://github.com/brunjlar "GitHub")

![Functional correctness with the Haskell masters](img/2018-09-26-functional-correctness-with-the-haskell-master.009.jpeg)

At IOHK, we are proud of our scientific approach and close collaboration with academia. We publish in peer reviewed scientific journals and present our results at acclaimed international conferences to ensure that our protocols and algorithms are built on rock-solid foundations. Our software must reflect this scientific excellence and quality, which means that we need a process to go from scientific results to actual code written in the Haskell programming language. We therefore decided to run internal training on “functional correctness”, so that the quality of our theoretical foundations can translate into equal quality for our code. We ran the first course over four days in Regensburg, Germany, two weeks ago. This training is aimed at everybody writing Haskell at IOHK, so we decided to run four sessions, roughly based on geography – there are IOHK engineers in 16 countries. We plan to do a second session in Regensburg in November and then two more early next year in the US. The lecturers were Andres Löh, co-founder of the Well-Typed consultancy, and John Hughes, the founder of [QuviQ](http://www.quviq.com/ "quiq.com"), who are both prominent in the Haskell world.

Tại IOHK, chúng tôi tự hào về cách tiếp cận khoa học và hợp tác chặt chẽ với học viện. Chúng tôi xuất bản trên các tạp chí khoa học được đánh giá ngang hàng và trình bày kết quả của chúng tôi tại các hội nghị quốc tế được hoan nghênh để đảm bảo rằng các giao thức và thuật toán của chúng tôi được xây dựng trên các nền tảng vững chắc. Phần mềm của chúng tôi phải phản ánh sự xuất sắc và chất lượng khoa học này, điều đó có nghĩa là chúng tôi cần một quy trình để đi từ kết quả khoa học sang mã thực tế được viết bằng ngôn ngữ lập trình Haskell. Do đó, chúng tôi đã quyết định chạy đào tạo nội bộ về tính chính xác của chức năng, để chất lượng của các nền tảng lý thuyết của chúng tôi có thể chuyển thành chất lượng như nhau cho mã của chúng tôi. Chúng tôi đã chạy khóa học đầu tiên trong bốn ngày ở Regensburg, Đức, hai tuần trước. Việc đào tạo này nhằm vào tất cả mọi người viết Haskell tại IOHK, vì vậy chúng tôi quyết định chạy bốn phiên, gần như dựa trên địa lý - có các kỹ sư IOHK ở 16 quốc gia. Chúng tôi dự định sẽ thực hiện một phiên thứ hai tại Regensburg vào tháng 11 và sau đó hai lần nữa vào đầu năm tới tại Mỹ. Các giảng viên là Andres Löh, đồng sáng lập của chuyên gia tư vấn được đánh giá cao và John Hughes, người sáng lập [Quviq] (http://www.quviq.com/ "Quiq.com"), cả hai đều nổi bật trong The Thế giới Haskell.

John is one of the creators of Haskell and the co-inventor of [QuickCheck](http://hackage.haskell.org/package/QuickCheck "hackage.haskell.org/package/QuickCheck"), the Haskell testing tool. Most mainstream software companies (if they do testing at all, which, sadly, is not always the case), use unit tests. For this, developers write down a number of tests by hand, cases that they deem typical or relevant or interesting, and then use a unit test framework to run the tests and report whether they yield the expected results. QuickCheck is different. Instead of specifying a handful of tests, developers using QuickCheck state the properties that their code should have. QuickCheck then generates many random test cases and checks the property for each of these. If QuickCheck finds that a property is violated, it first tries to simplify the test, then reports the simplest failing case back to the user.

John là một trong những người tạo ra Haskell và người đồng phát minh của [QuickCheck] (http://hackage.haskell.org/package/quickcheck "hackage.haskell.org/package/quickcheck"), công cụ kiểm tra Haskell.
Hầu hết các công ty phần mềm chính thống (nếu họ thực hiện thử nghiệm, điều đáng buồn là không phải lúc nào cũng như vậy), hãy sử dụng các bài kiểm tra đơn vị.
Đối với điều này, các nhà phát triển viết ra một số thử nghiệm bằng tay, các trường hợp mà họ cho là điển hình hoặc có liên quan hoặc thú vị, sau đó sử dụng khung kiểm tra đơn vị để chạy các bài kiểm tra và báo cáo xem họ có mang lại kết quả dự kiến hay không.
QuickCheck là khác nhau.
Thay vì chỉ định một số ít các thử nghiệm, các nhà phát triển sử dụng QuickCheck nêu các thuộc tính mà mã của họ nên có.
QuickCheck sau đó tạo ra nhiều trường hợp thử nghiệm ngẫu nhiên và kiểm tra thuộc tính cho từng trường hợp này.
Nếu QuickCheck thấy rằng một tài sản bị vi phạm, trước tiên nó sẽ cố gắng đơn giản hóa bài kiểm tra, sau đó báo cáo trường hợp thất bại đơn giản nhất cho người dùng.

![Learning in Regensburg](img/2018-09-26-functional-correctness-with-the-haskell-master.010.jpeg) 

Haskell students in class

Học sinh Haskell trong lớp

As a simple example, let’s say you wrote a program to sort a list of names. Using unit tests, you would check the program against a few handcrafted examples of lists of names (something like "Tom", "Dick", "Harry" and "Dora", "Caesar", "Berta", "Anton" ). With QuickCheck, on the other hand, you would sit down and carefully think about properties your program should have In the example of sorting lists of names, what properties would you expect? Well, after running the program, you should get a list that is sorted alphabetically. Oh, and that list should contain all the names you entered. And yes, it should only contain those names you entered. You can write down these properties as Haskell programs, then hand them over to QuickCheck. The tool checks your properties against as many randomly generated lists of names as you wish (usually hundreds or thousands) and identifies any violations.

Ví dụ đơn giản, hãy để nói rằng bạn đã viết một chương trình để sắp xếp một danh sách các tên.
Sử dụng các bài kiểm tra đơn vị, bạn sẽ kiểm tra chương trình dựa trên một vài ví dụ về danh sách các tên (một cái gì đó như "Tom", "Dick", "Harry" và "Dora", "Caesar", "Berta", "Anton").
Mặt khác, với QuickCheck, bạn sẽ ngồi xuống và suy nghĩ cẩn thận về các thuộc tính mà chương trình của bạn nên có trong ví dụ về việc sắp xếp các danh sách tên, bạn sẽ mong đợi những thuộc tính nào?
Chà, sau khi chạy chương trình, bạn sẽ nhận được một danh sách được sắp xếp theo thứ tự bảng chữ cái.
Ồ, và danh sách đó phải chứa tất cả các tên bạn đã nhập.
Và vâng, nó chỉ nên chứa những cái tên bạn đã nhập.
Bạn có thể viết ra các thuộc tính này như các chương trình Haskell, sau đó trao chúng cho QuickCheck.
Công cụ kiểm tra các thuộc tính của bạn đối với nhiều danh sách tên được tạo ngẫu nhiên như bạn muốn (thường là hàng trăm hoặc hàng ngàn) và xác định bất kỳ vi phạm nào.

In practice, QuickCheck often manages to find problems that are overlooked by less rigorous methods, because their authors tend to overlook obscure cases and complicated scenarios. In our example, they may, for example, forget to test an empty list of names. Or there may be a bug in the program that only occurs for long lists of names, and their unit tests only check short lists. John had many ‘war stories’ of this happening in real life with real customers, where bugs were only revealed after a series of complex interleaved operations that no human unit test writer would have imagined. 

Trong thực tế, QuickCheck thường quản lý để tìm ra các vấn đề bị bỏ qua bởi các phương pháp ít nghiêm ngặt hơn, bởi vì các tác giả của họ có xu hướng bỏ qua các trường hợp tối nghĩa và các kịch bản phức tạp.
Trong ví dụ của chúng tôi, ví dụ, họ có thể quên kiểm tra một danh sách tên trống.
Hoặc có thể có một lỗi trong chương trình chỉ xảy ra cho danh sách dài các tên và các bài kiểm tra đơn vị của họ chỉ kiểm tra danh sách ngắn.
John đã có nhiều câu chuyện chiến tranh về điều này xảy ra trong cuộc sống thực với các khách hàng thực sự, nơi các lỗi chỉ được tiết lộ sau một loạt các hoạt động xen kẽ phức tạp mà không có người viết thử nghiệm đơn vị nào của con người sẽ tưởng tượng.

Every Haskell developer has heard of QuickCheck and understands the basic ideas, but in complex real-world programs like Cardano, it is sometimes not so easy to use the tool properly. It was therefore great to have the intricacies and finer points explained by John himself, who has been using QuickCheck for 20 years and has worked with many industries, including web services (Riak, Dropbox and LevelDB), chat servers (Ejabberd), online purchasing (Dets), automotive (Autosar specification), and telecommunications (MediaProxy, Ericsson and Motorola). He helps find bugs and guarantee correctness every day. Given John’s experience, the training participants were able to spend about half of their time learning the finer points of QuickCheck from the master himself. It was tremendous fun enjoying John’s obvious enthusiasm for, and deep knowledge of, the subject. The rest of the session was dedicated to understanding the link between formal specifications, written in a mathematical style, and Haskell implementations.

Mọi nhà phát triển Haskell đã nghe nói về QuickCheck và hiểu các ý tưởng cơ bản, nhưng trong các chương trình thực tế phức tạp như Cardano, đôi khi không dễ sử dụng công cụ đúng cách. Do đó, thật tuyệt vời khi có những điều phức tạp và điểm tốt hơn được giải thích bởi chính John, người đã sử dụng QuickCheck trong 20 năm và đã làm việc với nhiều ngành công nghiệp, bao gồm các dịch vụ web (Riak, Dropbox và LevelDB), máy chủ trò chuyện (EJABBERD), mua hàng trực tuyến (DETS), ô tô (đặc điểm kỹ thuật tự động) và viễn thông (MediaProxy, Ericsson và Motorola). Anh ấy giúp tìm lỗi và đảm bảo sự đúng đắn mỗi ngày. Với kinh nghiệm của John, những người tham gia đào tạo đã có thể dành khoảng một nửa thời gian của họ để học những điểm tốt hơn của QuickCheck từ chính Master. Đó là niềm vui to lớn khi tận hưởng sự nhiệt tình rõ ràng của John, và kiến thức sâu sắc về chủ đề này. Phần còn lại của phiên được dành riêng để hiểu liên kết giữa các thông số kỹ thuật chính thức, được viết theo phong cách toán học và triển khai Haskell.

![Exploring Regensburg](img/2018-09-26-functional-correctness-with-the-haskell-master.010.jpeg) 

IOHK in Regensburg

IOHK ở Regensburg

At IOHK, we work very hard on writing correct code. For example, we specify program behavior and properties using rigorous mathematics. In the end, of course, we can’t deploy mathematics to a computer. Instead, our developers have to take the specification, translate the mathematics into Haskell and produce executable, efficient code. This process is easier for Haskell, because it is firmly rooted in mathematical principles, than for most languages, but it is still a conceptual leap. The specification talks about mathematical objects like sets and relations, which have to be translated into data types and functions as faithfully as possible. Nobody wins if your beautiful mathematics is ‘lost in translation’ and you end up with bug-ridden code. For example, when mathematicians talk about integers (..., −2, −1, 0, 1, 2,...) or real numbers (such as π, and √2), how do you express this in Haskell? There are data types like Int or Double that seem related, but they are not the same as the mathematical concepts they were inspired by. For example, a computer Int can overflow, and a Double can have rounding errors. It is important to understand such limitations when translating from mathematics to code. This is where the mathematician and renowned Haskell expert Andres Löh came in. He taught the participants how to read mathematical notation, how mathematical concepts relate to Haskell and how to translate from the one to the other.

Tại IOHK, chúng tôi làm việc rất chăm chỉ để viết mã chính xác. Ví dụ, chúng tôi chỉ định hành vi và thuộc tính của chương trình bằng toán học nghiêm ngặt. Cuối cùng, tất nhiên, chúng ta có thể triển khai toán học cho máy tính. Thay vào đó, các nhà phát triển của chúng tôi phải lấy đặc điểm kỹ thuật, dịch toán học thành Haskell và sản xuất mã hiệu quả, có thể thực thi. Quá trình này dễ dàng hơn đối với Haskell, bởi vì nó bắt nguồn từ các nguyên tắc toán học, hơn là đối với hầu hết các ngôn ngữ, nhưng nó vẫn là một bước nhảy vọt về khái niệm. Thông số kỹ thuật nói về các đối tượng toán học như tập hợp và quan hệ, phải được dịch thành các loại dữ liệu và chức năng trung thành nhất có thể. Không ai thắng nếu toán học xinh đẹp của bạn bị mất trong bản dịch và bạn kết thúc với mã lỗi. Ví dụ, khi các nhà toán học nói về số nguyên (..., −2, 1, 0, 1, 2, ...) hoặc số thực (chẳng hạn như π và √2), làm thế nào để bạn thể hiện điều này trong Haskell? Có những loại dữ liệu như INT hoặc Double có vẻ liên quan, nhưng chúng không giống như các khái niệm toán học mà chúng được truyền cảm hứng. Ví dụ, một máy tính Int có thể tràn và gấp đôi có thể có lỗi làm tròn. Điều quan trọng là phải hiểu những hạn chế như vậy khi dịch từ toán sang mã. Đây là nơi mà chuyên gia Haskell nổi tiếng và nhà toán học Andres Löh đến. Ông đã dạy những người tham gia cách đọc ký hiệu toán học, cách các khái niệm toán học liên quan đến Haskell và cách dịch từ cái này sang cái khác.

For example, Andres presented the first pages of our formal blockchain specification and talked the participants through understanding and implementing this piece of mathematics as simple (and correct!) Haskell code, which led to interesting questions and lively discussions: How do you represent hashing and other cryptographic primitives? What level of detail do you need? Is it more important to stay as faithful to the mathematics as possible or to write efficient code? When should you sacrifice mathematical precision for simplicity? 

Ví dụ, Andres đã trình bày các trang đầu tiên của đặc tả blockchain chính thức của chúng tôi và nói chuyện với những người tham gia thông qua việc hiểu và thực hiện phần toán học này là đơn giản (và chính xác!)
Các nguyên thủy mã hóa khác?
Bạn cần mức độ chi tiết nào?
Có quan trọng hơn là giữ trung thành với toán học nhất có thể hoặc viết mã hiệu quả?
Khi nào bạn nên hy sinh độ chính xác toán học cho sự đơn giản?

In addition to their great lectures, John and Andres also provided challenging practical exercises, where participants could immediately apply their newly-gained knowledge about testing and specifications. Finally, there was plenty of opportunity for discussions, questions and socializing. Regensburg is a beautiful town, founded by the Romans two thousand years ago and a Unesco World Heritage Site. The city offered participants a perfect setting to relax after the training, continuing their discussions while exploring the medieval architecture or sitting down for some excellent Bavarian food and beer.

Ngoài các bài giảng tuyệt vời của họ, John và Andres cũng cung cấp các bài tập thực tế đầy thách thức, nơi những người tham gia có thể ngay lập tức áp dụng kiến thức mới có lợi của họ về thử nghiệm và thông số kỹ thuật.
Cuối cùng, có rất nhiều cơ hội cho các cuộc thảo luận, câu hỏi và xã hội hóa.
Regensburg là một thị trấn xinh đẹp, được thành lập bởi người La Mã hai ngàn năm trước và là một di sản thế giới của UNESCO.
Thành phố cung cấp cho những người tham gia một khung cảnh hoàn hảo để thư giãn sau khi đào tạo, tiếp tục các cuộc thảo luận của họ trong khi khám phá kiến trúc thời trung cổ hoặc ngồi xuống cho một số thực phẩm và bia Bavaria tuyệt vời.

Artwork, [](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

Tác phẩm nghệ thuật, [] (https://creativecommons.org/licenses/by/4.0/ "Creative Commons")

![Creative Commons](img/2018-09-26-functional-correctness-with-the-haskell-master.011.png)[](https://creativecommons.org/licenses/by/4.0/ "Creative Commons")[](http://www.beeple-crap.com)

[Mike Beeple](http://www.beeple-crap.com)

[Mike Beeple] (http://www.beeple-crap.com)

