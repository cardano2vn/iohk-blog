# Native tokens on Cardano; core principles and points of difference
### **In yesterday’s post, we looked at the purpose and value of tokens on Cardano. Here, we dig deeper into the four principles guiding our approach, and the key advantages**
![](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.002.png) 9 December 2020![](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.002.png)[ Polina Vinogradova](tmp//en/blog/authors/polina-vinogradova/page-1/)![](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.003.png) 5 mins read

![Polina Vinogradova](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.004.png)[](tmp//en/blog/authors/polina-vinogradova/page-1/)
### [**Polina Vinogradova**](tmp//en/blog/authors/polina-vinogradova/page-1/)
Research Engineer

Engineering

- ![](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.005.png)[](mailto:polina.vinogradova@iohk.io "Email")
- ![](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.006.png)[](https://ca.linkedin.com/in/polina-vinogradova-62105713b "LinkedIn")
- ![](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.007.png)[](https://twitter.com/polinavinovino "Twitter")
- ![](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.008.png)[](https://github.com/polinavino "GitHub")

![Native tokens on Cardano; core principles and points of difference](img/2020-12-09-native-tokens-on-cardano-core-principles-and-points-of-difference.009.jpeg)

Your browser does not support the audio element.

Trình duyệt của bạn không hỗ trợ các yếu tố âm thanh.

Ethereum, custom (user-defined) tokens are implemented using smart contracts to simulate the transfer of custom assets. [Our approach with Cardano](https://iohk.io/en/blog/posts/2020/12/08/native-tokens-on-cardano/) does not require smart contracts, because the ledger itself supports the accounting of non-ada native assets. 

Các mã thông báo Ethereum, tùy chỉnh (do người dùng xác định) được triển khai bằng cách sử dụng các hợp đồng thông minh để mô phỏng việc chuyển giao tài sản tùy chỉnh.
[Cách tiếp cận của chúng tôi với Cardano] (https://iohk.io/en/blog/posts/2020/12/08/native-tokens-on-cardano/) không yêu cầu hợp đồng thông minh, bởi vì bản thân sổ cái hỗ trợ kế toán của kế toán cho việc kế toán của kế toán cho việc kế toán của kế toán cho việc kế toán của kế toán cho kế toán của kế toán cho kế toán của
Tài sản bản địa không phải là ADA.

Another difference is that Cardano’s multi-asset ledger supports both fungible and unique, non-fungible tokens without specialized contracts (similar to those required by ERC-20 and ERC-721 tokens). It can store a mix of both fungible and non-fungible tokens in a single output. 

Một điểm khác biệt khác là sổ cái đa tài sản của Cardano, hỗ trợ cả các mã thông báo có thể gây nấm và độc đáo, không thể bỏ qua mà không có hợp đồng chuyên dụng (tương tự như các mã thông báo được yêu cầu bởi các mã thông báo ERC-20 và ERC-721).
Nó có thể lưu trữ một hỗn hợp của cả hai mã thông báo nấm và không bị nấm trong một đầu ra.

Cardano’s native tokens framework is based on four principles:

Khung mã thông báo gốc Cardano sườn dựa trên bốn nguyên tắc:

- lightweight

- Nhẹ

- affordability

- Khả năng chi trả

- security

- Bảo vệ

- unified process

- Quá trình thống nhất

**Lightweight**

** Nhẹ **

The native token framework is based on a multi-asset ledger structure built around token bundles (values), A token bundle can contain a heterogeneous mix of ada and other tokens. These token-containing structures are stored in outputs on the ledger instead of ada, as previously. Each type of token is identified by its asset ID, which includes a hash reference to its minting policy. The minting policy itself is only ever checked during minting or burning, and is not itself stored on the ledger, which makes this approach quite lightweight.

Khung mã thông báo gốc dựa trên cấu trúc sổ cái đa tài sản được xây dựng xung quanh các gói mã thông báo (giá trị), một gói mã thông báo có thể chứa hỗn hợp không đồng nhất của ADA và các mã thông báo khác.
Các cấu trúc chứa mã thông báo này được lưu trữ trong các đầu ra trên sổ cái thay vì ADA, như trước đây.
Mỗi loại mã thông báo được xác định bởi ID tài sản của nó, bao gồm một tham chiếu băm về chính sách khai thác của nó.
Chính sách khai thác chỉ được kiểm tra trong quá trình khai thác hoặc đốt, và không được lưu trữ trên sổ cái, điều này làm cho phương pháp này khá nhẹ.

The fungibility relationship is also captured by the asset ID in a lightweight way: tokens with the same asset ID are fungible with each other, but not fungible with those with a different asset ID. Unique tokens have a quantity of exactly 1 associated with their asset ID. 

Mối quan hệ về khả năng nấm cũng được ghi nhận bởi ID tài sản theo cách nhẹ: mã thông báo có cùng ID tài sản là nấm với nhau, nhưng không phải là nấm với những người có ID tài sản khác.
Các token duy nhất có số lượng chính xác 1 liên quan đến ID tài sản của họ.

The asset ID identifies each type of token within a single token bundle and across the whole ledger. It also identifies the token’s place in the internal two-level map structure of the token bundle. This internal data structure enables fungible and non-fungible tokens to be represented uniformly. It also gives great flexibility to the kinds of asset use cases that can be tokenized in the system. It is straightforward to represent, for example, timeshares of a single piece of property, or a selection of unique pieces of art scoped under a single minting policy controlled by the artist. 

ID tài sản xác định từng loại mã thông báo trong một gói mã thông báo duy nhất và trên toàn bộ sổ cái.
Nó cũng xác định vị trí mã thông báo trong cấu trúc bản đồ hai cấp bên trong của gói mã thông báo.
Cấu trúc dữ liệu bên trong này cho phép các mã thông báo nấm và không bị nấm được biểu diễn đồng đều.
Nó cũng mang lại sự linh hoạt tuyệt vời cho các loại trường hợp sử dụng tài sản có thể được mã hóa trong hệ thống.
Nó rất đơn giản để đại diện, ví dụ, thời gian của một phần tài sản duy nhất hoặc một lựa chọn các tác phẩm nghệ thuật độc đáo được sử dụng theo một chính sách khai thác duy nhất do nghệ sĩ kiểm soát.

The inherent simplicity of native tokens is further highlighted when we look at how transferring assets between two contracts works in Ethereum’s ERC-20. In this situation, smart contract code is required, which adds complexity, and with it room for error and cost. The structure of token bundles offers a rather lightweight approach to asset transfer, because different types of token can be transacted in a single transaction, with greater speed.

Sự đơn giản vốn có của các mã thông báo gốc được nhấn mạnh thêm khi chúng ta xem xét cách chuyển tài sản giữa hai hợp đồng hoạt động trong Ethereum tựa ERC-20.
Trong tình huống này, mã hợp đồng thông minh là bắt buộc, làm tăng thêm độ phức tạp và với nó có chỗ cho lỗi và chi phí.
Cấu trúc của các gói mã thông báo cung cấp một cách tiếp cận khá nhẹ để chuyển tài sản, bởi vì các loại mã thông báo khác nhau có thể được giao dịch trong một giao dịch duy nhất, với tốc độ lớn hơn.

**Affordability**

** Khả năng chi trả **

In an ERC-20 token environment, transferring any number of tokens between two peers requires the execution of a smart contract, which carries an execution fee (gas). By contrast, in Cardano’s native multi-asset ecosystem, the transfer of assets (tokens, ada, custom currencies, etc) does not require a smart contract, and does not carry any execution fee, which means greater affordability.

Trong môi trường mã thông báo ERC-20, việc chuyển bất kỳ số lượng mã thông báo nào giữa hai đồng nghiệp đòi hỏi phải thực hiện hợp đồng thông minh, mang phí thực hiện (GAS).
Ngược lại, trong hệ sinh thái đa tài sản bản địa của Cardano, việc chuyển tài sản (mã thông báo, ADA, tiền tệ tùy chỉnh, v.v.) không yêu cầu hợp đồng thông minh và không mang bất kỳ phí thực hiện nào, có nghĩa là khả năng chi trả lớn hơn.

**Security**

**Bảo vệ**

Native tokens feature a more lightweight and less costly design than that of Ethereum’s ERC-20 and ERC-721 standards. But these two features would mean nothing without a robust security layer to guarantee the integrity of the system.

Các mã thông báo gốc có thiết kế nhẹ hơn và ít tốn kém hơn so với các tiêu chuẩn EthereumTHER ERC-20 và ERC-721.
Nhưng hai tính năng này sẽ không có nghĩa gì nếu không có lớp bảo mật mạnh mẽ để đảm bảo tính toàn vẹn của hệ thống.

In native tokens, system integrity is built around the ledger property of value preservation (that is, that the sum of all the inputs is equal to the sum of the outputs). All native token transfer logic is coded in the ledger, as opposed to user-defined smart contracts. This ensures predictable and uniform behaviour of the system, and does not require users to understand smart contracts, which can often be a point of vulnerability. 

Trong các mã thông báo gốc, tính toàn vẹn của hệ thống được xây dựng xung quanh thuộc tính sổ cái của bảo quản giá trị (nghĩa là tổng của tất cả các đầu vào bằng tổng của các đầu ra).
Tất cả logic chuyển mã thông báo gốc được mã hóa trong sổ cái, trái ngược với các hợp đồng thông minh do người dùng xác định.
Điều này đảm bảo hành vi có thể dự đoán và thống nhất của hệ thống và không yêu cầu người dùng hiểu các hợp đồng thông minh, thường có thể là một điểm dễ bị tổn thương.

While accounting correctness is ensured by the ledger, minting and burning of tokens is regulated by their user-defined minting policies. A minting policy is permanently hash-associated to the tokens scoped under it, and there is no way to change this policy. This guarantees that the policy an issuer chose can never be changed to allow minting or burning of this type of token which was not authorized under the original policy. Whenever a minting transaction is added to the ledger, the policy for each type of token being minted is checked and must be satisfied. Each token in circulation, except ada (as Cardano forbids minting additional ada), necessarily has a minting policy and is guaranteed to have been minted according to that policy. 

Mặc dù tính đúng kế toán được đảm bảo bởi sổ cái, việc khai thác và đốt mã thông báo được quy định bởi các chính sách khai thác do người dùng xác định.
Một chính sách khai thác được liên kết với băm vĩnh viễn cho các mã thông báo theo phạm vi theo nó, và không có cách nào để thay đổi chính sách này.
Điều này đảm bảo rằng chính sách mà một nhà phát hành đã chọn không bao giờ có thể được thay đổi để cho phép khai thác hoặc đốt loại mã thông báo này không được ủy quyền theo chính sách ban đầu.
Bất cứ khi nào một giao dịch khai thác được thêm vào sổ cái, chính sách cho từng loại mã thông báo được đúc sẵn được kiểm tra và phải được thỏa mãn.
Mỗi mã thông báo lưu hành, ngoại trừ ADA (vì Cardano cấm khai thác thêm ADA), nhất thiết phải có chính sách khai thác và được đảm bảo đã được đúc theo chính sách đó.

Therefore the only custom code required to manipulate tokens in Cardano is the policy itself. Tying the policy hash to the asset identifier means that there is no need for a global asset registry, so creating assets is cheap and easy. The system remains simple, lightweight and easy to use.

Do đó, mã tùy chỉnh duy nhất cần thiết để thao tác mã thông báo trong Cardano là chính sách.
Việc buộc chính sách băm vào số nhận dạng tài sản có nghĩa là không cần phải đăng ký tài sản toàn cầu, vì vậy việc tạo tài sản là rẻ và dễ dàng.
Hệ thống vẫn đơn giản, nhẹ và dễ sử dụng.

**Unified process**

** Quy trình thống nhất **

When native tokens are implemented as part of Goguen, the ledger will handle all tokens in the same way. And minting a token can only be done in one way, to reduce ambiguity and possible mistakes or bugs. This simplification in using a unified process will lead to faster development and a better development experience overall. 

Khi các mã thông báo gốc được thực hiện như một phần của Goguen, sổ cái sẽ xử lý tất cả các mã thông báo theo cùng một cách.
Và việc khai thác một mã thông báo chỉ có thể được thực hiện theo một cách, để giảm sự mơ hồ và có thể có những sai lầm hoặc lỗi.
Sự đơn giản hóa này trong việc sử dụng một quy trình thống nhất sẽ dẫn đến sự phát triển nhanh hơn và trải nghiệm phát triển tốt hơn nói chung.

### **Pre-production environment incoming**

### ** Môi trường tiền sản xuất đến **

Native token capability will be deployed to the Cardano mainnet following a protocol upgrade in Q1 2021 (known internally by the working name, ‘Mary’) opening up a new world of use cases and opportunity. To onboard new developers ahead of this date, we’re now finalizing the deployment of a pre-production environment for native tokens. So stay close to our social channels for the very latest news on deployment.

Khả năng mã thông báo gốc sẽ được triển khai cho Cardano Mainnet sau khi nâng cấp giao thức trong Q1 2021 (được biết đến bên trong tên làm việc, ‘Mary,) mở ra một thế giới mới của các trường hợp sử dụng và cơ hội.
Đối với các nhà phát triển mới trước ngày này, chúng tôi hiện đang hoàn thiện việc triển khai môi trường tiền sản xuất cho các mã thông báo gốc.
Vì vậy, hãy ở gần các kênh xã hội của chúng tôi cho các tin tức mới nhất về triển khai.

*If you are a developer and want to get involved early on, [visit our developer site](https://developers.cardano.org/en/development-environments/native-tokens/native-tokens/), where you can get supporting documentation and resources. We’ll add to this over time; sign up to our developer survey on [this page](https://bit.ly/3lX1ER0) to express your interest and be alerted as soon as everything becomes available.*

*Nếu bạn là nhà phát triển và muốn tham gia sớm, [truy cập trang web nhà phát triển của chúng tôi] (https://developers.cardano.org/en/development-environments/native-tokens/native-tokens/), nơi bạn có thể
Nhận tài liệu hỗ trợ và tài nguyên.
Chúng tôi sẽ thêm vào điều này theo thời gian;
Đăng ký khảo sát nhà phát triển của chúng tôi trên [trang này] (https://bit.ly/3lx1er0) để thể hiện sự quan tâm của bạn và được cảnh báo ngay khi mọi thứ có sẵn.*

