# Online learning with Haskell: the Mongolia Class of 2020
### **Reminiscing on the delivery of the first Haskell massive online course (MOOC)**
![](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.002.png) 21 December 2020![](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.002.png)[ Alejandro Garcia](tmp//en/blog/authors/alejandro-garcia/page-1/)![](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.003.png) 7 mins read

![Alejandro Garcia](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.004.png)[](tmp//en/blog/authors/alejandro-garcia/page-1/)
### [**Alejandro Garcia**](tmp//en/blog/authors/alejandro-garcia/page-1/)
Project Manager

Project Management

- ![](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.005.png)[](mailto:alejandro.garcia@iohk.io "Email")
- ![](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.006.png)[](https://www.linkedin.com/in/elviejo79 "LinkedIn")
- ![](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.007.png)[](https://twitter.com/agarciafdz "Twitter")
- ![](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.008.png)[](https://github.com/elviejo79 "GitHub")

![Online learning with Haskell: the Mongolia Class of 2020](img/2020-12-21-online-learning-with-haskell-the-mongolia-class-of-2020.009.jpeg)

*Here we share feedback on this year's Haskell course which we delivered online for the first time.*

*Ở đây chúng tôi chia sẻ phản hồi về khóa học Haskell năm nay mà chúng tôi đã cung cấp trực tuyến lần đầu tiên.*

Saying that the Covid-19 pandemic changed the world's plans is a clichÃ© at this point, and the same thing happened to us here at IOGâ€™s Education department. However, what we did not expect were the new opportunities that the global lockdown opened up for us which enabled us to deliver a fantastic online Haskell bootcamp in 2020.

Nói rằng đại dịch COVID-19 đã thay đổi kế hoạch của thế giới là một sự sáo rỗng vào thời điểm này, và điều tương tự đã xảy ra với chúng tôi ở đây tại bộ phận giáo dục của IOG.
Tuy nhiên, những gì chúng tôi không mong đợi là những cơ hội mới mà The Global Lockdown đã mở ra cho chúng tôi, điều này cho phép chúng tôi cung cấp một chiếc Haskell Bootcamp trực tuyến tuyệt vời vào năm 2020.

If you are familiar with IOG, you probably know that the Haskell programming language and its functional approach to software development are integral to the company. It is right there in the name â€œInput Outputâ€. So, it is no surprise that we have invested heavily in improving the Haskell ecosystem, from contributing to open-source projects, sponsoring developers, and much more. One of our big efforts is that every year we run a Haskell bootcamp, which involves three months of intensive in-person training with Lars BrÃ¼njes, director of education, and guest lectures by some of the best developers and computer scientists in the world. So far, there have been four iterations of this class: Ethiopia 2019, Barbados 2018, Athens 2017, and one was planned for Mongolia in 2020.

Nếu bạn quen thuộc với IOG, có lẽ bạn sẽ biết rằng ngôn ngữ lập trình Haskell và cách tiếp cận chức năng của nó để phát triển phần mềm là không thể thiếu đối với công ty.
Nó ở ngay đó trong tên - Đầu ra kết quả.
Vì vậy, không có gì ngạc nhiên khi chúng tôi đã đầu tư rất nhiều vào việc cải thiện hệ sinh thái Haskell, từ đóng góp cho các dự án nguồn mở, tài trợ cho các nhà phát triển và nhiều hơn nữa.
Một trong những nỗ lực lớn của chúng tôi là mỗi năm chúng tôi điều hành một bootcamp Haskell, bao gồm ba tháng đào tạo trực tiếp chuyên sâu với Lars BrÃ¼njes, Giám đốc Giáo dục và các bài giảng của một số nhà phát triển và nhà khoa học máy tính tốt nhất trên thế giới.
Cho đến nay, đã có bốn lần lặp lại của lớp này: Ethiopia 2019, Barbados 2018, Athens 2017 và một người đã được lên kế hoạch cho Mông Cổ vào năm 2020.

The actual class takes 10 weeks of Haskell, cryptocurrency, and smart contract training that opens up new opportunities for young students that take the challenge of the course. It is not easy, the topics are hard, the homework is even harder, and the hours are grueling. Calling this a full-time commitment is an understatement, most students in the previous editions have called it the â€œmost difficult class of their livesâ€.

Lớp học thực tế mất 10 tuần Haskell, tiền điện tử và đào tạo hợp đồng thông minh mở ra những cơ hội mới cho các sinh viên trẻ thực hiện thử thách của khóa học.
Thật không dễ dàng, các chủ đề khó khăn, bài tập về nhà thậm chí còn khó hơn và giờ là thời gian mệt mỏi.
Gọi đây là một cam kết toàn thời gian là một cách nói nhẹ nhàng, hầu hết các sinh viên trong các phiên bản trước đã gọi đó là lớp học khó khăn nhất trong cuộc sống của họ.

Despite all these factors, on completion of the 10 weeks, the students come away with experience in the most state-of-the-art topics in software development: strongly typed functional programming, embedded DSL design, property-based testing, smart contract development (with Plutus and Marlowe), as well as a strong sense of pride in having achieved something truly challenging that will influence their professional lives for decades to come.

Bất chấp tất cả các yếu tố này, sau khi hoàn thành 10 tuần, các sinh viên đã trải qua kinh nghiệm trong các chủ đề hiện đại nhất trong phát triển phần mềm: lập trình chức năng được đánh máy mạnh mẽ, thiết kế DSL nhúng, thử nghiệm dựa trên tài sản, phát triển hợp đồng thông minh
.

At the beginning of 2020, the Mongolia Haskell bootcamp was well on its way to taking place in March, and then, as we all know, the planet stopped. In January, the nature of Coronavirus was relatively unknown, but by March its mortality rate and its main mediums of transmission were front-page news, flights were being canceled, and later shut down completely. This made it impossible to deliver the class in person as planned. Thanks to the tenacity, or may I say stubbornness, of Dugerdorj Davaadorj and Lars, that class was going to happen no matter what. So, we had to adapt the class to the new realities imposed by the pandemic. We expected these changes to be difficult, and as any teacher will tell you, it is easier to provide feedback when you can see the studentsâ€™ reactions, and it is also easier to provide an interactive education when the students can see each other, program in pairs, or even practice â€œswarmâ€ development. 

Vào đầu năm 2020, Bootcamp của Mông Cổ Haskell đang trên đường diễn ra vào tháng 3, và sau đó, như chúng ta đều biết, hành tinh đã dừng lại.
Vào tháng 1, bản chất của coronavirus là tương đối xa lạ, nhưng vào tháng 3, tỷ lệ tử vong của nó và các phương tiện truyền tải chính của nó là tin tức trên trang nhất, các chuyến bay đã bị hủy bỏ, và sau đó đóng cửa hoàn toàn.
Điều này làm cho nó không thể giao hàng trực tiếp theo kế hoạch.
Nhờ sự kiên trì, hoặc tôi có thể nói sự bướng bỉnh, của Dugerdorj Davaadorj và Lars, lớp học đó sẽ xảy ra bất kể điều gì.
Vì vậy, chúng tôi đã phải điều chỉnh lớp học với thực tế mới do đại dịch.
Chúng tôi hy vọng những thay đổi này sẽ khó khăn và như bất kỳ giáo viên nào sẽ nói với bạn, việc cung cấp phản hồi dễ dàng hơn khi bạn có thể thấy các phản ứng của học sinh và việc cung cấp một nền giáo dục tương tác cũng dễ dàng hơn khi học sinh có thể nhìn thấy nhau,
Chương trình theo cặp, hoặc thậm chí thực hành - Phát triển.

What we didnâ€™t expect is that the MOOC approach would turn out to be *even better* in some ways than an in-person training course. For example, in the recent edition, the class was co-taught by Lars and Andres LÃ¶h from our friends at Well-typed. Andres is a highly regarded teacher in the Haskell community and has been involved with the language for over 20 years. Basically, if you find an interesting open-source project in Haskell, Andres has probably been involved in it in some way. Then we also had guest lectures by Rob Cohen (Program Manage IOG), Joshua Miller (Project Manager IOG), and Phillip Wadler (one of the original creators of Haskell, with too many achievements to mention; his Wikipedia page is a good starting point to find out more). 

Điều mà chúng tôi không mong đợi là phương pháp MOOC sẽ trở thành * thậm chí còn tốt hơn * theo một số cách hơn là một khóa đào tạo trực tiếp.
Ví dụ, trong phiên bản gần đây, lớp học đã được đồng giảng dạy bởi Lars và Andres lÃ¶h từ những người bạn của chúng tôi tại gõ.
Andres là một giáo viên được đánh giá cao trong cộng đồng Haskell và đã tham gia vào ngôn ngữ trong hơn 20 năm.
Về cơ bản, nếu bạn tìm thấy một dự án nguồn mở thú vị ở Haskell, Andres có lẽ đã tham gia vào nó theo một cách nào đó.
Sau đó, chúng tôi cũng đã có các bài giảng khách của Rob Cohen (Quản lý chương trình IOG), Joshua Miller (quản lý dự án IOG) và Phillip Wadler (một trong những người tạo ra Haskell ban đầu, với quá nhiều thành tích để đề cập đến; trang Wikipedia của anh ấy là một điểm khởi đầu tốt
để tìm hiểu thêm).

Our Haskell training course started in August and as usual, there were some hiccups getting all the students settled with a proper development environment, language barriers, and some cultural differences. Basically, professors were encouraging students to ask more questions, however, in Mongolian culture students tend to work quietly only asking questions or collaborating with each other. Therefore, it was good that all the students were working together in the University lab on-site and we were very glad to have access to that facility. It was great to see that universities were open in Mongolia!

Khóa đào tạo Haskell của chúng tôi bắt đầu vào tháng 8 và như thường lệ, có một số trục trặc khiến tất cả các sinh viên giải quyết với một môi trường phát triển thích hợp, rào cản ngôn ngữ và một số khác biệt về văn hóa.
Về cơ bản, các giáo sư đã khuyến khích sinh viên hỏi thêm câu hỏi, tuy nhiên, trong các sinh viên văn hóa Mông Cổ có xu hướng làm việc lặng lẽ chỉ đặt câu hỏi hoặc hợp tác với nhau.
Do đó, thật tốt khi tất cả các sinh viên đã làm việc cùng nhau trong phòng thí nghiệm đại học tại chỗ và chúng tôi rất vui mừng khi có quyền truy cập vào cơ sở đó.
Thật tuyệt khi thấy các trường đại học đã mở ở Mông Cổ!

Remember, this was August 2020 with most schools closed in Europe and America, so how come the Mongolian universities were open? It turns out that Mongolia, up to that point, had recorded zero deaths from Covid-19! Let me say that again â€” ZERO deaths from Covid-19. We couldnâ€™t even believe it in the beginning, but as the weeks progressed and we were able to get to know the students, we understood why. The discipline and disposition for work that our students were showing in class was the same attitude that allowed Mongolian citizens to isolate from the pandemic on January 27th. The Mongolian government took decisive actions right from the beginning, which the citizens followed precisely. We could see that while working, as everyone wore masks and kept their distance. Although the learning process was hard, students worked on many difficult exercises, consulted each other, and collaborated in spontaneous teams to encourage everyone that was participating.

Hãy nhớ rằng, đây là tháng 8 năm 2020 với hầu hết các trường học đóng cửa ở châu Âu và châu Mỹ, vậy làm thế nào mà các trường đại học Mông Cổ mở cửa?
Nó chỉ ra rằng Mông Cổ, cho đến thời điểm đó, đã ghi nhận cái chết bằng không từ Covid-19!
Hãy để tôi nói rằng một lần nữa "tử vong do 0 € từ Covid-19.
Chúng tôi không thể tin vào điều đó ngay từ đầu, nhưng khi nhiều tuần tiến triển và chúng tôi có thể làm quen với các sinh viên, chúng tôi đã hiểu tại sao.
Kỷ luật và khuynh hướng cho công việc mà các sinh viên của chúng tôi thể hiện trong lớp là cùng một thái độ cho phép công dân Mông Cổ cô lập với đại dịch vào ngày 27 tháng 1.
Chính phủ Mông Cổ đã thực hiện các hành động quyết định ngay từ đầu, điều mà công dân tuân theo chính xác.
Chúng ta có thể thấy điều đó trong khi làm việc, vì mọi người đều đeo mặt nạ và giữ khoảng cách.
Mặc dù quá trình học tập rất khó khăn, sinh viên đã làm việc với nhiều bài tập khó khăn, tham khảo ý kiến lẫn nhau và hợp tác trong các nhóm tự phát để khuyến khích mọi người tham gia.

The homework assignments were deployed on the GitHub Classroom platform, which allowed students to collaborate in team projects the way that professional software developers would do: committing and resolving issues in various branches in a common code repository. 

Các bài tập về nhà đã được triển khai trên nền tảng lớp học GitHub, cho phép sinh viên hợp tác trong các dự án nhóm theo cách mà các nhà phát triển phần mềm chuyên nghiệp sẽ làm: cam kết và giải quyết các vấn đề trong các chi nhánh khác nhau trong một kho lưu trữ mã chung.

As an additional benefit of the online learning environment, we were able to accept a couple of students from Mexico. This was also challenging for them as the classes were held from 11 pm until 5 am in the morning, which required a complete 10-week schedule switch for the students, as well as myself, as a reviewer.

Là một lợi ích bổ sung của môi trường học tập trực tuyến, chúng tôi đã có thể chấp nhận một vài sinh viên từ Mexico.
Đây cũng là một thách thức đối với họ khi các lớp học được tổ chức từ 11 giờ tối đến 5 giờ sáng, đòi hỏi một công tắc lịch trình 10 tuần hoàn chỉnh cho các sinh viên, cũng như bản thân tôi, như một người đánh giá.

In the end, their determination allowed them to finish the course having acquired really valuable skills and a sense of pride in the achievement itself. We want to thank the Mongolia ministry of Education and Economics for making this possible.

Cuối cùng, quyết tâm của họ cho phép họ hoàn thành khóa học có được các kỹ năng thực sự có giá trị và cảm giác tự hào về thành tích.
Chúng tôi muốn cảm ơn Bộ Giáo dục và Kinh tế Mông Cổ vì đã biến điều này thành có thể.

The feedback we received from the students was very positive, here are some comments we received from the participants:

Phản hồi chúng tôi nhận được từ các sinh viên là rất tích cực, đây là một số nhận xét chúng tôi nhận được từ những người tham gia:

*â€œThe course was my very first experience of functional programming. It felt like a whole new world to me and truly broadened my horizons and the way of thinking. Iâ€™m so glad that my first steps were guided by professionals. I will never be the same as before I took the class. I am very grateful; I grew both professionally and personally. I recommend it to anyone who wants to level up their programming skills*.â€

*"Khóa học là trải nghiệm đầu tiên của tôi về lập trình chức năng.
Nó cảm thấy như một thế giới hoàn toàn mới đối với tôi và thực sự mở rộng tầm nhìn của tôi và cách suy nghĩ.
Tôi rất vui vì những bước đầu tiên của tôi được hướng dẫn bởi các chuyên gia.
Tôi sẽ không bao giờ giống như trước khi tôi tham gia lớp học.
Tôi rât cảm kich;
Tôi đã phát triển cả chuyên nghiệp và cá nhân.
Tôi giới thiệu nó cho bất cứ ai muốn tăng cấp kỹ năng lập trình của họ*. '

Tuvshintsenguun

Tuvshintsenguun

*â€œAfter attending the Mongolia Haskell Class, I reaffirmed the beauty of functional programming. The beauty of the code makes it look so simple. I want to thank Lars and Andres for allowing me to attend your class. I admire your utmost professionalism and excitement to share your knowledge. You are an inspiration to all of us who want to become better engineers*.â€ 

*Sau khi tham dự lớp Mông Cổ Haskell, tôi đã tái khẳng định vẻ đẹp của lập trình chức năng.
Vẻ đẹp của mã làm cho nó trông rất đơn giản.
Tôi muốn cảm ơn Lars và Andres vì đã cho phép tôi tham dự lớp học của bạn.
Tôi ngưỡng mộ sự chuyên nghiệp và phấn khích tối đa của bạn để chia sẻ kiến thức của bạn.
Bạn là nguồn cảm hứng cho tất cả chúng ta muốn trở thành kỹ sư tốt hơn*.â € €

K. Chaires

K. Ghế

*â€œThis course exceeded all my expectations. I learned so much with Lars and Andres. They are expert programmers and even better teachers. They effortlessly explained complex concepts. Now I want to develop every project in Haskell*.â€

*"Khóa học này vượt quá mọi mong đợi của tôi.
Tôi đã học được rất nhiều với Lars và Andres.
Họ là lập trình viên chuyên gia và thậm chí là giáo viên tốt hơn.
Họ dễ dàng giải thích các khái niệm phức tạp.
Bây giờ tôi muốn phát triển mọi dự án trong Haskell*.â €

A. Ibarra

A. Ibarra

As for ourselves, we are very happy with how this experiment of running a small class in a remote setting turned out, making it our first MOOC delivery. It also opens up exciting new collaborative opportunities for the education team in the future. Of course, we cannot wait to get back on the road, and get to meet these students and prospective students in real life once more, once it is safe to travel again. Hence, in 2021 we plan to run one more iteration of the class in person and one online course that is open to the world, as we continue on our journey to train 10,000 smart contract developers on Cardano. Wishing you all a happy new year as we look forward to 2021!

Đối với chính chúng tôi, chúng tôi rất hài lòng với cách thử nghiệm điều hành một lớp nhỏ trong một cài đặt từ xa bật ra, biến nó thành giao hàng MOOC đầu tiên của chúng tôi.
Nó cũng mở ra các cơ hội hợp tác mới thú vị cho nhóm giáo dục trong tương lai.
Tất nhiên, chúng tôi không thể chờ đợi để trở lại trên đường, và gặp gỡ những sinh viên và sinh viên tương lai này trong cuộc sống thực một lần nữa, một khi an toàn để đi du lịch trở lại.
Do đó, vào năm 2021, chúng tôi dự định sẽ chạy thêm một lần lặp lại của lớp và một khóa học trực tuyến mở cửa cho thế giới, khi chúng tôi tiếp tục hành trình đào tạo 10.000 nhà phát triển hợp đồng thông minh trên Cardano.
Chúc tất cả các bạn một năm mới hạnh phúc khi chúng tôi mong đợi đến năm 2021!

