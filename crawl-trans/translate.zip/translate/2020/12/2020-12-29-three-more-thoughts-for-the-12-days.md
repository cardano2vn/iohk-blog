# Three more thoughts for the 12 days
### **The past, present, and future of Cardano in the spirit of an olde English counting song**
![](img/2020-12-29-three-more-thoughts-for-the-12-days.002.png) 29 December 2020![](img/2020-12-29-three-more-thoughts-for-the-12-days.002.png)[ Anthony Quinn](tmp//en/blog/authors/anthony-quinn/page-1/)![](img/2020-12-29-three-more-thoughts-for-the-12-days.003.png) 4 mins read

![Anthony Quinn](img/2020-12-29-three-more-thoughts-for-the-12-days.004.png)[](tmp//en/blog/authors/anthony-quinn/page-1/)
### [**Anthony Quinn**](tmp//en/blog/authors/anthony-quinn/page-1/)
Editor

Marketing & Communications

- ![](img/2020-12-29-three-more-thoughts-for-the-12-days.005.png)[](mailto:anthony.quinn@iohk.io "Email")
- ![](img/2020-12-29-three-more-thoughts-for-the-12-days.006.png)[](https://www.youtube.com/watch?v=KkcAic12dvc "YouTube")
- ![](img/2020-12-29-three-more-thoughts-for-the-12-days.007.png)[](https://www.linkedin.com/in/tony-quinn-frsa-0b093229 "LinkedIn")
- ![](img/2020-12-29-three-more-thoughts-for-the-12-days.008.png)[](https://twitter.com/IohkT "Twitter")

![Three more thoughts for the 12 days](img/2020-12-29-three-more-thoughts-for-the-12-days.009.png)

We're putting out some thoughts about the past, present and future in the spirit of an olde English counting song. There's one for each of [The Twelve Days of Christmas](https://www.classicfm.com/discover-music/occasions/christmas/twelve-12-days-of-christmas-lyrics-meaning/), from December 25 to January 5. [The first four](https://iohk.io/en/blog/posts/2020/12/24/some-thoughts-for-the-next-12-days/) went out together and here are three for the next few days. 

Chúng tôi đưa ra một số suy nghĩ về quá khứ, hiện tại và tương lai theo tinh thần của một bài hát đếm tiếng Anh cũ.
Có một cho mỗi [mười hai ngày Giáng sinh] (https://www.classicfm.com/discover-music/occasions/christmas/twelve-12-days-of-clogmas-nyrics-meaning/), từ ngày 25 tháng 12
đến ngày 5 tháng 1. [Bốn đầu tiên] (https://iohk.io/en/blog/posts/2020/12/24/some-houghtsts-for-the-next-12-days/) đã đi chơi cùng nhau và ở đây
là ba trong vài ngày tới.

## **Day 5. Romain Pellerin, technology chief**

## ** Ngày 5. Romain Pellerin, Giám đốc công nghệ **

Itâ€™s been a really satisfying year after delivering so much. There was the Byron reboot, then Shelley, and we haveÂ just released [Allegra for token locking](https://iohk.io/en/blog/posts/2020/12/02/goguen-brings-token-locking-to-cardano/) and are preparing [Mary for native tokens](https://iohk.io/en/blog/posts/2020/12/09/native-tokens-on-cardano-core-principles-and-points-of-difference/). We have been digesting years of research and science with strong engineering â€“ and creating a community with the stake pool operators for example. Itâ€™s been a very intense year. I am extremely proud of the team and the way they were able to digest all this. Delivering such complexity, steadily and on schedule all along this year was definitely a big achievement.Â 

Đó là một năm thực sự thỏa mãn sau khi cung cấp rất nhiều.
Có sự khởi động lại của Byron, sau đó là Shelley và chúng tôi vừa phát hành [Allegra để khóa mã thông báo] (https://iohk.io/en/blog/posts/2020/12/02/goguen-rings-token-locking-to--to
-cardano/) và đang chuẩn bị [Mary cho các mã thông báo bản địa] (https://iohk.io/en/blog/posts/2020/12/09/native-tokens-on-cardano-core-principles-and-points-
sự khác biệt/).
Chúng tôi đã tiêu hóa nhiều năm nghiên cứu và khoa học với kỹ thuật mạnh mẽ - ví dụ và tạo ra một cộng đồng với các nhà khai thác nhóm cổ phần chẳng hạn.
Đó là một năm rất mãnh liệt.
Tôi vô cùng tự hào về đội và cách họ có thể tiêu hóa tất cả những điều này.
Cung cấp sự phức tạp như vậy, đều đặn và đúng tiến độ trong năm nay chắc chắn là một thành tựu lớn.

Now, weâ€™re absorbing what weâ€™ve learned andÂ we continue to improve the company in terms of structure, organization, and processes. IO definitely grew up!

Bây giờ, chúng tôi đang tiếp thu những gì chúng tôi đã học được và chúng tôi tiếp tục cải thiện công ty về cấu trúc, tổ chức và quy trình.
Io chắc chắn lớn lên!

In 2021, we will deliver [Goguen](https://iohk.io/en/blog/posts/2020/10/29/bringing-new-value-and-utility-to-the-cardano-blockchain/) and [Voltaire](https://iohk.io/en/blog/posts/2020/09/10/project-catalyst-voltaire-bring-power-to-the-people/) â€“ smart contracts and decentralized governance â€“ alongside growing our communities of developers and operators. This will empower users to participate in the governance of the system itself. It is definitely a time that will be interesting to go through, so keep your heads high because 2021 will be amazing!

Vào năm 2021, chúng tôi sẽ cung cấp [Goguen] (https://iohk.io/en/blog/posts/2020/10/29/bringing-new-value-and-tility-to-the-cardano-blockchain/) và
.
€ bên cạnh việc phát triển cộng đồng các nhà phát triển và nhà khai thác của chúng tôi.
Điều này sẽ trao quyền cho người dùng tham gia vào quản trị của chính hệ thống.
Đó chắc chắn là một thời gian sẽ rất thú vị để trải qua, vì vậy hãy giữ đầu của bạn cao vì 2021 sẽ rất tuyệt vời!

![](img/2020-12-29-three-more-thoughts-for-the-12-days.010.jpeg)

## **Day 6. Junko Oda, translator**

## ** Ngày 6. Junko Oda, dịch giả **

Japan is an important part of the Cardano community and my job is to translate many of the blog posts into Japanese as quickly as possible. I was particularly pleased with how this post about the [hard fork combinator](https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-hard-fork/) read [once translated](https://forum.cardano.org/t/iohk-shelley/32915). I am not a technical person at all, but that is a virtue in my job because we want these posts to be understood by as many people as possible. Iâ€™m often the one asking the really basic questions! To translate such articles is tough, but it is also fascinating to learn about such cutting-edge technologies â€“ and to be part of the company making them happen.

Nhật Bản là một phần quan trọng của cộng đồng Cardano và công việc của tôi là dịch nhiều bài đăng trên blog sang tiếng Nhật càng nhanh càng tốt.
Tôi đặc biệt hài lòng với cách bài đăng này về [tổ hợp hard fork] (https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-hard-
Fork/) đọc [một khi được dịch] (https://forum.cardano.org/t/iohk-shelley/32915).
Tôi không phải là một người kỹ thuật, nhưng đó là một đức tính trong công việc của tôi bởi vì chúng tôi muốn những bài viết này được hiểu bởi càng nhiều người càng tốt.
Tôi thường là người hỏi những câu hỏi thực sự cơ bản!
Để dịch các bài báo như vậy là khó khăn, nhưng cũng rất hấp dẫn khi tìm hiểu về các công nghệ tiên tiến như vậy-và là một phần của công ty khiến chúng xảy ra.

Right now, Iâ€™m about to click on the purchase button of an e-book website. When Iâ€™m off work, I prefer reading Japanese books. Iâ€™m also fond of Japanese poetry and my husband publishes [*The Haibun Journal*](https://thehaibunjournal.blog). What I am buying is a novel by Takahiro Ueda called [*Nimrod*](https://bookclub.kodansha.co.jp/product?item=0000319220), which won the 2019 [Acutagawa award](https://www.japantimes.co.jp/news/2012/02/14/reference/literary-awards-run-spectrum/) sponsored by the Society for the Promotion of Japanese Literature. The [Acutagawa prize](https://www.bunshun.co.jp/shinkoukai/award/akutagawa/list.html) started in 1935 and is given twice a year. According to the blurb for *Nimrod*, the story relates somehow to cryptocurrency. A novel using cryptocurrency as a motif won such a prestigious award! Wow!

Ngay bây giờ, tôi sắp nhấp vào nút Mua hàng của một trang web sách điện tử.
Khi tôi nghỉ làm, tôi thích đọc sách Nhật Bản.
Tôi cũng thích thơ Nhật Bản và chồng tôi xuất bản [*Tạp chí Haibun*] (https://thehaibunjournal.blog).
Những gì tôi đang mua là một cuốn tiểu thuyết của Takahiro Ueda có tên [*Nimrod*] (https://bookclub.kodansha.co.jp/product?item=0000319220)
.
[Giải thưởng Acutagawa] (https://www.bunshun.co.jp/shinkoukai/award/akutagawa/list.html) bắt đầu vào năm 1935 và được trao hai lần một năm.
Theo The Blurb for *Nimrod *, câu chuyện liên quan đến bằng cách nào đó với tiền điện tử.
Một cuốn tiểu thuyết sử dụng tiền điện tử như một mô típ đã giành được một giải thưởng uy tín như vậy!
Ồ!

After Christmas, Iâ€™m looking forward to some quiet time reading *Nimrod* before the year starts to get going. The Basho development phase of Cardano is coming near. It is named after Matsuo Basho, the 17th century Japanese poet who specialized in the *haiku* and *haibun* forms, renowned for their intellectual and artistic discipline. If 2021 is anything like the past year for work, itâ€™s going to be a busy one. I hope you will enjoy reading our blog posts â€“ in English or Japanese â€“ while I am enjoying my book! In the meantime, hereâ€™s a Basho poem I particularly like:

Sau Giáng sinh, tôi đang mong chờ một số thời gian yên tĩnh để đọc * nimrod * trước khi năm bắt đầu diễn ra.
Giai đoạn phát triển Basho của Cardano đang đến gần.
Nó được đặt theo tên của Matsuo Basho, nhà thơ Nhật Bản thế kỷ 17, người chuyên về các hình thức * Haiku * và * Haibun *, nổi tiếng với kỷ luật trí tuệ và nghệ thuật của họ.
Nếu năm 2021 là bất cứ điều gì giống như năm vừa qua cho công việc, thì đó sẽ là một năm bận rộn.
Tôi hy vọng bạn sẽ thích đọc các bài đăng trên blog của chúng tôi - bằng tiếng Anh hoặc tiếng Nhật - Trong khi tôi đang thưởng thức cuốn sách của mình!
Trong khi đó, đây là một bài thơ basho tôi đặc biệt thích:

summer grasses â€“

Cỏ mùa hè -

all that remains,

tất cả những gì còn lại,

of warriorsâ€™ dreams

của những người chiến binh - những giấc mơ

*(trans. Sean Oâ€™Connor)*

*(Trans. Sean Oâ € ™ Connor)*

![](img/2020-12-29-three-more-thoughts-for-the-12-days.010.jpeg)

## **Day 7. Darko MijiÄ‡, product manager**

## ** Ngày 7. Darko Mijiä, Quản lý sản phẩm **

We had 40 releases for the Daedalus wallet this year â€“ more than in all the previous years combined! Among the many new features and improvements that Iâ€™m most proud of are the Byron reboot, which meant a big reduction in connection issues and faster blockchain synchronization. Then, Shelley was a big-bang release with a Daedelus update bringing enhanced cryptography, as well as stake pool delegation and rewards.

Chúng tôi đã có 40 bản phát hành cho ví Daedalus trong năm nay - nhiều hơn trong tất cả các năm trước kết hợp!
Trong số nhiều tính năng và cải tiến mới mà tôi tự hào nhất là khởi động lại Byron, điều đó có nghĩa là giảm lớn các vấn đề kết nối và đồng bộ hóa blockchain nhanh hơn.
Sau đó, Shelley là một bản phát hành lớn với bản cập nhật Daedelus mang đến mật mã nâng cao, cũng như phái đoàn và phần thưởng của nhóm cổ phần.

Right now, weâ€™re analysing the responses to our recent survey â€“ 5,000 from Daedalus users, and more than 100 from stake pool operators. These will help us put the community at the heart of our development plans.

Ngay bây giờ, chúng tôi đã phân tích các câu trả lời cho cuộc khảo sát gần đây của chúng tôi - 5.000 người từ người dùng Daedalus và hơn 100 người từ các nhà khai thác nhóm cổ phần.
Những điều này sẽ giúp chúng tôi đặt cộng đồng vào trung tâm của các kế hoạch phát triển của chúng tôi.

Going into 2021, we are keen for the technically-minded members of the Cardano community to continue with the [Daedalus Flight testing program](https://iohk.io/en/blog/posts/2020/04/01/we-need-you-for-the-daedalus-flight-testing-program/). Wallet improvements will include [decentralized identity using Atala Prism](https://iohk.io/en/blog/posts/2020/10/29/bringing-new-value-and-utility-to-the-cardano-blockchain/) â€“ something that will unlock Western-style financial services for developing countries â€“ and native tokens for use in Goguen smart contracts. Furthermore, paper wallets will combine PGP encryption with the convenience of QR codes.

Vào năm 2021, chúng tôi rất muốn các thành viên có đầu óc kỹ thuật của cộng đồng Cardano tiếp tục với [Chương trình thử nghiệm chuyến bay Daedalus] (https://iohk.io/en/blog/posts/2020/04/01/we-we-w
cần-bạn cho chương trình kiểm tra-máy bay-flight/).
Cải tiến ví sẽ bao gồm [Bản sắc phi tập trung bằng cách sử dụng Atala Prism] (https://iohk.io/en/blog/posts/2020/10/29/bringing-new-value-and-tility-to-the-cardano-blockchain/
)-Một cái gì đó sẽ mở khóa các dịch vụ tài chính theo phong cách phương Tây cho các nước đang phát triển-và mã thông báo gốc để sử dụng trong các hợp đồng thông minh Goguen.
Hơn nữa, ví giấy sẽ kết hợp mã hóa PGP với sự thuận tiện của mã QR.

*The next batch of 12 Days thoughts will be published on December 31*

*Lô 12 ngày tiếp theo sẽ được xuất bản vào ngày 31 tháng 12*

