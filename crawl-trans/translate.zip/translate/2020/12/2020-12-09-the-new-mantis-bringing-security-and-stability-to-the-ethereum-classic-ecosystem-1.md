# The new Mantis: Bringing security and stability to the Ethereum Classic ecosystem
### **We’re committed to bringing innovation and fresh life to ETC and this is just the start**
![](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.002.png) 9 December 2020![](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.002.png)[ Niamh Ahern](tmp//en/blog/authors/niamh-ahern/page-1/)![](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.003.png) 6 mins read

![Niamh Ahern](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.004.png)[](tmp//en/blog/authors/niamh-ahern/page-1/)
### [**Niamh Ahern**](tmp//en/blog/authors/niamh-ahern/page-1/)
Education Manager

Education

- ![](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.005.png)[](mailto:niamh.ahern@iohk.io "Email")
- ![](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.006.png)[](https://www.linkedin.com/in/niamh-ahern-67849949/ "LinkedIn")
- ![](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.007.png)[](https://twitter.com/nahern_iohk?lang=en "Twitter")
- ![](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.008.png)[](https://github.com/nahern "GitHub")

![The new Mantis: Bringing security and stability to the Ethereum Classic ecosystem](img/2020-12-09-the-new-mantis-bringing-security-and-stability-to-the-ethereum-classic-ecosystem-1.009.png)

IOHK has a long association with Ethereum Classic (ETC) and its community, which preserves an untampered history free from external interference and subjective altering of transactions. Serving as the next-generation digital currency platform, ETC is built as an intuitive programming platform, which allows developers of all skill sets to build the next wave of market disrupting decentralized applications (DApps). 

IOHK có mối liên hệ lâu dài với Ethereum Classic (ETC) và cộng đồng của nó, nơi bảo tồn một lịch sử không bị cản trở không có sự can thiệp bên ngoài và thay đổi chủ quan của các giao dịch.
Phục vụ như là nền tảng tiền kỹ thuật số thế hệ tiếp theo, v.v. được xây dựng như một nền tảng lập trình trực quan, cho phép các nhà phát triển của tất cả các bộ kỹ năng xây dựng làn sóng thị trường tiếp theo phá vỡ các ứng dụng phi tập trung (DAPP).

The goal of ETC is to securely and methodically establish a strong ecosystem underpinned by solid foundation and core immutability. However, recent 51% attacks have put the ETC ecosystem into a precarious position, denting its confidence and challenging the community’s ability to address this issue, while representing an existential threat to its future viability. 

Mục tiêu của ETC là thiết lập một cách an toàn và có phương pháp một hệ sinh thái mạnh mẽ được củng cố bởi nền tảng vững chắc và tính bất biến cốt lõi.
Tuy nhiên, 51% các cuộc tấn công gần đây đã đưa hệ sinh thái ETC vào một vị trí bấp bênh, làm giảm sự tự tin của nó và thách thức khả năng cộng đồng của cộng đồng để giải quyết vấn đề này, đồng thời thể hiện mối đe dọa hiện hữu đối với khả năng tồn tại trong tương lai của nó.

## **Driving innovation & future growth for ETC**

## ** Đổi mới lái xe và tăng trưởng trong tương lai cho ETC **

New Mantis is the only client that is written natively for Ethereum Classic and it offers unrivalled levels of assurance, security, and usability. IOHK has relaunched the Mantis project to mitigate against the recent attacks, provide enhanced security, and establish a robust means of interacting with the ETC chain. A commitment to fostering innovation and sustainability lies at the heart of the project. We are aiming to provide a steady funding income with the establishment of a proto-treasury to nurture future development and growth. This Mantis re-launch represents the culmination of a project that we've been working on for some time. Over the past few months, we have resurrected our code base, and gathered a dedicated Mantis team together who have worked hard to refine and improve the code and deliver important new features.

New Mantis là khách hàng duy nhất được viết tự nhiên cho Ethereum Classic và nó cung cấp mức độ đảm bảo, bảo mật và khả năng sử dụng vô song.
IOHK đã khởi động lại dự án Mantis để giảm thiểu các cuộc tấn công gần đây, cung cấp bảo mật nâng cao và thiết lập một phương tiện tương tác mạnh mẽ với chuỗi ETC.
Một cam kết để thúc đẩy sự đổi mới và tính bền vững nằm ở trung tâm của dự án.
Chúng tôi đang đặt mục tiêu cung cấp thu nhập tài trợ ổn định với việc thiết lập một proto-treasury để nuôi dưỡng sự phát triển và tăng trưởng trong tương lai.
Thần chú này tái khởi động đại diện cho đỉnh cao của một dự án mà chúng tôi đã làm việc một thời gian.
Trong vài tháng qua, chúng tôi đã hồi sinh cơ sở mã của mình và tập hợp một nhóm Mantis chuyên dụng với nhau, những người đã làm việc chăm chỉ để tinh chỉnh và cải thiện mã và cung cấp các tính năng mới quan trọng.

## **What is the Mantis project?**

## ** Dự án Mantis là gì? **

Mantis is a project that is built for the community, specifically designed for the developers, wallet users, and infrastructure providers to enable direct interaction with the ETC blockchain. Essentially, it is a place where future development can evolve and be tested by the community. The Mantis release includes the following components:

Mantis là một dự án được xây dựng cho cộng đồng, được thiết kế dành riêng cho các nhà phát triển, người dùng ví và nhà cung cấp cơ sở hạ tầng để cho phép tương tác trực tiếp với blockchain ETC.
Về cơ bản, đây là nơi phát triển trong tương lai có thể phát triển và được cộng đồng kiểm tra.
Bản phát hành Mantis bao gồm các thành phần sau:

- Mantis client - a CLI tool that connects to other clients in a peer-to-peer manner to allow users to communicate with the ETC chain, send and receive transactions, sync the blockchain data, execute and validate smart contracts, and deploy new smart contracts on-chain.

- MANTIS Client- Một công cụ CLI kết nối với các máy khách khác theo cách ngang hàng để cho phép người dùng giao tiếp với chuỗi ETC, gửi và nhận giao dịch, đồng bộ hóa dữ liệu blockchain, thực thi và xác nhận các hợp đồng thông minh và triển khai thông minh mới
hợp đồng trên chuỗi.

- Mantis wallet - a node wallet with incorporated graphical user interface (GUI), which connects to both mainnet and the Sagano and Mordor testnets. 

- Ví Mantis - Một ví nút có giao diện người dùng đồ họa được kết hợp (GUI), kết nối với cả testnet Mainnet và Sagano và Mordor.

- Mantis faucet - enables developers to receive testnet funds for use on the Sagano and Mordor testnets.

- Vòi Mantis - Cho phép các nhà phát triển nhận được các quỹ Testnet để sử dụng trên TestNets Sagano và Mordor.

- Mantis explorer - allows tracking recent activities and transactions in regards to the ETC chain, covering the ETC mainnet, and Sagano and Mordor testnets. 

- Mantis Explorer - Cho phép theo dõi các hoạt động và giao dịch gần đây liên quan đến chuỗi ETC, bao gồm ETC Mainnet, và TestNets Sagano và Mordor.

Please visit the [Mantis website](https://mantisclient.io/) where you can download the latest version of both the Mantis client and wallet.

Vui lòng truy cập [Trang web Mantis] (https://mantisclient.io/) nơi bạn có thể tải xuống phiên bản mới nhất của cả Client Client và Wallet.

Mantis software implements the official Ethereum Classic specification and Ethereum Classic Improvement Proposals [(ECIPs)](https://ecips.ethereumclassic.org/) introduced by ongoing efforts and discussed across teams in the ecosystem. The project has undergone a number of enhancements in terms of adding robustness and variety to the client offering, including optimizations and network upgrades that improve network security, sustainability, and performance in the long term. It has been developed from the ground up and built in 100% Scala code, a functional programming language that offers security guarantees that other languages do not. Mantis features include stable peer discovery, pruning, fast synchronization, and newly implemented checkpointing (for 51% attack resistance) and proto-treasury (for long-term sustainability). Let’s take a closer look at these features.

Phần mềm Mantis thực hiện các đề xuất cải tiến cổ điển Ethereum chính thức và Ethereum Classic [((ECIP)] (https://ecips.ethereumClassic.org/) được giới thiệu bởi những nỗ lực liên tục và thảo luận giữa các nhóm trong hệ sinh thái.
Dự án đã trải qua một số cải tiến về việc thêm sự mạnh mẽ và đa dạng cho việc cung cấp của khách hàng, bao gồm tối ưu hóa và nâng cấp mạng để cải thiện bảo mật mạng, tính bền vững và hiệu suất trong dài hạn.
Nó đã được phát triển từ đầu và được xây dựng theo mã Scala 100%, một ngôn ngữ lập trình chức năng cung cấp các đảm bảo bảo mật mà các ngôn ngữ khác không có.
Các tính năng bọ ngựa bao gồm khám phá ngang hàng ổn định, cắt tỉa, đồng bộ hóa nhanh và kiểm tra mới được triển khai (đối với khả năng chống tấn công 51%) và proto-breasury (cho tính bền vững lâu dài).
Hãy cùng xem xét kỹ hơn về các tính năng này.

## **Checkpointing**

## ** CheckPoining **

*Persistence* and *liveness* are two crucial properties that a transaction ledger should possess. It is a proven fact that both persistence and liveness suffer when the adversarial mining power in the proof of work surpasses 50%, and in the recent year, ETC has undergone several double-spending attacks prompted by the creation of large chain reorganizations. Considering that persistence and liveness were not guaranteed within the ETC network, we sought to implement protocol changes that will re-establish persistence and liveness under current network conditions, and *checkpointing* is one of the proposed solutions. 

* Sự kiên trì* và* LIGHLIVE* là hai thuộc tính quan trọng mà sổ cái giao dịch nên sở hữu.
Một thực tế đã được chứng minh là cả sự kiên trì và khả năng sinh học đều phải chịu đựng khi sức mạnh khai thác bất lợi trong bằng chứng công việc vượt quá 50%, và trong năm gần đây, v.v.
Xem xét rằng sự kiên trì và khả năng sống không được đảm bảo trong mạng ETC, chúng tôi đã tìm cách thực hiện các thay đổi giao thức sẽ thiết lập lại sự kiên trì và khả năng sinh hoạt trong các điều kiện mạng hiện tại và * kiểm tra * là một trong những giải pháp được đề xuất.

Checkpointing ensures that the protocol is unaltered, by using the *k* parameter, or depth parameter, where every *k* block gets irreversibly "checkpointed", meaning that no one can ever drop or revert it. A trusted authority can choose the block on which to issue a checkpoint, which means that they can decide which block becomes the canonical chain that all parties should follow. This trusted authority must run continuously and is responsible for publishing the checkpoint to the network. Checkpointing ensures that the protocol is unaltered with regards to mining. The mining rewards are not affected and the checkpointing federation can only issue checkpoints on blocks that have valid proof of work and cannot mint blocks on its own. 

Kiểm tra đảm bảo rằng giao thức không được thay đổi, bằng cách sử dụng tham số * K * hoặc tham số độ sâu, trong đó mỗi khối * K * đều được "Checkpound" không thể đảo ngược, có nghĩa là không ai có thể thả hoặc hoàn nguyên nó.
Một cơ quan đáng tin cậy có thể chọn khối để phát hành một trạm kiểm soát, điều đó có nghĩa là họ có thể quyết định khối nào trở thành chuỗi kinh điển mà tất cả các bên nên tuân theo.
Cơ quan đáng tin cậy này phải chạy liên tục và chịu trách nhiệm xuất bản điểm kiểm tra lên mạng.
Kiểm tra đảm bảo rằng giao thức không thay đổi liên quan đến khai thác.
Các phần thưởng khai thác không bị ảnh hưởng và Liên đoàn kiểm tra chỉ có thể phát hành các điểm kiểm tra trên các khối có bằng chứng công việc hợp lệ và không thể tự mình tạo ra các khối.

Checkpointing is now implemented within the Mantis project, and according to our recent [ECIP comparison for 51% attack resistance](https://static.iohk.io/docs/etc/ecip-comparison-for-51-attack-resistance.pdf), it provides far greater, and importantly formally proven, security against these types of attacks. It is important that any 51% attack mitigation is truly robust enough to give absolute certainty to ETC holders, users, and service providers that their transactions will be secure.

Kiểm tra hiện được thực hiện trong dự án Mantis và theo [so sánh ECIP gần đây của chúng tôi cho khả năng chống tấn công 51%] (https://static.iohk.io/docs/etc/ecip-comparison-for-51-tack-fresistance.
PDF), nó cung cấp bảo mật lớn hơn và quan trọng được chứng minh chính thức đối với các loại tấn công này.
Điều quan trọng là bất kỳ giảm thiểu tấn công 51% nào cũng thực sự đủ mạnh mẽ để cung cấp sự chắc chắn tuyệt đối cho chủ sở hữu, người dùng và nhà cung cấp dịch vụ mà các giao dịch của họ sẽ được bảo mật.

## **Proto-Treasury**

## ** proto-boolury **

For the longer-term health and success of the ETC ecosystem, we position network growth, sustainability, and innovation as key elements to ensure network security. With that in mind, we are implementing a proto-treasury system within the Mantis project to establish a steady funding income. A well-developed governance strategy will enable effective, distributed funding for the long-term development of Mantis, whereas a decentralized treasury would ensure two important things for the future of the ecosystem:

Đối với sức khỏe và thành công lâu dài của hệ sinh thái ETC, chúng tôi định vị tăng trưởng mạng, tính bền vững và đổi mới là các yếu tố chính để đảm bảo an ninh mạng.
Với ý nghĩ đó, chúng tôi đang thực hiện một hệ thống bảo lãnh proto trong dự án Mantis để thiết lập thu nhập tài trợ ổn định.
Một chiến lược quản trị được phát triển tốt sẽ cho phép tài trợ phân tán, hiệu quả cho sự phát triển dài hạn của Thần chú, trong khi Kho bạc phi tập trung sẽ đảm bảo hai điều quan trọng cho tương lai của hệ sinh thái:

- Firstly, it would provide a permanent ongoing source of funding for the ETC network. while increasing the value of the ecosystem and promoting greater developer engagement. 

- Thứ nhất, nó sẽ cung cấp một nguồn tài trợ liên tục vĩnh viễn cho mạng lưới ETC.
trong khi tăng giá trị của hệ sinh thái và thúc đẩy sự tham gia của nhà phát triển lớn hơn.

- Secondly, it would provide a distributed and transparent funding mechanism, which lets the ETC community determine its future growth and enable the sustainability required for innovation and growth.

- Thứ hai, nó sẽ cung cấp một cơ chế tài trợ phân tán và minh bạch, cho phép cộng đồng ETC xác định sự tăng trưởng trong tương lai của nó và cho phép tính bền vững cần thiết cho sự đổi mới và tăng trưởng.

Establishing the treasury for funding purposes ensures a clear vision of the substantial system maintenance focused to obtain innovation and diversity from other projects, including proof of stake (PoS) and newer blockchains. This solution is straightforward in its optimization for speed and implementation.

Thiết lập Kho bạc cho các mục đích tài trợ đảm bảo một tầm nhìn rõ ràng về việc bảo trì hệ thống đáng kể tập trung để có được sự đổi mới và đa dạng từ các dự án khác, bao gồm Proof of Stake (POS) và các blockchain mới hơn.
Giải pháp này rất đơn giản trong việc tối ưu hóa tốc độ và thực hiện.

The proposal foresees to distribute 80% of existing mining rewards to miners and 20% to the proto-treasury smart contract. The treasury will be controlled by the community and will enable a decentralized, collaborative decision-making process, offering an opt-in type collaboration for those who are interested.

Đề xuất dự đoán để phân phối 80% phần thưởng khai thác hiện có cho các công ty khai thác và 20% cho hợp đồng thông minh Proto-Treasury.
Kho bạc sẽ được cộng đồng kiểm soát và sẽ cho phép quy trình ra quyết định hợp tác, phi tập trung, cung cấp sự hợp tác loại chọn tham gia cho những người quan tâm.

## **What’s next?**

## **Cái gì tiếp theo?**

As much as we’re excited about the Mantis relaunch, it should be stressed that its capability won’t be limited to just the features outlined here. Mantis is an evolving project and right now we are establishing its foundational building blocks and running rigorous security audits. Further down the road, it will see more performance improvements in terms of CPU, GPU and ASICs compatibility, a new proof-of-work consensus protocol and algorithm introduction (PRISM consensus, Keccak256 algorithm) and, of course, additional enhancements for better interoperability and speed of transaction processing. You can also find out more by reading the [Mantis documentation](https://docs.mantisclient.io/) and joining the [Mantis discord](https://discord.com/invite/7vUyWrN33p) to stay up to date on all things Mantis or Ethereum Classic. Check out the Crowdcast launch event for the full Mantis showcase (and a keynote from Charles Hoskinson) and follow the Mantis team on [Twitter](https://twitter.com/Mantis_IO/) to get the latest updates! 

Nhiều như chúng tôi rất vui mừng về việc khởi động lại Mantis, cần nhấn mạnh rằng khả năng của nó đã giành được giới hạn chỉ trong các tính năng được nêu ở đây. Mantis là một dự án đang phát triển và ngay bây giờ chúng tôi đang thiết lập các khối xây dựng nền tảng của mình và thực hiện kiểm toán bảo mật nghiêm ngặt. Ngoài ra, nó sẽ thấy nhiều cải tiến hiệu suất hơn về CPU, khả năng tương thích GPU và ASICS, một giao thức đồng thuận bằng chứng làm việc mới và giới thiệu thuật toán (đồng thuận Prism, thuật toán KECCAK256) và, tất nhiên, cải tiến bổ sung cho khả năng tương tác tốt hơn và tốc độ xử lý giao dịch. Bạn cũng có thể tìm hiểu thêm bằng cách đọc [tài liệu Mantis] (https://docs.mantisclient.io/) và tham gia [Mantis Discord] (https://discord.com/invite/7vuywrn33p) Trên tất cả mọi thứ Mantis hoặc Ethereum Classic. Kiểm tra sự kiện ra mắt của đám đông cho Showcase Mantis đầy đủ (và một bài phát biểu quan trọng từ Charles Hoskinson) và theo dõi nhóm Mantis trên [Twitter] (https://twitter.com/Mantis_IO/) để nhận các bản cập nhật mới nhất!

