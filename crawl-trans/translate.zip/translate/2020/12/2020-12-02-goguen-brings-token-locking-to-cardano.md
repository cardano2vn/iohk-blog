# Goguen brings token locking to Cardano
### **We’re deploying the same process used for the Shelley update to deliver a smooth upgrade path to Goguen**
![](img/2020-12-02-goguen-brings-token-locking-to-cardano.002.png) 2 December 2020![](img/2020-12-02-goguen-brings-token-locking-to-cardano.002.png)[ Kevin Hammond](tmp//en/blog/authors/kevin-hammond/page-1/)![](img/2020-12-02-goguen-brings-token-locking-to-cardano.003.png) 7 mins read

![Kevin Hammond](img/2020-12-02-goguen-brings-token-locking-to-cardano.004.png)[](tmp//en/blog/authors/kevin-hammond/page-1/)
### [**Kevin Hammond**](tmp//en/blog/authors/kevin-hammond/page-1/)
Software Engineer

Engineering

- ![](img/2020-12-02-goguen-brings-token-locking-to-cardano.005.png)[](https://twitter.com/inputoutputhk "Twitter")

![Goguen brings token locking to Cardano](img/2020-12-02-goguen-brings-token-locking-to-cardano.006.jpeg)

Your browser does not support the audio element.

Trình duyệt của bạn không hỗ trợ các yếu tố âm thanh.

Cardano’s [development](https://roadmap.cardano.org/en/) has been conceived as a journey involving five overlapping development themes, each of which is underpinned by a *consensus* protocol – Ouroboros. As Cardano evolves, the protocol must also change as fresh functionality and utility are brought onto the platform. Upgrades require gradual changes to the network protocol and in this article, we will explain how these protocol changes are implemented and what goes on behind the scenes to make this process smooth and straightforward.

Cardano [phát triển] (https://roadmap.cardano.org/en/) đã được hình thành như một hành trình liên quan đến năm chủ đề phát triển chồng chéo, mỗi chủ đề được củng cố bởi một giao thức * đồng thuận * - ouroBoros.
Khi Cardano phát triển, giao thức cũng phải thay đổi khi chức năng và tiện ích mới được đưa lên nền tảng.
Nâng cấp yêu cầu thay đổi dần dần đối với giao thức mạng và trong bài viết này, chúng tôi sẽ giải thích cách các thay đổi giao thức này được thực hiện và những gì diễn ra đằng sau hậu trường để làm cho quá trình này suôn sẻ và đơn giản.

## **Reducing complexity in protocol changes**

## ** Giảm độ phức tạp trong thay đổi giao thức **

In the crypto world, any fundamental change to the blockchain protocol is referred to as a *hard fork*. In most blockchains, a hard fork is a ‘traumatic’ event that causes a – hopefully short – break in block production. In contrast, Cardano handles hard forks automatically, *without* stopping block production. This gives a uniquely smooth upgrade process that allows new features to be introduced easily and evolve the platform’s capabilities.

Trong thế giới tiền điện tử, bất kỳ thay đổi cơ bản nào đối với giao thức blockchain đều được gọi là *hard fork *.
Trong hầu hết các blockchains, một hard fork là một sự kiện ‘chấn thương gây ra sự phá vỡ - hy vọng ngắn - trong sản xuất khối.
Ngược lại, Cardano tự động xử lý các dĩa cứng, * mà không * dừng sản xuất khối.
Điều này mang lại một quy trình nâng cấp mượt mà duy nhất cho phép các tính năng mới được giới thiệu dễ dàng và phát triển các khả năng của nền tảng.

Traditionally, when a hard fork event occurs, the current protocol stops operating. All block producers upgrade to a new version of the software that implements the new block production rules or other changes. Having done this, the chain history is erased and block production is restarted. This means that a hard-forked chain will be different from the previous version, which can raise concerns over the integrity of the blockchain, or even lead to splits in the chain.

Theo truyền thống, khi một sự kiện khó khăn xảy ra, giao thức hiện tại ngừng hoạt động.
Tất cả các nhà sản xuất khối nâng cấp lên phiên bản mới của phần mềm thực hiện các quy tắc sản xuất khối mới hoặc các thay đổi khác.
Sau khi thực hiện điều này, lịch sử chuỗi bị xóa và sản xuất khối được khởi động lại.
Điều này có nghĩa là một chuỗi cứng sẽ khác với phiên bản trước, có thể gây lo ngại về tính toàn vẹn của blockchain, hoặc thậm chí dẫn đến việc chia tách trong chuỗi.

## **With Cardano, we do things differently**

## ** Với Cardano, chúng tôi làm những điều khác biệt **

The way that Cardano implements protocol changes is completely different from the way other blockchains handle hard forks. Our goal has always been to make these changes as seamless as possible. To enable a smooth transition, Cardano automatically preserves the history of previous blocks. This allows the protocol to be upgraded without radical interference to the chain. The previous state does not vanish. Rather, it is extended to include new capabilities. Instead of splitting into two different chains, Cardano combines the original blocks that comply with the current block production rules with new blocks that comply with the *new* block production rules. 

Cách mà Cardano thực hiện các thay đổi giao thức hoàn toàn khác với cách các blockchain khác xử lý các dĩa cứng.
Mục tiêu của chúng tôi luôn là thực hiện những thay đổi này một cách liền mạch nhất có thể.
Để cho phép chuyển đổi suôn sẻ, Cardano tự động bảo tồn lịch sử của các khối trước đó.
Điều này cho phép giao thức được nâng cấp mà không cần can thiệp triệt để vào chuỗi.
Nhà nước trước không biến mất.
Thay vào đó, nó được mở rộng để bao gồm các khả năng mới.
Thay vì chia thành hai chuỗi khác nhau, Cardano kết hợp các khối ban đầu tuân thủ các quy tắc sản xuất khối hiện tại với các khối mới tuân thủ các quy tắc sản xuất khối * mới *.

We have christened the mechanism that does this the [*hard-fork combinator*](https://docs.cardano.org/en/latest/explore-cardano/what-is-a-hard-fork-combinator.html) since it combines protocols without triggering interruptions or forcing a restart to Cardano. The [Byron to Shelley](https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-hard-fork/) transition used this technique for the first time. But the crucial point here is that Byron’s chain history did not disappear. Byron and Shelley chains appear ‘as one’, where the Shelley blocks extend the chain that was produced in the Byron era. Shifting from Byron’s Byzantine Fault Tolerance consensus protocol (OBFT) to Shelley’s Ouroboros Praos did not require block production to be stopped or all the nodes to update simultaneously. Instead, nodes could update independently. 

Chúng tôi đã đặt tên cho cơ chế thực hiện điều này [*Combinator hard-fork*] (https://docs.cardano.org/en/latest/explore-cardano/what-is-a-hard-pork-combinator.html)
Vì nó kết hợp các giao thức mà không kích hoạt gián đoạn hoặc buộc khởi động lại cho Cardano.
[Byron đến Shelley] (https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-hard-for
lần đầu tiên.
Nhưng điểm quan trọng ở đây là lịch sử chuỗi Byron không biến mất.
Các chuỗi Byron và Shelley xuất hiện ‘như một người, nơi Shelley khối mở rộng chuỗi được sản xuất trong kỷ nguyên Byron.
Chuyển từ Byron Byron Byzantine Byzantine Fault Protocol (OBFT) sang Shelley tựa Ouroboros PRAOS không yêu cầu dừng sản xuất khối hoặc tất cả các nút để cập nhật đồng thời.
Thay vào đó, các nút có thể cập nhật độc lập.

As Cardano and Ouroboros evolve, the hard fork combinator approach ensures that Goguen, Basho, and Voltaire blocks will all be held in a single chain. Features will be added at each stage in successive hard forks. Some new features may not even need a hard fork (where the consensus protocol does not change).

Khi Cardano và Ouroboros phát triển, cách tiếp cận tổ hợp hard Fork đảm bảo rằng các khối Goguen, Basho và Voltaire sẽ được tổ chức trong một chuỗi duy nhất.
Các tính năng sẽ được thêm vào ở mỗi giai đoạn trong các nút cứng liên tiếp.
Một số tính năng mới thậm chí có thể không cần một hard fork (trong đó giao thức đồng thuận không thay đổi).

## **The advent of token locking**

## ** Sự ra đời của khóa mã thông báo **

*Token locking* is a feature in the next protocol update that we are now preparing to deploy on mainnet. Internally, we are calling this development stage *Allegra* (named after Lord Byron’s daughter). Alongside the [integration of metadata](https://iohk.io/en/blog/posts/2020/11/03/getting-to-grips-with-metadata-on-cardano/) on the network, this is the next significant upgrade for Goguen. 

* Khóa mã thông báo* là một tính năng trong bản cập nhật giao thức tiếp theo mà chúng tôi hiện đang chuẩn bị triển khai trên Mainnet.
Trong nội bộ, chúng tôi đang gọi giai đoạn phát triển này * Allegra * (được đặt theo tên của con gái Lord Byron).
Bên cạnh [tích hợp siêu dữ liệu] (https://iohk.io/en/blog/posts/2020/11/03/getting-to-grips-with-metadata-on-cardano/) trên mạng, đây là
Nâng cấp quan trọng tiếp theo cho Goguen.

This represents a relatively small technical change to the consensus protocol, with a slight impact on the actual ledger. However, it is significant since it will prepare the platform for smart contracts and the creation of assets (in addition to ada) that run on Cardano. It also provides an important piece of Voltaire (governance) functionality, supporting a voting mechanism. Underlying this are system changes to ensure that we can continue to develop through future hard forks.

Điều này thể hiện một thay đổi kỹ thuật tương đối nhỏ đối với giao thức đồng thuận, với một tác động nhỏ đến sổ cái thực tế.
Tuy nhiên, nó rất có ý nghĩa vì nó sẽ chuẩn bị nền tảng cho các hợp đồng thông minh và việc tạo ra tài sản (ngoài ADA) chạy trên Cardano.
Nó cũng cung cấp một phần quan trọng của chức năng Voltaire (Quản trị), hỗ trợ cơ chế bỏ phiếu.
Bên dưới đây là những thay đổi hệ thống để đảm bảo rằng chúng ta có thể tiếp tục phát triển thông qua các dĩa cứng trong tương lai.

Token locking is a way of recording that a specific token is being used for some purpose. By *token*, we mean the items that are counted by the blockchain ledger. Until now, there has only been ada, but soon many other custom tokens will be able to use the Cardano platform. *Locking*, in this case, means ‘reserving’ a certain number of tokens for a specified period of time so they cannot be disposed of to gain a benefit (such as voting, or running a smart contract). 

Khóa mã thông báo là một cách ghi rằng một mã thông báo cụ thể đang được sử dụng cho một mục đích nào đó.
Bởi *mã thông báo *, chúng tôi có nghĩa là các mục được tính bởi sổ cái blockchain.
Cho đến bây giờ, chỉ có ADA, nhưng chẳng mấy chốc, nhiều mã thông báo tùy chỉnh khác sẽ có thể sử dụng nền tảng Cardano.
*Khóa*, trong trường hợp này, có nghĩa là ‘bảo lưu một số lượng mã thông báo nhất định trong một khoảng thời gian xác định để chúng không thể được xử lý để đạt được lợi ích (như bỏ phiếu hoặc điều hành hợp đồng thông minh).

We can compare this with earning dividends from shares. A person who buys shares in a company might be rewarded with a dividend from the company’s profits. Let’s assume that this dividend is paid at the end of each calendar year and requires the shareholder to have held their shares for the entire year. If they were to sell some of their shares at the end of November, they would lose *all* the dividends for those shares for that year. They have entered a conditional contract with the share provider that gives them something of value (here, a dividend) in return for holding a specific token (here, a share) for a certain period (in this case, a full calendar year).

Chúng tôi có thể so sánh điều này với việc kiếm cổ tức từ cổ phiếu.
Một người mua cổ phần trong một công ty có thể được thưởng cổ tức từ lợi nhuận của công ty.
Hãy giả sử rằng cổ tức này được trả vào cuối mỗi năm dương lịch và yêu cầu cổ đông đã nắm giữ cổ phần của họ trong cả năm.
Nếu họ bán một số cổ phiếu của họ vào cuối tháng 11, họ sẽ mất * tất cả * cổ tức cho những cổ phiếu đó cho năm đó.
Họ đã tham gia một hợp đồng có điều kiện với nhà cung cấp cổ phiếu cung cấp cho họ một cái gì đó có giá trị (ở đây, cổ tức) để đổi lại để giữ một mã thông báo cụ thể (ở đây, một cổ phiếu) trong một khoảng thời gian nhất định (trong trường hợp này, một năm lịch đầy đủ).

## **Enabling complex smart contracts**

## ** Kích hoạt các hợp đồng thông minh phức tạp **

Token locking is essential to enable complex smart contracts, and to support certain conditions, for example, when making a purchase. Thus, when someone enters into a contractual agreement to sell a house, a promise is made by the vendor that this house won’t be sold to another person – only to the person who actually pays the money. So, the token can represent the house in this case, whereas the ‘promise’ will be the actual token locking. If the house is sold to a third party, the promise in the contract will have been broken and any penalties will be invoked. This precise functionality will become available to contract providers with the introduction of token locking, using ada coins as the tokens. The ada may still be delegated to a stake pool as usual.

Khóa mã thông báo là điều cần thiết để kích hoạt các hợp đồng thông minh phức tạp và để hỗ trợ một số điều kiện nhất định, ví dụ, khi mua hàng.
Do đó, khi ai đó tham gia vào một thỏa thuận hợp đồng để bán một ngôi nhà, một lời hứa được thực hiện bởi nhà cung cấp rằng ngôi nhà này đã giành được cho người khác - chỉ cho người thực sự trả tiền.
Vì vậy, mã thông báo có thể đại diện cho ngôi nhà trong trường hợp này, trong khi ‘lời hứa sẽ là khóa mã thông báo thực tế.
Nếu ngôi nhà được bán cho bên thứ ba, lời hứa trong hợp đồng sẽ bị phá vỡ và bất kỳ hình phạt nào cũng sẽ được viện dẫn.
Chức năng chính xác này sẽ có sẵn cho các nhà cung cấp hợp đồng với việc giới thiệu khóa mã thông báo, sử dụng tiền ADA làm mã thông báo.
ADA vẫn có thể được giao cho một nhóm cổ phần như bình thường.

Within the Voltaire mechanism – which will be first used with Project Catalyst Fund2 voting – those ada holders who wish to participate in the voting process will need to ‘lock’ some ada. This will represent their voting rights, according to the amount of ada that they lock. It will prove that individuals have a certain number of votes, and eliminate the possibility of any votes being counted more than once. An individual cannot allocate more votes than they hold, or vote on contradictory ideas, or duplicate the votes.

Trong cơ chế Voltaire - lần đầu tiên được sử dụng với Bầu chọn Project Catalyst Fund2 - những người nắm giữ ADA muốn tham gia vào quá trình bỏ phiếu sẽ cần phải khóa một số ADA.
Điều này sẽ đại diện cho quyền biểu quyết của họ, theo số lượng ADA mà họ khóa.
Nó sẽ chứng minh rằng các cá nhân có một số phiếu bầu nhất định và loại bỏ khả năng bất kỳ phiếu bầu nào được tính nhiều lần.
Một cá nhân không thể phân bổ nhiều phiếu bầu hơn họ nắm giữ, hoặc bỏ phiếu cho các ý tưởng mâu thuẫn, hoặc nhân đôi số phiếu.

## **How is this implemented?**

## ** Điều này được thực hiện như thế nào? **

The introduction of token locking will happen behind the scenes. It will not affect the experience of ada holders because Daedalus and Yoroi wallets will automatically be updated without requiring any action from ada holders. 

Việc giới thiệu khóa mã thông báo sẽ xảy ra đằng sau hậu trường.
Nó sẽ không ảnh hưởng đến trải nghiệm của chủ sở hữu ADA vì ví Daedalus và Yoroi sẽ tự động được cập nhật mà không cần bất kỳ hành động nào từ chủ sở hữu ADA.

However, to implement the updated version of Ouroboros that will support token locking, all the nodes that run the network will have to ‘agree’ on it (that is, reach consensus). To achieve this, stake pool operators and exchanges that are running nodes will simply have to download the new version of the code and check its operation. IOHK’s development teams will support stake pool operators and monitor the network throughout this process to ensure that the transition goes smoothly. 

Tuy nhiên, để triển khai phiên bản cập nhật của OuroBoros sẽ hỗ trợ khóa mã thông báo, tất cả các nút chạy mạng sẽ phải đồng ý với nó (nghĩa là đạt được sự đồng thuận).
Để đạt được điều này, các nhà khai thác và trao đổi nhóm cổ phần đang chạy các nút sẽ chỉ cần tải xuống phiên bản mới của mã và kiểm tra hoạt động của nó.
Các nhóm phát triển của IOHK sẽ hỗ trợ các nhà khai thác nhóm cổ phần và giám sát mạng trong suốt quá trình này để đảm bảo rằng quá trình chuyển đổi diễn ra suôn sẻ.

Once token locking is running on the mainnet Cardano ledger, subsequent hard forks will introduce multi-asset and other smart contract capabilities. These will also be able to use token locking, opening up many new possibilities for Cardano users. In time, this will also lay the groundwork for creating non-fungible (unique) tokens on the Cardano blockchain. 

Khi khóa mã thông báo đang chạy trên sổ cái Mainnet Cardano, các Tay tựa cứng tiếp theo sẽ giới thiệu các khả năng hợp đồng thông minh và đa tài sản khác.
Chúng cũng sẽ có thể sử dụng khóa mã thông báo, mở ra nhiều khả năng mới cho người dùng Cardano.
Theo thời gian, điều này cũng sẽ đặt nền tảng để tạo ra các mã thông báo không có thể tạo ra (duy nhất) trên blockchain Cardano.

IOHK’s innovative hard fork combinator has given Cardano a secure, smooth path to regular protocol updates – each bringing fresh value and utility to the network while minimizing disruption and risk. We’re in the final stages of quality testing and will start the testnet deployment process this month, with an expectation of moving to the mainnet around the middle of December. During 2021, there will be more upgrades using the combinator – multi-asset support is coming up – as the Cardano platform continues to fulfill its potential. Stay tuned for an exciting year.

Combinator Fork Fork đổi mới của IOHK đã mang đến cho Cardano một con đường an toàn, trơn tru để cập nhật giao thức thông thường - mỗi người mang lại giá trị và tiện ích mới cho mạng trong khi giảm thiểu sự gián đoạn và rủi ro.
Chúng tôi trong giai đoạn cuối của thử nghiệm chất lượng và sẽ bắt đầu quá trình triển khai TestNet trong tháng này, với kỳ vọng sẽ chuyển đến Mainnet vào giữa tháng 12.
Trong năm 2021, sẽ có nhiều nâng cấp hơn khi sử dụng bộ kết hợp-hỗ trợ đa tài sản đang xuất hiện-khi nền tảng Cardano tiếp tục thực hiện tiềm năng của nó.
Hãy theo dõi một năm thú vị.

