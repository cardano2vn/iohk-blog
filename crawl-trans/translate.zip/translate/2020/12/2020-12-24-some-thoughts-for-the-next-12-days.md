# Some thoughts for the next 12 days
### **The past, present, and future in the spirit of an olde English counting song**
![](img/2020-12-24-some-thoughts-for-the-next-12-days.002.png) 24 December 2020![](img/2020-12-24-some-thoughts-for-the-next-12-days.002.png)[ Anthony Quinn](tmp//en/blog/authors/anthony-quinn/page-1/)![](img/2020-12-24-some-thoughts-for-the-next-12-days.003.png) 6 mins read

![Anthony Quinn](img/2020-12-24-some-thoughts-for-the-next-12-days.004.png)[](tmp//en/blog/authors/anthony-quinn/page-1/)
### [**Anthony Quinn**](tmp//en/blog/authors/anthony-quinn/page-1/)
Editor

Marketing & Communications

- ![](img/2020-12-24-some-thoughts-for-the-next-12-days.005.png)[](mailto:anthony.quinn@iohk.io "Email")
- ![](img/2020-12-24-some-thoughts-for-the-next-12-days.006.png)[](https://www.youtube.com/watch?v=KkcAic12dvc "YouTube")
- ![](img/2020-12-24-some-thoughts-for-the-next-12-days.007.png)[](https://www.linkedin.com/in/tony-quinn-frsa-0b093229 "LinkedIn")
- ![](img/2020-12-24-some-thoughts-for-the-next-12-days.008.png)[](https://twitter.com/IohkT "Twitter")

![Some thoughts for the next 12 days](img/2020-12-24-some-thoughts-for-the-next-12-days.009.png)

â€˜May you live in interesting timesâ€™ is a saying that seems apt for these turbulent days. The talk in the pastÂ few years has been of disruptive technologies â€“ then along comes the coronavirus to show the human race what disruption really means. And 2020 feels like a watershed time; what happens afterwards will not be the same as what has gone before. As the year ends, though, we turn to the future and want to look to brighter things and new horizons.

"Có thể bạn sống trong thời gian thú vị là một câu nói có vẻ thích hợp cho những ngày hỗn loạn này.
Cuộc nói chuyện trong vài năm qua là các công nghệ đột phá - sau đó cùng với coronavirus để cho loài người thấy sự gián đoạn thực sự có nghĩa là gì.
Và năm 2020 cảm thấy như một thời gian đầu nguồn;
Những gì xảy ra sau đó sẽ không giống như những gì đã đi trước đó.
Tuy nhiên, khi năm kết thúc, chúng ta chuyển sang tương lai và muốn tìm kiếm những thứ tươi sáng hơn và những chân trời mới.

So, in the spirit of ye olde English counting song [*The Twelve Days of Christmas*](https://www.classicfm.com/discover-music/occasions/christmas/twelve-12-days-of-christmas-lyrics-meaning/), we asked 12 of our people to tell us what had excited them in the past year, what they were doing now, and what they were looking forward to in the next year. Theyâ€™re a hard-working bunch, so expect plenty about Cardano, but they like to take time off too! Strangely, unlike in *The Twelve Days*, no-one talked about a partridge in a pear tree, five gold rings, or even 10 lords a-leaping. But you will find an octopus, security tips, and a classic piece of poetry.Â 

Vì vậy, theo tinh thần của bài hát đếm tiếng Anh của bạn
-meaning/), chúng tôi đã yêu cầu 12 người trong số chúng tôi nói với chúng tôi điều gì đã khiến họ phấn khích trong năm qua, những gì họ đang làm bây giờ và những gì họ đang mong đợi trong năm tới.
Họ là một nhóm làm việc chăm chỉ, vì vậy hãy mong đợi rất nhiều về Cardano, nhưng họ cũng thích dành thời gian nghỉ ngơi!
Thật kỳ lạ, không giống như trong *mười hai ngày *, không ai nói về một partridge trong một cây lê, năm vòng vàng, hoặc thậm chí 10 lãnh chúa a-loa.
Nhưng bạn sẽ tìm thấy một con bạch tuộc, mẹo bảo mật và một phần thơ cổ điển.

We hope the idea encourages you to look for the good things happening in your lives.

Chúng tôi hy vọng ý tưởng khuyến khích bạn tìm kiếm những điều tốt đẹp xảy ra trong cuộc sống của bạn.

However, we didnâ€™t want our content and web teams being dragged out of bed every day over Christmas, so weâ€™re publishing the pieces in four chunks to cover the 12 days, from December 25 to January 5. Here are the first four.

Tuy nhiên, chúng tôi không muốn các nhóm nội dung và web của chúng tôi bị kéo ra khỏi giường mỗi ngày vào Giáng sinh, vì vậy chúng tôi sẽ xuất bản các tác phẩm trong bốn phần để bao gồm 12 ngày, từ ngày 25 tháng 12 đến ngày 5 tháng 1.
Bốn đầu tiên.

## **Day 1. Duncan Coutts, technical architect**

## ** Ngày 1. Duncan Coutts, Kiến trúc sư kỹ thuật **

The great thing for me was getting Shelley out the door and demonstrating that we had done what we set out to do. We took a radically different approach to everyone else in blockchain with our high-assurance software engineering. A lot of that was partly on my head if it went wrong â€“ so it was very satisfying to see that it really did work! There has just been one bug in the consensus code since the [Shelley hard fork](https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-hard-fork/), and we knew about that from testing and had planned for it. This result has vindicated the formal-methods, Haskell testing approach.Â 

Điều tuyệt vời đối với tôi là đưa Shelley ra khỏi cửa và chứng minh rằng chúng tôi đã làm những gì chúng tôi đặt ra.
Chúng tôi đã thực hiện một cách tiếp cận hoàn toàn khác với những người khác trong blockchain với kỹ thuật phần mềm đảm bảo cao của chúng tôi.
Rất nhiều trong số đó là một phần trên đầu tôi nếu nó sai - Vì vậy, rất hài lòng khi thấy rằng nó thực sự đã hoạt động!
Chỉ có một lỗi trong mã đồng thuận kể từ [Shelley Hard Fork] (https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-
Hard-Fork/), và chúng tôi biết về điều đó từ việc thử nghiệm và đã lên kế hoạch cho nó.
Kết quả này đã chứng minh các phương pháp chính thức, phương pháp kiểm tra Haskell.â

Weâ€™ve had two smooth hard forks and shown that we can do changes to the ledger rules â€“ and only change the ledger rules. Everything else stays the same. The [modular approach we took in rewriting the Byron code](https://iohk.io/en/blog/posts/2020/04/07/architecting-shelley-an-interview-with-duncan-coutts-1/) means that altering things is not a whole system change, as would have been the case previously.Â 

Chúng tôi đã có hai bản cứng mượt mà và cho thấy rằng chúng tôi có thể thực hiện các thay đổi đối với các quy tắc sổ cái - và chỉ thay đổi các quy tắc sổ cái.
Mọi thứ khác vẫn giữ nguyên.
[Cách tiếp cận mô-đun mà chúng tôi đã thực hiện viết lại mã Byron] (https://iohk.io/en/blog/posts/2020/04/07/architecting-shelley-an-interview-with-duncan-coutts-1/)
có nghĩa là thay đổi mọi thứ không phải là toàn bộ thay đổi hệ thống, như đã từng xảy ra trước đây.

The [support for native assets](https://iohk.io/en/blog/posts/2020/12/08/native-tokens-on-cardano/) that weâ€™re bringing in at the moment is a big deal. It gives users most of the capabilities of ERC-20 and some other things besides. Looking ahead, adding Plutus will be the change that people really notice next year with the advent of smart contracts on Cardano.

[Hỗ trợ tài sản bản địa] (https://iohk.io/en/blog/posts/2020/12/08/native-tokens-on-cardano/) mà chúng tôi đang mang vào
thỏa thuận.
Nó cung cấp cho người dùng hầu hết các khả năng của ERC-20 và một số thứ khác ngoài việc.
Nhìn về phía trước, việc thêm Plutus sẽ là sự thay đổi mà mọi người thực sự chú ý vào năm tới với sự ra đời của các hợp đồng thông minh trên Cardano.

![](img/2020-12-24-some-thoughts-for-the-next-12-days.010.jpeg)

## **Day 2. Simon Thompson, senior research fellow**

## ** Ngày 2. Simon Thompson, Nghiên cứu viên cao cấp **

I keep on going back to this video on [*Wired* magazineâ€™s Facebook page](https://www.facebook.com/wired/videos/2865380683743188). And Iâ€™m not alone â€“ three million people have liked the page. Is it really an octopus dreaming?Â 

Tôi tiếp tục quay lại video này trên trang Facebook [* Wired* Tạp chí] (https://www.facebook.com/wired/video/2865380683743188).
Và tôi không đơn độc - ba triệu người đã thích trang này.
Nó thực sự là một con bạch tuộc mơ? Â

Right now, Iâ€™m planning the work weâ€™ll be doing in the first part of 2021, implementing [Marlowe on Cardano](https://iohk.io/en/blog/posts/2020/10/06/marlowe-industry-scale-finance-contracts-for-cardano/), and building the user-facing components to make it all usable.Â 

Ngay bây giờ, tôi đang lên kế hoạch cho công việc mà chúng tôi sẽ làm trong phần đầu tiên của năm 2021, thực hiện [Marlowe trên Cardano] (https://iohk.io/en/blog/posts/2020/10/06/
Marlowe-Industry-Pro-Finance-Contracts-for-cardano/) và xây dựng các thành phần hướng tới người dùng để làm cho tất cả có thể sử dụng được.

After that, Iâ€™m looking forward to the launch of Marlowe, giving everyone the chance to run financial contracts on a third-generation blockchain. In the meantime, chill out and watch that octopus â€“ it is truly cool!Â 

Sau đó, tôi đang mong chờ sự ra mắt của Marlowe, cho mọi người cơ hội điều hành các hợp đồng tài chính trên blockchain thế hệ thứ ba.
Trong khi đó, thư giãn và xem bạch tuộc đó - nó thực sự rất tuyệt! Â

![](img/2020-12-24-some-thoughts-for-the-next-12-days.010.jpeg)

## **Day 3. Dynal Patel, senior product manager**

## ** Ngày 3. Dynal Patel, Quản lý sản phẩm cao cấp **

Look at this blog piece predicting that Cardano could one day scale to [one million transactions a second](https://cointelegraph.com/news/cardano-releases-solution-that-scales-more-than-visas-payment-network). Thatâ€™s an amazing figure in the context of a blockchain â€“ well in excess of global payment systems such as Visa and Mastercard. Credit cards have been around since the 1950s and itâ€™s as long ago as 1997 that nCipher implemented cryptography on Arm chips for Visa and British Telecom to drive the online commerce weâ€™re so familiar with today. Of course, weâ€™re a way off the 1m tps figure yet, but coupling Cardano technology for microtransactions with [Atala Prism](https://www.atalaprism.io/), our decentralized identity platform, will open up a wave of applications. These will include secure devices for the internet of things, data for smart cities, and social-sharing networks that empower users to own, control and make money from their own data. For example, in Mongolia we are looking at ways of monitoring pollution. Here, service providers who need such data could pay local people to run sensors for collecting data.

Nhìn vào phần blog này dự đoán rằng Cardano một ngày có thể tỷ lệ lên [một triệu giao dịch một giây] (https://cointelegraph.com/news/cardano-releases-solution-that-scales-more-than-visas-payment-network ). Đó là một nhân vật tuyệt vời trong bối cảnh của một blockchain - vượt quá các hệ thống thanh toán toàn cầu như Visa và Mastercard. Thẻ tín dụng đã xuất hiện từ những năm 1950 và từ lâu năm 1997, NCIPHER đã thực hiện mật mã trên chip ARM cho Visa và British Telecom để thúc đẩy thương mại trực tuyến mà chúng tôi rất quen thuộc với ngày hôm nay. Tất nhiên, chúng tôi đã có một cách thoát khỏi con số TPS 1M, nhưng kết hợp công nghệ Cardano cho các giao dịch vi mô với [Atala Prism] (https://www.atalaprism.io/), nền tảng nhận dạng phi tập trung của chúng tôi, sẽ mở ra một sóng của các ứng dụng. Chúng sẽ bao gồm các thiết bị an toàn cho Internet vạn vật, dữ liệu cho các thành phố thông minh và các mạng chia sẻ xã hội trao quyền cho người dùng sở hữu, kiểm soát và kiếm tiền từ dữ liệu của chính họ. Ví dụ, ở Mông Cổ, chúng tôi đang xem xét các cách theo dõi ô nhiễm. Tại đây, các nhà cung cấp dịch vụ cần dữ liệu đó có thể trả tiền cho người dân địa phương để chạy các cảm biến để thu thập dữ liệu.

Right now Iâ€™m reading [*Blockchain Revolution*](http://blockchain-revolution.com/) by Don and Alex Tapscott. They discuss eight core functions ripe for disruption in the financial sector with the first being â€˜authenticating identity and valueâ€™ â€“ just what Atala Prism aims to do.Â 

Ngay bây giờ tôi đang đọc [*Cuộc cách mạng blockchain*] (http://blockchain-revolution.com/) của Don và Alex Tapscott.
Họ thảo luận về tám chức năng cốt lõi đã chín muồi cho sự gián đoạn trong lĩnh vực tài chính với bản sắc đầu tiên là bản sắc và giá trị " - chỉ là những gì Atala PRISM nhằm mục đích làm.

Iâ€™m looking forward to Atala deployments with our first clients. Prism enables peers to establish an identity that is verifiable, robust and cryptographically secure â€“ and we expect each implementation to have the potential to bring a million users into the Cardano ecosystem. On a personal note, I've recently stepped up to become the chair of [Bringing Smiles](https://www.bringingsmiles.de/), a children's charity. In 2021, we aim to expand our activities by raising funds to support selected children's charities across the world.

Tôi mong chờ triển khai Atala với các khách hàng đầu tiên của chúng tôi.
PRISM cho phép các đồng nghiệp thiết lập một danh tính có thể kiểm chứng, mạnh mẽ và bảo mật bằng mã hóa và chúng tôi hy vọng mỗi lần thực hiện sẽ có khả năng đưa một triệu người dùng vào hệ sinh thái Cardano.
Trên một ghi chú cá nhân, gần đây tôi đã bước lên để trở thành chủ tịch của [mang lại nụ cười] (https://www.bringingsmiles.de/), một tổ chức từ thiện của trẻ em.
Năm 2021, chúng tôi đặt mục tiêu mở rộng các hoạt động của mình bằng cách gây quỹ để hỗ trợ các tổ chức từ thiện trẻ em được chọn trên toàn thế giới.

![](img/2020-12-24-some-thoughts-for-the-next-12-days.010.jpeg)

## **Day 4. Aikaterini-Panagiota Stouka, researcher**

## ** Ngày 4. Aikaterini-Panagiota Stouka, nhà nghiên cứu **

2020 started with the exciting news that â€˜Reward sharing schemes for stake poolsâ€™, a paper I wrote with IOHKâ€™s education director Lars BrÃ¼njes, Professor Aggelos Kiayias at the University of Edinburgh and chief scientist at IOHK, and Professor Elias Koutsoupias at the University of Oxford, had been accepted for the [IEEE European Symposium on Security and Privacy](https://www.ieee-security.org/TC/EuroSP2020/accepted.html). This is one of the top peer-reviewed cyber security conferences and has an emphasis on building real systems, which is what weâ€™re helping to do with Cardano. Because of the coronavirus, however, it became an online-only event. This paper introduces the scheme on which Cardanoâ€™s incentives are based and a preprint had been available on [arXiv](https://arxiv.org/abs/1807.11218) since 2018. It was a great feeling to see our work accepted after years of research, many late nights, and lots of back and forth between theory and experiments trying to discover the most appropriate reward mechanism for decentralization.

Năm 2020 bắt đầu với những tin tức thú vị rằng các chương trình chia sẻ cho các nhóm cổ phần, một bài báo tôi đã viết với Giám đốc giáo dục của Iohk Koutsoupias tại Đại học Oxford, đã được chấp nhận cho [Hội nghị chuyên đề châu Âu của IEEE về an ninh và quyền riêng tư] (https://www.ieee-security.org/tc/eurosp2020/accepted.html). Đây là một trong những hội nghị bảo mật mạng được đánh giá hàng đầu và tập trung vào việc xây dựng các hệ thống thực, đó là những gì chúng tôi giúp làm với Cardano. Vì coronavirus, tuy nhiên, nó đã trở thành một sự kiện chỉ trực tuyến. Bài viết này giới thiệu chương trình mà các ưu đãi của Cardano dựa trên và một bản in đã có sẵn trên [arxiv] (https://arxiv.org/abs/1807.11218) kể từ năm 2018. Đó là một cảm giác tuyệt vời khi thấy công việc của chúng tôi được chấp nhận Sau nhiều năm nghiên cứu, nhiều đêm muộn và rất nhiều người qua lại giữa lý thuyết và thí nghiệm cố gắng khám phá cơ chế khen thưởng phù hợp nhất để phân cấp.

Right now, I am waiting for my examination after submitting my PhD thesis at Edinburgh. Iâ€™ve continued working with the same team on the reward mechanism. One problem we are investigating is incentivizing the pool operators to include in their blocks the registration certificates issued by other people who want to create a pool, even if these are likely to become competitors.

Ngay bây giờ, tôi đang chờ kỳ thi của mình sau khi gửi luận án tiến sĩ tại Edinburgh.
Tôi tiếp tục làm việc với cùng một nhóm về cơ chế phần thưởng.
Một vấn đề chúng tôi đang điều tra là khuyến khích các nhà khai thác nhóm đưa vào các khối của họ, các chứng chỉ đăng ký được cấp bởi những người khác muốn tạo ra một nhóm, ngay cả khi những điều này có khả năng trở thành đối thủ cạnh tranh.

I am certainly looking forward to completing my PhD. I also plan to continue collaborating with my co-authors and other members of IOHK as well, and to carry on exploring reward-sharing mechanisms for various types of collaborative projects. A relevant blog post written by Prof Kiayias [categorizes reward mechanisms](https://iohk.io/en/blog/posts/2020/11/30/blockchain-reward-sharing-a-comparative-systematization-from-first-principles/) and gives an insight into this research. In terms of Cardano, Iâ€™m watching the increase in the *k* parameter, which relates to the number of pools we expect to have, in an ideal scenario, in a stable state called the [Nash equilibrium](https://iohk.io/en/blog/posts/2017/02/16/a-proof-of-stake-lecture-at-oxford-university/). This increase will give more pools the opportunity to become competitive and will enhance decentralization.Â 

Tôi chắc chắn mong muốn hoàn thành bằng tiến sĩ của mình.
Tôi cũng có kế hoạch tiếp tục hợp tác với các đồng tác giả của tôi và các thành viên khác của IOHK, và tiếp tục khám phá các cơ chế chia sẻ phần thưởng cho nhiều loại dự án hợp tác khác nhau.
Một bài đăng trên blog có liên quan được viết bởi Giáo sư Kiayias [phân loại các cơ chế thưởng] (https://iohk.io/en/blog/posts/2020/11/30/blockchain-reward-sharing-a-comparative-systematization-from
Nguyên tắc/) và đưa ra một cái nhìn sâu sắc về nghiên cứu này.
Về mặt Cardano, tôi đang xem sự gia tăng tham số * K *, liên quan đến số lượng nhóm chúng tôi mong đợi, trong một kịch bản lý tưởng, ở trạng thái ổn định gọi là [trạng thái cân bằng Nash] (https:/
/iohk.io/en/blog/posts/2017/02/16/a-proof-of-pete-spoture-at-oxford-university/).
Sự gia tăng này sẽ mang lại cho nhiều nhóm hơn cơ hội để trở nên cạnh tranh và sẽ tăng cường phân cấp.

*The next batch of 12 Days thoughts will be published on December 29*

*Lô 12 ngày tiếp theo sẽ được xuất bản vào ngày 29 tháng 12*

