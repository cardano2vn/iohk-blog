# Devnets: Building bridges to developer communities
### **Our new interoperability platforms (devnets) will expand Cardano's reach with support for the Solidity/Ethereum communities and beyond**
![](img/2020-12-17-devnets-building-bridges-to-developer-communities.002.png) 17 December 2020![](img/2020-12-17-devnets-building-bridges-to-developer-communities.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2020-12-17-devnets-building-bridges-to-developer-communities.003.png) 6 mins read

![Tim Harrison](img/2020-12-17-devnets-building-bridges-to-developer-communities.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2020-12-17-devnets-building-bridges-to-developer-communities.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2020-12-17-devnets-building-bridges-to-developer-communities.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2020-12-17-devnets-building-bridges-to-developer-communities.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2020-12-17-devnets-building-bridges-to-developer-communities.008.png)[](https://github.com/timbharrison "GitHub")

![Devnets: Building bridges to developer communities](img/2020-12-17-devnets-building-bridges-to-developer-communities.009.jpeg)

Your browser does not support the audio element.

Trình duyệt của bạn không hỗ trợ các yếu tố âm thanh.

A blockchain environment is not a static one. Blockchains evolve as their communities grow and learn, and Cardano is no exception. 

Một môi trường blockchain không phải là một trường tĩnh.
Blockchain phát triển khi cộng đồng của họ phát triển và học hỏi, và Cardano cũng không ngoại lệ.

With every development stage, Cardano's core functionality has been expanded with new features: Shelley added delegation, stake pools, and decentralization to Byronâ€™s core transactional capability. Goguen is now starting to bring fresh utility, from metadata to smart contracts and native tokens. Voltaire introduces a treasury and voting system, and weâ€™ve seen the early steps of this process with Project Catalyst and the first ever public funding round for Cardano community ideas.

Với mọi giai đoạn phát triển, chức năng cốt lõi của Cardano đã được mở rộng với các tính năng mới: Shelley thêm phái đoàn, nhóm cổ phần và phân cấp cho khả năng giao dịch cốt lõi của Byron.
Goguen hiện đang bắt đầu mang lại tiện ích mới, từ siêu dữ liệu đến các hợp đồng thông minh và mã thông báo bản địa.
Voltaire giới thiệu một hệ thống Kho bạc và bỏ phiếu, và chúng tôi đã thấy những bước đầu của quá trình này với Project Catalyst và vòng tài trợ công cộng đầu tiên cho các ý tưởng cộng đồng Cardano.

We introduced transaction metadata in November, an important first element in creating new utility and commercial use cases. We recently deployed the first pre-production environment for native tokens. Following that will be token creation and ERC-20 conversion. Plutus and Marlowe, Cardanoâ€™s native smart contract languages are under active development and will be released in 2021, opening up the platform for developers to create fresh solutions and power exciting new use cases. 

Chúng tôi đã giới thiệu siêu dữ liệu giao dịch vào tháng 11, một yếu tố đầu tiên quan trọng trong việc tạo ra các trường hợp tiện ích và sử dụng thương mại mới.
Gần đây chúng tôi đã triển khai môi trường tiền sản xuất đầu tiên cho mã thông báo gốc.
Sau đó sẽ là tạo mã thông báo và chuyển đổi ERC-20.
Plutus và Marlowe, các ngôn ngữ hợp đồng thông minh bản địa của Cardano đang được phát triển tích cực và sẽ được phát hành vào năm 2021, mở ra nền tảng cho các nhà phát triển để tạo ra các giải pháp mới và cung cấp năng lượng cho các trường hợp sử dụng mới thú vị.

All of these Goguen elements play their part in delivering Cardano's ultimate objective: a truly decentralized and self-sustaining platform. All the time encouraging deeper community engagement and growth by creating fresh opportunities. 

Tất cả các yếu tố Goguen này đóng vai trò của họ trong việc cung cấp mục tiêu cuối cùng của Cardano: một nền tảng thực sự phi tập trung và tự duy trì.
Tất cả thời gian khuyến khích sự tham gia và tăng trưởng của cộng đồng sâu sắc hơn bằng cách tạo ra những cơ hội mới.

We have a vibrant and skilled community, arguably one of the strongest and smartest in the crypto space. And in line with our avowedly non-â€™maximalistâ€™ and open approach, we want to reach out to other communities and bring them onboard too.

Chúng tôi có một cộng đồng sôi động và lành nghề, được cho là một trong những cộng đồng mạnh nhất và thông minh nhất trong không gian tiền điện tử.
Và phù hợp với cách tiếp cận tối đa và mở rộng của chúng tôi, chúng tôi muốn tiếp cận với các cộng đồng khác và đưa họ lên tàu.

As outlined in [Charles Hoskinsonâ€™s recent video](https://www.youtube.com/watch?v=k8a6tX53YPs), Cardano's next strategic move will be the addition of a range of devnets to draw fresh developer communities into the wider Cardano ecosystem.

Như đã nêu trong video gần đây của Charles Hoskinson] (https://www.youtube.com/watch?v=K8A6TX53YPS), động thái chiến lược tiếp theo của Cardano sẽ là việc bổ sung một phạm vi của các cộng đồng phát triển mới vào
Hệ sinh thái Cardano rộng hơn.

These devnets will act as â€˜bridgesâ€™ between developer communities, providing development environments, virtual machines and suites of developer tools so new applications can be tested in an environment as close to the 'real world' as possible.

Các DevNet này sẽ đóng vai trò là "cộng đồng phát triển, cung cấp môi trường phát triển, máy ảo và bộ công cụ nhà phát triển để các ứng dụng mới có thể được kiểm tra trong môi trường gần với" thế giới thực "nhất có thể.

### **Understanding the devnets**

### ** Hiểu về DevNets **

After some initial exploratory work back in 2018, we are now restarting and accelerating the K Ethereum Virtual Machine (KEVM) program. The new [KEVM devnet](https://developers.cardano.org/en/virtual-machines/kevm/overview/) is the first of several devnets weâ€™re building out over the next month or so. The EVM runs within the K Framework, a system for specifying languages and VMs, and then deriving tools such as interpreters, type checkers, equivalence checkers, debuggers, etc. for these languages. (The EVM is what runs smart contracts in the Ethereum network.)

Sau một số công việc thăm dò ban đầu trở lại vào năm 2018, chúng tôi hiện đang khởi động lại và tăng tốc chương trình K Ethereum Virtual Machine (KEVM).
[KEVM DevNet mới] (https://developers.cardano.org/en/virtual-machines/kevm/overview/) là lần đầu tiên trong số một số Devnets chúng tôi xây dựng trong tháng tới.
EVM chạy trong khung K, một hệ thống chỉ định ngôn ngữ và VM, sau đó lấy các công cụ như phiên dịch, trình kiểm tra loại, trình kiểm tra tương đương, trình gỡ lỗi, v.v. cho các ngôn ngữ này.
(EVM là những gì điều hành các hợp đồng thông minh trong mạng Ethereum.)

K applies formal reasoning and mathematical rigor for the highest levels of assurance. It enables developers to define or implement the formal semantics of a programming language in an intuitive and modular way. K also generates an executable, 'correct by construction VM' from its formal specification, which is fast and powerful enough to run real programs and smart contracts. This effectively means that software should perform the required functions and *nothing else*, for all possible inputs, and have verifiable evidence. 

K áp dụng lý luận chính thức và sự nghiêm ngặt về toán học cho mức độ đảm bảo cao nhất.
Nó cho phép các nhà phát triển xác định hoặc thực hiện ngữ nghĩa chính thức của ngôn ngữ lập trình theo cách trực quan và mô -đun.
K cũng tạo ra một thực thi, 'Đúng bởi VM xây dựng' từ đặc điểm kỹ thuật chính thức của nó, đủ nhanh và mạnh để chạy các chương trình thực tế và hợp đồng thông minh.
Điều này có nghĩa là phần mềm nên thực hiện các chức năng cần thiết và *không có gì khác *, cho tất cả các đầu vào có thể và có bằng chứng có thể kiểm chứng được.

Our long term vision â€“ in association with our partners at Runtime Verification â€“ is to build a K environment where we can just 'plug-and-play' new VMs. You can hear more about the goals of K from the team at Runtime Verification in [this video segment](https://youtu.be/lj9SlvOIBgU?t=1628) from the Cardano monthly show.

Tầm nhìn dài hạn của chúng tôi-kết hợp với các đối tác của chúng tôi khi xác minh thời gian chạy-là xây dựng một môi trường k nơi chúng tôi có thể chỉ có các máy ảo mới 'cắm và chơi'.
Bạn có thể nghe thêm về các mục tiêu của K từ nhóm khi xác minh thời gian chạy trong [phân đoạn video này] (https://youtu.be/lj9slvoibgu?t=1628) từ chương trình hàng tháng của Cardano.

The KEVM devnet, which is aimed at the Solidity/Ethereum community, will enable full backward compatibility with Ethereum. Because Solidity is a high-level language similar to JavaScript and C++, it cannot be directly executed by the EVM. Solidity programs must be compiled to assembly language (EVM bytecode) first, so they can run on the KEVM. 

KEVM DevNet, nhằm vào cộng đồng Solity/Ethereum, sẽ cho phép tương thích hoàn toàn ngược với Ethereum.
Bởi vì độ rắn là ngôn ngữ cấp cao tương tự như JavaScript và C ++, nên nó không thể được thực hiện trực tiếp bởi EVM.
Các chương trình vững chắc phải được biên dịch cho ngôn ngữ lắp ráp (mã byte EVM) trước tiên, vì vậy chúng có thể chạy trên KEVM.

KEVM will allow developers to write applications in Solidity, EVM code, or [Glow](https://www.youtube.com/watch?v=jWyBjjgdWWU), providing toolkits to compile and deploy them on the devnet for (close to real-world) testing. We also plan to soon add [Truffle](https://www.trufflesuite.com/docs/truffle/overview) integration, further increasing developer usability.

KEVM sẽ cho phép các nhà phát triển viết các ứng dụng bằng cách vững chắc, mã EVM hoặc [Glow] (https://www.youtube.com/watch?v=JWYBJJGDWWU), cung cấp bộ công cụ để biên dịch và triển khai chúng trên
-world) kiểm tra.
Chúng tôi cũng có kế hoạch sớm thêm [Truffle] (https://www.trufflesuite.com/docs/truffle/overview) Tích hợp, tăng khả năng sử dụng của nhà phát triển.

### **Glow**

### **Ánh sáng**

Solidity is by far the most popular higher programming language compiling to EVM bytecode, but by no means the only one. One fascinating alternative to Solidity is Glow, developed by our partner MuKn.

Sự vững chắc cho đến nay là ngôn ngữ lập trình cao hơn phổ biến nhất được biên dịch cho EVM bytecode, nhưng không có nghĩa là duy nhất.
Một thay thế hấp dẫn cho sự vững chắc là phát sáng, được phát triển bởi đối tác của chúng tôi MUKN.

Glow is a â€˜high-levelâ€™ language (other examples of high level languages include JavaScript, Python etc.) designed to allow writing highly secure financial contracts intuitively. Glow follows the 'correct-by-construction' doctrine to avoid common pitfalls and potentially costly bugs. Glow can prove that contracts written in this language have certain desirable properties, no matter what other participants in the contract do or do not do.

Glow là ngôn ngữ cấp độ cao (các ví dụ khác về các ngôn ngữ cấp cao bao gồm JavaScript, Python, v.v.) được thiết kế để cho phép viết các hợp đồng tài chính an toàn cao bằng trực giác.
Glow tuân theo học thuyết 'chính xác theo xây dựng' để tránh những cạm bẫy thông thường và những lỗi có khả năng tốn kém.
Glow có thể chứng minh rằng các hợp đồng được viết bằng ngôn ngữ này có một số thuộc tính mong muốn nhất định, bất kể những người tham gia khác trong hợp đồng làm gì hoặc không làm gì.

Glow has been designed with interoperability in mind. There will be Glow compilers targeting many diverse platforms and blockchains, making code reuse so much simpler and more practicable.

Glow đã được thiết kế với khả năng tương tác trong tâm trí.
Sẽ có các trình biên dịch phát sáng nhắm mục tiêu nhiều nền tảng và blockchain khác nhau, làm cho việc tái sử dụng mã đơn giản và thực tế hơn rất nhiều.

This will be the next devnet to be deployed. Most of the core development work is now done, ready for final QA and deployment in January 2021.

Đây sẽ là DevNet tiếp theo được triển khai.
Hầu hết các công việc phát triển cốt lõi hiện đã được thực hiện, sẵn sàng cho QA cuối cùng và triển khai vào tháng 1 năm 2021.

### **IELE - A foundation for third-generation blockchains**

### ** IELE - Một nền tảng cho blockchains thế hệ thứ ba **

Full compatibility with the EVM is convenient and attractive to many experienced developers familiar with Ethereum, but KEVM inevitably also inherits the EVMâ€™s weaknesses.

Khả năng tương thích đầy đủ với EVM là thuận tiện và hấp dẫn đối với nhiều nhà phát triển có kinh nghiệm quen thuộc với Ethereum, nhưng Kevm chắc chắn cũng thừa hưởng những điểm yếu của EVM.

For this reason weâ€™ll offer a more advanced and secure alternative in the form of our IELE devnet. The IELE (pronounced *yeah-leh*) virtual machine, also being developed by our partner Runtime Verification, is similar to the EVM, but much more secure. For example, it uses arbitrary precision integers, immediately eliminating many of the EVM's vulnerabilities. IELE is also register-based, not stack-based like the EVM, making it much easier for developers to write IELE bytecode by hand directly.

Vì lý do này, chúng tôi sẽ cung cấp một sự thay thế tiên tiến và an toàn hơn dưới dạng iele devnet của chúng tôi.
Máy ảo IELE (phát âm *Yeah-Leh *), cũng được phát triển bởi xác minh thời gian chạy đối tác của chúng tôi, tương tự như EVM, nhưng an toàn hơn nhiều.
Ví dụ, nó sử dụng các số nguyên chính xác tùy ý, ngay lập tức loại bỏ nhiều lỗ hổng của EVM.
IELE cũng dựa trên đăng ký, không dựa trên ngăn xếp như EVM, giúp các nhà phát triển viết mã byte iele dễ dàng hơn nhiều.

The term IELE describes two things:

Thuật ngữ IELE mô tả hai điều:

- The IELE VM

- IELE VM

- The IELE assembly language

- Ngôn ngữ hội IELE

IELE is a human-readable, blockchain low-level language, meant to serve as the foundation for third-generation blockchains. IELE was designed using state-of-the-art formal methods to address security and correctness concerns in Ethereum, while simultaneously enabling the verification of mathematical correctness of smart contract code that K EVM brings to Ethereum. 

IELE là một ngôn ngữ cấp thấp có thể đọc được của con người, có nghĩa là làm nền tảng cho các blockchain thế hệ thứ ba.
IELE được thiết kế bằng cách sử dụng các phương pháp chính thức tiên tiến để giải quyết các mối quan tâm về bảo mật và tính chính xác trong Ethereum, đồng thời cho phép xác minh tính chính xác toán học của mã hợp đồng thông minh mà K EVM mang lại cho Ethereum.

IELE represents the next step in the evolution of correct-by-construction, automatically generated implementation concepts. It is built to become the foundation of an entire compiler backend, allowing robust gas optimization, including contracts written in a high-level language that has IELE as its compilation target, like Solidity or Plutus.

IELE đại diện cho bước tiếp theo trong sự phát triển của các khái niệm thực hiện chính xác, tự động tạo ra.
Nó được xây dựng để trở thành nền tảng của toàn bộ phụ trợ của trình biên dịch, cho phép tối ưu hóa khí mạnh mẽ, bao gồm các hợp đồng được viết bằng ngôn ngữ cấp cao có IELE là mục tiêu tổng hợp của nó, như Solility hoặc Plutus.

### **Bridges between developer communities**

### ** Cầu nối giữa các cộng đồng nhà phát triển **

The KEVM, Glow and IELE devnets align closely with Goguenâ€™s key goals: to bring use and utility to Cardano, and build solid, lasting partnerships that contribute to the ongoing growth of our developer ecosystem. We aim to attract as many developers from as many disciplines as possible, to foster versatility and inclusivity.

Kevm, Glow và Iele Devnets phù hợp chặt chẽ với các mục tiêu chính của Goguen: mang lại sự sử dụng và tiện ích cho Cardano, và xây dựng mối quan hệ đối tác vững chắc, lâu dài góp phần vào sự tăng trưởng liên tục của hệ sinh thái nhà phát triển của chúng tôi.
Chúng tôi mong muốn thu hút càng nhiều nhà phát triển từ càng nhiều ngành càng tốt, để thúc đẩy tính linh hoạt và tính bao gồm.

Alongside Plutus and Marlowe, we hope these devnets present an unrivalled opportunity for developers (in the blockchain-crypto world and beyond) to engage with the Cardano platform, build compelling use cases, and contribute to the growth of the ecosystem.

Bên cạnh Plutus và Marlowe, chúng tôi hy vọng các Devnets này mang đến một cơ hội vô song cho các nhà phát triển (trong thế giới blockchain-Crypto và hơn thế nữa) để tham gia vào nền tảng Cardano, xây dựng các trường hợp sử dụng hấp dẫn và đóng góp vào sự phát triển của hệ sinh thái.

### **An exciting future**

### ** Một tương lai thú vị **

We hope to provide a clear path towards new developer opportunities that will require close collaboration with many different communities, not least Cardanoâ€™s own. And it's one step at a time. 

Chúng tôi hy vọng sẽ cung cấp một con đường rõ ràng cho các cơ hội phát triển mới sẽ đòi hỏi sự hợp tác chặt chẽ với nhiều cộng đồng khác nhau, không kém phần quan trọng của chính Cardano.
Và đó là một bước tại một thời điểm.

Weâ€™re putting the building blocks in place now. Once fully established, the devnets will act as bridges between developer communities, opening up new avenues of communication and cooperation across not just blockchain, but the whole developer ecosystem. Cardano will have permanent backward compatibility with the Ethereum network, keeping pace with any developments in the Ethereum chain. And by broadening the developer base, the Cardano community can help drive the continuing evolution of smart contracts and the decentralized finance (DeFi) space. Another remarkable year awaits. See you on the other side.

Chúng tôi đang đặt các khối xây dựng vào vị trí ngay bây giờ.
Sau khi được thiết lập đầy đủ, DevNets sẽ đóng vai trò là cầu nối giữa các cộng đồng nhà phát triển, mở ra những con đường giao tiếp và hợp tác mới trên không chỉ blockchain, mà toàn bộ hệ sinh thái nhà phát triển.
Cardano sẽ có khả năng tương thích ngược vĩnh viễn với mạng Ethereum, theo kịp với bất kỳ sự phát triển nào trong chuỗi Ethereum.
Và bằng cách mở rộng cơ sở nhà phát triển, cộng đồng Cardano có thể giúp thúc đẩy sự phát triển liên tục của các hợp đồng thông minh và không gian tài chính phi tập trung (DEFI).
Một năm đáng chú ý khác đang chờ đợi.
Gặp lại bạn ở thế giới bên kia nhé.

