# Reflections on a decade of blockchain, and predictions for the next
### **We've had bitcoin for over a decade. Now, we're heading into the decade of Cardano**
![](img/2020-01-09-reflections-on-a-decade-of-blockchain.002.png) 9 January 2020![](img/2020-01-09-reflections-on-a-decade-of-blockchain.002.png)[ Charles Hoskinson](tmp//en/blog/authors/charles-hoskinson/page-1/)![](img/2020-01-09-reflections-on-a-decade-of-blockchain.003.png) 9 mins read

![Charles Hoskinson](img/2020-01-09-reflections-on-a-decade-of-blockchain.004.png)[](tmp//en/blog/authors/charles-hoskinson/page-1/)
### [**Charles Hoskinson**](tmp//en/blog/authors/charles-hoskinson/page-1/)
Chief Executive Officer

Founder

- ![](img/2020-01-09-reflections-on-a-decade-of-blockchain.005.png)[](mailto:charles.hoskinson@iohk.io "Email")
- ![](img/2020-01-09-reflections-on-a-decade-of-blockchain.006.png)[](tmp///www.youtube.com/watch?v=Ja9D0kpksxw "YouTube")
- ![](img/2020-01-09-reflections-on-a-decade-of-blockchain.007.png)[](tmp///twitter.com/IOHK_Charles "Twitter")

![Reflections on a decade of blockchain, and predictions for the next](img/2020-01-09-reflections-on-a-decade-of-blockchain.008.jpeg)

It's January 2020 and that means not only a new decade, but the 11th birthday of bitcoin. The world's first virtual asset was made available to the general public on January 3rd of 2009. It's been one hell of a decade since then, and I'm excited about the next 10 years: a decade that will bring a lot of interesting things to the world.

Đó là tháng 1 năm 2020 và điều đó có nghĩa là không chỉ một thập kỷ mới, mà còn là sinh nhật thứ 11 của Bitcoin.
Tài sản ảo đầu tiên trên thế giới đã được cung cấp cho công chúng vào ngày 3 tháng 1 năm 2009. Đó là một thập kỷ của một thập kỷ kể từ đó, và tôi rất vui mừng về 10 năm tới: một thập kỷ sẽ mang lại rất nhiều điều thú vị cho
thế giới.

## **The rapid growth of blockchain technology**

## ** Sự phát triển nhanh chóng của công nghệ blockchain **

Bitcoin will always be very special to me. It was my introduction to all sorts of wonderful problems to think about in the world, like remittances and microfinance. It is incredible to think that the small, ragtag group who brought bitcoin to the public changed not only my life but the lives of individuals around the world, sparking a global movement. Now, millions of people wake up every day thinking about cryptocurrencies and blockchain technology. Hundreds, if not thousands of academic papers have been written on the topic. The influence has been profound and it is only just beginning.

Bitcoin sẽ luôn rất đặc biệt đối với tôi.
Đó là lời giới thiệu của tôi về tất cả các loại vấn đề tuyệt vời để suy nghĩ trên thế giới, như kiều hối và tài chính vi mô.
Thật không thể tin được rằng nhóm nhỏ, ragtag, người đã đưa Bitcoin đến công chúng đã thay đổi không chỉ cuộc sống của tôi mà cả cuộc sống của các cá nhân trên khắp thế giới, làm dấy lên một phong trào toàn cầu.
Bây giờ, hàng triệu người thức dậy mỗi ngày nghĩ về tiền điện tử và công nghệ blockchain.
Hàng trăm, nếu không phải hàng ngàn bài báo học thuật đã được viết về chủ đề này.
Ảnh hưởng đã được sâu sắc và nó chỉ mới bắt đầu.

The G20 and the G7 have begun talking about it. We are now seeing global regulations begin to change. Every central bank in the world is aware of virtual assets and some are even taking positions on them. This is astounding because there has never been a time in human history where one piece of technology has attained such enormous global relevance without a centrally coordinated effort through marketing, development, and control. No one controls bitcoin. That was true 11 years ago, it is true now, and the revolution is just getting started.

G20 và G7 đã bắt đầu nói về nó.
Bây giờ chúng ta đang chứng kiến các quy định toàn cầu bắt đầu thay đổi.
Mỗi ngân hàng trung ương trên thế giới đều biết về tài sản ảo và một số thậm chí đang đảm nhận vị trí của họ.
Điều này thật đáng kinh ngạc bởi vì chưa bao giờ có thời gian trong lịch sử loài người, nơi một phần của công nghệ đã đạt được sự liên quan toàn cầu to lớn như vậy mà không cần nỗ lực phối hợp tập trung thông qua tiếp thị, phát triển và kiểm soát.
Không ai kiểm soát Bitcoin.
Đó là sự thật 11 năm trước, đó là sự thật bây giờ và cuộc cách mạng chỉ mới bắt đầu.

## **What we can expect over the next decade**

## ** Những gì chúng ta có thể mong đợi trong thập kỷ tới **

So, happy birthday to bitcoin. And welcome to the new decade. I am looking forward to the next 10 years to see where the technology takes us. 2010 to 2019 was crazy and I believe that 2020 to 2029 will be very interesting. In the next decade, we will see the first brain/computer interfaces for consumer devices to be implanted into people; for example, [neural lace](https://www.techworld.com/data/what-is-neural-lace-3657074/). We will also see the rise of private space travel. Within the next ten years, virtual reality and augmented reality will enter the mainstream rather than just being fun things.

Vì vậy, chúc mừng sinh nhật bitcoin.
Và chào mừng đến với thập kỷ mới.
Tôi đang mong chờ 10 năm tới để xem công nghệ đưa chúng ta đi đâu.
2010 đến 2019 thật điên rồ và tôi tin rằng 2020 đến 2029 sẽ rất thú vị.
Trong thập kỷ tiếp theo, chúng ta sẽ thấy các giao diện não/máy tính đầu tiên cho các thiết bị tiêu dùng được cấy vào người;
Ví dụ: [ren thần kinh] (https://www.techworld.com/data/what-is-nial-lace-3657074/).
Chúng ta cũng sẽ thấy sự trỗi dậy của du hành không gian riêng tư.
Trong mười năm tới, thực tế ảo và thực tế tăng cường sẽ bước vào dòng chính thay vì chỉ là những điều thú vị.

Telecommunications, energy, and transportation will also go through a cycle of major innovation. Cell phone technology will likely go through several more doublings. Given that Tesla has proven its model, we will now see the proliferation of electric vehicles. This means that battery technology will only get better. It's likely that battery density will double or quadruple in the next ten years. This means that we will see cars that can go between 600 and 1,200 miles on a single charge. Meanwhile, the capacity for solar and wind energy will double, if not quadruple.

Viễn thông, năng lượng và giao thông cũng sẽ trải qua một chu kỳ đổi mới lớn.
Công nghệ điện thoại di động có thể sẽ trải qua một số nhân đôi hơn.
Cho rằng Tesla đã chứng minh mô hình của mình, giờ đây chúng ta sẽ thấy sự tăng sinh của xe điện.
Điều này có nghĩa là công nghệ pin sẽ chỉ trở nên tốt hơn.
Có khả năng mật độ pin sẽ tăng gấp đôi hoặc tăng gấp bốn lần trong mười năm tới.
Điều này có nghĩa là chúng ta sẽ thấy những chiếc xe có thể đi từ 600 đến 1.200 dặm trong một lần sạc.
Trong khi đó, năng lượng năng lượng mặt trời và gió sẽ tăng gấp đôi, nếu không tăng gấp bốn lần.

The study of physics is advancing rapidly and we believe that the next decade will see mainstream quantum computers. I read recently that quantum teleportation happened [between two chips](https://phys.org/news/2019-12-chip-to-chip-quantum-teleportation-harnessing-silicon.html). Meanwhile, 5G will spread around the world, and technologies such as WiFi and Bluetooth can only get better. This will pave the road for self-driving cars and intelligent infrastructure. The consequences of this technology will touch governments, services, and democracy itself.

Nghiên cứu về vật lý đang tiến triển nhanh chóng và chúng tôi tin rằng thập kỷ tới sẽ thấy các máy tính lượng tử chính.
Gần đây tôi đã đọc rằng dịch chuyển tức thời lượng tử đã xảy ra [giữa hai con chip] (https://phys.org/news/2019-12-chip-to-chip-rantum-teleportation-harnessing-silicon.html).
Trong khi đó, 5G sẽ lan rộng khắp thế giới và các công nghệ như WiFi và Bluetooth chỉ có thể trở nên tốt hơn.
Điều này sẽ mở đường cho xe tự lái và cơ sở hạ tầng thông minh.
Hậu quả của công nghệ này sẽ chạm vào chính phủ, dịch vụ và nền dân chủ.

## **A decade of change â€“ and opportunity**

## ** Một thập kỷ thay đổi - cơ hội và cơ hội **

During this decade, we will probably see another economic collapse similar to 2008 and with it, an opening for cryptocurrencies to take over the global economy. We also anticipate that one or more African nations will achieve the same economic prominence as countries like Brazil and South Korea. It could be Kenya, Ethiopia, or Nigeria. This means that we will likely see innovations in the movement of people and the development of new passport and identity systems. This might be the decade that we see self-sovereign identity gain prominence. We believe that, soon, data will be treated as the commodity that it is. New rules and regulations around the use of data will begin to materialize. It is our hope that this will curtail the data surveillance and capitalism economy that has developed over the last twenty years. This might happen through global regulation. Regardless of what happens between 2020 and 2030, it has been the privilege of a lifetime to be alive right now to see how the world changes. Whether in the biotechnology spectrum, the nanotechnology spectrum, the ICT world, or otherwise, it is a privilege to see these technologies work their way into the mainstream.

Trong thập kỷ này, chúng ta có thể sẽ thấy một sự sụp đổ kinh tế khác tương tự như năm 2008 và với nó, một sự mở cửa cho tiền điện tử để tiếp quản nền kinh tế toàn cầu. Chúng tôi cũng dự đoán rằng một hoặc nhiều quốc gia châu Phi sẽ đạt được sự nổi bật về kinh tế giống như các quốc gia như Brazil và Hàn Quốc. Đó có thể là Kenya, Ethiopia hoặc Nigeria. Điều này có nghĩa là chúng ta có thể sẽ thấy những đổi mới trong sự chuyển động của con người và sự phát triển của hộ chiếu và hệ thống nhận dạng mới. Đây có thể là thập kỷ mà chúng ta thấy sự nổi bật về bản sắc có chủ quyền. Chúng tôi tin rằng, sớm, dữ liệu sẽ được coi là hàng hóa. Các quy tắc và quy định mới xung quanh việc sử dụng dữ liệu sẽ bắt đầu thành hiện thực. Chúng tôi hy vọng rằng điều này sẽ hạn chế sự giám sát dữ liệu và nền kinh tế chủ nghĩa tư bản đã phát triển trong hai mươi năm qua. Điều này có thể xảy ra thông qua quy định toàn cầu. Bất kể điều gì xảy ra giữa năm 2020 đến 2030, đó là đặc quyền của cả đời để sống ngay bây giờ để xem thế giới thay đổi như thế nào. Cho dù trong phổ công nghệ sinh học, phổ công nghệ nano, thế giới CNTT -TT, hay nói cách khác, đó là một đặc quyền khi thấy các công nghệ này hoạt động theo cách chính của họ.

In my view, this is the last decade of traditional organized media. In the future, we will see less CNN, Fox News, Bloomberg, and The Wall Street Journal. Instead, we will see more Joe Rogans. This will be especially true as we enter 2025 and beyond. The crypto space, in particular, will fundamentally change the incentives governing journalism. We'll move to a different way of paying for and curating content. The age of popular long-form journalism has begun. It is very exciting to see that occur.

Theo quan điểm của tôi, đây là thập kỷ cuối cùng của các phương tiện truyền thông có tổ chức truyền thống.
Trong tương lai, chúng ta sẽ thấy ít CNN, Fox News, Bloomberg và Tạp chí Phố Wall.
Thay vào đó, chúng ta sẽ thấy nhiều Joe Rogans hơn.
Điều này sẽ đặc biệt đúng khi chúng ta bước vào năm 2025 và hơn thế nữa.
Không gian tiền điện tử, đặc biệt, về cơ bản, sẽ thay đổi cơ bản các ưu đãi điều chỉnh báo chí.
Chúng tôi sẽ chuyển sang một cách trả tiền và quản lý nội dung khác.
Thời đại của báo chí kiểu dài phổ biến đã bắt đầu.
Nó rất thú vị để thấy điều đó xảy ra.

It is also exciting to see the continued adoption of open ideas, open technology, and idea flow. All the world's top companies have a dense portfolio of open source technology. This was not the case in 2000. It was only a little bit more the case in 2010. Now that we are entering 2020 and heading to 2030, it is exciting to see how quickly people are collaborating and how products are being built from common DNA across industries. It's good for you, it's good for the consumer, and it's good for all of us.

Thật thú vị khi thấy việc tiếp tục áp dụng các ý tưởng mở, công nghệ mở và luồng ý tưởng.
Tất cả các công ty hàng đầu thế giới đều có một danh mục công nghệ nguồn mở dày đặc.
Đây không phải là trường hợp vào năm 2000. Nó chỉ xảy ra nhiều hơn một chút vào năm 2010. Bây giờ chúng ta đang bước vào năm 2020 và hướng đến năm 2030, thật thú vị khi thấy mọi người đang hợp tác nhanh như thế nào và các sản phẩm được xây dựng từ DNA thông thường như thế nào
trên khắp các ngành công nghiệp.
Nó tốt cho bạn, nó tốt cho người tiêu dùng và nó tốt cho tất cả chúng ta.

## **Cardano's role**

## ** Vai trò của Cardano **

So, where does Cardano fit in all of this? This is hopefully our decade. Bitcoin owned the last one and I hope, by the end of the 2020s, Cardano will be the predominant force in the cryptocurrency space. I believe that it will become a true social operating system. My hope is that we could see thousands of meta tokens living on our platform, from securities to commodities to stablecoins, and all other kinds of representations of value, and that we'll see billions of transactions every single day from over a billion users. It really all comes down to whether or not the technology can properly meet the right incentive set and have the right commercial utilization. These are the things that we have to put together and we are obsessed with getting the technology right. We think we have the right paradigm. The peer-review process has given us unparalleled clarity and understanding of trade-offs, along with where we can go.

Vì vậy, Cardano phù hợp với tất cả những điều này ở đâu?
Đây là hy vọng thập kỷ của chúng tôi.
Bitcoin sở hữu cái cuối cùng và tôi hy vọng, vào cuối những năm 2020, Cardano sẽ là lực lượng chiếm ưu thế trong không gian tiền điện tử.
Tôi tin rằng nó sẽ trở thành một hệ điều hành xã hội thực sự.
Hy vọng của tôi là chúng ta có thể thấy hàng ngàn mã thông báo meta sống trên nền tảng của chúng tôi, từ chứng khoán đến hàng hóa đến stabloin và tất cả các loại đại diện khác về giá trị và chúng ta sẽ thấy hàng tỷ giao dịch mỗi ngày từ hơn một tỷ người dùng.
Nó thực sự thuộc về việc liệu công nghệ có thể đáp ứng đúng bộ ưu đãi hay không và có việc sử dụng thương mại phù hợp.
Đây là những điều mà chúng ta phải đặt cùng nhau và chúng ta bị ám ảnh bởi việc nhận được công nghệ đúng.
Chúng tôi nghĩ rằng chúng tôi có mô hình phù hợp.
Quá trình đánh giá ngang hàng đã cho chúng ta sự rõ ràng và hiểu biết vô song về sự đánh đổi, cùng với nơi chúng ta có thể đi.

It has also allowed us to talk with everyone in the world about what we can do using a common language. We've mastered virtual network infrastructure, consensus protocols, and the underlying cryptographic primitives. We have a very good understanding of what needs to be done in order to build a global skill system. We also know how to do that in a responsible, peer-reviewed, sustainable way. So, from a technological perspective, we feel our approach is right.

Nó cũng đã cho phép chúng tôi nói chuyện với mọi người trên thế giới về những gì chúng tôi có thể làm bằng cách sử dụng một ngôn ngữ chung.
Chúng tôi đã thành thạo cơ sở hạ tầng mạng ảo, giao thức đồng thuận và các nguyên thủy mật mã cơ bản.
Chúng tôi có một sự hiểu biết rất tốt về những gì cần phải làm để xây dựng một hệ thống kỹ năng toàn cầu.
Chúng tôi cũng biết làm thế nào để làm điều đó một cách có trách nhiệm, được đánh giá ngang hàng, bền vững.
Vì vậy, từ góc độ công nghệ, chúng tôi cảm thấy cách tiếp cận của chúng tôi là đúng.

## **Marketing and commercialization**

## ** Tiếp thị và thương mại hóa **

This year, in particular, we're going to start hitting commercialization hard. I've announced to the company that we are on a 'Cardano first' strategy. This means that if we are building a product we will always ask ourselves if we can deploy it on Cardano. So, if someone comes up to us and says, "Hey we'd like you to do some interesting blockchain solution," whether it be supply chain, authentication, credential verification, we will look at Cardano first. That might be in Ethiopia, Georgia, Mongolia, or closer to home like our partnership with New Balance.

Năm nay, đặc biệt, chúng ta sẽ bắt đầu đánh giá cao thương mại hóa.
Tôi đã thông báo với công ty rằng chúng tôi đang trong chiến lược 'Cardano đầu tiên'.
Điều này có nghĩa là nếu chúng ta đang xây dựng một sản phẩm, chúng ta sẽ luôn tự hỏi liệu chúng ta có thể triển khai nó trên Cardano không.
Vì vậy, nếu ai đó đến với chúng tôi và nói, "Này, chúng tôi muốn bạn thực hiện một số giải pháp blockchain thú vị", cho dù đó là chuỗi cung ứng, xác thực, xác minh thông tin xác thực, chúng tôi sẽ xem xét Cardano trước.
Đó có thể là ở Ethiopia, Georgia, Mông Cổ hoặc gần nhà hơn như sự hợp tác của chúng tôi với New Balance.

I think it's very important to use our own product in order to build these things properly. Hopefully, the Ethiopia project will be able to launch its currency on Cardano. This is the same for the credential verification project for Georgia. Our strategy is to always begin with Cardano first, this year and into the future.

Tôi nghĩ rằng việc sử dụng sản phẩm của chúng ta rất quan trọng để xây dựng những thứ này đúng cách.
Hy vọng, dự án Ethiopia sẽ có thể ra mắt tiền tệ của mình trên Cardano.
Điều này giống nhau cho dự án xác minh thông tin xác thực cho Georgia.
Chiến lược của chúng tôi là luôn bắt đầu với Cardano đầu tiên, năm nay và trong tương lai.

We're also going to get very aggressive about the commercialization of the technology, especially as Shelley and Goguen are deployed. We feel that this platform has a right to exist and brings a lot to the table. It allows people to solve problems in ways they couldn't previously. We believe that this is the platform that will bring future solutions into existence. We will push that mentality to our partners at Emurgo and the Cardano Foundation.

Chúng tôi cũng sẽ rất tích cực về việc thương mại hóa công nghệ, đặc biệt là khi Shelley và Goguen được triển khai.
Chúng tôi cảm thấy rằng nền tảng này có quyền tồn tại và mang lại rất nhiều cho bảng.
Nó cho phép mọi người giải quyết vấn đề theo cách mà trước đây họ không thể.
Chúng tôi tin rằng đây là nền tảng sẽ đưa các giải pháp trong tương lai vào sự tồn tại.
Chúng tôi sẽ đẩy tâm lý đó đến các đối tác của chúng tôi tại EMURGO và Quỹ Cardano.

We're excited to explore incentives. At the moment, we're looking at tokenomics, incentive schemes, and governance systems as first-class citizens in the growth of the product. The reason why bitcoin was so successful was the simplicity of its incentive model. Satoshi created the model for people to mine it. Similarly, if we're to be successful, we need incentives that are directly aligned with the growth of the system. So, with the launch of the Incentivized Testnet, we're learning a lot about the business of stake pools and the business of maintaining a stable cryptocurrency.

Chúng tôi rất vui mừng được khám phá các ưu đãi.
Hiện tại, chúng tôi đang xem xét tokenomics, các chương trình khuyến khích và hệ thống quản trị là công dân hạng nhất trong sự phát triển của sản phẩm.
Lý do tại sao Bitcoin thành công như vậy là sự đơn giản của mô hình khuyến khích của nó.
Satoshi đã tạo ra mô hình cho mọi người để khai thác nó.
Tương tự, nếu chúng ta thành công, chúng ta cần các ưu đãi trực tiếp phù hợp với sự phát triển của hệ thống.
Vì vậy, với sự ra mắt của Testnet được khuyến khích, chúng tôi đang tìm hiểu rất nhiều về việc kinh doanh của các nhóm cổ phần và hoạt động kinh doanh duy trì một loại tiền điện tử ổn định.

We already have 500 stake pools registered and we're learning critical information. This includes everything from what saturation metrics should look like to who is a good operator, who is a bad operator, and how the market and user experience look. This is a topic that we are incredibly interested in exploring this quarter. Our partners at Emurgo and the Cardano Foundation are also investing a lot of time to make sure that we fully understand how incentives work in the Cardano ecosystem.

Chúng tôi đã có 500 cổ phần được đăng ký và chúng tôi đang học thông tin quan trọng.
Điều này bao gồm tất cả mọi thứ, từ những gì các số liệu bão hòa sẽ trông giống ai là một nhà điều hành giỏi, người là một nhà điều hành xấu, và trải nghiệm thị trường và người dùng trông như thế nào.
Đây là một chủ đề mà chúng tôi vô cùng thích thú trong việc khám phá quý này.
Các đối tác của chúng tôi tại Emurgo và Quỹ Cardano cũng đang đầu tư rất nhiều thời gian để đảm bảo rằng chúng tôi hoàn toàn hiểu được các ưu đãi hoạt động trong hệ sinh thái Cardano.

As we exit 2020 and throughout the next decade, incentives will be a source of continuous research. The better we get, the faster the feedback loop becomes, the faster we can grow to achieve a billion users and become a truly global social operating system that is beneficial to everyone. With all that being said, commercialization, technology, and incentives are the three things that will need to be aligned for us to achieve that coveted number one spot.

Khi chúng tôi thoát khỏi năm 2020 và trong suốt thập kỷ tới, các ưu đãi sẽ là một nguồn nghiên cứu liên tục.
Chúng ta càng nhận được tốt hơn, vòng phản hồi càng nhanh, chúng ta có thể phát triển càng nhanh để đạt được tỷ người dùng và trở thành một hệ điều hành xã hội toàn cầu thực sự có lợi cho mọi người.
Với tất cả những gì đang được nói, thương mại hóa, công nghệ và ưu đãi là ba điều sẽ cần được liên kết để chúng tôi đạt được vị trí số một đáng thèm muốn đó.

We are building Cardano for a reason. It is not an academic project: it is a commercial project and we want to see it grow. This is an exciting time but we must remember where we came from. We came from bitcoin and bitcoin will always be around for us. It will always be a valuable project, and will always have a soft spot in my heart.

Chúng tôi đang xây dựng Cardano vì một lý do.
Nó không phải là một dự án học thuật: nó là một dự án thương mại và chúng tôi muốn thấy nó phát triển.
Đây là một thời gian thú vị nhưng chúng ta phải nhớ chúng ta đến từ đâu.
Chúng tôi đến từ Bitcoin và Bitcoin sẽ luôn ở bên chúng tôi.
Nó sẽ luôn là một dự án có giá trị, và sẽ luôn có một điểm yếu trong trái tim tôi.

So, on behalf of the Cardano community, Happy Birthday bitcoin! Thank you so much for all you've done. Thank you also to the bitcoin community. We wish you great success, stability, and innovation.

Vì vậy, thay mặt cho cộng đồng Cardano, chúc mừng sinh nhật Bitcoin!
Cảm ơn bạn rất nhiều vì tất cả những gì bạn đã làm.
Cảm ơn bạn cũng đến cộng đồng Bitcoin.
Chúng tôi chúc bạn thành công lớn, ổn định và đổi mới.

*This is an edited transcript of [Charles' January 3rd 2019 AMA](https://www.youtube.com/watch?v=CBGYIHb600w).*

*Đây là bảng điểm chỉnh sửa của [Charles 'ngày 3 tháng 1 năm 2019 AMA] (https://www.youtube.com/watch?v=cbgyihb600w).*

