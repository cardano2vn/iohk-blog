# Project Catalyst; introducing our first public fund for Cardano community innovation
### **An exciting experiment to start building the future of Cardano**
![](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.002.png) 16 September 2020![](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.002.png)[ Dor Garbash](tmp//en/blog/authors/dor-garbash/page-1/)![](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.003.png) 4 mins read

![Dor Garbash](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.004.png)[](tmp//en/blog/authors/dor-garbash/page-1/)
### [**Dor Garbash**](tmp//en/blog/authors/dor-garbash/page-1/)
Head of Product

Commercial

- ![](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.005.png)[](https://linkedin.com/in/garbash "LinkedIn")
- ![](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.006.png)[](https://twitter.com/garbash "Twitter")
- ![](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.007.png)[](https://github.com/Garbash "GitHub")

![Project Catalyst; introducing our first public fund for Cardano community innovation](img/2020-09-16-project-catalyst-introducing-our-first-public-fund-for-cardano-community-innovation.008.jpeg)

Today, we are announcing the launch of Project Catalystâ€™s first public fund, an important first step into the world of on-chain governance, treasury, and community innovation for Cardano.

Hôm nay, chúng tôi sẽ công bố ra mắt Quỹ công cộng đầu tiên của Project Catalyst, một bước đầu tiên quan trọng vào thế giới quản trị chuỗi, Kho bạc và đổi mới cộng đồng cho Cardano.

The public fund launch follows five months of intense activity, across two previous trial â€˜fundsâ€™. â€˜Fund 0â€™ was the very first experiment, using a focus group made up from IOG team members. â€˜Fund 1â€™ was the first time we introduced the idea to the Cardano community, recruiting a group of some 50 volunteers to help us develop the platform and processes. While this voting cycle did not offer â€˜realâ€™ funding, it served as a hugely valuable way to give our team and the Cardano community members a chance to test drive and refine the emerging process.

Việc ra mắt quỹ công cộng sau năm tháng hoạt động dữ dội, qua hai thử nghiệm trước đó - ˜ fundsâ € ™.
â € ˜ fund 0â € ™ là thử nghiệm đầu tiên, sử dụng một nhóm tập trung được tạo thành từ các thành viên nhóm IOG.
"Fund 1â € ™ là lần đầu tiên chúng tôi giới thiệu ý tưởng cho cộng đồng Cardano, tuyển dụng một nhóm gồm 50 tình nguyện viên để giúp chúng tôi phát triển nền tảng và quy trình.
Mặc dù chu kỳ bỏ phiếu này không cung cấp tài trợ - nó thực tế, nhưng nó phục vụ như một cách cực kỳ quý giá để cung cấp cho nhóm của chúng tôi và các thành viên cộng đồng Cardano có cơ hội lái thử và tinh chỉnh quá trình mới nổi.

We still have a way to go. But with the community's support, we want to maintain the pace of progress we have already set. If Fund 0 was the technical runthrough, Fund 1 was the dress rehearsal. Announced today, Fund 2 is the opening night where the star acts of the community get the chance to compete for the funding to bring their project center stage.

Chúng tôi vẫn còn một cách để đi.
Nhưng với sự hỗ trợ của cộng đồng, chúng tôi muốn duy trì tốc độ tiến bộ mà chúng tôi đã thiết lập.
Nếu Fund 0 là Runthrough kỹ thuật, Fund 1 là buổi thử trang phục.
Được công bố hôm nay, Fund 2 là đêm khai mạc, nơi ngôi sao hành động của cộng đồng có cơ hội cạnh tranh để tài trợ để mang đến giai đoạn trung tâm dự án của họ.

## **Funding the future**

## ** Tài trợ cho tương lai **

We have learned a lot since we kicked off the private phase of the program in August. Support from our pioneer group of 50 community participants helped us to identify areas for improvement so we could develop and refine the process before opening things up more widely. We learned that providing clear documentation and guidelines helps the community engage more deeply and focus on the ideas. We also learned we can provide alternative avenues for the community to discuss â€œmetaâ€ proposals. This enhances the Catalyst and Voltaire processes while focusing attention on writing impactful proposals. Furthermore, we realized that it was important for IOHK to support individuals writing proposals to ensure their ideas were fairly represented.

Chúng tôi đã học được rất nhiều kể từ khi chúng tôi khởi động giai đoạn riêng của chương trình vào tháng Tám.
Hỗ trợ từ nhóm Tiên phong của chúng tôi gồm 50 người tham gia cộng đồng đã giúp chúng tôi xác định các khu vực để cải thiện để chúng tôi có thể phát triển và tinh chỉnh quy trình trước khi mở ra mọi thứ rộng rãi hơn.
Chúng tôi đã học được rằng việc cung cấp tài liệu và hướng dẫn rõ ràng giúp cộng đồng tham gia sâu sắc hơn và tập trung vào các ý tưởng.
Chúng tôi cũng đã học được rằng chúng tôi có thể cung cấp các con đường thay thế cho cộng đồng để thảo luận về các đề xuất ".
Điều này giúp tăng cường các quá trình chất xúc tác và voltaire trong khi tập trung chú ý vào việc viết các đề xuất có tác động.
Hơn nữa, chúng tôi nhận ra rằng điều quan trọng đối với IOHK là hỗ trợ các cá nhân viết các đề xuất để đảm bảo ý tưởng của họ được thể hiện công bằng.

Cardano will thrive by unlocking the creative potential of our global community. Our voting protocol will only be as good as the ideas which feed into it. To that end, we are developing a guide to help anyone develop the best possible proposal for Fund 2 and beyond.

Cardano sẽ phát triển mạnh bằng cách mở khóa tiềm năng sáng tạo của cộng đồng toàn cầu của chúng tôi.
Giao thức bỏ phiếu của chúng tôi sẽ chỉ tốt như những ý tưởng ăn vào đó.
Cuối cùng, chúng tôi đang phát triển một hướng dẫn để giúp bất cứ ai phát triển đề xuất tốt nhất có thể cho Quỹ 2 và hơn thế nữa.

The first public fund weâ€™re announcing today contains up to $250k-worth of ada, which the community can access. Anyone can bring their idea and create a proposal. Through a public vote, â€˜winningâ€™ proposals will begin a development process.

Quỹ công cộng đầu tiên mà chúng tôi thông báo hôm nay chứa tới 250 nghìn đô la ADA, mà cộng đồng có thể truy cập.
Bất cứ ai cũng có thể mang ý tưởng của họ và tạo ra một đề xuất.
Thông qua một cuộc bỏ phiếu công khai, các đề xuất sẽ bắt đầu một quá trình phát triển.

Initially, weâ€™re keeping the focus tight, asking the community to address a challenge statement: â€œHow can we encourage developers and entrepreneurs to build Dapps and businesses on top of Cardano in the next 6 months?â€ Funding proposals (or â€˜FPsâ€™) can address this with a wide variety of ideas â€“ from marketing initiatives and infrastructure development, to business planning and content creation.

Ban đầu, chúng tôi giữ sự tập trung chặt chẽ, yêu cầu cộng đồng giải quyết một tuyên bố thách thức: "Làm thế nào chúng ta có thể khuyến khích các nhà phát triển và doanh nhân xây dựng DAPP và doanh nghiệp trên đỉnh Cardano trong 6 tháng tới?
Hoặc "FPSâ € ™) có thể giải quyết vấn đề này với nhiều ý tưởng - từ các sáng kiến tiếp thị và phát triển cơ sở hạ tầng, đến lập kế hoạch kinh doanh và sáng tạo nội dung.

The first stage will be to â€˜explore the challengeâ€™, asking members of the community to provide their perspectives. Next, weâ€™ll encourage everyone to put their best ideas forward on the [innovation platform](https://cardano.ideascale.com/a/index) to collaborate and discuss via a dedicated [Telegram chat](https://t.me/cardanocatalyst) channel.

Giai đoạn đầu tiên sẽ là việc giải thích thử thách, yêu cầu các thành viên của cộng đồng cung cấp quan điểm của họ.
Tiếp theo, chúng tôi sẽ khuyến khích mọi người đưa ý tưởng tốt nhất của họ về phía trước trên [nền tảng đổi mới] (https://cardano.ideascale.com/a/index) hợp tác và thảo luận thông qua [trò chuyện Telegram] (https:/
/t.me/cardanocatalyst) kênh.

## **A public vote**

## ** Một cuộc bỏ phiếu công khai **

After the initial ideation, collaboration and proposal stages, weâ€™ll be putting things to a vote. Proposals can be reviewed either on the innovation platform or on the new mobile voting application, currently in development. When it comes time to vote, all participants will need to register to vote through the voting app. The â€˜rightâ€™ to vote will be linked to each participantâ€™s ada holdings and will earn them additional rewards for voting. Participating in this first funding round will not prevent ada holders from delegating their ada and earning rewards as normal. Voting effectively functions like a â€˜transactionâ€™, allowing all participants to cast their vote to indicate â€˜yes,â€™ or â€˜no.â€™ Weâ€™ll share further information on the app and the voting process in a future blog post.

Sau khi ý tưởng ban đầu, sự hợp tác và đề xuất, chúng tôi sẽ đưa mọi thứ vào một cuộc bỏ phiếu.
Các đề xuất có thể được xem xét trên nền tảng đổi mới hoặc trên ứng dụng bỏ phiếu di động mới, hiện đang được phát triển.
Khi đến lúc bỏ phiếu, tất cả những người tham gia sẽ cần đăng ký để bỏ phiếu thông qua ứng dụng bỏ phiếu.
Việc bỏ phiếu sẽ được liên kết với mỗi người nắm giữ Ada của mỗi người tham gia và sẽ kiếm được phần thưởng bổ sung cho họ để bỏ phiếu.
Tham gia vào vòng tài trợ đầu tiên này sẽ không ngăn cản chủ sở hữu ADA ủy thác ADA của họ và kiếm được phần thưởng là bình thường.
Bỏ phiếu có chức năng hiệu quả như một sự phát hành, cho phép tất cả những người tham gia bỏ phiếu của họ để cho biết "chúng tôi sẽ chia sẻ thông tin thêm về ứng dụng và chúng tôi sẽ chia sẻ thêm thông tin về ứng dụng và
Quá trình bỏ phiếu trong một bài viết trên blog trong tương lai.

## **Collaboration and innovation**

## ** Hợp tác và đổi mới **

Voltaire will be a crucial building block in the Cardano ecosystem, because it allows every ada holder to be involved in making decisions on the future development of the platform and contribute to the growth of the ecosystem. Project Catalyst is the important first component in delivering that capability. The early stages of this experiment have already demonstrated the passion and commitment of the Cardano community to develop this further. With the introduction of an on-chain voting and treasury system, network participants will be able to use their stake and voting rights to steer Cardano towards tackling shared goals, in a democratic and self-sustaining way.

Voltaire sẽ là một khối xây dựng quan trọng trong hệ sinh thái Cardano, bởi vì nó cho phép mọi chủ sở hữu ADA tham gia vào việc đưa ra quyết định về sự phát triển trong tương lai của nền tảng và đóng góp vào sự phát triển của hệ sinh thái.
Project Catalyst là thành phần đầu tiên quan trọng trong việc cung cấp khả năng đó.
Các giai đoạn đầu của thí nghiệm này đã chứng minh niềm đam mê và cam kết của cộng đồng Cardano để phát triển điều này hơn nữa.
Với việc giới thiệu một hệ thống bỏ phiếu và kho bạc trên chuỗi, những người tham gia mạng lưới sẽ có thể sử dụng cổ phần và quyền biểu quyết của họ để điều khiển Cardano để giải quyết các mục tiêu chung, theo cách dân chủ và tự duy trì.

To find out more, you can watch our [announcement Crowdcast](https://www.crowdcast.io/e/fofg4hrz) with Charles Hoskinson and Project Catalystâ€™s product manager, Dor Garbash.

Để tìm hiểu thêm, bạn có thể xem [thông báo đám đông của chúng tôi] (https://www.crowdcast.io/e/fofg4hrz) với Charles Hoskinson và Giám đốc sản phẩm của Project Catalyst, Dor Garbash.

