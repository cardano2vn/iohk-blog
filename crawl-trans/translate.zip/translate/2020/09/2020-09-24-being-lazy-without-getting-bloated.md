# Being lazy without getting bloated
### **Haskell nothunks library goes a long way towards making memory leaks a thing of the past**
![](img/2020-09-24-being-lazy-without-getting-bloated.002.png) 24 September 2020![](img/2020-09-24-being-lazy-without-getting-bloated.002.png)[ Edsko de Vries](tmp//en/blog/authors/edsko-de-vries/page-1/)![](img/2020-09-24-being-lazy-without-getting-bloated.003.png) 25 mins read

![Edsko de Vries](img/2020-09-24-being-lazy-without-getting-bloated.004.png)[](tmp//en/blog/authors/edsko-de-vries/page-1/)
### [**Edsko de Vries**](tmp//en/blog/authors/edsko-de-vries/page-1/)
Software Engineer

Well-Typed

- ![](img/2020-09-24-being-lazy-without-getting-bloated.005.png)[](http://www.linkedin.com/in/edsko-de-vries-04126b31 "LinkedIn")
- ![](img/2020-09-24-being-lazy-without-getting-bloated.006.png)[](https://twitter.com/EdskoDeVries "Twitter")
- ![](img/2020-09-24-being-lazy-without-getting-bloated.007.png)[](https://github.com/edsko "GitHub")

![Being lazy without getting bloated](img/2020-09-24-being-lazy-without-getting-bloated.008.jpeg)

*In our Developer Deep Dive series of occasional technical blogs, we invite IOHKâ€™s engineers to discuss their latest work and insights.*

*Trong loạt các blog kỹ thuật thường xuyên của nhà phát triển Deep Dive, chúng tôi mời các kỹ sư của IOHK để thảo luận về công việc và hiểu biết mới nhất của họ.*

Haskell is a lazy language. The importance of laziness has been widely discussed elsewhere: [Why Functional Programming Matters](http://www.cse.chalmers.se/~rjmh/Papers/whyfp.html) is one of the classic papers on the topic, and [A History of Haskell: Being Lazy with Class](http://citeseer.ist.psu.edu/viewdoc/download;jsessionid=1DD00353B72F4318D0FE3D41668AB13A?doi=10.1.1.168.4008&rep=rep1&type=pdf) discusses it at length as well. For the purposes of this blog we will take it for granted that laziness is something we want. But laziness comes at a cost, and one of the disadvantages is that laziness can lead to memory leaks that are sometimes difficult to find. In this post we introduce a new library called [nothunks](http://hackage.haskell.org/package/nothunks) aimed at discovering a large class of such leaks early, and helping to debug them. This library was developed for our work on the Cardano blockchain, but we believe it will be widely applicable in other projects too.

Haskell là một ngôn ngữ lười biếng.
Tầm quan trọng của sự lười biếng đã được thảo luận rộng rãi ở nơi khác: [Tại sao các vấn đề lập trình chức năng] (http://www.cse.chalmers.se/~rjmh/papers/whyfp.html) là một trong những bài báo cổ điển về chủ đề và [và [và [
Lịch sử của Haskell: Lười với lớp] (http://citeseer.ist.psu.edu/viewdoc/doad;
Đối với mục đích của blog này, chúng tôi sẽ coi đó là sự lười biếng là điều chúng tôi muốn.
Nhưng sự lười biếng phải trả giá, và một trong những nhược điểm là sự lười biếng có thể dẫn đến rò rỉ bộ nhớ đôi khi khó tìm.
Trong bài đăng này, chúng tôi giới thiệu một thư viện mới có tên [Nothunks] (http://hackage.haskell.org/package/nothunks) nhằm khám phá một lớp lớn các rò rỉ như vậy sớm và giúp gỡ lỗi chúng.
Thư viện này được phát triển cho công việc của chúng tôi trên blockchain Cardano, nhưng chúng tôi tin rằng nó cũng sẽ được áp dụng rộng rãi trong các dự án khác.

## **A motivating example**

## ** một ví dụ động lực **

Consider the tiny application below, which processes incoming characters and reports how many characters there are in total, in addition to some per-character statistics:

Hãy xem xét ứng dụng nhỏ bên dưới, trong đó xử lý các ký tự đến và báo cáo tổng cộng có bao nhiêu ký tự, ngoài một số thống kê peracter:

import qualified Data.Map.Strict as Map

Nhập dữ liệu đủ điều kiện.Map.Strict dưới dạng bản đồ

data AppState = AppState {

Dữ liệu appstate = appstate {

`      `total :: !Int

`` Tổng cộng ::! Int

`    `, indiv :: !(Map Char Stats)

``, indiv ::! (Số liệu thống kê của bản đồ)

`    `}

``}

`  `deriving (Show)

`` Deriving (Hiển thị)

type Stats = Int

Nhập số liệu thống kê = int

update :: AppState -> Char -> AppState

CẬP NHẬT :: appstate -> char -> appstate

update st c = st {

Cập nhật st c = st {

`      `total = total st + 1

`` Total = Total St + 1

`    `, indiv = Map.alter (Just . aux) c (indiv st)

``, indiv = map.alter (chỉ. Aux) C (Indiv st)

`    `}

``}

`  `where

`` Ở đâu

`    `aux :: Maybe Stats -> Stats

`` AUX :: Có thể chỉ số -> Số liệu thống kê

`    `aux Nothing  = 1

`` Aux không có gì = 1

`    `aux (Just n) = n + 1

`` aux (chỉ n) = n + 1

initAppState :: AppState

INITAPPSTATE :: AppState

initAppState = AppState {

initaPstate = appstate {

`      `total = 0

`` Tổng cộng = 0

`    `, indiv = Map.empty

``, indiv = map.empty

`    `}

``}

main :: IO ()

chính :: io ()

main = interact $ show . foldl' update initAppState

Main = Tương tác $ Show.
Cập nhật Foldl 'initAppState

In this version of the code, the per-character statistics are simply how often we have seen each character. If we feed this code â€˜aabbbâ€™, it will tell us that it saw 5 characters, 2 of which were the letter â€˜aâ€™ and 3 of which were â€˜bâ€™:

Trong phiên bản này của mã, số liệu thống kê per-saracter chỉ đơn giản là tần suất chúng ta thấy từng ký tự.
Nếu chúng ta cung cấp mã này - ˜aabbbâ € ™, nó sẽ cho chúng ta biết rằng nó đã thấy 5 ký tự, 2 trong số đó là chữ cái - một trong đó là - trong đó

\# echo -n aabbb | cabal run example1

\# echo -n aabbb |
cabal chạy ví dụ1

AppState {

Appstate {

`    `total = 5

`` Tổng cộng = 5

`  `, indiv = fromList [('a',2),('b',3)]

``, indiv = fromlist [('a', 2), ('b', 3)]]

`  `}

``}

Moreover, if we feed the application a ton of data and construct a memory profile,

Hơn nữa, nếu chúng ta cung cấp cho ứng dụng một tấn dữ liệu và xây dựng cấu hình bộ nhớ,

dd if=/dev/zero bs=1M count=10 | cabal run --enable-profiling example1 -- +RTS -hy

DD if =/dev/zero bs = 1m đếm = 10 |
cabal chạy -ví dụ cũng có thể cung cấp lại1 - +rts -hy

we see from Figure 1 that the application runs in constant space.

Chúng ta thấy trong Hình 1 rằng ứng dụng chạy trong không gian không đổi.

![Figure 1. Memory profile for the first example](img/2020-09-24-being-lazy-without-getting-bloated.009.png)

**Figure 1. Memory profile for the first example**

** Hình 1. Hồ sơ bộ nhớ cho ví dụ đầu tiên **

So far so good. But now suppose we make an innocuous-looking change. Suppose, in addition to reporting how *often* every character occurs, we also want to know the *offset* of the last time that the character occurs in the file:

Càng xa càng tốt.
Nhưng bây giờ giả sử chúng ta tạo ra một sự thay đổi vô hại.
Giả sử, ngoài việc báo cáo cách * thường * mọi ký tự xảy ra, chúng ta cũng muốn biết * bù * của lần cuối cùng ký tự xảy ra trong tệp:

type Stats = (Int, Int)

Loại thống kê = (int, int)

update :: AppState -> Char -> AppState

CẬP NHẬT :: appstate -> char -> appstate

update st c = -- .. as before

Cập nhật st c = - .. như trước đây

`  `where

`` Ở đâu

`    `aux :: Maybe Stats -> Stats

`` AUX :: Có thể chỉ số -> Số liệu thống kê

`    `aux Nothing       = (1     , total st)

`` Aux nothing = (1, tổng số st)

`    `aux (Just (n, \_)) = (n + 1 , total st)

`` aux (chỉ (n, \ _)) = (n + 1, tổng st)

The application works as expected:

Ứng dụng hoạt động như mong đợi:

\# echo -n aabbb | cabal run example2

\# echo -n aabbb |
Cabal chạy ví dụ2

AppState {

Appstate {

`    `total = 5

`` Tổng cộng = 5

`  `, indiv = fromList [('a',(2,1)),('b',(3,4))]

``, indiv = fromlist [('a', (2,1)), ('b', (3,4))]]

`  `}

``}

and so the change is accepted in GitHub's PR code review and gets merged. However, although the code still *works*, it is now a lot slower.

Và do đó, sự thay đổi được chấp nhận trong đánh giá mã PR của GitHub và được hợp nhất.
Tuy nhiên, mặc dù mã vẫn *hoạt động *, nhưng bây giờ nó chậm hơn rất nhiều.

\# time (dd if=/dev/zero bs=1M count=100 | cabal run example1)

\# thời gian (dd if =/dev/zero bs = 1m đếm = 100 | cabal chạy ví dụ1)

(..)

(..)

real    0m2,312s

thực 0M2.312S

\# time (dd if=/dev/zero bs=1M count=100 | cabal run example2)

\# thời gian (dd if =/dev/zero bs = 1m đếm = 100 | cabal chạy ví dụ2)

(..)

(..)

real    0m15,692s

Thực 0M15,692S

We have a slowdown of almost an order of magnitude, although we are barely doing more work. Clearly, something has gone wrong, and indeed, we have introduced a memory leak (Figure 2).

Chúng tôi có sự chậm lại gần như một thứ tự cường độ, mặc dù chúng tôi hầu như không làm việc nhiều hơn.
Rõ ràng, một cái gì đó đã sai, và thực sự, chúng tôi đã giới thiệu rò rỉ bộ nhớ (Hình 2).

![Figure 2. Memory profile for example 2](img/2020-09-24-being-lazy-without-getting-bloated.009.png)

**Figure 2. Memory profile for example 2**

** Hình 2. Hồ sơ bộ nhớ Ví dụ 2 **

Unfortunately, tracing a profile like this to the actual problem in the code can be very difficult indeed. Whatâ€™s worse, although our change introduced a regression, the application still worked fine and so the test suite probably wouldnâ€™t have failed. Such memory leaks tend to be discovered only when they get so bad in production that things start to break (for example, servers running out of memory), at which point you have an emergency on your hands.

Thật không may, việc truy tìm một hồ sơ như thế này đối với vấn đề thực tế trong mã thực sự có thể rất khó khăn.
Điều tồi tệ hơn, mặc dù thay đổi của chúng tôi đã giới thiệu một hồi quy, ứng dụng vẫn hoạt động tốt và do đó bộ thử nghiệm có thể sẽ không thành công.
Rò rỉ bộ nhớ như vậy có xu hướng chỉ được phát hiện khi chúng trở nên tồi tệ trong sản xuất đến nỗi mọi thứ bắt đầu bị hỏng (ví dụ, máy chủ hết bộ nhớ), tại thời điểm đó bạn có trường hợp khẩn cấp trên tay.

In the remainder of this post we will describe how nothunks can help both with spotting such problems much earlier, and debugging them.

Trong phần còn lại của bài đăng này, chúng tôi sẽ mô tả cách Nothunks có thể giúp cả hai với việc phát hiện ra những vấn đề như vậy sớm hơn nhiều và gỡ lỗi chúng.

## **Instrumenting the code**

## ** Thiết bị mã **

Letâ€™s first see what usage of nothunks looks like in our example. We modify our code and derive a new class instance for our AppState:

Trước tiên, hãy xem cách sử dụng của Nothunks trông như thế nào trong ví dụ của chúng tôi.
Chúng tôi sửa đổi mã của chúng tôi và rút ra một thể hiện lớp mới cho AppState của chúng tôi:

data AppState = AppState {

Dữ liệu appstate = appstate {

`      `total :: !Int

`` Tổng cộng ::! Int

`    `, indiv :: !(Map Char Stats)

``, indiv ::! (Số liệu thống kê của bản đồ)

`    `}

``}

`  `deriving (Show, Generic, NoThunks)

`` xuất phát (hiển thị, chung chung, không có)

The NoThunks class is defined in the nothunks library, as we will see in detail later. Additionally, we will replace foldl' with a new function:

Lớp Nothunks được xác định trong thư viện Nothunks, như chúng ta sẽ thấy chi tiết sau.
Ngoài ra, chúng tôi sẽ thay thế Foldl 'bằng một chức năng mới:

repeatedly :: forall a b. (NoThunks b, HasCallStack)

lặp đi lặp lại :: forall a b.
(Nothunks B, Hascallstack)

`           `=> (b -> a -> b) -> (b -> [a] -> b)

`` => (b -> a -> b) -> (b -> [a] -> b)

repeatedly f = ..

nhiều lần f = ..

We will see how to define repeatedly later, but, for now, think of it as 'foldl' with some magic sprinkled on topâ€™. If we run the code again, the application will throw an exception almost immediately:

Chúng ta sẽ thấy cách xác định nhiều lần sau này, nhưng, bây giờ, hãy nghĩ về nó là 'Foldl' với một số phép thuật được rắc lên Topâ € ™.
Nếu chúng tôi chạy lại mã, ứng dụng sẽ ném một ngoại lệ gần như ngay lập tức:

\# dd if=/dev/zero bs=1M count=100 | cabal run example3

\# dd if =/dev/zero bs = 1m đếm = 100 |
Cabal chạy ví dụ3

(..)

(..)

example3: Unexpected thunk with context

Ví dụ3: Thunk bất ngờ với bối cảnh

`  `["Int","(,)","Map","AppState"]

`` ["Int", "(,)", "map", "appstate"]]

CallStack (from HasCallStack):

CallStack (từ Hascallstack):

`  `error, called at shared/Util.hs:22:38 in Util

`` Lỗi, được gọi là chia sẻ/UTIL.HS: 22: 38 trong Util

`  `repeatedly, called at app3/Main.hs:38:26 in main:Main

`` Nhiều lần, được gọi tại APP3/Main.HS: 38: 26 trong chính: Main

The essence of the nothunks library is that we can check if a particular value contains any thunks we werenâ€™t expecting, and this is what repeatedly is using to make sure weâ€™re not inadvertently introducing any thunks in the AppState; itâ€™s this check that is failing and causing the exception. We get a HasCallStack backtrace telling us where we introduced that thunk, and â€“ even more importantly â€“ the exception gives us a helpful clue about where the thunk was:

Bản chất của thư viện Nothunks là chúng tôi có thể kiểm tra xem một giá trị cụ thể có chứa bất kỳ thunks nào mà chúng tôi không mong đợi không, và đây là những gì nhiều lần sử dụng để đảm bảo rằng chúng tôi không vô tình giới thiệu bất kỳ thunks nào trong AppState;
Đó là kiểm tra này không thành công và gây ra ngoại lệ.
Chúng tôi nhận được một backtrace hascallstack cho chúng tôi biết nơi chúng tôi đã giới thiệu rằng Thunk đó, và thậm chí quan trọng hơn là ngoại lệ cho chúng tôi một manh mối hữu ích về việc thunk ở đâu:

["Int","(,)","Map","AppState"]

["Int", "(,)", "map", "appstate"]]]

This context tells us that we have an AppState containing a Map containing tuples, all of which were in weak head normal form (not thunks), *but* the tuple contained an Int which *was not* in weak head normal form: a thunk.

Bối cảnh này cho chúng ta biết rằng chúng ta có một appstate chứa bản đồ chứa các bộ dữ
.

From a context like this it is obvious what went wrong: although we are using a strict map, we have instantiated the map at a lazy pair type, and so although the map is forcing the *pairs*, itâ€™s not forcing the *elements* of those pairs. Moreover, we get an exception the *moment* we introduce the thunk, which means that we can catch such regressions in our test suite. We can even construct minimal counter-examples that result in thunks, as we will see later.

Từ một bối cảnh như thế này, rõ ràng những gì đã sai: mặc dù chúng tôi đang sử dụng một bản đồ nghiêm ngặt, chúng tôi đã khởi tạo bản đồ ở một loại cặp lười
* Các yếu tố* của các cặp đó.
Hơn nữa, chúng tôi có một ngoại lệ * khoảnh khắc * Chúng tôi giới thiệu Thunk, điều đó có nghĩa là chúng tôi có thể bắt được các hồi quy như vậy trong bộ thử nghiệm của chúng tôi.
Chúng ta thậm chí có thể xây dựng các ví dụ phản công tối thiểu dẫn đến thunks, như chúng ta sẽ thấy sau.

## **Using nothunks**

## ** sử dụng nothunks **

Before we look at how the library works, letâ€™s first see how itâ€™s used. In the previous section we were using a magical function repeatedly, but didnâ€™t see how we could define it. Letâ€™s now look at this function:

Trước khi chúng ta xem xét cách thức hoạt động của thư viện, trước tiên hãy xem nó được sử dụng như thế nào.
Trong phần trước, chúng tôi đã sử dụng một hàm ma thuật nhiều lần, nhưng không thấy làm thế nào chúng ta có thể xác định nó.
Bây giờ hãy xem chức năng này:

repeatedly :: forall a b. (NoThunks b, HasCallStack)

lặp đi lặp lại :: forall a b.
(Nothunks B, Hascallstack)

`           `=> (b -> a -> b) -> (b -> [a] -> b)

`` => (b -> a -> b) -> (b -> [a] -> b)

repeatedly f = go

nhiều lần f = đi

`  `where

`` Ở đâu

`    `go :: b -> [a] -> b

`` go :: b -> [a] -> b

`    `go !b []     = b

`` Đi! B [] = B

`    `go !b (a:as) =

`` GO! B (A: AS) =

`        `let !b' = f b a

`` let! B '= f b

`        `in case unsafeNoThunks b' of

`` trong trường hợp unsafenothunks b 'của

`              `Nothing    -> go b' as

`` Không có gì -> đi b 'như

`              `Just thunk -> error . concat $ [

`` Chỉ cần thunk -> lỗi.
concat $ [

`                  `"Unexpected thunk with context "

`` "Thunk bất ngờ với bối cảnh"

`                `, show (thunkContext thunk)

``, show (thunkcontext thunk)

`                `]

``]

The only difference between repeatedly and foldl' is the call to unsafeNoThunks, which is the function that checks if a given value contains any unexpected thunks. The function is marked as â€˜unsafeâ€™ because whether or not a value is a thunk is not normally observable in Haskell; making it observable breaks equational reasoning, and so this should only be used for debugging or in assertions. Each time repeatedly applies the provided function f to update the accumulator, it verifies that the resulting value doesnâ€™t contain any unexpected thunks; if it does, it errors out (in real code such a check would only be enabled in test suites and not in production).

Sự khác biệt duy nhất giữa lặp đi lặp lại và Foldl 'là cuộc gọi đến unsafenothunks, đó là chức năng kiểm tra xem một giá trị nhất định có chứa bất kỳ thunks bất ngờ nào không.
Hàm được đánh dấu là "˜unsafe" vì liệu một giá trị có thể không có thể quan sát được ở Haskell hay không;
Làm cho nó có thể quan sát được phá vỡ lý luận phương trình, và do đó, điều này chỉ nên được sử dụng để gỡ lỗi hoặc xác nhận.
Mỗi lần áp dụng nhiều lần chức năng được cung cấp để cập nhật bộ tích lũy, nó xác minh rằng giá trị kết quả không chứa bất kỳ thunks bất ngờ nào;
Nếu có, nó bị lỗi (trong mã thực như một kiểm tra như vậy sẽ chỉ được bật trong các bộ thử nghiệm chứ không phải trong sản xuất).

One point worth emphasizing is that repeatedly reduces the value to weak head normal form (WHNF) *before* calling unsafeNoThunks. This is, of course, what makes a strict fold-left *strict*, and so repeatedly must do this to be a good substitute for foldl'. However, it is important to realize that if repeatedly *did not* do that, the call to unsafeNoThunks would trivially and immediately report a thunk; after all, we have just created the f b a thunk! Generally speaking, it is not useful to call unsafeNoThunks (or its IO cousin noThunks) on values that arenâ€™t already in WHNF.

Một điểm đáng để nhấn mạnh là nhiều lần giảm giá trị thành dạng bình thường đầu yếu (WHNF) * trước khi * gọi unsafenothunks.
Tất nhiên, đây là những gì tạo nên một lần nếp gấp *nghiêm ngặt *, và do đó, nhiều lần phải làm điều này để trở thành một sự thay thế tốt cho Foldl '.
Tuy nhiên, điều quan trọng là phải nhận ra rằng nếu nhiều lần * không * làm điều đó, lời kêu gọi unsafenothunks sẽ tầm thường và ngay lập tức báo cáo một thunk;
Rốt cuộc, chúng tôi vừa tạo ra F B A Thunk!
Nói chung, không hữu ích khi gọi unsafenothunks (hoặc người anh em họ IO của nó) trên các giá trị đã phát sinh trong WHNF.

In general, long-lived application state should never contain any unexpected thunks, and so we can apply the same kind of pattern in other scenarios. For example, suppose we have a server that is a thin IO layer on top of a mostly pure code base, storing the application state in an IORef. Here, too, we might want to make sure that that IORef never points to a value containing unexpected thunks:

Nói chung, trạng thái ứng dụng tồn tại lâu không bao giờ nên chứa bất kỳ thunks bất ngờ nào, và vì vậy chúng tôi có thể áp dụng cùng một loại mẫu trong các kịch bản khác.
Ví dụ: giả sử chúng ta có một máy chủ là một lớp IO mỏng trên đầu cơ sở mã chủ yếu là thuần túy, lưu trữ trạng thái ứng dụng trong IOREF.
Ở đây cũng vậy, chúng tôi có thể muốn đảm bảo rằng IOREF không bao giờ trỏ đến một giá trị chứa Thunks bất ngờ:

newtype StrictIORef a = StrictIORef (IORef a)

newtype Strictioref a = Strictioref (Ioref A)

readIORef :: StrictIORef a -> IO a

readioref :: Strictioref a -> io a

readIORef (StrictIORef v) = Lazy.readIORef v

Readioref (Strictioref V) = Lazy.Readioref V

writeIORef :: (NoThunks a, HasCallStack)

writeioref :: (nothunks a, hascallstack)

`           `=> StrictIORef a -> a -> IO ()

`` => Strictioref a -> a -> io ()

writeIORef (StrictIORef v) !x = do

writeioref (Strictioref v)! x = do

`    `check x

`` Kiểm tra x

`    `Lazy.writeIORef v x

`` Lazy.writeioref V x

check :: (NoThunks a, HasCallStack) => a -> IO ()

Kiểm tra :: (Nothunks A, Hascallstack) => a -> io ()

check x = do

kiểm tra x = làm

`    `mThunk <- noThunks [] x

`` mthunk <- nothunks [] x

`    `case mThunk of

`` Trường hợp Mthunk của

`      `Nothing -> return ()

`` Không có gì -> return ()

`      `Just thunk ->

`` Chỉ cần thunk ->

`        `throw $ ThunkException

`` Ném $ Thunkexception

`                  `(thunkContext thunk)

`` (ThunkContext thunk)

`                  `callStack

`` Callstack

Since check already lives in IO, it can use noThunks directly, instead of using the unsafe pure wrapper; but otherwise this code follows a very similar pattern: the moment we might introduce a thunk, we instead throw an exception. One could imagine doing a very similar thing for, say, StateT, checking for thunks in put:

Vì kiểm tra đã sống trong IO, nó có thể sử dụng trực tiếp, thay vì sử dụng trình bao bọc tinh khiết không an toàn;
Nhưng nếu không, mã này tuân theo một mô hình rất giống nhau: khoảnh khắc chúng tôi có thể giới thiệu một thunk, thay vào đó chúng tôi ném một ngoại lệ.
Người ta có thể tưởng tượng làm một điều rất giống nhau, nói, Statet, kiểm tra Thunks trong Put:

newtype StrictStateT s m a = StrictStateT (StateT s m a)

Newtype StrictStatet s m a = StrictStatet (Statet S M A)

`  `deriving (Functor, Applicative, Monad)

`` Deriving (functor, Ứng dụng, Monad)

instance (Monad m, NoThunks s)

ví dụ (Monad M, Nothunks S)

`      `=> MonadState s (StrictStateT s m) where

`` => Monadstate s (StrictStatet s m) ở đâu

`  `get    = StrictStateT $ get

`` get = StrictStatet $ get

`  `put !s = StrictStateT $

`` Đặt! S = StrictStatet $

`      `case unsafeNoThunks s of

`` Trường hợp unsafenothunks s của

`        `Nothing -> put s

`` Không có gì -> đặt S

`        `Just thunk -> error . concat $ [

`` Chỉ cần thunk -> lỗi.
concat $ [

`            `"Unexpected thunk with context "

`` "Thunk bất ngờ với bối cảnh"

`          `, show (thunkContext thunk)

``, show (thunkcontext thunk)

`          `]

``]

## **Minimal counter-examples**

## ** Các ví dụ phản đối tối thiểu **

In some applications, there can be complicated interactions between the input to the program and the thunks it may or may not create. We will study this through a somewhat convoluted but, hopefully, easy-to-understand example. Suppose we have a server that is processing two types of events, A and B:

Trong một số ứng dụng, có thể có các tương tác phức tạp giữa đầu vào cho chương trình và thunks mà nó có thể hoặc không thể tạo.
Chúng tôi sẽ nghiên cứu điều này thông qua một ví dụ hơi phức tạp nhưng, hy vọng, dễ hiểu.
Giả sử chúng ta có một máy chủ đang xử lý hai loại sự kiện, A và B:

data Event = A | B

Sự kiện dữ liệu = A |
B

`  `deriving (Show)

`` Deriving (Hiển thị)

type State = (Int, Int)

Loại trạng thái = (int, int)

initState :: State

initState :: State

initState = (0, 0)

initState = (0, 0)

update :: Event -> State -> State

CẬP NHẬT :: Sự kiện -> State -> State

update A (a, b)    = let !a' = a + 1 in (a', b)

Cập nhật A (A, B) = LET! A '= A + 1 IN (A', B)

update B (a, b)

Cập nhật B (A, B)

`  `| a < 1 || b < 1 = let !b' = b + 1 in (a, b')

`` |
A <1 ||
B <1 = let! B '= b + 1 in (a, b')

`  `| otherwise      = let  b' = b + 2 in (a, b')

`` |
Nếu không = Đặt B '= B + 2 in (A, B')

The serverâ€™s internal state consists of two counters, a and b. Each time we see an A event, we just increment the first counter. When we see a B event, however, we increment b by 1 only if a and b havenâ€™t reached 1 yet, and by 2 otherwise. Unfortunately, the code contains a bug: in one of these cases, part of the serverâ€™s state is not forced and we introduce a thunk. (Disclaimer: the code snippets in this blog post are not intended to be good examples of coding, but to make it obvious where memory leaks are introduced. Typically, memory leaks should be avoided by using appropriate *data types*, not by modifying *code*.)

Trạng thái nội bộ của máy chủ bao gồm hai bộ đếm, a và b.
Mỗi lần chúng tôi thấy một sự kiện, chúng tôi chỉ cần tăng bộ đếm đầu tiên.
Tuy nhiên, khi chúng tôi thấy một sự kiện B, chúng tôi tăng B bằng 1 chỉ khi A và B Haven không đạt được 1, và bằng 2 nếu không.
Thật không may, mã chứa một lỗi: Trong một trong những trường hợp này, một phần trạng thái của máy chủ không bị ép buộc và chúng tôi giới thiệu một thunk.
.
mã số*.)

A minimal counter-example that will demonstrate the bug would therefore involve two events A and B, in any order, followed by another B event. Since we get an exception the *moment* we introduce an exception, we can then use a framework such as quickcheck-state-machine to find bugs like this and construct such minimal counter-examples.

Do đó, một ví dụ phản đối tối thiểu sẽ chứng minh lỗi sẽ liên quan đến hai sự kiện A và B, theo bất kỳ thứ tự nào, theo sau là một sự kiện B khác.
Vì chúng tôi nhận được một ngoại lệ * khoảnh khắc * Chúng tôi giới thiệu một ngoại lệ, sau đó chúng tôi có thể sử dụng một khung như que-máy của QuickCheck-State để tìm các lỗi như thế này và xây dựng các ví dụ phản đối tối thiểu như vậy.

Hereâ€™s how we might set up our test. Explaining how quickcheck-state-machine (QSM) works is well outside the scope of this blog post; if youâ€™re interested, a good starting point might be [An in-depth look at quickcheck-state-machine](http://www.well-typed.com/blog/2019/01/qsm-in-depth/). For this post, it is enough to know that in QSM we are comparing a real implementation against some kind of model, firing off â€˜commandsâ€™ against both, and then checking that the responses match. Here, both the server and the model will use the update function, but the â€˜realâ€™ implementation will use the StrictIORef type we introduced above, and the mock implementation will just use the pure code, with no thunks check. Thus, when we compare the real implementation against the model, the responses will diverge whenever the real implementation throws an exception (caused by a thunk):

Đây là cách chúng tôi có thể thiết lập bài kiểm tra của mình.
Giải thích cách thức hoạt động của QuickCheck-State-Machine (QSM) nằm ngoài phạm vi của bài đăng trên blog này;
Nếu bạn quan tâm, một điểm khởi đầu tốt có thể là [một cái nhìn sâu sắc về QuickCheck-State-Machine] (http://www.well-typed.com/blog/2019/01/qsm-in-depth
/).
Đối với bài đăng này, nó đủ để biết rằng trong QSM, chúng tôi đang so sánh một triển khai thực sự với một loại mô hình nào đó, bắn ra "Commands" với cả hai, sau đó kiểm tra xem các phản hồi có khớp không.
Ở đây, cả máy chủ và mô hình sẽ sử dụng chức năng cập nhật, nhưng việc triển khai thực tế sẽ sử dụng loại nghiêm ngặt mà chúng tôi đã giới thiệu ở trên và việc triển khai giả sẽ chỉ sử dụng mã thuần túy, không có kiểm tra Thunks.
Do đó, khi chúng tôi so sánh việc triển khai thực với mô hình, các phản hồi sẽ phân kỳ bất cứ khi nào triển khai thực sự ném một ngoại lệ (gây ra bởi một thunk):

data T

dữ liệu t

type instance MockState   T = State

Loại phiên bản mockstate t = state

type instance RealMonad   T = IO

Loại phiên bản RealMonad T = IO

type instance RealHandles T = '[]

Nhập phiên bản realHandles t = '[]

data instance Cmd T f hs where

thể hiện dữ liệu cmd t f hs ở đâu

`  `Cmd :: Event -> Cmd T f '[]

`` CMD :: Sự kiện -> CMD T F '[]

data instance Resp T f hs where

thể hiện dữ liệu tương ứng với hs ở đâu

`  `-- We record any exceptions that occurred

``- Chúng tôi ghi lại bất kỳ trường hợp ngoại lệ nào xảy ra

`  `Resp :: Maybe String -> Resp T f '[]

`` RESP :: Có thể chuỗi -> resp t f '[]

deriving instance Eq   (Resp T f hs)

Lấy ví dụ EQ (resp t f hs)

deriving instance Show (Resp T f hs)

Hiển thị thể hiện (Rev T f hs)

deriving instance Show (Cmd  T f hs)

Hiển thị thể hiện (CMD T F HS)

instance NTraversable (Resp T) where

ví dụ ntraversable (resp t) ở đâu

`  `nctraverse \_ \_ (Resp ok) = pure (Resp ok)

`` NCTRAURES \ _ \ _ (resp ok) = tinh khi

instance NTraversable (Cmd T) where

ví dụ ntraversable (cmd t) ở đâu

`  `nctraverse \_ \_ (Cmd e) = pure (Cmd e)

`` NCTRAURES \ _ \ _ (CMD E) = Pure (CMD E)

**This document was truncated here because it was created in the Evaluation Mode.**

** Tài liệu này đã bị cắt ngắn ở đây vì nó được tạo trong chế độ đánh giá. **

