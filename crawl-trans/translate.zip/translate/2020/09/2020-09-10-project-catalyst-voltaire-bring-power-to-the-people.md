# Project Catalyst and Voltaire bring power to the people
### **Establishing a long-term future for Cardano growth has begun with a treasury and democratic voting in the Catalyst project**
![](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.002.png) 10 September 2020![](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.002.png)[ Bingsheng Zhang](tmp//en/blog/authors/bingsheng-zhang/page-1/)![](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.003.png) 7 mins read

![Bingsheng Zhang](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.004.png)[](tmp//en/blog/authors/bingsheng-zhang/page-1/)
### [**Bingsheng Zhang**](tmp//en/blog/authors/bingsheng-zhang/page-1/)
Research Fellow

Academic Research

- ![](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.005.png)[](mailto:bingsheng.zhang@iohk.io "Email")
- ![](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.006.png)[](https://www.linkedin.com/in/bingsheng-zhang-05558659/ "LinkedIn")
- ![](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.007.png)[](https://twitter.com/BingshengZ "Twitter")
- ![](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.008.png)[](https://github.com/BingyZhang "GitHub")

![Project Catalyst and Voltaire bring power to the people](img/2020-09-10-project-catalyst-voltaire-bring-power-to-the-people.009.jpeg)

Designing a groundbreaking proof-of-stake blockchain means it is vital to ensure that the system is self-sustainable. This will allow it to drive growth and maturity in a truly decentralized and organic way. [Voltaire](https://roadmap.cardano.org/en/voltaire/) is IOHKâ€™s way of establishing this capability, allowing the community to maintain the Cardano blockchain while continuing to develop it by proposing and implementing system improvements. This puts the power to make decisions in the hands of ada holders.

Thiết kế một blockchain bằng chứng đột phá có nghĩa là điều quan trọng là phải đảm bảo rằng hệ thống là tự bền vững.
Điều này sẽ cho phép nó thúc đẩy tăng trưởng và trưởng thành theo cách thực sự phi tập trung và hữu cơ.
.
Điều này đặt sức mạnh để đưa ra quyết định trong tay của những người nắm giữ Ada.

Rigorous research lies at the heart of building a solid blockchain. Julyâ€™s Shelley summit included a presentation on the importance of funding for the growth of Cardano. This was based on research between Lancaster University and IOHK into the [notion of a treasury system](https://eprint.iacr.org/2018/435.pdf) and an [effective, democratic approach to funding Cardanoâ€™s long-term development](https://www.youtube.com/watch?v=cXCmvQg_-J8). IOHK has now applied treasury mechanism capabilities in Project Catalyst, which combines research, social experiments and community consent to establish an open, democratic culture within the Cardano community.

Nghiên cứu nghiêm ngặt nằm ở trung tâm xây dựng một blockchain vững chắc.
Hội nghị thượng đỉnh Shelley của tháng 7 bao gồm một bài thuyết trình về tầm quan trọng của việc tài trợ cho sự phát triển của Cardano.
Điều này dựa trên nghiên cứu giữa Đại học Lancaster và IOHK thành [khái niệm về hệ thống kho bạc] (https://eprint.iacr.org/2018/435.pdf) và một cách tiếp cận dân chủ, hiệu quả để tài trợ cho Cardano dài
-Term phát triển] (https://www.youtube.com/watch?v=CXCMVQG_-J8).
IOHK hiện đã áp dụng các khả năng cơ chế kho bạc trong Project Catalyst, kết hợp nghiên cứu, thí nghiệm xã hội và sự đồng ý của cộng đồng để thiết lập một nền văn hóa dân chủ mở, dân chủ trong cộng đồng Cardano.

## **A democratic approach**

## ** Một cách tiếp cận dân chủ **

With the rapid growth of blockchain technology, the world is witnessing the emergence of platforms across a variety of industries. Technological growth and maturity are essential for long-term blockchain sustainability and development. That is why someone has to support and fund growth and system enhancements. A democratic approach is an integral part of the blockchain ecosystem because it allows sustainability decisions to be made collaboratively, without relying on a central governing entity. Thus, the governing and decision-making process must be collective. This will allow users to understand how improvements are made, who makes decisions, and ultimately where the funding comes from to make these choices.

Với sự phát triển nhanh chóng của công nghệ blockchain, thế giới đang chứng kiến sự xuất hiện của các nền tảng trong nhiều ngành công nghiệp.
Tăng trưởng công nghệ và sự trưởng thành là rất cần thiết cho sự bền vững và phát triển blockchain dài hạn.
Đó là lý do tại sao ai đó phải hỗ trợ và tài trợ cho tăng trưởng và cải tiến hệ thống.
Một cách tiếp cận dân chủ là một phần không thể thiếu của hệ sinh thái blockchain vì nó cho phép các quyết định bền vững được hợp tác, mà không dựa vào một thực thể quản lý trung tâm.
Do đó, quá trình quản lý và ra quyết định phải là tập thể.
Điều này sẽ cho phép người dùng hiểu cách cải thiện, người đưa ra quyết định và cuối cùng là nơi tài trợ đến từ để đưa ra những lựa chọn này.

## **Long-term sustainability**

## ** Tính bền vững lâu dài **

There are several ways to raise capital for development purposes. Donations, venture capital funding, and initial coin offerings (ICOs) are the most common. However, although such models may work for raising initial capital, they rarely ensure a long-term funding source or predict the amount of capital needed for development and maintenance. In addition, these models suffer from centralized control, making it difficult to find a consensus meeting the needs and goals of everyone.

Có một số cách để tăng vốn cho mục đích phát triển.
Quyên góp, tài trợ đầu tư mạo hiểm và các dịch vụ tiền xu ban đầu (ICO) là phổ biến nhất.
Tuy nhiên, mặc dù các mô hình như vậy có thể hoạt động để tăng vốn ban đầu, nhưng chúng hiếm khi đảm bảo nguồn tài trợ dài hạn hoặc dự đoán số vốn cần thiết để phát triển và bảo trì.
Ngoài ra, các mô hình này bị kiểm soát tập trung, gây khó khăn cho việc tìm thấy sự đồng thuận đáp ứng nhu cầu và mục tiêu của mọi người.

To establish a long-term funding source for blockchain development, some cryptocurrency projects apply taxation, taking a percentage from fees or rewards, and accumulating them in a separate pool â€“ a *treasury*. Treasury funds can then be used for system development and maintenance purposes. In addition, treasury reserves undergo inflation as the value of cryptocurrencies grows. This grants another potential source of funds accretion.

Để thiết lập một nguồn tài trợ dài hạn cho phát triển blockchain, một số dự án tiền điện tử áp dụng thuế, lấy tỷ lệ phần trăm từ phí hoặc phần thưởng và tích lũy chúng trong một nhóm riêng biệt-Kho bạc *.
Quỹ Kho bạc sau đó có thể được sử dụng cho mục đích phát triển và bảo trì hệ thống.
Ngoài ra, dự trữ Kho bạc trải qua lạm phát khi giá trị của tiền điện tử tăng lên.
Điều này cho phép một nguồn kế toán quỹ tiềm năng khác.

However, funding systems are often at risk of centralization when making decisions on guiding development. In these systems, only certain individuals in the organization or company are empowered to make decisions on how to use available funds and for which purposes. Considering that the decentralized architecture of blockchain makes it inappropriate to have centralized control over funding, disagreement can arise among organization members and lead to complex disputes.

Tuy nhiên, các hệ thống tài trợ thường có nguy cơ tập trung hóa khi đưa ra quyết định hướng dẫn phát triển.
Trong các hệ thống này, chỉ một số cá nhân trong tổ chức hoặc công ty được trao quyền để đưa ra quyết định về cách sử dụng các quỹ có sẵn và cho mục đích nào.
Xem xét rằng kiến trúc phi tập trung của blockchain khiến việc kiểm soát tài trợ tập trung, bất đồng có thể phát sinh giữa các thành viên tổ chức và dẫn đến các tranh chấp phức tạp.

## **Treasury systems and Cardano**

## ** Hệ thống Kho bạc và Cardano **

A number of treasury systems have arisen to address the problems. These systems may consist of iterative treasury periods during which project funding proposals are submitted, discussed, and voted on. However, common drawbacks include poor voter privacy or ballot submission security. In addition, the soundness of funding decisions can be compromised if master nodes are subject to coercion, or a lack of expert involvement might encourage irrational behavior.

Một số hệ thống kho bạc đã phát sinh để giải quyết các vấn đề.
Các hệ thống này có thể bao gồm các giai đoạn Kho bạc lặp đi lặp lại trong đó các đề xuất tài trợ dự án được gửi, thảo luận và bỏ phiếu.
Tuy nhiên, những hạn chế phổ biến bao gồm quyền riêng tư cử tri kém hoặc bảo mật đệ trình bỏ phiếu.
Ngoài ra, tính đúng đắn của các quyết định tài trợ có thể bị xâm phạm nếu các nút chính bị ép buộc, hoặc thiếu sự tham gia của chuyên gia có thể khuyến khích hành vi phi lý.

As a third-generation cryptocurrency platform, Cardano was created to solve the difficulties encountered by previous platforms.

Là một nền tảng tiền điện tử thế hệ thứ ba, Cardano đã được tạo ra để giải quyết những khó khăn mà các nền tảng trước đó gặp phải.

Cardano aims to bring democracy to the process, giving power to everyone and so ensuring that decisions are fair. For this, it is crucial to put in place transparent voting and funding processes. This is where Voltaire comes in.

Cardano nhằm mục đích mang lại nền dân chủ cho quá trình này, trao quyền lực cho mọi người và vì vậy đảm bảo rằng các quyết định là công bằng.
Đối với điều này, điều quan trọng là phải đưa ra các quy trình bỏ phiếu và tài trợ minh bạch.
Đây là nơi Voltaire đến.

The paper on [treasury systems for cryptocurrencies](https://www.ndss-symposium.org/wp-content/uploads/2019/02/ndss2019_02A-2_Zhang_paper.pdf) introduces a community-controlled, decentralized, collaborative decision-making mechanism for sustainable funding of blockchain development and maintenance. This approach to collaborative intelligence relies on â€˜liquid democracyâ€™ â€“ a hybrid of direct and representative democracy that provides the benefits of both systems.

Bài viết về [Hệ thống kho bạc cho tiền điện tử] (https://www.ndss-symposium.org/wp-content/uploads/2019/02/ndss2019_02a-2_zhang_aper.pdf)
Cơ chế tài trợ bền vững của phát triển và bảo trì blockchain.
Cách tiếp cận này đối với tình báo hợp tác dựa trên "Dân chủ liquid" Một sự kết hợp của nền dân chủ trực tiếp và đại diện mang lại lợi ích của cả hai hệ thống.

This approach enables the treasury system to take advantage of expert knowledge in a voting process, as well as ensuring that all ada holders are granted an opportunity to vote. Thus, for each project, a voter can either vote directly or delegate their voting power to a member of the community who is an expert on the topic.

Cách tiếp cận này cho phép hệ thống Kho bạc tận dụng kiến thức chuyên môn trong quá trình bỏ phiếu, cũng như đảm bảo rằng tất cả các chủ sở hữu ADA đều được cấp cơ hội để bỏ phiếu.
Do đó, đối với mỗi dự án, một cử tri có thể bỏ phiếu trực tiếp hoặc ủy thác quyền bầu cử của họ cho một thành viên của cộng đồng, một chuyên gia về chủ đề này.

To ensure sustainability, the treasury system is controlled by the community and is refilled constantly from potential sources such as:

Để đảm bảo tính bền vững, hệ thống kho bạc được cộng đồng kiểm soát và được nạp lại liên tục từ các nguồn tiềm năng như:

- some newly-minted coins being held back as funding

- Một số đồng tiền mới được đóng lại dưới dạng tài trợ

- a percentage of stake pool rewards and transaction fees

- Phần trăm phần thưởng của nhóm cổ phần và phí giao dịch

- additional donations or charity

- Đóng góp bổ sung hoặc từ thiện

Because funds are being accumulated continually, it will be possible to fund projects and pay for improvement proposals. 

Bởi vì các quỹ đang được tích lũy liên tục, nên có thể tài trợ cho các dự án và trả tiền cho các đề xuất cải tiến.

So, the funding process can consist of â€˜treasury periodsâ€™, with each being divided into the following phases:

Vì vậy, quy trình tài trợ có thể bao gồm các giai đoạn ", với mỗi giai đoạn được chia thành các giai đoạn sau:

- pre-voting 

- Pre-bỏ phiếu

- voting 

- Bỏ phiếu

- post-voting

- Hậu bỏ phiếu

During each period, project proposals may be submitted, discussed by experts and voters, and finally voted for to fund the most essential projects. Even though anyone can submit a proposal, only certain proposals can be supported depending on their importance and desirability for network development. 

Trong mỗi giai đoạn, các đề xuất dự án có thể được gửi, thảo luận bởi các chuyên gia và cử tri, và cuối cùng đã bỏ phiếu để tài trợ cho các dự án thiết yếu nhất.
Mặc dù bất cứ ai cũng có thể gửi một đề xuất, chỉ có một số đề xuất nhất định có thể được hỗ trợ tùy thuộc vào tầm quan trọng và mong muốn của chúng đối với phát triển mạng.

## **Voting and decision making**

## ** Bỏ phiếu và ra quyết định **

To understand which project should be funded first, letâ€™s discuss the process of decision-making. 

Để hiểu dự án nào nên được tài trợ trước, hãy thảo luận về quá trình ra quyết định.

Ada holders who participate in treasury voting include scientists and developers, management team members, and investors and the general public. Each of these may have different imperatives for the growth of the system, and that is why there has to be a way to make these choices and desires work together.

Những người nắm giữ ADA tham gia bỏ phiếu kho bạc bao gồm các nhà khoa học và nhà phát triển, thành viên nhóm quản lý và nhà đầu tư và công chúng nói chung.
Mỗi trong số này có thể có các mệnh lệnh khác nhau cho sự phát triển của hệ thống, và đó là lý do tại sao phải có một cách để làm cho những lựa chọn và mong muốn này hoạt động cùng nhau.

For this, the voting power is proportional to the amount of ada someone owns; the more ada, the more influence in making decisions. As part of the liquid democracy approach, as well as direct yes/no voting, an individual may delegate their voting power to an expert they trust. In this case, the expert will be able to vote directly on the proposal they regard as the most important. After the voting, project proposals may be scored based on the number of yes/no votes and be shortlisted; the weakest project proposals will be discarded. Then, shortlisted proposals can be ranked according to their score, and the top-ranked proposals will be funded in turn until the treasury fund is exhausted. The strategy of dividing the decision-making process into stages allows reaching consensus on the priority of improvements.

Đối với điều này, sức mạnh bỏ phiếu tỷ lệ thuận với số lượng ADA mà ai đó sở hữu;
ADA càng nhiều, càng có nhiều ảnh hưởng trong việc đưa ra quyết định.
Là một phần của phương pháp dân chủ lỏng, cũng như có/không bỏ phiếu trực tiếp, một cá nhân có thể ủy thác quyền bầu cử của họ cho một chuyên gia mà họ tin tưởng.
Trong trường hợp này, chuyên gia sẽ có thể bỏ phiếu trực tiếp về đề xuất mà họ coi là quan trọng nhất.
Sau khi bỏ phiếu, các đề xuất dự án có thể được ghi dựa trên số lượng phiếu bầu có/không và được lọt vào danh sách;
Các đề xuất dự án yếu nhất sẽ bị loại bỏ.
Sau đó, các đề xuất lọt vào danh sách có thể được xếp hạng theo điểm số của họ, và các đề xuất được xếp hạng hàng đầu sẽ được tài trợ lần lượt cho đến khi Quỹ Kho bạc cạn kiệt.
Chiến lược chia quá trình ra quyết định thành các giai đoạn cho phép đạt được sự đồng thuận về mức độ ưu tiên của các cải tiến.

To ensure voter privacy, the research team has invented an â€˜honest verifier zero-knowledge proof for unit vector encryption with logarithmic size communicationâ€™. Zero-knowledge techniques are mathematical methods used to verify things without revealing any underlying data. In this case, the zero-knowledge proof means that someone can vote without revealing any information about themselves, other than that they are eligible to vote. This eliminates any possibility of voter coercion. 

Để đảm bảo quyền riêng tư của cử tri, nhóm nghiên cứu đã phát minh ra một bằng chứng xác nhận không biết gì về mã hóa đơn vị với mã hóa kích thước logarit.
Các kỹ thuật không hiểu biết là các phương pháp toán học được sử dụng để xác minh mọi thứ mà không tiết lộ bất kỳ dữ liệu cơ bản nào.
Trong trường hợp này, bằng chứng không hiểu biết có nghĩa là ai đó có thể bỏ phiếu mà không tiết lộ bất kỳ thông tin nào về bản thân họ, ngoài việc họ đủ điều kiện để bỏ phiếu.
Điều này loại bỏ bất kỳ khả năng ép buộc cử tri.

Treasury prototypes have been created at IOHK for benchmarking. Implementing the research as the basis of Voltaire will help to deliver reliable and secure means for treasury voting and decision-making. Project Catalyst is an experimental treasury system that combines proposal and voting procedures focusing on the establishment of a democratic culture within the Cardano community. Initially, Cardanoâ€™s treasury will be refilled from a percentage of stake pool rewards ensuring a sustainable treasury source. Other blockchains have treasury systems, but IOHKâ€™s combines complete privacy through zero-knowledge proofs, liquid democracy from expert involvement and vote delegation, and participation for all, not just a governing entity. This should encourage participation, incentivization, and decentralization for making fair and transparent decisions. 

Các nguyên mẫu của Kho bạc đã được tạo ra tại IOHK để điểm chuẩn.
Việc thực hiện nghiên cứu làm cơ sở của Voltaire sẽ giúp cung cấp các phương tiện đáng tin cậy và an toàn cho việc bỏ phiếu và ra quyết định của Kho bạc.
Project Catalyst là một hệ thống kho bạc thử nghiệm kết hợp các quy trình đề xuất và bỏ phiếu tập trung vào việc thành lập một nền văn hóa dân chủ trong cộng đồng Cardano.
Ban đầu, Kho bạc của Cardano sẽ được nạp lại từ phần trăm phần thưởng của nhóm cổ phần đảm bảo một nguồn Kho bạc bền vững.
Các blockchain khác có hệ thống kho bạc, nhưng kết hợp sự riêng tư hoàn toàn thông qua bằng chứng không hiểu biết, dân chủ lỏng từ sự tham gia của chuyên gia và ủy quyền bỏ phiếu, và tham gia cho tất cả, không chỉ là một thực thể cai trị.
Điều này nên khuyến khích sự tham gia, khuyến khích và phân cấp để đưa ra quyết định công bằng và minh bạch.

It is also important to note that this treasury system mechanism can be implemented on a variety of blockchains, not just Cardano. It has already been proposed implementing it for [Ethereum Classic](https://www.youtube.com/watch?v=47DhB1obZNs). In the process, treasury systems can help everyone to understand how a network will develop.

Cũng cần lưu ý rằng cơ chế hệ thống kho bạc này có thể được thực hiện trên nhiều loại blockchain khác nhau, không chỉ Cardano.
Nó đã được đề xuất thực hiện nó cho [Ethereum Classic] (https://www.youtube.com/watch?v=47DHB1OBZNS).
Trong quá trình này, các hệ thống kho bạc có thể giúp mọi người hiểu cách mạng sẽ phát triển như thế nào.

*After a successful closed user group trial earlier which started this summer, Project Catalyst will very soon be opened up to its first public beta program. Although it is still early days for Cardano on-chain governance, we look forward to a bright future, with the community lighting the way. So, please follow the blog for updates on Voltaire and how Project Catalyst is paving the way to Cardanoâ€™s sustainability.*

*Sau khi một bản dùng thử nhóm người dùng đóng thành công trước đó bắt đầu vào mùa hè này, Project Catalyst sẽ sớm được mở ra cho chương trình beta công khai đầu tiên của mình.
Mặc dù vẫn là những ngày đầu để quản trị chuỗi Cardano, chúng tôi mong chờ một tương lai tươi sáng, với cộng đồng chiếu sáng theo cách.
Vì vậy, vui lòng theo dõi blog để cập nhật về Voltaire và cách Project Catalyst mở đường đến tính bền vững của Cardano.*

