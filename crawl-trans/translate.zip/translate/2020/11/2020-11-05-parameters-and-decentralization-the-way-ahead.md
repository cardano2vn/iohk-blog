# Parameters and decentralization: the way ahead
### **On December 6 we'll be making adjustments to the k-parameter in Cardano. Here’s why**
![](img/2020-11-05-parameters-and-decentralization-the-way-ahead.002.png) 5 November 2020![](img/2020-11-05-parameters-and-decentralization-the-way-ahead.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2020-11-05-parameters-and-decentralization-the-way-ahead.003.png) 10 mins read

![Tim Harrison](img/2020-11-05-parameters-and-decentralization-the-way-ahead.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2020-11-05-parameters-and-decentralization-the-way-ahead.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2020-11-05-parameters-and-decentralization-the-way-ahead.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2020-11-05-parameters-and-decentralization-the-way-ahead.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2020-11-05-parameters-and-decentralization-the-way-ahead.008.png)[](https://github.com/timbharrison "GitHub")

![Parameters and decentralization: the way ahead](img/2020-11-05-parameters-and-decentralization-the-way-ahead.009.jpeg)

Your browser does not support the audio element.

Trình duyệt của bạn không hỗ trợ các yếu tố âm thanh.

Shelley continues to evolve and, as it does, IOHK is committed to supporting the healthy development of the Cardano ecosystem. There are many factors at play in this regard: everything from the wallet experience for ada delegators to network tools for stake pool operators; from governance and funding frameworks like Project Catalyst and Voltaire to community-led initiatives. Central to the health of Cardano as a vibrant proof-of-stake network is the manner in which delegators and stake operators are rewarded for running it, and how those rewards are shared to maximize decentralization and secure the network.

Shelley tiếp tục phát triển và, như vậy, IOHK cam kết hỗ trợ sự phát triển lành mạnh của hệ sinh thái Cardano.
Có nhiều yếu tố đang diễn ra về vấn đề này: tất cả mọi thứ từ trải nghiệm ví cho các ủy viên ADA đến các công cụ mạng cho các nhà khai thác nhóm cổ phần;
Từ các khung quản trị và tài trợ như Project Catalyst và Voltaire đến các sáng kiến do cộng đồng lãnh đạo.
Trọng tâm của sức khỏe của Cardano như một mạng lưới chứng minh sôi động là cách thức mà các ủy viên và nhà khai thác cổ phần được khen thưởng khi điều hành nó và cách chia sẻ những phần thưởng đó để tối đa hóa sự phân cấp và bảo mật mạng.

The system is still transitioning towards full decentralization and community ownership. Very shortly, the majority of blocks will be minted by community pools as the influence of the genesis nodes supporting the network is gradually reduced. The steady reduction of *d* (the parameter governing this process) will see it reach zero by the end of March 2021. This will mark the full decentralization of all block production on Cardano.

Hệ thống vẫn đang chuyển sang phân cấp đầy đủ và quyền sở hữu cộng đồng.
Trong thời gian ngắn, phần lớn các khối sẽ được các nhóm cộng đồng đúc ra do ảnh hưởng của các nút Genesis hỗ trợ mạng bị giảm dần.
Việc giảm ổn định * D * (tham số chi phối quá trình này) sẽ thấy nó đạt đến 0 vào cuối tháng 3 năm 2021. Điều này sẽ đánh dấu sự phân cấp đầy đủ của tất cả các khối sản xuất trên Cardano.

Some four months on from the deployment of Shelley, it is time to adjust the parameters of the rewards mechanism so that the next phase of the network’s growth is fueled. Since launch, we have been monitoring network behavior, while seeing how the community and ecosystem are developing. We have also been carefully modeling various scenarios based on data as it emerges. We have now finished a full review and have aligned – from a philosophical, scientific, technical and practical perspective – the next steps. Before we make further adjustments to the parameters of the rewards scheme, we wanted to share with the community what we hope to achieve with the underlying mechanism and associated parameter adjustments. 

Khoảng bốn tháng kể từ khi triển khai Shelley, đã đến lúc điều chỉnh các tham số của cơ chế phần thưởng để giai đoạn tiếp theo của sự tăng trưởng của mạng lưới được thúc đẩy.
Kể từ khi ra mắt, chúng tôi đã theo dõi hành vi mạng, trong khi thấy cộng đồng và hệ sinh thái đang phát triển như thế nào.
Chúng tôi cũng đã được mô hình hóa cẩn thận các kịch bản khác nhau dựa trên dữ liệu khi nó xuất hiện.
Bây giờ chúng tôi đã hoàn thành một đánh giá đầy đủ và đã phù hợp - từ một quan điểm triết học, khoa học, kỹ thuật và thực tế - các bước tiếp theo.
Trước khi chúng tôi điều chỉnh thêm cho các tham số của chương trình phần thưởng, chúng tôi muốn chia sẻ với cộng đồng những gì chúng tôi hy vọng sẽ đạt được với cơ chế cơ bản và điều chỉnh tham số liên quan.

## **Encouraging sustainability through pool diversity**

## ** Khuyến khích sự bền vững thông qua sự đa dạng của hồ bơi **

First and foremost, the rewards-sharing mechanism of Cardano aims to reward people fairly for supporting the platform in a *sustainable* way, not as a short-term windfall. One of the goals of staking has always been to encourage long-term holders of ada: the people who are committed to the success of the ecosystem.

Đầu tiên và quan trọng nhất, cơ chế chia sẻ phần thưởng của Cardano nhằm mục đích thưởng cho mọi người một cách công bằng cho việc hỗ trợ nền tảng theo cách * bền vững *, không phải là một cơn gió ngắn hạn.
Một trong những mục tiêu của việc đặt cược luôn là khuyến khích những người nắm giữ lâu dài của ADA: những người cam kết thành công của hệ sinh thái.

In the longer term, the system can be successful only if it is widely decentralized. Philosophically, the design of the rewards scheme aims to encourage a wide and diverse set of stake pool operators. This secures the platform against attacks, spreads any available rewards evenly across the community, and makes the system more resilient to change. 

Về lâu dài, hệ thống chỉ có thể thành công nếu nó được phân cấp rộng rãi.
Về mặt triết học, thiết kế của chương trình phần thưởng nhằm mục đích khuyến khích một bộ các nhà khai thác nhóm cổ phần rộng và đa dạng.
Điều này đảm bảo nền tảng chống lại các cuộc tấn công, lan truyền mọi phần thưởng có sẵn trên cộng đồng và làm cho hệ thống trở nên kiên cường hơn để thay đổi.

Many economic systems have a tendency towards consolidation and a smaller number of strong players. On the other hand, blockchains can only be successful when control is decentralized. The rewards-sharing scheme ensures that smaller and medium pools can contribute meaningfully to the ecosystem without becoming subsumed into larger operators and consortia, as has happened with other blockchain systems, particularly Bitcoin.

Nhiều hệ thống kinh tế có xu hướng hợp nhất và một số lượng nhỏ người chơi mạnh mẽ.
Mặt khác, blockchain chỉ có thể thành công khi kiểm soát được phân cấp.
Sơ đồ chia sẻ phần thưởng đảm bảo rằng các nhóm nhỏ hơn và trung bình có thể đóng góp một cách có ý nghĩa cho hệ sinh thái mà không được đưa vào các nhà khai thác và tập đoàn lớn hơn, như đã xảy ra với các hệ thống blockchain khác, đặc biệt là Bitcoin.

One way to discourage a trend towards a few large pools that collectively control the system is to introduce a counter-incentive to a pool's growth. The rewards-sharing scheme we designed is an example of this novel (in the cryptocurrency space) concept. As soon as stake delegation to a single pool increases above a threshold, the rewards automatically diminish, encouraging ada holders delegating to that pool to find a new home to improve their rewards. This mechanism limits the delegation that can be rationally made to any pool and spreads delegated stake more evenly across a larger number of pools. 

Một cách để ngăn cản một xu hướng đối với một vài hồ bơi lớn kiểm soát chung hệ thống là giới thiệu một sự phản đối đối với sự phát triển của hồ bơi.
Sơ đồ chia sẻ phần thưởng mà chúng tôi thiết kế là một ví dụ về khái niệm tiểu thuyết này (trong không gian tiền điện tử).
Ngay khi phái đoàn cổ phần lên một nhóm tăng lên trên ngưỡng, phần thưởng sẽ tự động giảm dần, khuyến khích những người nắm giữ ADA ủy thác cho nhóm đó để tìm một ngôi nhà mới để cải thiện phần thưởng của họ.
Cơ chế này giới hạn phái đoàn có thể được thực hiện một cách hợp lý cho bất kỳ hồ bơi nào và lây lan đặt cọc được ủy quyền hơn trên một số lượng lớn hơn các nhóm.

## **All about *k***

## ** Tất cả về*k ***

The parameter of the rewards scheme that sets this 'soft-cap' on the pool size is called *k*. The mechanism is designed so that, at equilibrium, assuming rational participants and no external factors, the stakeholders' best response behavior converges to *k* pools of equal size delivering the same level of rewards per unit of stake to their delegates. 

Tham số của sơ đồ phần thưởng đặt 'nắp mềm' này trên kích thước nhóm được gọi là *k *.
Cơ chế được thiết kế sao cho, ở trạng thái cân bằng, giả sử những người tham gia hợp lý và không có yếu tố bên ngoài, hành vi phản ứng tốt nhất của các bên liên quan hội tụ đến các nhóm * K * có kích thước bằng nhau mang cùng mức phần thưởng trên mỗi đơn vị cổ phần cho các đại biểu của họ.

For the deployment of Shelley on mainnet, we started with *k*=150, which limits pool size to 210 million ada. This was a modest increase from the parameter choice used in the incentivized testnet (ITN), which had a value of *k*=100. At the time, this was considered to be a relatively conservative choice, made to ensure the ITN environment would smoothly move to the mainnet. The launch of Shelley has seen enormous interest from the community and a large number of pools. Over the past few months, we have observed the way the staking pools are operating, and recognize that *k* needs to be adjusted upwards. 

Để triển khai Shelley trên chính, chúng tôi đã bắt đầu với *K *= 150, giới hạn quy mô nhóm đến 210 triệu ADA.
Đây là một sự gia tăng khiêm tốn từ lựa chọn tham số được sử dụng trong TestNet được khuyến khích (ITN), có giá trị *K *= 100.
Vào thời điểm đó, đây được coi là một lựa chọn tương đối bảo thủ, được thực hiện để đảm bảo môi trường ITN sẽ di chuyển trơn tru đến mainnet.
Sự ra mắt của Shelley đã chứng kiến sự quan tâm to lớn từ cộng đồng và một số lượng lớn các hồ bơi.
Trong vài tháng qua, chúng tôi đã quan sát cách các nhóm đặt cược đang hoạt động và nhận ra rằng * K * cần được điều chỉnh lên trên.

It is worth noting that the *k*-parameter is not amenable to small, gradual increases (unlike, for example, the *d*-parameter, which lends itself to a gradual reduction). Each increase in *k* requires pools and delegators to take action. For pool operators, this means a careful adjustment of their parameters and in particular their margin; for delegators, it means choosing new pools to delegate their ada to, especially if their current choice becomes oversaturated.

Điều đáng chú ý là *K *-Parameter không thể chấp nhận được, tăng dần dần (không giống như, ví dụ, *d *-parameter, cho vay để giảm dần).
Mỗi sự gia tăng * K * yêu cầu các nhóm và ủy viên phải hành động.
Đối với các nhà khai thác nhóm, điều này có nghĩa là điều chỉnh cẩn thận các tham số của họ và đặc biệt là biên độ của chúng;
Đối với các đại biểu, điều đó có nghĩa là chọn các nhóm mới để ủy thác ADA của họ, đặc biệt là nếu lựa chọn hiện tại của họ trở nên quá bão hòa.

Therefore, the best strategy for an upwards adjustment of *k* is to move in larger, less frequent increments – and to move it as far and as fast as practical network dynamics and economics will allow. The ‘how much’ and ‘how soon’ has been a topic of intense debate and discussion within the team, made more complex by a number of technical factors. The best solution is one that minimizes disruption for successful pools and their delegators, while maximizing the opportunity for medium and smaller pools to mint blocks and attract more stake. Equally, it is crucial to be always focused on the longer-term strategic goal as a community to broaden decentralization as widely as possible.

Do đó, chiến lược tốt nhất để điều chỉnh lên trên * K * là di chuyển theo mức tăng lớn hơn, ít thường xuyên hơn - và di chuyển nó xa và nhanh như động lực học và kinh tế mạng thực tế sẽ cho phép.
’Bao nhiêu và’ bao nhiêu sớm đã là một chủ đề của cuộc tranh luận và thảo luận dữ dội trong nhóm, trở nên phức tạp hơn bởi một số yếu tố kỹ thuật.
Giải pháp tốt nhất là một giải pháp giảm thiểu sự gián đoạn cho các nhóm thành công và các ủy viên của họ, đồng thời tối đa hóa cơ hội cho các nhóm trung bình và nhỏ hơn để các khối bạc hà và thu hút nhiều cổ phần hơn.
Một cách công bằng, điều quan trọng là phải luôn tập trung vào mục tiêu chiến lược dài hạn như một cộng đồng để mở rộng sự phân cấp càng rộng càng tốt.

## **Moving to *k*=500 in December**

## ** chuyển sang*k*= 500 vào tháng 12 **

We are committed to a measured and deliberate set of changes and will be using the data we gather to inform subsequent decisions. Therefore, we plan to implement the *k* change in a staged manner. First, we shall move to *k*=500 at epoch 234 (21:44 UTC Sunday, December 6, 2020). The move to *k*=500 will give small- to medium-sized pools that are struggling an improved opportunity to attract delegation. It will also have the effect of limiting pool size to 64 million ada, which means more than 100 of the largest pools will become saturated. 

Chúng tôi cam kết với một tập hợp các thay đổi được đo lường và có chủ ý và sẽ sử dụng dữ liệu chúng tôi thu thập để thông báo cho các quyết định tiếp theo.
Do đó, chúng tôi có kế hoạch thực hiện thay đổi * K * theo cách thức.
Đầu tiên, chúng ta sẽ chuyển đến *K *= 500 tại Epoch 234 (21:44 UTC Chủ nhật, ngày 6 tháng 12 năm 2020).
Việc chuyển sang *K *= 500 sẽ cung cấp cho các nhóm nhỏ đến trung bình đang đấu tranh một cơ hội được cải thiện để thu hút phái đoàn.
Nó cũng sẽ có tác dụng hạn chế kích thước nhóm đến 64 triệu ADA, điều đó có nghĩa là hơn 100 nhóm lớn nhất sẽ trở nên bão hòa.

Ada holders can redelegate at any point between now and the change. If you are currently delegating to one of the largest pools, and wish to continue receiving optimal staking rewards, you may need to move your ada before or during epoch 233, before the new epoch boundary at 21:44 UTC on December 6. We certainly encourage delegators to keep an eye on their favorite pools in the saturation meter in the Daedalus wallet a day or two before December 6. If it shows significantly more than 64 million ada at this point, you should certainly consider redelegating. It is important to note that rewards will still be payable from slightly saturated pools, but these steadily diminish the greater the saturation over 64 million ada in the pool. To be clear, though, no one delegating to an over-saturated pool will lose any of their stake. It is simply that the return on their stake will be reduced if they stay delegated to a saturated pool. We always encourage the community to keep an eye on their delegation choices, and this will be especially important around this time.

Chủ sở hữu ADA có thể được phân phối lại tại bất kỳ điểm nào giữa bây giờ và sự thay đổi. Nếu bạn hiện đang ủy thác cho một trong những hồ bơi lớn nhất và muốn tiếp tục nhận phần thưởng đặt cược tối ưu, bạn có thể cần phải di chuyển ADA của mình trước hoặc trong thời gian Epoch 233, trước ranh giới Epoch mới vào 21:44 UTC vào ngày 6 tháng 12. Chúng tôi chắc chắn Khuyến khích các ủy viên để mắt đến các hồ bơi yêu thích của họ trong đồng hồ đo độ bão hòa trong ví Daedalus một hoặc hai ngày trước ngày 6 tháng 12. Nếu nó cho thấy hơn 64 triệu ADA tại thời điểm này, bạn chắc chắn nên xem xét việc chuyển đổi lại. Điều quan trọng cần lưu ý là phần thưởng vẫn sẽ được trả từ các nhóm hơi bão hòa, nhưng chúng giảm dần độ bão hòa hơn 64 triệu ADA trong nhóm. Tuy nhiên, để rõ ràng, không ai ủy thác cho một nhóm quá bão hòa sẽ mất bất kỳ cổ phần nào của họ. Nó chỉ đơn giản là lợi nhuận trên cổ phần của họ sẽ được giảm nếu họ được giao cho một nhóm bão hòa. Chúng tôi luôn khuyến khích cộng đồng để mắt đến các lựa chọn phái đoàn của họ, và điều này sẽ đặc biệt quan trọng trong khoảng thời gian này.

Modeling the long-term viability of stake pools, we found that *k* values of 1,000 were stable in the long term. As a result, our aim is to move to *k*=1,000 during March 2021. We recognize the importance of economic factors that also strongly influence pool profitability and will continue to consult widely with the community on the plan; the social dynamics of the network should also not be underestimated. A number of opportunities will be presented (including community panels and seminars) for further discussion, while helping the community understand more about the changes and contribute their perspectives.

Mô hình hóa khả năng tồn tại lâu dài của các nhóm cổ phần, chúng tôi thấy rằng các giá trị * K * của 1.000 đã ổn định trong dài hạn.
Do đó, mục đích của chúng tôi là chuyển sang *K *= 1.000 trong tháng 3 năm 2021. Chúng tôi nhận ra tầm quan trọng của các yếu tố kinh tế cũng ảnh hưởng mạnh đến lợi nhuận của nhóm và sẽ tiếp tục tham khảo ý kiến rộng rãi với cộng đồng trong kế hoạch;
Các động lực xã hội của mạng cũng không được đánh giá thấp.
Một số cơ hội sẽ được trình bày (bao gồm các hội thảo cộng đồng và hội thảo) để thảo luận thêm, đồng thời giúp cộng đồng hiểu thêm về những thay đổi và đóng góp quan điểm của họ.

From a strategic and philosophical perspective, we believe this is the correct approach for Cardano. We wish to encourage decentralization across a large number of stake pools that are independently operated, while recognizing the positive contribution of the pools currently leading in the rankings. We shall also pay heed to the practical dynamics of the evolving ecosystem. By the end of March, *d*, the decentralization parameter, will also be set to zero, meaning that Cardano block production will be fully decentralized, and responsibility shared across nearly all the pools currently running the network (and hopefully, some new entrants too).

Từ góc độ chiến lược và triết học, chúng tôi tin rằng đây là cách tiếp cận chính xác cho Cardano.
Chúng tôi muốn khuyến khích phân cấp trên một số lượng lớn các nhóm cổ phần được vận hành độc lập, đồng thời nhận ra sự đóng góp tích cực của các nhóm hiện đang dẫn đầu trong bảng xếp hạng.
Chúng ta cũng sẽ chú ý đến các động lực thực tế của hệ sinh thái đang phát triển.
Vào cuối tháng 3, *D *, tham số phân cấp, cũng sẽ được đặt thành 0, có nghĩa là sản xuất khối Cardano sẽ được phân cấp hoàn toàn và trách nhiệm được chia sẻ trên gần như tất cả các nhóm hiện đang chạy mạng (và hy vọng, một số người mới tham gia
cũng vậy).

## **No silver bullet**

## ** Không có viên đạn bạc **

We believe that changing *k* to 500 will benefit the ecosystem, despite a period of disruption and change. However, it is not the whole solution. We are continuing to develop our thinking in other areas that will tangibly contribute to Cardano’s decentralization. Hardware wallet delegation support (coming very soon) should help open up ada supply, to the benefit of all. We shall soon add the ability to delegate to several pools from a hardware wallet, which will help Trezor (initially) and subsequently Ledger owners spread their stake across a range of pools. Improvements to stake pool servers will in time allow community members to start curating their own pool lists to help shape and steer delegation choices. We shall also be retiring all but one of our public IOG pools and encouraging delegators to switch their ada to community pools, while developing our own delegation strategy. On the parameter side, we are now finalizing some modeling around pledging by pool operators, another factor that will help shift network dynamics in favor of a broader spread of ada. Expect more news on all these topics soon.

Chúng tôi tin rằng việc thay đổi * K * thành 500 sẽ có lợi cho hệ sinh thái, mặc dù thời gian gián đoạn và thay đổi. Tuy nhiên, nó không phải là toàn bộ giải pháp. Chúng tôi đang tiếp tục phát triển suy nghĩ của mình trong các lĩnh vực khác sẽ đóng góp một cách hữu hình vào sự phân cấp của Cardano. Hỗ trợ ủy quyền ví phần cứng (đến rất sớm) sẽ giúp mở nguồn cung ADA, vì lợi ích của tất cả mọi người. Chúng tôi sẽ sớm thêm khả năng ủy thác cho một số nhóm từ ví phần cứng, điều này sẽ giúp Trezor (ban đầu) và sau đó là chủ sở hữu sổ cái lây lan cổ phần của họ trên một loạt các nhóm. Các cải tiến để đặt máy chủ nhóm sẽ kịp thời cho phép các thành viên cộng đồng bắt đầu quản lý danh sách nhóm của riêng họ để giúp định hình và điều khiển các lựa chọn ủy quyền. Chúng tôi cũng sẽ nghỉ hưu tất cả trừ một trong những nhóm IOG công khai của chúng tôi và khuyến khích các đại biểu chuyển ADA của họ sang nhóm cộng đồng, đồng thời phát triển chiến lược phái đoàn của riêng chúng tôi. Về phía tham số, chúng tôi hiện đang hoàn thiện một số mô hình xung quanh việc cam kết của các nhà khai thác nhóm, một yếu tố khác sẽ giúp thay đổi động lực mạng có lợi cho sự lan truyền rộng hơn của ADA. Mong đợi nhiều tin tức hơn về tất cả các chủ đề này sớm.

We recognize that in the short term, the move to *k*=500 will mean significant change for some. If delegators to larger pools do not react, some pools will become oversaturated and rewards will be unclaimed (note that no rewards are lost; everything goes back to the system’s reserves for the community to draw upon in the future). As a result, pool operators will need to adjust their margin and cost in the short term to stay profitable and incentivize delegators to take action. While this will require some effort from the community, it is an essential step for the Cardano ecosystem to maximize its decentralization. As smart contracts and multi-currency support will be coming soon to Cardano, a high level of decentralization will be the jewel of the ecosystem, and a strong competitive advantage over other blockchains.

Chúng tôi nhận ra rằng trong ngắn hạn, việc chuyển sang *k *= 500 sẽ có nghĩa là thay đổi đáng kể đối với một số người.
Nếu các ủy viên đến các hồ bơi lớn hơn không phản ứng, một số nhóm sẽ trở nên quá bão hòa và phần thưởng sẽ không được yêu cầu (lưu ý rằng không có phần thưởng nào bị mất; mọi thứ trở lại dự trữ của hệ thống để cộng đồng rút ra trong tương lai).
Do đó, các nhà khai thác nhóm sẽ cần điều chỉnh biên độ và chi phí của họ trong thời gian ngắn để có lợi nhuận và khuyến khích các ủy viên hành động.
Mặc dù điều này sẽ đòi hỏi một số nỗ lực từ cộng đồng, nhưng đó là một bước thiết yếu để hệ sinh thái Cardano để tối đa hóa sự phân cấp của nó.
Vì các hợp đồng thông minh và hỗ trợ đa tiền tệ sẽ sớm ra mắt Cardano, mức độ phân cấp cao sẽ là viên ngọc của hệ sinh thái và lợi thế cạnh tranh mạnh mẽ so với các blockchain khác.

The increase in *k* will be a significant step forward in delivering Cardano’s mission. Because this change will bring some disruption, we want to give the community plenty of time to absorb the changes and adjust their strategy. Moreover, we would like to help the community make the right decisions for the long-term sustainability of Cardano. We will be publishing more content over the next few weeks and months to support this approach (including a guide to making good delegation choices) as we continue to improve the experience.

Sự gia tăng * K * sẽ là một bước tiến đáng kể trong việc cung cấp nhiệm vụ Cardano.
Bởi vì sự thay đổi này sẽ mang lại một số gián đoạn, chúng tôi muốn cho cộng đồng nhiều thời gian để tiếp thu các thay đổi và điều chỉnh chiến lược của họ.
Hơn nữa, chúng tôi muốn giúp cộng đồng đưa ra quyết định đúng đắn về sự bền vững lâu dài của Cardano.
Chúng tôi sẽ xuất bản nhiều nội dung hơn trong vài tuần và tháng tới để hỗ trợ phương pháp này (bao gồm cả hướng dẫn để đưa ra các lựa chọn phái đoàn tốt) khi chúng tôi tiếp tục cải thiện trải nghiệm.

Achieving the highest level of decentralization is the ultimate objective of any blockchain system. Decentralization is the solid foundation over which the Cardano ecosystem will thrive. True decentralization cannot be conjured purely out of mathematical theorems, and the tweaking of parameters and formulas will never be enough by itself – even though with Cardano we have taken huge strides compared to any other blockchain. Nevertheless, in the end, true decentralization will emanate from the collective will and actions of the Cardano community. We will continue in this path together, investigating additional approaches to allow stake pools to build their brand, communicate with their delegators, and highlight their own contributions and mission more directly. 

Đạt được mức độ phân cấp cao nhất là mục tiêu cuối cùng của bất kỳ hệ thống blockchain nào.
Phân cấp là nền tảng vững chắc mà hệ sinh thái Cardano sẽ phát triển mạnh.
Phân cấp thực sự không thể được kết hợp hoàn toàn từ các định lý toán học, và việc điều chỉnh các tham số và công thức sẽ không bao giờ là đủ - mặc dù với Cardano, chúng tôi đã có những bước tiến lớn so với bất kỳ blockchain nào khác.
Tuy nhiên, cuối cùng, sự phân cấp thực sự sẽ xuất phát từ ý chí tập thể và hành động của cộng đồng Cardano.
Chúng tôi sẽ tiếp tục trong con đường này cùng nhau, điều tra các cách tiếp cận bổ sung để cho phép các nhóm cổ phần xây dựng thương hiệu của họ, giao tiếp với các ủy viên của họ và làm nổi bật những đóng góp và nhiệm vụ của riêng họ trực tiếp hơn.

*Thanks to Aggelos Kiayias, Colin Edwards, Olga Hryniuk and Francisco Landino for their input to this piece. Thanks also to researchers Aikaterini-Panagiota Stouka and Elias Koutsoupias.*

*Cảm ơn Aggelos Kiayias, Colin Edwards, Olga Hryniuk và Francisco Landino vì đầu vào của họ cho tác phẩm này.
Cũng xin cảm ơn các nhà nghiên cứu Aikaterini-Panagiota Stouka và Elias Koutsoupias.*

*We’ll be posting throughout the next month to support delegators and stake pool operators as we approach the December 6 deadline. Please be sure to follow us on [Twitter](https://twitter.com/InputOutputHK) and subscribe on [YouTube ](https://www.youtube.com/channel/UCBJ0p9aCW-W82TwNM-z3V2w)for all the latest updates.*

*Chúng tôi sẽ đăng trong suốt tháng tới để hỗ trợ các ủy viên và nhà điều hành nhóm cổ phần khi chúng tôi tiếp cận thời hạn ngày 6 tháng 12.
Hãy chắc chắn theo dõi chúng tôi trên [Twitter] (https://twitter.com/inputoutputhk) và đăng ký trên [youtube] (https://www.youtube.com/channel/ucbj0p9acw-w82twnm-z3v2w)
Cập nhật.*

