# IOHK sponsors new Haskell Foundation
### **Independent, open, non-profit body will support tools, libraries, education, and research**
![](img/2020-11-04-iohk-sponsors-new-haskell-foundation.002.png) 4 November 2020![](img/2020-11-04-iohk-sponsors-new-haskell-foundation.002.png)[ Moritz Angermann](tmp//en/blog/authors/moritz-angermann/page-1/)![](img/2020-11-04-iohk-sponsors-new-haskell-foundation.003.png) 2 mins read

![Moritz Angermann](img/2020-11-04-iohk-sponsors-new-haskell-foundation.004.png)[](tmp//en/blog/authors/moritz-angermann/page-1/)
### [**Moritz Angermann**](tmp//en/blog/authors/moritz-angermann/page-1/)
Software Engineering Lead

Engineering

- ![](img/2020-11-04-iohk-sponsors-new-haskell-foundation.005.png)[](mailto:moritz.angermann@iohk.io "Email")
- ![](img/2020-11-04-iohk-sponsors-new-haskell-foundation.006.png)[](https://www.linkedin.com/in/mangermann "LinkedIn")
- ![](img/2020-11-04-iohk-sponsors-new-haskell-foundation.007.png)[](https://twitter.com/angerman_io "Twitter")
- ![](img/2020-11-04-iohk-sponsors-new-haskell-foundation.008.png)[](https://github.com/angerman "GitHub")

![IOHK sponsors new Haskell Foundation](img/2020-11-04-iohk-sponsors-new-haskell-foundation.009.jpeg)

Simon Peyton Jones [has just announced](https://youtu.be/MEmRarBL9kw) the launch of the Haskell Foundation at the Haskell eXchange virtual conference. The foundation is an independent, open, non-profit organization dedicated to broadening the adoption of the Haskell language, by supporting its ecosystem of tools, libraries, education, and research.

Simon Peyton Jones [vừa công bố] (https://youtu.be/memrarbl9kw) Sự ra mắt của Quỹ Haskell tại Hội nghị ảo Haskell Exchange.
Quỹ là một tổ chức độc lập, cởi mở, phi lợi nhuận dành riêng để mở rộng việc áp dụng ngôn ngữ Haskell, bằng cách hỗ trợ hệ sinh thái của các công cụ, thư viện, giáo dục và nghiên cứu.

IOHK is one of the first sponsors of the Haskell Foundation because we believe in the power of functional programming, open-source software, and open governance. So, we are delighted to be able to join other key companies in supporting the community through an open and transparent process in which everyone can participate.

IOHK là một trong những nhà tài trợ đầu tiên của Quỹ Haskell vì chúng tôi tin vào sức mạnh của lập trình chức năng, phần mềm nguồn mở và quản trị mở.
Vì vậy, chúng tôi rất vui mừng khi có thể tham gia các công ty chủ chốt khác trong việc hỗ trợ cộng đồng thông qua một quy trình mở và minh bạch mà mọi người có thể tham gia.

## **IOHK and Haskell**

## ** iohk và haskell **

All of IOHKâ€™s core software is open-source, and where possible we do our work via standalone projects that will benefit the community too. We have contributed substantially to compilers like GHC, GHCJS and Asterius; created libraries for eliminating space leaks; and are even building the Plutus smart contract platform on Haskell.

Tất cả phần mềm cốt lõi của IOHK đều là nguồn mở và nếu có thể chúng tôi thực hiện công việc của mình thông qua các dự án độc lập cũng sẽ có lợi cho cộng đồng.
Chúng tôi đã đóng góp đáng kể cho các nhà biên dịch như GHC, GHCJ và Asterius;
đã tạo các thư viện để loại bỏ rò rỉ không gian;
Và thậm chí đang xây dựng nền tảng hợp đồng thông minh Plutus trên Haskell.

For several years IOHK has been supporting the development of GHC itself and aims to continue doing so. Our engineers have contributed the ghc-bignum library, improved cross-compilation support, worked on support for ARM architectures, provided general code improvements, and fixed a number of bugs. We are keen to help other community efforts, for example by funding the work of others, and by helping to get the recently-merged Windows I/O manager across the finish line.

Trong nhiều năm, IOHK đã hỗ trợ sự phát triển của chính GHC và nhằm mục đích tiếp tục làm như vậy.
Các kỹ sư của chúng tôi đã đóng góp thư viện GHC-Bignum, hỗ trợ biên dịch chéo được cải thiện, làm việc hỗ trợ cho kiến trúc ARM, cung cấp các cải tiến mã chung và sửa một số lỗi.
Chúng tôi rất muốn giúp đỡ các nỗ lực cộng đồng khác, ví dụ bằng cách tài trợ cho công việc của những người khác và bằng cách giúp có được trình quản lý Windows I/O được công bố gần đây trên vạch đích.

In addition to its direct technical involvement, IOHK has also invested in expanding the Haskell community, including developing online tutorials, education programmes, and delivering face-to-face training courses in places such as Athens, Barbados, Mongolia and Ethiopia. Through this and other programs, we are fully committed to the Haskell Foundationâ€™s goals of enhancing diversity within the Haskell community.

Ngoài sự tham gia kỹ thuật trực tiếp, IOHK cũng đã đầu tư vào việc mở rộng cộng đồng Haskell, bao gồm phát triển các hướng dẫn trực tuyến, các chương trình giáo dục và cung cấp các khóa đào tạo trực tiếp ở những nơi như Athens, Barbados, Mongolia và Ethiopia.
Thông qua các chương trình này và các chương trình khác, chúng tôi hoàn toàn cam kết với các mục tiêu của Haskell Foundation là tăng cường sự đa dạng trong cộng đồng Haskell.

## **Looking forward**

## **Nhìn về phía trước**

We are excited to be working with the Haskell Foundation to help move Haskell forward. IOHK has contributed to the Foundationâ€™s technical agenda, and will help directly with technical work. Stay tuned for more exciting announcements!

Chúng tôi rất vui mừng được làm việc với Quỹ Haskell để giúp di chuyển Haskell về phía trước.
IOHK đã đóng góp cho chương trình nghị sự kỹ thuật của Foundation và sẽ giúp trực tiếp với công việc kỹ thuật.
Hãy theo dõi các thông báo thú vị hơn!

