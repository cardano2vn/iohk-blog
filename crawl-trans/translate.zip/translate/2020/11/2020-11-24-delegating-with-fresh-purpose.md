# Delegating with fresh purpose
### **To encourage a sustainable, decentralized and diverse network, we’re introducing a new ada delegation program.**
![](img/2020-11-24-delegating-with-fresh-purpose.002.png) 24 November 2020![](img/2020-11-24-delegating-with-fresh-purpose.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2020-11-24-delegating-with-fresh-purpose.003.png) 7 mins read

![Tim Harrison](img/2020-11-24-delegating-with-fresh-purpose.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2020-11-24-delegating-with-fresh-purpose.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2020-11-24-delegating-with-fresh-purpose.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2020-11-24-delegating-with-fresh-purpose.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2020-11-24-delegating-with-fresh-purpose.008.png)[](https://github.com/timbharrison "GitHub")

![Delegating with fresh purpose](img/2020-11-24-delegating-with-fresh-purpose.009.jpeg)

Your browser does not support the audio element.

Trình duyệt của bạn không hỗ trợ các yếu tố âm thanh.

The deployment of Shelley on mainnet in July opened up a new world of staking and delegation for Cardano. Since then, we have seen a groundswell of support from the community, with the creation of 1,200+ stake pools. Many have thrived and taken an early vantage position in the community in terms of visibility or controlled stake – or both. Equally, some pools are yet to make their mark. With a sub-optimal *k*, the high saturation threshold has made it particularly tough going for pools yet to mint their first block.

Việc triển khai Shelley trên Mainnet vào tháng 7 đã mở ra một thế giới mới về việc đặt cược và phái đoàn cho Cardano.
Kể từ đó, chúng tôi đã thấy một nền tảng hỗ trợ từ cộng đồng, với việc tạo ra hơn 1.200 nhóm cổ phần.
Nhiều người đã phát triển mạnh và chiếm một vị trí thuận lợi sớm trong cộng đồng về khả năng hiển thị hoặc cổ phần được kiểm soát - hoặc cả hai.
Tương tự, một số hồ bơi vẫn chưa tạo được dấu ấn của họ.
Với mức tối ưu phụ *K *, ngưỡng bão hòa cao đã làm cho nó đặc biệt khó khăn đối với các hồ bơi chưa làm cho khối đầu tiên của họ.

This is starting to change. On December 6, we’ll raise the k parameter to 500 – it was set at 150 for the Shelley launch. This will encourage delegators to spread their stake, giving more stake pools the opportunity to make blocks and step into the spotlight. It’s an important move, just one of a number of changes in the evolving ecosystem and staking experience we can expect over the months ahead.

Điều này đang bắt đầu thay đổi.
Vào ngày 6 tháng 12, chúng tôi sẽ nâng tham số K lên 500 - nó được đặt ở mức 150 cho buổi ra mắt Shelley.
Điều này sẽ khuyến khích các ủy viên lan truyền cổ phần của họ, cho nhiều cổ phần hơn cơ hội để tạo ra các khối và bước vào ánh đèn sân khấu.
Đó là một động thái quan trọng, chỉ là một trong một số thay đổi trong hệ sinh thái đang phát triển và kinh nghiệm đặt cược mà chúng ta có thể mong đợi trong những tháng tới.

This week, we are also announcing that we’ll change our staking approach. Initially, we set up 20 public pools. This was partly due to our desire to monitor and test the network and technical dynamics of running a range of ‘real’ pools. Also, for operational and security reasons, we elected to stake the company’s own ada holdings across these pools, rather than within private pools. 

Tuần này, chúng tôi cũng thông báo rằng chúng tôi sẽ thay đổi phương pháp đặt cược của mình.
Ban đầu, chúng tôi thiết lập 20 hồ bơi công cộng.
Điều này một phần là do mong muốn của chúng tôi để theo dõi và kiểm tra mạng và động lực kỹ thuật của việc chạy một loạt các nhóm ’thực.
Ngoài ra, vì lý do hoạt động và bảo mật, chúng tôi đã chọn đặt cược các tổ chức ADA của công ty trên các nhóm này, thay vì trong các nhóm tư nhân.

In late December, we shall be retiring all but one of our (IOG) public pools, and moving the majority of our stake to private pools. We shall keep one pool open. This is both a symbolic and practical move – we want to maintain a public presence as a pool operator as well as benefit from the technical and operational experience involved.

Vào cuối tháng 12, chúng tôi sẽ nghỉ hưu tất cả trừ một trong những nhóm công cộng (IOG) của chúng tôi và chuyển phần lớn cổ phần của chúng tôi sang các hồ bơi tư nhân.
Chúng tôi sẽ giữ một hồ bơi mở.
Đây là cả một động thái biểu tượng và thực tế - chúng tôi muốn duy trì sự hiện diện công khai như một nhà điều hành hồ bơi cũng như được hưởng lợi từ kinh nghiệm kỹ thuật và hoạt động liên quan.

**Evolving our approach**

** Phát triển cách tiếp cận của chúng tôi **

IOG is a research and development company driven by a vision and missionary zeal that is arguably unmatched in the crypto space. We are committed to Cardano’s long-term adoption and success. We’re also a commercial entity and as such, we have an obligation to be commercially successful. So as much as we are bound together by our mission and purpose, an equally powerful motivation has to be in sustaining the financial success that will enable us to keep delivering on our objectives.

IOG là một công ty nghiên cứu và phát triển được thúc đẩy bởi một tầm nhìn và lòng nhiệt thành truyền giáo được cho là vô song trong không gian tiền điện tử.
Chúng tôi cam kết với việc áp dụng và thành công lâu dài của Cardano.
Chúng tôi cũng là một thực thể thương mại và như vậy, chúng tôi có nghĩa vụ phải thành công về mặt thương mại.
Vì vậy, nhiều như chúng ta bị ràng buộc với nhau bởi sứ mệnh và mục đích của chúng ta, một động lực mạnh mẽ không kém phải duy trì thành công tài chính sẽ cho phép chúng ta tiếp tục thực hiện các mục tiêu của mình.

As the creators of Cardano, we have a wide and deep role to play. Alongside our technological investment, we want to invest in other ways to help nurture the ecosystem.

Là người tạo ra Cardano, chúng ta có một vai trò rộng lớn và sâu sắc.
Bên cạnh khoản đầu tư công nghệ của chúng tôi, chúng tôi muốn đầu tư vào các cách khác để giúp nuôi dưỡng hệ sinh thái.

**Our new strategy**

** Chiến lược mới của chúng tôi **

As Cardano continues the journey to full decentralization, IOG is evolving its delegation approach. Besides moving our holdings to private pools, we will be taking about 15% of our ada holdings and delegating it to the Cardano community. We shall use this ada to support our long-term vision, support Cardano’s growth and reaffirm the values we espouse, while maintaining the financially responsible position required from us as a commercial organization.

Khi Cardano tiếp tục hành trình phân cấp hoàn toàn, IOG đang phát triển phương pháp phái đoàn của mình.
Bên cạnh việc chuyển các tổ chức của chúng tôi đến các hồ bơi tư nhân, chúng tôi sẽ nhận khoảng 15% cổ phần của chúng tôi và giao nó cho cộng đồng Cardano.
Chúng tôi sẽ sử dụng ADA này để hỗ trợ tầm nhìn dài hạn của chúng tôi, hỗ trợ tăng trưởng Cardano, và khẳng định lại các giá trị mà chúng tôi tán thành, đồng thời duy trì vị trí có trách nhiệm về tài chính từ chúng tôi như một tổ chức thương mại.

Our delegation strategy will be based on two elements: supporting what we are calling purpose pools, and encouraging network security, technological excellence and decentralized innovation through incubator pools. 

Chiến lược phái đoàn của chúng tôi sẽ dựa trên hai yếu tố: hỗ trợ những gì chúng tôi gọi là nhóm mục đích và khuyến khích an ninh mạng, sự xuất sắc về công nghệ và đổi mới phi tập trung thông qua các nhóm ươm tạo.

**Purpose pools**

** Hồ bơi mục đích **

Our primary objective here is to delegate to pools that we feel support our wider purpose and mission of economic inclusion – decentralization of sustainable technology, empowerment through education, and opening up economic identity for all. 

Mục tiêu chính của chúng tôi ở đây là ủy thác cho các nhóm mà chúng tôi cảm thấy hỗ trợ mục đích và sứ mệnh bao gồm kinh tế rộng lớn hơn - phân cấp công nghệ bền vững, trao quyền thông qua giáo dục và mở ra bản sắc kinh tế cho tất cả mọi người.

These purpose pools might include operations hosted in developing countries, where blockchain can make a massive impact, or operations focused on supporting educational objectives. Purpose pools might also include those run on a charitable or philanthropic basis, pools supporting underserved or minority members of the community, pools committed to the use of sustainable energy, and so on.

Các nhóm mục đích này có thể bao gồm các hoạt động được lưu trữ ở các nước đang phát triển, nơi blockchain có thể tạo ra một tác động lớn hoặc các hoạt động tập trung vào việc hỗ trợ các mục tiêu giáo dục.
Các nhóm mục đích cũng có thể bao gồm những người chạy trên cơ sở từ thiện hoặc từ thiện, các nhóm hỗ trợ các thành viên dân tộc thiểu số hoặc dân tộc thiểu số của cộng đồng, các nhóm cam kết sử dụng năng lượng bền vững, v.v.

These are pools that not only create tangible value today, but also aim to deliver societal impact tomorrow. That’s a bold ambition, but it is what drives us already, so we want to use some of our ada holdings to support ecosystem players who share and live by similar values.

Đây là những hồ bơi không chỉ tạo ra giá trị hữu hình ngày nay, mà còn nhằm mục đích mang lại tác động xã hội vào ngày mai.
Đó là một tham vọng táo bạo, nhưng đó là những gì thúc đẩy chúng tôi, vì vậy chúng tôi muốn sử dụng một số nắm giữ ADA của chúng tôi để hỗ trợ người chơi hệ sinh thái chia sẻ và sống theo các giá trị tương tự.

**Incubator pools**

** Bể ươm tạo **

With incubator pools, we’ll focus on supporting smaller stake pools and their operators to maximize the diversity of our pool ecosystem, notably in terms of ownership, geographic location and decentralized block production. Such pools may or may not have an ambition to grow or deliver additional value beyond their network role, but we want to get them to the stage where they can take it forward themselves.

Với các nhóm ươm tạo, chúng tôi sẽ tập trung vào việc hỗ trợ các nhóm cổ phần nhỏ hơn và các nhà khai thác của họ để tối đa hóa sự đa dạng của hệ sinh thái nhóm của chúng tôi, đáng chú ý là về quyền sở hữu, vị trí địa lý và sản xuất khối phi tập trung.
Các nhóm như vậy có thể có hoặc không có tham vọng phát triển hoặc cung cấp thêm giá trị ngoài vai trò mạng của chúng, nhưng chúng tôi muốn đưa họ đến giai đoạn mà chúng có thể tự đưa nó về phía trước.

Of course, some pools may fall into *both* categories. These categories are not mutually exclusive, and, initially, our criteria will be flexible as we develop the program. We do, however, expect a certain level of performance and potential (along with a healthy dose of ambition) from *every* pool. We shall look closely at each pool’s track record, while community kudos and influence will be important factors to consider. We also reserve the right to make occasional awards outside these core categories in the early days. This program will be driven by clear objectives, but we are open to adapting the approach at this early stage of the ecosystem’s development.

Tất nhiên, một số hồ bơi có thể rơi vào * cả hai loại *.
Các danh mục này không loại trừ lẫn nhau, và ban đầu, các tiêu chí của chúng tôi sẽ linh hoạt khi chúng tôi phát triển chương trình.
Tuy nhiên, chúng tôi mong đợi một mức độ hiệu suất và tiềm năng nhất định (cùng với một liều tham vọng lành mạnh) từ * mỗi * nhóm *.
Chúng tôi sẽ xem xét kỹ vào mỗi hồ sơ theo dõi nhóm nhóm, trong khi các danh tiếng và ảnh hưởng của cộng đồng sẽ là những yếu tố quan trọng để xem xét.
Chúng tôi cũng có quyền thực hiện các giải thưởng thường xuyên bên ngoài các hạng mục cốt lõi này trong những ngày đầu.
Chương trình này sẽ được thúc đẩy bởi các mục tiêu rõ ràng, nhưng chúng tôi sẵn sàng điều chỉnh cách tiếp cận ở giai đoạn đầu của sự phát triển của hệ sinh thái.

**Applying for delegation**

** Đơn xin ủy quyền **

We’ll launch our first ‘call for delegation’ on **December 10** (we thought [Ada Lovelace’s birthday](https://www.britannica.com/biography/Ada-Lovelace) was a suitable day to start), and we’ll keep applications open until the end of the year. Throughout 2021, we’ll run quarterly cohorts, inviting pools to apply for delegation, within a two-week window every quarter. We’ll also talk more about the program on our [**monthly update**](https://www.crowdcast.io/e/cardanoshow) next week (December 3) so be sure to tune in for details.

Chúng tôi sẽ ra mắt 'cuộc gọi cho phái đoàn' đầu tiên của chúng tôi vào ngày 10 tháng 12 ** (chúng tôi nghĩ [sinh nhật của Ada Lovelace] (https://www.britannica.com/biography/ada-lovelace) là một ngày phù hợp để bắt đầu)
và chúng tôi sẽ giữ các ứng dụng mở cho đến cuối năm nay.
Trong suốt năm 2021, chúng tôi sẽ điều hành các đoàn hệ hàng quý, mời các nhóm để nộp đơn cho phái đoàn, trong vòng hai tuần mỗi quý.
Chúng tôi cũng sẽ nói thêm về chương trình trên [** Cập nhật hàng tháng của chúng tôi **] (https://www.crowdcast.io/e/cardanoshow) vào tuần tới (ngày 3 tháng 12), vì vậy hãy chắc chắn điều chỉnh để biết chi tiết.

Here's a summary. For both programs, pool operators will need to fill out a survey covering some details, plus other questions depending on which category a pool falls into. To register for a delegation award during our winter cohort (delegation during Feb-April 2021) operators should submit a form providing background information such as their pool’s location, technology set up, objectives etc.

Đây là một bản tóm tắt.
Đối với cả hai chương trình, các nhà khai thác nhóm sẽ cần điền vào một cuộc khảo sát bao gồm một số chi tiết, cộng với các câu hỏi khác tùy thuộc vào danh mục mà một nhóm rơi vào.
Để đăng ký một giải thưởng phái đoàn trong các nhà điều hành đoàn hệ mùa đông của chúng tôi (phái đoàn trong tháng 2 năm 2021) nên gửi một biểu mẫu cung cấp thông tin cơ bản như vị trí hồ bơi của họ, công nghệ thiết lập, mục tiêu, v.v.

On the incubation side, each quarter we will be looking to delegate to between 50 and 70 pools. 

Về phía ươm tạo, mỗi quý chúng tôi sẽ tìm cách ủy thác từ 50 đến 70 bể.

We shall also select up to 10 purpose pools each quarter for the program. We’ll publish full criteria as part of the registration process on December 10, but in short, we will be looking to support pools with a mission of economic and social inclusion, and geographical diversity. We recognize that pools located in parts of the world that would most benefit from blockchain also have some of the biggest barriers. 

Chúng tôi cũng sẽ chọn tối đa 10 nhóm mục đích mỗi quý cho chương trình.
Chúng tôi sẽ xuất bản các tiêu chí đầy đủ như là một phần của quá trình đăng ký vào ngày 10 tháng 12, nhưng tóm lại, chúng tôi sẽ tìm cách hỗ trợ các nhóm với sứ mệnh hòa nhập kinh tế và xã hội, và sự đa dạng về địa lý.
Chúng tôi nhận ra rằng các hồ bơi nằm ở các nơi trên thế giới có lợi nhất từ blockchain cũng có một số rào cản lớn nhất.

**Initial three-month delegation**

** Phái đoàn ba tháng ban đầu **

Each pool selected will receive a delegation for an initial three months – pools will be rotated every quarter. IOG will delegate enough ada to ensure that each of these pools produces at least one block every epoch. At *k*= 500, we anticipate this amount to be between 3 million and 5 million ada *per pool*. All pools selected will receive an equal delegation amount.

Mỗi nhóm được chọn sẽ nhận được một phái đoàn trong ba tháng ban đầu - các nhóm sẽ được xoay vòng mỗi quý.
IOG sẽ ủy thác đủ ADA để đảm bảo rằng mỗi nhóm này tạo ra ít nhất một khối mỗi kỷ nguyên.
Tại *K *= 500, chúng tôi dự đoán số tiền này là từ 3 triệu đến 5 triệu ADA *mỗi nhóm *.
Tất cả các nhóm được chọn sẽ nhận được một số tiền ủy quyền.

We’ll review all applications in early/mid January, with a view to start delegating by the end of that month. We’ll publish a list of all chosen pools for both programs for full transparency among the community, which may also help people with their own delegation choices. Initial delegation awards will stay in place till the end of March.

Chúng tôi sẽ xem xét tất cả các ứng dụng vào đầu/giữa tháng 1, với mục đích bắt đầu ủy thác vào cuối tháng đó.
Chúng tôi sẽ công bố một danh sách tất cả các nhóm được chọn cho cả hai chương trình để minh bạch toàn diện trong cộng đồng, điều này cũng có thể giúp mọi người có lựa chọn phái đoàn của riêng họ.
Giải thưởng phái đoàn ban đầu sẽ giữ nguyên vị trí cho đến cuối tháng ba.

It is still early days for Cardano. Together, we’re building a decentralized ecosystem that will prove its value over decades, so it cannot be fairly judged over months. Yet we’re already seeing incredible momentum in a community that is passionate, committed, and skilled. We hope this new strategy will help identify and encourage some of those pools and ‘pioneers’ – a word we may have overused in 2020 but one we feel remains valid – and help accelerate our growth into 2021 and set us up for many successful years ahead.

Vẫn là những ngày đầu cho Cardano.
Cùng nhau, chúng tôi xây dựng một hệ sinh thái phi tập trung sẽ chứng minh giá trị của nó trong nhiều thập kỷ, vì vậy nó không thể được đánh giá khá nhiều trong nhiều tháng.
Tuy nhiên, chúng tôi đã nhìn thấy động lực đáng kinh ngạc trong một cộng đồng đam mê, cam kết và lành nghề.
Chúng tôi hy vọng chiến lược mới này sẽ giúp xác định và khuyến khích một số nhóm và 'người tiên phong' - một từ mà chúng tôi có thể đã sử dụng quá mức vào năm 2020 nhưng chúng tôi cảm thấy vẫn còn hợp lệ - và giúp tăng tốc sự tăng trưởng của chúng tôi vào năm 2021 và đưa chúng tôi lên trong nhiều năm thành công phía trước
.

