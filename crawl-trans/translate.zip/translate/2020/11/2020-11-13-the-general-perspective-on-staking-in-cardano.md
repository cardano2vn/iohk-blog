# The general perspective on staking in Cardano
### **Advice for Stakeholders - Delegators and Stake Pool Operators.**
![](img/2020-11-13-the-general-perspective-on-staking-in-cardano.002.png) 13 November 2020![](img/2020-11-13-the-general-perspective-on-staking-in-cardano.002.png)[ Prof Aggelos Kiayias](tmp//en/blog/authors/aggelos-kiayias/page-1/)![](img/2020-11-13-the-general-perspective-on-staking-in-cardano.003.png) 13 mins read

![Prof Aggelos Kiayias](img/2020-11-13-the-general-perspective-on-staking-in-cardano.004.png)[](tmp//en/blog/authors/aggelos-kiayias/page-1/)
### [**Prof Aggelos Kiayias**](tmp//en/blog/authors/aggelos-kiayias/page-1/)
Chief Scientist

Academic Research

- ![](img/2020-11-13-the-general-perspective-on-staking-in-cardano.005.png)[](mailto:aggelos.kiayias@iohk.io "Email")
- ![](img/2020-11-13-the-general-perspective-on-staking-in-cardano.006.png)[](tmp///www.youtube.com/watch?v=nB6eDbnkAk8 "YouTube")

![The general perspective on staking in Cardano](img/2020-11-13-the-general-perspective-on-staking-in-cardano.007.jpeg)

Your browser does not support the audio element.

Trình duyệt của bạn không hỗ trợ các yếu tố âm thanh.

As a project, decentralization remains arguably our most important and fundamental goal for Cardano. Protocols and parameters provide the foundations for any blockchain. Last week, we outlined some of the planned [changes around Cardano parameters](https://iohk.io/en/blog/posts/2020/11/05/parameters-and-decentralization-the-way-ahead/) and how these will impact the staking ecosystem and thus accelerate our decentralization mission.

Là một dự án, phân cấp vẫn được cho là mục tiêu quan trọng nhất và cơ bản nhất của chúng tôi đối với Cardano.
Các giao thức và tham số cung cấp nền tảng cho bất kỳ blockchain nào.
Tuần trước, chúng tôi đã phác thảo một số [những thay đổi được lên kế hoạch xung quanh các tham số Cardano] (https://iohk.io/en/blog/posts/2020/11/05/parameters-and-decentralization-the-way-ahead/) và
Làm thế nào những điều này sẽ tác động đến hệ sinh thái đặt cược và do đó tăng tốc sứ mệnh phân cấp của chúng tôi.

Yet the community itself â€“ how it sees itself, how it behaves, and how it sets common standards â€“ is a key factor in the pace of this success. Cardano has been very carefully engineered to provide â€œby designâ€ all the necessary properties for a blockchain system to operate successfully. However, Cardano is also a *social* construct, and as such, observance, interpretation, and social norms play a crucial role in shaping its resilience and longevity.

Tuy nhiên, bản thân cộng đồng - cách nó nhìn thấy, cách cư xử của nó và cách nó thiết lập các tiêu chuẩn chung - là một yếu tố chính trong tốc độ của thành công này.
Cardano đã được thiết kế rất cẩn thận để cung cấp thiết kế - tất cả các thuộc tính cần thiết cho một hệ thống blockchain để vận hành thành công.
Tuy nhiên, Cardano cũng là một cấu trúc * xã hội *, và như vậy, sự quan sát, giải thích và các chuẩn mực xã hội đóng một vai trò quan trọng trong việc định hình khả năng phục hồi và tuổi thọ của nó.

So in anticipation of the *k*-parameter adjustment on December 6th, I would like to give a broader perspective on staking, highlighting some of the innovative features of the [rewards sharing scheme](https://arxiv.org/abs/1807.11218) used in Cardano. 

Vì vậy, dự đoán điều chỉnh *K *-Parameter vào ngày 6 tháng 12, tôi muốn đưa ra một viễn cảnh rộng hơn về việc đặt cược, nêu bật một số tính năng sáng tạo của [Chương trình chia sẻ phần thưởng] (https://arxiv.org/abs/
1807.11218) Được sử dụng trong Cardano.

### **Principles & practical intent**

### ** Nguyên tắc và ý định thực tế **

As well as outlining some of the key principles, this piece has a clear practical intent; to provide guidance and some recommendations to stakeholders so that they engage meaningfully with the mechanism, and support the projectâ€™s longer-term strategic goals through their actions.

Cũng như phác thảo một số nguyên tắc chính, tác phẩm này có một ý định thực tế rõ ràng;
Để cung cấp hướng dẫn và một số khuyến nghị cho các bên liên quan để họ tham gia một cách có ý nghĩa với cơ chế và hỗ trợ các mục tiêu chiến lược dài hạn của dự án thông qua hành động của họ.

Consensus based on a *resource* that is dispersed somehow across a population of users â€“ as opposed to identity-based participation â€“ has been the hallmark of the blockchain space since the launch of the Bitcoin blockchain. In this domain, proof-of-stake systems are distinguished in the sense that they use a virtual resource, *stake*, which is recorded in the blockchain itself. 

Sự đồng thuận dựa trên một tài nguyên * * được phân tán bằng cách nào đó trên một nhóm người dùng-trái ngược với sự tham gia dựa trên danh tính-đã là dấu hiệu đặc trưng của không gian blockchain kể từ khi ra mắt blockchain bitcoin.
Trong miền này, các hệ thống chứng minh cổ phần được phân biệt theo nghĩa là chúng sử dụng tài nguyên ảo, *cổ phần *, được ghi lại trong chính blockchain.

Pooling resources for participation is something that is inevitable; some level of pooling is typically beneficial in the economic sense and hence resource holders will find a way to make it happen. Given this inevitability, the question arises: how does a system prevent a dictatorship or an oligarchy from emerging?

Tài nguyên gộp cho sự tham gia là điều không thể tránh khỏi;
Một số mức độ gộp thường có lợi theo nghĩa kinh tế và do đó, những người nắm giữ tài nguyên sẽ tìm ra cách để biến nó thành hiện thực.
Với điều không thể tránh khỏi này, câu hỏi đặt ra: Làm thế nào để một hệ thống ngăn chặn chế độ độc tài hoặc đầu sỏ không xuất hiện?

### **The objectives of the reward sharing scheme**

### ** Mục tiêu của chương trình chia sẻ phần thưởng **

Contrary to other blockchain systems, Cardano uses a reward sharing scheme that (1) facilitates staking with *minimum friction as well* as (2) it incentivizes pooling resources in a way that *system-wide decentralization* emerges naturally from the rational engagement of the resource holders.

Trái với các hệ thống blockchain khác, Cardano sử dụng sơ đồ chia sẻ phần thưởng mà (1) tạo điều kiện cho việc đặt cược với * ma sát tối thiểu cũng như (2) nó khuyến khích các tài nguyên gộp theo cách * phân cấp toàn hệ thống * xuất hiện một cách tự nhiên từ sự tham gia hợp lý của
các chủ sở hữu tài nguyên.

The mechanism has the following two broad objectives:

Cơ chế có hai mục tiêu rộng sau:

1. **Engage *all* stakeholders** - This is important since the more stakeholders are engaged in the system, the more *secure* the distributed ledger will be. This also means that the system should have no barriers for participation, nor should impose friction by requiring off-chain coordination between stakeholders to engage with the mechanism. 

1. ** Tham gia*Tất cả*các bên liên quan ** - Điều này rất quan trọng vì càng nhiều bên liên quan tham gia vào hệ thống, thì càng an toàn*sổ cái phân tán sẽ có.
Điều này cũng có nghĩa là hệ thống không nên có rào cản tham gia, cũng không nên áp đặt ma sát bằng cách yêu cầu sự phối hợp ngoài chuỗi giữa các bên liên quan tham gia vào cơ chế.

1. **Keep the leverage of individual stakeholders low** -. Pooling resources leads to increased leverage for some stakeholders. Pool operators exert an influence in the system proportional to the resources controlled by their pool, *not to their own* resources. Without pooling, all resource holders have leverage of exactly 1; contrast this e.g., to a pool operator, owning, say 100K ada, who controls a pool of total delegated stake of 200M ada; that operator has leverage of 2,000. The higher the leverage of the system, the worse its security (to see this, consider that with leverage above 50, launching a 51% attack requires a mere 1% of the total resources!).

1. ** Giữ đòn bẩy của các bên liên quan cá nhân thấp ** -.
Tài nguyên tổng hợp dẫn đến tăng đòn bẩy cho một số bên liên quan.
Các nhà khai thác nhóm gây ảnh hưởng trong hệ thống tỷ lệ thuận với các tài nguyên do nhóm của họ kiểm soát, * không phải là tài nguyên * của chính họ.
Không có gộp, tất cả các chủ sở hữu tài nguyên đều có đòn bẩy chính xác 1;
Tương phản điều này, ví dụ, với một nhà điều hành hồ bơi, sở hữu, nói 100k ADA, người kiểm soát một nhóm tổng cổ phần được ủy quyền là 200m ADA;
Nhà điều hành đó có đòn bẩy 2.000.
Đòn bẩy của hệ thống càng cao, bảo mật của nó càng tệ (để thấy điều này, hãy xem xét rằng với đòn bẩy trên 50, khởi động một cuộc tấn công 51% chỉ cần chỉ 1% tổng số tài nguyên!).

It should also be stressed that a disproportionately large pool size is not the only reason for increased leverage; stakeholders creating multiple pools, either openly or covertly (what is known as a Sybil attack) can also lead to increased leverage. The lower the leverage of a blockchain system, the higher its degree of decentralization.

Cũng cần nhấn mạnh rằng kích thước hồ bơi lớn không tương xứng không phải là lý do duy nhất để tăng đòn bẩy;
Các bên liên quan tạo ra nhiều nhóm, một cách công khai hoặc bí mật (cái được gọi là một cuộc tấn công của Sybil) cũng có thể dẫn đến tăng đòn bẩy.
Đòn bẩy của một hệ thống blockchain càng thấp, mức độ phân cấp của nó càng cao.

### **Putting this into practice**

### ** Đặt điều này vào thực tế **

So how does the reward sharing scheme used in Cardano meet the above objectives? Staking via our scheme facilitates two different paths: *pledging* and *delegating*. Pledging applies to stake pool operators; pledged stake is committed to a stake pool and is supposed to stay put for as long as the pool is operating. Think of pledge as a â€˜commitmentâ€™ to the network â€“ â€˜locking upâ€™ a certain amount of stake in order to help safeguard and secure the protocol. Delegating on the other hand, is for those who do not wish to be involved as operators. Instead, they are invited to assess the offerings the stake pool operators provide, and delegate their stake to one or more pools that, in their opinion, best serve their interests and the interest of the community at large. Given that delegation does not require locking up funds, there is no reason to abstain from staking in Cardano; all stakeholders can and are encouraged to engage in staking.

Vậy làm thế nào để chương trình chia sẻ phần thưởng được sử dụng trong Cardano đáp ứng các mục tiêu trên?
Cổ phần thông qua sơ đồ của chúng tôi tạo điều kiện cho hai đường dẫn khác nhau: *cam kết *và *ủy thác *.
Cam kết áp dụng cho các nhà khai thác nhóm cổ phần;
Cam kết cam kết cam kết với một nhóm cổ phần và được cho là sẽ được đặt miễn là hồ bơi đang hoạt động.
Hãy nghĩ về cam kết như là một phần mềm "đối với mạng -" € ˜ ˜ ˜ ˜ ˜ ’€ ™ một số lượng cổ phần nhất định để giúp bảo vệ và bảo vệ giao thức.
Mặt khác, ủy thác là dành cho những người không muốn tham gia với tư cách là nhà khai thác.
Thay vào đó, họ được mời để đánh giá các dịch vụ mà các nhà khai thác nhóm cổ phần cung cấp và ủy thác cổ phần của họ cho một hoặc nhiều nhóm, theo ý kiến của họ, phục vụ tốt nhất lợi ích của họ và lợi ích của cộng đồng nói chung.
Cho rằng phái đoàn không yêu cầu khóa tiền, không có lý do gì để kiêng việc đặt cardano;
Tất cả các bên liên quan có thể và được khuyến khích tham gia vào việc đặt cược.

Central to the mechanismâ€™s behavior are two parameters: *k* and a0. The k-parameter caps the rewards of pools to 1/*k* of the total available. The a0 parameter creates a benefit for pledging more stake into a single pool; adding X amount of pledge to a pool increases its rewards additively by up to a0\*X. This is not to the detriment of other pools; any rewards left unclaimed due to insufficient pledging will be returned to the Cardanoâ€™s reserves and allocated in the future. 

Trọng tâm của hành vi của cơ chế là hai tham số: * K * và A0.
Các tham số K giới hạn phần thưởng của các nhóm đến 1/* k* trong tổng số có sẵn.
Tham số A0 tạo ra một lợi ích cho việc cam kết nhiều cổ phần hơn vào một nhóm duy nhất;
Thêm x số tiền cam kết vào một nhóm làm tăng phần thưởng của nó một cách phụ thuộc lên đến A0 \*x.
Điều này không gây bất lợi cho các hồ bơi khác;
Bất kỳ phần thưởng nào không được yêu cầu do cam kết không đủ sẽ được trả lại cho dự trữ của Cardano và được phân bổ trong tương lai.

Beyond deciding on an amount to pledge, creating a stake pool requires that operators declare their profit margin and operational costs. When the pool rewards are allocated at the end of each epoch, the operational costs are withheld first, ensuring that stake pools remain viable. Subsequently, operator profit is calculated, and all pool delegators are rewarded in ada proportional to their stake afterwards. 

Ngoài việc quyết định một khoản tiền cam kết, việc tạo ra một nhóm cổ phần yêu cầu các nhà khai thác tuyên bố tỷ suất lợi nhuận và chi phí hoạt động của họ.
Khi phần thưởng nhóm được phân bổ ở cuối mỗi kỷ nguyên, chi phí hoạt động được giữ lại trước, đảm bảo rằng các nhóm cổ phần vẫn khả thi.
Sau đó, lợi nhuận của nhà điều hành được tính toán và tất cả các ủy viên nhóm được khen thưởng theo tỷ lệ thuận với cổ phần của họ sau đó.

Paired with the assessment of stake pools performed by the delegates, this mechanism provides the right set of constraints for the system to converge to a configuration of *k* equal size pools with the maximum amount of pledge possible. The equilibrium point has the property that delegator rewards are equalized (so it doesnâ€™t matter what pool they delegate to!), while stake pool operators are rewarded appropriately for their performance, their cost efficiency, and their general contributions to the ecosystem.

Được kết hợp với việc đánh giá các nhóm cổ phần được thực hiện bởi các đại biểu, cơ chế này cung cấp bộ ràng buộc phù hợp để hệ thống hội tụ đến một cấu hình của các nhóm kích thước bằng nhau * K * với số lượng cam kết tối đa có thể.
Điểm cân bằng có tài sản mà phần thưởng ủy quyền được cân bằng (vì vậy nó không quan trọng với nhóm họ ủy thác!), Trong khi các nhà khai thác nhóm cổ phần được khen thưởng cho hiệu suất, hiệu quả chi phí của họ và đóng góp chung của họ cho hệ sinh thái.

For the above to happen, it is necessary to engage with the mechanism in a meaningful and rational manner. To assist stakeholders in understanding the mechanism, here are some points of advice. 

Để những điều trên xảy ra, cần phải tham gia vào cơ chế một cách có ý nghĩa và hợp lý.
Để hỗ trợ các bên liên quan trong việc tìm hiểu cơ chế, đây là một số điểm của lời khuyên.

### **Guidance for delegators**

### ** Hướng dẫn cho các ủy viên **

1. **Know your pool(s)** - Investigate the poolsâ€™ available data and information. What is the operatorsâ€™ web-presence? What kind of information do they provide about their operation? Are they descriptive about their costs? Are the costs reasonably based on geographic location and other aspects of their operation? Do they update their costs regularly to account for the fluctuation of ada? Do they include the costs for their personal time? Remember that maintaining a high-performance pool requires commitment and effort, so those committed operators deserve compensation. 

1. ** Biết (các) nhóm của bạn ** - Điều tra dữ liệu và thông tin có sẵn của nhóm.
Các nhà điều hành-trình bày web là gì?
Những loại thông tin họ cung cấp về hoạt động của họ?
Họ có mô tả về chi phí của họ không?
Là chi phí hợp lý dựa trên vị trí địa lý và các khía cạnh khác của hoạt động của họ?
Họ có cập nhật chi phí thường xuyên để tính đến sự biến động của ADA không?
Họ có bao gồm các chi phí cho thời gian cá nhân của họ không?
Hãy nhớ rằng việc duy trì một nhóm hiệu suất cao đòi hỏi sự cam kết và nỗ lực, vì vậy những nhà khai thác cam kết xứng đáng được bồi thường.

2. **Think bigger** - Consider your choice holistically, not based on just a single dimension. Consider the longer term value your choices bring to the network. Think of your delegation as a â€˜vote of confidenceâ€™, or a way to show your support to a pool's mission or goals. Opt for professionalism and demonstrated long-term commitment to the systemâ€™s goals. Recognize community members who have been helping to lay down the foundations for the ecosystem, either with their community presence or by helping to build things. The long-term wellbeing of the ecosystem is crucially affected by your delegation choice. A more decentralized network is a more resilient and long-lived network. 

2. ** Nghĩ lớn hơn ** - Hãy xem xét sự lựa chọn của bạn một cách toàn diện, không chỉ dựa trên một chiều duy nhất.
Hãy xem xét giá trị dài hạn hơn lựa chọn của bạn mang đến cho mạng.
Hãy nghĩ về phái đoàn của bạn như là một sự tự tin "hoặc là một cách để thể hiện sự hỗ trợ của bạn đối với nhiệm vụ hoặc mục tiêu của nhóm.
Lựa chọn không chuyên nghiệp và thể hiện cam kết lâu dài đối với các mục tiêu của hệ thống.
Nhận ra các thành viên cộng đồng, những người đã giúp đặt nền móng cho hệ sinh thái, với sự hiện diện của cộng đồng hoặc bằng cách giúp xây dựng mọi thứ.
Sự thịnh vượng lâu dài của hệ sinh thái bị ảnh hưởng chủ yếu bởi sự lựa chọn phái đoàn của bạn.
Một mạng phi tập trung hơn là một mạng có khả năng phục hồi và tồn tại lâu dài hơn.

2. **Be wary of â€˜pool splittersâ€™** - Pool operators that run multiple pools *with small pledge* ***hurt delegators and smaller operators***. They hurt their delegators because they could have provided a higher amount of rewards by concentrating their pledge into a single pool; by not doing that, there are rewards that remain unclaimed. They hurt smaller and new operators, because they are forcing them to remain without delegates and hence making their operation unviable â€“ without delegates a pool may be forced to close. So avoid pool operators that run multiple pools with pledge below saturation level. Note there are legitimate reasons for large stakeholders to accept delegators and run a public pool (e.g., they are delegating some of their stake to other pools to support the community); consult any public statements such operators make about their delegation strategy and their leverage. It is ok to delegate to them, assuming they keep their leverage low and they support the community. 

2. ** Hãy cảnh giác với những người chia tách pool '€ ™ ** - Các nhà khai thác hồ bơi chạy nhiều hồ bơi*với cam kết nhỏ**** HAVE MALTERS và các nhà khai thác nhỏ hơn ***. Họ làm tổn thương các ủy viên của họ vì họ có thể đã cung cấp một lượng phần thưởng cao hơn bằng cách tập trung cam kết của họ vào một hồ bơi duy nhất; Bằng cách không làm điều đó, có những phần thưởng vẫn chưa được yêu cầu. Họ làm tổn thương các nhà khai thác nhỏ hơn và mới, bởi vì họ buộc họ phải ở lại mà không có đại biểu và do đó làm cho hoạt động của họ không thể thực hiện được - mà không có đại biểu, một hồ bơi có thể bị buộc phải đóng cửa. Vì vậy, tránh các nhà khai thác hồ bơi chạy nhiều nhóm với cam kết dưới mức bão hòa. Lưu ý Có những lý do chính đáng để các bên liên quan lớn chấp nhận các ủy viên và điều hành một nhóm công cộng (ví dụ: họ đang ủy thác một số cổ phần của họ cho các nhóm khác để hỗ trợ cộng đồng); Tham khảo bất kỳ tuyên bố công khai nào mà các nhà khai thác như vậy thực hiện về chiến lược phái đoàn của họ và đòn bẩy của họ. Bạn có thể ủy thác cho họ, giả sử họ giữ đòn bẩy của họ thấp và họ hỗ trợ cộng đồng.

2. **Be wary of highly leveraged operators** - Be mindful of the stake pool operatorsâ€™ *leverage* (see below for more details on how to calculate leverage). A higher pledge is correlated to less leverage when comparing pools of the same size; a high leverage is indicative of a stake pool operator with very little â€œskin in the game.â€ Stake pool operators may prove to have skin in the game in other ways than pledging stake of course; e.g., they can be very professional and contribute to the community in different ways. You should be the judge of this: high leverage in itself is not a reason to avoid delegating to a particular pool, but it is a *strong* indication that you should proceed with caution and carefully evaluate the people behind the operation. 

2. ** Hãy cảnh giác với các nhà khai thác có đòn bẩy cao ** - Hãy chú ý đến các nhà khai thác nhóm cổ phần - đòn bẩy**(xem bên dưới để biết thêm chi tiết về cách tính toán đòn bẩy).
Một cam kết cao hơn có liên quan đến ít đòn bẩy hơn khi so sánh các nhóm có cùng kích thước;
Một đòn bẩy cao là dấu hiệu của một nhà điều hành nhóm cổ phần với rất ít "da trong trò chơi. Các nhà điều hành nhóm cổ phần có thể chứng minh có da trong trò chơi theo những cách khác hơn là cam kết cổ phần;
Ví dụ: họ có thể rất chuyên nghiệp và đóng góp cho cộng đồng theo những cách khác nhau.
Bạn nên là thẩm phán của điều này: Bản thân đòn bẩy cao không phải là lý do để tránh ủy thác cho một nhóm cụ thể, nhưng đó là một dấu hiệu * mạnh * cho thấy bạn nên tiến hành thận trọng và đánh giá cẩn thận những người đứng sau hoạt động.

2. **Shop around** - Do take into account the information provided from your wallet software (or from recognized community resources such as [adapools](https://adapools.org/) or [pooltool](https://pooltool.io/)) in terms of the poolâ€™s ranking and its performance factor. Remember though, while the ranking is important, it should not be the sole factor behind your delegation choice. Think holistically â€“ you may want to consider pools fulfilling a mission you agree with, or trying to add value to the wider community through podcasts or social activity, even if they do not offer the highest possible returns.

2. ** Mua sắm xung quanh ** - Hãy tính đến thông tin được cung cấp từ phần mềm ví của bạn (hoặc từ các tài nguyên cộng đồng được công nhận như [Adapools] (https://adapools.org/) hoặc [pooltool] (https: //
pooltool.io/)) về thứ hạng của nhóm và yếu tố hiệu suất của nó.
Mặc dù vậy, hãy nhớ rằng trong khi xếp hạng là quan trọng, nó không phải là yếu tố duy nhất đằng sau sự lựa chọn phái đoàn của bạn.
Hãy suy nghĩ một cách toàn diện - Bạn có thể muốn xem xét các nhóm hoàn thành một nhiệm vụ mà bạn đồng ý hoặc cố gắng tăng thêm giá trị cho cộng đồng rộng lớn hơn thông qua podcast hoặc hoạt động xã hội, ngay cả khi họ không cung cấp lợi nhuận cao nhất có thể.

2. **Be involved** - A pool with no performance data on display may have attractive characteristics; it could be providing better rewards in the best case scenario, but also high risk as a delegation choice since its performance may turn out to be suboptimal. Delegate according to your â€˜risk profileâ€™, and the frequency you are willing to re-delegate your stake. Do check the poolâ€™s performance and updates regularly to ensure that your choice and assessment remains the best possible. 

2. ** Có liên quan ** - Một nhóm không có dữ liệu hiệu suất được hiển thị có thể có các đặc điểm hấp dẫn;
Nó có thể cung cấp phần thưởng tốt hơn trong trường hợp tốt nhất, nhưng cũng có rủi ro cao như một lựa chọn phái đoàn vì hiệu suất của nó có thể trở nên tối ưu.
Đại biểu theo hồ sơ kỹ lưỡng của bạn, và tần suất bạn sẵn sàng phân bổ lại cổ phần của mình.
Hãy kiểm tra hiệu suất của nhóm và cập nhật thường xuyên để đảm bảo rằng sự lựa chọn và đánh giá của bạn vẫn là tốt nhất có thể.

### **Guidance for pool operators**

### ** Hướng dẫn cho người vận hành hồ bơi **

1. **Be transparent** - Choose your poolâ€™s operational cost as accurately as possible. Do include the personal effort (priced at a reasonable rate) that you and your partners put into the pool operation! You are a pillar of Cardano and so you have every right to be compensated by the community. Be upfront about your costs and include them in your poolâ€™s website. Educate your prospective delegates about where the pool costs are going. Always remember that it is important to charge for the time you invest in maintaining your pool. In the short term, you may be prepared to invest your time and energy â€˜for freeâ€™ (or after hosting costs, at an effective loss) but remember that this is not a sustainable model for the network over the medium and longer term. 

1. ** Hãy minh bạch ** - Chọn chi phí hoạt động của nhóm bạn càng chính xác càng tốt.
Bao gồm nỗ lực cá nhân (có giá với mức giá hợp lý) mà bạn và các đối tác của bạn đưa vào hoạt động nhóm!
Bạn là một trụ cột của Cardano và vì vậy bạn có quyền được cộng đồng bồi thường.
Hãy thẳng thắn về chi phí của bạn và đưa chúng vào trang web của bạn.
Giáo dục các đại biểu tương lai của bạn về nơi chi phí hồ bơi đang đi.
Luôn luôn nhớ rằng điều quan trọng là phải tính phí cho thời gian bạn đầu tư vào việc duy trì nhóm của bạn.
Trong ngắn hạn, bạn có thể sẵn sàng đầu tư thời gian và năng lượng của mình - miễn phí
kỳ hạn.

1. **Donâ€™t split your pool** - With the coming changes in *k* (commencing with the move to k=500 on 6th December), we are already seeing pool operators splitting their pools in order to retain delegators without becoming saturated. Do not engage in pool splitting unless you can saturate a pool completely with your stake. If you are a whale (relative stake > 1/*k*) you can create multiple pools â€“ but you should keep your leverage as close to 1 as possible or less. Pool splitting that increases your leverage hurts the delegatorsâ€™ rewards, and more importantly, it hurts the decentralization of the Cardano ecosystem, which is detrimental to everyone. If you run and control multiple pools under different tickers, make a public statement about it. Explain the steps you take to control your leverage. Creating multiple pools while trying to conceal the fact that you control them is akin to a Sybil attack against Cardano. This behavior should be condemned by the community. You can calculate and publicize your leverage using the following formula:

1 mà không trở nên bão hòa. Không tham gia vào việc chia tách bể bơi trừ khi bạn có thể bão hòa hoàn toàn một nhóm bằng cổ phần của mình. Nếu bạn là một con cá voi (cổ phần tương đối> 1/*k*), bạn có thể tạo nhiều nhóm - Nhưng bạn nên giữ đòn bẩy của mình càng gần 1 càng tốt hoặc ít hơn. Việc chia tách nhóm làm tăng đòn bẩy của bạn làm tổn thương phần thưởng của các đại biểu, và quan trọng hơn, nó làm tổn thương sự phân cấp của hệ sinh thái Cardano, gây bất lợi cho mọi người. Nếu bạn chạy và kiểm soát nhiều nhóm dưới các mã ve khác nhau, hãy đưa ra một tuyên bố công khai về nó. Giải thích các bước bạn thực hiện để kiểm soát đòn bẩy của bạn. Tạo ra nhiều hồ bơi trong khi cố gắng che giấu sự thật rằng bạn kiểm soát chúng giống như một cuộc tấn công của Sybil chống lại Cardano. Hành vi này nên được cộng đồng lên án. Bạn có thể tính toán và công khai đòn bẩy của mình bằng công thức sau:

![](img/2020-11-13-the-general-perspective-on-staking-in-cardano.008.jpeg)

Exchanges are a special kind of whale stakeholder, since they collectively manage other peopleâ€™s stake. One strategy for an exchange is to avoid leverage altogether and delegate the stake they control to community pools. If an exchange becomes a pool operator, they can maintain their leverage below 1 by using a mixed pledging and delegation strategy. 

Trao đổi là một loại bên liên quan đặc biệt của cá voi, vì họ quản lý chung cổ phần của người khác.
Một chiến lược cho một cuộc trao đổi là để tránh đòn bẩy hoàn toàn và ủy thác cổ phần mà họ kiểm soát cho các nhóm cộng đồng.
Nếu một trao đổi trở thành một nhà điều hành hồ bơi, họ có thể duy trì đòn bẩy của mình dưới 1 bằng cách sử dụng chiến lược cam kết và ủy quyền hỗn hợp.

3. **Set your profit margin wisely** - Select the margin to make your pool competitive. Remember that if everyone delegates their stake and is rational, you only have to beat the (*k*+1)-th pool in the rankings offered by the Daedalus wallet. If your pool offers other advantages that can attract delegation (e.g., you are contributing to a charitable cause you feel others may wish to support), or you have acquired exceptional equipment that promises notable uptime/performance, make sure you promote this widely. When you offer such benefits, you should consider setting a higher profit margin. 

3. ** Đặt biên lợi nhuận của bạn một cách khôn ngoan ** - Chọn biên độ để làm cho nhóm của bạn cạnh tranh.
Hãy nhớ rằng nếu mọi người ủy thác cổ phần của họ và hợp lý, bạn chỉ phải đánh bại nhóm (*k*+1) trong bảng xếp hạng được cung cấp bởi ví Daedalus.
Nếu nhóm của bạn cung cấp những lợi thế khác có thể thu hút phái đoàn (ví dụ: bạn đang đóng góp cho một khoản tiền từ thiện mà bạn cảm thấy người khác có thể muốn hỗ trợ) hoặc bạn đã có được các thiết bị đặc biệt hứa hẹn thời gian hoạt động/hiệu suất đáng chú ý, hãy đảm bảo bạn quảng bá điều này rộng rãi.
Khi bạn cung cấp những lợi ích như vậy, bạn nên xem xét thiết lập tỷ suất lợi nhuận cao hơn.

4. **Keep your pool data updated** - Regularly update the cost and margin to accommodate fluctuations in ada price. Give assurances to your delegators and update them about the stake pool operational details. In case of mishaps and downtimes, be upfront and inform your delegators via your website and/or other communication channels you maintain with them. 

4. ** Cập nhật dữ liệu nhóm của bạn ** - Thường xuyên cập nhật chi phí và ký quỹ để phù hợp với biến động trong giá ADA.
Đưa ra sự đảm bảo cho các ủy viên của bạn và cập nhật chúng về chi tiết vận hành nhóm cổ phần.
Trong trường hợp rủi ro và thời gian suy giảm, hãy trả trước và thông báo cho các ủy viên của bạn thông qua trang web của bạn và/hoặc các kênh liên lạc khác mà bạn duy trì với họ.

4. **Pledge as much as you are able to** - Increase the amount of pledge as much as you comfortably can and not more. Beyond using your own stake, you can also partner with other stakeholders to increase the pledge of your pool. A high pledge signals long-term commitment and reduced leverage, and it unlocks additional rewards every epoch as dictated by the a0 term in the rewards sharing scheme calculation. As a result, it does make your pool more desirable to prospective delegators. On the other hand, remember that pledge is not the only factor that makes a pool attractive. Spend time on your web and social media presence and be sure to advertise all the ways that you contribute to the Cardano ecosystem. 

4. ** Cam kết nhiều như bạn có thể ** - Tăng số lượng cam kết nhiều nhất có thể và không nhiều hơn.
Ngoài việc sử dụng cổ phần của riêng bạn, bạn cũng có thể hợp tác với các bên liên quan khác để tăng cam kết nhóm của bạn.
Một cam kết cao tín hiệu cam kết dài hạn và giảm đòn bẩy, và nó mở ra các phần thưởng bổ sung cho mỗi kỷ nguyên theo quy định của thuật ngữ A0 trong tính toán sơ đồ chia sẻ phần thưởng.
Kết quả là, nó làm cho hồ bơi của bạn mong muốn hơn đối với các ủy viên tiềm năng.
Mặt khác, hãy nhớ rằng cam kết không phải là yếu tố duy nhất làm cho một hồ bơi hấp dẫn.
Dành thời gian cho sự hiện diện trên mạng và phương tiện truyền thông xã hội của bạn và chắc chắn quảng cáo tất cả các cách mà bạn đóng góp cho hệ sinh thái Cardano.

If you are a Cardano stakeholder, we hope that you find the above advice informative and helpful in your efforts to engage in staking. As in many other respects, Cardano brings a novel and heavily researched mechanism to its blockchain design. The rewards scheme is mathematically proven to offer an equilibrium that meets the set of objectives set out in the beginning of this document. Ultimately though, the math is not enough; it is *only the people* that can make it happen. 

Nếu bạn là một bên liên quan của Cardano, chúng tôi hy vọng rằng bạn tìm thấy những thông tin lời khuyên trên và hữu ích trong nỗ lực tham gia vào việc đặt cược.
Như trong nhiều khía cạnh khác, Cardano mang đến một cơ chế mới và nghiên cứu rất nhiều cho thiết kế blockchain của nó.
Sơ đồ phần thưởng được chứng minh về mặt toán học để cung cấp một trạng thái cân bằng đáp ứng tập hợp các mục tiêu được đặt ra ở phần đầu của tài liệu này.
Cuối cùng, toán học là không đủ;
Đó là * chỉ những người * có thể làm cho nó xảy ra.

Cardanoâ€™s future is in the hands of the community. 

Tương lai của Cardano nằm trong tay cộng đồng.

*The opinions expressed in the blogpost are for educational purposes only and are not intended to provide any form of financial advice.*

*Các ý kiến thể hiện trong blogpost chỉ dành cho mục đích giáo dục và không nhằm cung cấp bất kỳ hình thức tư vấn tài chính nào.*

