# Smash: introducing a new way of managing stake pool metadata
### **Our metadata framework supports delegators and the community by bringing verified information to the Cardano network**
![](img/2020-11-17-in-pools-we-trust.002.png) 17 November 2020![](img/2020-11-17-in-pools-we-trust.002.png)[ Olga Hryniuk](tmp//en/blog/authors/olga-hryniuk/page-1/)![](img/2020-11-17-in-pools-we-trust.003.png) 5 mins read

![Olga Hryniuk](img/2020-11-17-in-pools-we-trust.004.png)[](tmp//en/blog/authors/olga-hryniuk/page-1/)
### [**Olga Hryniuk**](tmp//en/blog/authors/olga-hryniuk/page-1/)
Technical Writer

Marketing & Communications

- ![](img/2020-11-17-in-pools-we-trust.005.png)[](https://www.linkedin.com/in/olga-hryniuk-1094a3160/ "LinkedIn")
- ![](img/2020-11-17-in-pools-we-trust.006.png)[](https://github.com/olgahryniuk "GitHub")

![Smash: introducing a new way of managing stake pool metadata](img/2020-11-17-in-pools-we-trust.007.jpeg)

Stake pool operations lie at the heart of Cardano decentralization, enabling servers to reach a consensus agreement across the network. Our groundbreaking Ouroboros proof-of-stake consensus protocol allows pool operators to reach agreement on the validity of transactions and sign a block, which is then immutably recorded on the Cardano blockchain.

Các hoạt động của nhóm cổ phần nằm ở trung tâm phân cấp Cardano, cho phép các máy chủ đạt được thỏa thuận đồng thuận trên mạng.
Giao thức đồng thuận chống cổ phần của chúng tôi đột phá cho phép các nhà khai thác nhóm đạt được thỏa thuận về tính hợp lệ của các giao dịch và ký một khối, sau đó được ghi lại bất động trên blockchain Cardano.

On the Shelley path to decentralization, as more stake pools are created, the more the Cardano network grows. Operators form their pools, attract delegation, stake ada, earn rewards and take a small cut to cover their running costs before distributing the rest between the pool participants. 

Trên con đường Shelley để phân cấp, khi nhiều nhóm cổ phần được tạo ra, mạng Cardano càng phát triển.
Các nhà khai thác tạo thành hồ bơi của họ, thu hút phái đoàn, đặt cược ADA, kiếm được phần thưởng và cắt giảm nhỏ để trang trải chi phí chạy của họ trước khi phân phối phần còn lại giữa những người tham gia nhóm.

Node decentralization is a key element. However, to keep track of stake pool information and simplify the choice of a pool for delegators, it is crucial to ensure that information about each stake pool is relevant and valid. And, as far as is possible, that the influence of bad actors, such as potential attackers, spoof pools, and trolls, on the system is minimized. 

Phân cấp nút là một yếu tố chính.
Tuy nhiên, để theo dõi thông tin nhóm cổ phần và đơn giản hóa việc lựa chọn một nhóm cho các ủy viên, điều quan trọng là phải đảm bảo rằng thông tin về mỗi nhóm cổ phần là có liên quan và hợp lệ.
Và, theo như có thể, ảnh hưởng của các tác nhân xấu, chẳng hạn như những kẻ tấn công tiềm năng, nhóm giả mạo và troll, trên hệ thống được giảm thiểu.

## **Welcome to Smash**

## ** Chào mừng bạn đến với Smash **

To address these needs, we have developed Smash â€“ the server that supports operators and ada owners by validating information about stake pools and storing it as metadata. 

Để giải quyết các nhu cầu này, chúng tôi đã phát triển Smash - Máy chủ hỗ trợ các nhà khai thác và chủ sở hữu ADA bằng cách xác nhận thông tin về nhóm cổ phần và lưu trữ nó dưới dạng siêu dữ liệu.

Each stake pool is registered on the blockchain along with the information required to calculate rewards. However, stake pools also include metadata that helps ada owners to make a rational choice when delegating their stake. This metadata includes owner details, pool name, pool ticker, homepage, and a short description, which are not stored on the blockchain, and thus it is important to provide visibility and access to this information. 

Mỗi nhóm cổ phần được đăng ký trên blockchain cùng với thông tin cần thiết để tính toán phần thưởng.
Tuy nhiên, các nhóm cổ phần cũng bao gồm siêu dữ liệu giúp chủ sở hữu ADA đưa ra lựa chọn hợp lý khi ủy thác cổ phần của họ.
Siêu dữ liệu này bao gồm chi tiết chủ sở hữu, tên nhóm, đánh dấu nhóm, trang chủ và mô tả ngắn, không được lưu trữ trên blockchain, và do đó, điều quan trọng là cung cấp khả năng hiển thị và truy cập vào thông tin này.

As well as ensuring that registered stake pools are valid, Smash metadata server helps to avoid duplicated ticker names or trademarks, and ensure that they do not feature content that Cardano users are likely to find offensive. Given that scams, trolls, and abusive behavior are an unfortunate part of life online, we had to find a way of filtering potentially problematic actors out of the playing field.

Cùng với việc đảm bảo rằng các nhóm cổ phần đã đăng ký là hợp lệ, Smash Metadata Server giúp tránh các tên hoặc nhãn hiệu đánh dấu trùng lặp và đảm bảo rằng họ không có nội dung mà người dùng Cardano có thể thấy bị xúc phạm.
Cho rằng lừa đảo, troll và hành vi lạm dụng là một phần đáng tiếc của cuộc sống trực tuyến, chúng tôi phải tìm cách lọc các diễn viên có khả năng ra khỏi sân chơi.

## **What is Smash?**

## ** Smash là gì? **

Smash is a stake pool metadata aggregation server that was conceived to improve Cardano usersâ€™ access to verified stake pool information and make it easier to use the system. A Smash server can aggregate stake pool metadata, fetch it, and store it. 

Smash là một máy chủ tổng hợp siêu dữ liệu của nhóm cổ phần được hình thành để cải thiện quyền truy cập của người dùng Cardano vào thông tin nhóm cổ phần đã được xác minh và giúp sử dụng hệ thống dễ dàng hơn.
Một máy chủ Smash có thể tổng hợp siêu dữ liệu của nhóm cổ phần, lấy nó và lưu trữ nó.

The first generation of Smash has been deployed by IOHK and provides information about delegation in the Daedalus wallet. Previously, this off-chain data was fetched by Daedalus from each stake pool separately, which required a lot of network connections and affected performance. All of this data can now be served from one server, hosted and fetched, initially by our team. 

Thế hệ đầu tiên của Smash đã được IOHK triển khai và cung cấp thông tin về phái đoàn trong ví Daedalus.
Trước đây, dữ liệu ngoài chuỗi này đã được Daedalus tìm nạp riêng biệt, điều này đòi hỏi rất nhiều kết nối mạng và hiệu suất bị ảnh hưởng.
Tất cả dữ liệu này hiện có thể được phục vụ từ một máy chủ, được lưu trữ và tìm nạp, ban đầu bởi nhóm của chúng tôi.

Although the Smash server is currently run by IOHK, it is important to note that the server code is open source and can be deployed by anyone. So we hope that in the future, the Smash approach will be adopted by the community for decentralized metadata. Daedalus will allow users to configure any server of their choice and browse custom stake pool lists â€“ for example, charity pools, bare metal pools, or pools from a certain region for ada holders who would prefer to support stake pool businesses with a particular focus.

Mặc dù máy chủ Smash hiện đang được IOHK điều hành, nhưng điều quan trọng cần lưu ý là mã máy chủ là nguồn mở và có thể được triển khai bởi bất kỳ ai.
Vì vậy, chúng tôi hy vọng rằng trong tương lai, phương pháp Smash sẽ được cộng đồng áp dụng cho siêu dữ liệu phi tập trung.
Daedalus sẽ cho phép người dùng định cấu hình bất kỳ máy chủ nào mà họ chọn và duyệt danh sách nhóm cổ phần tùy chỉnh - ví dụ, các nhóm từ thiện, nhóm kim loại trần hoặc nhóm từ một khu vực nhất định cho những người nắm giữ ADA, những người thích hỗ trợ các doanh nghiệp nhóm cổ phần với một doanh nghiệp cụ thể
tiêu điểm.

## **How does it work?**

## **Làm thế nào nó hoạt động?**

Smash is an evolving system. Currently, as its operator, we are responsible for the maintenance and metadata curation on the IOHK Smash server. Badly behaved stake pools can be delisted from display in Daedalus. Factors taken into account for such decisions include illegal or malicious metadata content, impersonation, the use of ticker names that were previously registered on the Incentivized Testnet (when this is not the same stake pool/operator), intellectual property rights violations, or stake pools that are no longer active. 

Smash là một hệ thống phát triển.
Hiện tại, với tư cách là nhà điều hành của nó, chúng tôi chịu trách nhiệm về việc bảo trì và giám tuyển siêu dữ liệu trên máy chủ IOHK Smash.
Các nhóm cổ phần hành xử tồi tệ có thể bị hủy bỏ khỏi màn hình trong Daedalus.
Các yếu tố được tính đến cho các quyết định như vậy bao gồm nội dung siêu dữ liệu bất hợp pháp hoặc độc hại, mạo danh, sử dụng tên đánh dấu trước đây đã được đăng ký trên Testnet được khuyến khích (khi đây không phải là cùng một nhóm/nhà điều hành cổ phần), vi phạm quyền sở hữu trí tuệ hoặc nhóm cổ phần
không còn hoạt động.

While its most immediate impact can be seen in Daedalus, Smash is a resource to support the community. So if you identify a stake pool ticker that you feel might be causing harm and transgresses the guidelines, we encourage you to review the guidelines we have recently published outlining the [reasons for a stake pool delisting and a step-by-step explanation of the delisting process](https://docs.cardano.org/en/latest/getting-started/stake-pool-operators/SMASH-metadata-management.html). Get in touch if you believe there is a case to be made for removal.

Trong khi tác động ngay lập tức nhất của nó có thể được nhìn thấy ở Daedalus, Smash là một nguồn tài nguyên để hỗ trợ cộng đồng.
Vì vậy, nếu bạn xác định một người đánh dấu nhóm cổ phần mà bạn cảm thấy có thể gây hại và vượt qua các hướng dẫn, chúng tôi khuyến khích bạn xem xét các hướng dẫn mà chúng tôi đã công bố gần đây phác thảo [lý do cho một nhóm cổ phần hủy bỏ và giải thích từng bước về
Quá trình hủy bỏ] (https://docs.cardano.org/en/latest/getting-started/stake-pool-operators/smash-metadata-man quản lý.html).
Hãy liên lạc nếu bạn tin rằng có một trường hợp được thực hiện để loại bỏ.

It is important to ensure that there is a reason for a stake pool to be delisted and that if possible, there is a reasonable level of community consent. Thus, any request should include the rationale and any proof of violations. All requests are reviewed by the Smash operator. It usually takes seven days for a request to be inspected and processed, and we always respond by clarifying the motivation for any decision. Cardano is a decentralized ecosystem and aims not to limit any stake pool operation activity unduly or unfairly. We reserve the right to make the final decision regarding the Smash server we manage, however we aim to provide the community with as much visibility and trust as possible. For more details, please email ***smash@iohk.io*** or contact directly ***@benohanlon*** in Telegram.

Điều quan trọng là phải đảm bảo rằng có một lý do để một nhóm cổ phần bị hủy bỏ và nếu có thể, có một mức độ đồng ý hợp lý của cộng đồng.
Vì vậy, bất kỳ yêu cầu nào cũng nên bao gồm lý do và bất kỳ bằng chứng vi phạm.
Tất cả các yêu cầu được xem xét bởi nhà điều hành Smash.
Thường phải mất bảy ngày để một yêu cầu được kiểm tra và xử lý, và chúng tôi luôn trả lời bằng cách làm rõ động lực cho bất kỳ quyết định nào.
Cardano là một hệ sinh thái phi tập trung và nhằm mục đích không giới hạn bất kỳ hoạt động hoạt động nhóm cổ phần nào quá hoặc không công bằng.
Chúng tôi có quyền đưa ra quyết định cuối cùng liên quan đến máy chủ Smash mà chúng tôi quản lý, tuy nhiên chúng tôi hướng đến việc cung cấp cho cộng đồng càng nhiều khả năng hiển thị và tin tưởng càng tốt.
Để biết thêm chi tiết, xin vui lòng gửi email ***smash@iohk.io*** hoặc liên hệ trực tiếp ***@Benohanlon *** trong Telegram.

