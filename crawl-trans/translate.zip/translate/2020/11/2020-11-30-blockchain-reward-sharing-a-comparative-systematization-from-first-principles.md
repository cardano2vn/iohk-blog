# Blockchain reward sharing - a comparative systematization from first principles
### **Navigating the diverse landscape of reward-sharing schemes and the choices we have made in the design of Cardano’s reward-sharing scheme**
![](img/2020-11-30-blockchain-reward-sharing-a-comparative-systematization-from-first-principles.002.png) 30 November 2020![](img/2020-11-30-blockchain-reward-sharing-a-comparative-systematization-from-first-principles.002.png)[ Prof Aggelos Kiayias](tmp//en/blog/authors/aggelos-kiayias/page-1/)![](img/2020-11-30-blockchain-reward-sharing-a-comparative-systematization-from-first-principles.003.png) 10 mins read

![Prof Aggelos Kiayias](img/2020-11-30-blockchain-reward-sharing-a-comparative-systematization-from-first-principles.004.png)[](tmp//en/blog/authors/aggelos-kiayias/page-1/)
### [**Prof Aggelos Kiayias**](tmp//en/blog/authors/aggelos-kiayias/page-1/)
Chief Scientist

Academic Research

- ![](img/2020-11-30-blockchain-reward-sharing-a-comparative-systematization-from-first-principles.005.png)[](mailto:aggelos.kiayias@iohk.io "Email")
- ![](img/2020-11-30-blockchain-reward-sharing-a-comparative-systematization-from-first-principles.006.png)[](tmp///www.youtube.com/watch?v=nB6eDbnkAk8 "YouTube")

![Blockchain reward sharing - a comparative systematization from first principles](img/2020-11-30-blockchain-reward-sharing-a-comparative-systematization-from-first-principles.007.jpeg)

Your browser does not support the audio element.

Trình duyệt của bạn không hỗ trợ các yếu tố âm thanh.

In the previous article, we identified the [objectives of the reward scheme in Cardano](https://iohk.io/en/blog/posts/2020/11/13/the-general-perspective-on-staking-in-cardano/), and we gave general guidelines regarding engaging with the system.

Trong bài viết trước, chúng tôi đã xác định [mục tiêu của sơ đồ phần thưởng trong Cardano] (https://iohk.io/en/blog/posts/2020/11/13/the-general-perspective-on-staking-in-
Cardano/), và chúng tôi đã đưa ra các hướng dẫn chung về việc tham gia với hệ thống.

Taking a more high-level view, we will examine from first principles, the general problem of reward sharing in blockchain systems. To recall, the two overarching objectives of any *resource-based* consensus system is to incentivize the following.

Có một cái nhìn cấp cao hơn, chúng tôi sẽ kiểm tra từ các nguyên tắc đầu tiên, vấn đề chung về việc chia sẻ phần thưởng trong các hệ thống blockchain.
Để nhớ lại, hai mục tiêu bao quát của bất kỳ hệ thống đồng thuận * dựa trên tài nguyên * nào là khuyến khích những điều sau đây.

**High engagement**. Resource-based consensus protocols are more secure the more resources are engaged with protocol maintenance. The problem, of course, is that the underlying resources are useful for a wide variety of other things too (e.g., electricity and computational power in the case of proof of work, **or stake for engaging in decentralized apps** in the case of proof of stake), so resource holders should be incentivized to commit resources for protocol maintenance.

** Tham gia cao **.
Các giao thức đồng thuận dựa trên tài nguyên an toàn hơn, càng nhiều tài nguyên tham gia vào bảo trì giao thức.
Tất nhiên, vấn đề là các tài nguyên cơ bản cũng hữu ích cho nhiều thứ khác (ví dụ: điện và sức mạnh tính toán trong trường hợp chứng minh công việc, ** hoặc cổ phần để tham gia vào các ứng dụng phi tập trung ** trong trường hợp
bằng chứng về cổ phần), vì vậy chủ sở hữu tài nguyên nên được khuyến khích cam kết các nguồn lực để bảo trì giao thức.

**Low leverage**: leverage relates to decentralization. Take a group of 10 people; if there is a leader and the group follows the leader’s wishes all the time, the leader’s leverage is 10 while everyone else’s is zero. If, on the other hand, everyone’s opinion matters the same, everyone’s leverage is 1. These are two extremes, but it should be fairly obvious what types of leverage align better with decentralization. From an economic viewpoint, however, a “benevolent dictatorship” is always more efficient; as a result, decentralization will come at a cost (exactly as democracy does), and hence it has to be also properly incentivized. 

** đòn bẩy thấp **: đòn bẩy liên quan đến phân cấp.
Lấy một nhóm 10 người;
Nếu có một nhà lãnh đạo và nhóm theo sau mong muốn của người lãnh đạo, thì đòn bẩy của người lãnh đạo là 10 trong khi mọi người khác là không.
Mặt khác, nếu mọi người có ý kiến giống nhau, thì mọi người đều có đòn bẩy là 1. Đây là hai thái cực, nhưng nó khá rõ ràng loại đòn bẩy nào phù hợp hơn với sự phân cấp.
Tuy nhiên, từ quan điểm kinh tế, một chế độ độc tài nhân từ của người Hồi giáo luôn hiệu quả hơn;
Do đó, sự phân cấp sẽ phải trả giá (chính xác như dân chủ), và do đó nó cũng phải được khuyến khích đúng.

Given the above objectives, let us now examine some approaches that have been considered in consensus systems and systematize them in terms of how they address the above objectives. An important first categorization we will introduce is between unimodal and multimodal reward schemes.

Với các mục tiêu trên, bây giờ chúng ta hãy xem xét một số phương pháp đã được xem xét trong các hệ thống đồng thuận và hệ thống hóa chúng theo cách chúng giải quyết các mục tiêu trên.
Một phân loại đầu tiên quan trọng, chúng tôi sẽ giới thiệu là giữa các chương trình phần thưởng không chính thống và đa phương thức.

## **Unimodal**

## ** unimodal **

In a unimodal scheme, there is only one way to engage in the consensus protocol with your resources. We examine two sub-categories of unimodal schemes. 

Trong một sơ đồ đơn phương, chỉ có một cách để tham gia vào giao thức đồng thuận với tài nguyên của bạn.
Chúng tôi kiểm tra hai loại phụ của các sơ đồ đơn phương.

1. **Linear Unimodal**

1. ** unimodal tuyến tính **

This is the simplest approach and is followed by many systems, notably Bitcoin; the original proof-of-work based Ethereum, as well as Algorand. The idea is simple: if an entity commands x% resources, then the system will attempt to provide x% of the rewards – at least in expectation. This might seem fair—until one observes the serious downsides that come with it. 

Đây là cách tiếp cận đơn giản nhất và được theo sau bởi nhiều hệ thống, đáng chú ý là Bitcoin;
Ethereum dựa trên công việc ban đầu, cũng như Algorand.
Ý tưởng rất đơn giản: nếu một thực thể ra lệnh cho tài nguyên X%, thì hệ thống sẽ cố gắng cung cấp x% phần thưởng - ít nhất là theo mong đợi.
Điều này có vẻ công bằng cho đến khi người ta quan sát những nhược điểm nghiêm trọng đi kèm với nó.

First, consider that someone has x% of resources and that x% of the rewards in expectation are below their individual cost to operate as a node. Then, they will either not engage (lowering the engagement rate of the system), or, more likely, actively seek others to combine resources and create a node. Even if there are two resource holders with x% of resources each and a viable individual cost *c* when running as separate nodes, they will fare better by combining resources into a single node of 2x% resources because the resulting cost will be typically less than *2c*. This can result in a strong trend to centralize, and lead to high leverage since the combined pool of resources will be (typically) run by one entity. 

Đầu tiên, hãy xem xét rằng ai đó có x% tài nguyên và x% phần thưởng trong kỳ vọng nằm dưới chi phí cá nhân của họ để hoạt động như một nút.
Sau đó, họ sẽ không tham gia (giảm tỷ lệ tương tác của hệ thống), hoặc, nhiều khả năng, tích cực tìm kiếm người khác để kết hợp tài nguyên và tạo một nút.
Ngay cả khi có hai chủ sở hữu tài nguyên với x% tài nguyên mỗi và chi phí cá nhân khả thi * c * khi chạy dưới dạng các nút riêng biệt, họ sẽ có giá tốt hơn bằng cách kết hợp tài nguyên thành một nút 2x% tài nguyên vì chi phí kết quả sẽ ít hơn
hơn *2c *.
Điều này có thể dẫn đến một xu hướng mạnh mẽ để tập trung và dẫn đến đòn bẩy cao vì nhóm tài nguyên kết hợp sẽ được điều hành bởi một thực thể.

In practice, a single dictatorially operated node is unlikely to emerge. This is due to various reasons such as friction in coordination between parties, fear of the potential drop in the exchange rate of the system’s underlying token if the centralization trend becomes noticeable, as well as the occasional use of complex protocols to jointly run pools. Even so, it is clear that unimodal linear rewards can hurt decentralization. 

Trong thực tế, một nút hoạt động độc tài duy nhất không có khả năng xuất hiện.
Điều này là do nhiều lý do khác nhau như ma sát trong sự phối hợp giữa các bên, sợ giảm tỷ giá hối đoái tiềm năng của hệ thống mã thông báo cơ bản nếu xu hướng tập trung trở nên đáng chú ý, cũng như việc sử dụng các giao thức phức tạp thường xuyên để cùng chạy các nhóm.
Mặc dù vậy, rõ ràng là phần thưởng tuyến tính đơn phương có thể làm tổn thương sự phân cấp.

One does not need to go much further than looking at Bitcoin and its current, fairly centralized, mining pool lineup. It is worth noting that if stake (rather than hashing power) is used as a resource, the centralization pressure will be less – since the expenditure to operate a node is smaller. But the same problems apply in principle. 

Người ta không cần phải đi xa hơn nhiều so với việc nhìn vào Bitcoin và dòng sản phẩm khai thác hiện tại, khá tập trung của nó.
Điều đáng chú ý là nếu cổ phần (thay vì công suất băm) được sử dụng làm tài nguyên, áp lực tập trung sẽ ít hơn - vì chi tiêu để vận hành một nút nhỏ hơn.
Nhưng các vấn đề tương tự áp dụng về nguyên tắc.

An additional disadvantage of the above setting is that the ensuing “off-chain” resource pooling that occurs will be completely opaque from the ledger perspective, and hence more difficult for the community to monitor and react to. In summary, the linear unimodal approach has the advantage of being simple, but is precarious, both in terms of increasing engagement and for keeping leverage low. 

Một nhược điểm bổ sung của cài đặt trên là việc gộp tài nguyên ngoài chuỗi trực tuyến tiếp theo xảy ra sẽ hoàn toàn mờ đục từ góc độ sổ cái, và do đó cộng đồng khó theo dõi và phản ứng.
Tóm lại, cách tiếp cận đơn phương tuyến tính có lợi thế là đơn giản, nhưng bấp bênh, cả về việc tăng sự tham gia và để giữ đòn bẩy thấp.

2. **Quantized Linear Unimodal**

2. ** unimodal tuyến tính số lượng **

This approach is the same as the linear rewards approach, but it quantizes the underlying resource. I.e., if your resources are below a certain threshold, you may be completely unable to participate; you can only participate in fixed quanta. Notably, this approach is taken in [ETH2.0, where 32 Ether](https://blog.ethereum.org/2019/11/27/validated-staking-on-eth2-0/) should be pledged in order to acquire a validator identity. It should be clear that this quantized approach shares the same problems with the linear unimodal approach in terms of participation and leverage. Despite this, it has been considered for two primary reasons. First, using the quantized approach enables one to retrofit traditional BFT-style protocol design elements (e.g. that require counting identities) in a resource-based consensus setting. The resulting system is less elegant than true resource-based consensus but this is unavoidable since traditional BFT-style protocols do not work very well when there are more than a few hundred nodes involved. The second reason, specific to the proof-of-stake setting, is seeking to impose penalties on participants as a means of ensuring compliance with the protocol. Imposing quantized collateral pledges makes penalties for protocol infractions more substantial and painful.

Cách tiếp cận này giống như cách tiếp cận phần thưởng tuyến tính, nhưng nó định lượng tài nguyên cơ bản. Tức là, nếu tài nguyên của bạn dưới một ngưỡng nhất định, bạn có thể hoàn toàn không thể tham gia; Bạn chỉ có thể tham gia vào lượng tử cố định. Đáng chú ý, cách tiếp cận này được thực hiện trong [eth2.0, trong đó 32 ether] (https://blog.ethereum.org/2019/11/27/validated-staking-on-eth2-0/) có được một danh tính xác thực. Cần phải rõ ràng rằng phương pháp lượng tử hóa này chia sẻ các vấn đề tương tự với cách tiếp cận đơn phương tuyến tính về sự tham gia và đòn bẩy. Mặc dù vậy, nó đã được xem xét vì hai lý do chính. Đầu tiên, sử dụng phương pháp lượng tử hóa cho phép người ta trang bị thêm các yếu tố thiết kế giao thức kiểu BFT truyền thống (ví dụ: yêu cầu tính danh tính) trong cài đặt đồng thuận dựa trên tài nguyên. Hệ thống kết quả ít thanh lịch hơn so với sự đồng thuận dựa trên tài nguyên thực sự nhưng điều này là không thể tránh khỏi vì các giao thức kiểu BFT truyền thống không hoạt động tốt khi có hơn vài trăm nút liên quan. Lý do thứ hai, cụ thể cho cài đặt bằng chứng cổ phần, đang tìm cách áp dụng hình phạt đối với người tham gia như một phương tiện để đảm bảo tuân thủ giao thức. Áp đặt các cam kết tài sản thế chấp lượng tử làm cho hình phạt cho các vi phạm giao thức đáng kể và đau đớn hơn.

## **Multimodal**

## ** Đa phương thức **

We next turn to multimodal schemes. This broad category includes Cosmos, Tezos, Polkadot & EOS. It also includes Cardano. In a multimodal scheme, a resource holder may take different roles in the protocol; being a fully active node in the consensus protocol is just one of the options. The advantage of a multimodal scheme is that offering multiple ways to engage (with correspondingly different rates of return) within the protocol itself can accommodate a higher engagement, as well as limit off-chain resource pooling. For instance, if the potential rewards received by an individual when they engage with all their resources sit below their operational cost of running a node, they can still choose to engage by a different mode in the protocol. In this way, the tendency to combine resources off-chain is eased and the system – if designed properly – may translate this higher engagement to increased resilience. 

Chúng tôi tiếp theo chuyển sang các chương trình đa phương thức.
Danh mục rộng này bao gồm Cosmos, Tezos, Polkadot & EOS.
Nó cũng bao gồm Cardano.
Trong sơ đồ đa phương thức, người giữ tài nguyên có thể đảm nhận các vai trò khác nhau trong giao thức;
Trở thành một nút hoạt động hoàn toàn trong giao thức đồng thuận chỉ là một trong những tùy chọn.
Ưu điểm của sơ đồ đa phương thức là việc cung cấp nhiều cách để tham gia (với tỷ lệ hoàn vốn tương ứng) trong chính giao thức có thể phù hợp với sự tham gia cao hơn, cũng như giới hạn gộp tài nguyên ngoài chuỗi.
Chẳng hạn, nếu phần thưởng tiềm năng nhận được bởi một cá nhân khi họ tham gia với tất cả các tài nguyên của họ nằm dưới chi phí hoạt động của họ để chạy một nút, họ vẫn có thể chọn tham gia bởi một chế độ khác trong giao thức.
Theo cách này, xu hướng kết hợp các tài nguyên ngoài chuỗi được nới lỏng và hệ thống-nếu được thiết kế đúng cách-có thể chuyển sự tham gia cao hơn này để tăng khả năng phục hồi.

We will distinguish between a number of different multimodal schemes.

Chúng tôi sẽ phân biệt giữa một số sơ đồ đa phương thức khác nhau.

- **Representative bimodal without leverage control.** The representative approach is inspired by [representative democracy](https://en.wikipedia.org/wiki/Representative_democracy): the system is run by a number of elected operators. The approach is bimodal as it enables parties to (1) advertise themselves as operators in the ledger and/or (2) “vote” for operators with their resources. The set of representative operators has a fixed size and is updated on a rolling basis typically with fixed terms using some election function that selects representatives based on the votes they received. Rewards are distributed evenly between representatives, possibly taking into account performance data and adjusting accordingly. Allowing rewards to flow to voters using a smart contract can incentivize higher engagement in voting since resource holders get paid for voting for good representatives (note that this is not necessarily followed by all schemes in this category). The disadvantage of this approach is the lack of leverage control, beyond, possibly, the existence of a very large upper bound, which suggests that the system may end up with a set of very highly leveraged operators. This is the approach that is broadly followed by Cosmos, EOS, and Polkadot.

- ** Bimodal đại diện không có quyền kiểm soát đòn bẩy. ** Cách tiếp cận đại diện được lấy cảm hứng từ [Dân chủ đại diện] (https://en.wikipedia.org/wiki/Representative_Democracy): Hệ thống được điều hành bởi một số nhà khai thác được bầu. Cách tiếp cận là lưỡng kim vì nó cho phép các bên (1) tự quảng cáo là người vận hành trong sổ cái và/hoặc (2) phiếu bầu cho các nhà khai thác với tài nguyên của họ. Tập hợp các toán tử đại diện có kích thước cố định và được cập nhật trên cơ sở cuộn thường với các thuật ngữ cố định bằng cách sử dụng một số chức năng bầu cử chọn các đại diện dựa trên phiếu bầu mà họ nhận được. Phần thưởng được phân phối đều giữa các đại diện, có thể có tính đến dữ liệu hiệu suất và điều chỉnh cho phù hợp. Cho phép phần thưởng cho cử tri sử dụng hợp đồng thông minh có thể khuyến khích sự tham gia cao hơn vào việc bỏ phiếu vì những người nắm giữ tài nguyên được trả tiền cho việc bỏ phiếu cho các đại diện tốt (lưu ý rằng điều này không nhất thiết phải theo tất cả các chương trình trong danh mục này). Nhược điểm của phương pháp này là thiếu kiểm soát đòn bẩy, ngoài ra, có thể, sự tồn tại của một giới hạn trên rất lớn, điều này cho thấy hệ thống có thể kết thúc với một tập hợp các toán tử có đòn bẩy rất cao. Đây là cách tiếp cận được theo sau bởi Cosmos, EOS và Polkadot.

A different approach to the representative approach is the *delegative* approach. In general, this approach is closer to direct democracy as it allows resource holders the option to engage directly with the protocol with the resources they have. However, they are free to also delegate their resources to others as in [liquid (or delegative) democracy](https://en.wikipedia.org/wiki/Liquid_democracy) (where the term delegative is derived from). This results in a community-selected operator configuration that does not have a predetermined number of representatives. As in the representative approach, user engagement is bimodal. Resource holders can advertise themselves as operators and/or delegate their resources to existing operators. The rewards provided are proportional to the amount of delegated resources and delegates can be paid via an on-chain smart contract, perhaps at various different rates. Within the delegative approach we will further distinguish two subcategories.

Một cách tiếp cận khác với phương pháp đại diện là cách tiếp cận * ủy quyền *.
Nhìn chung, cách tiếp cận này gần với nền dân chủ trực tiếp hơn vì nó cho phép chủ tài nguyên tùy chọn tham gia trực tiếp với giao thức với các tài nguyên họ có.
Tuy nhiên, họ có thể tự do ủy thác tài nguyên của họ cho người khác như trong nền dân chủ [chất lỏng (hoặc đại biểu)] (https://en.wikipedia.org/wiki/liquid_democracy) (nơi có thuật ngữ ủy quyền bắt nguồn từ).
Điều này dẫn đến một cấu hình toán tử do cộng đồng lựa chọn không có số lượng đại diện được xác định trước.
Như trong cách tiếp cận đại diện, sự tham gia của người dùng là lưỡng kim.
Chủ sở hữu tài nguyên có thể tự quảng cáo là nhà khai thác và/hoặc ủy thác tài nguyên của họ cho các nhà khai thác hiện có.
Các phần thưởng được cung cấp tỷ lệ thuận với số lượng tài nguyên được ủy quyền và các đại biểu có thể được thanh toán thông qua một hợp đồng thông minh trên chuỗi, có lẽ ở nhiều mức giá khác nhau.
Trong cách tiếp cận đại biểu, chúng tôi sẽ phân biệt thêm hai danh mục con.

- **Delegative bimodal with pledge-based capped rewards.** What typifies this particular delegative approach is that the resource pool’s rewards have a bound that is determined by the amount of pledge that is committed to the pool by its operator. In this way, the total leverage of an operator can be controlled and fixed to a constant. Unfortunately, this leverage control feature has the negative side effect of implicitly imposing the same bound to all, small and large resource holders. So, on the one hand, in a population of small resource holders, engagement will be constrained by the little pledge that operators are able to commit. On the other hand, a few large whale resource holders may end up influencing the consensus protocol in a very significant manner, possibly even beyond its security threshold bound. In terms of leverage control, it should be clear that one size does not fit all! From existing systems, this is the approach that is (in essence) followed by Tezos. 

- ** Bimodal ủy quyền với phần thưởng giới hạn dựa trên cam kết.
Theo cách này, tổng đòn bẩy của người vận hành có thể được kiểm soát và cố định thành một hằng số.
Thật không may, tính năng kiểm soát đòn bẩy này có tác dụng phụ tiêu cực của việc áp đặt ngầm cùng ràng buộc với tất cả, những người nắm giữ tài nguyên nhỏ và lớn.
Vì vậy, một mặt, trong một nhóm người nắm giữ tài nguyên nhỏ, sự tham gia sẽ bị hạn chế bởi những cam kết nhỏ mà các nhà khai thác có thể cam kết.
Mặt khác, một vài người nắm giữ tài nguyên cá voi lớn có thể cuối cùng ảnh hưởng đến giao thức đồng thuận theo một cách rất quan trọng, thậm chí có thể vượt quá ngưỡng bảo mật của nó.
Về mặt kiểm soát đòn bẩy, rõ ràng là một kích thước không phù hợp với tất cả!
Từ các hệ thống hiện tại, đây là cách tiếp cận (về bản chất) theo sau là Tezos.

It is worth noting that all the specific approaches we have seen so far come with downsides – either in terms of maximizing engagement, controlling leverage, or both. With this in mind, let us now fit into our systematization, the approach of the reward-sharing scheme that we are using in Cardano. 

Điều đáng chú ý là tất cả các phương pháp cụ thể mà chúng ta đã thấy cho đến nay đi kèm với những nhược điểm - về mặt tối đa hóa sự tham gia, kiểm soát đòn bẩy hoặc cả hai.
Với suy nghĩ này, bây giờ chúng ta hãy phù hợp với hệ thống hóa của chúng ta, cách tiếp cận của chương trình chia sẻ phần thưởng mà chúng ta đang sử dụng trong Cardano.

- **Delegative bimodal with capped rewards and incentivized pledging.** In this delegative system (introduced in our [reward-sharing scheme](https://arxiv.org/abs/1807.11218) paper), the rewards that are provided to each pool follow a piecewise function on the pool’s size. The function is initially monotonically increasing and then becomes constant at a certain “cap” level which is a configurable system parameter (in Cardano this is determined by the parameter *k*). This cap limits the incentives to grow individual resource pools. At the same time, pledging resources to a pool is *incentivized* with higher pledged pools receiving more rewards. As a result, lowering one’s leverage becomes incentive-driven: resource pools have bounded size and operators have an incentive to pledge all the resources they can afford into the smallest number of pools possible. In particular, whale resource holders are incentivized to keep their leverage low. The benefit of the approach is that high engagement is reinforced, while leverage is kept in control by incentivizing the community to (i) pledge as much as possible, (ii) use all the remaining unpledged resources as part of a crowdsourced filtering mechanism. This translates stake to voting power and supports exactly those operators that materially contribute to the system’s goals the most.

- ** Bimodal đại biểu với phần thưởng giới hạn và cam kết khuyến khích. Mỗi nhóm tuân theo một chức năng piecewise trên kích thước của nhóm. Hàm ban đầu đang tăng một cách đơn điệu và sau đó trở thành hằng số ở một cấp độ nhất định của Cap Cap, đó là một tham số hệ thống có thể định cấu hình (trong Cardano, điều này được xác định bởi tham số *k *). CAP này giới hạn các ưu đãi để phát triển các nhóm tài nguyên riêng lẻ. Đồng thời, các tài nguyên cam kết vào một nhóm được * khuyến khích * với các nhóm cam kết cao hơn nhận được nhiều phần thưởng hơn. Do đó, việc hạ thấp một đòn bẩy của một người trở thành động lực khuyến khích: Nhóm tài nguyên có kích thước giới hạn và các nhà khai thác có động lực để cam kết tất cả các tài nguyên mà họ có thể đủ khả năng vào số lượng nhỏ nhất có thể. Cụ thể, những người nắm giữ tài nguyên cá voi được khuyến khích để giữ cho đòn bẩy của họ thấp. Lợi ích của phương pháp này là sự tham gia cao được củng cố, trong khi đòn bẩy được kiểm soát bằng cách khuyến khích cộng đồng (i) cam kết càng nhiều càng tốt, (ii) sử dụng tất cả các tài nguyên chưa được giải thích còn lại như một phần của cơ chế lọc đám đông. Điều này chuyển cổ phần của quyền bầu cử và hỗ trợ chính xác những nhà khai thác đóng góp vật chất cho các mục tiêu của hệ thống nhiều nhất.

The above systematization puts into perspective the choices that we have made in the design of the reward-sharing scheme used in Cardano vis-a-vis other systems. In summary, what the Cardano reward system achieves is to materially promote with incentives and community stake-based voting the best possible outcome: *low leverage and high engagement*. And this is accomplished, while still allowing for a very high degree of heterogeneity in terms of input behavior from the stakeholders.

Hệ thống hóa ở trên đưa vào quan điểm các lựa chọn mà chúng tôi đã thực hiện trong việc thiết kế sơ đồ chia sẻ phần thưởng được sử dụng trong các hệ thống khác của Cardano Vis-A-Vis.
Tóm lại, những gì hệ thống phần thưởng Cardano đạt được là thúc đẩy nghiêm trọng với các ưu đãi và bỏ phiếu dựa trên cổ phần cộng đồng Kết quả tốt nhất có thể: *đòn bẩy thấp và sự tham gia cao *.
Và điều này được thực hiện, trong khi vẫn cho phép một mức độ không đồng nhất rất cao về hành vi đầu vào từ các bên liên quan.

As a final point, it is important to stress that while considerable progress has been made since the introduction of the Bitcoin blockchain, research in reward sharing for collaborative projects is still an extremely active and growing domain. Our team continuously evaluates various aspects of reward-sharing schemes and actively explores the whole design space in a first-principles manner. In this way, we can ensure that any research advances will be disseminated widely for the benefit of the whole community.

Như một điểm cuối cùng, điều quan trọng là nhấn mạnh rằng trong khi những tiến bộ đáng kể đã được thực hiện kể từ khi giới thiệu blockchain bitcoin, nghiên cứu về việc chia sẻ phần thưởng cho các dự án hợp tác vẫn là một lĩnh vực cực kỳ tích cực và đang phát triển.
Nhóm của chúng tôi liên tục đánh giá các khía cạnh khác nhau của các chương trình chia sẻ phần thưởng và tích cực khám phá toàn bộ không gian thiết kế theo cách thức đầu tiên.
Theo cách này, chúng tôi có thể đảm bảo rằng bất kỳ tiến bộ nghiên cứu nào sẽ được phổ biến rộng rãi vì lợi ích của cả cộng đồng.

*I am grateful to Christian Badertscher, Sandro Coretti-Drayton, Matthias Fitzi, and Peter Gaži, for their help in the review of other systems and their placement in the systematization of this article.*

*Tôi biết ơn Christian Badertscher, Sandro Coretti-Drayton, Matthias Fitzi và Peter Gaži, vì sự giúp đỡ của họ trong việc xem xét các hệ thống khác và vị trí của họ trong việc hệ thống hóa bài viết này.*

