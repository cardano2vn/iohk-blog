# Getting to grips with metadata on Cardano
### **Adding information about transactions is a powerful tool for companies and developers**
![](img/2020-11-03-getting-to-grips-with-metadata-on-cardano.002.png) 3 November 2020![](img/2020-11-03-getting-to-grips-with-metadata-on-cardano.002.png)[ Alan McSherry](tmp//en/blog/authors/alan-mcsherry/page-1/)![](img/2020-11-03-getting-to-grips-with-metadata-on-cardano.003.png) 5 mins read

![Alan McSherry](img/2020-11-03-getting-to-grips-with-metadata-on-cardano.004.png)[](tmp//en/blog/authors/alan-mcsherry/page-1/)
### [**Alan McSherry**](tmp//en/blog/authors/alan-mcsherry/page-1/)
Solutions Architect

Engineering

- ![](img/2020-11-03-getting-to-grips-with-metadata-on-cardano.005.png)[](https://www.linkedin.com/in/alanmcsherry/ "LinkedIn")
- ![](img/2020-11-03-getting-to-grips-with-metadata-on-cardano.006.png)[](https://github.com/mcsherrylabs "GitHub")

![Getting to grips with metadata on Cardano ](img/2020-11-03-getting-to-grips-with-metadata-on-cardano.007.jpeg)

In a previous post, [Bringing new value and utility to the Cardano blockchain](https://iohk.io/en/blog/posts/2020/10/29/bringing-new-value-and-utility-to-the-cardano-blockchain/), I discussed the notion of transaction metadata. I also explained why this is crucial to Cardanoâ€™s Goguen evolution as a utility platform for decentralized finance (DeFi) operations.

Trong một bài viết trước, [mang lại giá trị và tiện ích mới cho blockchain cardano] (https://iohk.io/en/blog/posts/2020/10/29/bringing-new-value-and-tility-to-the
-Cardano-blockchain/), tôi đã thảo luận về khái niệm siêu dữ liệu giao dịch.
Tôi cũng đã giải thích lý do tại sao điều này rất quan trọng đối với sự tiến hóa của Goguen của Cardano như một nền tảng tiện ích cho các hoạt động tài chính phi tập trung (DEFI).

There are many potential uses for metadata. With that in mind, IOHK has been working to ensure that both developers and enterprise-focused clients can easily build metadata into their applications. Furthermore, we want to make certain that ada users have a convenient way to see information about their transactions.

Có nhiều cách sử dụng tiềm năng cho siêu dữ liệu.
Với ý nghĩ đó, IOHK đã làm việc để đảm bảo rằng cả nhà phát triển và khách hàng tập trung vào doanh nghiệp có thể dễ dàng xây dựng siêu dữ liệu vào các ứng dụng của họ.
Hơn nữa, chúng tôi muốn chắc chắn rằng người dùng ADA có một cách thuận tiện để xem thông tin về các giao dịch của họ.

## **How does metadata work on Cardano?**

## ** Siêu dữ liệu hoạt động như thế nào trên Cardano? **

Metadata tells the story of a transaction and there are many ways to interact with this story. Developers can take advantage of metadata by embedding details directly into a transaction, and ada users can search for specific information in the Cardano Explorer. The data can be added directly, or, for larger amounts, it is possible to create a Merkle tree of the data and put the root hash of the Merkle tree on the blockchain. Once this is done, it can be proved that the data existed at a specific point of time and that it remains permanently on the chain for future reference. 

Siêu dữ liệu kể câu chuyện về một giao dịch và có nhiều cách để tương tác với câu chuyện này.
Các nhà phát triển có thể tận dụng siêu dữ liệu bằng cách nhúng chi tiết trực tiếp vào giao dịch và người dùng ADA có thể tìm kiếm thông tin cụ thể trong Cardano Explorer.
Dữ liệu có thể được thêm trực tiếp, hoặc, với số lượng lớn hơn, có thể tạo một cây Merkle của dữ liệu và đặt băm rễ của cây Merkle trên blockchain.
Một khi điều này được thực hiện, có thể chứng minh rằng dữ liệu tồn tại tại một thời điểm cụ thể và nó vẫn còn vĩnh viễn trên chuỗi để tham khảo trong tương lai.

It is also important to note that transaction metadata is stored on the blockchain and is carried along with each transaction. The fact that it is stored on-chain, rather than being recorded in the ledger state, is beneficial because it does not influence transaction validation or compromise ledger performance.

Cũng cần lưu ý rằng siêu dữ liệu giao dịch được lưu trữ trên blockchain và được thực hiện cùng với mỗi giao dịch.
Thực tế là nó được lưu trữ trên chuỗi, thay vì được ghi lại ở trạng thái sổ cái, có lợi vì nó không ảnh hưởng đến xác thực giao dịch hoặc thỏa hiệp hiệu suất sổ cái.

**Metadata service from IOHK**

** Dịch vụ siêu dữ liệu từ iohk **

IOHKâ€™s Professional Services Group (PSG) provides business consulting and technological services. In particular, our PSG is developing services to help companies build and implement blockchain solutions by integrating their systems in a seamless and convenient way with distributed ledger technology.

Nhóm dịch vụ chuyên nghiệp (PSG) của IOHK cung cấp dịch vụ tư vấn và công nghệ kinh doanh.
Cụ thể, PSG của chúng tôi đang phát triển các dịch vụ để giúp các công ty xây dựng và triển khai các giải pháp blockchain bằng cách tích hợp các hệ thống của họ một cách liền mạch và thuận tiện với công nghệ sổ cái phân tán.

The metadata service has been developed with a variety of applications in mind, but for commercial applications in particular.

Dịch vụ siêu dữ liệu đã được phát triển với nhiều ứng dụng khác nhau, nhưng đặc biệt đối với các ứng dụng thương mại.

This interface handles the wallet interaction, provides users with low balance alarms, and rolls it all up into a Docker container. This eliminates the complexity associated with submitting metadata directly in the walletâ€™s backend API. Thus, the metadata service only requires the specified metadata and the number of blocks under which the transaction should be stored before it is considered as final. 

Giao diện này xử lý tương tác ví, cung cấp cho người dùng báo động cân bằng thấp và cuộn tất cả vào thùng chứa Docker.
Điều này giúp loại bỏ sự phức tạp liên quan đến việc gửi siêu dữ liệu trực tiếp trong API phụ trợ của ví.
Do đó, dịch vụ siêu dữ liệu chỉ yêu cầu siêu dữ liệu được chỉ định và số lượng khối theo đó giao dịch nên được lưu trữ trước khi nó được coi là cuối cùng.

In the metadata request, one can include: 

Trong yêu cầu siêu dữ liệu, người ta có thể bao gồm:

- **The actual metadata**: sender and receiver identities, comments, tags.

- ** Siêu dữ liệu thực tế **: Danh tính người gửi và người nhận, nhận xét, thẻ.

- **The depth**: the number of blocks under which the transaction containing the metadata should be stored before it is considered as final.

- ** Độ sâu **: Số lượng khối theo đó giao dịch chứa siêu dữ liệu nên được lưu trữ trước khi nó được coi là cuối cùng.

- **The client identity**: indicates the wallet to be used.

- ** Danh tính khách hàng **: Cho biết ví được sử dụng.

- **Transaction identity**: this feature is useful in case of failures and restarts. It allows clients to re-examine previously submitted metadata.

- ** Nhận dạng giao dịch **: Tính năng này hữu ích trong trường hợp lỗi và khởi động lại.
Nó cho phép khách hàng kiểm tra lại siêu dữ liệu đã gửi trước đó.

After including all the details, the metadata service records a transaction on the blockchain, which then allows transaction information to be retrieved using the Cardano Explorer. For this, one would just have to indicate a transaction identity. 

Sau khi bao gồm tất cả các chi tiết, dịch vụ siêu dữ liệu ghi lại một giao dịch trên blockchain, sau đó cho phép lấy thông tin giao dịch được truy xuất bằng Cardano Explorer.
Đối với điều này, người ta sẽ phải chỉ ra một danh tính giao dịch.

Another feature is that PSG metadata service can be specified using language-neutral protocol buffers. This expands the number of potential uses because client generators support many programming languages, including Python, Java, and Scala. Such extended opportunities make the process of integration with the Cardano blockchain more straightforward.

Một tính năng khác là dịch vụ siêu dữ liệu PSG có thể được chỉ định bằng cách sử dụng bộ đệm giao thức trung tính ngôn ngữ.
Điều này mở rộng số lượng sử dụng tiềm năng vì các trình tạo khách hàng hỗ trợ nhiều ngôn ngữ lập trình, bao gồm Python, Java và Scala.
Những cơ hội mở rộng như vậy làm cho quá trình tích hợp với blockchain cardano đơn giản hơn.

**Accessibility is key**

** Khả năng truy cập là chìa khóa **

We have also developed a Scala and Java client for the Cardano wallet API, which bundles together calls to the API and makes them easily accessible to more developers. As well as a Java and Scala API, we can provide an executable jar file to give rudimentary access from the command line. You can find details of the [PSG Cardano wallet API on GitHub](https://github.com/input-output-hk/psg-cardano-wallet-api) and see how it allows clients to perform tasks such as submitting and listing a transaction, wallet maintenance, and node monitoring.

Chúng tôi cũng đã phát triển một máy khách scala và java cho API ví Cardano, kết hợp các cuộc gọi với API và khiến chúng dễ dàng truy cập nhiều nhà phát triển hơn.
Cũng như API Java và Scala, chúng tôi có thể cung cấp một tệp JAR có thể thực thi để cung cấp quyền truy cập thô sơ từ dòng lệnh.
Bạn có thể tìm thấy chi tiết về API [PSG Cardano Wallet trên GitHub] (https://github.com/input-output-hk/psg-cardano-wallet-api) và xem cách nó cho phép khách hàng thực hiện các nhiệm vụ như gửi và
Liệt kê một giao dịch, bảo trì ví và giám sát nút.

**Working with wallets and Cardano-CLI**

** Làm việc với ví và Cardano-cli **

Another way of working with metadata is by submitting it directly from a wallet or the Cardano command-line interface (CLI). 

Một cách khác để làm việc với siêu dữ liệu là bằng cách gửi trực tiếp từ ví hoặc giao diện dòng lệnh Cardano (CLI).

These processes require basic coding experience and familiarity with running the Cardano node and CLI. Direct interaction with metadata opens powerful capabilities for building decentralized applications on Cardano because developers can authenticate valuable data in their preferred way. 

Các quy trình này đòi hỏi trải nghiệm mã hóa cơ bản và sự quen thuộc với việc chạy nút Cardano và CLI.
Tương tác trực tiếp với siêu dữ liệu mở ra các khả năng mạnh mẽ để xây dựng các ứng dụng phi tập trung trên Cardano vì các nhà phát triển có thể xác thực dữ liệu có giá trị theo cách ưa thích của họ.

In the Cardano wallet and the CLI, the structure of the metadata is defined by a mapping from keys to values (key-value pairs) that combine details for multiple purposes into the same transaction.

Trong ví Cardano và CLI, cấu trúc của siêu dữ liệu được xác định bằng ánh xạ từ các phím đến các giá trị (cặp giá trị khóa) kết hợp chi tiết cho nhiều mục đích vào cùng một giao dịch.

- *Metadata keys* act as a schema identifier showing the metadata value. Keys are unsigned integers limited in size up to 64 bits. 

- * Khóa siêu dữ liệu * hoạt động như một định danh lược đồ hiển thị giá trị siêu dữ liệu.
Chìa khóa là số nguyên không dấu giới hạn kích thước lên tới 64 bit.

- *Metadata values* are simple terms, consisting of integers, text strings, byte strings, lists, and maps. Values have to be structured, which makes it easier for them to be inspected and managed, particularly by scripts.

- * Giá trị siêu dữ liệu * là các thuật ngữ đơn giản, bao gồm số nguyên, chuỗi văn bản, chuỗi byte, danh sách và bản đồ.
Các giá trị phải được cấu trúc, giúp chúng được kiểm tra và quản lý dễ dàng hơn, đặc biệt là bằng các tập lệnh.

The only extra cost involved is that the metadata adds to the size, in bytes, of the transaction and the processing fee is based on transaction size.

Chi phí bổ sung duy nhất liên quan là siêu dữ liệu thêm vào kích thước, tính theo byte, của giao dịch và phí xử lý dựa trên quy mô giao dịch.

Metadata can be constructed using the Concise Binary Object Representation ([CBOR](https://tools.ietf.org/html/rfc7049)) and Concise Data Definition Language ([CDDL](https://tools.ietf.org/html/rfc8610)) notations. For more detailed information, please refer to [transaction metadata in the Cardano wallet](https://github.com/input-output-hk/cardano-wallet/wiki/TxMetadata) and see how to use [transaction metadata schemes in Cardano CLI](https://github.com/input-output-hk/cardano-node/blob/master/doc/reference/tx-metadata.md).

Siêu dữ liệu có thể được xây dựng bằng cách sử dụng biểu diễn đối tượng nhị phân ngắn gọn ([CBOR] (https://tools.ietf.org/html/rfc7049)) và ngôn ngữ định nghĩa dữ liệu ngắn gọn ([CDDL] (https://tools.ietf.org/
HTML/RFC8610)) ký hiệu.
Để biết thêm thông tin chi tiết, vui lòng tham khảo [Siêu dữ liệu giao dịch trong ví Cardano] (https://github.com/input-output
CLI] (https://github.com/input-output-hk/cardano-node/blob/master/doc/reference/tx-metadata.md).

*Transaction metadata is an integral step for Cardanoâ€™s evolution into a multi-functional smart contract platform. Further Goguen enhancements will add metadata to specify transaction conditions for smart contracts, opening more opportunities for commercial use and deal settlement. If you want to integrate metadata into your business processes, contact **enterprise.solutions@iohk.io** with any questions or support requests. And keep following this blog for updates as we continue to build out Goguen functionality.*

*Siêu dữ liệu giao dịch là một bước tích hợp để phát triển của Cardano thành một nền tảng hợp đồng thông minh đa chức năng.
Các cải tiến hơn nữa của Goguen sẽ thêm siêu dữ liệu để chỉ định các điều kiện giao dịch cho các hợp đồng thông minh, mở ra nhiều cơ hội hơn cho việc sử dụng thương mại và giải quyết giao dịch.
Nếu bạn muốn tích hợp siêu dữ liệu vào các quy trình kinh doanh của mình, hãy liên hệ với **Enterprise.solutions@iohk.io** với bất kỳ câu hỏi hoặc yêu cầu hỗ trợ nào.
Và tiếp tục theo dõi blog này để cập nhật khi chúng tôi tiếp tục xây dựng chức năng Goguen.*

