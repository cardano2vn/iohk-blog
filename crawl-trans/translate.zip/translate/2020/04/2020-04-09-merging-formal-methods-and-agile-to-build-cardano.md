# Merging formal methods and agile development to build Cardano
### **IOHK formal methods director Philipp Kant lays out our methodology for building software with flexibility and precision**
![](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.002.png) 9 April 2020![](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.002.png)[ Philipp Kant](tmp//en/blog/authors/philipp-kant/page-1/)![](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.003.png) 7 mins read

![Philipp Kant](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.004.png)[](tmp//en/blog/authors/philipp-kant/page-1/)
### [**Philipp Kant**](tmp//en/blog/authors/philipp-kant/page-1/)
Formal Methods Director

Engineering

- ![](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.005.png)[](https://www.linkedin.com/in/dr-philipp-kant-4972b1a3 "LinkedIn")
- ![](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.006.png)[](https://twitter.com/philipp_kant "Twitter")
- ![](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.007.png)[](https://github.com/kantp "GitHub")

![Merging formal methods and agile development to build Cardano](img/2020-04-09-merging-formal-methods-and-agile-to-build-cardano.008.jpeg)

**Form and function**

**Hình thức và chức năng**

IOHK is building Cardano into a global financial and social operating system. This enormous task requires both quick iteration and absolute precision. It is why IOHK has chosen to combine the speed of agile development with high assurance code and formal methods. Fusing flexibility and formality led our engineers to pioneer this modern development philosophy.

IOHK đang xây dựng Cardano thành một hệ điều hành xã hội và tài chính toàn cầu.
Nhiệm vụ khổng lồ này đòi hỏi cả lần lặp nhanh và độ chính xác tuyệt đối.
Đó là lý do tại sao IOHK đã chọn kết hợp tốc độ phát triển nhanh với mã đảm bảo cao và các phương pháp chính thức.
Hợp nhất tính linh hoạt và hình thức đã khiến các kỹ sư của chúng tôi tiên phong trong triết lý phát triển hiện đại này.

IOHK believes firmly in research, formal methods, functional programming, and building in a rigorous manner. As a competitor in the blockchain development industry, we also have to consistently demonstrate progress and create value for our global community of stakeholders. This means we canâ€™t compromise on robustness or on development speed and flexibility. In an ever-changing marketplace this is a challenge, so our developers have to strike a balance.

IOHK tin tưởng vững chắc vào nghiên cứu, phương pháp chính thức, lập trình chức năng và xây dựng một cách nghiêm ngặt.
Là một đối thủ cạnh tranh trong ngành phát triển blockchain, chúng tôi cũng phải thể hiện sự tiến bộ và tạo ra giá trị cho cộng đồng các bên liên quan toàn cầu của chúng tôi.
Điều này có nghĩa là chúng ta không thể thỏa hiệp về sự mạnh mẽ hoặc tốc độ phát triển và tính linh hoạt.
Trong một thị trường luôn thay đổi, đây là một thách thức, vì vậy các nhà phát triển của chúng tôi phải đạt được sự cân bằng.

**Agility versus formality**

** Agility so với hình thức **

The start-up standard for developing technology has been to build a minimum viable product quickly and then continually iterate until it is ready for the mass market. This is known as an agile process. It is a great way of showing that a project is advancing while eventually building a fully functional product. However, an agile methodology assumes there will be bugs and weaknesses in each step of development that can be ironed out later. This is fine if there is no value at risk â€“ but, with virtual currencies, there is an enormous amount of money and stakeholder trust on the line. 

Tiêu chuẩn khởi nghiệp cho công nghệ phát triển là xây dựng một sản phẩm khả thi tối thiểu một cách nhanh chóng và sau đó liên tục lặp lại cho đến khi nó sẵn sàng cho thị trường đại chúng.
Điều này được gọi là một quá trình nhanh nhẹn.
Đó là một cách tuyệt vời để cho thấy rằng một dự án đang tiến triển trong khi cuối cùng xây dựng một sản phẩm đầy đủ chức năng.
Tuy nhiên, một phương pháp Agile giả định sẽ có lỗi và điểm yếu trong mỗi bước phát triển có thể được giải quyết sau đó.
Điều này là tốt nếu không có giá trị có rủi ro - nhưng, với các loại tiền ảo, có một số tiền khổng lồ và niềm tin của các bên liên quan trên đường dây.

Building a digital asset on a blockchain provides several challenges to overcome in terms of organizing a development process. As a proof-of-stake cryptocurrency, Cardano is a distributed system in an adversarial environment where consistent performance is critical. The protocol has to maintain security in the face of malicious actors attempting sabotage. This means that no one can afford to build quickly and deal with problems later. 

Xây dựng một tài sản kỹ thuật số trên một blockchain cung cấp một số thách thức để khắc phục về mặt tổ chức một quá trình phát triển.
Là một loại tiền điện tử chứng minh, Cardano là một hệ thống phân tán trong môi trường bất lợi trong đó hiệu suất nhất quán là rất quan trọng.
Giao thức phải duy trì bảo mật khi đối mặt với các diễn viên độc hại đang cố gắng phá hoại.
Điều này có nghĩa là không ai có thể đủ khả năng để xây dựng nhanh chóng và giải quyết các vấn đề sau này.

Trust is essential for a currency to be accepted and correctness proofs are an important way to increase the veracity of a system. This is why the code should not only be correct, but there should be evidence of its correctness, such as extensive meaningful tests and mathematical proofs. In a young industry like cryptocurrencies, IOHK engineers have to anticipate the addition of new features while maintaining the correctness guarantees established in the initial version. The platform can only scale globally if it is able to grow while maintaining security and utility for everyone. This is why Cardano developers streamlined their methodology, combining a variety of tools ranging from property-based testing all the way to machine verifiable proofs, to create high assurance software even in the presence of changing requirements.

Niềm tin là điều cần thiết cho một loại tiền tệ được chấp nhận và bằng chứng chính xác là một cách quan trọng để tăng tính xác thực của một hệ thống.
Đây là lý do tại sao mã không chỉ đúng, mà còn có bằng chứng về tính đúng đắn của nó, chẳng hạn như các bài kiểm tra có ý nghĩa rộng rãi và bằng chứng toán học.
Trong một ngành công nghiệp trẻ như tiền điện tử, các kỹ sư IOHK phải dự đoán việc bổ sung các tính năng mới trong khi duy trì các đảm bảo tính chính xác được thiết lập trong phiên bản ban đầu.
Nền tảng chỉ có thể mở rộng toàn cầu nếu nó có thể phát triển trong khi duy trì bảo mật và tiện ích cho mọi người.
Đây là lý do tại sao các nhà phát triển Cardano đã hợp lý hóa phương pháp của họ, kết hợp một loạt các công cụ khác nhau, từ thử nghiệm dựa trên tài sản cho đến các bằng chứng có thể kiểm chứng của máy, để tạo ra phần mềm đảm bảo cao ngay cả khi có các yêu cầu thay đổi.

**Research to code**

** Nghiên cứu để mã **

The methodology begins with scientific research. To date, IOHK has released more than 60 research papers that have contributed to creating the platform. Each paper examines a critical aspect of blockchain technology from first principles. How do we gain consensus in a decentralized way? How is a smart contract designed? What is the right reward structure to incentivize good behavior? IOHK researchers examine these questions, and submit their answers to scientific journals and conferences. These papers contain proofs that must pass rigorous peer review. Then, to ensure that the quality of our software does justice to the science, it is developed using formal methods.

Phương pháp bắt đầu với nghiên cứu khoa học.
Đến nay, IOHK đã phát hành hơn 60 bài nghiên cứu đã góp phần tạo ra nền tảng.
Mỗi bài kiểm tra một khía cạnh quan trọng của công nghệ blockchain từ các nguyên tắc đầu tiên.
Làm thế nào để chúng ta đạt được sự đồng thuận một cách phi tập trung?
Một hợp đồng thông minh được thiết kế như thế nào?
Cấu trúc phần thưởng phù hợp để khuyến khích hành vi tốt là gì?
Các nhà nghiên cứu của IOHK kiểm tra những câu hỏi này và gửi câu trả lời của họ cho các tạp chí và hội nghị khoa học.
Những bài báo này chứa các bằng chứng phải vượt qua đánh giá ngang hàng nghiêm ngặt.
Sau đó, để đảm bảo rằng chất lượng phần mềm của chúng tôi thực hiện công bằng cho khoa học, nó được phát triển bằng các phương pháp chính thức.

In essence, this means that IOHK engineers specify what the code should do mathematically. That way, they can ensure that when the code is run, it contains the desired properties designed into it. The code is written in Haskell, a high-assurance functional programming language with a strong type system. While Haskell is a great tool for implementing reliable software, it is not foolproof, so the code still needs to be tested. A great way to write tests is using QuickCheck, which allows developers to state properties that should always hold in a program. QuickCheck then generates test cases, and searches for minimal counterexamples that violate those properties.

Về bản chất, điều này có nghĩa là các kỹ sư IOHK chỉ định những gì mã nên làm toán học.
Bằng cách đó, họ có thể đảm bảo rằng khi mã được chạy, nó chứa các thuộc tính mong muốn được thiết kế vào nó.
Mã này được viết bằng Haskell, ngôn ngữ lập trình chức năng bảo đảm cao với một hệ thống loại mạnh.
Mặc dù Haskell là một công cụ tuyệt vời để triển khai phần mềm đáng tin cậy, nhưng nó không phải là hoàn hảo, vì vậy mã vẫn cần được kiểm tra.
Một cách tuyệt vời để viết các bài kiểm tra là sử dụng QuickCheck, cho phép các nhà phát triển có các thuộc tính trạng thái luôn luôn giữ trong một chương trình.
QuickCheck sau đó tạo ra các trường hợp thử nghiệm và tìm kiếm các mẫu phản đối tối thiểu vi phạm các thuộc tính đó.

In code that interacts with the external world, in particular network applications, it can be hard to find minimal counterexamples. This is because the order of execution is not deterministic: it can change every time the software is run. The same code can be run hundreds of times, and only fail once. We can get around this by using simulations with deterministic execution order. Running tests in simulation allows us to reliably find and fix a class of bugs in testing, which would otherwise only occur randomly in production.

Trong mã tương tác với thế giới bên ngoài, đặc biệt là các ứng dụng mạng, có thể khó tìm thấy các mẫu phản ứng tối thiểu.
Điều này là do thứ tự thực thi không xác định: nó có thể thay đổi mỗi khi phần mềm được chạy.
Mã tương tự có thể được chạy hàng trăm lần và chỉ thất bại một lần.
Chúng ta có thể hiểu được điều này bằng cách sử dụng các mô phỏng với thứ tự thực hiện xác định.
Chạy các thử nghiệm trong mô phỏng cho phép chúng tôi tìm thấy và sửa một lớp lỗi trong thử nghiệm một cách đáng tin cậy, điều này chỉ xảy ra ngẫu nhiên trong sản xuất.

**Bridging the gap**

**Thu hẹp khoảng cách**

To get a picture of the development methodology employed for Cardano, letâ€™s consider the metaphor of bridge building. When a civil engineer builds a bridge, a large portion of their time is spent behind a desk. The civil engineer plans a design, calculates the statics, and orders geographic surveys. During that time, nothing happens at the building site. An observer would be unable to see any progress being made. For building bridges, this is the correct approach. If the planning is not accurate, it is difficult and expensive to correct problems at a later stage. Ultimately, the result would be a delayed bridge at a higher cost, or one which fails completely. Lack of visible progress is a good price to pay for a functional and safe bridge.

Để có được một bức tranh về phương pháp phát triển được sử dụng cho Cardano, hãy xem xét phép ẩn dụ xây dựng cầu.
Khi một kỹ sư dân sự xây dựng một cây cầu, một phần lớn thời gian của họ được dành cho một bàn làm việc.
Kỹ sư dân dụng lên kế hoạch thiết kế, tính toán các thống kê và đặt hàng khảo sát địa lý.
Trong thời gian đó, không có gì xảy ra tại địa điểm xây dựng.
Một người quan sát sẽ không thể thấy bất kỳ tiến bộ nào được thực hiện.
Đối với việc xây dựng cầu, đây là cách tiếp cận chính xác.
Nếu kế hoạch không chính xác, thật khó khăn và tốn kém để khắc phục các vấn đề ở giai đoạn sau.
Cuối cùng, kết quả sẽ là một cây cầu bị trì hoãn với chi phí cao hơn, hoặc một cầu nối hoàn toàn thất bại.
Thiếu tiến bộ có thể nhìn thấy là một mức giá tốt để trả cho một cây cầu chức năng và an toàn.

When building software, making changes in later stages is much easier than in construction. That is what enables the common agile development approach. If an agile developer was building a bridge, they would construct a pillar in one rapid sprint and then the next in a second sprint. The gap between the pillars would be spanned in a final sprint and, if things didnâ€™t hold up, the developers would add on one more sprint to fix any issues. While progress would be demonstrable at the building site, the final product would likely have a great deal of problems built into it. This creates clean up work at the end of the project which could have been avoided by better planning at an earlier stage. Furthermore, the minimum viable product would likely be given to a small group of people for a test drive with the expectation that it would fail in order to alert developers of bugs. Needless to say, it is best that bridges arenâ€™t designed in this way.

Khi xây dựng phần mềm, thực hiện các thay đổi trong các giai đoạn sau sẽ dễ dàng hơn nhiều so với xây dựng.
Đó là những gì cho phép phương pháp phát triển Agile phổ biến.
Nếu một nhà phát triển Agile đang xây dựng một cây cầu, họ sẽ xây dựng một trụ cột trong một lần chạy nước rút nhanh chóng và sau đó là lần chạy nước rút thứ hai.
Khoảng cách giữa các trụ cột sẽ được kéo dài trong lần chạy nước rút cuối cùng và, nếu mọi thứ không giữ được, các nhà phát triển sẽ thêm vào một lần chạy nước rút để khắc phục bất kỳ vấn đề nào.
Mặc dù tiến bộ sẽ được chứng minh tại địa điểm xây dựng, sản phẩm cuối cùng có thể sẽ có rất nhiều vấn đề được tích hợp trong nó.
Điều này tạo ra công việc dọn dẹp ở cuối dự án có thể tránh được bằng cách lập kế hoạch tốt hơn ở giai đoạn sớm hơn.
Hơn nữa, sản phẩm khả thi tối thiểu có thể sẽ được trao cho một nhóm nhỏ người để lái thử với kỳ vọng rằng nó sẽ thất bại để cảnh báo các nhà phát triển lỗi.
Không cần phải nói, tốt nhất là Bridges không được thiết kế theo cách này.

When hearing the words 'formal methodsâ€™, a lot of people in software development think about the civil engineering approach, which is dubbed â€˜waterfallâ€™ and generally shunned. This is a common but unfortunate misunderstanding. Indeed, using appropriate formal techniques allows us to have our cake, and eat it too: to have an overall design (a deliberate design, not an accidental one from fitting together pieces developed in sprints), to show progress continuously, and to retain the ability to react to changing requirements.

Khi nghe các từ 'Phương pháp chính thức, rất nhiều người trong phát triển phần mềm nghĩ về phương pháp kỹ thuật dân dụng, được mệnh danh là "Waterfall" và thường bị xa lánh.
Đây là một sự hiểu lầm phổ biến nhưng đáng tiếc.
Thật vậy, bằng cách sử dụng các kỹ thuật chính thức phù hợp cho phép chúng ta có bánh và ăn nó: để có một thiết kế tổng thể (một thiết kế có chủ ý, không phải là một thứ ngẫu nhiên phù hợp với các mảnh được phát triển trong các lần chạy nước rút), để hiển thị sự tiến bộ liên tục và giữ lại
Có khả năng phản ứng với các yêu cầu thay đổi.

A key technique employed by IOHK developers is executable specifications. These are high level designs, which abstract over low level details, written in a language that the computer can understand and execute. Executable specifications can be used as prototypes to show progress, get feedback from users, and test assumptions. On top of that, lower level details can be added via successive refinements. Our developers build the bridge to solve the biggest problems first then add pillars to reinforce it at a later time. In a software system, the pillars would be features like saving data to disk, or using performant algorithms, which are needed for a final product, but which are not essential to demonstrate the overall functionality.

Một kỹ thuật quan trọng được sử dụng bởi các nhà phát triển IOHK là thông số kỹ thuật thực thi.
Đây là những thiết kế cấp cao, trừu tượng về các chi tiết cấp thấp, được viết bằng một ngôn ngữ mà máy tính có thể hiểu và thực hiện.
Thông số kỹ thuật thực thi có thể được sử dụng làm nguyên mẫu để hiển thị tiến trình, nhận phản hồi từ người dùng và các giả định kiểm tra.
Trên hết, các chi tiết cấp thấp hơn có thể được thêm vào thông qua các tinh chỉnh liên tiếp.
Các nhà phát triển của chúng tôi xây dựng cây cầu để giải quyết các vấn đề lớn nhất trước tiên sau đó thêm các trụ cột để củng cố nó sau đó.
Trong một hệ thống phần mềm, các trụ cột sẽ là các tính năng như lưu dữ liệu vào đĩa hoặc sử dụng các thuật toán biểu diễn, cần thiết cho một sản phẩm cuối cùng, nhưng không cần thiết để chứng minh chức năng tổng thể.

Using executable specifications, we get the benefits of proper planning without sacrificing flexibility. IOHK developers can fix what the system should look like on a large scale, and then implement suitable components as needed. Continuous testing guarantees that each component fits the overall design. This helps prevent problems that are common in a late integration approach. With this methodology, we get the best of both worlds: we can use a top-down design (avoiding late integration troubles, having a good handle on the overall design at all times), and have working code early (demonstrating progress, and allowing for tests and feedback through the whole process).

Sử dụng thông số kỹ thuật thực thi, chúng tôi nhận được những lợi ích của việc lập kế hoạch đúng đắn mà không phải hy sinh tính linh hoạt.
Các nhà phát triển IOHK có thể sửa chữa hệ thống sẽ trông như thế nào trên quy mô lớn, và sau đó thực hiện các thành phần phù hợp khi cần thiết.
Kiểm tra liên tục đảm bảo rằng mỗi thành phần phù hợp với thiết kế tổng thể.
Điều này giúp ngăn ngừa các vấn đề phổ biến trong một phương pháp tích hợp muộn.
Với phương pháp này, chúng ta có được những điều tốt nhất của cả hai thế giới: chúng ta có thể sử dụng thiết kế từ trên xuống (tránh các rắc rối tích hợp muộn, có khả năng xử lý tốt trong thiết kế tổng thể mọi lúc) và có mã làm việc sớm (thể hiện tiến trình và cho phép
cho các thử nghiệm và phản hồi thông qua toàn bộ quá trình).

**Future proof**

** Bằng chứng trong tương lai **

Ultimately, the method of construction should be determined by what is being built. IOHK is building a global social and financial operating system which requires rigor and speed. Formal versus agile is a false dichotomy. Instead, weâ€™re continuing to develop our methodology which fuses the best of both approaches: formal techniques within an agile delivery framework, with robust, higher assurance code upon which we can build for all our futures.

Cuối cùng, phương pháp xây dựng nên được xác định bằng những gì đang được xây dựng.
IOHK đang xây dựng một hệ điều hành tài chính và xã hội toàn cầu đòi hỏi sự nghiêm ngặt và tốc độ.
Chính thức so với nhanh nhẹn là một sự phân đôi sai.
Thay vào đó, chúng tôi đang tiếp tục phát triển phương pháp của chúng tôi, điều này hợp nhất các phương pháp tốt nhất của cả hai phương pháp: các kỹ thuật chính thức trong một khung phân phối nhanh, với mã đảm bảo mạnh mẽ, cao hơn mà chúng tôi có thể xây dựng cho tất cả các tương lai của mình.

