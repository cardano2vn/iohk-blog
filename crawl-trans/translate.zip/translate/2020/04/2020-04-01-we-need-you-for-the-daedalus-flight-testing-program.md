# We need you for a Daedalus testing program!
### **A call for the Cardano community to help shape IOHK’s ada wallet for the Shelley era**
![](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.002.png) 1 April 2020![](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.002.png)[ Anthony Quinn](tmp//en/blog/authors/anthony-quinn/page-1/)![](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.003.png) 7 mins read

![Anthony Quinn](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.004.png)[](tmp//en/blog/authors/anthony-quinn/page-1/)
### [**Anthony Quinn**](tmp//en/blog/authors/anthony-quinn/page-1/)
Editor

Marketing & Communications

- ![](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.005.png)[](mailto:anthony.quinn@iohk.io "Email")
- ![](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.006.png)[](https://www.youtube.com/watch?v=KkcAic12dvc "YouTube")
- ![](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.007.png)[](https://www.linkedin.com/in/tony-quinn-frsa-0b093229 "LinkedIn")
- ![](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.008.png)[](https://twitter.com/IohkT "Twitter")

![We need you for a Daedalus testing program!](img/2020-04-01-we-need-you-for-the-daedalus-flight-testing-program.009.jpeg)

The Daedalus team is opening up IOHK’s wallet testing program to ada owners. The aim is to seek the help of a broad range of people who can test – on a rolling basis – the latest interface features being readied for the next release version of Daedalus. This will be a fully-functioning version of the wallet, called Daedalus Flight, so you will be able to spend and receive ada as usual – and give the team valuable feedback to improve the experience with each release.

Nhóm Daedalus đang mở chương trình thử nghiệm ví IOHK cho chủ sở hữu ADA.
Mục đích là để tìm kiếm sự giúp đỡ của một loạt những người có thể kiểm tra - trên cơ sở lăn - các tính năng giao diện mới nhất được chuẩn bị cho phiên bản phát hành tiếp theo của Daedalus.
Đây sẽ là phiên bản hoạt động đầy đủ của ví, được gọi là Daedalus Flight, vì vậy bạn sẽ có thể chi tiêu và nhận ADA như bình thường-và cung cấp cho nhóm phản hồi có giá trị để cải thiện trải nghiệm với mỗi bản phát hành.

We put some questions to Daedalus Product Manager, Darko Mijić, to tease out the details for people who want to take part.

Chúng tôi đặt một số câu hỏi cho người quản lý sản phẩm Daedalus, Darko Mijić, để trêu chọc các chi tiết cho những người muốn tham gia.

**Darko, can you expand on the thinking behind the program?**

** Darko, bạn có thể mở rộng suy nghĩ đằng sau chương trình không? **

I’ve been working at IOHK for almost four years. It’s been amazing to see the way the Incentivized Testnet has galvanized the Cardano community in the past few months. The community helped us develop the stake pools for Shelley, and, of course, to test and develop a version of the Daedalus wallet for the ITN. So, building on that strategy, we came up with the idea of Daedalus Flight. This is a pre-release version of the Daedalus wallet that users can test with real ada transactions on the mainnet. People can join the program by downloading and using the Flight wallet alongside their usual Daedalus – or Yoroi – wallet to find and report issues so we can fix them before the actual release. We’ve seen that people want to help – and they will gain early access to the new features of the next production Daedalus release for the mainnet.

Tôi đã làm việc tại IOHK trong gần bốn năm.
Thật tuyệt vời khi thấy cách mà Testnet khuyến khích đã mạ điện cho cộng đồng Cardano trong vài tháng qua.
Cộng đồng đã giúp chúng tôi phát triển các nhóm cổ phần cho Shelley, và tất nhiên, để kiểm tra và phát triển một phiên bản của ví Daedalus cho ITN.
Vì vậy, xây dựng dựa trên chiến lược đó, chúng tôi đã nảy ra ý tưởng về chuyến bay Daedalus.
Đây là phiên bản phát hành trước của ví Daedalus mà người dùng có thể kiểm tra với các giao dịch ADA thực trên chính.
Mọi người có thể tham gia chương trình bằng cách tải xuống và sử dụng ví chuyến bay cùng với ví Daedalus - hoặc Yoroi - thông thường của họ để tìm và báo cáo các vấn đề để chúng tôi có thể khắc phục chúng trước khi phát hành thực tế.
Chúng tôi đã thấy rằng mọi người muốn giúp đỡ - và họ sẽ có quyền truy cập sớm vào các tính năng mới của bản phát hành Daedalus sản xuất tiếp theo cho Mainnet.

It’s similar to beta testing, or the ‘canary’ approach Google uses for its Chrome browser. Adding this tactic to our release process creates another valuable source of testing data. We will be able to improve the quality assurance of our new software versions and move more quickly into full production by first trialing these changes in Daedalus Flight with a subset of participating users.

Nó tương tự như thử nghiệm beta hoặc cách tiếp cận ‘Canary, Google sử dụng cho trình duyệt Chrome của mình.
Thêm chiến thuật này vào quá trình phát hành của chúng tôi tạo ra một nguồn dữ liệu thử nghiệm có giá trị khác.
Chúng tôi sẽ có thể cải thiện sự đảm bảo chất lượng của các phiên bản phần mềm mới của chúng tôi và chuyển nhanh hơn vào sản xuất đầy đủ bằng cách thử nghiệm những thay đổi này trong chuyến bay Daedalus với một tập hợp người dùng tham gia.

**But is it for everyone?**

** Nhưng nó có dành cho tất cả mọi người không? **

This program is especially important because it will give us a bigger sample of users who are using Daedalus in various ways on a wide variety of software and hardware configurations. We want to bring confident ada owners on board to help us develop the wallet by testing features and suggesting their own ideas. People who volunteer for this must already be familiar with using the Daedalus wallet. People need to be skilled in using computers – copying and backing up files, moving things around between folders – and prepared to deal with any issues that arise. We’re not expecting IT experts, but you do need to be confident about computers and making ada transactions.

Chương trình này đặc biệt quan trọng vì nó sẽ cung cấp cho chúng tôi một mẫu người dùng lớn hơn đang sử dụng Daedalus theo nhiều cách khác nhau trên nhiều cấu hình phần mềm và phần cứng.
Chúng tôi muốn đưa chủ sở hữu ADA tự tin lên tàu để giúp chúng tôi phát triển ví bằng cách thử nghiệm các tính năng và đề xuất ý tưởng của riêng họ.
Những người tình nguyện cho việc này phải quen thuộc với việc sử dụng ví Daedalus.
Mọi người cần phải có kỹ năng sử dụng máy tính - sao chép và sao lưu các tệp, di chuyển mọi thứ xung quanh giữa các thư mục - và chuẩn bị giải quyết mọi vấn đề phát sinh.
Chúng tôi không mong đợi các chuyên gia CNTT, nhưng bạn cần phải tự tin về máy tính và thực hiện các giao dịch ADA.

**How will the process work?**

** Quá trình sẽ hoạt động như thế nào? **

We complete a Daedalus development sprint every two weeks and quality assurance is a continuous effort during the development of every feature. At the end of each sprint, we will now create a new Daedalus Flight release, and, starting with the first flight candidate, we do our tests internally. But testing in a lab for a mass-market desktop product is not a real test. Under the new flight process, we will release a series of flight candidates and work on testing, finding issues and fixing issues with members of the Cardano community who have joined the program to help us. Flight candidate releases will be delivered through the Daedalus newsfeed, after an initial download from a new Flight option on the [**official Daedalus website](https://daedaluswallet.io/)[](https://daedaluswallet.io/), which is *the only source* of the Flight wallet.

Chúng tôi hoàn thành một cuộc chạy nước rút Daedalus phát triển cứ sau hai tuần và đảm bảo chất lượng là một nỗ lực liên tục trong quá trình phát triển của mọi tính năng.
Vào cuối mỗi lần chạy nước rút, giờ đây chúng tôi sẽ tạo ra một bản phát hành chuyến bay Daedalus mới, và, bắt đầu với ứng cử viên chuyến bay đầu tiên, chúng tôi thực hiện các bài kiểm tra của chúng tôi trong nội bộ.
Nhưng thử nghiệm trong phòng thí nghiệm cho một sản phẩm máy tính để bàn thị trường đại chúng không phải là một thử nghiệm thực sự.
Theo quy trình bay mới, chúng tôi sẽ phát hành một loạt các ứng cử viên chuyến bay và làm việc để thử nghiệm, tìm kiếm các vấn đề và khắc phục các vấn đề với các thành viên của cộng đồng Cardano đã tham gia chương trình để giúp chúng tôi.
Các bản phát hành ứng cử viên chuyến bay sẽ được phân phối thông qua Daedalus Newsfeed, sau khi tải xuống ban đầu từ tùy chọn chuyến bay mới trên trang web Daedalus chính thức] (https://daedaluswallet.io/) [] (https://daedaluswallet.io/
), đó là * nguồn duy nhất * của ví chuyến bay.

Once we reach our final candidate, and we are confident that the release ‘can fly’, we will be releasing it to production for all Daedalus users.

Khi chúng tôi đạt được ứng cử viên cuối cùng và chúng tôi tự tin rằng bản phát hành có thể bay, chúng tôi sẽ phát hành nó để sản xuất cho tất cả người dùng Daedalus.

This process will repeat every two weeks. There will be instances when we don’t release the production version after completing a flight release. This will happen when we are building big, multi-sprint features that cannot be delivered partially.

Quá trình này sẽ lặp lại hai tuần một lần.
Sẽ có những trường hợp khi chúng tôi không phát hành phiên bản sản xuất sau khi hoàn thành phát hành chuyến bay.
Điều này sẽ xảy ra khi chúng ta đang xây dựng các tính năng lớn, đa dạng không thể được phân phối một phần.

When you download Daedalus Flight, you can compare balances and transaction histories and see that all your wallet data has moved across. If there’s a problem, you just report it and go back to using your usual wallet while we fix things and release another candidate.

Khi bạn tải xuống chuyến bay Daedalus, bạn có thể so sánh số dư và lịch sử giao dịch và thấy rằng tất cả dữ liệu ví của bạn đã di chuyển.
Nếu có một vấn đề, bạn chỉ cần báo cáo và quay lại sử dụng ví thông thường của bạn trong khi chúng tôi sửa chữa mọi thứ và giải phóng một ứng cử viên khác.

**Why is this on the mainnet? Won’t it put our ada at risk?**

** Tại sao điều này lại trên Mainnet?
Thắng nó khiến ADA của chúng tôi gặp rủi ro? **

Your ada will not be at risk. The Flight wallet is a real wallet and can do everything your usual wallet can. We’re adding features to make things easier for users. We could have done this on a testnet but the real test is where the real wallets live, on the mainnet. ‘Real’ user testing only happens after a wallet update is released to the mainnet. This flight process is secure because it is a completely separate wallet installation. We import your wallets from your production version of Daedalus. The production version of Daedalus stays untouched and fully functional.

ADA của bạn sẽ không gặp rủi ro.
Ví chuyến bay là một ví thực sự và có thể làm mọi thứ mà ví thông thường của bạn có thể.
Chúng tôi thêm các tính năng để làm cho mọi thứ dễ dàng hơn cho người dùng.
Chúng tôi có thể đã thực hiện điều này trên một testnet nhưng thử nghiệm thực sự là nơi các ví thực sự sống, trên mainnet.
Thử nghiệm người dùng thực sự chỉ xảy ra sau khi cập nhật ví được phát hành cho Mainnet.
Quá trình bay này được an toàn vì nó là một cài đặt ví hoàn toàn riêng biệt.
Chúng tôi nhập ví của bạn từ phiên bản sản xuất của Daedalus.
Phiên bản sản xuất của Daedalus vẫn chưa được xử lý và đầy đủ chức năng.

**So, we keep our present wallets?**

** Vì vậy, chúng tôi giữ ví hiện tại của chúng tôi? **

Yes, you keep all your present wallets. You can use them alongside each Daedalus Flight candidate.

Vâng, bạn giữ tất cả các ví hiện tại của bạn.
Bạn có thể sử dụng chúng cùng với mỗi ứng cử viên bay Daedalus.

**How will we give feedback?**

** Chúng ta sẽ đưa ra phản hồi như thế nào? **

There is an option to open a support request directly from the Daedalus interface. These requests will be handled separately by the support desk, and you can attach a wallet log so we can investigate your problem. If you just want to suggest an idea, you can do that too by clicking ‘Support request’ in the help menu.

Có một tùy chọn để mở một yêu cầu hỗ trợ trực tiếp từ giao diện Daedalus.
Các yêu cầu này sẽ được xử lý riêng bởi bàn hỗ trợ và bạn có thể đính kèm nhật ký ví để chúng tôi có thể điều tra vấn đề của bạn.
Nếu bạn chỉ muốn đề xuất một ý tưởng, bạn cũng có thể làm điều đó bằng cách nhấp vào ‘yêu cầu hỗ trợ trong menu trợ giúp.

**Can you give us a sneak preview of the features?**

** Bạn có thể cho chúng tôi xem trước các tính năng lén lút không? **

Well, first of all, there will be Yoroi support in the new Flight wallet. Yoroi users will be able to use the same wallet both in Flight and Yoroi. Transactions will be in sync. Then, there will be a transaction filtering function in your transaction history so you can filter transactions by type, date, and ada amount. There will also be a warning in the transaction confirmation window making sure users understand that Daedalus Flight transactions are real ada transactions on the mainnet. Other neat touches will include parallel wallet restoration and a resync wallet function. Later on, we will be adding cool features like hardware wallet support.

Chà, trước hết, sẽ có sự hỗ trợ của Yoroi trong ví chuyến bay mới.
Người dùng Yoroi sẽ có thể sử dụng cùng một ví cả trong chuyến bay và Yoroi.
Giao dịch sẽ được đồng bộ hóa.
Sau đó, sẽ có một chức năng lọc giao dịch trong lịch sử giao dịch của bạn để bạn có thể lọc các giao dịch theo loại, ngày và số tiền ADA.
Cũng sẽ có một cảnh báo trong cửa sổ Xác nhận giao dịch để đảm bảo người dùng hiểu rằng các giao dịch bay của Daedalus là các giao dịch ADA thực sự trên Mainnet.
Các điểm nhấn gọn gàng khác sẽ bao gồm phục hồi ví song song và chức năng ví Resync.
Sau này, chúng tôi sẽ thêm các tính năng thú vị như hỗ trợ ví phần cứng.

**How long will the Daedalus Flight program last?**

** Chương trình bay Daedalus sẽ kéo dài bao lâu? **

The program started with the Byron reboot on March 31, with the first flight release and its candidate #1 release. If we discover and fix issues, we will issue a second candidate. When we get to a fully stable candidate, we will release it to all Daedalus users. April 6 is the planned date for the first production-ready Daedalus, but this depends on the results and user data from Daedalus Flight.

Chương trình bắt đầu với việc khởi động lại Byron vào ngày 31 tháng 3, với bản phát hành chuyến bay đầu tiên và bản phát hành ứng cử viên số 1.
Nếu chúng tôi khám phá và khắc phục các vấn đề, chúng tôi sẽ đưa ra một ứng cử viên thứ hai.
Khi chúng tôi nhận được một ứng cử viên hoàn toàn ổn định, chúng tôi sẽ phát hành nó cho tất cả người dùng Daedalus.
Ngày 6 tháng 4 là ngày được lên kế hoạch cho Daedalus sẵn sàng sản xuất đầu tiên, nhưng điều này phụ thuộc vào kết quả và dữ liệu người dùng từ chuyến bay Daedalus.

The next release and its series of candidates can be expected for April 14, and then every two weeks. Because this is a new product, we will try this process out for a month or two. If successful, we plan to make this permanent practice in the long term. It is important to note that the special Daedalus version for the Incentivized Testnet will still exist – that is a completely separate product.

Bản phát hành tiếp theo và loạt ứng cử viên của nó có thể được dự kiến vào ngày 14 tháng 4, và sau đó hai tuần một lần.
Bởi vì đây là một sản phẩm mới, chúng tôi sẽ thử quá trình này trong một hoặc hai tháng.
Nếu thành công, chúng tôi có kế hoạch thực hiện thực hành vĩnh viễn này trong dài hạn.
Điều quan trọng cần lưu ý là phiên bản Daedalus đặc biệt cho Testnet được khuyến khích vẫn sẽ tồn tại - đó là một sản phẩm hoàn toàn riêng biệt.

**Any final message?**

** Bất kỳ tin nhắn cuối cùng? **

People should be clear that the Daedalus Flight wallet is used with your mainnet ada. It’s a real wallet with all the core functions of Daedalus. It’s just the new features, which are not to do with transactions, that we’re testing. Going back to the Chrome comparison, think of it as buying something from Amazon using a beta test release of a web browser; you are doing real things with test software.

Mọi người nên rõ ràng rằng ví chuyến bay Daedalus được sử dụng với Mainnet ADA của bạn.
Nó có một ví thực sự với tất cả các chức năng cốt lõi của Daedalus.
Nó chỉ là các tính năng mới, không liên quan đến các giao dịch mà chúng tôi đang thử nghiệm.
Quay trở lại với so sánh Chrome, hãy nghĩ về nó như mua một cái gì đó từ Amazon bằng cách sử dụng bản phát hành thử nghiệm beta của trình duyệt web;
Bạn đang làm những điều thực sự với phần mềm thử nghiệm.

We hope you’ll be as excited as we are by this innovation – and can help our Daedalus development really fly! And remember, for the latest information and news, visit the [official Daedalus website](https://daedaluswallet.io/en/).

Chúng tôi hy vọng bạn sẽ phấn khích như chúng tôi bằng sự đổi mới này - và có thể giúp sự phát triển Daedalus của chúng tôi thực sự bay!
Và hãy nhớ rằng, để biết thông tin và tin tức mới nhất, hãy truy cập [trang web Daedalus chính thức] (https://daedaluswallet.io/en/).

