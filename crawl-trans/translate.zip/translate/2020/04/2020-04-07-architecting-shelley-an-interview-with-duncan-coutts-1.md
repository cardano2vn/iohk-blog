# Architecting Shelley: an interview with Duncan Coutts
### **A fireside chat with Duncan Coutts, Cardano's chief technical architect, about Haskell and delivering Shelley**
![](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.002.png) 7 April 2020![](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.002.png)[ Eric Czuleger](tmp//en/blog/authors/eric-czuleger/page-1/)![](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.003.png) 6 mins read

![Eric Czuleger](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.004.png)[](tmp//en/blog/authors/eric-czuleger/page-1/)
### [**Eric Czuleger**](tmp//en/blog/authors/eric-czuleger/page-1/)
Senior Content Editor

Marketing & Communications

- ![](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.005.png)[](mailto:eric.czuleger@iohk.io "Email")
- ![](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.006.png)[](https://www.linkedin.com/in/eric-czuleger-6b67a395/ "LinkedIn")
- ![](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.007.png)[](https://twitter.com/eczuleger "Twitter")

![Architecting Shelley: an interview with Duncan Coutts](img/2020-04-07-architecting-shelley-an-interview-with-duncan-coutts-1.008.jpeg)

Duncan Coutts has been an important guide on the road to the Cardano Shelley mainnet. Long time supporters of IOHK are likely familiar with his signature long hair, beard, and penchant for drinking tea while discussing decentralization in front of a [white board](https://www.youtube.com/watch?v=TZGVgNsJSnA&t=572s). He recently sat down for an interview to discuss the upcoming Byron reboot, the Haskell Shelley testnet, and the conclusion of the pre-Shelley development cycle. Coutts, who has been working with IOHK since 2016, brings a wealth of knowledge from working with the Haskell programming language for nearly 20 years and helping found the Well-Typed consultancy.

Duncan Coutts là một hướng dẫn quan trọng trên con đường đến Cardano Shelley Mainnet.
Những người ủng hộ IOHK lâu năm có khả năng quen thuộc với mái tóc dài, râu và râu của anh ấy để uống trà trong khi thảo luận về phân cấp trước [bảng trắng] (https://www.youtube.com/watch?v=TZGVGNS
).
Gần đây, anh ấy đã ngồi lại cho một cuộc phỏng vấn để thảo luận về việc khởi động lại Byron sắp tới, Haskell Shelley Testnet và kết luận về chu kỳ phát triển tiền Shelley.
Coutts, người đã làm việc với IOHK từ năm 2016, mang đến nhiều kiến thức từ việc làm việc với ngôn ngữ lập trình Haskell trong gần 20 năm và giúp tìm ra tư vấn được gõ tốt.

**Whatâ€™s your role at IOHK?**

** Vai trò của bạn tại IOHK là gì? **

Iâ€™m the chief technical architect for the Cardano project and Iâ€™m primarily responsible for the design and implementation of the node. This means that I collaborate with the teams that work on consensus, ledger, networking, and other things. Ultimately, I work to bring everyone together around the same design after a discussion with the team leaders. The design of Cardano is the product of joint work by many individuals working together.

Tôi là kiến trúc sư kỹ thuật chính cho dự án Cardano và tôi chịu trách nhiệm chủ yếu cho việc thiết kế và triển khai nút.
Điều này có nghĩa là tôi hợp tác với các nhóm làm việc về sự đồng thuận, sổ cái, kết nối mạng và những thứ khác.
Cuối cùng, tôi làm việc để kết hợp mọi người xung quanh cùng một thiết kế sau một cuộc thảo luận với các nhà lãnh đạo nhóm.
Thiết kế của Cardano là sản phẩm của công việc chung của nhiều cá nhân làm việc cùng nhau.

**What does the Haskell programming language bring to Cardano?**

** Ngôn ngữ lập trình Haskell mang đến Cardano? **

Haskell is an enabler. It makes it easier for us to follow the approach that we believe is right, which is driven by computer science. We know how to do things properly; computer science tells us how. We just need to pick the appropriate techniques to do that. Haskell makes that easier.

Haskell là một yếu tố hỗ trợ.
Nó giúp chúng tôi dễ dàng theo cách tiếp cận mà chúng tôi tin là đúng, được điều khiển bởi khoa học máy tính.
Chúng tôi biết làm thế nào để làm mọi thứ đúng đắn;
Khoa học máy tính cho chúng ta biết làm thế nào.
Chúng ta chỉ cần chọn các kỹ thuật thích hợp để làm điều đó.
Haskell làm cho điều đó dễ dàng hơn.

Itâ€™s a good fit for Cardano because it suits the high-assurance, specification-driven software that is vital for a blockchain. Haskell helps us find systematic ways of avoiding mistakes. In essence, itâ€™s a better mousetrap.

Đó là một sự phù hợp tốt với Cardano vì nó phù hợp với phần mềm dựa trên đặc điểm kỹ thuật, rất quan trọng đối với một blockchain.
Haskell giúp chúng tôi tìm ra những cách có hệ thống để tránh sai lầm.
Về bản chất, nó là một bẫy chuột tốt hơn.

**Youâ€™ve been working with Haskell for a long time. How have you seen the landscape of functional programming change?**

** Bạn đã làm việc với Haskell trong một thời gian dài.
Làm thế nào bạn đã thấy cảnh quan của thay đổi lập trình chức năng? **

People take it seriously now. When I started as an undergraduate in 1999, I thought that Haskell was amazing. Other students thought, â€˜Wow thatâ€™s totally impractical. How will you ever get a job?â€™

Mọi người coi trọng nó ngay bây giờ.
Khi tôi bắt đầu làm đại học vào năm 1999, tôi nghĩ rằng Haskell thật tuyệt vời.
Các sinh viên khác nghĩ, "Điều đó hoàn toàn không thực tế.
Làm thế nào bạn sẽ có một công việc? "

At the time, functional programming was an academic curiosity. There wasnâ€™t any prebuilt code and it wasnâ€™t machine readable, which meant that Haskell wasnâ€™t usable for a wide range of people. There wasnâ€™t the tooling, range of libraries, or experience. That has changed over the years: the tooling got better, the libraries got better. IOHK has helped develop the infrastructure for building and distributing open-source Haskell code and the number of libraries exploded. That, combined with more teaching and a gradual change of attitude in the industry, means that people take it more seriously now. Haskell hasnâ€™t changed as much as the industry around us has.

Vào thời điểm đó, lập trình chức năng là một sự tò mò học thuật.
Không có bất kỳ mã nào được xây dựng sẵn và nó không có thể đọc được, điều đó có nghĩa là Haskell không thể sử dụng được cho nhiều người.
Không có công cụ, phạm vi thư viện hoặc kinh nghiệm.
Điều đó đã thay đổi qua nhiều năm: Công cụ trở nên tốt hơn, các thư viện đã tốt hơn.
IOHK đã giúp phát triển cơ sở hạ tầng để xây dựng và phân phối mã Haskell nguồn mở và số lượng thư viện bùng nổ.
Điều đó, kết hợp với việc giảng dạy nhiều hơn và thay đổi thái độ dần dần trong ngành, có nghĩa là mọi người coi trọng nó nghiêm trọng hơn bây giờ.
Haskell đã thay đổi nhiều như ngành công nghiệp xung quanh chúng ta có.

**Whatâ€™s the biggest change from an industry point of view?**

** Sự thay đổi lớn nhất từ quan điểm của ngành là gì? **

There are two things. The first is that attitudes are changing, albeit slowly. People are changing their opinions about what they consider a sensible language choice. Previously, everything had to be in C or Java or maybe Python, but eventually good ideas make progress, even if it takes a long time. You can make a lot of progress by just recognizing that a good idea is a good idea. The mainstream does pick up on important developments, even if it does take 10 or 15 years. The industry has not embraced functional programming wholesale yet, but individual programmers have taken up various ideas. That makes Haskell look less radical.

Có hai điều.
Đầu tiên là thái độ đang thay đổi, mặc dù chậm.
Mọi người đang thay đổi ý kiến của họ về những gì họ coi là một lựa chọn ngôn ngữ hợp lý.
Trước đây, mọi thứ phải có trong C hoặc Java hoặc có thể là Python, nhưng cuối cùng những ý tưởng tốt đã đạt được sự tiến bộ, ngay cả khi nó mất nhiều thời gian.
Bạn có thể đạt được nhiều tiến bộ bằng cách nhận ra rằng một ý tưởng tốt là một ý tưởng tốt.
Dòng chính không nhận được những phát triển quan trọng, ngay cả khi mất 10 hoặc 15 năm.
Ngành công nghiệp chưa chấp nhận bán buôn lập trình chức năng, nhưng các lập trình viên cá nhân đã đưa ra nhiều ý tưởng khác nhau.
Điều đó làm cho Haskell trông ít triệt để hơn.

If you look at a language like Rust, it has some of the clever type systems of Haskell, although it doesnâ€™t have any functional programming ideas. Even Java and C++ have some functional programming ideas in them these days, so Haskell is not quite so far from the mainstream as it used to be.

Nếu bạn nhìn vào một ngôn ngữ như Rust, nó có một số hệ thống thông minh của Haskell, mặc dù nó không có bất kỳ ý tưởng lập trình chức năng nào.
Ngay cả Java và C ++ cũng có một số ý tưởng lập trình chức năng trong đó những ngày này, vì vậy Haskell không hoàn toàn xa với dòng chính như trước đây.

The second major change has been performance, which is getting much better. Weâ€™ve recently become competitive with Java in terms of performance. It makes people say, â€˜Wow, Haskell is so fast,â€™ but thatâ€™s because theyâ€™re comparing it to Python and PHP rather than C. So thatâ€™s another way of saying that Haskell has improved slightly, but the industry environment around it has changed as well.

Thay đổi lớn thứ hai là hiệu suất, điều này đang trở nên tốt hơn nhiều.
Gần đây chúng tôi đã trở nên cạnh tranh với Java về hiệu suất.
Mọi người nói rằng, "Haskell rất nhanh, nhưng điều đó là vì họ so sánh nó với Python và PHP chứ không phải là một cách khác để nói rằng Haskell có
Cải thiện một chút, nhưng môi trường ngành công nghiệp xung quanh nó cũng đã thay đổi.

**You have been heavily involved in the Byron reboot which was kicked off last week. Why was this work important?**

** Bạn đã tham gia rất nhiều vào việc khởi động lại Byron đã được khởi động vào tuần trước.
Tại sao công việc này lại quan trọng? **

The [Byron reboot](https://iohk.io/en/blog/posts/2020/03/30/what-the-byron-reboot-means-for-cardano/) is the culmination of over 18 months of hard work across multiple IOHK development teams, and constitutes a complete overhaul of the node infrastructure with 100% fresh code. The reboot introduces an extensible, modular design within the node itself, separating out the ledger, consensus, and networking components, as well as improvements and new functionality in the wallet backend and the Cardano explorer.

[Khởi động lại Byron] (https://iohk.io/en/blog/posts/2020/03/30/what-the-byron-reboot-mean-for-cardano/) là đỉnh cao của hơn 18 tháng
Làm việc trên nhiều nhóm phát triển IOHK và tạo thành một cuộc đại tu hoàn toàn cơ sở hạ tầng nút với mã mới 100%.
Việc khởi động lại giới thiệu một thiết kế mô -đun có thể mở rộng trong chính nút, tách ra sổ cái, sự đồng thuận và các thành phần mạng, cũng như các cải tiến và chức năng mới trong phụ trợ ví và nhà thám hiểm Cardano.

For Daedalus users, the Byron reboot will see us moving to a regular update cadence [see our recent piece on [Daedalus Flight](https://iohk.io/en/blog/posts/2020/04/01/we-need-you-for-the-daedalus-flight-testing-program/) for more on that], after which they should find that Daedalus is faster, more reliable, and uses less memory. A lot of the issues users have experienced with Daedalus in the past were due to the underlying node, rather than Daedalus itself. The Byron reboot will go a long way to improving things, and users should see Daedalus syncing and restoring wallets within minutes, even when downloading the entire Cardano blockchain.

Đối với người dùng Daedalus, việc khởi động lại Byron sẽ thấy chúng tôi chuyển sang một nhịp cập nhật thường xuyên [xem phần gần đây của chúng tôi trên [Daedalus Flight] (https://iohk.io/en/blog/posts/2020/04/01/we-eed
-you-for-the-daedalus-flight-testing-chương trình/) để biết thêm về điều đó], sau đó họ nên thấy rằng Daedalus nhanh hơn, đáng tin cậy hơn và sử dụng ít bộ nhớ hơn.
Rất nhiều vấn đề mà người dùng đã trải qua với Daedalus trong quá khứ là do nút cơ bản, thay vì chính Daedalus.
Việc khởi động lại Byron sẽ đi một chặng đường dài để cải thiện mọi thứ và người dùng sẽ thấy Daedalus đồng bộ hóa và khôi phục ví trong vòng vài phút, ngay cả khi tải xuống toàn bộ blockchain Cardano.

**As the chief architect, your job is to lay the foundation for Cardanoâ€™s future. What have you focused on to achieve this?**

** Là kiến trúc sư trưởng, công việc của bạn là đặt nền tảng cho tương lai của Cardano.
Bạn đã tập trung vào điều gì để đạt được điều này? **

The most important aspect in terms of flexibility for the future is keeping different functions separate. One of the big improvements of the Byron reboot is that the ledger rules will be totally independent of the consensus implementation; this modularity means that the ledger rules are perfectly clean mathematical functions, which is a core aspect of functional programming.

Khía cạnh quan trọng nhất về tính linh hoạt cho tương lai là tách biệt các chức năng khác nhau.
Một trong những cải tiến lớn của việc khởi động lại Byron là các quy tắc sổ cái sẽ hoàn toàn độc lập với việc thực hiện đồng thuận;
Tính mô -đun này có nghĩa là các quy tắc sổ cái là các hàm toán học hoàn toàn sạch, đây là một khía cạnh cốt lõi của lập trình chức năng.

As a result, everything is easier to test, tweak, and change, both now and in the future. The consensus algorithm isnâ€™t entangled with the details of the ledger rules, so we can alter the ledger rules without changing the consensus implementation. This makes integrating Plutus and smart contracts functionality much easier and will also help in the future when we are adding treasury and governance features.

Do đó, mọi thứ đều dễ dàng hơn để kiểm tra, điều chỉnh và thay đổi, cả bây giờ và trong tương lai.
Thuật toán đồng thuận không bị vướng vào các chi tiết của các quy tắc sổ cái, vì vậy chúng tôi có thể thay đổi các quy tắc sổ cái mà không thay đổi việc thực hiện đồng thuận.
Điều này làm cho việc tích hợp Plutus và chức năng hợp đồng thông minh dễ dàng hơn nhiều và cũng sẽ giúp trong tương lai khi chúng ta đang thêm các tính năng quản trị và kho bạc.

The consensus implementation itself has also been parameterized so that we can transition from the Ouroboros Classic consensus protocol to BFT and then Praos, which also provides flexibility for future versions of the protocol that haven't been developed yet.

Bản thân việc thực hiện đồng thuận cũng đã được tham số hóa để chúng tôi có thể chuyển từ giao thức đồng thuận cổ điển Ouroboros sang BFT và sau đó là Praos, cũng cung cấp tính linh hoạt cho các phiên bản tương lai của giao thức chưa được phát triển.

**Shelley is a big step towards the future of Cardano, but what is the significance of compiling Haskell into JavaScript and WebAssembly?**

** Shelley là một bước tiến lớn đối với tương lai của Cardano, nhưng tầm quan trọng của việc biên dịch Haskell vào JavaScript và Webassugging là gì? **

Weâ€™re interested in compiling to JavaScript or WebAssembly because of Plutus. We want to have Plutus contracts or Plutus applications that can be distributed to users, which would include custom interfaces and custom logic with the user rather than in a server. Compiling to JavaScript allows us to do that; you can compile the Plutus code once and distribute it to users on different platforms.

Chúng tôi quan tâm đến việc biên dịch với JavaScript hoặc Webassugging vì Plutus.
Chúng tôi muốn có các hợp đồng Plutus hoặc các ứng dụng Plutus có thể được phân phối cho người dùng, bao gồm các giao diện tùy chỉnh và logic tùy chỉnh với người dùng thay vì trong máy chủ.
Biên dịch với JavaScript cho phép chúng tôi làm điều đó;
Bạn có thể biên dịch mã Plutus một lần và phân phối nó cho người dùng trên các nền tảng khác nhau.

-----

-----

Thanks to Duncan Coutts for his time. As chief technical architect, heâ€™s a cornerstone of the Cardano project and has been fundamental to the ongoing success of the platform. For more interviews with the team, stay tuned to our social channels and the IOHK blog.

Cảm ơn Duncan Coutts đã dành thời gian.
Là kiến trúc sư kỹ thuật trưởng, ông là nền tảng của dự án Cardano và là nền tảng cho sự thành công liên tục của nền tảng này.
Để biết thêm các cuộc phỏng vấn với nhóm, hãy theo dõi các kênh xã hội của chúng tôi và blog IOHK.

