# From Byron to Shelley: Part one, the testnets
### **The evolution to decentralization continues with a series of three Haskell Shelley testnets**
![](img/2020-04-29-from-byron-to-shelley-part-one-the-testnets.002.png) 29 April 2020![](img/2020-04-29-from-byron-to-shelley-part-one-the-testnets.002.png)[ Kevin Hammond](tmp//en/blog/authors/kevin-hammond/page-1/)![](img/2020-04-29-from-byron-to-shelley-part-one-the-testnets.003.png) 7 mins read

![Kevin Hammond](img/2020-04-29-from-byron-to-shelley-part-one-the-testnets.004.png)[](tmp//en/blog/authors/kevin-hammond/page-1/)
### [**Kevin Hammond**](tmp//en/blog/authors/kevin-hammond/page-1/)
Software Engineer

Engineering

- ![](img/2020-04-29-from-byron-to-shelley-part-one-the-testnets.005.png)[](https://twitter.com/inputoutputhk "Twitter")

![From Byron to Shelley: Part one, the testnets](img/2020-04-29-from-byron-to-shelley-part-one-the-testnets.006.jpeg)

Following the successful Byron reboot of Cardano, we are beginning our phased transition to the Shelley mainnet. This means moving from a static, federated system to a dynamic, decentralized Cardano blockchain.

Sau khi khởi động lại Byron thành công của Cardano, chúng tôi đang bắt đầu quá trình chuyển đổi theo giai đoạn của chúng tôi sang Shelley Mainnet.
Điều này có nghĩa là chuyển từ một hệ thống tĩnh, liên kết sang một blockchain cardano năng động, phi tập trung.

The process begins with a series of Haskell Shelley testnets, culminating in the Shelley upgrade hybrid phase.

Quá trình bắt đầu với một loạt các bài kiểm tra của Haskell Shelley, đỉnh cao là giai đoạn lai của Shelley.

The Haskell Shelley testnets will be a different experience from the previous Incentivized Testnet (ITN) for both stake pool operators and general users/ada holders. This is because the ITN and the Haskell testnets have been created with different goals in mind.

Testnets của Haskell Shelley sẽ là một trải nghiệm khác với TestNet được khuyến khích trước đó (ITN) cho cả người vận hành nhóm cổ phần và người dùng chung/chủ sở hữu ADA.
Điều này là do các bài kiểm tra ITN và Haskell đã được tạo ra với các mục tiêu khác nhau trong tâm trí.

The ITN was designed to give stake pool operators experience in building their critical infrastructure, while allowing IOHKâ€™s engineers to test the new incentive mechanisms with real ada, delegated by actual ada holders. The Haskell Shelley testnet is about ensuring that the Shelley mainnet is calibrated to be a best-in-class experience from day one. Unlike the ITN, the Haskell Shelley testnet will not involve â€˜regularâ€™ ada holders: the testnet will not be incentivized. Each phase is intended to run for a much shorter period â€“ weeks rather than months. We will, of course, be testing out the operation of the wallet, explorer, and so on, but using a faucet distributing test ada that doesnâ€™t offer rewards. Ada holders will be able to try Daedalus and the explorer on the public testnet and provide feedback, but without using real ada.

ITN được thiết kế để cung cấp cho các nhà khai thác nhóm cổ phần trong việc xây dựng cơ sở hạ tầng quan trọng của họ, đồng thời cho phép các kỹ sư của IOHK kiểm tra các cơ chế khuyến khích mới với ADA thực sự, được ủy quyền bởi những người nắm giữ ADA thực tế.
Haskell Shelley Testnet là về việc đảm bảo rằng Shelley Mainnet được hiệu chỉnh để trở thành một trải nghiệm tốt nhất trong lớp từ ngày đầu tiên.
Không giống như ITN, Haskell Shelley Testnet sẽ không liên quan đến những người nắm giữ ada -€ ™ € ™: testnet sẽ không được khuyến khích.
Mỗi giai đoạn được dự định sẽ chạy trong một khoảng thời gian ngắn hơn nhiều - tuần thay vì vài tháng.
Tất nhiên, chúng tôi sẽ thử nghiệm hoạt động của ví, nhà thám hiểm, v.v.
Chủ sở hữu ADA sẽ có thể thử Daedalus và nhà thám hiểm trên testnet công khai và cung cấp phản hồi, nhưng không sử dụng ADA thực sự.

The Shelley experience will roll out within clearly defined phases. The first three phases will involve exploring and testing the new Shelley capabilities and moving to a situation where we are ready for full Shelley mainnet deployment.

Trải nghiệm Shelley sẽ tung ra trong các giai đoạn được xác định rõ ràng.
Ba giai đoạn đầu tiên sẽ liên quan đến việc khám phá và thử nghiệm các khả năng mới của Shelley và chuyển sang tình huống chúng tôi sẵn sàng để triển khai Shelley Mainnet đầy đủ.

## **Phase 1: Pioneers and the â€˜Friends & Familyâ€™ phase**

## nó

The rollout will begin with an invitation-only â€˜friends and familyâ€™ testnet. During this phase, IOHK will first spin up and run a Shelley-only test network internally. We will then invite about 20 trusted stake pool operators â€“ weâ€™re calling them â€˜pioneersâ€™ â€“ to join this (initially closed) network. These operators will comprise a small group who have demonstrated a high level of technical skill and community contribution during the ITN.

Việc triển khai sẽ bắt đầu với một lời mời chỉ-bạn bè và Testnet của gia đình.
Trong giai đoạn này, IOHK trước tiên sẽ quay lên và chạy một mạng thử nghiệm chỉ dành cho Shelley trong nội bộ.
Sau đó, chúng tôi sẽ mời khoảng 20 nhà khai thác nhóm cổ phần đáng tin cậy - chúng tôi gọi họ là - những người tham gia - để tham gia mạng này (ban đầu đã đóng).
Các nhà khai thác này sẽ bao gồm một nhóm nhỏ, người đã thể hiện một kỹ năng kỹ thuật và đóng góp cộng đồng cao trong ITN.

These pioneers will blaze the trail for others to follow as we head to full Shelley deployment on the Cardano mainnet. In this important first phase, weâ€™ll be asking them to perform specific functionality tests to capture their valuable feedback while exploring the capabilities of the Haskell Shelley platform. We expect to invite more pioneers to join us â€“ a few at a time â€“ as we add features and prove the reliability of the testnet.

Những người tiên phong này sẽ làm cháy đường mòn cho những người khác theo dõi khi chúng ta đi đến triển khai Shelley đầy đủ trên Cardano Mainnet.
Trong giai đoạn đầu tiên quan trọng này, chúng tôi sẽ yêu cầu họ thực hiện các bài kiểm tra chức năng cụ thể để nắm bắt phản hồi có giá trị của họ trong khi khám phá các khả năng của nền tảng Haskell Shelley.
Chúng tôi hy vọng sẽ mời nhiều người tiên phong tham gia cùng chúng tôi - một số ít tại một thời điểm - khi chúng tôi thêm các tính năng và chứng minh độ tin cậy của testnet.

In this â€˜closed alphaâ€™ testing phase, IOHK will focus on tuning system parameters such as the saturation threshold, network resilience, and decentralization. Furthermore, IOHKâ€™s engineers will see the Ouroboros Praos consensus mechanism working outside of simulation. The pioneer phase will give IOHKâ€™s engineers the opportunity to address any issues in a controlled environment, with feedback and support from stake pool operators, before moving to the next phase. The findings will be communicated to the Cardano community and opportunities will be taken to learn about and improve the Shelley system.

Trong giai đoạn thử nghiệm alphaâ € ™ này, IOHK sẽ tập trung vào các tham số hệ thống điều chỉnh như ngưỡng bão hòa, khả năng phục hồi mạng và phân cấp.
Hơn nữa, các kỹ sư của IOHK sẽ thấy cơ chế đồng thuận của Ouroboros PRAOS hoạt động bên ngoài mô phỏng.
Giai đoạn Tiên phong sẽ cung cấp cho các kỹ sư của IOHK cơ hội giải quyết mọi vấn đề trong môi trường được kiểm soát, với phản hồi và hỗ trợ từ các nhà khai thác nhóm cổ phần, trước khi chuyển sang giai đoạn tiếp theo.
Các phát hiện sẽ được truyền đạt cho cộng đồng Cardano và các cơ hội sẽ được thực hiện để tìm hiểu và cải thiện hệ thống Shelley.

This phase will also be all about producing high-quality technical documentation and support. The pioneers (supported by the community as a whole) will help us produce documentation that will make it easy to set up and run stakepools, and give our technical support team an understanding of the issues that our users will face.

Giai đoạn này cũng sẽ là tất cả về việc sản xuất tài liệu và hỗ trợ kỹ thuật chất lượng cao.
Những người tiên phong (được toàn bộ cộng đồng hỗ trợ) sẽ giúp chúng tôi sản xuất tài liệu giúp bạn dễ dàng thiết lập và chạy các bên cạnh và cung cấp cho nhóm hỗ trợ kỹ thuật của chúng tôi hiểu biết về các vấn đề mà người dùng của chúng tôi sẽ gặp phải.

## **Phase 2: Opening up the testnet â€“ the public phase**

## ** Giai đoạn 2: Mở Testnet - Giai đoạn công khai **

The community response to the ITN was incredible, and we are blessed with having a wealth of skilled stake pool operators in the community. Weâ€™ll keep everyone informed through every step of the process and â€“ as ever â€“ our repos will be fully open. But for purely practical reasons, weâ€™ll be working 1-2-1 with just a small group of around 20 operators at first. But our goal is to open things up as soon as we can, with full public access in the next phase.

Phản ứng của cộng đồng đối với ITN là không thể tin được, và chúng tôi may mắn có được vô số các nhà điều hành nhóm cổ phần lành nghề trong cộng đồng.
Chúng tôi sẽ thông báo cho tất cả mọi người thông qua từng bước của quy trình và - như mọi khi - các repos của chúng tôi sẽ được mở hoàn toàn.
Nhưng vì lý do hoàn toàn thực tế, chúng tôi sẽ làm việc 1-2-1 chỉ với một nhóm nhỏ khoảng 20 nhà khai thác lúc đầu.
Nhưng mục tiêu của chúng tôi là mở ra mọi thứ ngay khi chúng tôi có thể, với quyền truy cập công cộng đầy đủ trong giai đoạn tiếp theo.

This will allow all the stake pool operators who participated in the ITN to redeploy their previously constructed infrastructure, and to tune their stake pool to the new Haskell settings. This testnet will run as closely as possible to mainnet conditions, including mixing Byron and Shelley era blocks.

Điều này sẽ cho phép tất cả các nhà khai thác nhóm cổ phần đã tham gia vào ITN để triển khai lại cơ sở hạ tầng được xây dựng trước đó của họ và điều chỉnh nhóm cổ phần của họ với các cài đặt Haskell mới.
TestNet này sẽ chạy gần nhất có thể với các điều kiện chính, bao gồm trộn các khối thời đại Byron và Shelley.

During each evolution in the transition to Shelley, IOHK is placing an emphasis on community training and collaboration. Decentralization of knowledge is just as important as decentralization of the platform. Pioneer participants in the alpha testnet will provide crucial support in advising the remaining stake pool operators on configuration and use of the Shelley system. And as operators acclimatize, weâ€™ll also be asking them to support and bring new operators on board.

Trong mỗi quá trình tiến hóa trong quá trình chuyển đổi sang Shelley, IOHK đang nhấn mạnh vào đào tạo và hợp tác cộng đồng.
Phân cấp kiến thức cũng quan trọng như sự phân cấp của nền tảng.
Những người tham gia Pioneer trong Alpha Testnet sẽ cung cấp hỗ trợ quan trọng trong việc tư vấn cho các nhà khai thác nhóm cổ phần còn lại về cấu hình và sử dụng hệ thống Shelley.
Và khi các nhà khai thác thích nghi, chúng tôi cũng sẽ yêu cầu họ hỗ trợ và đưa các nhà khai thác mới lên tàu.

## **Phase 3: The balance check**

## ** Giai đoạn 3: Kiểm tra số dư **

The third and final phase prior to mainnet deployment is the balance check. This will bring together the Byron and ITN transaction histories, and prepare the mainnet for the Shelley era. At this point, the ITN rewards and mainnet balances will be consolidated. After this point, it will no longer be possible to earn rewards on the ITN. However, users will be able to check their rewards and confirm them in mainnet wallets. Weâ€™ll share full details of what ada holders need to do to reclaim their ITN rewards a little nearer the time. The balance check phase will last for only a couple of weeks before we start moving towards decentralized stake pools and the Shelley era.

Giai đoạn thứ ba và cuối cùng trước khi triển khai chính là kiểm tra số dư.
Điều này sẽ tập hợp các lịch sử giao dịch Byron và ITN, và chuẩn bị chính cho thời kỳ Shelley.
Tại thời điểm này, phần thưởng ITN và số dư chính sẽ được hợp nhất.
Sau thời điểm này, nó sẽ không còn có thể kiếm được phần thưởng trên ITN.
Tuy nhiên, người dùng sẽ có thể kiểm tra phần thưởng của họ và xác nhận chúng trong ví chính.
Chúng tôi sẽ chia sẻ chi tiết đầy đủ về những gì chủ sở hữu ADA cần làm để đòi lại phần thưởng ITN của họ gần hơn một chút thời gian.
Giai đoạn kiểm tra cân bằng sẽ chỉ kéo dài trong một vài tuần trước khi chúng tôi bắt đầu tiến tới các nhóm cổ phần phi tập trung và kỷ nguyên Shelley.

## **How we will select the pioneers**

## ** Cách chúng tôi sẽ chọn những người tiên phong **

We are selecting the pioneer group based on a number of criteria, devised in collaboration with the team at the Cardano Foundation. Pool operators must have a deep knowledge of running stake pools on the ITN, as well as competency working with Linux, and come from a range of backgrounds and geographical locations. Some will be working with cloud solutions providers to run their pool, others with their own hardware â€“ weâ€™ll have a mix. By selecting pioneers from different geographical regions, we will be able to ensure a global reach, and test out our new network implementation.

Chúng tôi đang chọn nhóm Tiên phong dựa trên một số tiêu chí, được đưa ra hợp tác với nhóm tại Quỹ Cardano.
Các nhà khai thác nhóm phải có kiến thức sâu sắc về việc chạy nhóm cổ phần trên ITN, cũng như năng lực làm việc với Linux, và đến từ một loạt các nền tảng và vị trí địa lý.
Một số người sẽ làm việc với các nhà cung cấp giải pháp đám mây để điều hành nhóm của họ, những người khác với phần cứng của riêng họ - Chúng tôi sẽ có một hỗn hợp.
Bằng cách chọn những người tiên phong từ các khu vực địa lý khác nhau, chúng tôi sẽ có thể đảm bảo phạm vi toàn cầu và kiểm tra triển khai mạng mới của chúng tôi.

Pioneers will be expected to commit a set number of hours per week to supporting the rollout program, give direct feedback and provide advice to the community and mentor others at subsequent phases. Bringing others on board and supporting them along the way will be a crucial part of the role. To be clear, as ever, all our repos will be open so we encourage everyone to get involved. As always, IOHKâ€™s developers value input from every member of the Cardano community. Anyone who wishes to is encouraged to spin up their own nodes. If they are skilled developers they can also recommend enhancements to the Shelley Haskell code base because all the information will be published through GitHub.

Những người tiên phong sẽ được dự kiến sẽ cam kết một số giờ được thiết lập mỗi tuần để hỗ trợ chương trình triển khai, đưa ra phản hồi trực tiếp và cung cấp lời khuyên cho cộng đồng và cố vấn cho những người khác ở các giai đoạn tiếp theo.
Đưa người khác lên tàu và hỗ trợ họ trên đường đi sẽ là một phần quan trọng của vai trò.
Để rõ ràng, như mọi khi, tất cả các repos của chúng tôi sẽ được mở để chúng tôi khuyến khích mọi người tham gia.
Như mọi khi, các nhà phát triển của IOHK giá trị đầu vào từ mọi thành viên của cộng đồng Cardano.
Bất cứ ai muốn được khuyến khích quay các nút của riêng họ.
Nếu họ là các nhà phát triển lành nghề, họ cũng có thể đề xuất các cải tiến cho cơ sở mã Shelley Haskell vì tất cả các thông tin sẽ được công bố thông qua GitHub.

Weâ€™ll be looking to expand the network rapidly with more pools as soon as this earliest testing phase delivers the results we want.

Chúng tôi sẽ tìm cách mở rộng mạng nhanh chóng với nhiều nhóm hơn ngay khi giai đoạn thử nghiệm sớm nhất này mang lại kết quả chúng tôi muốn.

## **Ensuring an easier start for everyone**

## ** Đảm bảo bắt đầu dễ dàng hơn cho mọi người **

The Haskell Shelley code base has been developed with formal methods and the high assurance Haskell programming language. So while we anticipate that some minor elements will need addressing, we believe that the initial experience should be free of any major issues. This is the approach that we have used for the Byron reboot, with great success, and we will be building on the code base that we have developed there. The approach will deliver even greater benefits for Shelley and beyond, by allowing us to deploy software much more quickly than in the past, with new features subject to rigorous and careful checks even before coding has been completed.

Cơ sở mã Haskell Shelley đã được phát triển với các phương pháp chính thức và ngôn ngữ lập trình Haskell đảm bảo cao.
Vì vậy, trong khi chúng tôi dự đoán rằng một số yếu tố nhỏ sẽ cần giải quyết, chúng tôi tin rằng trải nghiệm ban đầu sẽ không có bất kỳ vấn đề lớn nào.
Đây là cách tiếp cận mà chúng tôi đã sử dụng để khởi động lại Byron, với thành công lớn và chúng tôi sẽ xây dựng trên cơ sở mã mà chúng tôi đã phát triển ở đó.
Cách tiếp cận sẽ mang lại lợi ích lớn hơn cho Shelley và hơn thế nữa, bằng cách cho phép chúng tôi triển khai phần mềm nhanh hơn nhiều so với trước đây, với các tính năng mới chịu kiểm tra nghiêm ngặt và cẩn thận ngay cả trước khi mã hóa đã hoàn thành.

Our goal is to provide a plug-and-play solution to get stake pool operators up and running. This means they should be able to pick up a pre-prepared docker image or AWS instance, for example, and their stake pool will be launched. We will, of course, also provide standalone binaries and source code for those with more experience, or who have specific configuration requirements.

Mục tiêu của chúng tôi là cung cấp một giải pháp cắm và chơi để có được các nhà khai thác nhóm cổ phần lên và chạy.
Điều này có nghĩa là họ sẽ có thể chọn một hình ảnh Docker hoặc AWS được chuẩn bị sẵn, ví dụ, và nhóm cổ phần của họ sẽ được ra mắt.
Tất nhiên, chúng tôi cũng sẽ cung cấp các nhị phân độc lập và mã nguồn cho những người có nhiều kinh nghiệm hơn hoặc những người có yêu cầu cấu hình cụ thể.

Weâ€™re now in the final stages of preparation and things are heating up (you may have recently seen a tweet that the [new node](https://twitter.com/IOHK_Charles/status/1254642739247022081) has produced its first block). With that successful first step completed, weâ€™ll be sharing dates and more details very soon. Weâ€™ll also be publishing further blogs outlining the other key steps and milestones in the process. Keep an eye out for those and meanwhile stay tuned to IOHKâ€™s social channels. Weâ€™ll be sure to let you know as we start rolling things out.

Bây giờ chúng tôi đang trong giai đoạn chuẩn bị cuối cùng và mọi thứ đang nóng lên (gần đây bạn có thể đã thấy một tweet rằng [nút mới] (https://twitter.com/iohk_charles/status/1254642739247022081) đã sản xuất khối đầu tiên của mình
).
Với bước đầu tiên thành công đó đã hoàn thành, chúng tôi sẽ chia sẻ ngày và chi tiết nhiều hơn rất sớm.
Chúng tôi cũng sẽ xuất bản các blog tiếp theo phác thảo các bước và mốc quan trọng khác trong quá trình này.
Hãy để mắt đến những người đó và trong khi đó hãy theo dõi các kênh xã hội của Iohk.
Chúng tôi sẽ chắc chắn cho bạn biết khi chúng tôi bắt đầu tung ra mọi thứ.

