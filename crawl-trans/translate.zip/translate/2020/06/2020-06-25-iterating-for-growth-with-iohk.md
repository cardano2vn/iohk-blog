# Iterating for growth with IOHK research
### **Building key values into the Cardano ecosystem**
![](img/2020-06-25-iterating-for-growth-with-iohk.002.png) 25 June 2020![](img/2020-06-25-iterating-for-growth-with-iohk.002.png)[ Lars Brünjes](tmp//en/blog/authors/lars-brunjes/page-1/)![](img/2020-06-25-iterating-for-growth-with-iohk.003.png) 11 mins read

![Lars Brünjes](img/2020-06-25-iterating-for-growth-with-iohk.004.png)[](tmp//en/blog/authors/lars-brunjes/page-1/)
### [**Lars Brünjes**](tmp//en/blog/authors/lars-brunjes/page-1/)
Education Director

Education

- ![](img/2020-06-25-iterating-for-growth-with-iohk.005.png)[](mailto:lars.bruenjes@iohk.io "Email")
- ![](img/2020-06-25-iterating-for-growth-with-iohk.006.png)[](https://www.linkedin.com/in/dr-lars-br%C3%BCnjes-1640993b "LinkedIn")
- ![](img/2020-06-25-iterating-for-growth-with-iohk.007.png)[](https://twitter.com/LarsBrunjes "Twitter")
- ![](img/2020-06-25-iterating-for-growth-with-iohk.008.png)[](https://github.com/brunjlar "GitHub")

![Iterating for growth with IOHK research](img/2020-06-25-iterating-for-growth-with-iohk.009.jpeg)

Setting solid parameter values – while maintaining flexibility for the future – will be key to the growth and ongoing decentralization of Cardano. After consulting with the community, and working closely with my colleagues Kevin Hammond and Alex Appledoorn, we believe we’ve identified a good place to start.

Đặt các giá trị tham số rắn - trong khi duy trì tính linh hoạt cho tương lai - sẽ là chìa khóa cho sự tăng trưởng và phân cấp liên tục của Cardano.
Sau khi tham khảo ý kiến với cộng đồng và hợp tác chặt chẽ với các đồng nghiệp Kevin Hammond và Alex Appledoorn, chúng tôi tin rằng chúng tôi đã xác định được một nơi tốt để bắt đầu.

The behavior of Cardano Shelley is controlled by around 20 parameters, and values have to be set for all of those before we launch the mainnet. Most of these parameters are technical in nature, so while setting them correctly is important to guarantee the safety and optimize performance of the system, their particular values do not have a significant influence on user experience.

Hành vi của Cardano Shelley được kiểm soát bởi khoảng 20 tham số và các giá trị phải được đặt cho tất cả các thông số trước khi chúng tôi khởi chạy Mainnet.
Hầu hết các tham số này đều có bản chất kỹ thuật, vì vậy trong khi thiết lập chúng một cách chính xác là quan trọng để đảm bảo sự an toàn và tối ưu hóa hiệu suất của hệ thống, các giá trị cụ thể của chúng không có ảnh hưởng đáng kể đến trải nghiệm người dùng.

Some parameters are different, though. They determine the level of centralization and sustainability of the Cardano ecosystem. They also drive the economics of delegation and of operating a stake pool. Choosing good values for these is exceedingly complicated, because we have to carefully balance a number of important considerations; security, performance, stability, sustainability, decentralization, fairness and economic viability. 

Một số tham số là khác nhau, mặc dù.
Họ xác định mức độ tập trung và tính bền vững của hệ sinh thái Cardano.
Họ cũng thúc đẩy kinh tế của phái đoàn và điều hành một nhóm cổ phần.
Chọn các giá trị tốt cho những điều này là cực kỳ phức tạp, bởi vì chúng tôi phải cân bằng cẩn thận một số cân nhắc quan trọng;
An ninh, hiệu suất, ổn định, bền vững, phân cấp, công bằng và khả năng kinh tế.

With all parameters on the Cardano blockchain, we have three distinct goals to keep in mind:

Với tất cả các tham số trên blockchain Cardano, chúng tôi có ba mục tiêu riêng biệt cần ghi nhớ:

- We want to be truly decentralized, so that no one party can threaten the integrity of the chain

- Chúng tôi muốn thực sự phân cấp, để không một bên nào có thể đe dọa tính toàn vẹn của chuỗi

- We want the stake pool operators to be incentivized to keep supporting our chain

- Chúng tôi muốn các nhà khai thác nhóm cổ phần được khuyến khích để tiếp tục hỗ trợ chuỗi của chúng tôi

- We do not want these incentives to significantly change at any singular point in time in a way that might negatively affect the stability of the operators’ income

- Chúng tôi không muốn những ưu đãi này thay đổi đáng kể tại bất kỳ thời điểm duy nhất nào theo cách có thể ảnh hưởng tiêu cực đến sự ổn định của các nhà khai thác thu nhập

We want to give equal opportunity to everyone who wants to participate in Cardano and run a stake pool. However, parameter values that might seem fair and reasonable for smaller pools can become challenging for larger pools and vice versa. For example, large pools could find it easy to put down a higher pledge than small pools can afford. Small pools, on the other hand, might be able to operate with far lower costs than larger pools.

Chúng tôi muốn tạo cơ hội bình đẳng cho tất cả những ai muốn tham gia Cardano và điều hành một nhóm cổ phần.
Tuy nhiên, các giá trị tham số có vẻ công bằng và hợp lý cho các nhóm nhỏ hơn có thể trở thành thách thức đối với các nhóm lớn hơn và ngược lại.
Ví dụ, các hồ bơi lớn có thể thấy dễ dàng để đưa ra một cam kết cao hơn so với các hồ bơi nhỏ có thể đủ khả năng.
Mặt khác, các hồ bơi nhỏ có thể có thể hoạt động với chi phí thấp hơn nhiều so với các nhóm lớn hơn.

We also consider it imprudent to change parameters too frequently, because this might negatively affect the stability and predictability of the operators’ income. Taking all of this under consideration we came up with some recommendations for initial choices of parameter values which we will outline here.

Chúng tôi cũng xem xét việc thay đổi các tham số quá thường xuyên, vì điều này có thể ảnh hưởng tiêu cực đến sự ổn định và khả năng dự đoán của các nhà khai thác thu nhập.
Đưa ra tất cả những điều này đang được xem xét, chúng tôi đã đưa ra một số khuyến nghị cho các lựa chọn ban đầu về các giá trị tham số mà chúng tôi sẽ phác thảo ở đây.

However, we do not want to stop there. With decentralization comes democracy. Our community must have a say in how the chain is governed. For this reason, we will run with these numbers initially and issue a Cardano improvement proposal, where the community can vote on optimal chain parameters. In the end, the governance of Cardano will be in the hands of the Cardano community, who we feel confident are the best people to advise us.

Tuy nhiên, chúng tôi không muốn dừng lại ở đó.
Với sự phân cấp đến dân chủ.
Cộng đồng của chúng tôi phải có một tiếng nói trong cách chuỗi được quản lý.
Vì lý do này, chúng tôi sẽ chạy với những con số này ban đầu và đưa ra đề xuất cải tiến Cardano, trong đó cộng đồng có thể bỏ phiếu về các tham số chuỗi tối ưu.
Cuối cùng, quản trị của Cardano sẽ nằm trong tay cộng đồng Cardano, người mà chúng tôi cảm thấy tự tin là những người tốt nhất để tư vấn cho chúng tôi.

# **Desired number of stake pools**

# ** Số lượng nhóm cổ phần mong muốn **

The desired number of stake pools *k* is an important parameter. Cardano incentives have been designed to encourage an equilibrium with *k* fully saturated pools, which means that rewards will be optimal for everybody when all stake is delegated uniformly to the *k* most attractive pools.

Số lượng nhóm cổ phần mong muốn * K * là một tham số quan trọng.
Các ưu đãi của Cardano đã được thiết kế để khuyến khích trạng thái cân bằng với các nhóm hoàn toàn bão hòa * K *, điều đó có nghĩa là phần thưởng sẽ là tối ưu cho mọi người khi tất cả các cổ phần được ủy quyền đồng đều cho các nhóm hấp dẫn nhất * K *.

The higher *k* chosen, the more decentralized the system becomes. But a higher *k* also leads to a less efficient system (higher costs, more energy consumption) and lower rewards for both delegators and stake pool owners. Based on what we have learned from both the Incentivized Testnet (ITN) and the Haskell Shelley testnet, we know that our community is highly motivated to set up pools and support the chain with hundreds within a matter of weeks.

* K * được chọn càng cao, hệ thống càng phân cấp.
Nhưng * K * cao hơn cũng dẫn đến một hệ thống kém hiệu quả hơn (chi phí cao hơn, tiêu thụ năng lượng nhiều hơn) và phần thưởng thấp hơn cho cả ủy quyền và chủ sở hữu nhóm cổ phần.
Dựa trên những gì chúng tôi đã học được từ cả Testnet khuyến khích (ITN) và Haskell Shelley Testnet, chúng tôi biết rằng cộng đồng của chúng tôi có động lực cao để thiết lập các nhóm và hỗ trợ chuỗi với hàng trăm trong vài tuần.

This tells us that some measure of decentralization can – and will – happen relatively quickly. But decentralization alone is not enough. Cardano needs a long term commitment from its operators, and conversely, operators need to be sufficiently incentivized to keep supporting the system.

Điều này cho chúng ta biết rằng một số biện pháp phân cấp có thể - và sẽ - xảy ra tương đối nhanh chóng.
Nhưng sự phân cấp một mình là không đủ.
Cardano cần một cam kết lâu dài từ các nhà khai thác của mình và ngược lại, các nhà khai thác cần được khuyến khích đầy đủ để tiếp tục hỗ trợ hệ thống.

To strike a balance between decentralization and these incentives for stake pool operators, we are proposing an initial *k*=150 and then to gradually increase that value. We believe this will ensure that the system is stable and efficient in the beginning, and can gradually grow over time to become more decentralized (and even more secure) later on:

Để đạt được sự cân bằng giữa phân cấp và các ưu đãi này cho các nhà khai thác nhóm cổ phần, chúng tôi đang đề xuất một *k *= 150 ban đầu và sau đó tăng dần giá trị đó.
Chúng tôi tin rằng điều này sẽ đảm bảo rằng hệ thống ổn định và hiệu quả ngay từ đầu và có thể dần dần phát triển theo thời gian để trở nên phi tập trung hơn (và thậm chí an toàn hơn) sau này:

![](img/2020-06-25-iterating-for-growth-with-iohk.010.png)

The number of 150 stake pools of roughly equal size makes Cardano an order of magnitude more decentralized than any other blockchain. And this is only the beginning. There is no reason why there could not be thousands of stake pools in the future.

Số lượng 150 nhóm cổ phần có kích thước gần bằng với Cardano trở thành một thứ tự lớn hơn so với bất kỳ blockchain nào khác.
Và đây mới chỉ là khởi đầu.
Không có lý do tại sao không thể có hàng ngàn cổ phần trong tương lai.

# **Monetary expansion**

# ** Mở rộng tiền tệ **

Staking rewards for both delegators and stake pool operators are taken from two sources; transaction fees and monetary expansion. Specifically, every epoch, all the transaction fees from every transaction from all blocks produced during that epoch are put into a virtual 'pot'. Additionally, a fixed percentage, *ρ*, of the remaining ada reserves is added to that pot. Then a certain percentage, *τ*, of the pot is sent to the treasury, the rest is used as epoch rewards.

Phần thưởng đặt cược cho cả ủy quyền và người vận hành nhóm cổ phần được lấy từ hai nguồn;
Phí giao dịch và mở rộng tiền tệ.
Cụ thể, mỗi kỷ nguyên, tất cả các khoản phí giao dịch từ mọi giao dịch từ tất cả các khối được tạo ra trong thời đại đó đều được đưa vào một 'nồi' ảo.
Ngoài ra, một tỷ lệ phần trăm cố định, *ρ *, của dự trữ ADA còn lại được thêm vào nồi đó.
Sau đó, một tỷ lệ phần trăm nhất định, *τ *, của nồi được gửi đến Kho bạc, phần còn lại được sử dụng làm phần thưởng kỷ nguyên.

This mechanism ensures that in the beginning, when the number of transactions is still relatively low, because users are just starting to build their business on Cardano, the portion of rewards taken from the reserves is high. This provides a great incentive for early adopters to move quickly and benefit from the high initial rewards. Over time, as transaction volume increases, the additional fees compensate for dwindling reserves.

Cơ chế này đảm bảo rằng ngay từ đầu, khi số lượng giao dịch vẫn còn tương đối thấp, bởi vì người dùng mới bắt đầu xây dựng doanh nghiệp của họ trên Cardano, phần phần thưởng được lấy từ dự trữ cao.
Điều này cung cấp một động lực lớn cho những người chấp nhận sớm để di chuyển nhanh chóng và được hưởng lợi từ phần thưởng ban đầu cao.
Theo thời gian, khi khối lượng giao dịch tăng lên, các khoản phí bổ sung bù đắp cho dự trữ giảm dần.

This mechanism also ensures that available rewards are predictable and change gradually. There will be no sudden 'jumps' comparable to bitcoin halving events every four years. Instead, the fixed percentage taken from remaining reserves every epoch guarantees a smooth exponential decline.

Cơ chế này cũng đảm bảo rằng phần thưởng có sẵn là có thể dự đoán được và thay đổi dần dần.
Sẽ không có 'bước nhảy' đột ngột nào tương đương với các sự kiện giảm một nửa Bitcoin cứ sau bốn năm.
Thay vào đó, tỷ lệ phần trăm cố định được lấy từ dự trữ còn lại mỗi epoch đảm bảo sự suy giảm theo cấp số nhân trơn tru.

So what value should *ρ* have? And how much should go to the treasury? This is again a trade off: higher values of *ρ* mean higher rewards for everybody initially and a treasury that fills faster. But higher values of *ρ* also mean faster reserve depletion. It is certainly important, especially in the beginning, to pay high rewards and incentivize early adopters. But it is also important to provide a long term perspective for all stakeholders.

Vậy giá trị nào * ρ * có?
Và bao nhiêu nên đi vào Kho bạc?
Đây một lần nữa là một giao dịch: giá trị cao hơn của * * có nghĩa là phần thưởng cao hơn cho mọi người ban đầu và một kho bạc lấp đầy nhanh hơn.
Nhưng các giá trị cao hơn của * ρ * cũng có nghĩa là sự suy giảm dự trữ nhanh hơn.
Nó chắc chắn là quan trọng, đặc biệt là ngay từ đầu, để trả phần thưởng cao và khuyến khích những người chấp nhận sớm.
Nhưng điều quan trọng là cung cấp một quan điểm dài hạn cho tất cả các bên liên quan.

As explained above, Cardano will never run out of reserves; look instead at an exponential decay. To get a feeling for the impact of a specific value of *ρ*, one can calculate the 'reserve half life', the time it takes for half of the reserve to have been used up.

Như đã giải thích ở trên, Cardano sẽ không bao giờ hết dự trữ;
Thay vào đó, hãy nhìn vào một sự phân rã theo cấp số nhân.
Để có được cảm giác về tác động của một giá trị cụ thể là * * *, người ta có thể tính toán 'cuộc sống nửa dự trữ', thời gian cần một nửa dự trữ đã được sử dụng hết.

After much deliberation, we arrived at a suggestion of 0.22% for *ρ*. When you crunch the numbers, you get around four to five years as 'reserve half life' for this. In other words, every four to five years, half of the remaining reserve will be used. This is close to the 'bitcoin half life' of circa four years, so Cardano reserves will deplete at about the same rate as bitcoin reserves.

Sau nhiều lần cân nhắc, chúng tôi đã đi đến một gợi ý 0,22% cho * *.
Khi bạn khủng hoảng các con số, bạn sẽ nhận được khoảng bốn đến năm năm là 'Life Life' cho việc này.
Nói cách khác, cứ sau bốn đến năm năm, một nửa dự trữ còn lại sẽ được sử dụng.
Điều này gần với 'Bitcoin Half Life' của Circa bốn năm, vì vậy dự trữ Cardano sẽ giảm dần với tốc độ tương đương với dự trữ Bitcoin.

It is worth noting here that it took Bitcoin around eight years to reach its peak of maximum adoption and price. We therefore feel that it makes sense to expect Cardano transaction volume and exchange rate to increase sufficiently over the next eight years to more than make up for the decrease of monetary expansion during that time.

Điều đáng chú ý ở đây là phải mất Bitcoin khoảng tám năm để đạt đến đỉnh cao của việc áp dụng và giá tối đa.
Do đó, chúng tôi cảm thấy rằng thật hợp lý khi mong đợi khối lượng giao dịch Cardano và tỷ giá hối đoái sẽ tăng đủ trong tám năm tới để nhiều hơn bù đắp cho việc giảm mở rộng tiền tệ trong thời gian đó.

# **From reserves to treasury**

# ** Từ dự trữ đến Kho bạc **

We also propose an initial value of 5% for *τ*, the percentage of rewards automatically going to the treasury every epoch. This means that at least 380,000,000 ada will be sent from the reserves to the treasury over the next 5 years.

Chúng tôi cũng đề xuất giá trị ban đầu là 5% cho *τ *, tỷ lệ phần trăm phần thưởng tự động đi đến Kho bạc mỗi kỷ nguyên.
Điều này có nghĩa là ít nhất 380.000.000 ADA sẽ được gửi từ dự trữ đến Kho bạc trong 5 năm tới.

However, the real amount going to the treasury will be significantly higher. First of all – again taking learnings from the ITN, but also predicting the use of ada in the future – it’s unreasonable to assume that all ada will be delegated. Some of it will be locked-up in exchanges, be transacted and used in various smart contracts. The ada that is not being delegated will produce unclaimed awards. Those 'unclaimed rewards' also go to the treasury, which will bump the amount to around 1,900,000,000 ada.

Tuy nhiên, số tiền thực sự đi đến Kho bạc sẽ cao hơn đáng kể.
Trước hết - một lần nữa học hỏi từ ITN, nhưng cũng dự đoán việc sử dụng ADA trong tương lai - thật không hợp lý khi cho rằng tất cả ADA sẽ được ủy quyền.
Một số trong số đó sẽ được khóa trong các sàn giao dịch, được giao dịch và sử dụng trong các hợp đồng thông minh khác nhau.
ADA không được ủy thác sẽ tạo ra các giải thưởng không có người nhận.
Những 'phần thưởng không được yêu cầu' cũng đi vào Kho bạc, sẽ tăng số tiền lên tới khoảng 1.900.000.000 ADA.

Secondly, we do not expect the pledge of most pools to be particularly high, just high enough to make it unattractive to launch a Sybil attack. The difference between potential pool rewards with a very high pledge and pools with the more realistic pledge level we expect goes to the treasury as well and will add an additional 1,000,000,000 ada over the first five years. The sum of all the ada flowing to the treasury means that there will be sufficient funds to pay for new exciting features and extensions for the foreseeable future.

Thứ hai, chúng tôi không hy vọng cam kết của hầu hết các nhóm sẽ đặc biệt cao, chỉ đủ cao để khiến nó không hấp dẫn khi tiến hành một cuộc tấn công Sybil.
Sự khác biệt giữa các phần thưởng nhóm tiềm năng với cam kết và hồ bơi rất cao với mức cam kết thực tế hơn mà chúng tôi mong đợi cũng được dành cho Kho bạc và sẽ bổ sung thêm 1.000.000.000 ADA trong năm năm đầu tiên.
Tổng của tất cả các ADA chảy vào Kho bạc có nghĩa là sẽ có đủ tiền để trả cho các tính năng và gia hạn thú vị mới trong tương lai gần.

# **Pledge influence factor & minimum operational cost settings**

# ** Cài đặt chi phí hoạt động ảnh hưởng & cam kết và cài đặt chi phí hoạt động tối thiểu **

Ada that is pledged by pool owners provides essential protection against 'Sybil' attacks by ensuring that delegated stake is not excessively attracted to pools whose owners try to attack the system by creating a large number of pools without themselves owning a lot of stake. Myself, Kevin Hammond and Duncan Coutts covered this in some detail recently on the [Cardano Effect](https://www.youtube.com/watch?v=X-ziLksiPOE) show.

ADA được các chủ sở hữu hồ bơi cam kết cung cấp sự bảo vệ thiết yếu chống lại các cuộc tấn công 'Sybil' bằng cách đảm bảo rằng cổ phần được ủy quyền không bị thu hút quá mức vào các nhóm mà chủ sở hữu cố gắng tấn công hệ thống bằng cách tạo ra một số lượng lớn các nhóm mà không cần phải sở hữu nhiều cổ phần.
Bản thân tôi, Kevin Hammond và Duncan Coutts đã đề cập đến điều này một cách chi tiết gần đây về [Hiệu ứng Cardano] (https://www.youtube.com/watch?v=x-Zilksipoe).

The pledge influence factor directly affects the rewards that a pool earns: the higher the influence factor, the more of a difference a higher pledge makes on rewards. A higher influence factor increases the level of Sybil protection and makes the system safer and more secure, but it also gives an advantage to stake pool owners that can afford a higher pledge.

Yếu tố ảnh hưởng cam kết ảnh hưởng trực tiếp đến phần thưởng mà một nhóm kiếm được: yếu tố ảnh hưởng càng cao, càng có nhiều sự khác biệt, cam kết càng cao về phần thưởng.
Một yếu tố ảnh hưởng cao hơn làm tăng mức độ bảo vệ Sybil và làm cho hệ thống an toàn và an toàn hơn, nhưng nó cũng mang lại lợi thế cho chủ sở hữu nhóm có thể đủ khả năng cam kết cao hơn.

Higher pledge can be used to compensate for higher operational costs, meaning that a pool with relatively high costs can maintain suitable rewards and remain attractive to delegators by increasing its pledge. We have tested a variety of pledge influence factors under various real world conditions (about a million simulations in all). The influence factor can range between 0 and infinity. Our chosen initial setting of 0.3 is designed to balance the level of Sybil protection against the required pledge.

Cam kết cao hơn có thể được sử dụng để bù cho chi phí hoạt động cao hơn, có nghĩa là một nhóm có chi phí tương đối cao có thể duy trì phần thưởng phù hợp và vẫn hấp dẫn đối với các ủy viên bằng cách tăng cam kết của nó.
Chúng tôi đã thử nghiệm một loạt các yếu tố ảnh hưởng cam kết trong các điều kiện thế giới thực khác nhau (tất cả khoảng một triệu mô phỏng).
Yếu tố ảnh hưởng có thể nằm trong khoảng từ 0 đến vô cùng.
Cài đặt ban đầu được chọn của chúng tôi là 0,3 được thiết kế để cân bằng mức độ bảo vệ SYBIL so với cam kết cần thiết.

There is no minimal pledge, though. Pool operators can set the pledge as low or as high as they like. Rewards are influenced by their choice, but there is no 'hard' rule forcing them to pledge a specific amount. This means that ultimately, pool pledges will be as high as pool owners are willing to make them, and it will be up to our community to find a sweet spot between protection against attacks, economic considerations and the desire for fairness and equal opportunity.

Không có cam kết tối thiểu, mặc dù.
Các nhà khai thác hồ bơi có thể đặt cam kết thấp hoặc cao như họ muốn.
Phần thưởng bị ảnh hưởng bởi sự lựa chọn của họ, nhưng không có quy tắc 'khó' buộc họ phải cam kết một số tiền cụ thể.
Điều này có nghĩa là cuối cùng, các cam kết bể bơi sẽ cao như chủ sở hữu hồ bơi sẵn sàng tạo ra chúng, và sẽ tùy thuộc vào cộng đồng của chúng tôi để tìm một điểm ngọt ngào giữa các cuộc tấn công, cân nhắc kinh tế và mong muốn công bằng và cơ hội bình đẳng.

The minimum operational cost setting ensures that the pledge influence factor is effective, by avoiding a 'race to the bottom' where pool owners claim excessively low operating costs in order to gain a competitive advantage. While this might benefit ada stakeholders in the short term, the long-term effect would be to risk the health of the Cardano network by disincentivizing professional pool operation.

Cài đặt chi phí hoạt động tối thiểu đảm bảo rằng yếu tố ảnh hưởng cam kết có hiệu quả, bằng cách tránh 'cuộc đua xuống đáy' nơi chủ sở hữu nhóm yêu cầu chi phí vận hành quá mức thấp để đạt được lợi thế cạnh tranh.
Mặc dù điều này có thể có lợi cho các bên liên quan ADA trong thời gian ngắn, nhưng hiệu quả dài hạn sẽ là nguy cơ sức khỏe của mạng lưới Cardano bằng cách không thể phân biệt hoạt động nhóm chuyên nghiệp.

![](img/2020-06-25-iterating-for-growth-with-iohk.011.png)

Distribution of Typical Pool Operating Costs per pool per year, obtained from a survey of experienced pool operators in May 2020.

Phân phối chi phí vận hành nhóm điển hình mỗi nhóm mỗi năm, được lấy từ một cuộc khảo sát của các nhà khai thác bể bơi có kinh nghiệm vào tháng 5 năm 2020.

Genuine low cost operators can greatly benefit from the minimum operational cost, because the difference between the minimal cost and their actual cost provides them with additional income on top of their margin and their staking rewards. Our research shows that typical operating costs are expected to be in the $2,000-$15,000 range per pool per year, as shown in the diagram above. We have therefore chosen a setting of $2,000 for the minimum operational cost.

Các nhà khai thác chi phí thấp có thể được hưởng lợi rất nhiều từ chi phí hoạt động tối thiểu, bởi vì sự khác biệt giữa chi phí tối thiểu và chi phí thực tế của họ cung cấp cho họ thu nhập bổ sung trên mức ký quỹ và phần thưởng đặt cược của họ.
Nghiên cứu của chúng tôi cho thấy rằng chi phí vận hành điển hình dự kiến sẽ nằm trong phạm vi $ 2.000- $ 15.000 mỗi nhóm mỗi năm, như thể hiện trong sơ đồ ở trên.
Do đó, chúng tôi đã chọn cài đặt 2.000 đô la cho chi phí hoạt động tối thiểu.

![](img/2020-06-25-iterating-for-growth-with-iohk.012.png)

Estimated Range of Average Return on Investment (ROI) for Stake Pools assuming a Monetary Expansion Rate of 0.22% per epoch.

Phạm vi lợi nhuận trung bình của đầu tư trung bình (ROI) đối với nhóm cổ phần cho rằng tỷ lệ mở rộng tiền tệ là 0,22% mỗi epoch.

Finally, we calculated the expected returns for stake pools under a range of different real world scenarios (about 150,000 pools in total). We used the settings for the influence factor, monetary expansion and minimum cost that were given above and varied the targeted number of pools between 150 and 500. Our results show that given the distribution of costs that we showed in the diagram above, stake pools will achieve sustainable ROIs of between 6%-6.5% on average, using today’s ada to dollar conversion rate. The ROIs would, of course, be even better if the value of Ada were to appreciate.

Cuối cùng, chúng tôi đã tính toán lợi nhuận dự kiến cho các nhóm cổ phần trong một loạt các kịch bản trong thế giới thực khác nhau (tổng cộng khoảng 150.000 nhóm).
Chúng tôi đã sử dụng các cài đặt cho yếu tố ảnh hưởng, mở rộng tiền tệ và chi phí tối thiểu được đưa ra ở trên và thay đổi số lượng nhóm được nhắm mục tiêu trong khoảng từ 150 đến 500. Kết quả của chúng tôi cho thấy rằng việc phân phối chi phí mà chúng tôi đã hiển thị trong sơ đồ trên, các nhóm cổ phần sẽ
đạt được ROI bền vững trung bình từ 6% -6,5%, sử dụng tỷ lệ chuyển đổi ADA sang đô la ngày nay.
ROI, tất nhiên, sẽ thậm chí còn tốt hơn nếu giá trị của ADA được đánh giá cao.

# **Conclusion**

# **Sự kết luận**

Choosing good values for all Cardano Shelley parameters is a hard and complicated endeavor, because a lot of concerns have to be balanced – security, efficiency and stability of the system on the one hand versus economic viability for stake pool operators and delegators and long-term sustainability of the ecosystem on the other hand.

Chọn các giá trị tốt cho tất cả các thông số Cardano Shelley là một nỗ lực khó khăn và phức tạp, bởi vì rất nhiều mối quan tâm phải được cân bằng-bảo mật, hiệu quả và sự ổn định của hệ thống một mặt so với khả năng kinh tế đối với các nhà điều hành nhóm và ủy quyền lâu dài và lâu dài
Tính bền vững của hệ sinh thái mặt khác.

No other blockchain has ever done what we are going to do, we are charting new territory with every step and move at the cutting edge of science and technology, so we can’t rely on existing data and statistics or past experience, but have to use educated guesses and mathematical models, which can never be perfect, more often than not.

Không có blockchain nào khác đã từng làm những gì chúng ta sẽ làm, chúng ta đang lập biểu đồ lãnh thổ mới với mỗi bước và di chuyển ở mức độ tiên tiến của khoa học và công nghệ, vì vậy chúng ta không thể dựa vào dữ liệu và thống kê hiện có hoặc kinh nghiệm trong quá khứ, nhưng phải
Sử dụng các dự đoán có học thức và mô hình toán học, không bao giờ có thể hoàn hảo, thường xuyên hơn không.

We did our best to come up with a reasonable proposal, but we know it will have to be improved upon over time. The values proposed here are just a start, and we will closely work with our Community to refine and adjust them over the coming months and years.

Chúng tôi đã làm hết sức mình để đưa ra một đề xuất hợp lý, nhưng chúng tôi biết rằng nó sẽ phải được cải thiện theo thời gian.
Các giá trị được đề xuất ở đây chỉ là một khởi đầu, và chúng tôi sẽ làm việc chặt chẽ với cộng đồng của chúng tôi để tinh chỉnh và điều chỉnh chúng trong những tháng và năm tới.

