# Looking to the future of Haskell and JavaScript for Plutus
### **Smart contracts use the GHCJS cross-compiler to translate off-chain code**
![](img/2020-06-04-looking-to-the-future-of-haskell-and-javascript-for-plutus.002.png) 4 June 2020![](img/2020-06-04-looking-to-the-future-of-haskell-and-javascript-for-plutus.002.png)[ Luite Stegeman](tmp//en/blog/authors/luite-stegeman/page-1/)![](img/2020-06-04-looking-to-the-future-of-haskell-and-javascript-for-plutus.003.png) 8 mins read

![Luite Stegeman](img/2020-06-04-looking-to-the-future-of-haskell-and-javascript-for-plutus.004.png)[](tmp//en/blog/authors/luite-stegeman/page-1/)
### [**Luite Stegeman**](tmp//en/blog/authors/luite-stegeman/page-1/)
Software Engineer

Engineering

- ![](img/2020-06-04-looking-to-the-future-of-haskell-and-javascript-for-plutus.005.png)[](mailto:luite.stegeman@iohk.io "Email")
- ![](img/2020-06-04-looking-to-the-future-of-haskell-and-javascript-for-plutus.006.png)[](https://github.com/luite "GitHub")

![Looking to the future of Haskell and JavaScript for Plutus](img/2020-06-04-looking-to-the-future-of-haskell-and-javascript-for-plutus.007.jpeg)

*This is the second of the Developer Deep Dive technical posts from our Haskell team. This occasional series offers a candid glimpse into the core elements of the Cardano platform and protocols, and gives insights into the engineering choices that have been made. Here, we outline some of the work that has been going on to improve the libraries and developer tools for Plutus, Cardanoâ€™s smart contract platform.*

*Đây là phần thứ hai của nhà phát triển bài viết kỹ thuật lặn sâu từ nhóm Haskell của chúng tôi.
Sê -ri thỉnh thoảng này cung cấp một cái nhìn thẳng thắn về các yếu tố cốt lõi của nền tảng và giao thức Cardano, và đưa ra những hiểu biết sâu sắc về các lựa chọn kỹ thuật đã được thực hiện.
Ở đây, chúng tôi phác thảo một số công việc đang diễn ra để cải thiện các thư viện và công cụ phát triển cho Plutus, nền tảng hợp đồng thông minh của Cardano.

## **Introduction**

## **Giới thiệu**

At IOHK we are developing the Plutus smart contract platform for the Cardano blockchain. A Plutus contract is a Haskell program that is partly compiled to on-chain Plutus Core code and partly to off-chain code. On-chain code is run by Cardano network nodes using the interpreter for Plutus Core, the smart contract language embedded in the Cardano ledger. This is how the network verifies transactions. Off-chain code is for tasks such as setting up the contract and for user interaction. It runs inside the wallet of each user of the contract, on a node.js runtime.

Tại IOHK, chúng tôi đang phát triển nền tảng hợp đồng thông minh Plutus cho Blockchain Cardano.
Hợp đồng Plutus là một chương trình Haskell được tổng hợp một phần cho mã lõi Plutus trên chuỗi và một phần cho mã ngoài chuỗi.
Mã trên chuỗi được điều hành bởi các nút mạng Cardano bằng cách sử dụng trình thông dịch cho Plutus Core, ngôn ngữ hợp đồng thông minh được nhúng trong sổ cái Cardano.
Đây là cách mạng xác minh các giao dịch.
Mã ngoài chuỗi dành cho các tác vụ như thiết lập hợp đồng và cho tương tác của người dùng.
Nó chạy bên trong ví của mỗi người dùng hợp đồng, trên thời gian chạy Node.js.

Compiling the off-chain part of a Plutus contract therefore involves translating the off-chain code to JavaScript. To accomplish this, we use GHCJS, the Glasgow Haskell to JavaScript cross-compiler.

Do đó, biên dịch phần ngoài chuỗi của hợp đồng Plutus liên quan đến việc dịch mã ngoài chuỗi sang JavaScript.
Để thực hiện điều này, chúng tôi sử dụng GHCJS, Glasgow Haskell đến trình biên dịch chéo JavaScript.

In the past year, we haven't made many changes in the GHCJS code generator. Instead, we did some restructuring to make compiling things with GHCJS more reliable and predictable as well as adding support for Windows and making use of the most recent Cabal features. This post gives an overview of what has happened, and a brief look at what's in store for this year.

Trong năm qua, chúng tôi đã không thực hiện nhiều thay đổi trong trình tạo mã GHCJS.
Thay vào đó, chúng tôi đã thực hiện một số tái cấu trúc để tạo ra mọi thứ với GHCJ đáng tin cậy hơn và có thể dự đoán được cũng như thêm hỗ trợ cho Windows và sử dụng các tính năng Cabal gần đây nhất.
Bài đăng này đưa ra một cái nhìn tổng quan về những gì đã xảy ra, và một cái nhìn ngắn gọn về những gì trong cửa hàng trong năm nay.

## **Cabal support**

## ** Hỗ trợ Cabal **

When installing a package with GHCJS, you probably use the --ghcjs command line flag or include compiler: ghcjs in your configuration file. This activates the [ghcjs compiler flavor](https://hackage.haskell.org/package/Cabal-3.0.0.0/docs/Distribution-Simple-GHCJS.html) in Cabal. The ghcjs flavor is based on the ghc flavor and adds features such as support for running set-up scripts built by GHCJS, and for adding JavaScript sources.

Khi cài đặt gói với GHCJS, bạn có thể sử dụng cờ dòng lệnh --GHCJS hoặc bao gồm trình biên dịch: GHCJ trong tệp cấu hình của bạn.
Điều này kích hoạt [hương vị trình biên dịch GHCJS] (https://hackage.haskell.org/package/cabal-3.0.0.0/docs/distribution-simple-ghcjs.html) trong cabal.
Hương vị GHCJS dựa trên hương vị GHC và thêm các tính năng như hỗ trợ để chạy các tập lệnh thiết lập được xây dựng bởi GHCJS và để thêm các nguồn JavaScript.

Cabal has introduced many features in recent years, including support for backpack, Nix-style local builds, multiple (named) libraries per package, and per-component build plans. Unfortunately, the new features resulted in many changes to the code base, and maintenance for the ghcjs flavor fell behind for some time. We have brought GHCJS support up to date again in version 3.0. If you want to use the new-style build features, make sure that you use [cabal-install](https://hackage.haskell.org/package/cabal-install) version 3 or later.

Cabal đã giới thiệu nhiều tính năng trong những năm gần đây, bao gồm hỗ trợ cho ba lô, các bản dựng địa phương kiểu NIX, nhiều thư viện (được đặt tên) trên mỗi gói và các kế hoạch xây dựng trên mỗi thành phần.
Thật không may, các tính năng mới dẫn đến nhiều thay đổi đối với cơ sở mã và bảo trì cho hương vị GHCJS bị tụt lại trong một thời gian.
Chúng tôi đã mang lại hỗ trợ GHCJS một lần nữa trong phiên bản 3.0.
Nếu bạn muốn sử dụng các tính năng xây dựng kiểu mới, hãy đảm bảo rằng bạn sử dụng [cabal-install] (https://hackage.haskell.org/package/cabal-install) phiên bản 3 trở lên.

The differences between the ghcjs and ghc compiler flavors are minor, and cross-compilation support in Cabal has been improving. Therefore, we hope that eventually we will be able to drop the ghcjs compiler flavor altogether. The extensions would instead be added as platform-specific behaviour in the ghc flavor.

Sự khác biệt giữa các hương vị trình biên dịch GHCJ và GHC là nhỏ và hỗ trợ biên dịch chéo trong Cabal đã được cải thiện.
Do đó, chúng tôi hy vọng rằng cuối cùng chúng tôi sẽ có thể bỏ hoàn toàn hương vị của trình biên dịch GHCJS.
Thay vào đó, các tiện ích mở rộng sẽ được thêm vào như hành vi cụ thể của nền tảng trong hương vị GHC.

## **Compiler plug-ins**

## ** Trình cắm trình biên dịch **

GHC allows the compiler to be extended with [plug-ins](https://downloads.haskell.org/ghc/8.8.1/docs/html/users_guide/extending_ghc.html#compiler-plugins), which can change aspects of the compilation pipeline. For example, plug-ins can introduce new optimization features or extend the typechecker.

GHC cho phép trình biên dịch được mở rộng với [plug-in] (https://doads.haskell.org/ghc/8.8.1/docs/html/users_guide/extending_ghc.html#compiler-plugins)
Các đường ống biên dịch.
Ví dụ, các trình cắm có thể giới thiệu các tính năng tối ưu hóa mới hoặc mở rộng typechecker.

Unlike Template Haskell, which is separated from the compiler through the [Quasi typeclass](https://hackage.haskell.org/package/template-haskell-2.12.0.0/docs/Language-Haskell-TH-Syntax.html#t:Quasi) abstraction, plug-ins can directly use the whole GHC API. This makes the â€˜[external interpreter](https://gitlab.haskell.org/ghc/ghc/wikis/commentary/compiler/external-interpreter)â€™ approach that GHCJS introduced for running Template Haskell in a cross-compiler unsuitable for compiler plug-ins. Instead, plug-ins need to be built for the build platform (that runs GHC).

Không giống như mẫu Haskell, được tách ra khỏi trình biên dịch thông qua [Quasi typeclass] (https://hackage.haskell.org/package/template-haskell
: Quasi) Trừu tượng, trình cắm có thể trực tiếp sử dụng toàn bộ API GHC.
Điều này làm cho â € ˜ [Thông dịch viên bên ngoài] (https://gitlab.haskell.org/ghc/ghc/wikis/commentary/compiler/external-interpreter)
Trình biên dịch không phù hợp cho trình cắm trình biên dịch.
Thay vào đó, các plugin cần được xây dựng cho nền tảng xây dựng (chạy GHC).

In 2016, GHCJS introduced experimental support for compiler plug-ins. This relied on looking up the plug-in in the GHCJS package database and then trying to find a close match for the plug-in package and module in the GHC package database. We have now [added a new flag](https://github.com/ghcjs/ghc/commit/21aee8d3e6ff3991cf17b59b0992829de1565265) to point GHCJS to packages runnable on the build system. This makes plug-ins usable again with new-style builds and other â€˜exoticâ€™ package database configurations.

Năm 2016, GHCJS đã giới thiệu hỗ trợ thử nghiệm cho trình cắm trình biên dịch.
Điều này phụ thuộc vào việc tìm kiếm trình cắm trong cơ sở dữ liệu gói GHCJS và sau đó cố gắng tìm một kết quả gần gũi cho gói cắm và mô-đun trong cơ sở dữ liệu Gói GHC.
Bây giờ chúng tôi đã [thêm một lá cờ mới] (https://github.com/ghcjs/ghc/commit/21AEE8D3E6FF3991CF17B59B0992829DE1565265)
Điều này làm cho plugin có thể sử dụng lại với các bản dựng kiểu mới và các cấu hình cơ sở dữ liệu gói "Exexotic".

In principle, our new flag can make plug-ins work on any GHC cross-compiler, but the requirement to also build the plug-in with the cross-compiler is quite ugly. We are working on removing this requirement followed by merging plug-in support for cross-compilers into upstream GHC (see [ticket 14335](https://gitlab.haskell.org/ghc/ghc/issues/14335) and [ticket 17957](https://gitlab.haskell.org/ghc/ghc/issues/17957)).

Về nguyên tắc, cờ mới của chúng tôi có thể làm cho các trình cắm hoạt động trên bất kỳ trình biên dịch chéo GHC nào, nhưng yêu cầu cũng xây dựng trình cắm với trình biên dịch chéo là khá xấu.
Chúng tôi đang làm việc để loại bỏ yêu cầu này theo sau là hợp nhất hỗ trợ cắm cho các trình biên dịch chéo vào GHC ngược dòng (xem [vé 14335] (https://gitlab.haskell.org/ghc/ghc/issues/14335) và [vé 17957
] (https://gitlab.haskell.org/ghc/ghc/issues/17957)).

## **Emscripten toolchain**

## ** Công cụ EMScripten **

Long, long ago, GHCJS worked on Windows. One or two brave souls might have actually used it! Its boot packages (the packages built by ghcjs-boot) would include the Win32 package on the Windows build platform. The reason for this was the Cabal configuration with GHCJS. Cabalâ€™s os(win32) flag would be set if the build platform was Windows. At the time it was easiest to just patch the package to build without errors with GHCJS, and include it in the boot packages. However, the Win32 package didn't really work, and keeping it up to date was a maintenance burden. At some point it fell behind and GHCJS didn't work on Windows any more.

Long, Long Long, GHCJs đã làm việc trên Windows.
Một hoặc hai linh hồn dũng cảm có thể đã thực sự sử dụng nó!
Các gói khởi động của nó (các gói được xây dựng bởi GHCJS-Boot) sẽ bao gồm gói Win32 trên nền tảng Windows Build.
Lý do cho điều này là cấu hình Cabal với GHCJS.
Cờ HĐH (Win32) của Cabal sẽ được đặt nếu nền tảng xây dựng là Windows.
Vào thời điểm đó, dễ nhất chỉ vá gói để xây dựng mà không có lỗi với GHCJ và đưa nó vào các gói khởi động.
Tuy nhiên, gói Win32 không thực sự hoạt động và giữ cho nó cập nhật là gánh nặng bảo trì.
Tại một số thời điểm, nó bị tụt lại phía sau và GHCJ không hoạt động trên Windows nữa.

The boot packages having to include Win32 on Windows was indicative of poor separation between the build platform (which runs the compiler) and the host platform (which runs the executable produced by the compiler). This was caused by the lack of a complete C toolchain for GHCJS. Many packages don't just have Haskell code, but also have files produced by a C toolchain, for example via an [Autotools configure](https://www.gnu.org/software/autoconf/) script or [hsc2hs](https://hackage.haskell.org/package/hsc2hs).

Các gói khởi động phải bao gồm Win32 trên Windows là dấu hiệu cho thấy sự phân tách kém giữa nền tảng xây dựng (chạy trình biên dịch) và nền tảng máy chủ (chạy thực thi do trình biên dịch sản xuất).
Điều này được gây ra bởi việc thiếu một công cụ C hoàn chỉnh cho GHCJS.
Nhiều gói không chỉ có mã Haskell, mà còn có các tệp được tạo bởi một công cụ C, ví dụ thông qua [cấu hình autotools] (https://www.gnu.org/software/autoconf/)
https://hackage.haskell.org/package/hsc2hs).

The GHCJS approach was to include some pre-generated files, and use the build platform C toolchain (the same that GHC would use) for everything else, hoping that it wouldn't break. If it did break, we would patch the package.

Cách tiếp cận GHCJS là bao gồm một số tệp được tạo sẵn và sử dụng công cụ Build Platform C (giống như GHC sẽ sử dụng) cho mọi thứ khác, hy vọng rằng nó sẽ không bị hỏng.
Nếu nó bị phá vỡ, chúng tôi sẽ vá gói.

In recent years, the web browser as a compilation target has steadily been gaining more traction. Emscripten has been providing a C toolchain for many years, and has recently switched from its own compiler backend to the Clang compiler with the standard LLVM backend.

Trong những năm gần đây, trình duyệt web như một mục tiêu tổng hợp đã liên tục đạt được lực kéo hơn.
EMScripten đã cung cấp một công cụ C trong nhiều năm và gần đây đã chuyển từ phụ trợ trình biên dịch của riêng mình sang trình biên dịch Clang với phụ trợ LLVM tiêu chuẩn.

Clang has been supported by GHC as a C toolchain for a while. It can output asm.js and WebAssembly code that can run directly in the browser. Unfortunately, users of the compiler cannot yet directly interact with compiled C code through the C FFI (foreign import ccall) in GHCJS. But having a C toolchain allows packages that depend on configure scripts or hsc2hs to compile much more reliably. This fixes some [long-standing build problems](https://github.com/ghcjs/ghcjs/issues/702) and allows us to support Windows again. We thought this is already worth the additional dependency.

Clang đã được GHC hỗ trợ như một công cụ C trong một thời gian.
Nó có thể xuất ra mã ASM.JS và Webassugging có thể chạy trực tiếp trong trình duyệt.
Thật không may, người dùng của trình biên dịch chưa thể tương tác trực tiếp với mã C được biên dịch thông qua C FFI (CCALL nhập khẩu nước ngoài) trong GHCJS.
Nhưng có một công cụ C cho phép các gói phụ thuộc vào cấu hình tập lệnh hoặc HSC2HS để biên dịch đáng tin cậy hơn nhiều.
Điều này khắc phục một số [vấn đề xây dựng lâu dài] (https://github.com/ghcjs/ghcjs/issues/702) và cho phép chúng tôi hỗ trợ Windows một lần nữa.
Chúng tôi nghĩ rằng điều này đã có giá trị phụ thuộc bổ sung.

A variant of GHCJS 8.6 using the Emscripten toolchain is available in the ghc-8.6-emscripten branch, which can be installed on Windows. This time around, the set of boot packages is the same on every build platform. Emscripten is planned to be the standard toolchain in GHCJS 8.8 onwards.

Một biến thể của GHCJS 8.6 sử dụng công cụ EMScripten có sẵn trong nhánh GHC-8.6-Demscripten, có thể được cài đặt trên Windows.
Lần này, tập hợp các gói khởi động giống nhau trên mọi nền tảng xây dựng.
EMScripten được lên kế hoạch là công cụ tiêu chuẩn trong GHCJS 8.8 trở đi.

## **Code organization**

## ** Tổ chức mã **

At some point in the early days, GHCJS was implemented as a patch to GHC. It generated JavaScript from the STG intermediate code that a regular GHC installation produced. This made it easy to install packages with GHCJS. Just install normally and get JavaScript for free. Even Template Haskell worked!

Tại một số thời điểm trong những ngày đầu, GHCJS đã được triển khai như một bản vá cho GHC.
Nó tạo ra JavaScript từ mã trung gian STG mà một bản cài đặt GHC thông thường được tạo ra.
Điều này giúp bạn dễ dàng cài đặt các gói với GHCJ.
Chỉ cần cài đặt bình thường và nhận JavaScript miễn phí.
Ngay cả mẫu Haskell đã làm việc!

The downside of this approach was that the build platform very much affected the generated code. If you build on a 64-bit Linux machine, all platform constants would come from the Linux platform. And the code would be built with the assumption that Int is 64-bit. That is not very efficient to implement in JavaScript. And Cabal would not be aware that JavaScript was being generated at all.

Nhược điểm của phương pháp này là nền tảng xây dựng ảnh hưởng rất nhiều đến mã được tạo.
Nếu bạn xây dựng trên máy Linux 64 bit, tất cả các hằng số nền tảng sẽ đến từ nền tảng Linux.
Và mã sẽ được xây dựng với giả định rằng int là 64 bit.
Điều đó không hiệu quả lắm để thực hiện trong JavaScript.
Và Cabal sẽ không nhận thức được rằng JavaScript đang được tạo ra.

Later, we switched to using ghc as a library, introducing [Hooks](https://gitlab.haskell.org/ghc/ghc/blob/ghc-8.8/compiler/main/Hooks.hs) to change the compilation pipeline where needed. This made it possible to make the GHCJS platform word size independent of the build platform, introduce the JavaScriptFFI extension and run Template Haskell in a separate process with node.js.

Sau đó, chúng tôi đã chuyển sang sử dụng GHC làm thư viện, giới thiệu [móc] (https://gitlab.haskell.org/ghc/ghc/blob/ghc-8.8/compiler/main/hooks.hs)
cần thiết.
Điều này cho phép làm cho kích thước từ GHCJS độc lập với nền tảng xây dựng, giới thiệu phần mở rộng JavaScriptffi và Run Memlate Haskell trong một quy trình riêng với Node.js.

Unfortunately, it turned out to be hard to keep up with changes in the upstream ghc library. In addition, modifying the existing ghc through Hooks encouraged engineers to work around issues instead of directly fixing them upstream.

Thật không may, hóa ra rất khó để theo kịp những thay đổi trong thư viện GHC ngược dòng.
Ngoài ra, sửa đổi GHC hiện tại thông qua các móc nối khuyến khích các kỹ sư giải quyết các vấn đề thay vì trực tiếp sửa chúng ngược dòng.

In early 2018, we decided to build a custom ghc library for GHCJS, installed as ghc-api-ghcjs, allowing us to work around serious issues before they were merged upstream. Recently, we dropped the separate library, and built both the GHC and GHCJS source code in one library: ghcjs.

Đầu năm 2018, chúng tôi đã quyết định xây dựng một thư viện GHC tùy chỉnh cho GHCJS, được cài đặt dưới dạng GHC-API-GHCJS, cho phép chúng tôi giải quyết các vấn đề nghiêm trọng trước khi chúng được hợp nhất ngược dòng.
Gần đây, chúng tôi đã bỏ thư viện riêng biệt và xây dựng cả mã nguồn GHC và GHCJS trong một thư viện: GHCJS.

Although we cannot build GHCJS with the GHC build system yet, we are using the upstream GHC source tree much more directly again. Are we going back to the past? Perhaps, but this time we have our own platform with a toolchain and build tools, avoiding the pitfalls that made this approach so problematic the first time.

Mặc dù chúng tôi chưa thể xây dựng GHCJ với hệ thống xây dựng GHC, nhưng chúng tôi đang sử dụng cây nguồn GHC ngược dòng trực tiếp hơn nhiều.
Chúng ta có trở lại quá khứ không?
Có lẽ, nhưng lần này chúng ta có nền tảng riêng với một công cụ và công cụ xây dựng, tránh những cạm bẫy khiến phương pháp này trở nên khó khăn trong lần đầu tiên.

# **Outlook**

# **Quan điểm**

In 2019, we saw improvements to make Cabal work again, to bring back Windows support and to improve the C toolchain. We hope that the underlying changes in the GHCJS code base will make it easier to merge more upstream and to make libraries compatible with fewer changes. By continuing this path of turning GHCJS into a proper cross-compiler with a proper toolchain, as well as reducing its custom tools, we intend to further align and eventually merge GHCJS with GHC. While there will always be platform-specific libraries that simply cannot be cross-compiled, our ultimate goal is to provide GHC with a JavaScript target, alongside its x86\_64, Arm, AArch64, and other code generation targets.

Vào năm 2019, chúng tôi đã thấy những cải tiến để làm cho Cabal hoạt động trở lại, để mang lại hỗ trợ Windows và cải thiện công cụ C.
Chúng tôi hy vọng rằng những thay đổi cơ bản trong cơ sở mã GHCJS sẽ giúp việc hợp nhất ngược dòng hơn và làm cho các thư viện tương thích với ít thay đổi hơn.
Bằng cách tiếp tục con đường biến GHCJ này thành một trình biên dịch chéo thích hợp với một công cụ thích hợp, cũng như giảm các công cụ tùy chỉnh của nó, chúng tôi dự định sẽ liên kết thêm và cuối cùng hợp nhất GHCJ với GHC.
Mặc dù sẽ luôn có các thư viện dành riêng cho nền tảng mà đơn giản là không thể được biên dịch chéo, mục tiêu cuối cùng của chúng tôi là cung cấp cho GHC một mục tiêu JavaScript, cùng với x86 \ _64, ARM, AARCH64 và các mục tiêu tạo mã khác.

