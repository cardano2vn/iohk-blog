# Integrating and advancing with Adrestia
### **Taking the challenge out of fast-paced blockchain development**
![](img/2020-06-15-integrating-and-advancing-with-adrestia.002.png) 15 June 2020![](img/2020-06-15-integrating-and-advancing-with-adrestia.002.png)[ Eric Czuleger](tmp//en/blog/authors/eric-czuleger/page-1/)![](img/2020-06-15-integrating-and-advancing-with-adrestia.003.png) 4 mins read

![Eric Czuleger](img/2020-06-15-integrating-and-advancing-with-adrestia.004.png)[](tmp//en/blog/authors/eric-czuleger/page-1/)
### [**Eric Czuleger**](tmp//en/blog/authors/eric-czuleger/page-1/)
Senior Content Editor

Marketing & Communications

- ![](img/2020-06-15-integrating-and-advancing-with-adrestia.005.png)[](mailto:eric.czuleger@iohk.io "Email")
- ![](img/2020-06-15-integrating-and-advancing-with-adrestia.006.png)[](https://www.linkedin.com/in/eric-czuleger-6b67a395/ "LinkedIn")
- ![](img/2020-06-15-integrating-and-advancing-with-adrestia.007.png)[](https://twitter.com/eczuleger "Twitter")

![Integrating and advancing with Adrestia](img/2020-06-15-integrating-and-advancing-with-adrestia.008.jpeg)

For exchanges and developer partners, integrating with any blockchain can be challenging. The technology often moves so quickly that keeping up with the pace of change can be unrealistic. Cardanoâ€™s development and release process are now driving things forward apace. Managing parallel software development workstreams moving at different speeds can feel a bit like changing the tires on a truck while itâ€™s driving at 60 miles per hour. 

Đối với trao đổi và đối tác nhà phát triển, việc tích hợp với bất kỳ blockchain nào có thể là thách thức.
Công nghệ thường di chuyển nhanh đến mức theo kịp tốc độ thay đổi có thể không thực tế.
Quá trình phát triển và phát hành của Cardano hiện đang thúc đẩy mọi thứ về phía trước.
Quản lý các công việc phát triển phần mềm song song di chuyển ở các tốc độ khác nhau có thể cảm thấy hơi giống như thay đổi lốp xe trên một chiếc xe tải trong khi nó lái xe với tốc độ 60 dặm một giờ.

Cardanoâ€™s vision is to provide unparalleled security and sustainability to decentralized applications, systems, and societies. It has been created to be the most technologically advanced and environmentally sustainable blockchain platform, offering a secure, transparent, and scalable template for how we work, interact, and create, as individuals, businesses, and societies.

Tầm nhìn của Cardano là cung cấp bảo mật và tính bền vững vô song cho các ứng dụng, hệ thống và xã hội phi tập trung.
Nó đã được tạo ra để trở thành nền tảng blockchain bền vững về công nghệ và bền vững nhất về môi trường, cung cấp một mẫu an toàn, minh bạch và có thể mở rộng cho cách chúng tôi làm việc, tương tác và tạo ra, với tư cách cá nhân, doanh nghiệp và xã hội.

In line with these ambitions, we needed to devise a way that our partners could swiftly, easily and reliably integrate with Cardano, regardless of what was going on under the hood. Whatever the pace and cadence of future rollouts, we wanted to develop a consistent method by which all updates to the core node could be easily adopted by everyone.

Để phù hợp với những tham vọng này, chúng tôi cần phải nghĩ ra một cách mà các đối tác của chúng tôi có thể nhanh chóng, dễ dàng và đáng tin cậy tích hợp với Cardano, bất kể điều gì đang xảy ra dưới mui xe.
Bất kể tốc độ và nhịp điệu của các triển khai trong tương lai, chúng tôi muốn phát triển một phương pháp nhất quán, theo đó tất cả các cập nhật cho nút cốt lõi có thể dễ dàng được mọi người áp dụng.

In order to make that integration and interaction with Cardano easier and faster, IOHK engineers formed the Adrestia team, to take responsibility for building all the web APIs and libraries that make Cardano accessible to developers and application builders. Developments to the node can then focus on performance and scalability, while users will always be able to interact with it effortlessly. The name Adrestia was chosen after the goddess of revolt because with these new interfaces we expect everyone to be able to integrate with Cardano, creating a â€˜revolutionâ€™ in accessibility.

Để làm cho sự tích hợp và tương tác đó với Cardano dễ dàng và nhanh hơn, các kỹ sư của IOHK đã thành lập nhóm Adrestia, chịu trách nhiệm xây dựng tất cả các API và thư viện web giúp các nhà phát triển và xây dựng ứng dụng có thể truy cập được Cardano.
Sự phát triển của nút sau đó có thể tập trung vào hiệu suất và khả năng mở rộng, trong khi người dùng sẽ luôn có thể tương tác với nó một cách dễ dàng.
Cái tên Adrestia đã được chọn sau Nữ thần nổi dậy bởi vì với các giao diện mới này, chúng tôi hy vọng mọi người đều có thể tích hợp với Cardano, tạo ra khả năng tiếp cận.

## **Enabling developers to keep pace with change**

## ** Cho phép các nhà phát triển theo kịp sự thay đổi **

The goal of the Adrestia team is to provide â€“ via Web APIs â€“ a consistent integration experience so that developers can know what to expect between Cardano roadmap releases. Whether they are a wallet developer or an exchange, users can flexibly explore the chain, make transactions and more.

Mục tiêu của nhóm Adrestia là cung cấp thông qua API Web - Một trải nghiệm tích hợp nhất quán để các nhà phát triển có thể biết những gì mong đợi giữa các bản phát hành Lộ trình Cardano.
Cho dù họ là nhà phát triển ví hay trao đổi, người dùng có thể khám phá chuỗi một cách linh hoạt, thực hiện các giao dịch và hơn thế nữa.

The APIs are as follows:

Các API như sau:

- cardano-wallet: HTTP ReST API for managing UTXOs, and much more.

- Cardano-Wallet: HTTP REST API để quản lý UTXOS và nhiều hơn nữa.

- cardano-submit-api: HTTP API for submitting signed transactions.

-Cardano-Submit-API: API HTTP để gửi các giao dịch đã ký.

- cardano-graphql: HTTP GraphQL API for exploring the blockchain.

- Cardano-graphql: API HTTP GraphQL để khám phá blockchain.

The SDK consists of several low-level libraries:

SDK bao gồm một số thư viện cấp thấp:

- cardano-addresses: Address generation, derivation & mnemonic manipulation.

- Các địa chỉ Cardano: Tạo địa chỉ, Dẫn xuất & Thao tác ghi nhớ.

- cardano-coin-selection: Algorithms for coin selection and fee balancing.

-Cardano-coin-Selection: Các thuật toán để lựa chọn tiền xu và cân bằng phí.

- cardano-transactions: Utilities for constructing and signing transactions.

- Cardano-Transactions: Các tiện ích để xây dựng và ký giao dịch.

- bech32: Haskell implementation of the Bech32 address format (BIP 0173).

- Bech32: Thực hiện Haskell của định dạng địa chỉ Bech32 (BIP 0173).

In addition to providing a flexible and productive way to integrate with Cardano, maintenance is also made easier. With consistency, it can often require less time to update integrations between releases. This familiarity reduces maintenance costs. New software can then deploy in days rather than weeks. Ultimately, anyone can keep pace with change.

Ngoài việc cung cấp một cách linh hoạt và hiệu quả để tích hợp với Cardano, bảo trì cũng được thực hiện dễ dàng hơn.
Với tính nhất quán, nó thường có thể đòi hỏi ít thời gian hơn để cập nhật tích hợp giữa các bản phát hành.
Sự quen thuộc này làm giảm chi phí bảo trì.
Phần mềm mới sau đó có thể triển khai theo ngày thay vì vài tuần.
Cuối cùng, bất cứ ai cũng có thể theo kịp với sự thay đổi.

## **Get Started**

## **Bắt đầu**

The results are now live in the Byron era of Cardano. Exchanges or third-party wallets using Cardano-SL, should now be integrating to prepare for the new Byron and upgrading to Shelley wallet. These need to happen consecutively to avoid any outages. Full details have been added to the Adrestia team repo and we continue to work with our partners to ensure there is no interruption in service for ada holders keeping their funds on exchanges or in third-party wallets. The chart below shows the difference between the Cardano-SL node and the upcoming Shelley node. The components in red are non-Shelley compatible and will break after the hard fork, while the other components are Shelley compatible and will be supported during and after the hard fork.

Kết quả hiện đang sống trong kỷ nguyên Byron của Cardano.
Trao đổi hoặc ví của bên thứ ba bằng Cardano-SL, giờ đây nên tích hợp để chuẩn bị cho Byron mới và nâng cấp lên ví Shelley.
Những điều này cần phải xảy ra liên tiếp để tránh mất điện.
Chi tiết đầy đủ đã được thêm vào Repo của Adrestia Team và chúng tôi tiếp tục làm việc với các đối tác của mình để đảm bảo không có sự gián đoạn nào trong dịch vụ cho những người nắm giữ ADA giữ tiền của họ trên sàn giao dịch hoặc trong ví của bên thứ ba.
Biểu đồ dưới đây cho thấy sự khác biệt giữa nút Cardano-SL và nút Shelley sắp tới.
Các thành phần màu đỏ không tương thích với Shelley và sẽ bị phá vỡ sau khi hard fork, trong khi các thành phần khác tương thích với Shelley và sẽ được hỗ trợ trong và sau khi hard fork.

![](img/2020-06-15-integrating-and-advancing-with-adrestia.009.png)

Consistency is key in creating a blockchain network that works for everyone. Cardano is not being built for the next five or ten years, but for the next fifty. Change to the system is inevitable in that time but Adrestia was made to ensure that everyone can connect with the Cardano node. To get started, check out the Adrestia project [repo](https://github.com/input-output-hk/adrestia) and read the[user guide](https://input-output-hk.github.io/adrestia/).

Tính nhất quán là chìa khóa trong việc tạo một mạng blockchain phù hợp với mọi người.
Cardano không được xây dựng trong năm hoặc mười năm tới, nhưng trong năm mươi tiếp theo.
Thay đổi sang hệ thống là không thể tránh khỏi trong thời gian đó nhưng Adrestia đã được thực hiện để đảm bảo rằng mọi người đều có thể kết nối với nút Cardano.
Để bắt đầu, hãy xem dự án Adrestia [repo] (https://github.com/input-output-hk/adrestia) và đọc [Hướng dẫn sử dụng] (https://input-output-hk.github.io
/adrestia/).

