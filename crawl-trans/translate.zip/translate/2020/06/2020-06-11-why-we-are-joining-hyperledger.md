# Why we are joining Hyperledger
### **Collaboration is central to fostering industry development and enterprise blockchain adoption.**
![](img/2020-06-11-why-we-are-joining-hyperledger.002.png) 11 June 2020![](img/2020-06-11-why-we-are-joining-hyperledger.002.png)[ Romain Pellerin](tmp//en/blog/authors/romain-pellerin/page-1/)![](img/2020-06-11-why-we-are-joining-hyperledger.003.png) 3 mins read

![Romain Pellerin](img/2020-06-11-why-we-are-joining-hyperledger.004.png)[](tmp//en/blog/authors/romain-pellerin/page-1/)
### [**Romain Pellerin**](tmp//en/blog/authors/romain-pellerin/page-1/)
Chief Technology Officer

engineering

- ![](img/2020-06-11-why-we-are-joining-hyperledger.005.png)[](mailto:romain.pellerin@iohk.io "Email")
- ![](img/2020-06-11-why-we-are-joining-hyperledger.006.png)[](https://www.linkedin.com/in/romainpellerin/ "LinkedIn")
- ![](img/2020-06-11-why-we-are-joining-hyperledger.007.png)[](tmp///twitter.com/rom1_pellerin "Twitter")
- ![](img/2020-06-11-why-we-are-joining-hyperledger.008.png)[](https://github.com/romainPellerin "GitHub")

![Why we are joining Hyperledger](img/2020-06-11-why-we-are-joining-hyperledger.009.png)

A community's overall success largely depends on its ability to collaborate. How its members interact with each other, how they share knowledge to find new avenues of development, and how open they are to embrace innovation and novel technologies will determine the community's long-term viability.

Thành công chung của một cộng đồng phần lớn phụ thuộc vào khả năng hợp tác của nó.
Cách các thành viên của nó tương tác với nhau, cách họ chia sẻ kiến thức để tìm ra những con đường phát triển mới và họ cởi mở như thế nào để nắm lấy sự đổi mới và các công nghệ mới lạ sẽ quyết định khả năng tồn tại lâu dài của cộng đồng.

One of IOHKâ€™s founding principles is its belief in nurturing a collaborative ecosystem for blockchain development. Our commitment to knowledge-sharing and to our deeply-held principles of open-source serves as the rationale behind[becoming a member of the Hyperledger community](https://www.hyperledger.org/announcements/2020/06/11/eight-new-members-join-hyperledger).

Một trong những nguyên tắc sáng lập của IOHK là niềm tin của nó trong việc nuôi dưỡng một hệ sinh thái hợp tác để phát triển blockchain.
Cam kết của chúng tôi về chia sẻ kiến thức và các nguyên tắc sâu sắc của chúng tôi về nguồn mở đóng vai trò là lý do đằng sau [trở thành thành viên của cộng đồng Hyperledger] (https://www.hyperledger.org/announcements/2020/06/11/
Tám thành viên mới-join-hyperledger).

IOHK understands and fosters the principles of building its own blockchain technologies, while simultaneously partnering with other enterprises - all driven by the shared goal of driving forward blockchain adoption. We want to share what we have learned, build partnerships, and combine expertise to solve enterprise challenges across multiple industries for the benefit of all.

IOHK hiểu và thúc đẩy các nguyên tắc xây dựng các công nghệ blockchain của riêng mình, đồng thời hợp tác với các doanh nghiệp khác - tất cả đều được thúc đẩy bởi mục tiêu chung là thúc đẩy việc áp dụng blockchain về phía trước.
Chúng tôi muốn chia sẻ những gì chúng tôi đã học, xây dựng quan hệ đối tác và kết hợp chuyên môn để giải quyết các thách thức của doanh nghiệp trong nhiều ngành công nghiệp vì lợi ích của tất cả mọi người.

## **Becoming part of the Hyperledger Community: What it means for IOHK**

## ** Trở thành một phần của cộng đồng Hyperledger: Ý nghĩa của nó đối với iohk **

Blockchain is a rapidly developing technology. But its sheer versatility has demonstrated an unparalleled potential for innovation across multiple sectors. We are now entering the next phase of maturity with the creation of enterprise ecosystems to support novel projects that leverage decentralization.

Blockchain là một công nghệ phát triển nhanh chóng.
Nhưng tính linh hoạt tuyệt đối của nó đã thể hiện một tiềm năng vô song cho sự đổi mới trên nhiều lĩnh vực.
Bây giờ chúng tôi đang bước vào giai đoạn trưởng thành tiếp theo với việc tạo ra các hệ sinh thái doanh nghiệp để hỗ trợ các dự án mới có thể tận dụng sự phân cấp.

Hyperledger focuses on developing a suite of robust frameworks, tools, and libraries for enterprise-grade blockchain deployments, serving as a collaborative platform for various distributed ledger frameworks.

Hyperledger tập trung vào việc phát triển một bộ các khung, công cụ và thư viện mạnh mẽ để triển khai blockchain cấp doanh nghiệp, đóng vai trò là nền tảng hợp tác cho các khung sổ cái phân tán khác nhau.

IOHK is joining Hyperledger to contribute to its growing suite of blockchain projects while employing the Hyperledger umbrella to provide visibility and share components of IOHK's interoperable framework. Through this collaborative effort, we want to foster and accelerate collective innovation and industrial adoption of blockchain technologies.

IOHK đang tham gia Hyperledger để đóng góp cho bộ dự án blockchain ngày càng tăng của mình trong khi sử dụng ô Hyperledger để cung cấp khả năng hiển thị và chia sẻ các thành phần của khung tương tác của IOHK.
Thông qua nỗ lực hợp tác này, chúng tôi muốn thúc đẩy và tăng tốc đổi mới tập thể và áp dụng công nghiệp các công nghệ blockchain.

## **Why we are joining Hyperledger**

## ** Tại sao chúng ta tham gia Hyperledger **

Hyperledger includes more than 250 member companies, including many industry leaders in finance, banking, technology, and others. Becoming a part of this consortium enables us to do two things: (1) to collaborate and build synergies with others in this community, and (2) to refine our products for further interoperability. By doing so, we hope to encourage the co-development of our protocols and products, in line with our open-source development philosophy. 

Hyperledger bao gồm hơn 250 công ty thành viên, bao gồm nhiều nhà lãnh đạo ngành về tài chính, ngân hàng, công nghệ và các công ty khác.
Trở thành một phần của tập đoàn này cho phép chúng ta làm hai điều: (1) hợp tác và xây dựng sự hiệp lực với những người khác trong cộng đồng này và (2) để tinh chỉnh các sản phẩm của chúng ta để có khả năng tương tác hơn nữa.
Bằng cách đó, chúng tôi hy vọng sẽ khuyến khích sự đồng phát triển của các giao thức và sản phẩm của chúng tôi, phù hợp với triết lý phát triển nguồn mở của chúng tôi.

We are keen to gain a deeper understanding of specific enterprise requirements from all these projects, so we can construct better products and attune our offering more accurately. We want to help shape the future of the enterprise blockchain ecosystem by leveraging blockchain technology for a more decentralized economy - both through the products and solutions we engineer, and everything that this framework represents. We believe that this collaborative spirit will drive innovation and adoption of blockchain over the next decade, and beyond.

Chúng tôi rất muốn có được sự hiểu biết sâu sắc hơn về các yêu cầu doanh nghiệp cụ thể từ tất cả các dự án này, vì vậy chúng tôi có thể xây dựng các sản phẩm tốt hơn và cung cấp chính xác hơn.
Chúng tôi muốn giúp định hình tương lai của hệ sinh thái blockchain doanh nghiệp bằng cách tận dụng công nghệ blockchain cho một nền kinh tế phi tập trung hơn - cả thông qua các sản phẩm và giải pháp mà chúng tôi kỹ sư, và mọi thứ mà khung này thể hiện.
Chúng tôi tin rằng tinh thần hợp tác này sẽ thúc đẩy sự đổi mới và áp dụng blockchain trong thập kỷ tới, và hơn thế nữa.

