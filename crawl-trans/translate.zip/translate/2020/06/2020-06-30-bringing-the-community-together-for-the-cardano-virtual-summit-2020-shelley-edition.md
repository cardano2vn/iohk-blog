# Bringing the community together for the Cardano Virtual Summit 2020: Shelley Edition
### **Celebrating the journey and making way for the future with IOHK**
![](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.002.png) 30 June 2020![](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.002.png)[ Eric Czuleger](tmp//en/blog/authors/eric-czuleger/page-1/)![](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.003.png) 4 mins read

![Eric Czuleger](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.004.png)[](tmp//en/blog/authors/eric-czuleger/page-1/)
### [**Eric Czuleger**](tmp//en/blog/authors/eric-czuleger/page-1/)
Senior Content Editor

Marketing & Communications

- ![](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.005.png)[](mailto:eric.czuleger@iohk.io "Email")
- ![](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.006.png)[](https://www.linkedin.com/in/eric-czuleger-6b67a395/ "LinkedIn")
- ![](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.007.png)[](https://twitter.com/eczuleger "Twitter")

![Bringing the community together for the Cardano Virtual Summit 2020: Shelley Edition](img/2020-06-30-bringing-the-community-together-for-the-cardano-virtual-summit-2020-shelley-edition.008.jpeg)

Shelley has arrived and IOHK is gearing up to celebrate with the [Cardano Virtual Summit 2020: Shelley Edition](https://cardanosummit.iohk.io/) on July 2nd and 3rd. Every presentation, panel and guest speaker at this online event, has been chosen to represent the many faces of Cardano. From world-class foundational research to the latest advances in cryptographic development; from the passion and dedication of the wider community to some of the innovators who have created our world and are lighting the path to the future. The event is meant to honor the hard work and dedication of the Cardano community, developers and contributors, and the wider ecosystem.

Shelley đã đến và IOHK đang chuẩn bị để ăn mừng với [Cardano Virtual Summit 2020: Shelley Edition] (https://cardanosummit.iohk.io/) vào ngày 2 và 3 tháng 7.
Mỗi bài thuyết trình, bảng điều khiển và diễn giả khách mời tại sự kiện trực tuyến này, đã được chọn để đại diện cho nhiều gương mặt của Cardano.
Từ nghiên cứu nền tảng đẳng cấp thế giới đến những tiến bộ mới nhất trong phát triển mật mã;
Từ niềm đam mê và sự cống hiến của cộng đồng rộng lớn hơn cho đến một số nhà đổi mới đã tạo ra thế giới của chúng ta và đang thắp sáng con đường đến tương lai.
Sự kiện này nhằm tôn vinh sự chăm chỉ và cống hiến của cộng đồng Cardano, các nhà phát triển và người đóng góp, và hệ sinh thái rộng lớn hơn.

The virtual summit, much like IOHKâ€™s 2019 Miami summit will include presentations from IOHK team members, special guest appearances by thought leaders and a keynote speech by IOHK CEO, Charles Hoskinson. We were proud to announce that our guest of honor is internet co-creator and lead internet evangelist for Google, Vint Cerf. As one of the lead architects of the internet Vint is uniquely positioned to give us insight into building world changing technology.

Hội nghị thượng đỉnh ảo, giống như Hội nghị thượng đỉnh Miami 2019 của IOHK sẽ bao gồm các bài thuyết trình từ các thành viên nhóm IOHK, sự xuất hiện đặc biệt của các nhà lãnh đạo tư tưởng và bài phát biểu quan trọng của CEO IOHK, Charles Hoskinson.
Chúng tôi tự hào thông báo rằng khách mời danh dự của chúng tôi là đồng sáng lập Internet và dẫn dắt nhà truyền giáo Internet cho Google, Vint Cerf.
Là một trong những kiến trúc sư chính của Vint Internet được định vị duy nhất để cung cấp cho chúng ta cái nhìn sâu sắc về việc xây dựng công nghệ thay đổi thế giới.

Weâ€™ll also be joined by Caitlin Long of the Wyoming Blockchain Select Committee. The Wall Street professional turned crypto pioneer has been blazing the trail for adoption in the state of Wyoming. She will give us a look at the challenges and opportunities she has faced while pushing for wider adoption of decentralization. Our final special guest, Stephen Wolfram is the creator of the computational knowledge platform Wolfram Alpha and the CEO of Wolfram Research. Cardano shares his dedication to advancing technology through open source research and a commitment to academic excellence. Between each of these important discussions our colleagues at IOHK will take center stage.

Chúng tôi cũng sẽ được tham gia bởi Caitlin Long của Ủy ban Chọn Blockchain của bang Utah.
Chuyên gia Phố Wall đã biến Crypto Pioneer đã rực sáng đường mòn để nhận con nuôi tại bang bang Utah.
Cô ấy sẽ cho chúng tôi một cái nhìn về những thách thức và cơ hội mà cô ấy đã phải đối mặt trong khi thúc đẩy việc áp dụng rộng rãi hơn đối với sự phân cấp.
Khách mời đặc biệt cuối cùng của chúng tôi, Stephen Wolfram là người tạo ra nền tảng kiến thức tính toán Wolfram Alpha và CEO của Wolfram Research.
Cardano chia sẻ sự cống hiến của mình cho việc thúc đẩy công nghệ thông qua nghiên cứu nguồn mở và cam kết xuất sắc trong học tập.
Giữa mỗi cuộc thảo luận quan trọng này, các đồng nghiệp của chúng tôi tại IOHK sẽ chiếm vị trí trung tâm.

## **Thought leadership**

## ** Lãnh đạo suy nghĩ **

IOHKâ€™s chief scientist, Aggelos Kiayias, and director of African operations John Oâ€™Connor will talk about research and outreach in the Cardano Blockchain. Our panel entitled â€˜Haskell, then, now, and the futureâ€™ will examine the impact the functional programming language has had and where it is heading. The virtual summit also serves as the launchpad for new advancements like â€˜Prismâ€™ our decentralized identity solution. More guest speakers will be announced over the week ahead and weâ€™ll also have a number of special announcements over the 2-day summit itself; weâ€™re keeping those under our hats until then.

Nhà khoa học trưởng của IOHK, Aggelos Kiayias, và giám đốc hoạt động của châu Phi John Oâ € ™ Connor sẽ nói về nghiên cứu và tiếp cận với Blockchain Cardano.
Bảng điều khiển của chúng tôi có tựa đề â € ˜haskell, sau đó, bây giờ, và tương lai sẽ kiểm tra tác động của ngôn ngữ lập trình chức năng đã có và nơi nó đang hướng tới.
Hội nghị thượng đỉnh ảo cũng đóng vai trò là Launchpad cho các tiến bộ mới như "Giải pháp nhận dạng phi tập trung của chúng tôi.
Nhiều diễn giả khách mời sẽ được công bố trong tuần tới và chúng tôi cũng sẽ có một số thông báo đặc biệt trong chính Hội nghị thượng đỉnh 2 ngày;
Chúng tôi sẽ giữ những thứ đó dưới mũ của chúng tôi cho đến lúc đó.

The two day [agenda](https://cardanosummit.iohk.io/images/virtual-summit-agenda.pdf) includes five digital stages with programs dedicated to the ideology of blockchain technology; the science of decentralization, and building distributed ledgers for business and enterprise. We will be discussing next steps for growing the Cardano community alongside oncoming blockchain regulations, governance, and opportunities. In combination, we hope the summit tracks will offer something for anyone interested in the future of Cardano, by the science and ideas that surround it, by the great minds making it all happen and by the incredible community that has brought us here and will take us forward.

Hai ngày [Chương trình nghị sự] (https://cardanosummit.iohk.io/images/virtual-summit-agenda.pdf) bao gồm năm giai đoạn kỹ thuật số với các chương trình dành riêng cho ý nghĩa học của công nghệ blockchain;
Khoa học phân cấp, và xây dựng sổ cái phân tán cho doanh nghiệp và doanh nghiệp.
Chúng tôi sẽ thảo luận về các bước tiếp theo để phát triển cộng đồng Cardano cùng với các quy định, quản trị và cơ hội của blockchain sắp tới.
Kết hợp, chúng tôi hy vọng các bài hát hội nghị sẽ cung cấp một cái gì đó cho bất kỳ ai quan tâm đến tương lai của Cardano, bởi khoa học và ý tưởng xung quanh nó, bởi những bộ óc vĩ đại làm cho tất cả xảy ra và bởi cộng đồng đáng kinh ngạc đã đưa chúng tôi đến đây và sẽ
chúng tôi chuyển tiếp.

Sessions will encompass the philosophical as well as the technical. Brian Behlendorf, the CEO of the Hyperledger Consortium will form part of a panel focused on the importance of open source development. IOHK recently [joined](https://iohk.io/en/blog/posts/2020/06/11/why-we-are-joining-hyperledger/) the Hyperledger Consortium, to better exploit our common vision of a future made better through shared knowledge. Following on the philosophy track, artificial intelligence researcher, Ben Goertzel will speak on the intersection of AI and decentralized technology. We hope to announce more exciting sessions in the days leading up to the event. At the end of the day, building the next generation of technology means bringing the best minds of many fields into the same room, even if itâ€™s a virtual one.

Các phiên sẽ bao gồm các triết lý cũng như kỹ thuật.
Brian Behlendorf, CEO của Hyperledger Consortium sẽ là một phần của hội đồng tập trung vào tầm quan trọng của sự phát triển nguồn mở.
IOHK gần đây [đã tham gia] (https://iohk.io/en/blog/posts/2020/06/11/why-we-are-joining-hyperledger/) Consortium hyperledger, để khai thác tốt hơn tầm nhìn chung của chúng ta về một tương lai
làm tốt hơn thông qua kiến thức chia sẻ.
Theo dõi theo dõi triết học, nhà nghiên cứu trí tuệ nhân tạo, Ben Goertzel sẽ nói về sự giao thoa của AI và công nghệ phi tập trung.
Chúng tôi hy vọng sẽ công bố các phiên thú vị hơn trong những ngày dẫn đến sự kiện này.
Vào cuối ngày, việc xây dựng thế hệ công nghệ tiếp theo có nghĩa là đưa những bộ óc tốt nhất của nhiều lĩnh vực vào cùng một phòng, ngay cả khi đó là một nơi ảo.

## **Building community**

## ** Cộng đồng xây dựng **

The Cardano Virtual Summit 2020: Shelley Edition, wonâ€™t be all work and no play. The Covid crisis has forced every conference online in past months. While we canâ€™t recreate the full physical conference experience in the virtual space, weâ€™re keen to provide some of the networking and downtime opportunities you might expect. So weâ€™ve added a virtual â€˜chill-outâ€™ zone, with guided meditations, a DJ set, and even an online calligraphy lesson/demonstration. Our virtual platform will allow attendees to enjoy the digital expo space through avatars. Weâ€™ll even get the conversation flowing with a digital Shelley cocktail â€˜happy hourâ€™ between meetings.

Hội nghị thượng đỉnh ảo Cardano 2020: Shelley Edition, sẽ không phải là tất cả công việc và không chơi.
Cuộc khủng hoảng Covid đã buộc mọi hội nghị trực tuyến trong những tháng qua.
Mặc dù chúng tôi không thể tái tạo trải nghiệm hội nghị vật lý đầy đủ trong không gian ảo, chúng tôi rất muốn cung cấp một số cơ hội mạng và thời gian chết mà bạn có thể mong đợi.
Vì vậy, chúng tôi đã thêm một khu vực ảo, với các thiền định hướng dẫn, một bộ DJ và thậm chí là một bài học/trình diễn thư pháp trực tuyến.
Nền tảng ảo của chúng tôi sẽ cho phép người tham dự tận hưởng không gian hội chợ kỹ thuật số thông qua Avatars.
Chúng tôi thậm chí sẽ có được cuộc trò chuyện với một loại cocktail Shelley kỹ thuật số - Giờ vui vẻ giữa các cuộc họp.

Recent events have made it difficult to meet in person but we see The Cardano Virtual Summit as an opportunity to invite everyone from around the world to participate. Attendance for anyone interested in the summit is absolutely free of charge. To join in, simply [reserve](https://www.ubivent.com/register/cardanovirtualsummit) your spot.

Các sự kiện gần đây đã gây khó khăn cho việc gặp gỡ trực tiếp nhưng chúng ta thấy Hội nghị thượng đỉnh ảo Cardano là cơ hội để mời mọi người từ khắp nơi trên thế giới tham gia.
Tham dự cho bất cứ ai quan tâm đến hội nghị là hoàn toàn miễn phí.
Để tham gia, chỉ đơn giản là [Dự trữ] (https://www.ubivent.com/register/cardanovirtualsummit) vị trí của bạn.

Shelley is the culmination of over 5 years of research and development, the creation of a multi-disciplinary team and a remarkable community. The virtual summit is just a single point of time â€“ a time to take stock, reflect and celebrate. But it marks just the start of a groundbreaking new era of decentralization, growth and adoption.

Shelley là đỉnh cao của hơn 5 năm nghiên cứu và phát triển, thành lập một nhóm đa ngành và một cộng đồng đáng chú ý.
Hội nghị thượng đỉnh ảo chỉ là một thời điểm duy nhất - một thời gian để lấy cổ phiếu, suy ngẫm và ăn mừng.
Nhưng nó chỉ đánh dấu sự khởi đầu của một kỷ nguyên mới đột phá của sự phân cấp, tăng trưởng và nhận con nuôi.

