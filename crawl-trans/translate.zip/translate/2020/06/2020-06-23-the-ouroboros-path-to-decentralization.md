# The Ouroboros path to decentralization
### **The protocol that powers Cardano and its design philosophy**
![](img/2020-06-23-the-ouroboros-path-to-decentralization.002.png) 23 June 2020![](img/2020-06-23-the-ouroboros-path-to-decentralization.002.png)[ Prof Aggelos Kiayias](tmp//en/blog/authors/aggelos-kiayias/page-1/)![](img/2020-06-23-the-ouroboros-path-to-decentralization.003.png) 6 mins read

![Prof Aggelos Kiayias](img/2020-06-23-the-ouroboros-path-to-decentralization.004.png)[](tmp//en/blog/authors/aggelos-kiayias/page-1/)
### [**Prof Aggelos Kiayias**](tmp//en/blog/authors/aggelos-kiayias/page-1/)
Chief Scientist

Academic Research

- ![](img/2020-06-23-the-ouroboros-path-to-decentralization.005.png)[](mailto:aggelos.kiayias@iohk.io "Email")
- ![](img/2020-06-23-the-ouroboros-path-to-decentralization.006.png)[](tmp///www.youtube.com/watch?v=nB6eDbnkAk8 "YouTube")

![The Ouroboros path to decentralization](img/2020-06-23-the-ouroboros-path-to-decentralization.007.jpeg)

Designing and deploying a distributed ledger is a technically challenging task. What is expected of a ledger is the promise of a consistent view to all participants as well as a guarantee of responsiveness to the continuous flow of events that result from their actions. These two properties, sometimes referred to as *persistence* and *liveness*, are the hallmark of distributed ledger systems.

Thiết kế và triển khai một sổ cái phân tán là một nhiệm vụ thử thách kỹ thuật.
Những gì được mong đợi của một sổ cái là lời hứa về một quan điểm nhất quán cho tất cả những người tham gia cũng như đảm bảo khả năng đáp ứng với luồng các sự kiện liên tục xuất phát từ hành động của họ.
Hai thuộc tính này, đôi khi được gọi là *bền bỉ *và *Living *, là dấu hiệu đặc trưng của các hệ thống sổ cái phân tán.

Achieving persistence and liveness in a centralized system is a well-studied and fairly straightforward task; unfortunately, the ledger that emerges is precariously brittle because the server that supports the ledger becomes a single point of failure. As a result, hacking the server can lead to the instant violation of both properties. Even if the server is not hacked, the interests of the serverâ€™s operators may not align with the continuous assurance of these properties. For this reason, *decentralization* has been advanced as an essential remedy.

Đạt được sự kiên trì và khả năng sống trong một hệ thống tập trung là một nhiệm vụ được nghiên cứu kỹ lưỡng và khá đơn giản;
Thật không may, sổ cái nổi lên là giòn bấp vì máy chủ hỗ trợ sổ cái trở thành một điểm thất bại duy nhất.
Do đó, việc hack máy chủ có thể dẫn đến vi phạm tức thì của cả hai thuộc tính.
Ngay cả khi máy chủ không bị hack, lợi ích của các nhà khai thác của máy chủ có thể không phù hợp với sự đảm bảo liên tục của các thuộc tính này.
Vì lý do này, * Phân cấp * đã được nâng cao như một phương thuốc thiết yếu.

Informally, decentralization refers to a system architecture that calls for many entities to act individually in such a way that the ledgerâ€™s properties emerge from the convergence of their actions. In exchange for this increase in complexity, a well-designed system can continue to function even if some parties deviate from proper operation. Moreover, in the case of more significant deviations, even if some disruption is unavoidable, the system should still be capable of returning to normal operation and contain the damage.

Một cách không chính thức, sự phân cấp đề cập đến một kiến trúc hệ thống kêu gọi nhiều thực thể hành động riêng lẻ theo cách mà các thuộc tính của sổ cái xuất hiện từ sự hội tụ của hành động của họ.
Để đổi lấy sự gia tăng độ phức tạp này, một hệ thống được thiết kế tốt có thể tiếp tục hoạt động ngay cả khi một số bên đi chệch khỏi hoạt động thích hợp.
Hơn nữa, trong trường hợp sai lệch đáng kể hơn, ngay cả khi một số sự gián đoạn là không thể tránh khỏi, hệ thống vẫn có khả năng trở lại hoạt động bình thường và chứa thiệt hại.

How does one design a robust decentralized system? The world is a complicated place and decentralization is not a characteristic that can be hard-coded or demonstrated via testing â€“ the potential configurations that might arise are infinite. To counter this, one must develop *models* that systematically encompass all the different threats the system may encounter and demonstrate rigorously that the two basic properties of persistence and liveness are upheld.

Làm thế nào để một người thiết kế một hệ thống phi tập trung mạnh mẽ?
Thế giới là một nơi phức tạp và phân cấp không phải là một đặc điểm có thể được mã hóa cứng hoặc được chứng minh thông qua thử nghiệm-Các cấu hình tiềm năng có thể phát sinh là vô hạn.
Để chống lại điều này, người ta phải phát triển * mô hình * bao gồm một cách có hệ thống tất cả các mối đe dọa khác nhau mà hệ thống có thể gặp phải và chứng minh nghiêm ngặt rằng hai tính chất cơ bản của sự kiên trì và khả năng sống được giữ nguyên.

The strongest arguments for the reliability of a decentralized system combine formal guarantees against a broad portfolio of different classes of failure and attack models. The first important class is that of powerful Byzantine models. In this setting, it should be guaranteed that even if a subset of participants *arbitrarily* deviate from the rules, the two fundamental properties are retained. The second important class is models of rationality. Here, participants are assumed to be *rational utility maximizers* and the objective is to show that the ledger properties arise from their efforts to pursue their self interest.

Các lập luận mạnh mẽ nhất cho độ tin cậy của một hệ thống phi tập trung kết hợp các đảm bảo chính thức đối với một danh mục rộng của các lớp các mô hình thất bại và tấn công khác nhau.
Lớp quan trọng đầu tiên là các mô hình Byzantine mạnh mẽ.
Trong cài đặt này, cần đảm bảo rằng ngay cả khi một tập hợp con của người tham gia * tùy ý * đi chệch khỏi các quy tắc, hai thuộc tính cơ bản được giữ lại.
Lớp quan trọng thứ hai là các mô hình hợp lý.
Ở đây, những người tham gia được cho là * Tối đa hóa tiện ích hợp lý * và mục tiêu là chỉ ra rằng các thuộc tính sổ cái phát sinh từ những nỗ lực của họ để theo đuổi lợi ích bản thân của họ.

Ouroboros is a decentralized ledger protocol that is analyzed in the context of both Byzantine and rational behavior. What makes the protocol unique is the combination of the following design elements.

Ouroboros là một giao thức sổ cái phi tập trung được phân tích trong bối cảnh của cả hành vi byzantine và hợp lý.
Điều làm cho giao thức độc đáo là sự kết hợp của các yếu tố thiết kế sau.

- It uses **stake** as the fundamental resource to identify the participantsâ€™ leverage in the system. No physical resource is wasted in the process of ledger maintenance, which is shown to be robust despite â€˜costless simulationâ€™ and â€˜nothing at stakeâ€™ attacks that were previously thought to be fundamental barriers to stake-based ledgers. This makes Ouroboros distinctly more appealing than proof-of-work protocols, which require prodigious energy expenditure to maintain consensus.

- Nó sử dụng ** Stake ** làm tài nguyên cơ bản để xác định đòn bẩy của người tham gia trong hệ thống.
Không có tài nguyên vật lý nào bị lãng phí trong quá trình bảo trì sổ cái, điều này được chứng minh là mạnh mẽ mặc dù mô phỏng không hợp lý và các cuộc tấn công không có bên cạnh mà trước đây được cho là rào cản cơ bản đối với các sổ cái dựa trên cổ phần.
Điều này làm cho Ouroboros trở nên hấp dẫn hơn so với các giao thức bằng chứng làm việc, đòi hỏi phải chi tiêu năng lượng phi thường để duy trì sự đồng thuận.

- It is proven to be resilient even if arbitrarily large subsets of participants, in terms of stake, abstain from ledger maintenance. This guarantee of **dynamic availability** ensures liveness even under arbitrary, and unpredictable, levels of engagement. At the same time, of those participants who are active, barely more than half need to follow the protocol â€“ the rest can arbitrarily deviate; in fact, even temporary spikes above the 50% threshold can be tolerated. Thus Ouroboros is distinctly more resilient and adaptable than classical Byzantine fault tolerance protocols (as well as all their modern adaptations), which have to predict with relative certainty the level of expected participation and may stop operating when the prediction is false.

- Nó được chứng minh là có khả năng phục hồi ngay cả khi các tập hợp lớn người tham gia tùy ý, về mặt cổ phần, kiêng bảo trì sổ cái.
Sự đảm bảo này của ** tính khả dụng năng động ** đảm bảo khả năng sinh hoạt ngay cả dưới mức độ tham gia tùy tiện và không thể đoán trước.
Đồng thời, trong số những người tham gia hoạt động, chỉ hơn một nửa cần tuân theo giao thức - phần còn lại có thể tùy ý đi chệch hướng;
Trên thực tế, ngay cả các gai tạm thời trên ngưỡng 50% cũng có thể được dung nạp.
Do đó, Ouroboros rõ rệt hơn và dễ thích nghi hơn so với các giao thức dung sai lỗi Byzantine cổ điển (cũng như tất cả các điều chỉnh hiện đại của chúng), phải dự đoán với mức độ chắc chắn tương đối mức độ tham gia dự kiến và có thể ngừng hoạt động khi dự đoán là sai.

- The process of joining and participating in the protocol execution is **trustless** in the sense that it does not require the availability of any special shared resource such as a recent checkpoint or a common clock. Engaging in the protocol requires merely the public genesis block of the chain, and access to the network. This makes Ouroboros free of the trust assumptions common in other consensus protocols whose security collapses when trusted shared resources are subverted or unavailable.

- Quá trình tham gia và tham gia thực thi giao thức là ** không đáng tin cậy ** theo nghĩa là nó không yêu cầu sự sẵn có của bất kỳ tài nguyên được chia sẻ đặc biệt nào như điểm kiểm tra gần đây hoặc đồng hồ chung.
Tham gia vào giao thức chỉ yêu cầu khối genesis công khai của chuỗi và truy cập vào mạng.
Điều này làm cho Ouroboros không có các giả định ủy thác phổ biến trong các giao thức đồng thuận khác mà bảo mật bị sụp đổ khi các tài nguyên chia sẻ đáng tin cậy bị lật đổ hoặc không có sẵn.

- Ouroboros incorporates a reward-sharing mechanism to incentivize participants to **organize themselves** in operational nodes, known as stake pools, that can offer a good quality of service independently of how stake is distributed among the user population. In this way, all stakeholders contribute to the systemâ€™s operation â€“ ensuring robustness and democratic representation â€“ while the cost of ledger maintenance is efficiently distributed across the user population. At the same time, the mechanism comes with countermeasures that de-incentivize centralization. This makes Ouroboros fundamentally more inclusive and decentralized compared with other protocols that either end up with just a handful of actors responsible for ledger maintenance or provide no incentives to stakeholders to participate and offer a good quality of service.

- Ouroboros kết hợp một cơ chế chia sẻ phần thưởng để khuyến khích người tham gia ** tự tổ chức ** trong các nút hoạt động, được gọi là nhóm cổ phần, có thể cung cấp chất lượng dịch vụ tốt độc lập về cách phân phối cổ phần trong dân số người dùng.
Theo cách này, tất cả các bên liên quan đều đóng góp cho hoạt động của hệ thống - đảm bảo sự mạnh mẽ và đại diện dân chủ - trong khi chi phí bảo trì sổ cái được phân phối hiệu quả trên dân số người dùng.
Đồng thời, cơ chế đi kèm với các biện pháp đối phó không kích thích tập trung hóa.
Điều này làm cho Ouroboros về cơ bản bao quát và phi tập trung hơn so với các giao thức khác cuối cùng chỉ với một số ít các diễn viên chịu trách nhiệm bảo trì sổ cái hoặc không cung cấp các ưu đãi cho các bên liên quan tham gia và cung cấp chất lượng dịch vụ tốt.

These design elements of Ouroboros are not supposed to be self-evident appeals to the common sense of the protocol user. Instead, they were delivered with meticulous documentation in papers that have undergone peer review and appeared in top-tier conferences and publications in the area of cybersecurity and cryptography. Indeed, it is fair to say that no other consensus research effort is represented so comprehensively in these circles. Each paper is explicit about the specific type of model that is used to analyze the protocol and the results derived are laid out in concrete terms. The papers are open-access, patent-free, and include all technical details to allow anyone, with the relevant technical expertise, to convince themselves of the veracity of the claims made about performance, security, and functionality.

Các yếu tố thiết kế của ouroboros không được cho là hiển nhiên hấp dẫn đối với ý thức chung của người dùng giao thức.
Thay vào đó, họ đã được gửi với các tài liệu tỉ mỉ trong các bài báo đã trải qua đánh giá ngang hàng và xuất hiện trong các hội nghị và ấn phẩm hàng đầu trong lĩnh vực an ninh mạng và mật mã.
Thật vậy, thật công bằng khi nói rằng không có nỗ lực nghiên cứu đồng thuận nào khác được thể hiện một cách toàn diện trong các vòng tròn này.
Mỗi bài báo rõ ràng về loại mô hình cụ thể được sử dụng để phân tích giao thức và kết quả thu được được đặt ra theo thuật ngữ cụ thể.
Các bài báo được truy cập mở, không có bằng sáng chế và bao gồm tất cả các chi tiết kỹ thuật để cho phép bất cứ ai, với chuyên môn kỹ thuật có liên quan, để thuyết phục bản thân về tính xác thực của các khiếu nại về hiệu suất, bảo mật và chức năng.

Building an inclusive, fair and resilient infrastructure for financial and social applications on a global scale is the grand challenge of information technology today. Ouroboros contributes, not just as a protocol with unique characteristics, but also in presenting a design methodology that highlights first principles, careful modeling and rigorous analysis. Its modular and adaptable architecture also lends itself to continuous improvement, adaptation and enrichment with additional elements (such as parallelization to improve scalability or zero-knowledge proofs to improve privacy, to name two examples), which is a befitting characteristic to meet the ever-evolving needs and complexities of the real world.

Xây dựng một cơ sở hạ tầng toàn diện, công bằng và kiên cường cho các ứng dụng tài chính và xã hội trên phạm vi toàn cầu là thách thức lớn của công nghệ thông tin ngày nay.
Ouroboros đóng góp, không chỉ là một giao thức với các đặc điểm độc đáo, mà còn trong việc trình bày một phương pháp thiết kế làm nổi bật các nguyên tắc đầu tiên, mô hình cẩn thận và phân tích nghiêm ngặt.
Kiến trúc mô-đun và có thể thích ứng của nó cũng cho vay để cải tiến, thích ứng và làm giàu liên tục với các yếu tố bổ sung (như song song hóa để cải thiện khả năng mở rộng hoặc bằng chứng bằng không để cải thiện sự riêng tư, để đặt tên cho hai ví dụ), là một đặc điểm phù hợp để đáp ứng
Phát triển nhu cầu và sự phức tạp của thế giới thực.

## **Further reading**

## **Đọc thêm**

To delve deeper into the Ouroboros protocol, from its inception to recent new features, follow these links:

Để đi sâu hơn vào giao thức Ouroboros, từ khi ra đời đến các tính năng mới gần đây, hãy theo các liên kết sau:

1. [Ouroboros (Classic)](http://ia.cr/2016/889): the first provably secure proof-of-stake blockchain protocol.

1. [OuroBoros (Classic)] (http://ia.cr/2016/889): Giao thức blockchain chứng minh chứng minh an toàn đầu tiên.

1. [Ouroboros Praos](http://ia.cr/2017/573): removes the need for a rigid round structure and improves resilience against â€˜adaptiveâ€™ attackers.

1. [Ouroboros PRAOS] (http://ia.cr/2017/573): Loại bỏ sự cần thiết của một cấu trúc tròn cứng nhắc và cải thiện khả năng phục hồi chống lại những kẻ tấn công.

1. [Ouroboros Genesis](https://ia.cr/2018/378): how to avoid the need for a recent checkpoint and prove the protocol is secure under dynamic availability for trustless joining and participating.

1. [Ouroboros Genesis] (https://ia.cr/2018/378): Làm thế nào để tránh sự cần thiết của một điểm kiểm tra gần đây và chứng minh giao thức được bảo mật theo tính khả dụng của sự tham gia và tham gia không đáng tin cậy.

1. [Ouroboros Chronos](http://ia.cr/2019/838): removes the need for a common clock.

1. [Ouroboros Chronos] (http://ia.cr/2019/838): Loại bỏ sự cần thiết của một đồng hồ chung.

1. [Reward sharing schemes](https://arxiv.org/abs/1807.11218) for stake pools.

1. [Các chương trình chia sẻ phần thưởng] (https://arxiv.org/abs/1807.11218) cho nhóm cổ phần.

1. [Account management](https://ia.cr/2020/525) and maximizing participation in stake pools.

1. [Quản lý tài khoản] (https://ia.cr/2020/525) và tối đa hóa sự tham gia vào nhóm cổ phần.

1. [Optimizing transaction throughput](http://ia.cr/2020/037) with proof-of-stake protocols.

1. [tối ưu hóa thông lượng giao dịch] (http://ia.cr/2020/037) với các giao thức chứng minh.

1. [Fast settlement](http://ia.cr/2020/675) using ledger combiners.

1. [Giải quyết nhanh] (http://ia.cr/2020/675) bằng cách sử dụng các kết hợp sổ cái.

1. [Ouroboros Crypsinous](http://ia.cr/2018/1132): a privacy-preserving proof-of-stake protocol.

1. [Ouroboros crypsinous] (http://ia.cr/2018/1132): Một giao thức chứng minh bảo vệ quyền riêng tư.

1. [Kachina](http://ia.cr/2020/543): a unified security model for private smart contracts.

1. [Kachina] (http://ia.cr/2020/543): Một mô hình bảo mật thống nhất cho các hợp đồng thông minh riêng tư.

1. [Hydra](http://ia.cr/2020/299): an off-chain scalability architecture for high transaction throughput with low latency, and minimal storage per node.

1. [Hydra] (http://ia.cr/2020/299): Kiến trúc khả năng mở rộng chuỗi cho thông lượng giao dịch cao với độ trễ thấp và lưu trữ tối thiểu trên mỗi nút.

