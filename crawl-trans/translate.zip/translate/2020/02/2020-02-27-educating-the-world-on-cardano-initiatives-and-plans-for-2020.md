# Educating the world on Cardano: initiatives and plans for 2020
### **Learn more about the education team's plans for the upcoming year**
![](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.002.png) 27 February 2020![](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.002.png)[ Niamh Ahern](tmp//en/blog/authors/niamh-ahern/page-1/)![](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.003.png) 5 mins read

![Niamh Ahern](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.004.png)[](tmp//en/blog/authors/niamh-ahern/page-1/)
### [**Niamh Ahern**](tmp//en/blog/authors/niamh-ahern/page-1/)
Education Manager

Education

- ![](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.005.png)[](mailto:niamh.ahern@iohk.io "Email")
- ![](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.006.png)[](https://www.linkedin.com/in/niamh-ahern-67849949/ "LinkedIn")
- ![](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.007.png)[](https://twitter.com/nahern_iohk?lang=en "Twitter")
- ![](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.008.png)[](https://github.com/nahern "GitHub")

![Educating the world on Cardano: initiatives and plans for 2020](img/2020-02-27-educating-the-world-on-cardano-initiatives-and-plans-for-2020.009.jpeg)

Education has always been a key part of IOHKâ€™s strategy. Our mission is to grow our global community and business through the medium of education, and to share what we have learned. By claiming leadership in worldwide education on blockchain technology, we have the chance to shape the field for generations and to leave a lasting legacy.

Giáo dục luôn là một phần quan trọng trong chiến lược của IOHK.
Nhiệm vụ của chúng tôi là phát triển cộng đồng và doanh nghiệp toàn cầu của chúng tôi thông qua phương tiện giáo dục và chia sẻ những gì chúng tôi đã học được.
Bằng cách tuyên bố sự lãnh đạo trong giáo dục trên toàn thế giới về công nghệ blockchain, chúng tôi có cơ hội định hình lĩnh vực này qua nhiều thế hệ và để lại một di sản lâu dài.

A consistent theme from 2019 has been the demand for a broad range of educational content, as demonstrated by the feedback received about the Incentivized Testnet, as well as the steady flow of support requests to our helpdesk. A key focus in IOHK for 2020 is to develop and expand our education materials as we transition fully into the Shelley era and then to the Goguen era of Cardano.

Một chủ đề nhất quán từ năm 2019 là nhu cầu về một loạt các nội dung giáo dục, như được thể hiện bằng phản hồi nhận được về TestNet được khuyến khích, cũng như dòng yêu cầu hỗ trợ ổn định đến trợ giúp của chúng tôi.
Trọng tâm quan trọng trong IOHK cho năm 2020 là phát triển và mở rộng các tài liệu giáo dục của chúng tôi khi chúng tôi chuyển sang thời kỳ Shelley và sau đó đến kỷ nguyên Goguen của Cardano.

The IOHK education team will be investing significant time and effort this year in broadening our range of materials. We aim to enhance understanding of our technologies using a variety of learning and training assets targeted at a wide range of stakeholder audiences, both internal and external. This will be vital as the use of IOHK technology moves into the mainstream. We also aim to provide knowledge and information to enterprise decision-makers so they know what business problems our technologies can solve. We have lots planned and many projects are underway as we grow Cardano into a global social and financial operating system.

Nhóm giáo dục IOHK sẽ đầu tư thời gian và nỗ lực đáng kể trong năm nay để mở rộng phạm vi tài liệu của chúng tôi.
Chúng tôi mong muốn nâng cao sự hiểu biết về các công nghệ của chúng tôi bằng cách sử dụng nhiều tài sản học tập và đào tạo được nhắm mục tiêu tại một loạt các đối tượng bên liên quan, cả bên trong và bên ngoài.
Điều này sẽ rất quan trọng khi việc sử dụng công nghệ IOHK chuyển sang dòng chính.
Chúng tôi cũng đặt mục tiêu cung cấp kiến thức và thông tin cho những người ra quyết định doanh nghiệp để họ biết những vấn đề kinh doanh của chúng tôi có thể giải quyết.
Chúng tôi có rất nhiều kế hoạch và nhiều dự án đang được tiến hành khi chúng tôi phát triển Cardano thành một hệ điều hành xã hội và tài chính toàn cầu.

## **What can you expect?**

## ** Bạn có thể mong đợi điều gì? **

We started 2020 with lectures, by Dr Lars BrÃ¼njes, our director of education, at the University of Malta. The focus of these lectures was on Plutus and Marlowe, our programming languages for smart contracts. The fruits of these sessions will, in turn, form the foundation of some modular training materials that we plan to formalize and develop over the coming months.

Chúng tôi bắt đầu năm 2020 với các bài giảng, bởi Tiến sĩ Lars BrÃ¼njes, Giám đốc Giáo dục của chúng tôi, tại Đại học Malta.
Trọng tâm của các bài giảng này là Sao Diêm Vương và Marlowe, ngôn ngữ lập trình của chúng tôi cho các hợp đồng thông minh.
H quả của các phiên này sẽ lần lượt tạo thành nền tảng của một số tài liệu đào tạo mô -đun mà chúng tôi dự định chính thức hóa và phát triển trong những tháng tới.

Our free Udemy courses on [Plutus](https://www.udemy.com/course/plutus-reliable-smart-contracts/) and [Marlowe](https://www.udemy.com/course/marlowe-programming-language/) by Alejandro Garcia have proven very popular, with over 5,000 students signed up. Feedback has been positive and, as a result of what we learned from our students, weâ€™ve been making incremental improvements over the last year. We now want to take this to the next level and are planning to fully update both courses soon to bring them up to speed with the latest development changes and new features. We are also in the initial planning stages for a second edition of the ebook, [Plutus: Writing reliable smart contracts](https://leanpub.com/plutus-smart-contracts) by Lars BrÃ¼njes and Polina Vinogradova, which we will be publishing later this year. The writing team has started to identify improvements and we are also gathering feedback directly from readers. If you have suggestions, please raise a pull request in our Plutus ebook GitHub repository with your ideas.

Các khóa học Udemy miễn phí của chúng tôi về [Plutus] (https://www.udemy.com/cof -L lý ngôn/) của Alejandro Garcia đã được chứng minh rất phổ biến, với hơn 5.000 sinh viên đã đăng ký. Phản hồi là tích cực và, do kết quả của những gì chúng tôi học được từ các sinh viên của mình, chúng tôi đã thực hiện những cải tiến gia tăng trong năm qua. Bây giờ chúng tôi muốn đưa điều này lên một tầm cao mới và dự định cập nhật đầy đủ cả hai khóa học để đưa chúng lên tốc độ với những thay đổi phát triển mới nhất và các tính năng mới. Chúng tôi cũng đang trong giai đoạn lập kế hoạch ban đầu cho phiên bản thứ hai của ebook, [Plutus: Viết hợp đồng thông minh đáng tin cậy] (https://leanpub.com/plutus-smart-contracts) của Lars BrÃ¼njes và Polina Vinogradova, mà chúng tôi sẽ là Xuất bản vào cuối năm nay. Nhóm viết đã bắt đầu xác định các cải tiến và chúng tôi cũng đang thu thập phản hồi trực tiếp từ độc giả. Nếu bạn có đề xuất, vui lòng nâng cao yêu cầu kéo trong kho lưu trữ GitHub Ebook Plutus của chúng tôi với ý tưởng của bạn.

An important step in bridging the gap between our academic papers and mainstream understanding of these concepts is to teach people about Ouroboros, the proof-of-stake protocol that powers Cardano and ada. In response to the valuable feedback we have received from running the Incentivized Testnet, we are planning to create varied educational content to help stake pool operators understand Ouroboros and how the protocol works on a practical level.

Một bước quan trọng trong việc thu hẹp khoảng cách giữa các bài báo học thuật của chúng tôi và sự hiểu biết chính thống về các khái niệm này là dạy mọi người về Ouroboros, giao thức chứng minh cung cấp năng lượng cho Cardano và ADA.
Để đáp ứng với phản hồi có giá trị mà chúng tôi đã nhận được từ việc điều hành Testnet khuyến khích, chúng tôi đang lên kế hoạch tạo nội dung giáo dục đa dạng để giúp các nhà khai thác nhóm đặt cược hiểu ouroboros và cách giao thức hoạt động ở cấp độ thực tế.

## **Broadening our reach**

## ** Mở rộng phạm vi của chúng tôi **

To broaden the reach of our training courses and content, we are also investigating a way to migrate our popular Haskell training course into a massive online course, or MOOC, while also making it more comprehensive with the inclusion of Plutus and Marlowe material. In this way, we hope our MOOC will make the course even more valuable, and provide access to the widest possible global community. In addition, we are planning a comprehensive classroom-based Haskell and Plutus course in Mongolia, details of which will be finalized soon. We plan to use the introductory part of the online Haskell course as a primer for this face-to-face training. This is an example of a core efficiency that we are embracing where we aim to reuse content on Haskell, Plutus, and Marlowe across a variety of stand-alone modular materials that we can use externally and within the company for developing our staff.

Để mở rộng phạm vi của các khóa đào tạo và nội dung của chúng tôi, chúng tôi cũng đang điều tra một cách để di chuyển khóa đào tạo Haskell phổ biến của chúng tôi vào một khóa học trực tuyến lớn, hoặc MOOC, đồng thời làm cho nó toàn diện hơn với việc đưa vào Plutus và Marlowe tài liệu.
Theo cách này, chúng tôi hy vọng MOOC của chúng tôi sẽ làm cho khóa học trở nên có giá trị hơn và cung cấp quyền truy cập vào cộng đồng toàn cầu rộng nhất có thể.
Ngoài ra, chúng tôi đang lên kế hoạch cho một khóa học Haskell và Plutus dựa trên lớp học toàn diện ở Mông Cổ, chi tiết sẽ sớm được hoàn thành.
Chúng tôi dự định sử dụng phần giới thiệu của khóa học Haskell trực tuyến như một mồi cho đào tạo trực tiếp này.
Đây là một ví dụ về hiệu quả cốt lõi mà chúng tôi đang chấp nhận, nơi chúng tôi hướng đến việc tái sử dụng nội dung trên Haskell, Plutus và Marlowe trên nhiều loại vật liệu mô-đun độc lập mà chúng tôi có thể sử dụng bên ngoài và trong công ty để phát triển nhân viên của chúng tôi.

We appreciate the value of interactive and meaningful training workshops, so we intend to host many more this year in several locations around the world. These events are in the initial planning stages and the first in the series will take place in Quebec in the spring. Weâ€™ll announce more details through our official channels â€“ Twitter, email, here â€“ nearer the time. The IOHK education team are on hand to support and prepare the necessary learning tools for participants to use at these events.

Chúng tôi đánh giá cao giá trị của các hội thảo đào tạo tương tác và có ý nghĩa, vì vậy chúng tôi dự định sẽ tổ chức nhiều hơn trong năm nay tại một số địa điểm trên thế giới.
Những sự kiện này đang trong giai đoạn lập kế hoạch ban đầu và lần đầu tiên trong loạt phim sẽ diễn ra tại Quebec vào mùa xuân.
Chúng tôi sẽ thông báo thêm chi tiết thông qua các kênh chính thức của chúng tôi - Twitter, email, ở đây - gần hơn thời gian.
Nhóm Giáo dục IOHK có mặt để hỗ trợ và chuẩn bị các công cụ học tập cần thiết cho người tham gia sử dụng tại các sự kiện này.

Alongside these materials and courses, we are mentoring an undergraduate student at the International University of Management (ISM), with her thesis on the topic of the power of blockchain in emerging markets. Additionally, Dr Jamie Gabbay has been invited to contribute to the book '*Applications of new generation technology to cryptocurrencies, banking, and finance*â€™ by Devraj Basu.

Bên cạnh các tài liệu và khóa học này, chúng tôi đang cố vấn cho một sinh viên đại học tại Đại học Quản lý Quốc tế (ISM), với luận điểm của cô về chủ đề sức mạnh của blockchain tại các thị trường mới nổi.
Ngoài ra, Tiến sĩ Jamie Gabbay đã được mời đóng góp cho cuốn sách '*Ứng dụng công nghệ thế hệ mới cho tiền điện tử, ngân hàng và tài chính* - của Devraj Basu.

## **Internal initiatives**

## ** Sáng kiến nội bộ **

We are also working with our human resources team to build the IOHK Training Academy: a new learning portal for our internal teams to upskill and develop professionally. This new resource is part of our learning and development strategy that aims to improve employee engagement, satisfaction, and retention. We want to provide access to a library of assets so our staff can easily find exactly what they need. We will be developing tailored â€˜learning journeysâ€™ by function, ready-made content that will help people develop skills in new areas, as well as creating specific onboarding journeys for new starters. This is a vital resource for a fast-growing company with staff and contractors spread across 43 countries and will prove to be an important asset for all our people.

Chúng tôi cũng đang làm việc với nhóm nhân sự của chúng tôi để xây dựng Học viện đào tạo IOHK: một cổng thông tin học tập mới cho các nhóm nội bộ của chúng tôi để tăng trưởng và phát triển chuyên nghiệp.
Tài nguyên mới này là một phần của chiến lược học tập và phát triển của chúng tôi nhằm cải thiện sự tham gia, sự hài lòng và duy trì của nhân viên.
Chúng tôi muốn cung cấp quyền truy cập vào một thư viện tài sản để nhân viên của chúng tôi có thể dễ dàng tìm thấy chính xác những gì họ cần.
Chúng tôi sẽ phát triển các hành trình được thiết kế riêng-theo chức năng, nội dung sẵn sàng sẽ giúp mọi người phát triển các kỹ năng trong các khu vực mới, cũng như tạo ra những hành trình trên tàu cụ thể cho người mới bắt đầu.
Đây là một nguồn tài nguyên quan trọng cho một công ty phát triển nhanh với nhân viên và nhà thầu trải rộng trên 43 quốc gia và sẽ chứng minh là một tài sản quan trọng cho tất cả mọi người của chúng tôi.

2020 is going to be a pivotal year for Cardano and we are looking forward to playing our part. It is our aim to teach both individuals and organizations how to use the protocol, and how it can help with their everyday lives. We have lots to do and we look forward to sharing all the educational content that we produce with our existing community, as well as those of you who are new to Cardano.

Năm 2020 sẽ là một năm quan trọng đối với Cardano và chúng tôi mong muốn được chơi phần của mình.
Mục đích của chúng tôi là dạy cả cá nhân và tổ chức cách sử dụng giao thức và làm thế nào nó có thể giúp với cuộc sống hàng ngày của họ.
Chúng tôi có rất nhiều việc phải làm và chúng tôi mong muốn được chia sẻ tất cả các nội dung giáo dục mà chúng tôi sản xuất với cộng đồng hiện tại của chúng tôi, cũng như những người mới sử dụng Cardano.

