# Shelley Incentivized Testnet: the story in numbers
### **We've compiled some Incentivized Testnet statistics. Check them out.**
![](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.002.png) 7 February 2020![](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.003.png) <1 min read

![Tim Harrison](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.008.png)[](https://github.com/timbharrison "GitHub")

The Shelley Incentivized Testnet is proving to be an incredible journey. Originally, we hoped for around 100 pools. As of today, we've reached over 1,000 registered and more than 670 active pools. Over 11.5B ada is now being staked on the testnet. The many improvements to performance have resulted in an increase in uptime â€“ but there's still a way to go. We are not resting on our laurels, even for a minute, and efforts to improve stability and performance are ongoing. 

Testnet khuyến khích Shelley đang chứng tỏ là một hành trình đáng kinh ngạc.
Ban đầu, chúng tôi hy vọng khoảng 100 hồ bơi.
Tính đến hôm nay, chúng tôi đã đạt hơn 1.000 người đăng ký và hơn 670 nhóm hoạt động.
Hơn 11,5B ADA hiện đang được đặt trên TestNet.
Nhiều cải tiến về hiệu suất đã dẫn đến sự gia tăng thời gian hoạt động - nhưng vẫn còn một cách để đi.
Chúng tôi không nghỉ ngơi trên vòng nguyệt quế của mình, ngay cả trong một phút và những nỗ lực để cải thiện sự ổn định và hiệu suất đang diễn ra.

Still, the progress to date is a remarkable testament to the commitment of our incredible Cardano community, which grows in number and passion every day. 

Tuy nhiên, tiến trình cho đến nay là một minh chứng đáng chú ý cho sự cam kết của cộng đồng Cardano đáng kinh ngạc của chúng tôi, phát triển về số lượng và niềm đam mê mỗi ngày.

Weâ€™re started compiling some testnet statistics, a few of which weâ€™ve captured here. Transparency is always our goal: we want the community to see what we see. To that end, here's a look at the Incentivized Testnet's story so far, along with a flavor of the community's reaction. We'll continue to gather community feedback and data, and we'll be sharing these as we go forward. So stay tuned as we continue to chart our journey.

Chúng tôi đã bắt đầu biên dịch một số số liệu thống kê của TestNet, một vài trong số đó chúng tôi đã nắm bắt được ở đây.
Tính minh bạch luôn là mục tiêu của chúng tôi: Chúng tôi muốn cộng đồng xem những gì chúng tôi thấy.
Cuối cùng, đây là một cái nhìn về câu chuyện của Testnet được khuyến khích cho đến nay, cùng với hương vị của phản ứng của cộng đồng.
Chúng tôi sẽ tiếp tục thu thập phản hồi và dữ liệu của cộng đồng và chúng tôi sẽ chia sẻ những điều này khi chúng tôi đi tiếp.
Vì vậy, hãy theo dõi khi chúng tôi tiếp tục lập biểu đồ hành trình của chúng tôi.

![Incentivized Testnet statistics](img/2020-02-07-shelley-incentivized-testnet-story-in-numbers.009.png)

