# From Byron to Shelley: part two, the journey to the mainnet
### **Continuing on to Shelley with the decentralization of block production**
![](img/2020-05-11-from-byron-to-shelley-part-two-the-journey-to-the-mainnet.002.png) 11 May 2020![](img/2020-05-11-from-byron-to-shelley-part-two-the-journey-to-the-mainnet.002.png)[ Kevin Hammond](tmp//en/blog/authors/kevin-hammond/page-1/)![](img/2020-05-11-from-byron-to-shelley-part-two-the-journey-to-the-mainnet.003.png) 5 mins read

![Kevin Hammond](img/2020-05-11-from-byron-to-shelley-part-two-the-journey-to-the-mainnet.004.png)[](tmp//en/blog/authors/kevin-hammond/page-1/)
### [**Kevin Hammond**](tmp//en/blog/authors/kevin-hammond/page-1/)
Software Engineer

Engineering

- ![](img/2020-05-11-from-byron-to-shelley-part-two-the-journey-to-the-mainnet.005.png)[](https://twitter.com/inputoutputhk "Twitter")

![From Byron to Shelley: part two, the journey to the mainnet](img/2020-05-11-from-byron-to-shelley-part-two-the-journey-to-the-mainnet.006.png)

Today, weâ€™re kicking off the â€˜Friends & Familyâ€™ testnet, which will allow us to establish a robust network to test and iterate, before we roll it out to the wider community. Weâ€™ve gathered a small number of around 20 â€˜pioneersâ€™ to help us with this important initial work. By the time you probably read this, theyâ€™ll be briefed and weâ€™ll have things underway.

Hôm nay, chúng tôi sẽ khởi động TestNet của Friends & Familys & Family, sẽ cho phép chúng tôi thiết lập một mạng lưới mạnh mẽ để kiểm tra và lặp lại, trước khi chúng tôi chuyển nó cho cộng đồng rộng lớn hơn.
Chúng tôi đã thu thập một số lượng nhỏ khoảng 20 - € ˜pioneers 'để giúp chúng tôi với công việc ban đầu quan trọng này.
Vào thời điểm bạn có thể đọc được điều này, chúng sẽ được thông báo và chúng tôi sẽ có những thứ đang được tiến hành.

In [my last blog](https://iohk.io/en/blog/posts/2020/04/29/from-byron-to-shelley-part-one-the-testnets/), I outlined how the Shelley experience will roll out within clearly defined phases. These first three phases will involve exploring and testing the new Shelley capabilities via a series of testnets. I thought it might be useful to offer a glimpse ahead to provide some additional context.

Trong [blog cuối cùng của tôi] (https://iohk.io/en/blog/posts/2020/04/29/from-byron-to-shelley-part-one-the-testnet/), tôi đã vạch ra cách Shelley
Kinh nghiệm sẽ tung ra trong các giai đoạn được xác định rõ ràng.
Ba giai đoạn đầu tiên này sẽ liên quan đến việc khám phá và thử nghiệm các khả năng mới của Shelley thông qua một loạt các bài kiểm tra.
Tôi nghĩ rằng nó có thể hữu ích để đưa ra một cái nhìn thoáng qua phía trước để cung cấp một số bối cảnh bổ sung.

The rollout of the testnets will happen very much in parallel with our continued progress towards mainnet. So alongside the work on the Haskell Shelley testnet, the mainnet will be systematically upgraded to support the Shelley era protocol, that will enable staking, delegation and metadata.

Việc triển khai các bài kiểm tra sẽ diễn ra rất nhiều song song với tiến trình tiếp tục của chúng tôi đối với Mainnet.
Vì vậy, cùng với công việc trên Haskell Shelley Testnet, Mainnet sẽ được nâng cấp một cách có hệ thống để hỗ trợ giao thức ERA Shelley, sẽ cho phép đặt cược, phái đoàn và siêu dữ liệu.

Similarly, IOHKâ€™s block-producing and public-facing relay nodes on the mainnet will be upgraded so that they are ready for Shelley, and the Blockchain Explorer, Daedalus Wallet, Wallet CLI and other user-facing software will be polished so that it can be used for mainnet.

Tương tự, các nút rơle sản xuất khối và sản xuất khối công khai trên mainnet sẽ được nâng cấp để chúng sẵn sàng cho Shelley và Blockchain Explorer, Daedalus Pallet, Wallet CLI và các phần mềm hướng tới người dùng khác sẽ được đánh bóng để điều đó
Nó có thể được sử dụng cho mainnet.

Users will soon be able to go to the official Cardano websites or other providers such as Yoroi, to download a new wallet â€“ currently in development â€“ that will work with both Byron and Shelley era blocks. The Shelley-era Daedalus wallet will contain all the logic for staking and delegation that has been tested on the Incentivized Testnet, plus new features that are specific to the full Shelley protocol. Stakepool operators, exchanges and others will also be able to download Shelley-compatible nodes and to adapt their own software to support the new Shelley client API. However, during this period, the mainnet will still be running in Byron reboot mode with federated consensus governed by the OBFT (Ouroboros Byzantine Fault Tolerance) algorithm. Think of it as a time when forward compatibility is being integrated but not yet â€˜switched onâ€™.

Người dùng sẽ sớm có thể truy cập các trang web Cardano chính thức hoặc các nhà cung cấp khác như Yoroi, để tải xuống một ví mới - hiện đang được phát triển - sẽ hoạt động với cả Byron và Shelley ERA Blocks.
Ví Daedalus thời Shelley sẽ chứa tất cả logic cho việc đặt cược và phái đoàn đã được thử nghiệm trên Testnet được khuyến khích, cộng với các tính năng mới dành riêng cho giao thức Shelley đầy đủ.
Các nhà khai thác, trao đổi và các nhà khai thác khác cũng sẽ có thể tải xuống các nút tương thích với Shelley và điều chỉnh phần mềm của riêng họ để hỗ trợ API khách hàng Shelley mới.
Tuy nhiên, trong giai đoạn này, Mainnet vẫn sẽ chạy ở chế độ khởi động lại Byron với sự đồng thuận được liên kết được điều chỉnh bởi thuật toán dung sai lỗi OBFT (Ouroboros Byzantine).
Hãy nghĩ về nó như là một thời điểm mà khả năng tương thích về phía trước đang được tích hợp nhưng chưa được thực hiện trên '.

The move to Shelley will be accomplished using the new [hard fork combinator](https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-hard-fork/) that has been developed by IOHK.The hard fork combinator allows a node to transition from one blockchain protocol to another. The Cardano node software that is running on the mainnet will gradually evolve so that it is able to deal with both Byron era and Shelley era blocks, and will be modified to include the hard fork combinator. When the time comes to move the mainnet from the Byron era to the Shelley era, IOHK will trigger a hard fork.

Việc chuyển đến Shelley sẽ được thực hiện bằng cách sử dụng [tổ hợp hard fork hard] (https://iohk.io/en/blog/posts/2020/05/07/combinator-makes-easy-work-of-shelley-hard-
Fork/) đã được IOHK phát triển. Bộ kết hợp hard fork cho phép một nút chuyển từ giao thức blockchain sang giao thức khác.
Phần mềm Cardano Node đang chạy trên Mainnet sẽ dần dần phát triển để nó có thể đối phó với cả các khối kỷ nguyên của ERA và Shelley, và sẽ được sửa đổi để bao gồm bộ kết hợp hard fork.
Khi đến lúc di chuyển Mainnet từ thời Byron đến thời Shelley, Iohk sẽ kích hoạt một hard fork.

## **â€˜Switching onâ€™ Shelley**

## ** â € ˜witching onâ € ™ Shelley **

This will activate the hard fork combinator within the nodes, and the nodes will then change from only producing Byron era blocks to only producing Shelley era blocks. After the hard fork, no new Byron era blocks will be recorded on the blockchain, and the nodes will be able to support distributed block production, staking and delegation. They will have seamlessly switched from the OBFT to the Ouroboros Praos consensus mechanism. We will have entered the Shelley era on the mainnet.

Điều này sẽ kích hoạt bộ kết hợp hard fork trong các nút và các nút sau đó sẽ thay đổi từ việc chỉ tạo ra các khối thời đại Byron sang chỉ tạo ra các khối ERA Shelley.
Sau khi hard fork, sẽ không có khối kỷ nguyên Byron mới nào được ghi lại trên blockchain và các nút sẽ có thể hỗ trợ sản xuất, đặt cược và ủy quyền của khối phân tán.
Họ sẽ chuyển liền mạch từ OBFT sang cơ chế đồng thuận Ouroboros PRAOS.
Chúng tôi sẽ bước vào kỷ nguyên Shelley trên Mainnet.

## **Distributed stake pools and Decentralization of Block Production**

## ** Nhóm cổ phần phân tán và phân cấp sản xuất khối **

Central to Shelley is the idea of decentralization. IOHK believes that companies, systems, and platforms run by a single individual or central authority are more vulnerable and less fair. This is why it is crucial that we move block production to our supporters rather than keeping the power contained within our organizations.

Trung tâm của Shelley là ý tưởng phân cấp.
IOHK tin rằng các công ty, hệ thống và nền tảng được điều hành bởi một cá nhân hoặc cơ quan trung ương dễ bị tổn thương hơn và ít công bằng hơn.
Đây là lý do tại sao điều quan trọng là chúng tôi chuyển sản xuất khối cho những người ủng hộ của chúng tôi thay vì giữ sức mạnh trong các tổ chức của chúng tôi.

The Cardano blockchain currently operates on a federated basis. Effectively, nodes â€˜controlledâ€™ by IOHK and EMURGO are responsible for block production, while Daedalus wallet users act as the nodes of the network. Shelley will mark the â€˜beginning of the endâ€™ of that era, as we move from Byronâ€™s static federated system to an active, decentralized system.

Blockchain Cardano hiện đang hoạt động trên cơ sở liên kết.
Về mặt hiệu quả, các nút được IOHK và Emurgo kiểm soát chịu trách nhiệm sản xuất khối, trong khi người dùng ví Daedalus đóng vai trò là nút của mạng.
Shelley sẽ đánh dấu sự kết thúc của thời đại đó, khi chúng ta chuyển từ hệ thống liên kết tĩnh của Byron sang một hệ thống phi tập trung, hoạt động.

At the moment, core nodes and relays are owned and operated by IOHK. The network propagates through relays into each individual wallet. Once the system decentralizes, nodes will be run by stake pool operators and networked with individual wallets. Once control of the system is transferred over, the community will be fully running the Cardano ecosystem.

Hiện tại, các nút và rơle cốt lõi được sở hữu và vận hành bởi IOHK.
Mạng truyền bá thông qua các rơle vào từng ví riêng.
Khi hệ thống phân cấp, các nút sẽ được chạy bởi các nhà khai thác nhóm cổ phần và được nối mạng với các ví riêng lẻ.
Khi kiểm soát hệ thống được chuyển giao, cộng đồng sẽ hoàn toàn chạy hệ sinh thái Cardano.

## **Federated Block Production (Byron)**

## ** Sản xuất khối liên kết (Byron) **

Following the hard fork, IOHKâ€™s existing core nodes will initially produce all of the Shelley blocks, as in the Byron era. However, this will change over time, under the control of the built-in d (decentralization) parameter. This parameter can be considered as a control valve that allows increasing amounts of decentralization.

Theo sau hard fork, các nút lõi hiện tại của IOHK ban đầu sẽ tạo ra tất cả các khối Shelley, như trong kỷ nguyên Byron.
Tuy nhiên, điều này sẽ thay đổi theo thời gian, dưới sự kiểm soát của tham số D (phân cấp) tích hợp.
Tham số này có thể được coi là một van điều khiển cho phép tăng số lượng phân cấp.

In the decentralization phase, the federated system will still produce a (steadily decreasing) portion of the blocks. As this happens, stake pools will begin registering, operating, and producing blocks and will start to earn rewards in proportion to the stake that is delegated to them. As time passes, more blocks will be made by stake pools and fewer will be made by the core consensus nodes. The balance between the two will be controlled by the d parameter.

Trong giai đoạn phân cấp, hệ thống liên kết vẫn sẽ tạo ra một phần (giảm dần) của các khối.
Khi điều này xảy ra, các nhóm cổ phần sẽ bắt đầu đăng ký, vận hành và sản xuất các khối và sẽ bắt đầu kiếm được phần thưởng tương ứng với cổ phần được giao cho chúng.
Khi thời gian trôi qua, nhiều khối sẽ được thực hiện bởi các nhóm cổ phần và ít hơn sẽ được thực hiện bởi các nút đồng thuận cốt lõi.
Sự cân bằng giữa hai sẽ được kiểm soát bởi tham số D.

## **Distributed Block Production (Shelley and Beyond)**

## ** Sản xuất khối phân tán (Shelley và hơn thế nữa) **

We will use metrics like the amount of ada that has been staked to determine how quickly to change the d parameter and so to decentralize the network. Once the network has fully decentralized, the stake pools will completely take over block production. At that point, we will then be able to shut down the core consensus nodes and disable the d parameter. This is the first step towards the full decentralization of Cardano. We will return to that in future blog posts, when we discuss some of the exciting developments that the Shelley mainnet will enable.

Chúng tôi sẽ sử dụng các số liệu như số lượng ADA đã được đặt để xác định mức độ nhanh chóng thay đổi tham số D và vì vậy để phân cấp mạng.
Khi mạng đã phân cấp hoàn toàn, các nhóm cổ phần sẽ hoàn toàn tiếp quản sản xuất khối.
Tại thời điểm đó, sau đó chúng tôi sẽ có thể tắt các nút đồng thuận lõi và tắt tham số D.
Đây là bước đầu tiên hướng tới sự phân cấp đầy đủ của Cardano.
Chúng tôi sẽ trở lại với điều đó trong các bài đăng trên blog trong tương lai, khi chúng tôi thảo luận về một số phát triển thú vị mà Shelley Mainnet sẽ kích hoạt.

The road towards Shelley has been long but creating a global financial and social operating system takes time, scientific rigor, and the support of an informed, passionate community. As always, we thank you for your support and encourage you to follow our official channels closely as the Haskell Shelley testnet and subsequent phases roll out.

Con đường hướng tới Shelley đã dài nhưng tạo ra một hệ điều hành tài chính và xã hội toàn cầu cần có thời gian, sự nghiêm ngặt về khoa học và sự hỗ trợ của một cộng đồng đam mê, có hiểu biết.
Như mọi khi, chúng tôi cảm ơn bạn đã hỗ trợ và khuyến khích bạn theo dõi các kênh chính thức của chúng tôi một cách chặt chẽ khi Haskell Shelley Testnet và các giai đoạn tiếp theo được đưa ra.

