# How pledging will keep Cardano healthy
### **Warding off attacks on the decentralized blockchain is just one benefit of the process**
![](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.002.png) 12 May 2020![](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.002.png)[ Lars Brünjes](tmp//en/blog/authors/lars-brunjes/page-1/)![](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.003.png) 5 mins read

![Lars Brünjes](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.004.png)[](tmp//en/blog/authors/lars-brunjes/page-1/)
### [**Lars Brünjes**](tmp//en/blog/authors/lars-brunjes/page-1/)
Education Director

Education

- ![](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.005.png)[](mailto:lars.bruenjes@iohk.io "Email")
- ![](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.006.png)[](https://www.linkedin.com/in/dr-lars-br%C3%BCnjes-1640993b "LinkedIn")
- ![](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.007.png)[](https://twitter.com/LarsBrunjes "Twitter")
- ![](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.008.png)[](https://github.com/brunjlar "GitHub")

![How pledging will keep Cardano healthy](img/2020-05-12-how-pledging-encourages-a-healthy-decentralized-cardano-ecosystem.009.jpeg)

As we approach Shelley on the Cardano mainnet, decentralization has, inevitably, become a topic of debate. Regardless of any initial founding intent, proof-of-work cryptocurrencies such as Bitcoin and Ethereum have become more centralized over time. The early days of Bitcoin enthusiasts mining blocks at the weekend are long gone and today we see a small group of specialized, professional mining operations dominating their respective chains.

Khi chúng ta tiếp cận Shelley trên Cardano Mainnet, sự phân cấp, chắc chắn, đã trở thành một chủ đề tranh luận.
Bất kể ý định sáng lập ban đầu nào, các loại tiền điện tử làm việc như Bitcoin và Ethereum đã trở nên tập trung hơn theo thời gian.
Những ngày đầu của các khối khai thác của những người đam mê Bitcoin vào cuối tuần đã mất từ lâu và hôm nay chúng ta thấy một nhóm nhỏ các hoạt động khai thác chuyên nghiệp, chuyên môn thống trị chuỗi tương ứng của họ.

In itself, this isn’t necessarily a bad thing – but if it happened to Cardano, it would run contrary to the vision of a decentralized, proof-of-stake protocol. 

Bản thân nó, đây không nhất thiết là một điều xấu-nhưng nếu nó xảy ra với Cardano, nó sẽ chạy ngược lại với tầm nhìn của một giao thức phi tập trung, chứng minh cổ phần.

Cardano has been designed from the ground up with decentralization at its core and, in particular, in its stake delegation and reward mechanisms. On the Cardano network, pools above a certain size will not be competitive, and delegation rewards for everyone are optimal when there are many medium-sized pools. Every ecosystem benefits from diversity. Similarly, we believe that this approach offers the best balance between encouraging grass-roots involvement from skilled members of the community through to supporting those aiming to establish commercial stake pool businesses.

Cardano đã được thiết kế từ đầu với sự phân cấp ở cốt lõi của nó và đặc biệt, trong các cơ chế của phái đoàn và phần thưởng.
Trên mạng Cardano, các nhóm trên một kích thước nhất định sẽ không cạnh tranh và phần thưởng phái đoàn cho mọi người đều tối ưu khi có nhiều nhóm cỡ trung bình.
Mỗi hệ sinh thái đều được hưởng lợi từ sự đa dạng.
Tương tự, chúng tôi tin rằng phương pháp này cung cấp sự cân bằng tốt nhất giữa việc khuyến khích sự tham gia của cơ sở từ các thành viên có kỹ năng của cộng đồng cho đến việc hỗ trợ những người nhằm thành lập các doanh nghiệp cổ phần thương mại.

### **Pledging, and how it works**

### ** cam kết và cách thức hoạt động **

During pool registration, a pool operator can choose to pledge some personal stake to their pool to make the pool more attractive. The pledged amount can be changed on an epoch-by-epoch basis and will be returned when the pool is closed.

Trong quá trình đăng ký bể bơi, một nhà điều hành hồ bơi có thể chọn cam kết một số cổ phần cá nhân vào hồ bơi của họ để làm cho hồ bơi hấp dẫn hơn.
Số tiền cam kết có thể được thay đổi trên cơ sở từng epoch và sẽ được trả lại khi hồ bơi được đóng lại.

Everybody can operate a pool on the Cardano blockchain. No minimum pledge is required. Pool operators can optionally pledge some or all of their stake (or the stake of their friends and partners) to their pool to make their pool more attractive. The higher the amount of ada pledged, the more rewards the pool will receive, which will attract more delegation.

Mọi người đều có thể vận hành một hồ bơi trên blockchain Cardano.
Không cần cam kết tối thiểu.
Các nhà khai thác hồ bơi có thể tùy ý cam kết một số hoặc tất cả các cổ phần của họ (hoặc cổ phần của bạn bè và đối tác của họ) đến hồ bơi của họ để làm cho nhóm của họ hấp dẫn hơn.
Số lượng ADA cam kết càng cao, nhóm càng nhận được nhiều phần thưởng, điều này sẽ thu hút nhiều phái đoàn hơn.

It is important to remember that there is also no maximum pledge, so a pool operator with a lot of ada to stake can maximize their own rewards by saturating the pool with the pledge and not attracting any delegation. This will of course only be possible for very few operators; most operators will try to attract delegation with a combination of pledge, low costs, low margin and good performance.

Điều quan trọng cần nhớ là cũng không có cam kết tối đa, vì vậy một nhà điều hành hồ bơi có nhiều ADA để đặt cược có thể tối đa hóa phần thưởng của chính họ bằng cách bão hòa nhóm với cam kết và không thu hút bất kỳ phái đoàn nào.
Điều này tất nhiên sẽ chỉ có thể cho rất ít nhà khai thác;
Hầu hết các nhà khai thác sẽ cố gắng thu hút phái đoàn với sự kết hợp của cam kết, chi phí thấp, tỷ suất lợi nhuận thấp và hiệu suất tốt.

How attractive a pool is to delegators depends on four interacting elements:

Làm thế nào hấp dẫn một hồ bơi đối với các ủy viên phụ thuộc vào bốn yếu tố tương tác:

- operating costs (the lower, the better); 

- Chi phí vận hành (càng thấp, càng tốt);

- operator margin (the lower, the better);

- Biên độ vận hành (càng thấp, càng tốt);

- performance (the higher, the better);

- Hiệu suất (càng cao, càng tốt);

- level of pledge (the higher, the better). 

- Mức độ cam kết (càng cao, càng tốt).

By pledging more, the pool operator can ask for a higher operator margin while still being attractive to delegators.

Bằng cách cam kết nhiều hơn, nhà điều hành hồ bơi có thể yêu cầu biên độ vận hành cao hơn trong khi vẫn hấp dẫn các ủy viên.

### **Why is pledging necessary?**

### ** Tại sao cam kết cần thiết? **

Pledging provides a mechanism to encourage a healthy commercial ecosystem on the Cardano blockchain. The pledging mechanism is also necessary to protect the system against Sybil attacks. As I've discussed before, in a [Sybil attack](https://iohk.io/en/blog/posts/2018/10/29/preventing-sybil-attacks/), someone with very little personal stake creates hundreds of pools with low margins and tries to attract the majority of stake to their pools. If this succeeds, they can control consensus and engage in double-spending attacks, create forks, censor blocks, and damage or even destroy the system. 

Cam kết cung cấp một cơ chế để khuyến khích một hệ sinh thái thương mại lành mạnh trên blockchain Cardano.
Cơ chế cam kết cũng là cần thiết để bảo vệ hệ thống chống lại các cuộc tấn công của Sybil.
Như tôi đã thảo luận trước đây, trong một [cuộc tấn công Sybil] (https://iohk.io/en/blog/posts/2018/10/29/preventing-sybil-attacks/), một người có cổ phần cá nhân rất ít tạo ra hàng trăm
của các hồ bơi có tỷ suất lợi nhuận thấp và cố gắng thu hút phần lớn cổ phần vào hồ bơi của họ.
Nếu điều này thành công, họ có thể kiểm soát sự đồng thuận và tham gia vào các cuộc tấn công chi tiêu kép, tạo dĩa, khối kiểm duyệt và thiệt hại hoặc thậm chí phá hủy hệ thống.

By making pools with higher pledges more attractive, such attacks are prevented, because an attacker now needs to split their stake between many pools, making those pools less attractive and increasing the inherent cost of attempting a Sybil attack.

Bằng cách làm cho các nhóm có cam kết cao hơn hấp dẫn hơn, các cuộc tấn công như vậy được ngăn chặn, bởi vì một kẻ tấn công bây giờ cần phải phân chia cổ phần của họ giữa nhiều nhóm, làm cho các nhóm đó kém hấp dẫn và làm tăng chi phí cố hữu khi cố gắng tấn công Sybil.

### **How influential will pledging be?**

### ** Cam kết sẽ có ảnh hưởng như thế nào? **

We face a classic trade-off here: we want the system to be as decentralized as possible and we want to give as many people as possible the chance to operate a stake pool, so pledging should not have a big effect on rewards.

Chúng tôi phải đối mặt với sự đánh đổi cổ điển ở đây: Chúng tôi muốn hệ thống được phân cấp nhất có thể và chúng tôi muốn cung cấp cho càng nhiều người càng tốt để có cơ hội vận hành một nhóm cổ phần, vì vậy cam kết không nên có ảnh hưởng lớn đến phần thưởng.

On the other hand, we need to protect the system from Sybil attacks, and the higher the influence of pledging is, the more ada an attacker requires to succeed in such an attack.

Mặt khác, chúng ta cần bảo vệ hệ thống khỏi các cuộc tấn công của Sybil và ảnh hưởng của cam kết càng cao, một kẻ tấn công ADA càng đòi hỏi phải thành công trong một cuộc tấn công như vậy.

The goal is clear: we want to set the influence of pledging as low as possible, while still being able to guarantee security. 

Mục tiêu rất rõ ràng: Chúng tôi muốn thiết lập ảnh hưởng của việc cam kết càng thấp càng tốt, trong khi vẫn có thể đảm bảo bảo mật.

### **How do we determine the influence of pledging?**

### ** Làm thế nào để chúng tôi xác định ảnh hưởng của cam kết? **

The parameter that determines the influence of pledging will need to be set before the rollout of Shelley on the Cardano mainnet. However, the parameter has been designed to be flexible and adjustable over time. The [Shelley Haskell testnet](https://iohk.io/en/blog/posts/2020/04/29/from-byron-to-shelley-part-one-the-testnets/) will provide an ideal opportunity to tune this parameter and test which values work and which do not. We’re also developing a calculator to help pool operators model different pledge amounts and work out how this might affect delegation and thus their rewards and revenues.

Tham số xác định ảnh hưởng của việc cam kết sẽ cần được đặt trước khi triển khai Shelley trên Cardano Mainnet.
Tuy nhiên, tham số đã được thiết kế để linh hoạt và có thể điều chỉnh theo thời gian.
[Shelley Haskell Testnet] (https://iohk.io/en/blog/posts/2020/04/29/from-byron-to-shelley-part-one-the-testnet/) sẽ cung cấp cơ hội lý tưởng cho
Điều chỉnh tham số này và kiểm tra giá trị nào hoạt động và cái nào không.
Chúng tôi cũng phát triển một máy tính để giúp các nhà khai thác nhóm mô hình hóa các khoản cam kết khác nhau và tìm ra cách này có thể ảnh hưởng đến phái đoàn và do đó phần thưởng và doanh thu của họ.

Reasonable values depend on many factors: How much stake does a typical pool operator own? How expensive is it to operate a node? How many people are interested in operating a pool? We gathered a lot of data during the Incentivized Testnet, and we will gain even more from the next testnet in close collaboration with our users. 

Các giá trị hợp lý phụ thuộc vào nhiều yếu tố: một nhà điều hành nhóm điển hình có cổ phần sở hữu bao nhiêu cổ phần?
Làm thế nào đắt để vận hành một nút?
Có bao nhiêu người quan tâm đến việc vận hành một hồ bơi?
Chúng tôi đã thu thập rất nhiều dữ liệu trong Testnet được khuyến khích và chúng tôi sẽ đạt được nhiều hơn từ TestNet tiếp theo với sự hợp tác chặt chẽ với người dùng của chúng tôi.

We believe in our scientific approach and are confident that our design will lead to a decentralized, stable, and secure system – but science and mathematics only get you so far. You always have to make modeling assumptions, and no model can ever be as complex and colorful as the real world and the real people who make up the Cardano community. 

Chúng tôi tin vào cách tiếp cận khoa học của chúng tôi và tự tin rằng thiết kế của chúng tôi sẽ dẫn đến một hệ thống phi tập trung, ổn định và an toàn - nhưng khoa học và toán học chỉ đưa bạn đến nay.
Bạn luôn phải đưa ra các giả định mô hình hóa, và không có mô hình nào có thể phức tạp và đầy màu sắc như thế giới thực và những người thực sự tạo nên cộng đồng Cardano.

We have already seen some very positive contributions and debate on the topic, including on [Reddit](https://www.reddit.com/r/cardano/comments/gfed1l/cardano_mainnet_pledge_influence_factor_analysis/) and a recent [Cardano Effect](https://www.youtube.com/watch?v=ubWIytFZYGE) show. The Shelley Haskell testnets will be the perfect training ground for us to continue to debate, assess and iterate, collaborating with stake pool operators to see what is optimal for everyone. Just as we saw with the success of the Incentivized Testnet and the recently launched [Daedalus Flight user testing](https://iohk.io/en/blog/posts/2020/04/01/we-need-you-for-the-daedalus-flight-testing-program/), it’s again the time to draw upon the community’s help to put our research into practice.

Chúng tôi đã thấy một số đóng góp rất tích cực và tranh luận về chủ đề này, bao gồm trên [reddit] (https://www.reddit.com/r/cardano/comments/gfed1l/cardano_mainnet_pledge_influence_factor_analys
: //www.youtube.com/watch? V = ubwiytfzyge).
Testnets Shelley Haskell sẽ là nơi đào tạo hoàn hảo để chúng tôi tiếp tục tranh luận, đánh giá và lặp đi lặp lại, hợp tác với các nhà khai thác nhóm cổ phần để xem điều gì là tối ưu cho mọi người.
Đúng như chúng ta đã thấy với sự thành công của Testnet được khuyến khích và thử nghiệm người dùng chuyến bay Daedalus] (https://iohk.io/en/blog/posts/2020/04/01/we-we-you-for-
Chương trình thử nghiệm máy bay-Daedalus/), một lần nữa đã đến lúc thu hút sự giúp đỡ của cộng đồng để đưa nghiên cứu của chúng tôi vào thực tế.

