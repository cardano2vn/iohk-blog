# Combinator makes easy work of Shelley hard fork
### **A behind-the-scenes look with Duncan Coutts and Edsko de Vries** 
![](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.002.png) 7 May 2020![](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.002.png)[ Anthony Quinn](tmp//en/blog/authors/anthony-quinn/page-1/)![](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.003.png) 11 mins read

![Anthony Quinn](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.004.png)[](tmp//en/blog/authors/anthony-quinn/page-1/)
### [**Anthony Quinn**](tmp//en/blog/authors/anthony-quinn/page-1/)
Editor

Marketing & Communications

- ![](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.005.png)[](mailto:anthony.quinn@iohk.io "Email")
- ![](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.006.png)[](https://www.youtube.com/watch?v=KkcAic12dvc "YouTube")
- ![](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.007.png)[](https://www.linkedin.com/in/tony-quinn-frsa-0b093229 "LinkedIn")
- ![](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.008.png)[](https://twitter.com/IohkT "Twitter")

![Combinator makes easy work of Shelley hard fork](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.009.jpeg)

Since the launch of the Incentivized Testnet marked the coming of the Shelley era last year, the Cardano platform has entered a fast-moving period of development. The Ouroboros Classic consensus protocol has supported Cardano Byron and the ada cryptocurrency for the past 30 months, and weâ€™ll soon be switching to Ouroboros Praos. This is the version of our [proof-of-stake](https://iohk.io/en/blog/posts/2020/03/23/from-classic-to-hydra-the-implementations-of-ouroboros-explained/) (PoS) protocol that will initially power Shelley as Cardano decentralizes. It builds in the staking process with monetary rewards for ada holders and stake pool owners.

Kể từ khi ra mắt TestNet được khuyến khích đánh dấu sự xuất hiện của kỷ nguyên Shelley năm ngoái, nền tảng Cardano đã bước vào thời kỳ phát triển nhanh chóng.
Giao thức đồng thuận cổ điển Ouroboros đã hỗ trợ Cardano Byron và tiền điện tử ADA trong 30 tháng qua và chúng tôi sẽ sớm chuyển sang PRAO của Ouoboros.
Đây là phiên bản của [Proof-of-compet của chúng tôi (https://iohk.io/en/blog/posts/2020/03/23/from-blassic-to-hydra-the-implementations-of-ooboros-
Giải thích/) (POS) Giao thức ban đầu sẽ cung cấp năng lượng cho Shelley khi Cardano phân cấp.
Nó xây dựng trong quá trình đặt cược với phần thưởng tiền tệ cho chủ sở hữu ADA và chủ sở hữu nhóm cổ phần.

We upgraded Cardano on February 20 with a hard fork that switched the mainnet from the original consensus protocol, Ouroboros Classic, to an updated version, Ouroboros BFT. This BFT hard fork began a transition period under Ouroboros BFT, a slimmed-down version of the protocol designed to help us make the switch to Praos, while still preventing any malicious behaviour. Many probably didnâ€™t even notice. For Daedalus wallet users, it meant a standard software update. Exchanges had to upgrade manually, but they had several weeks to do this and we were on hand to help.

Chúng tôi đã nâng cấp Cardano vào ngày 20 tháng 2 với một hard Fork đã chuyển chính từ giao thức đồng thuận ban đầu, Ouroboros Classic, sang phiên bản cập nhật, OuroBoros BFT.
BFT Hard Fork này đã bắt đầu một giai đoạn chuyển tiếp theo Ouroboros BFT, một phiên bản giảm dần của giao thức được thiết kế để giúp chúng tôi chuyển sang PRAOS, trong khi vẫn ngăn chặn bất kỳ hành vi độc hại nào.
Nhiều người có lẽ đã không chú ý.
Đối với người dùng ví Daedalus, nó có nghĩa là một bản cập nhật phần mềm tiêu chuẩn.
Trao đổi đã phải nâng cấp thủ công, nhưng họ đã có vài tuần để làm điều này và chúng tôi đã có mặt để giúp đỡ.

The next event was the â€˜[Byron reboot](https://iohk.io/en/blog/posts/2020/03/30/what-the-byron-reboot-means-for-cardano/)â€™ on March 30. This released totally new code for many of the Cardano components, including a new node to support delegation and decentralization, and future Shelley features. A big advantage of the new code base is that it has been redesigned to be modular, so many components can be changed without affecting the others.

Sự kiện tiếp theo là phần khởi động lại [Byron] (https://iohk.io/en/blog/posts/2020/03/30/what-the-byron-reboot-mean-for-cardano/) â € €
™ vào ngày 30 tháng 3. Điều này đã phát hành mã hoàn toàn mới cho nhiều thành phần Cardano, bao gồm một nút mới để hỗ trợ phái đoàn và phân cấp, và các tính năng Shelley trong tương lai.
Một lợi thế lớn của cơ sở mã mới là nó đã được thiết kế lại để được mô -đun, vì vậy nhiều thành phần có thể được thay đổi mà không ảnh hưởng đến các thành phần khác.

In turn, the BFT will act as the jumping off point for the Shelley hard fork, which will happen once weâ€™re happy with the Haskell testnet. This second hard fork will be a similar process to the February one for exchanges, ada holders and wallet users, and, hopefully, just as much of a non-event.

Đổi lại, BFT sẽ đóng vai trò là điểm nhảy ra cho Shelley Hard Fork, điều này sẽ xảy ra một khi chúng ta hài lòng với Haskell Testnet.
Ngựa cứng thứ hai này sẽ là một quá trình tương tự như tháng hai đối với các trao đổi, người nắm giữ ADA và người dùng ví, và, hy vọng, cũng không giống như sự kiện.

However, while everything looks smooth on the surface, there is a lot of hidden activity going on. Like a duck serenely swimming across a pond â€“ while its feet are furiously paddling below the calm waters â€“ our blockchain engineers are hard at it.

Tuy nhiên, trong khi mọi thứ trông trơn tru trên bề mặt, có rất nhiều hoạt động ẩn đang diễn ra.
Giống như một con vịt thanh thản bơi qua một cái ao - trong khi đôi chân của nó đang chèo thuyền bên dưới vùng nước yên tĩnh - các kỹ sư blockchain của chúng tôi rất khó khăn.

So, we sat down two of the leading engineers on the Cardano project, Duncan Coutts and Edsko de Vries, to find out how theyâ€™ve done it. Duncan has been Cardanoâ€™s architectural lead for the past three years, and between them, Duncan and Edsko have spent 35 years using Haskell, the programming language being used to develop Cardano.

Vì vậy, chúng tôi đã ngồi xuống hai trong số các kỹ sư hàng đầu trong dự án Cardano, Duncan Coutts và Edsko de Vries, để tìm hiểu cách họ thực hiện nó.
Duncan đã trở thành người dẫn đầu về kiến trúc của Cardano trong ba năm qua, và giữa họ, Duncan và Edsko đã dành 35 năm để sử dụng Haskell, ngôn ngữ lập trình được sử dụng để phát triển Cardano.

**Duncan, how did you do it?**

** Duncan, bạn đã làm như thế nào? **

As described in the Cardano roadmap, IOHKâ€™s blockchain engineers believe in smooth code updates. Instead of trying to do the jump from Ouroboros Classic to Praos in a single update â€“ which would be an incredibly complex task â€“ itâ€™s been a two-stage approach using Ouroboros BFT as an intermediary (Figure 1). The BFT code is compatible with both the Byron-era federated nodes and the Shelley-style nodes released in the Byron reboot. It's like a relay race: one runner (in our case, running one protocol) enters the handover box where the other runner is waiting; they synchronise their speeds (so they're perfectly compatible with each other) and then hand over the baton (operating the mainnet), and then the new runner with the baton continues from the handover box for the next lap.

Như được mô tả trong Lộ trình Cardano, các kỹ sư blockchain của IOHK tin vào các bản cập nhật mã trơn tru.
Thay vì cố gắng thực hiện bước nhảy từ Ouroboros Classic sang Praos trong một bản cập nhật duy nhất-đó sẽ là một nhiệm vụ cực kỳ phức tạp-Đó là cách tiếp cận hai giai đoạn sử dụng Ouroboros BFT làm trung gian (Hình 1).
Mã BFT tương thích với cả các nút liên kết thời kỳ Byron và các nút kiểu Shelley được phát hành trong phần khởi động lại Byron.
Nó giống như một cuộc đua tiếp sức: một người chạy (trong trường hợp của chúng tôi, chạy một giao thức) vào hộp bàn giao nơi người chạy khác đang chờ;
Họ đồng bộ hóa tốc độ của mình (vì vậy chúng hoàn toàn tương thích với nhau) và sau đó giao dùi cui (vận hành chính), và sau đó người chạy mới với Baton tiếp tục từ hộp bàn giao cho vòng đua tiếp theo.

![Mainnet Byron to Shelley roadmap](img/2020-05-07-combinator-makes-easy-work-of-shelley-hard-fork.010.jpeg) 

**Figure 1. Mainnet Byron to Shelley roadmap**

** Hình 1. Mainnet Byron đến lộ trình Shelley **

The [Daedalus Flight](https://iohk.io/en/blog/posts/2020/04/01/we-need-you-for-the-daedalus-flight-testing-program/) process has helped us quickly develop and test a new wallet and, once everyone is running that on the mainnet, and once we finish swapping over the core nodes, the old code is redundant. We are in that transition phase right now, with a new mainnet Daedalus wallet released on April 24.

Chuyến bay [Daedalus] (https://iohk.io/en/blog/posts/2020/04/01/we-need-you-for-the-daedalus-flight-testing-program/) đã giúp chúng tôi nhanh chóng nhanh chóng
Phát triển và kiểm tra một ví mới và, một khi mọi người đang chạy nó trên chính và một khi chúng tôi hoàn thành việc hoán đổi các nút cốt lõi, mã cũ sẽ dư thừa.
Chúng tôi đang trong giai đoạn chuyển tiếp đó ngay bây giờ, với một ví Mainnet Daedalus mới được phát hành vào ngày 24 tháng 4.

Our aim is to have a â€˜graceful entry into Shelleyâ€™, as IOHK chief Charles Hoskinson describes in his [whiteboard video about the hard fork](https://www.youtube.com/watch?v=g7uySEgt06c). A vital tool in making this move has been creating a hard fork combinator.

Mục đích của chúng tôi là có một mục nhập lớn vào Shelleyâ € ™, như người đứng đầu IOHK Charles Hoskinson mô tả trong [Video Whiteboard của anh ấy về hard fork] (https://www.youtube.com/watch?v=g7uySegt06c).
Một công cụ quan trọng trong việc thực hiện động thái này đã tạo ra một tổ hợp hard fork.

**That sounds like farm machinery. What is it?**

** Nghe có vẻ như máy móc nông trại.
Nó là gì?**

A combinator is just a technical term for something that combines other things. For example, addition is a combinator on numbers. A hard fork combinator combines two *protocols* into a single protocol. We call this a sequential combination of the two protocols because it runs the first protocol for a while and at some point it switches over to the second. In our case, this is two versions of Ouroboros as we move from BTF to Praos.

Một tổ hợp chỉ là một thuật ngữ kỹ thuật cho một cái gì đó kết hợp những thứ khác.
Ví dụ, bổ sung là một tổ hợp về số.
Một tổ hợp hard fork kết hợp hai giao thức * * thành một giao thức duy nhất.
Chúng tôi gọi đây là sự kết hợp tuần tự của hai giao thức vì nó chạy giao thức đầu tiên trong một thời gian và tại một số điểm, nó chuyển sang thứ hai.
Trong trường hợp của chúng tôi, đây là hai phiên bản của Ouroboros khi chúng tôi chuyển từ BTF sang Praos.

The clever part of all this has been the use of discrete modules that do their job, while knowing as little as possible about each other and the blockchain. Simplicity is the key here and this process of taking out the details we call â€˜abstractionâ€™. Most of the consensus modules donâ€™t even have to know that theyâ€™re dealing with a cryptocurrency and could be putting pretty much anything on a blockchain. For example, weâ€™ve done seminars using the example of a PokÃ©mon ledger on a Ouroboros blockchain. The only thing thatâ€™s different is the ledger rules; the consensus is all the same. You just set it up â€“ â€˜instantiateâ€™ it in the programming jargon â€“ with the rules for playing PokÃ©mon rather than for UTXO-style accounting.[For readers with a technical interest, watch out for Edsko delving further into the â€˜abstractionâ€™ process and combinators in a future blog post.]

Phần thông minh của tất cả những điều này là việc sử dụng các mô -đun riêng biệt thực hiện công việc của họ, trong khi biết càng ít càng tốt về nhau và blockchain.
Đơn giản là chìa khóa ở đây và quá trình lấy ra các chi tiết chúng tôi gọi là - ˜abstractionâ € ™.
Hầu hết các mô -đun đồng thuận thậm chí không phải biết rằng họ đang đối phó với một loại tiền điện tử và có thể đặt khá nhiều thứ trên một blockchain.
Ví dụ, chúng tôi đã thực hiện các cuộc hội thảo bằng cách sử dụng ví dụ về sổ cái PokÃ © trên một blockchain Ouroboros.
Điều duy nhất khác nhau là các quy tắc sổ cái;
Sự đồng thuận là tất cả giống nhau.
Bạn chỉ cần thiết lập nó-â € ˜Tantiateâ € ™ nó trong thuật ngữ lập trình-với các quy tắc để chơi pokÃ © mon thay vì kế toán theo phong cách utxo.
Đi sâu hơn vào quy trình và tổ hợp và kết hợp trong một bài đăng trên blog trong tương lai.]

**You make it sound simple**

** Bạn làm cho nó nghe đơn giản **

In fact, itâ€™s tricky because Cardano is running the ada cryptocurrency, and a pile of other things, at the same time. Think of it as changing all the wheels on a car while youâ€™re driving along and towing a caravan. So we have to be sure we can do this in a totally reliable way.

Trên thực tế, đó là một cách khó khăn vì Cardano đang điều hành tiền điện tử ADA và một đống những thứ khác, cùng một lúc.
Hãy nghĩ về nó như thay đổi tất cả các bánh xe trên một chiếc xe trong khi bạn đang lái xe và kéo một caravan.
Vì vậy, chúng tôi phải chắc chắn rằng chúng tôi có thể làm điều này theo một cách hoàn toàn đáng tin cậy.

We could have tackled this as a one-off task, but it made sense to do it in a generic way using a protocol combinator. We chose this route because we get a better result and the testing that is vital to ensuring the code works is made far easier. On top of that, there will be more hard forks to come, which made the choice even clearer. For example, as we near the culmination of Cardanoâ€™s development and move through the Goguen, Basho, and Voltaire eras, there will be at least one hard fork at each stage.

Chúng tôi có thể đã giải quyết vấn đề này như một nhiệm vụ một lần, nhưng thật có ý nghĩa khi thực hiện nó theo cách chung bằng cách sử dụng một tổ hợp giao thức.
Chúng tôi đã chọn tuyến đường này vì chúng tôi có kết quả tốt hơn và thử nghiệm rất quan trọng để đảm bảo mã hoạt động được thực hiện dễ dàng hơn nhiều.
Trên hết, sẽ có nhiều cái nút khó đến, điều này làm cho sự lựa chọn thậm chí còn rõ ràng hơn.
Ví dụ, khi chúng tôi ở gần đỉnh cao của sự phát triển của Cardano và di chuyển qua thời đại Goguen, Basho và Voltaire, sẽ có ít nhất một ngã ba khó khăn ở mỗi giai đoạn.

**So how did you cope with the tricky bits?**

** Vậy bạn đã đối phó với các bit khó khăn như thế nào? **

Well, first off, we had to do it without research to turn to. The researchers describe a single protocol as a free-standing, perfect thing. But thatâ€™s not where we are. We are trying to run Praos after having started with a chain that was using something else. What Edskoâ€™s working on, going from one protocol to another in a generic way, is just not covered in the research. And itâ€™s hard, itâ€™s complicated. All the details need a lot of thinking, a lot of scratching your head. But switching between Cardano code bases is not the sort of thing the academics can expect to get published. It doesnâ€™t have a novel aspect and is seen as just an implementation issue.

Chà, trước hết, chúng tôi phải làm điều đó mà không cần nghiên cứu để hướng tới.
Các nhà nghiên cứu mô tả một giao thức duy nhất là một điều hoàn hảo, tự do.
Nhưng đó không phải là nơi chúng ta đang ở.
Chúng tôi đang cố gắng chạy Praos sau khi bắt đầu với một chuỗi đang sử dụng thứ khác.
Những gì Edsko đang làm việc, đi từ giao thức này sang giao thức khác theo cách chung, không được đề cập trong nghiên cứu.
Và khó khăn, nó phức tạp.
Tất cả các chi tiết cần rất nhiều suy nghĩ, rất nhiều người gãi đầu.
Nhưng việc chuyển đổi giữa các cơ sở mã Cardano không phải là điều mà các học giả có thể mong đợi để được xuất bản.
Nó không có một khía cạnh mới lạ và được coi là một vấn đề thực hiện.

**Edsko, can you give us an example?**

** edsko, bạn có thể cho chúng tôi một ví dụ không? **

As Duncan says, for the researchers, these implementation issues are trivial but dealing with them is 99% of what we do. Take the problem of time for a blockchain. Itâ€™s what Iâ€™ve been banging my head against for a couple of weeks. Time is divided into slots where the chain can contain at most one block per slot. We often need to convert between slot numbers and time in the real world, for example when a node needs to know â€˜Is it my turn?â€™ to generate the next block. This is fundamental to Cardano, but the length of a slot changes after the hard fork. For Byron, a slot is 20 seconds; for Shelley, it will be two seconds, or perhaps one. To really complicate things, the exact point of time when the hard fork is made is decided on the chain itself. Yet, I need to know when the changeover point is. Itâ€™s a quandary: to do slot conversions I need to know the state of the blockchain, but to know the state I need to know the slot conversions!

Như Duncan nói, đối với các nhà nghiên cứu, các vấn đề thực hiện này là tầm thường nhưng đối phó với chúng là 99% những gì chúng ta làm.
Lấy vấn đề về thời gian cho một blockchain.
Đó là những gì tôi đã đập đầu vào một vài tuần.
Thời gian được chia thành các khe trong đó chuỗi có thể chứa tối đa một khối trên mỗi khe.
Chúng ta thường cần chuyển đổi giữa các số khe và thời gian trong thế giới thực, ví dụ như khi một nút cần biết - đó là lượt của tôi? "Để tạo khối tiếp theo.
Đây là nền tảng cho Cardano, nhưng độ dài của một khe thay đổi sau khi khó khăn.
Đối với Byron, một khe là 20 giây;
Đối với Shelley, nó sẽ là hai giây, hoặc có lẽ là một.
Để thực sự làm phức tạp mọi thứ, thời điểm chính xác khi fork hard được thực hiện được quyết định trên chính chuỗi.
Tuy nhiên, tôi cần biết khi nào điểm thay đổi là.
Đó là một khó khăn: để thực hiện chuyển đổi khe tôi cần biết trạng thái của blockchain, nhưng để biết trạng thái tôi cần biết các chuyển đổi khe!

This is real chicken-and-egg territory with many complex things to disentangle. We have to be very precise with how we do things. It might be trivial in theory, but itâ€™s very difficult to disentangle things and make sure itâ€™s not a circular problem.

Đây là lãnh thổ gà và trứng thực sự với nhiều điều phức tạp để giải quyết.
Chúng ta phải rất chính xác với cách chúng ta làm mọi việc.
Nó có thể là tầm thường về mặt lý thuyết, nhưng rất khó để giải quyết mọi thứ và đảm bảo rằng đó không phải là vấn đề tròn.

**We canâ€™t afford for it to be wrong, so how do you know youâ€™re right?**

** Chúng tôi không thể đủ khả năng để nó sai, vậy làm thế nào để bạn biết bạn đúng không? **

*Duncan*: Thatâ€™s an excellent question. My reply is that you come to the answer on two levels. The first is intellectual: you analyse the problem, you do the maths, you talk to colleagues and wrestle with it until you can see how it all fits together. Second, we do all our QuickCheck testing to give us the confidence that this does what we think it does. We do extensive testing that really takes us into the unusual cases that you might never think of, including this changeover. We can do 100,000 tests every time we change a line of code. [Lars BrÃ¼njes has written about how John Hughes, one of the creators of Haskell, has helped [IOHK develop its testing strategies](https://iohk.io/en/blog/posts/2018/09/26/functional-correctness-with-the-haskell-master/).]

*Duncan*: Đó là một câu hỏi tuyệt vời.
Câu trả lời của tôi là bạn đến câu trả lời ở hai cấp độ.
Đầu tiên là trí tuệ: Bạn phân tích vấn đề, bạn làm toán, bạn nói chuyện với các đồng nghiệp và vật lộn với nó cho đến khi bạn có thể thấy tất cả phù hợp với nhau như thế nào.
Thứ hai, chúng tôi thực hiện tất cả các thử nghiệm QuickCheck của chúng tôi để cung cấp cho chúng tôi sự tự tin rằng điều này làm những gì chúng tôi nghĩ nó làm.
Chúng tôi thực hiện thử nghiệm rộng rãi thực sự đưa chúng tôi vào các trường hợp bất thường mà bạn có thể không bao giờ nghĩ đến, kể cả sự thay đổi này.
Chúng tôi có thể thực hiện 100.000 bài kiểm tra mỗi khi chúng tôi thay đổi một dòng mã.
.
-with-the-Haskell-master/).].

*Edsko*: Yes, I agree with those two points. In terms of the combinator, I resolve these things by thinking about the guarantees that the code I write needs to provide, and which guarantees that it, in turn, needs from the ledger. I sketch a mathematical proof that this â€˜if-thenâ€™ reasoning is indeed justified, and then turn to the formal method teams. The formal methods team are the people who set up the mathematical rules that describe the blockchain, and they can then tweak the rules in such a way that they provide the required guarantees.

*EDSKO*: Vâng, tôi đồng ý với hai điểm đó.
Về mặt tổ hợp, tôi giải quyết những điều này bằng cách suy nghĩ về các đảm bảo mà mã tôi viết cần phải cung cấp và đến lượt nó, nó cần từ sổ cái.
Tôi phác thảo một bằng chứng toán học rằng lý luận này thực sự là lý do, và sau đó chuyển sang các nhóm phương pháp chính thức.
Nhóm phương pháp chính thức là những người thiết lập các quy tắc toán học mô tả blockchain và sau đó họ có thể điều chỉnh các quy tắc theo cách mà họ cung cấp các bảo đảm cần thiết.

In terms of Duncanâ€™s second point, I know the time issue I mentioned above is correct by thinking hard mathematically, and by testing. Timing decisions are easy when we have the full blockchain, but are hard when we have to make predictions about the future. Fortunately, the way we set things up means I can easily create testing blockchains. So, I can create a full blockchain, then slice this chain in half. I take the first half and consider that to be in the present; and set the other half in the future. Then I can use the â€˜presentâ€™ (first half) to make predictions about the â€˜futureâ€™ (the second half) and verify them against the whole thing (on which the calculations are easy). If they match, then I know everything is OK.

Về điểm thứ hai của Duncan, tôi biết vấn đề thời gian tôi đã đề cập ở trên là chính xác bằng cách suy nghĩ khó khăn về mặt toán học và bằng cách kiểm tra.
Các quyết định thời gian rất dễ dàng khi chúng ta có toàn bộ blockchain, nhưng khó khăn khi chúng ta phải đưa ra dự đoán về tương lai.
May mắn thay, cách chúng tôi thiết lập mọi thứ có nghĩa là tôi có thể dễ dàng tạo ra các blockchain thử nghiệm.
Vì vậy, tôi có thể tạo một blockchain đầy đủ, sau đó cắt chuỗi này làm đôi.
Tôi lấy nửa đầu và xem xét điều đó là ở hiện tại;
và đặt nửa còn lại trong tương lai.
Sau đó, tôi có thể sử dụng "(nửa đầu tiên) (nửa đầu) để đưa ra dự đoán về" Future "(nửa thứ hai) và xác minh chúng chống lại toàn bộ sự việc (trên đó tính toán dễ dàng).
Nếu họ phù hợp, thì tôi biết mọi thứ đều ổn.

**When did you start on this?**

** Khi nào bạn bắt đầu về điều này? **

Right after Duncan came up with the genius idea of the OBFT. So Iâ€™ve been thinking about the combinator on and off for about 18 months. It was a design goal from the very beginning of our modular rewrite of Ouroboros starting in October 2018, with my first commit to the GitHub repository. We had a prototype demonstration with OBFT and Praos soon after, in December 2018.

Ngay sau khi Duncan nảy ra ý tưởng thiên tài của OBFT.
Vì vậy, tôi đã suy nghĩ về việc kết hợp trong và tắt trong khoảng 18 tháng.
Đó là một mục tiêu thiết kế ngay từ khi bắt đầu viết lại mô -đun của chúng tôi bắt đầu vào tháng 10 năm 2018, với cam kết đầu tiên của tôi đối với kho lưu trữ GitHub.
Chúng tôi đã có một cuộc biểu tình nguyên mẫu với OBFT và Praos ngay sau đó, vào tháng 12 năm 2018.

**And how many people have been involved?**

** Và có bao nhiêu người đã tham gia? **

*Duncan*: Many people have been working on the consensus code, but whenever we have anything really hard, like this combinator, we give it to Edsko: heâ€™s our software engineer extraordinaire! This is Haskell programming as free climbing, rather than climbing with the ropes of formal methods for support.

*Duncan*: Nhiều người đã làm việc theo mã đồng thuận, nhưng bất cứ khi nào chúng tôi có bất cứ điều gì thực sự khó khăn, như tổ hợp này, chúng tôi đưa nó cho Edsko: Anh ấy là kỹ sư phần mềm của chúng tôi Extraordinaire!
Đây là chương trình Haskell như leo núi miễn phí, thay vì leo lên với những sợi dây của các phương pháp chính thức để hỗ trợ.

**Any final thoughts?**

** Bất kỳ suy nghĩ cuối cùng? **

*Duncan*: The code that was running is right now being phased out and pretty soon the code that was running Cardano a month ago will no longer exist. Once everyone is running the new code on the mainnet and once we finish swapping over the core nodes, the old code is redundant. We are in that transition phase right now and no one is shouting that the sky is falling. No one has noticed it.

*Duncan*: Mã đang chạy hiện đang bị loại bỏ và chẳng mấy chốc, mã đang chạy Cardano một tháng trước sẽ không còn tồn tại.
Khi mọi người đang chạy mã mới trên chính và một khi chúng tôi hoàn thành việc hoán đổi các nút cốt lõi, mã cũ sẽ dư thừa.
Chúng tôi đang trong giai đoạn chuyển tiếp đó ngay bây giờ và không ai hét lên rằng bầu trời đang rơi xuống.
Không ai nhận thấy nó.

*Edsko*: That is quite an achievement in its own right. The idea of OBFT was crucial in making the transition, but itâ€™s not relevant any more once we make that transition to Shelley. This has been a way for us genuinely to ditch legacy code, which is often very difficult to do, as the banks know to their cost.

*EDSKO*: Đó là một thành tựu khá riêng theo đúng nghĩa của nó.
Ý tưởng về OBFT là rất quan trọng trong việc thực hiện quá trình chuyển đổi, nhưng nó không liên quan nữa khi chúng ta thực hiện quá trình chuyển đổi đó sang Shelley.
Đây là một cách để chúng tôi thực sự bỏ mã di sản, điều này thường rất khó thực hiện, vì các ngân hàng biết chi phí của họ.

*Duncan*: And if it all works fine, you wonâ€™t notice anything.

*Duncan*: Và nếu tất cả đều hoạt động tốt, bạn sẽ không nhận thấy bất cứ điều gì.

**Duncan and Edsko, thank you for your time. I think weâ€™d better let you both get back to it.**

** Duncan và Edsko, cảm ơn bạn đã dành thời gian.
Tôi nghĩ rằng tốt hơn là chúng ta nên để cả hai bạn quay lại với nó. **

