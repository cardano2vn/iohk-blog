# Cardano’s path to decentralization
### **Three mini-protocols are vital to the network’s operation**
![](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.002.png) 9 July 2020![](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.002.png)[ Marcin Szamotulski](tmp//en/blog/authors/marcin-szamotulski/page-1/)![](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.003.png) 6 mins read

![Marcin Szamotulski](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.004.png)[](tmp//en/blog/authors/marcin-szamotulski/page-1/)
### [**Marcin Szamotulski**](tmp//en/blog/authors/marcin-szamotulski/page-1/)
Software Engineering Lead

Engineering

- ![](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.005.png)[](mailto:marcin.szamotulski@iohk.io "Email")
- ![](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.006.png)[](https://www.linkedin.com/in/marcin-szamotulski/ "LinkedIn")
- ![](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.007.png)[](https://twitter.com/me_coot "Twitter")
- ![](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.008.png)[](https://github.com/coot "GitHub")

![Cardano’s path to decentralization](img/2020-07-09-cardanos-path-to-decentralization-by-marcin-szamotulski.009.jpeg)

The next releases of Cardano and the Ouroboros protocol contain changes that guide us towards decentralization and the Shelley era. This Deep Dive post explains how we are approaching this phase. With the release of the Praos algorithm for Shelley, which comes with the staking process, stake pools can be set up so ada owners can delegate their stake. The networking team is focused now on two features that will enable us to run a fully decentralized system. Let me first briefly describe how the networking is designed and engineered and give an overview of where we are at the moment. This post will start at the top of our abstractions and go down the stack. Hopefully, this will be an interesting journey through our design.

Các bản phát hành tiếp theo của Cardano và Nghị định thư Ouroboros có chứa những thay đổi hướng dẫn chúng ta hướng tới sự phân cấp và kỷ nguyên Shelley.
Bài lặn sâu này giải thích cách chúng ta đang tiếp cận giai đoạn này.
Với việc phát hành thuật toán PRAOS cho Shelley, đi kèm với quá trình đặt cược, các nhóm cổ phần có thể được thiết lập để chủ sở hữu ADA có thể ủy thác cổ phần của họ.
Nhóm mạng hiện đang tập trung vào hai tính năng cho phép chúng tôi chạy một hệ thống phi tập trung hoàn toàn.
Trước tiên, hãy để tôi mô tả ngắn gọn cách thức mạng được thiết kế và thiết kế và đưa ra một cái nhìn tổng quan về nơi chúng ta đang ở vào lúc này.
Bài đăng này sẽ bắt đầu ở đầu các trừu tượng của chúng tôi và đi xuống ngăn xếp.
Hy vọng, đây sẽ là một hành trình thú vị thông qua thiết kế của chúng tôi.

## **Typed protocols**

## ** Giao thức gõ **

At the very top of the stack is IOHK’s typed-protocols framework, which allows us to design application-level protocols. The top-level goal of protocol design for Ouroboros is to distribute chains of blocks and transactions among participants in the network and that is achieved by three mini-protocols:

Ở đầu ngăn xếp là khung giao thức được đánh máy của IOHK, cho phép chúng tôi thiết kế các giao thức cấp ứng dụng.
Mục tiêu cấp cao nhất của thiết kế giao thức cho Ouroboros là phân phối chuỗi khối và giao dịch giữa những người tham gia mạng và điều đó đạt được bằng ba giao thức nhỏ:

- *chain-sync* is used to efficiently sync a chain of headers;

- * Chuỗi-sync * được sử dụng để đồng bộ hóa hiệu quả một chuỗi các tiêu đề;

- *block-fetch* allows us to pull blocks;

- * Khối-Fetch * cho phép chúng tôi kéo các khối;

- *tx-submission* is used to submit transactions.

- * TX-Submission * được sử dụng để gửi giao dịch.

All three mini-protocols were carefully designed after considering the threats that can arise running a decentralized system. This is very important, because cyber attacks are very common, especially against targets that present strong incentives. There is a range of possible attacks at this level that we need to be able to defend against and one type that we were very careful about is resource-consumption attacks. To defend against such attacks, the protocols allow the consumer side to stay in control of how much data it will receive, and ultimately keep use of its resources (eg, memory, CPU, and open file descriptors) below a certain level.

Tất cả ba giao thức nhỏ đều được thiết kế cẩn thận sau khi xem xét các mối đe dọa có thể phát sinh chạy một hệ thống phi tập trung.
Điều này rất quan trọng, bởi vì các cuộc tấn công trên mạng là rất phổ biến, đặc biệt là chống lại các mục tiêu thể hiện các ưu đãi mạnh mẽ.
Có một loạt các cuộc tấn công có thể có ở cấp độ này mà chúng ta cần có khả năng bảo vệ chống lại và một loại mà chúng ta rất cẩn thận về các cuộc tấn công tiêu thụ tài nguyên.
Để bảo vệ chống lại các cuộc tấn công như vậy, các giao thức cho phép phía người tiêu dùng kiểm soát số lượng dữ liệu sẽ nhận được và cuối cùng tiếp tục sử dụng tài nguyên của mình (ví dụ: bộ nhớ, CPU và mô tả tệp mở) dưới một mức nhất định.

If you are interested in more details about typed-protocols, we gave talks and ran workshops at Haskell events last year and these were very well received by the engineering community. In particular, see the talk by [Duncan Coutts talk at Haskell eXchange](https://skillsmatter.com/skillscasts/14633-45-minute-talk-by-duncan-coutts) and the workshop I ran at [Monadic Party](https://www.youtube.com/watch?v=j8gza2L61nM).

Nếu bạn quan tâm đến nhiều chi tiết hơn về các giao thức đánh máy, chúng tôi đã nói chuyện và điều hành các hội thảo tại các sự kiện Haskell năm ngoái và những điều này đã được cộng đồng kỹ thuật đón nhận rất tốt.
Cụ thể, hãy xem bài nói chuyện của [Duncan Coutts Talk tại Haskell Exchange] (https://skillsmatter.com/skillscasts/14633-45-minute-Talk-by-Duncan-Coutts) và hội thảo tôi đã chạy tại [Đảng Monadic]
(https://www.youtube.com/watch?v=j8GZA2L61NM).

## **Role of the multiplexer**

## ** Vai trò của bộ ghép kênh **

TCP/IP protocols form the most ubiquitous protocol suite deployed on the internet. They are also some of the most studied protocols and are available on almost every operating system and computer architecture, so are a good first choice for our purposes. TCP/IP gives us access to a two-way communication channel between servers on the internet. The only high-level requirement of typed-protocols is an ordered delivery of network packets, which is guaranteed by the TCP protocol.

Các giao thức TCP/IP tạo thành bộ giao thức phổ biến nhất được triển khai trên Internet.
Chúng cũng là một số giao thức được nghiên cứu nhiều nhất và có sẵn trên hầu hết mọi hệ điều hành và kiến trúc máy tính, vì vậy là lựa chọn đầu tiên tốt cho mục đích của chúng tôi.
TCP/IP cho phép chúng tôi truy cập vào kênh liên lạc hai chiều giữa các máy chủ trên Internet.
Yêu cầu cấp cao duy nhất của các giao thức đánh máy là việc phân phối các gói mạng được đặt hàng, được đảm bảo bởi giao thức TCP.

Operating systems limit the number of connections at any one time. For example, Linux, by default, can open 1,024 connections per process, but on macOS the limit is just 256. To avoid excessive use of resources we use a multiplexer. This allows us to combine communication channels into a single one, so we can run all three of our mini-protocols on a single TCP connection. Another way to save resources is to use the bi-directionality of TCP: this means that one can send and receive messages at both ends simultaneously. We haven't used that feature in the Byron Reboot era, but we do want to take advantage of it in the decentralized Shelley era.

Hệ điều hành giới hạn số lượng kết nối tại một thời điểm.
Ví dụ, Linux, theo mặc định, có thể mở 1.024 kết nối cho mỗi quy trình, nhưng trên MacOS, giới hạn chỉ là 256. Để tránh sử dụng quá nhiều tài nguyên, chúng tôi sử dụng bộ ghép kênh.
Điều này cho phép chúng tôi kết hợp các kênh liên lạc thành một kênh duy nhất, vì vậy chúng tôi có thể chạy cả ba giao thức mini trên một kết nối TCP duy nhất.
Một cách khác để lưu tài nguyên là sử dụng tính hai chiều của TCP: điều này có nghĩa là người ta có thể gửi và nhận tin nhắn ở cả hai đầu cùng một lúc.
Chúng tôi đã không sử dụng tính năng đó trong kỷ nguyên khởi động lại Byron, nhưng chúng tôi muốn tận dụng nó trong kỷ nguyên Shelley phi tập trung.

## **The peer-to-peer-governor**

## ** Thống đốc ngang hàng **

We want to use bi-directional connections, running all three mini-protocols in both directions, so we need to have a component that is aware which connections are currently running. When a node connects to a new peer, we can first check if it already has an open connection with that peer, which would be the case if the peer had connected to it already. But this is only one part of connection management that we will need.

Chúng tôi muốn sử dụng các kết nối hai chiều, chạy cả ba giao thức nhỏ theo cả hai hướng, vì vậy chúng tôi cần có một thành phần nhận thức được kết nối nào hiện đang chạy.
Khi một nút kết nối với một ngang hàng mới, trước tiên chúng ta có thể kiểm tra xem nó đã có kết nối mở với ngang hàng đó, đó sẽ là trường hợp nếu người ngang hàng đã kết nối với nó.
Nhưng đây chỉ là một phần của quản lý kết nối mà chúng ta sẽ cần.

Another requirement comes from the peer-to-peer governor. This part of the system is responsible for finding peers, and choosing some of them to connect to. Making a connection takes some time, depending on factors such as the quality of the network connection and the physical distance. Ouroboros is a real-time system, so it is good to [hide some latency](https://link.springer.com/referenceworkentry/10.1007%2F978-0-387-09766-4_415) here. It wouldn't be good if the system was under pressure and yet still needed to connect to new peers; it's much better if the system maintains a handful of spare connections that are ready to take on any new task. A node should be able to make an educated decision about which existing connections to promote to get the best performance. For this reason we decided to have three type of peer:

Một yêu cầu khác đến từ thống đốc ngang hàng.
Phần này của hệ thống chịu trách nhiệm tìm kiếm các đồng nghiệp và chọn một số trong số chúng để kết nối.
Tạo kết nối mất một thời gian, tùy thuộc vào các yếu tố như chất lượng của kết nối mạng và khoảng cách vật lý.
Ouroboros là một hệ thống thời gian thực, vì vậy thật tốt khi [ẩn một số độ trễ] (https://link.springer.com/referenceworkentry/10.1007%2f978-0-387-09766-4_415) tại đây.
Sẽ không tốt nếu hệ thống chịu áp lực và vẫn cần kết nối với các đồng nghiệp mới;
Sẽ tốt hơn nhiều nếu hệ thống duy trì một số ít các kết nối dự phòng sẵn sàng nhận bất kỳ nhiệm vụ mới nào.
Một nút sẽ có thể đưa ra quyết định có giáo dục về các kết nối hiện có để thúc đẩy hiệu suất tốt nhất.
Vì lý do này, chúng tôi quyết định có ba loại ngang hàng:

- *cold peers* know about their existence, but there is no established network connection.

- * Các đồng nghiệp lạnh * Biết về sự tồn tại của họ, nhưng không có kết nối mạng được thiết lập.

- *warm peers* have a connection, but it is only used for network measurements and none of the node-to-node mini-protocols is used;

- * Các đồng nghiệp ấm * có kết nối, nhưng nó chỉ được sử dụng cho các phép đo mạng và không có giao thức nhỏ nào trong nút đến nút được sử dụng;

- *hot peers* have a connection, which is being used by all three node-to-node mini-protocols.

- * Các đồng nghiệp nóng * có một kết nối, đang được sử dụng bởi cả ba giao thức mini từ nút đến nút.

A node can potentially know about thousands of cold peers, maintain up to hundreds of warm peers, and have tens of hot peers (20 seems a reasonable figure at the moment). There are interesting and challenging questions around the design of policies that will drive decisions for the peer-to-peer governor. Choice of such policies will affect network topology and alter the performance characteristics of the network, including performance under load or malicious action. This will shape the timely distribution of block diffusion (parameterized by block sizes), or transactions. Since running such a system has many unknowns, we'd like to phase it into two parts. For the first phase, which will be released in a few weeks (probably shortly after Praos, also known as the Shelley release), we want to be ready with all the peer-to-peer components but still running in a federated mode. In addition, we will deliver the connection manager together with implementing a server accepting connections, and its integration with the peer-to-peer governor. In this phase, the peer-to-peer governor will be used as a subscription mechanism. Running various private and public testnets, together with our extensive testing should give us enough confidence before releasing this to mainnet. 

Một nút có khả năng có thể biết về hàng ngàn đồng nghiệp lạnh, duy trì tới hàng trăm đồng nghiệp ấm áp và có hàng chục đồng nghiệp nóng (20 có vẻ là một con số hợp lý tại thời điểm này). Có những câu hỏi thú vị và đầy thách thức xung quanh việc thiết kế các chính sách sẽ thúc đẩy các quyết định cho Thống đốc ngang hàng. Lựa chọn các chính sách như vậy sẽ ảnh hưởng đến cấu trúc liên kết mạng và thay đổi các đặc điểm hiệu suất của mạng, bao gồm hiệu suất dưới tải hoặc hành động độc hại. Điều này sẽ định hình phân phối kịp thời của khuếch tán khối (tham số hóa bởi các kích thước khối) hoặc giao dịch. Vì chạy một hệ thống như vậy có nhiều ẩn số, chúng tôi muốn đưa nó thành hai phần. Đối với giai đoạn đầu tiên, sẽ được phát hành trong một vài tuần (có thể ngay sau khi Praos, còn được gọi là phát hành Shelley), chúng tôi muốn sẵn sàng với tất cả các thành phần ngang hàng nhưng vẫn chạy trong chế độ liên kết. Ngoài ra, chúng tôi sẽ cung cấp Trình quản lý kết nối cùng với việc triển khai các kết nối chấp nhận máy chủ và tích hợp của nó với Thống đốc ngang hàng. Trong giai đoạn này, thống đốc ngang hàng sẽ được sử dụng làm cơ chế đăng ký. Chạy các bài kiểm tra tư nhân và công cộng khác nhau, cùng với thử nghiệm rộng rãi của chúng tôi sẽ cho chúng tôi đủ sự tự tin trước khi phát hành điều này cho Mainnet.

In the second phase, we will extend the mini-protocols with a gossip protocol. This will allow exchange of information about peers, finalize network quality measures, and plug them into the block-fetch logic (which decides from whom to download a block) as well as the peer-to-peer governor. At this stage, we would like to design and run some experiments to discover how peer-to-peer policies shape the network, and check how they recover from any topologies that are suboptimal (or adversarial).

Trong giai đoạn thứ hai, chúng tôi sẽ mở rộng các giao thức nhỏ với một giao thức tin đồn.
Điều này sẽ cho phép trao đổi thông tin về các đồng nghiệp, hoàn thiện các biện pháp chất lượng mạng và cắm chúng vào logic tìm kiếm khối (quyết định tải xuống ai) cũng như thống đốc ngang hàng.
Ở giai đoạn này, chúng tôi muốn thiết kế và chạy một số thí nghiệm để khám phá cách các chính sách ngang hàng định hình mạng và kiểm tra cách chúng phục hồi từ bất kỳ cấu trúc liên kết nào dưới mức tối ưu (hoặc đối nghịch).

I hope this gives you a good sense of where we are with the design and implementation of decentralization for Cardano, and our roadmap towards the Shelley era. You can follow further progress in our [weekly reports](https://roadmap.cardano.org/en/status-updates/).

Tôi hy vọng điều này mang lại cho bạn cảm giác tốt về nơi chúng ta đang ở với việc thiết kế và thực hiện phân cấp cho Cardano, và lộ trình của chúng ta đối với kỷ nguyên Shelley.
Bạn có thể theo dõi tiến trình tiếp theo trong [báo cáo hàng tuần của chúng tôi] (https://roadmap.cardano.org/en/status-updates/).

*This is the third of the Developer Deep Dive technical posts from our software engineering teams.*

*Đây là phần ba trong số các bài đăng kỹ thuật lặn sâu của nhà phát triển từ các nhóm kỹ thuật phần mềm của chúng tôi.*

