# Documenting Cardano: a single source of developer truth, fit for the future
![](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.002.png) 1 July 2020![](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.003.png) 3 mins read

![Tim Harrison](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.008.png)[](https://github.com/timbharrison "GitHub")

![Documenting Cardano: a single source of developer truth, fit for the future](img/2020-07-01-documenting-cardano-a-single-source-of-developer-truth-fit-for-the-future.009.png)

With yesterdayâ€™s release of the first [Shelley-complete node](https://forum.cardano.org/t/shelley-rollout-an-important-day/35147) on the Cardano mainnet, a new era has begun. Between this, the launch today of a brand new [Cardano website](https://www.cardano.org/) and brand identity, and tomorrowâ€™s [Cardano Virtual Summit](https://cardanosummit.iohk.io/), the dawn of Shelley is casting fresh light on IOHK's future. It has also highlighted the need for a documentation framework fit for our rapidly growing ecosystem.

Với bản phát hành ngày hôm qua của [nút Shelley-complete] (https://forum.cardano.org/t/shelley-rollout-anportant-day/35147) trên Cardano Mainnet, một kỷ nguyên mới đã bắt đầu
.
Giữa điều này, sự ra mắt ngày hôm nay của một [trang web Cardano] hoàn toàn mới (https://www.cardano.org/) và nhận dạng thương hiệu, và ngày mai [Cardano Virtual Summit] (https://cardanosummit.iohk.io
/), Bình minh của Shelley đang tạo ra ánh sáng mới về tương lai của Iohk.
Nó cũng đã nhấn mạnh sự cần thiết của một khung tài liệu phù hợp với hệ sinh thái đang phát triển nhanh chóng của chúng tôi.

We have written and gathered a substantial amount of technical material on Cardano over the years. Inevitably, this has developed organically and has been of variable quality and utility. Not all of it remains accurate or useful. The deployment of Shelley, the growth in developer interest, and the evolution of Cardano has moved us from project into product. So this has created the need to take a fresh look at how we explain Cardano.

Chúng tôi đã viết và thu thập một lượng lớn tài liệu kỹ thuật trên Cardano trong những năm qua.
Không thể tránh khỏi, điều này đã phát triển một cách hữu cơ và có chất lượng và tiện ích khác nhau.
Không phải tất cả vẫn chính xác hoặc hữu ích.
Việc triển khai Shelley, sự tăng trưởng về sự quan tâm của nhà phát triển và sự phát triển của Cardano đã đưa chúng tôi từ dự án thành sản phẩm.
Vì vậy, điều này đã tạo ra sự cần thiết phải có một cái nhìn mới về cách chúng ta giải thích Cardano.

Users and consumers of Cardano need to have clear, concise, and relevant material that matches the quality of the code on which the blockchain is built. Documentation needs to be correct and useful, and well organised and focused. In addition, we have identified the need to map categories of information to each user group, or persona. We're building a best-in-class blockchain, and this necessitates high-quality supporting documentation. The old Cardano docs site was in serious need of re-organization and updating, and our technical writers have been busy doing just that. Welcome to the new [Cardano docs](https://docs.cardano.org/).

Người dùng và người tiêu dùng Cardano cần phải có tài liệu rõ ràng, súc tích và có liên quan phù hợp với chất lượng của mã mà blockchain được xây dựng.
Tài liệu cần phải đúng và hữu ích, và được tổ chức tốt và tập trung.
Ngoài ra, chúng tôi đã xác định sự cần thiết phải ánh xạ các danh mục thông tin cho từng nhóm người dùng hoặc persona.
Chúng tôi đang xây dựng một blockchain tốt nhất trong lớp và điều này đòi hỏi phải có tài liệu hỗ trợ chất lượng cao.
Trang web Old Cardano Docs đang rất cần tổ chức lại và cập nhật, và các nhà văn kỹ thuật của chúng tôi đã bận rộn làm điều đó.
Chào mừng bạn đến với [Cardano Docs] mới (https://docs.cardano.org/).

### **Documentation for the future**

### ** Tài liệu cho tương lai **

Cardano is a complex product with complex technological underpinnings. However, for the developer community and wider audience to embrace it, we need them to understand how it can provide rewarding experiences. They need to know what Cardano can do and how it can solve problems. To ensure that we have the right information for all users, we are reorganising the documentation suite and mapping what each audience needs. 

Cardano là một sản phẩm phức tạp với nền tảng công nghệ phức tạp.
Tuy nhiên, đối với cộng đồng nhà phát triển và khán giả rộng lớn hơn để nắm lấy nó, chúng tôi cần họ hiểu làm thế nào nó có thể cung cấp kinh nghiệm bổ ích.
Họ cần biết Cardano có thể làm gì và làm thế nào nó có thể giải quyết vấn đề.
Để đảm bảo rằng chúng tôi có thông tin phù hợp cho tất cả người dùng, chúng tôi đang tổ chức lại bộ tài liệu và lập bản đồ những gì mỗi đối tượng cần.

Over the past few months, IOHK has been engaged in a company-wide effort to revamp all the content about the Cardano project. Our technical writing team has been immersed in transforming our previous repository, working closely with our developer teams to create a single source of technical truth, A resource of effective, informative, and up-to-date information that provides value to a broad set of audiences: exchange partners, stake pools, experienced blockchain developers, as well as people who want to understand Cardano. That also caters for skilled crypto enthusiasts and those who simply want to learn about Cardano from a technical perspective. 

Trong vài tháng qua, IOHK đã tham gia vào một nỗ lực toàn công ty để cải tạo tất cả nội dung về dự án Cardano.
Nhóm viết kỹ thuật của chúng tôi đã được đắm mình trong việc chuyển đổi kho lưu trữ trước đây của chúng tôi, hợp tác chặt chẽ với các nhóm nhà phát triển của chúng tôi để tạo ra một nguồn sự thật kỹ thuật duy nhất, một nguồn thông tin hiệu quả, thông tin và cập nhật cung cấp giá trị cho một bộ rộng
Khán giả: Đối tác trao đổi, nhóm cổ phần, các nhà phát triển blockchain có kinh nghiệm, cũng như những người muốn hiểu Cardano.
Điều đó cũng phục vụ cho những người đam mê tiền điện tử lành nghề và những người chỉ muốn tìm hiểu về Cardano từ góc độ kỹ thuật.

So today, weâ€™re launching a new documentation site. Instead of a static repository, the site is now a living, breathing source of information on Cardano, plugged into the heart of our development methodology. Just like Cardano, this is an ever-evolving entity. Components are added regularly as we strive to improve on the content we are delivering. New functionality is implemented all the time. We also intend to publish a lot more documentation based on our plans and community feedback. We need to build this out based on what works for our users, whether they sit in the technology or commercial space. 

Vì vậy, hôm nay, chúng tôi sẽ ra mắt một trang web tài liệu mới.
Thay vì một kho lưu trữ tĩnh, trang web hiện là nguồn thông tin sống, thở trên Cardano, được cắm vào trung tâm của phương pháp phát triển của chúng tôi.
Cũng giống như Cardano, đây là một thực thể không ngừng phát triển.
Các thành phần được thêm vào thường xuyên khi chúng tôi cố gắng cải thiện nội dung chúng tôi đang cung cấp.
Chức năng mới được thực hiện mọi lúc.
Chúng tôi cũng dự định xuất bản nhiều tài liệu hơn dựa trên các kế hoạch và phản hồi của cộng đồng.
Chúng tôi cần xây dựng điều này dựa trên những gì hoạt động cho người dùng của chúng tôi, cho dù họ ngồi trong công nghệ hoặc không gian thương mại.

With the virtual summit and our continuing momentum bringing a host of new faces into the ecosystem, we now have a jumping-off point for a single source of developer truth that we can build on.

Với hội nghị thượng đỉnh ảo và động lực liên tục của chúng tôi mang đến một loạt các gương mặt mới vào hệ sinh thái, giờ đây chúng tôi có một điểm xuất phát cho một nguồn sự thật của nhà phát triển mà chúng tôi có thể xây dựng.

