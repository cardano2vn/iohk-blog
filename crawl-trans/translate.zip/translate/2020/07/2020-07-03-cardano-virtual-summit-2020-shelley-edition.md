# Cardano Virtual Summit 2020: Shelley Edition
### **Bringing the global community together under one virtual roof.**
![](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.002.png) 3 July 2020![](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.003.png) 5 mins read

![Tim Harrison](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.008.png)[](https://github.com/timbharrison "GitHub")

![Cardano Virtual Summit 2020: Shelley Edition](img/2020-07-03-cardano-virtual-summit-2020-shelley-edition.009.jpeg)

Day One of the Cardano Virtual Summit 2020: Shelley Edition started with a splash. IOHK CEO, Charles Hoskinson, took the stage to welcome almost 10k registered attendees from around the world to the digital conference space. Each participant was met with exhibition areas, lots of virtual hangout space, and most importantly, session programming across five digital stages, covering everything from governance and community, to science and enterprise. With so much content to enjoy, we canâ€™t hope to summarize it all here. So take a look for yourself. [Register now](https://cardanosummit.iohk.io/) to enjoy all of todayâ€™s sessions either live or on-demand right after the summit closes this evening. 

Ngày thứ nhất của Hội nghị thượng đỉnh ảo Cardano 2020: Phiên bản Shelley bắt đầu với một cú giật gân.
Giám đốc điều hành của IOHK, Charles Hoskinson, đã lên sân khấu để chào đón gần 10 nghìn người tham dự đã đăng ký từ khắp nơi trên thế giới đến không gian hội nghị kỹ thuật số.
Mỗi người tham gia được đáp ứng với các khu vực triển lãm, rất nhiều không gian hangout ảo và quan trọng nhất là lập trình phiên trên năm giai đoạn kỹ thuật số, bao gồm tất cả mọi thứ từ quản trị và cộng đồng, đến khoa học và doanh nghiệp.
Với rất nhiều nội dung để thưởng thức, chúng ta không thể hy vọng tóm tắt tất cả ở đây.
Vì vậy, hãy tự mình xem.
[Đăng ký ngay] (https://cardanosummit.iohk.io/) để thưởng thức tất cả các phiên hôm nay hoặc trực tiếp hoặc theo yêu cầu ngay sau khi hội nghị thượng đỉnh kết thúc tối nay.

To bring you up to speed, here are the key take-outs from Thursday.

Để đưa bạn lên tốc độ, đây là những tác phẩm quan trọng từ thứ năm.

### **Shelley is here**

### ** Shelley đang ở đây **

The summit comes right after a significant milestone in the Shelley rollout. The pace of delivery has been ramping up considerably over the last couple of months, leading to the June 30th deployment of the first Shelley-complete node. The stage is now set for the continued rollout, with a high degree of confidence in the dates we have laid out, with delegation and staking due on mainnet in August. However, the confirmation of Shelleyâ€™s successful deployment was just the first of many announcements at the summit.

Hội nghị thượng đỉnh đến ngay sau một cột mốc quan trọng trong buổi giới thiệu Shelley.
Tốc độ giao hàng đã tăng lên đáng kể trong vài tháng qua, dẫn đến việc triển khai ngày 30 tháng 6 của nút hoàn thành Shelley đầu tiên.
Giai đoạn này được thiết lập cho việc tiếp tục triển khai, với mức độ tự tin cao về ngày chúng tôi đã đặt ra, với phái đoàn và tổ chức đặt ra trên Mainnet vào tháng Tám.
Tuy nhiên, việc xác nhận triển khai thành công của Shelley chỉ là thông báo đầu tiên trong số nhiều thông báo tại hội nghị thượng đỉnh.

### **Goguen and Voltaire are coming**

### ** Goguen và Voltaire đang đến **

Within 120 days, weâ€™ll be rolling out the native asset standard for Cardano. Within 150 days, weâ€™ll see the roll-out of Plutus Foundations, the first point of entry for smart contracts on Cardano. Sustaining a decentralized project means more than simply allowing users to run the protocol and build on the platform. They must also decide what the platform does and where it goes. Project Catalyst and Voltaire seek to give that power to the community through decentralized democracy. A pool of funds and a voting protocol will allow the Cardano community to make their voices heard on proposed advancements to the blockchain. Ada holders will also be able to submit improvement proposals to help shape the direction of the ecosystem. Improvement proposals might include software updates, technical development options, funding decisions, and choices about the long-term plans of the ecosystem. Once delivered, the Cardano network will become a self-governed and user-run platform. 

Trong vòng 120 ngày, chúng tôi sẽ đưa ra tiêu chuẩn tài sản gốc cho Cardano.
Trong vòng 150 ngày, chúng ta sẽ thấy sự triển khai của Plutus Foundations, điểm đầu tiên của các hợp đồng thông minh trên Cardano.
Duy trì một dự án phi tập trung có nghĩa là nhiều hơn chỉ cho phép người dùng chạy giao thức và xây dựng trên nền tảng.
Họ cũng phải quyết định những gì nền tảng làm và nơi nó đi.
Project Catalyst và Voltaire tìm cách trao quyền lực đó cho cộng đồng thông qua dân chủ phi tập trung.
Một nhóm tiền và một giao thức bỏ phiếu sẽ cho phép cộng đồng Cardano làm cho tiếng nói của họ được nghe về những tiến bộ được đề xuất cho blockchain.
Chủ sở hữu ADA cũng sẽ có thể gửi các đề xuất cải tiến để giúp định hình hướng của hệ sinh thái.
Các đề xuất cải tiến có thể bao gồm cập nhật phần mềm, tùy chọn phát triển kỹ thuật, quyết định tài trợ và lựa chọn về các kế hoạch dài hạn của hệ sinh thái.
Sau khi được phân phối, mạng Cardano sẽ trở thành một nền tảng tự quản và chạy của người dùng.

### **Atala PRISM**

### ** Atala Prism **

Day One continued on a successful note with the announcement of [PRISM](https://atalaprism.io/), a decentralized identity solution that enables people to own their personal data and interact with organizations seamlessly, privately, and securely. It will encourage better practice in consumer data privacy and security by offering users â€˜self-sovereignâ€™ digital identities, without Big Tech intermediaries accessing, storing or sharing personal data.

Ngày thứ nhất tiếp tục ghi chú thành công với thông báo [Prism] (https://atalaprism.io/), một giải pháp nhận dạng phi tập trung cho phép mọi người sở hữu dữ liệu cá nhân của họ và tương tác với các tổ chức một cách liền mạch, riêng tư và an toàn.
Nó sẽ khuyến khích thực hành tốt hơn về quyền riêng tư và bảo mật dữ liệu của người tiêu dùng bằng cách cung cấp cho người dùng danh tính kỹ thuật số của người dùng, mà không có các trung gian công nghệ lớn truy cập, lưu trữ hoặc chia sẻ dữ liệu cá nhân.

PRISM also promises to open up access to a blockchain marketplace of financial and social services for millions of users who might not previously have had access to banking and financial services. This will enable low-income populations to store and share personal information like credentials, land deeds, and health records. Through PRISM, users can also access financial products like loans and insurance.

Prism cũng hứa hẹn sẽ mở ra quyền truy cập vào một thị trường blockchain của các dịch vụ tài chính và xã hội cho hàng triệu người dùng trước đây có thể không có quyền truy cập vào các dịch vụ tài chính và ngân hàng.
Điều này sẽ cho phép dân số thu nhập thấp lưu trữ và chia sẻ thông tin cá nhân như thông tin đăng nhập, hành động đất đai và hồ sơ sức khỏe.
Thông qua Prism, người dùng cũng có thể truy cập các sản phẩm tài chính như cho vay và bảo hiểm.

Atala PRISM is built for compatibility with other blockchains and legacy systems to make it accessible worldwide. A pilot currently underway in Georgia will give employers the ability to verify graduate qualifications instantly. But PRISM is only one part of a suite of enterprise-grade â€˜layer 2â€™ software solutions designed to bring advanced, highly flexible functionality to blockchains. Other elements of the evolving Atala suite of products include traceability for supply chains and the ability to monitor the movement of goods globally.

Atala Prism được xây dựng để tương thích với các blockchains và hệ thống kế thừa khác để làm cho nó có thể truy cập trên toàn thế giới.
Một phi công hiện đang được tiến hành ở Georgia sẽ cung cấp cho nhà tuyển dụng khả năng xác minh trình độ sau đại học ngay lập tức.
Nhưng Prism chỉ là một phần của một bộ giải pháp phần mềm cấp độ doanh nghiệp-Layer 2â € ™ được thiết kế để mang lại chức năng tiên tiến, linh hoạt cao cho blockchains.
Các yếu tố khác của bộ sản phẩm ATALA phát triển bao gồm truy xuất nguồn gốc cho chuỗi cung ứng và khả năng giám sát sự di chuyển của hàng hóa trên toàn cầu.

In an impressive [demo](https://atalaprism.io/credentials), the team showcased the platform and mobile app with a smart city walkthrough. The app will work with Android and iOS devices, while the platform also supports paper wallets and smart cards.

Trong một [demo] ấn tượng (https://atalaprism.io/credentials), nhóm đã giới thiệu nền tảng và ứng dụng di động với hướng dẫn thành phố thông minh.
Ứng dụng sẽ hoạt động với các thiết bị Android và iOS, trong khi nền tảng này cũng hỗ trợ ví giấy và thẻ thông minh.

### **cFund**

### ** Cfund **

Last but not least, we announced a landmark partnership with Wave Financial Group. The $10 million dollars pledged to the development of Cardanoâ€™s ecosystem represents the first venture capital to support IOHK. Together, the two companies will generate a $20 million dollar incubator fund to help startups who want to build on the blockchain. This provides several years of financial runway to target seed and early-stage opportunities. Wave Financial is looking to invest in global companies created on Cardano by giving funding of up to $500k. The move aligns both firmsâ€™ interests in driving Wave to become the industryâ€™s leading digital asset management group while ensuring IOHK becomes the vanguard technology provider in the space.

Cuối cùng nhưng không kém phần quan trọng, chúng tôi đã công bố một quan hệ đối tác mang tính bước ngoặt với Wave Financial Group.
Các đô la trị giá 10 triệu đô la đã cam kết phát triển hệ sinh thái của Cardano đại diện cho vốn đầu tư đầu tiên hỗ trợ IOHK.
Cùng nhau, hai công ty sẽ tạo ra một quỹ ươm tạo trị giá 20 triệu đô la để giúp các công ty khởi nghiệp muốn xây dựng trên blockchain.
Điều này cung cấp nhiều năm đường băng tài chính để nhắm mục tiêu hạt giống và cơ hội giai đoạn đầu.
Wave Financial đang tìm cách đầu tư vào các công ty toàn cầu được tạo ra trên Cardano bằng cách tài trợ lên tới 500 nghìn đô la.
Động thái này phù hợp với cả hai lợi ích của công ty trong việc thúc đẩy làn sóng trở thành nhóm quản lý tài sản kỹ thuật số hàng đầu của ngành trong khi đảm bảo IOHK trở thành nhà cung cấp công nghệ Vanguard trong không gian.

Weâ€™ll revisit all these stories over the weeks ahead to give you a deeper dive into our plans and what they mean. But, as excited as we are by these opportunities for future adoption and growth, Day One was also a day of reflection.

Chúng tôi sẽ xem xét lại tất cả những câu chuyện này trong những tuần tới để cung cấp cho bạn một cuộc đi sâu hơn vào kế hoạch của chúng tôi và ý nghĩa của chúng.
Nhưng, phấn khích như chúng ta bởi những cơ hội để áp dụng và tăng trưởng trong tương lai, ngày đầu tiên cũng là một ngày suy ngẫm.

Because we would not be where we are without the incredible support of the Cardano community, which helped to bring us here and joined from all around the world to celebrate Shelley. Connections were made between companies, platforms... and people. Day One was full of big announcements, and boosted by some fascinating speaker sessions with world-class scientists, technologists, and thought leaders sharing their vision of the future. It was also full of optimism, of ideas, buzzing with community contribution and opportunity. Thanks to everyone who helped make it such a special day. And see you back at the summit later today!

Bởi vì chúng tôi sẽ không ở nơi chúng tôi không có sự hỗ trợ đáng kinh ngạc của cộng đồng Cardano, điều này đã giúp đưa chúng tôi đến đây và tham gia từ khắp nơi trên thế giới để chúc mừng Shelley.
Kết nối được thực hiện giữa các công ty, nền tảng ... và con người.
Ngày đầu tiên có đầy đủ các thông báo lớn, và được thúc đẩy bởi một số phiên diễn giả hấp dẫn với các nhà khoa học, nhà công nghệ đẳng cấp thế giới và các nhà lãnh đạo tư tưởng chia sẻ tầm nhìn của họ về tương lai.
Nó cũng đầy sự lạc quan, về ý tưởng, ù ù với sự đóng góp và cơ hội của cộng đồng.
Cảm ơn tất cả những người đã giúp làm cho nó một ngày đặc biệt như vậy.
Và hẹn gặp lại bạn tại hội nghị thượng đỉnh sau ngày hôm nay!

