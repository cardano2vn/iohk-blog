# Improving Haskell’s big numbers support
### **Work by IOHK engineers is part of the latest release of the Glasgow compiler**
![](img/2020-07-28-improving-haskells-big-numbers-support.002.png) 28 July 2020![](img/2020-07-28-improving-haskells-big-numbers-support.002.png)[ Sylvain Henry](tmp//en/blog/authors/sylvain-henry/page-1/)![](img/2020-07-28-improving-haskells-big-numbers-support.003.png) 9 mins read

![Sylvain Henry](img/2020-07-28-improving-haskells-big-numbers-support.004.png)[](tmp//en/blog/authors/sylvain-henry/page-1/)
### [**Sylvain Henry**](tmp//en/blog/authors/sylvain-henry/page-1/)
Software Engineer

Engineering

- ![](img/2020-07-28-improving-haskells-big-numbers-support.005.png)[](mailto:sylvain.henry@iohk.io "Email")
- ![](img/2020-07-28-improving-haskells-big-numbers-support.006.png)[](https://www.linkedin.com/in/sylvain-henry-39323297/ "LinkedIn")
- ![](img/2020-07-28-improving-haskells-big-numbers-support.007.png)[](https://twitter.com/shenry_io "Twitter")
- ![](img/2020-07-28-improving-haskells-big-numbers-support.008.png)[](https://github.com/hsyl20 "GitHub")

![Improving Haskell’s big numbers support](img/2020-07-28-improving-haskells-big-numbers-support.009.jpeg)

Haskell is vital to IOHK’s work in ensuring Cardano is a secure blockchain for the future of decentralized finance. As part of this, we use the language to develop the [Plutus smart contract platform](https://prod.playground.plutus.iohkdev.io/tutorial/), and you may have read about the training courses run by our engineers, including a [Haskell course in Mongolia](https://www.montsame.mn/en/read/231778) this month. Smart contract applications are a powerful way for a distributed network to generate value, allowing individuals and businesses to agree to conditions and automatically execute exchanges of information and wealth, without relying on third parties. Plutus contracts contain a substantial amount of code that is run off the chain, on users’ computers. To make it easy to create portable executables for these, we want to compile the off-chain Haskell code into JavaScript or WebAssembly. To reach that goal, we take part in the development of the Glasgow Haskell Compiler ([GHC](https://www.haskell.org/ghc/)), [GHCJS](https://github.com/ghcjs/ghcjs) (Haskell to JavaScript compiler) and [Asterius](https://github.com/tweag/asterius/) (Haskell to WebAssembly compiler).

Haskell rất quan trọng đối với công việc của IOHK, trong việc đảm bảo Cardano là một blockchain an toàn cho tương lai của tài chính phi tập trung. Là một phần của điều này, chúng tôi sử dụng ngôn ngữ để phát triển [nền tảng hợp đồng thông minh Plutus] (https://prod.playground.plutus.iohkdev.io/tutorial/), và bạn có thể đã đọc về các khóa đào tạo do các kỹ sư của chúng tôi điều hành , bao gồm một khóa học [Haskell ở Mông Cổ] (https://www.montsame.mn/en/read/231778) trong tháng này. Các ứng dụng hợp đồng thông minh là một cách mạnh mẽ để mạng phân tán tạo ra giá trị, cho phép các cá nhân và doanh nghiệp đồng ý với các điều kiện và tự động thực hiện trao đổi thông tin và sự giàu có mà không cần dựa vào bên thứ ba. Hợp đồng Plutus chứa một lượng mã đáng kể chạy khỏi chuỗi, trên máy tính của người dùng. Để giúp dễ dàng tạo các tệp thực thi di động cho những điều này, chúng tôi muốn biên dịch mã Haskell ngoài chuỗi thành JavaScript hoặc WebAssugging. Để đạt được mục tiêu đó, chúng tôi tham gia vào sự phát triển của trình biên dịch Glasgow Haskell ([GHC] (https://www.haskell.org/ghc/)), [GHCJS] (https://github.com/ghcjs/ GHCJS) (Haskell to JavaScript Trình biên dịch) và [Asterius] (https://github.com/tweag/asterius/) (Haskell cho trình biên dịch WebAssugging).

Recently we have been working on improving GHC’s support for big numbers, ie, numbers larger than 64-bit (both Integer and Natural types in Haskell). We have developed an implementation of big number operations in Haskell that is faster than the previous one (integer-simple). We have also improved the way GHC deals with the different implementations to make it more robust and evolutive. These contributions are part of the [latest GHC release, version 9.0](https://gitlab.haskell.org/ghc/ghc/-/wikis/status/ghc-9.0.1).

Gần đây, chúng tôi đã làm việc để cải thiện hỗ trợ GHC, cho số lượng lớn, tức là các số lớn hơn 64 bit (cả số nguyên và loại tự nhiên trong Haskell).
Chúng tôi đã phát triển việc triển khai các hoạt động số lượng lớn trong Haskell nhanh hơn so với lần trước (số nguyên đơn giản).
Chúng tôi cũng đã cải thiện cách GHC xử lý các triển khai khác nhau để làm cho nó mạnh mẽ và phát triển hơn.
Những đóng góp này là một phần của bản phát hành GHC mới nhất, phiên bản 9.0] (https://gitlab.haskell.org/ghc/ghc/-/wikis/status/ghc-9.0.1).

## **Background**

Gần đây, chúng tôi đã làm việc để cải thiện hỗ trợ GHC, cho số lượng lớn, tức là các số lớn hơn 64 bit (cả số nguyên và loại tự nhiên trong Haskell).
Chúng tôi đã phát triển việc triển khai các hoạt động số lượng lớn trong Haskell nhanh hơn so với lần trước (số nguyên đơn giản).
Chúng tôi cũng đã cải thiện cách GHC xử lý các triển khai khác nhau để làm cho nó mạnh mẽ và phát triển hơn.
Những đóng góp này là một phần của bản phát hành GHC mới nhất, phiên bản 9.0] (https://gitlab.haskell.org/ghc/ghc/-/wikis/status/ghc-9.0.1).

Every Haskell compiler has to support arbitrary-precision integers (see [Haskell 98](https://www.haskell.org/onlinereport/basic.html#sect6.4) and [Haskell 2010](https://www.haskell.org/onlinereport/haskell2010/haskellch6.html#x13-1350006.4) reports, section 6.4). GHC is no exception and as such it provides the ubiquitous Integer and Natural types (‘big numbers’ for the rest of this post).

Mỗi trình biên dịch Haskell phải hỗ trợ các số nguyên chính xác tùy ý (xem [Haskell 98] (https://www.haskell.org/onlinereport/basic.html#sect6.4) và [Haskell 2010] (https: //www.haskell
.org/onlinereport/haskell2010/haskellch6.html#x13-1350006.4) Báo cáo, Phần 6.4).
GHC cũng không ngoại lệ và như vậy, nó cung cấp số nguyên và loại tự nhiên phổ biến (’số lớn cho phần còn lại của bài viết này).

Until now, GHC could use one of two packages for this support:

Cho đến bây giờ, GHC có thể sử dụng một trong hai gói cho hỗ trợ này:

- integer-gmp: use [GNU MP library (GMP)](https://gmplib.org) (via FFI), LGPL. Good performance.

- Integer-GMP: Sử dụng [Thư viện GNU MP (GMP)] (https://gmplib.org) (thông qua FFI), LGPL.
Hiệu suất tốt.

- integer-simple: Haskell implementation, BSD3. Bad performance.

- Số nguyên-đơn giản: Thực hiện Haskell, BSD3.
Phần trình bày tệ.

Choosing one or the other depended on license, performance and cross-compilation considerations. In some cases, GMP’s LGPL license can be problematic, [especially if you use static linking](http://www.gnu.org/licenses/gpl-faq.html#LGPLStaticVsDynamic), which is required on some platforms, including [Windows](https://gitlab.haskell.org/ghc/ghc/wikis/windows-dynamic-linking). When it comes to performance: integer-simple is sometimes several orders of magnitude slower than integer-gmp, as discussed below. And with cross-compilation, some target platforms may not support GMP, such as JavaScript.

Chọn một hoặc cái khác phụ thuộc vào giấy phép, hiệu suất và cân nhắc biên dịch chéo.
Trong một số trường hợp, giấy phép LGPL của GMP có thể có vấn đề, [đặc biệt là nếu bạn sử dụng liên kết tĩnh] (http://www.gnu.org/licenses/gpl-faq.html#lgplstaticvsdynamic), được yêu cầu trên một số nền tảng, bao gồm [bao gồm [
Windows] (https://gitlab.haskell.org/ghc/ghc/wikis/windows-dynamic-linking).
Khi nói đến hiệu suất: Số nguyên đơn giản đôi khi chậm hơn một số bậc độ lớn hơn số nguyên-GMP, như được thảo luận dưới đây.
Và với sự biên dịch chéo, một số nền tảng mục tiêu có thể không hỗ trợ GMP, chẳng hạn như JavaScript.

The situation was already unfortunate but there were additional issues:

Tình huống đã không may nhưng đã có thêm vấn đề:

1. Each implementation had its own way of representing big numbers (array of unboxed words or list of boxed words). GHC was aware of the selected implementation and produced different code for each. It could lead to bugs – even ‘[insanity](https://gitlab.haskell.org/ghc/ghc/issues/15262)’! – when big numbers were exchanged between processes compiled with different implementations. Moreover, it made the compiler code more complicated because it had to deal with this discrepancy (eg, when inspecting heap objects at runtime in GHCi).

1
GHC đã nhận thức được việc triển khai được chọn và tạo mã khác nhau cho mỗi.
Nó có thể dẫn đến lỗi - thậm chí ‘[Insanity] (https://gitlab.haskell.org/ghc/ghc/issues/15262)
- Khi số lượng lớn được trao đổi giữa các quy trình được tổng hợp với các triển khai khác nhau.
Hơn nữa, nó làm cho mã trình biên dịch trở nên phức tạp hơn vì nó phải đối phó với sự khác biệt này (ví dụ, khi kiểm tra các đối tượng HEAP khi chạy trong GHCI).

1. Similarly, because of the different internal representations, there are at least [71 packages on Hackage](https://packdeps.haskellers.com/reverse/integer-gmp) (among them some widely used ones such as bytestring and text) that explicitly depend on integer-gmp package or that provide a flag to depend either on integer-gmp or integer-simple. It is a maintenance burden because each code path could have specific bugs and should be tested on CI.

1. Tương tự, do các biểu diễn nội bộ khác nhau, có ít nhất [71 gói trên hackage] (https://packdeps.haskeller.com/reverse/integer-gmp) (trong số đó
) Điều đó phụ thuộc rõ ràng vào gói Integer-GMP hoặc cung cấp cờ phụ thuộc vào số nguyên-GMP hoặc số nguyên đơn giản.
Đó là một gánh nặng bảo trì vì mỗi đường dẫn mã có thể có các lỗi cụ thể và nên được kiểm tra trên CI.

All this meant that every new big number implementation was a daunting task. First, the interface to implement was very large (Integer and Natural types and all their operations). Then, we needed to ensure that GHC’s rewrite rules (constant folding) still worked for the implementation, the packages mentioned above needed to be fixed, and new Cabal flags added (by the way, Cabal flags are Boolean so they can’t be easily extended to support more than two options). Finally, GHC’s build system needed to be modified. No wonder it never happened.

Tất cả điều này có nghĩa là mọi triển khai số lớn mới là một nhiệm vụ khó khăn.
Đầu tiên, giao diện để thực hiện là rất lớn (các loại số nguyên và tự nhiên và tất cả các hoạt động của chúng).
Sau đó, chúng tôi cần đảm bảo rằng các quy tắc viết lại của GHC (gấp liên tục) vẫn hoạt động để thực hiện, các gói được đề cập ở trên cần phải được sửa chữa và các lá cờ mới được thêm
mở rộng để hỗ trợ nhiều hơn hai tùy chọn).
Cuối cùng, hệ thống xây dựng GHC, cần phải sửa đổi.
Không có gì ngạc nhiên khi nó không bao giờ xảy ra.

Fortunately, most of these issues are now fixed in the latest release, GHC 9.0.

May mắn thay, hầu hết các vấn đề này hiện đã được khắc phục trong bản phát hành mới nhất, GHC 9.0.

## **The ghc-bignum package**

## ** Gói Ghc-Bignum **

Starting from GHC 9.0, big numbers support is provided by a single package: ghc-bignum. This provides a Haskell implementation of big numbers (native-backend) that is faster than integer-simple’s (performance figures are given below), is also BSD3-licensed, and uses the same representation of big numbers as integer-gmp.

Bắt đầu từ GHC 9.0, hỗ trợ số lớn được cung cấp bởi một gói duy nhất: GHC-Bignum.
Điều này cung cấp một triển khai Haskell của các số lớn (hậu vệ tự nhiên) nhanh hơn số nguyên-đơn giản (số liệu hiệu suất được đưa ra dưới đây), cũng được cấp phép BSD3 và sử dụng cùng một biểu diễn của số lượng lớn như số nguyên-GMP.

Now the different big numbers implementations are considered as internal backends of ghc-bignum library and there should be no observable difference between backends, except for performance. To enforce this, we even have a meta-backend used during tests that performs every operation with two backends (native-backend and another selected one) and checks that their results are the same.

Bây giờ các triển khai số lớn khác nhau được coi là phụ trợ nội bộ của thư viện GHC-Bignum và không có sự khác biệt có thể quan sát được giữa các phụ trợ, ngoại trừ hiệu suất.
Để thực thi điều này, chúng tôi thậm chí còn có một meta-backend được sử dụng trong các thử nghiệm thực hiện mọi hoạt động với hai phụ trợ (backend gốc và một phương pháp khác được chọn) và kiểm tra xem kết quả của chúng có giống nhau không.

A pure Haskell implementation can't really expect to beat the performance of heavily optimized libraries such as GMP, hence integer-gmp has been integrated into ghc-bignum as a backend (gmp-backend).

Việc triển khai Haskell thuần túy thực sự không thể mong đợi đánh bại hiệu suất của các thư viện được tối ưu hóa mạnh mẽ như GMP, do đó Integer-GMP đã được tích hợp vào GHC-Bignum như một phụ trợ (GMP-Backend).

Adding a big numbers backend is now much easier. The interface to implement is minimal and is documented. A new backend doesn’t have to provide the whole implementation up front: operations provided by native-backend can be used to fill the holes while another backend is being developed. The test framework doesn’t have to be rewritten for each backend and results can be checked automatically against native-backend with the meta-backend mentioned above. We hope backends using other libraries, such as [OpenSSL libcrypto integers](https://github.com/ghc-proposals/ghc-proposals/pull/183) or [BSDNT](https://github.com/wbhart/bsdnt), will be developed in the near future.

Thêm một phụ trợ số lớn bây giờ dễ dàng hơn nhiều.
Giao diện để thực hiện là tối thiểu và được ghi lại.
Một phụ trợ mới không phải cung cấp toàn bộ việc triển khai trước: các hoạt động do hậu vệ tự nhiên cung cấp có thể được sử dụng để lấp đầy các lỗ hổng trong khi một phụ trợ khác đang được phát triển.
Khung kiểm tra không phải được viết lại cho mỗi phụ trợ và kết quả có thể được kiểm tra tự động đối với hậu vệ tự nhiên với các mặt trái meta được đề cập ở trên.
Chúng tôi hy vọng các phụ trợ sử dụng các thư viện khác, chẳng hạn như [số nguyên openSSL libcrypto] (https://github.com/ghc-proposals/ghc-proposals/pull/183) hoặc [bsdnt] (https://github.com/wbhart/
BSDNT), sẽ được phát triển trong tương lai gần.

The ghc-bignum package also has a third ffi-backend that doesn’t provide an implementation per se but performs FFI calls for each operation. So ghc-bignum must be linked with an object providing the implementation or the compiler should replace these calls with platform-specific operations (eg, JavaScript/CLR/JVM big numbers operations) when this backend is selected. It is similar to what the Asterius compiler was doing – replacing GMP FFI calls with JavaScript BigInt calls – but in a cleaner way because GMP isn’t involved any more.

Gói GHC-Bignum cũng có FFI-Backend thứ ba không cung cấp triển khai mỗi lần nhưng thực hiện các cuộc gọi FFI cho mỗi thao tác.
Vì vậy, GHC-Bignum phải được liên kết với một đối tượng cung cấp việc triển khai hoặc trình biên dịch nên thay thế các cuộc gọi này bằng các hoạt động dành riêng cho nền tảng (ví dụ: các hoạt động số lớn của JavaScript/CLR/JVM) khi phụ trợ này được chọn.
Nó tương tự như những gì trình biên dịch Asterius đang làm - thay thế các cuộc gọi GMP FFI bằng các cuộc gọi lớn của JavaScript - nhưng theo cách sạch hơn vì GMP không còn liên quan nữa.

A major advantage of ghc-bignum is that all the backends use the same representation for big numbers: an array of words stored in little-endian order. This representation is also used by most big numbers libraries. Formerly, integer-simple was a notorious exception because it used a Haskell list to store the words, partly explaining its poor performance. Now, any package wanting to access the representation of the big numbers just has to depend on ghc-bignum. Cabal flags and CPP code are no longer required to deal with the different implementations. However, conditional code may be needed during the transition from integer-\* packages to ghc-bignum. 

Một lợi thế lớn của GHC-Bignum là tất cả các phụ trợ đều sử dụng cùng một đại diện cho số lượng lớn: một loạt các từ được lưu trữ theo thứ tự nhỏ.
Đại diện này cũng được sử dụng bởi hầu hết các thư viện số lớn.
Trước đây, số nguyên đơn giản là một ngoại lệ khét tiếng vì nó đã sử dụng danh sách Haskell để lưu trữ các từ, một phần giải thích hiệu suất kém của nó.
Bây giờ, bất kỳ gói nào muốn truy cập vào đại diện của các số lớn chỉ phải phụ thuộc vào GHC-Bignum.
Cờ Cabal và mã CPP không còn cần thiết để đối phó với các triển khai khác nhau.
Tuy nhiên, mã có điều kiện có thể cần thiết trong quá trình chuyển từ các gói số nguyên-\* sang GHC-Bignum.

To make the transition easier, the integer-gmp-1.1 package is still provided but it has been rewritten to depend on ghc-bignum and to provide some backward-compatible functions and pattern synonyms. Note, however, that some functions that were only available in integer-gmp-1.0.\* (eg, prime number test, extended GCD) have been removed in integer-gmp-1.1. We expect these very specific functions to be exported by packages such as [hgmp](https://hackage.haskell.org/package/hgmp) instead. Alternatively, someone could implement Haskell versions of these functions into native-backend.

Để làm cho quá trình chuyển đổi dễ dàng hơn, gói Integer-GMP-1.1 vẫn được cung cấp nhưng nó đã được viết lại để phụ thuộc vào GHC-Bignum và cung cấp một số chức năng tương thích ngược và từ đồng nghĩa mẫu.
Tuy nhiên, lưu ý rằng một số hàm chỉ có sẵn trong Integer-GMP-1.0. \* (Ví dụ, kiểm tra số nguyên tố, GCD mở rộng) đã bị xóa trong Integer-GMP-1.1.
Chúng tôi hy vọng các chức năng rất cụ thể này sẽ được xuất khẩu bởi các gói như [HGMP] (https://hackage.haskell.org/package/hgmp) thay thế.
Ngoài ra, ai đó có thể thực hiện các phiên bản Haskell của các chức năng này thành bản gốc.

GHC code has been simplified and made faster. Big numbers types and constructors are now known to the compiler (‘wired-in’), in the same way as other literals, so GHC doesn’t have to read interface files each time it wants to generate code using them. The unified representation avoids any need for two code paths, which makes the code more robust and easier to test. 

Mã GHC đã được đơn giản hóa và làm cho nhanh hơn.
Các loại số và nhà xây dựng số lớn hiện được trình biên dịch (có dây-in), giống như các nghĩa đen khác, vì vậy GHC không phải đọc các tệp giao diện mỗi khi nó muốn tạo mã bằng cách sử dụng chúng.
Đại diện thống nhất tránh mọi nhu cầu về hai đường dẫn mã, giúp mã mạnh hơn và dễ kiểm tra hơn.

## **Performance**

## **Màn biểu diễn**

We have compared the performance of native-backend against latest integer-simple and integer-gmp implementations (Figure 1). We measured the time necessary to compute basic operations:

Chúng tôi đã so sánh hiệu suất của hậu vệ tự nhiên với các triển khai số nguyên và số nguyên mới nhất (Hình 1).
Chúng tôi đã đo thời gian cần thiết để tính toán các hoạt động cơ bản:

Platform was Linux 5.5.4 on Intel Core i7-9700K CPU running at 3.60GHz. The three GHC bindists have been built with Hadrian using ‘perf’ flavor. integer-gmp and integer-simple bindists are built from commit 84dd96105. native-backend bindist is built from ghc-bignum branch rebased on commit 9d094111.

Nền tảng là Linux 5.5.4 trên CPU Intel Core i7-9700K chạy ở mức 3,60GHz.
Ba người ràng buộc GHC đã được xây dựng với Hadrian bằng hương vị ‘Perf Perf.
Integer-GMP và các ràng buộc đơn giản số nguyên được xây dựng từ cam kết 84DD96105.
Bindist Backend bản địa được xây dựng từ chi nhánh GHC-Bignum được sửa đổi trên cam kết 9D094111.

Computations have been performed with positive integers of the following sizes: small – 1 word (64-bit); medium – 8 words (512-bit); big – 76 words (4,848-bit).

Các tính toán đã được thực hiện với các số nguyên dương với các kích thước sau: Nhỏ-1 từ (64 bit);
trung bình-8 từ (512 bit);
Lớn-76 từ (4.848 bit).

![Figure 1. Native-backend and integer-gmp are faster than integer-simple in almost all cases](img/2020-07-28-improving-haskells-big-numbers-support.010.png "Figure 1. Native-backend and integer-gmp are faster than integer-simple in almost all cases")

Figure 1. Native-backend and integer-gmp are faster than integer-simple in almost all cases (note the logarithmic scale)

Hình 1. Ngược lại và số nguyên-GMP nhanh hơn số nguyên đơn giản trong hầu hết các trường hợp (lưu ý thang đo logarit)

Figure 1 shows that native-backend and integer-gmp are always faster than integer-simple. The only exceptions are when we add or subtract a small number (1 word) from a big one as these operations are particularly well suited for integer-simple’s bignum representation (a list) because the tail of the list remains unchanged and is shared between the big numbers before and after the operation. With the other representation, the tail has to be duplicated in memory.

Hình 1 cho thấy dự phòng gốc và số nguyên-GMP luôn nhanh hơn số nguyên đơn giản.
Các ngoại lệ duy nhất là khi chúng ta thêm hoặc trừ một số nhỏ (1 từ) từ một số lớn vì các hoạt động này đặc biệt phù hợp với biểu diễn Bignum của Integer-Simple (một danh sách) vì đuôi của danh sách vẫn không thay đổi và được chia sẻ giữa
Số lượng lớn trước và sau khi hoạt động.
Với các đại diện khác, đuôi phải được nhân đôi trong bộ nhớ.

Division with integer-simple performs so badly that native-backend is 40 times faster in all the tested cases.

Sự phân chia với số nguyên đơn giản thực hiện rất tệ đến nỗi hậu vệ tự nhiên nhanh hơn 40 lần trong tất cả các trường hợp được thử nghiệm.

Sometimes, native-backend is faster than integer-gmp (eg, addition/subtraction with a small/medium number). GMP library is probably at least as good as native-backend but the latter avoids FFI calls, which may explain the better performance. Otherwise, native-backend is still slower than integer-gmp but these results are expected because it only implements basic algorithms and it doesn’t use vectorised or optimised processor instructions.

Đôi khi, hậu vệ tự nhiên nhanh hơn số nguyên-GMP (ví dụ: bổ sung/trừ với số nhỏ/trung bình).
Thư viện GMP có lẽ ít nhất là tốt như mặt sau bản địa nhưng sau đó tránh các cuộc gọi FFI, điều này có thể giải thích hiệu suất tốt hơn.
Mặt khác, hậu vệ tự nhiên vẫn chậm hơn số nguyên-GMP nhưng những kết quả này được dự kiến vì nó chỉ thực hiện các thuật toán cơ bản và nó không sử dụng các hướng dẫn bộ xử lý được tối ưu hóa hoặc tối ưu hóa.

When it comes to GHC performance tests, we took our baseline as GHC HEAD compiled with integer-gmp. We compare the results with ghc-bignum's gmp-backend. There are no regressions. Noticeable improvements in memory use are seen in Table 1.

Khi nói đến các bài kiểm tra hiệu suất GHC, chúng tôi đã đưa ra đường cơ sở của chúng tôi làm đầu GHC được biên soạn với số nguyên-GMP.
Chúng tôi so sánh kết quả với GMP-backend của GHC-Bignum.
Không có hồi quy.
Những cải tiến đáng chú ý trong việc sử dụng bộ nhớ được nhìn thấy trong Bảng 1.

![](img/2020-07-28-improving-haskells-big-numbers-support.011.png)

Next, we compared metrics obtained with native-backend to those obtained with GHC HEAD built with integer-simple. The new Haskell implementation results in noticeable changes (Table 2). Note that the first four tests were disabled with integer-simple because they took too long or failed to complete (heap overflow) but they all passed with native-backend. Also, T10678, the final test in the table, performs a lot of additions of a small number to a big number. As we saw above, this is the only case for which integer-simple representation is better: in most iterations only the head of the list is modified without duplicating the tail. It is reflected again in this result.

Tiếp theo, chúng tôi đã so sánh các số liệu thu được với mặt trái tự nhiên với các số lượng thu được với đầu GHC được xây dựng với số nguyên đơn giản.
Việc thực hiện Haskell mới dẫn đến những thay đổi đáng chú ý (Bảng 2).
Lưu ý rằng bốn thử nghiệm đầu tiên đã bị vô hiệu hóa với số nguyên đơn giản vì chúng mất quá nhiều thời gian hoặc không hoàn thành (đống tràn) nhưng tất cả chúng đều được truyền lại.
Ngoài ra, T10678, thử nghiệm cuối cùng trong bảng, thực hiện rất nhiều bổ sung của một số lượng nhỏ vào một số lượng lớn.
Như chúng ta đã thấy ở trên, đây là trường hợp duy nhất mà biểu diễn đơn giản số nguyên là tốt hơn: trong hầu hết các lần lặp chỉ, chỉ người đứng đầu danh sách được sửa đổi mà không sao chép đuôi.
Nó được phản ánh một lần nữa trong kết quả này.

![](img/2020-07-28-improving-haskells-big-numbers-support.012.png)

Finally, we compared native-backend with gmp-backend: it tells us how far our Haskell implementation is from our best backend. Noticeable changes are reported in Table 3.

Cuối cùng, chúng tôi đã so sánh hậu vệ tự nhiên với GMP-Backend: Nó cho chúng tôi biết việc triển khai Haskell của chúng tôi là bao xa từ phụ trợ tốt nhất của chúng tôi.
Những thay đổi đáng chú ý được báo cáo trong Bảng 3.

![](img/2020-07-28-improving-haskells-big-numbers-support.013.png)

## **Conclusion**

## **Sự kết luận**

We are very proud to have made this contribution to GHC. IOHK and the whole community now benefits from the improved performance and robustness of the compiler. Programs that use the new Haskell implementation of big numbers (native-backend) should get a performance boost when they switch from integer-simple.

Chúng tôi rất tự hào vì đã đóng góp này cho GHC.
IOHK và toàn bộ cộng đồng hiện được hưởng lợi từ hiệu suất và sự mạnh mẽ được cải thiện của trình biên dịch.
Các chương trình sử dụng triển khai Haskell mới của các số lớn (hậu vệ tự nhiên) sẽ được tăng hiệu suất khi chúng chuyển từ số nguyên đơn giản.

We are also eager to see what the community will do with this work. In particular, it should now be easier to create backends based on other libraries. There is also a lot of room for optimization in native-backend. We also encourage everyone to test this new implementation and to report any issue on [GHC’s bug tracker.](https://gitlab.haskell.org/ghc/ghc/-/issues)

Chúng tôi cũng mong muốn xem cộng đồng sẽ làm gì với công việc này.
Cụ thể, bây giờ sẽ dễ dàng hơn để tạo các phụ trợ dựa trên các thư viện khác.
Ngoài ra còn có rất nhiều chỗ để tối ưu hóa trong backend bản địa.
Chúng tôi cũng khuyến khích tất cả mọi người kiểm tra triển khai mới này và báo cáo bất kỳ vấn đề nào trên [GHC Lừa theo dõi lỗi.]

