# Blockchain governance - from philosophy and vision to real-world application
### **Robust and effective community governance lies at the very heart of Cardano's decentralized vision, and Project Catalyst will test the theory this summer.**
![](img/2020-08-05-philosophy-of-governance.002.png) 5 August 2020![](img/2020-08-05-philosophy-of-governance.002.png)[ Olga Hryniuk](tmp//en/blog/authors/olga-hryniuk/page-1/)![](img/2020-08-05-philosophy-of-governance.003.png) 8 mins read

![Olga Hryniuk](img/2020-08-05-philosophy-of-governance.004.png)[](tmp//en/blog/authors/olga-hryniuk/page-1/)
### [**Olga Hryniuk**](tmp//en/blog/authors/olga-hryniuk/page-1/)
Technical Writer

Marketing & Communications

- ![](img/2020-08-05-philosophy-of-governance.005.png)[](https://www.linkedin.com/in/olga-hryniuk-1094a3160/ "LinkedIn")
- ![](img/2020-08-05-philosophy-of-governance.006.png)[](https://github.com/olgahryniuk "GitHub")

![Blockchain governance - from philosophy and vision to real-world application](img/2020-08-05-philosophy-of-governance.007.jpeg)

Taking a decentralized approach to governance and decision-making is proving to be more efficient in many spheres than the centralized, authority-based model that became the norm in so many areas in the last century. At IOHK, we believe that blockchain technology offers a way to encourage participation in collective action. And we are building just such a system, so Cardano can grow in a fair and decentralized way, with an open governance system that encourages global participation by granting ada holders the power to make decisions.

Thực hiện một cách tiếp cận phi tập trung đối với quản trị và ra quyết định đang chứng tỏ là hiệu quả hơn trong nhiều lĩnh vực so với mô hình tập trung, dựa trên cơ quan, đã trở thành chuẩn mực trong nhiều lĩnh vực trong thế kỷ trước.
Tại IOHK, chúng tôi tin rằng công nghệ blockchain cung cấp một cách để khuyến khích tham gia vào hành động tập thể.
Và chúng tôi đang xây dựng một hệ thống như vậy, vì vậy Cardano có thể phát triển một cách công bằng và phi tập trung, với một hệ thống quản trị mở khuyến khích sự tham gia toàn cầu bằng cách cấp cho chủ sở hữu ADA quyền lực để đưa ra quyết định.

## **Decentralization is core to global governance**

## ** Phân cấp là cốt lõi của quản trị toàn cầu **

As weâ€™ve been working on this, the pandemic crisis has exposed weaknesses in our globalized economy and made it clear that everyone needs to reconsider the ways we collaborate in the face of challenging international situations. Over recent decades, the world has become ever more connected through digital infrastructure and social platforms. Therefore, robust tools and new behavior patterns are now necessary to improve the way we collaborate. 

Khi chúng ta đang làm việc về vấn đề này, cuộc khủng hoảng đại dịch đã phơi bày những điểm yếu trong nền kinh tế toàn cầu hóa của chúng ta và nói rõ rằng mọi người cần xem xét lại cách chúng ta hợp tác khi đối mặt với các tình huống quốc tế đầy thách thức.
Trong những thập kỷ gần đây, thế giới đã trở nên kết nối hơn bao giờ hết thông qua cơ sở hạ tầng kỹ thuật số và các nền tảng xã hội.
Do đó, các công cụ mạnh mẽ và các mẫu hành vi mới hiện là cần thiết để cải thiện cách chúng ta hợp tác.

In the past, large collective challenges had to be solved in a centralized manner by high-level actors governing from the â€˜topâ€™ down. In that governance model, power, authority, and control were decided and exercised at management level. This could be a chief executive, a president, or even a dictator determining the â€˜bestâ€™ course of action. In this centralized system, once a decision is made, it becomes the law of the land, and new behaviors are enforced. However, the top-down model is inefficient for solving global-scale challenges. Dr Mihaela Ulieru, an adviser on digital ecosystems organization and transformation, spoke at the recent Cardano Virtual Summit about her vision of â€˜bottom-upâ€™ organic governance. There, she pointed out that hierarchical structures are rigid and less productive. Furthermore, they cannot deal efficiently with emerging complexity.

Trong quá khứ, các thử thách tập thể lớn đã phải được giải quyết một cách tập trung bởi các diễn viên cấp cao điều chỉnh từ-âtopâ € ™ trở xuống.
Trong mô hình quản trị đó, quyền lực, thẩm quyền và kiểm soát đã được quyết định và thực hiện ở cấp quản lý.
Đây có thể là một giám đốc điều hành, một tổng thống, hoặc thậm chí là một nhà độc tài xác định hành động hành động ".
Trong hệ thống tập trung này, một khi quyết định được đưa ra, nó trở thành luật đất đai và các hành vi mới được thi hành.
Tuy nhiên, mô hình từ trên xuống là không hiệu quả để giải quyết các thách thức quy mô toàn cầu.
Tiến sĩ Mihaiela Ulieru, một cố vấn về Tổ chức và chuyển đổi hệ sinh thái kỹ thuật số, đã phát biểu tại Hội nghị thượng đỉnh ảo Cardano gần đây về tầm nhìn của cô về quản trị hữu cơ của cô.
Ở đó, cô chỉ ra rằng các cấu trúc phân cấp là cứng nhắc và kém năng suất.
Hơn nữa, họ không thể đối phó hiệu quả với sự phức tạp mới nổi.

A centralized governance model depends on the limited knowledge, expertise, and understanding of a single individual or a body of actors. Decisions must then proliferate through the system to deal with emerging problems. This generates an inflexible response that lacks on-the-ground information from the people affected by a particular event. Therefore, the more complex and widespread a problem is, the less prepared a top-down organization can deal with it in a way that works for most people. So the question arises, how do we create a system that responds to emerging problems, aids decision-making, and remains all-inclusive?

Một mô hình quản trị tập trung phụ thuộc vào kiến thức, chuyên môn và hiểu biết hạn chế về một cá nhân hoặc một cơ thể của các diễn viên.
Các quyết định sau đó phải sinh sôi nảy nở thông qua hệ thống để đối phó với các vấn đề mới nổi.
Điều này tạo ra một phản ứng không linh hoạt, thiếu thông tin trên mặt đất từ những người bị ảnh hưởng bởi một sự kiện cụ thể.
Do đó, một vấn đề phức tạp và phổ biến hơn là, một tổ chức từ trên xuống ít có thể đối phó với nó theo cách phù hợp với hầu hết mọi người.
Vì vậy, câu hỏi đặt ra, làm thế nào để chúng ta tạo ra một hệ thống đáp ứng các vấn đề mới nổi, ra quyết định AIDS và vẫn bao gồm tất cả?

Dr Ulieru reminds us that the bottom-up approach has been used in peer-to-peer networks to great effect allowing network participants to collaborate in a way that is reflective of the desires and needs of the community. [SoScial.Network](https://soscial.network/), launched by Jon Cole after Hurricane Harvey hit the southern US in 2017, is one example. This network enabled people and communities to gather and offer help to each other by providing aid to disaster victims. Another social network, [ChefsForAmerica](https://wck.org/chefsforamerica), delivers food to hospitals, the disadvantaged, and those in need. [AgeWell](https://www.agewellglobal.com/) created a peer-to-peer care delivery model that improves the well-being and health of elderly people, keeping them in their homes, while reducing their healthcare costs. Such activity, organized by individuals in a decentralized manner, can solve challenges faster and collaboratively.

Tiến sĩ Ulieru nhắc nhở chúng ta rằng phương pháp từ dưới lên đã được sử dụng trong các mạng ngang hàng để có hiệu quả tuyệt vời cho phép những người tham gia mạng hợp tác theo cách phản ánh mong muốn và nhu cầu của cộng đồng.
[Soscial.network] (https://soscial.network/), được ra mắt bởi Jon Cole sau khi cơn bão Harvey tấn công miền Nam Hoa Kỳ vào năm 2017, là một ví dụ.
Mạng lưới này cho phép mọi người và cộng đồng thu thập và cung cấp sự giúp đỡ cho nhau bằng cách cung cấp viện trợ cho các nạn nhân thảm họa.
Một mạng xã hội khác, [Chefsforamerica] (https://wck.org/chefsforamerica), cung cấp thực phẩm cho các bệnh viện, những người thiệt thòi và những người có nhu cầu.
[Agewell] (https://www.agewellglobal.com/) đã tạo ra một mô hình cung cấp dịch vụ chăm sóc ngang hàng giúp cải thiện sức khỏe và sức khỏe của người cao tuổi, giữ họ trong nhà, đồng thời giảm chi phí chăm sóc sức khỏe.
Hoạt động như vậy, được tổ chức bởi các cá nhân theo cách phi tập trung, có thể giải quyết các thách thức nhanh hơn và hợp tác.

## **Cardano decentralization**

## ** Phân cấp Cardano **

For effective collaboration on decision-making, Cardano offers a decentralized network built on a blockchain for a higher level of security and transparency. It takes the networking peer-to-peer concept further and builds it into a global infrastructure. For Cardano to establish a solid governance model, it is important to ensure that everyone can participate in a transparent, accountable, and responsive way. As decentralization empowers individuals and communities to take action and collaborate, anyone can suggest a change, or an activity to be initiated, whether this is for social good or for technological progress. 

Để hợp tác hiệu quả về việc ra quyết định, Cardano cung cấp một mạng lưới phi tập trung được xây dựng trên một blockchain để có mức độ bảo mật và minh bạch cao hơn.
Nó đưa khái niệm ngang hàng mạng hơn nữa và xây dựng nó thành một cơ sở hạ tầng toàn cầu.
Để Cardano thiết lập một mô hình quản trị vững chắc, điều quan trọng là phải đảm bảo rằng mọi người đều có thể tham gia vào một cách minh bạch, có trách nhiệm và đáp ứng.
Khi sự phân cấp trao quyền cho các cá nhân và cộng đồng hành động và hợp tác, bất cứ ai cũng có thể đề xuất một sự thay đổi, hoặc một hoạt động được bắt đầu, cho dù điều này là vì lợi ích xã hội hay tiến bộ công nghệ.

The question is, how to decide which change is crucial and what exactly will benefit everyone? Crucially, who will pay for its realization? To solve these issues, Cardano is establishing a global voting and treasury systems for funding the blockchain long-term development. Hence, decision-making and funding are two crucial components of governance. At IOHK, we worked to solve these issues and to provide the tools to empower decentralized governance and improve all our systems. 

Câu hỏi là, làm thế nào để quyết định thay đổi nào là quan trọng và chính xác điều gì sẽ có lợi cho mọi người?
Điều quan trọng, ai sẽ trả tiền cho việc hiện thực hóa của nó?
Để giải quyết những vấn đề này, Cardano đang thiết lập một hệ thống bỏ phiếu và kho bạc toàn cầu để tài trợ cho sự phát triển dài hạn của blockchain.
Do đó, việc ra quyết định và tài trợ là hai thành phần quan trọng của quản trị.
Tại IOHK, chúng tôi đã làm việc để giải quyết các vấn đề này và cung cấp các công cụ để trao quyền cho quản trị phi tập trung và cải thiện tất cả các hệ thống của chúng tôi.

## **Voltaire and ada holders**

## ** Chủ sở hữu Voltaire và ADA **

For Cardano, a decentralized governance model should grant all ada holders the ability to decide what changes should be made for the ecosystem to grow and mature. When building an ecosystem for the next century rather than the next decade, the self-sustainability of the network becomes vital. Since individuals in the Cardano ecosystem are most affected by the decisions made about the protocol, it is important for them to understand how those decisions are made and how they are paid for, as well as how to participate in that process.

Đối với Cardano, một mô hình quản trị phi tập trung nên cấp cho tất cả các chủ sở hữu ADA khả năng quyết định những thay đổi nào nên được thực hiện để hệ sinh thái phát triển và trưởng thành.
Khi xây dựng một hệ sinh thái trong thế kỷ tiếp theo chứ không phải là thập kỷ tiếp theo, khả năng tự duy trì của mạng trở nên quan trọng.
Vì các cá nhân trong hệ sinh thái Cardano bị ảnh hưởng nhiều nhất bởi các quyết định về giao thức, điều quan trọng là họ phải hiểu cách đưa ra các quyết định đó và cách họ được trả tiền, cũng như cách tham gia vào quá trình đó.

[Voltaire ](https://roadmap.cardano.org/en/voltaire/)is the era in Cardano development that deals with decentralized governance and decision-making. Voltaire focuses on the Cardano communityâ€™s ability to decide on software updates, technical improvements, and project funding. To provide the final components that turn Cardano into a self-sustainable blockchain, we need to introduce:

[Voltaire] (https://roadmap.cardano.org/en/voltaire/) là kỷ nguyên trong sự phát triển của Cardano liên quan đến quản trị phi tập trung và ra quyết định.
Voltaire tập trung vào khả năng của cộng đồng Cardano để quyết định cập nhật phần mềm, cải tiến kỹ thuật và tài trợ dự án.
Để cung cấp các thành phần cuối cùng biến Cardano thành một blockchain tự bền vững, chúng ta cần giới thiệu:

- A treasury system: a continuous source of funding to develop the Cardano blockchain.

- Một hệ thống kho bạc: Một nguồn tài trợ liên tục để phát triển blockchain Cardano.

- [Decentralized software updates](https://www.youtube.com/watch?v=eK1fAtubEyA&feature=youtu.be): the process enabling decentralized, open participation for fair voting on decisions about system advancements.

- [Cập nhật phần mềm phi tập trung] (https://www.youtube.com/watch?v=ek1Fatubeya&feature=youtu.be): Quá trình cho phép phân cấp, tham gia mở cho các quyết định về các quyết định về các tiến trình hệ thống.

In line with that, IOHKâ€™s engineers are implementing tools and social experiments to enable Cardanoâ€™s governance framework. Hence, we are working on:

Theo đó, các kỹ sư của IOHK đang thực hiện các công cụ và thử nghiệm xã hội để cho phép khung quản trị của Cardano.
Do đó, chúng tôi đang làm việc:

- Cardano improvement proposals (CIPs): a social communication system for describing formal, technically-oriented standards, codes, and processes that provide guidelines for the Cardano community in a transparent and open-source way.

-Các đề xuất cải tiến Cardano (CIP): Một hệ thống giao tiếp xã hội để mô tả các tiêu chuẩn, quy tắc và quy trình chính thức, định hướng kỹ thuật, cung cấp các hướng dẫn cho cộng đồng Cardano một cách minh bạch và nguồn mở.

- Project Catalyst: an experimental treasury system combining proposal and voting procedures.

- Project Catalyst: Một hệ thống kho bạc thử nghiệm kết hợp các quy trình đề xuất và bỏ phiếu.

Project Catalyst focuses on making the treasury system a reality by establishing a democratic culture for the Cardano community. This goal will be achieved by a combination of research, social experiments, and community consent. Catalyst enables the community to make proposals, vote on them, and fund them according to their feasibility, auditability and impact. 

Project Catalyst tập trung vào việc biến hệ thống kho bạc thành hiện thực bằng cách thiết lập văn hóa dân chủ cho cộng đồng Cardano.
Mục tiêu này sẽ đạt được bằng sự kết hợp của nghiên cứu, thí nghiệm xã hội và sự đồng ý của cộng đồng.
Chất xúc tác cho phép cộng đồng đưa ra các đề xuất, bỏ phiếu cho họ và tài trợ cho họ theo tính khả thi, khả năng kiểm toán và tác động của họ.

It is important to note that everyone has an equal right to propose changes and system enhancements, and that everyone is encouraged to collaborate on innovative and powerful proposals.

Điều quan trọng cần lưu ý là mọi người đều có quyền bình đẳng để đề xuất các thay đổi và cải tiến hệ thống, và mọi người đều được khuyến khích hợp tác về các đề xuất sáng tạo và mạnh mẽ.

To ensure that everyone gets a say, we are establishing a ballot submission system where people can propose improvements. This may be a proposal to sustain a system, to market it, or perhaps a suggestion to improve an existing protocol. In addition, IOHK wants to enable our community to create products or applications aimed at solving challenges within the market. 

Để đảm bảo rằng mọi người đều có tiếng nói, chúng tôi đang thiết lập một hệ thống đệ trình bỏ phiếu nơi mọi người có thể đề xuất các cải tiến.
Đây có thể là một đề xuất để duy trì một hệ thống, để tiếp thị nó, hoặc có lẽ là một gợi ý để cải thiện một giao thức hiện có.
Ngoài ra, IOHK muốn cho phép cộng đồng của chúng tôi tạo ra các sản phẩm hoặc ứng dụng nhằm giải quyết các thách thức trên thị trường.

To suggest such contributions, people can submit ballots to the community. After the ballots are submitted, voting will decide which proposals can move forward.

Để đề xuất những đóng góp như vậy, mọi người có thể gửi phiếu bầu cho cộng đồng.
Sau khi các lá phiếu được gửi, bỏ phiếu sẽ quyết định đề xuất nào có thể tiến lên.

Voting is the exercise of influence to decide which proposals get accepted or rejected. Only by encouraging everyone to participate can we ensure that preferences are determined in a democratic way. The value of Catalyst, though, lies not only in the technology improvement, but also in enabling the community to learn how to collaborate, make good decisions, and essentially, generate great proposals. So, decisions are taken through a robust set of voting protocols that we are developing. These will be evaluated by the community with the help of members who can put themselves forward as â€˜expertsâ€™ to help explain proposals.

Bỏ phiếu là việc thực hiện ảnh hưởng để quyết định đề xuất nào được chấp nhận hoặc từ chối.
Chỉ bằng cách khuyến khích mọi người tham gia, chúng ta mới có thể đảm bảo rằng các ưu tiên được xác định theo cách dân chủ.
Tuy nhiên, giá trị của Catalyst không chỉ nằm trong việc cải thiện công nghệ, mà còn cho phép cộng đồng học cách hợp tác, đưa ra quyết định tốt và về cơ bản, tạo ra các đề xuất tuyệt vời.
Vì vậy, các quyết định được đưa ra thông qua một tập hợp các giao thức bỏ phiếu mạnh mẽ mà chúng tôi đang phát triển.
Những điều này sẽ được cộng đồng đánh giá với sự giúp đỡ của các thành viên, những người có thể tự đặt mình là "Experts" để giúp giải thích các đề xuất.

Although any ada holder can submit a proposal, the voting power of an individual is proportional to the amount of ada that is â€˜lockedâ€™ into the system when people register. By voting, participants will influence decisions on which proposals to fund for network development and maintenance. This could also lead to the creation of educational materials, marketing strategies, technical improvements processes, and many other ideas.

Mặc dù bất kỳ chủ sở hữu ADA nào cũng có thể gửi một đề xuất, khả năng bỏ phiếu của một cá nhân tỷ lệ thuận với số lượng ADA được sử dụng vào hệ thống khi mọi người đăng ký.
Bằng cách bỏ phiếu, những người tham gia sẽ ảnh hưởng đến các quyết định về các đề xuất tài trợ cho phát triển và bảo trì mạng.
Điều này cũng có thể dẫn đến việc tạo ra các tài liệu giáo dục, chiến lược tiếp thị, quy trình cải tiến kỹ thuật và nhiều ý tưởng khác.

Another feature of Catalyst is privacy. As in any political elections, this is key for preventing voter coercion and helping defend against corruption. So, Cardano is looking to implement a zero-knowledge proof for each vote. This cryptographic technique grants privacy by allowing the vote to be verified without it being publicly revealed. 

Một tính năng khác của Catalyst là sự riêng tư.
Như trong bất kỳ cuộc bầu cử chính trị nào, đây là chìa khóa để ngăn chặn sự ép buộc của cử tri và giúp bảo vệ chống tham nhũng.
Vì vậy, Cardano đang tìm cách thực hiện một bằng chứng không hiểu biết cho mỗi phiếu bầu.
Kỹ thuật mật mã này cấp quyền riêng tư bằng cách cho phép bỏ phiếu được xác minh mà không được tiết lộ công khai.

## **The treasury funds proposals**

## ** Các đề xuất quỹ Kho bạc **

A crucial aspect of a self-sustainable network is understanding who will fund decisions and proposals. To meet these needs, Cardano is introducing a self-sustainable treasury system to fund blockchain enhancements and maintenance. The main sources of capital will be refilled every epoch from a portion of stake pool rewards, and later from minted new coins, the percentage from fees, and additional donations or charity. 

Một khía cạnh quan trọng của một mạng lưới tự bền vững là hiểu ai sẽ tài trợ cho các quyết định và đề xuất.
Để đáp ứng những nhu cầu này, Cardano đang giới thiệu một hệ thống kho bạc tự bền vững để tài trợ cho các cải tiến và bảo trì blockchain.
Các nguồn vốn chính sẽ được nạp lại mỗi kỷ nguyên từ một phần phần thưởng của nhóm cổ phần, và sau đó từ tiền xu mới, tỷ lệ phần trăm từ phí và quyên góp hoặc từ thiện bổ sung.

Project Catalyst will maintain this constant source of funding. A steady income stream will support initiatives and improvements proposed by ada holders, while at the same time rewarding and incentivizing people who dedicate their time and effort to making productive decisions. This will enable the establishment of a decentralized system that promotes participation, collaborative decisions, and incentivization. Besides the funding purposes, Catalyst ensures that funds are used well, facilitating the flow of information so the community is able to assess proposals while addressing the most important needs of the ecosystem.

Project Catalyst sẽ duy trì nguồn tài trợ liên tục này.
Một dòng thu nhập ổn định sẽ hỗ trợ các sáng kiến và cải tiến được đề xuất bởi các chủ sở hữu ADA, đồng thời bổ ích và khuyến khích những người dành thời gian và công sức của họ để đưa ra quyết định hiệu quả.
Điều này sẽ cho phép thiết lập một hệ thống phi tập trung nhằm thúc đẩy sự tham gia, quyết định hợp tác và khuyến khích.
Bên cạnh các mục đích tài trợ, chất xúc tác đảm bảo rằng các quỹ được sử dụng tốt, tạo điều kiện cho luồng thông tin để cộng đồng có thể đánh giá các đề xuất trong khi giải quyết các nhu cầu quan trọng nhất của hệ sinh thái.

IOHK is building a decentralized financial system that can address the world's needs. Voltaire is the first step in this direction. Using a collection of concepts, tools, and experiments, we are creating a fully decentralized ecosystem that will democratize our blockchain, and open it to the world. 

IOHK đang xây dựng một hệ thống tài chính phi tập trung có thể giải quyết các nhu cầu của thế giới.
Voltaire là bước đầu tiên theo hướng này.
Sử dụng một tập hợp các khái niệm, công cụ và thí nghiệm, chúng tôi đang tạo ra một hệ sinh thái phi tập trung hoàn toàn sẽ dân chủ hóa blockchain của chúng tôi và mở nó ra thế giới.

*Want to help shape the future of Cardano? Project Catalyst is looking for 25 community members to join a focus group on the direction of the program, pitch their ideas, and test the platform and voting. If you have an idea that might be suitable for funding, or would like to join a panel assessing community ideas, [apply today](https://docs.google.com/forms/d/1ooKwWwylKQ0-krsCv4eQAELal1nHpsjUWlgr1cwWqSQ/viewform?edit_requested=true)! Please ensure you have a Telegram and an email account to apply by midnight UTC on Friday, August 7.*

*Bạn muốn giúp định hình tương lai của Cardano?
Project Catalyst đang tìm kiếm 25 thành viên cộng đồng để tham gia một nhóm tập trung vào hướng của chương trình, đưa ra ý tưởng của họ và kiểm tra nền tảng và bỏ phiếu.
Nếu bạn có một ý tưởng có thể phù hợp để tài trợ, hoặc muốn tham gia một hội đồng đánh giá ý tưởng cộng đồng, [áp dụng ngày hôm nay] (https://docs.google.com/forms/d/1ookwwwylkq0-krscv4eqaelal1nh
thật)!
Vui lòng đảm bảo bạn có một bức điện tín và tài khoản email để đăng ký vào nửa đêm UTC vào thứ Sáu, ngày 7 tháng 8.*

