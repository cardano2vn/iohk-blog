# The decline and fall of centralization
### **This week marks the first step in the road to the full decentralization of Cardano, as stake pools begin to take responsibility for block production. Here’s what the journey will look like.**
![](img/2020-08-14-the-decline-and-fall-of-centralization.002.png) 14 August 2020![](img/2020-08-14-the-decline-and-fall-of-centralization.002.png)[ Kevin Hammond](tmp//en/blog/authors/kevin-hammond/page-1/)![](img/2020-08-14-the-decline-and-fall-of-centralization.003.png) 12 mins read

![Kevin Hammond](img/2020-08-14-the-decline-and-fall-of-centralization.004.png)[](tmp//en/blog/authors/kevin-hammond/page-1/)
### [**Kevin Hammond**](tmp//en/blog/authors/kevin-hammond/page-1/)
Software Engineer

Engineering

- ![](img/2020-08-14-the-decline-and-fall-of-centralization.005.png)[](https://twitter.com/inputoutputhk "Twitter")

![The decline and fall of centralization](img/2020-08-14-the-decline-and-fall-of-centralization.006.jpeg)

Full decentralization lies at the heart of Cardano’s mission. While it is not the only goal that we're focused on, in many ways, it is a goal that will enable and accelerate almost every other. It is *integral* to where we want to go as a project.

Phân cấp đầy đủ nằm ở trung tâm của nhiệm vụ Cardano.
Mặc dù nó không phải là mục tiêu duy nhất mà chúng tôi tập trung vào, theo nhiều cách, nhưng đó là một mục tiêu sẽ cho phép và tăng tốc hầu hết mọi người khác.
Đó là * tích phân * đến nơi chúng tôi muốn đến như một dự án.

It is also where the philosophical and technical grounding of the entire Cardano project meets its community, in very real and tangible ways. This is why we have done a lot of thinking on how to achieve decentralization effectively, safely, and with the health of the ecosystem front of mind.

Đó cũng là nơi nền tảng triết học và kỹ thuật của toàn bộ dự án Cardano gặp cộng đồng của nó, theo những cách rất thực tế và hữu hình.
Đây là lý do tại sao chúng tôi đã thực hiện rất nhiều suy nghĩ về cách đạt được sự phân cấp một cách hiệu quả, an toàn và với sức khỏe của mặt trước của hệ sinh thái.

### **Defining *decentralization***

### ** Xác định*Phân cấp ***

Let’s start by explaining what we mean by *decentralization*. This is a word that is fraught with challenge, with several competing meanings prevalent in the blockchain community. 

Hãy bắt đầu bằng cách giải thích ý nghĩa của chúng tôi bằng cách *phân cấp *.
Đây là một từ đầy thách thức, với một số ý nghĩa cạnh tranh phổ biến trong cộng đồng blockchain.

For us, decentralization is both a destination and a journey. Shelley represents the first steps toward a fully decentralized state; from the static, federated approach of Byron to a fully democratic environment where the community not only runs the network, but is empowered and encouraged to take decisions through an on-chain framework of governance and voting.

Đối với chúng tôi, phân cấp là cả điểm đến và một hành trình.
Shelley đại diện cho những bước đầu tiên đối với một trạng thái phi tập trung hoàn toàn;
Từ cách tiếp cận tĩnh, liên kết của Byron đến một môi trường dân chủ hoàn toàn, nơi cộng đồng không chỉ điều hành mạng lưới mà còn được trao quyền và khuyến khích đưa ra quyết định thông qua khuôn khổ quản trị và bỏ phiếu trên chuỗi.

True decentralization lies at the confluence of three essential components, working together in unison.

Phân cấp thực sự nằm ở nơi hợp lưu của ba thành phần thiết yếu, làm việc cùng nhau đồng thanh.

- **Networking** - where geographically distributed agents are linked together to provide a secure and robust blockchain platform.

- ** Mạng ** - Trường hợp các tác nhân phân bố địa lý được liên kết với nhau để cung cấp một nền tảng blockchain an toàn và mạnh mẽ.

- **Block production** - where the work of building and maintaining the blockchain is distributed across the network to a collection of cooperating stake pools.

- ** Sản xuất khối ** - Trường hợp công việc xây dựng và duy trì blockchain được phân phối trên mạng cho một bộ sưu tập các nhóm cổ phần hợp tác.

- **Governance** - where decisions about the blockchain protocol and the evolution of Cardano are taken collectively by the community of Cardano stakeholders.

- ** Quản trị ** - Trong đó các quyết định về giao thức blockchain và sự phát triển của Cardano được cộng đồng các bên liên quan của Cardano thực hiện.

Only when all these factors exist within a single environment can true decentralization be said to have been achieved successfully.

Chỉ khi tất cả các yếu tố này tồn tại trong một môi trường duy nhất mới có thể phân cấp thực sự được cho là đã đạt được thành công.

### **Key parameters that affect decentralization**

### ** Các thông số chính ảnh hưởng đến phân cấp **

Let's talk about *d*, maybe.

Hãy nói về *d *, có thể.

The *d*-parameter performs a pivotal role in controlling the decentralization of block production. Decentralization is a spectrum, of course, rather than an absolute. In simple terms, d controls ‘how’ decentralized the network is. For example, at one extreme, *d*=1 means that block production is fully centralized. In this state, IOG’s core nodes produce all the blocks. This was how Byron operated,

Các parameter *d *thực hiện vai trò then chốt trong việc kiểm soát việc phân cấp sản xuất khối.
Phân cấp là một quang phổ, tất nhiên, thay vì tuyệt đối.
Nói một cách đơn giản, D điều khiển mạng đã phân cấp mạng như thế nào.
Ví dụ, ở một thái cực, *d *= 1 có nghĩa là sản xuất khối được tập trung hoàn toàn.
Ở trạng thái này, các nút cốt lõi của IOG, tạo ra tất cả các khối.
Đây là cách Byron hoạt động,

Conversely, once *d*=0, and decentralized governance is in place and on chain, ‘full’ decentralization will have been achieved. At this point, stake pool operators produce all the blocks (block production is 100% decentralized), the community makes all the decisions on future direction and development (governance is decentralized), and a healthy ecosystem of geographically distributed stake pools are connected into a coherent and effective network (the network is decentralized). We will have reached our decentralization goal.

Ngược lại, một lần *d *= 0, và quản trị phi tập trung được áp dụng và trên chuỗi, sự phân cấp đầy đủ sẽ đạt được.
Tại thời điểm này, các nhà khai thác nhóm cổ phần sản xuất tất cả các khối (sản xuất khối được phân cấp 100%), cộng đồng đưa ra tất cả các quyết định về định hướng và phát triển trong tương lai (quản trị được phân cấp) và một hệ sinh thái lành mạnh của các cổ phần phân phối địa lý được kết nối thành một
Mạng kết hợp và hiệu quả (mạng được phân cấp).
Chúng tôi sẽ đạt được mục tiêu phân cấp của chúng tôi.

The journey that *d* will take from 1 to 0 is a nuanced one that requires a careful balance between the action of the protocol and the reaction of the network and its community. Rather than declining instantly, *d* will go through a period of ‘constant decay’ where it is gradually decremented until it reaches 0. At this point Cardano will be fully decentralized. This gradual process will allow us to collect performance data and to monitor the state of the network as it progresses towards this all-important point. A parameter-driven approach will help provide the community with transparency and a level of predictability. Meanwhile, we’ll be monitoring the results carefully; there will always be socio-economic and market factors to consider once ‘in the wild’.

Hành trình mà * D * sẽ lấy từ 1 đến 0 là một cuộc hành trình đòi hỏi sự cân bằng cẩn thận giữa hành động của giao thức và phản ứng của mạng và cộng đồng của nó.
Thay vì giảm ngay lập tức, * D * sẽ trải qua khoảng thời gian decay không đổi, nơi nó bị giảm dần cho đến khi nó đạt đến 0. Tại thời điểm này, Cardano sẽ được phân cấp hoàn toàn.
Quá trình dần dần này sẽ cho phép chúng tôi thu thập dữ liệu hiệu suất và giám sát trạng thái của mạng khi nó tiến triển theo điểm quan trọng này.
Một cách tiếp cận dựa trên tham số sẽ giúp cung cấp cho cộng đồng sự minh bạch và mức độ dự đoán.
Trong khi đó, chúng tôi sẽ theo dõi các kết quả một cách cẩn thận;
Sẽ luôn có các yếu tố kinh tế xã hội và thị trường để xem xét một lần trong hoang dã.

### **How will the d parameter change over time**

### ** Tham số D sẽ thay đổi theo thời gian ** như thế nào

The evolution from 1 to 0 is relatively simple:

Sự tiến hóa từ 1 đến 0 tương đối đơn giản:

When *d*=1, all blocks are produced by IOG core nodes, running in Ouroboros Byzantine Fault Tolerance (OBFT) mode. No blocks are produced by stake pool operators (running in Ouroboros Praos mode). All rewards go to treasury.

Khi *d *= 1, tất cả các khối được tạo bởi các nút lõi IOG, chạy trong chế độ dung sai lỗi Byzantine (OBFT) của Ouoboros.
Không có khối nào được sản xuất bởi các toán tử Pool Stake (chạy ở chế độ Ouroboros PRAOS).
Tất cả các phần thưởng đều đi đến Kho bạc.

When *d*=0, the reverse becomes true: every block will be produced by stake pools (running in Praos mode), and none by the IOG core nodes. All rewards go to stake pools, once the fixed treasury rate is taken.

Khi *d *= 0, điều ngược lại trở thành sự thật: Mỗi khối sẽ được sản xuất bởi các nhóm cổ phần (chạy ở chế độ PRAOS) và không có nút nào bởi các nút lõi IOG.
Tất cả các phần thưởng được đưa đến các nhóm cổ phần, một khi tỷ lệ kho bạc cố định được thực hiện.

In between these extremes, a fraction of the blocks will be produced by the core nodes, and a fraction by the stake pools. The precise amounts are determined by *d*. So when *d* reaches 0.7, for example, 70% of the blocks will be produced by the core nodes and 30% will be produced by stake pools. When *d* subsequently reaches 0.2, 20% of the blocks will be produced by the core nodes, and 80% by the stake pools. 

Ở giữa các thái cực này, một phần của các khối sẽ được tạo ra bởi các nút lõi và một phần của các nhóm cổ phần.
Các lượng chính xác được xác định bởi *d *.
Vì vậy, khi * D * đạt 0,7, ví dụ, 70% các khối sẽ được sản xuất bởi các nút lõi và 30% sẽ được sản xuất bởi các nhóm cổ phần.
Khi * d * sau đó đạt 0,2, 20% các khối sẽ được tạo ra bởi các nút lõi và 80% bởi các nhóm cổ phần.

It is important to note that regardless of the percentage of blocks that are produced by the stake pools, however, once *d* < 1, all the rewards will go to stake pools in line with the stake that they hold (after the fixed treasury percentage is taken), and none to the core nodes. This means that IOG has absolutely no incentive to keep the *d* parameter high. In fact, when *d* reaches zero, IOG will be able to save the costs of running the core nodes, which are not insubstantial.

Điều quan trọng cần lưu ý là bất kể tỷ lệ phần trăm của các khối được sản xuất bởi các nhóm cổ phần, tuy nhiên, một khi
Tỷ lệ phần trăm được thực hiện), và không có nút nào cho các nút cốt lõi.
Điều này có nghĩa là IOG hoàn toàn không có động cơ để giữ tham số * D * cao.
Trên thực tế, khi * D * đạt được số 0, IOG sẽ có thể tiết kiệm chi phí chạy các nút cốt lõi, không phải là không đáng kể.

Like many other ada holders, IO Global is currently running a number of stake pools on the mainnet. As the creator of the Cardano platform, IO Global naturally has a significant stake in its success from fiscal, fiduciary, and security aspects, and this success will be built on a large number of effective and decentralized pools. As a commercial entity, IO needs to generate revenue from its stake, while recognizing the part it needs to play within an ecosystem of stake pools, helping to grow and maintain the health of the network as we move towards full decentralization. In the medium term, we will follow a private/public/community delegation approach, similar to that we adopted on the ITN, spreading our stake across both IOG and community pools. In the short term, however, we are running IOG pools on the mainnet, establishing a number of our own pools that can take some of the load from our core nodes. Using our stake and technical expertise to secure and stabilise the network is an important element at first, but one that will become less important as the *d* parameter decreases. The road to decentralization will offer many opportunities for pools of all sizes to establish themselves and thrive along the way.

Giống như nhiều chủ sở hữu ADA khác, IO Global hiện đang điều hành một số nhóm cổ phần trên mainnet. Là người tạo ra nền tảng Cardano, IO Global tự nhiên có cổ phần đáng kể trong thành công từ các khía cạnh tài chính, ủy thác và bảo mật, và thành công này sẽ được xây dựng trên một số lượng lớn các nhóm hiệu quả và phi tập trung. Là một thực thể thương mại, IO cần tạo doanh thu từ cổ phần của mình, đồng thời nhận ra phần cần chơi trong một hệ sinh thái của nhóm cổ phần, giúp phát triển và duy trì sức khỏe của mạng khi chúng ta tiến tới phân cấp hoàn toàn. Trong trung hạn, chúng tôi sẽ tuân theo cách tiếp cận của phái đoàn tư nhân/cộng đồng/cộng đồng, tương tự như chúng tôi đã áp dụng trên ITN, lan truyền cổ phần của chúng tôi trên cả IOG và nhóm cộng đồng. Tuy nhiên, trong ngắn hạn, chúng tôi đang chạy các nhóm IOG trên Mainnet, thiết lập một số nhóm riêng của chúng tôi có thể lấy một số tải từ các nút cốt lõi của chúng tôi. Sử dụng cổ phần và chuyên môn kỹ thuật của chúng tôi để bảo mật và ổn định mạng là một yếu tố quan trọng lúc đầu, nhưng một yếu tố sẽ trở nên ít quan trọng hơn khi tham số * D * giảm. Con đường phân cấp sẽ cung cấp nhiều cơ hội cho các nhóm thuộc mọi quy mô để tự thiết lập và phát triển trên đường đi.

![d-parameter diagram](img/2020-08-14-the-decline-and-fall-of-centralization.007.png)

### **The key milestones of the *d* journey**

### ** Các cột mốc quan trọng của cuộc hành trình*d***

***d*<1.0 (Move away from centralization)**

*** D*<1.0 (di chuyển khỏi tập trung) **

The first milestone happened on August 13 at the boundary of epoch 210 and 211 when the *d* parameter first dropped below 1.0. At this point, IOG's core nodes started to share the block production of blocks with community stake pools. This marks the beginning of the road to full decentralization. 

Cột mốc đầu tiên xảy ra vào ngày 13 tháng 8 tại ranh giới của Epoch 210 và 211 khi tham số * D * lần đầu tiên giảm xuống dưới 1.0.
Tại thời điểm này, các nút cốt lõi của IOG bắt đầu chia sẻ việc sản xuất khối các khối với các nhóm cổ phần cộng đồng.
Điều này đánh dấu sự khởi đầu của con đường để phân cấp hoàn toàn.

***d*=0.8 (Stake pools produce 20% of blocks)**

*** d*= 0.8 (nhóm cổ phần sản xuất 20% khối) **

At 0.8, more pools (double the number compared to *d*=0.9) will get the opportunity to create blocks and establish themselves. At this level, pools won’t suffer in the rankings as long as they create one of the allocated blocks and get rewards. This way, we believe we can start growing the block-minting proportion of the network, at low network risk.

Ở mức 0,8, nhiều nhóm hơn (gấp đôi số so với *d *= 0,9) sẽ có cơ hội tạo các khối và tự thiết lập.
Ở cấp độ này, các nhóm đã giành được sự đau khổ trong bảng xếp hạng miễn là chúng tạo ra một trong những khối được phân bổ và nhận phần thưởng.
Bằng cách này, chúng tôi tin rằng chúng tôi có thể bắt đầu phát triển tỷ lệ thu nhỏ của mạng, có nguy cơ mạng thấp.

***d*<0.8 (Stake pool performance taken into account)**

*** D*<0.8 (Hiệu suất nhóm cổ phần được tính đến) **

The next major milestone will happen when *d* drops below 0.8. Below that level, each pool's performance will be taken into account when determining the rewards that it receives. Above that level, however, the pool’s performance is ignored. The reason for this is to avoid unfairness to pools when they are only expected to produce a few blocks. 

Các cột mốc chính tiếp theo sẽ xảy ra khi * D * giảm xuống dưới 0,8.
Dưới mức đó, hiệu suất của mỗi nhóm sẽ được tính đến khi xác định phần thưởng mà nó nhận được.
Tuy nhiên, trên mức đó, hiệu suất của nhóm nhóm bị bỏ qua.
Lý do cho điều này là để tránh sự không công bằng đối với các nhóm khi chúng chỉ được dự kiến sẽ tạo ra một vài khối.

***d*<0.5 (Stake Pools Produce the Majority of Blocks)**

*** D*<0,5 (nhóm cổ phần tạo ra phần lớn các khối) **

When *d* drops below 0.5, stake pools will produce the majority of blocks. The network will have reached a tipping point, where decentralization is inevitable.

Khi * D * giảm xuống dưới 0,5, nhóm Stake sẽ tạo ra phần lớn các khối.
Mạng sẽ đạt đến một điểm bùng phát, trong đó phân cấp là không thể tránh khỏi.

Before taking this dramatic step, we will ensure that two critical features are in place: peer-to-peer (P2P) pool discovery and protocol changes to enable community voting. These will enable us to make the final push to full and true decentralization The recently announced [Project Catalyst program](https://iohk.io/en/blog/posts/2020/08/05/philosophy-of-governance/) was the first step in this, concurrent journey to full on-chain governance.

Trước khi thực hiện bước kịch tính này, chúng tôi sẽ đảm bảo rằng hai tính năng quan trọng đã được đưa ra: khám phá nhóm ngang hàng (P2P) và thay đổi giao thức để cho phép bỏ phiếu cộng đồng.
Những điều này sẽ cho phép chúng tôi thực hiện thúc đẩy cuối cùng để phân cấp đầy đủ và thực sự được công bố gần đây [Chương trình Project Catalyst] (https://iohk.io/en/blog/posts/2020/08/05/philosophy-of-governance/)
là bước đầu tiên trong hành trình này, hành trình đồng thời để quản trị chuỗi đầy đủ.

***d*=0 (Achieve Full Decentralization)**

*** d*= 0 (đạt được sự phân cấp đầy đủ) **

As soon as the parameter reaches 0, the IOG core nodes will be permanently switched off.

Ngay khi tham số đạt 0, các nút lõi IOG sẽ được tắt vĩnh viễn.

IOG will continue to run its own stake pools that will produce blocks in line with the stake they attract, just like any other pools. But these will no longer have any special role in maintaining the Cardano network. It will also, of course, delegate a substantial amount of its stake to community pools. Simultaneously, the voting mechanism will be enabled, and it will no longer be possible to increase *d* and ‘re-centralize’ Cardano. 

IOG sẽ tiếp tục chạy các nhóm cổ phần của riêng mình sẽ tạo ra các khối phù hợp với cổ phần mà chúng thu hút, giống như bất kỳ nhóm nào khác.
Nhưng những điều này sẽ không còn có vai trò đặc biệt nào trong việc duy trì mạng Cardano.
Tất nhiên, nó cũng sẽ ủy thác một lượng đáng kể cổ phần của mình cho các nhóm cộng đồng.
Đồng thời, cơ chế bỏ phiếu sẽ được bật và sẽ không còn có thể tăng * D * và tập trung lại Cardano.

At this point in time, we will have irrevocably entered a fully decentralized Cardano network. **Network + block production + on-chain governance = decentralization.**

Tại thời điểm này, chúng tôi sẽ nhập vào một mạng Cardano phi tập trung hoàn toàn.
** Mạng + Khối sản xuất + Quản trị chuỗi trên chuỗi = Phân cấp. **

### **Rate of constant decay**

### ** Tỷ lệ phân rã không đổi **

The progressive decrement of *d* is known as *constant decay*. The gradual decrease will give us the chance to monitor the effects of each decrement on the network and to make adjustments where necessary. As the parameter decreases, more stake pools will also be able to make blocks, since the number of blocks that are made by the pools will increase, and less stake will then be required for each block that is made.

Sự giảm dần của *d *được gọi là *phân rã không đổi *.
Việc giảm dần sẽ cho chúng ta cơ hội theo dõi các tác động của từng sự giảm trên mạng và để điều chỉnh khi cần thiết.
Khi tham số giảm, nhiều nhóm cổ phần cũng sẽ có thể tạo ra các khối, vì số lượng khối được thực hiện bởi các nhóm sẽ tăng lên, và sau đó sẽ ít cổ phần hơn cho mỗi khối được tạo ra.

The key factors driving this decrease will be:

Các yếu tố chính thúc đẩy sự giảm này sẽ là:

- The resilience and reliability of the network as a whole.

- Khả năng phục hồi và độ tin cậy của toàn bộ mạng.

- The number of effective block-producing pools.

- Số lượng các nhóm sản xuất khối hiệu quả.

- The amount of the total stake that has been delegated.

- Số tiền của tổng cổ phần đã được ủy quyền.

Here’s our current thinking on what implementation might look like:

Ở đây, suy nghĩ hiện tại của chúng tôi về việc thực hiện có thể trông như thế nào:

![Constant decay timeline](img/2020-08-14-the-decline-and-fall-of-centralization.007.png)

We will then likely pause before dropping the parameter below 0.5 to ensure that the two key conditions described above are met:

Sau đó, chúng tôi có thể sẽ tạm dừng trước khi bỏ tham số dưới 0,5 để đảm bảo rằng hai điều kiện chính được mô tả ở trên được đáp ứng:

- The implementation of the new Peer-to-Peer pool discovery mechanism has been released and is successfully in use;

-Việc thực hiện cơ chế khám phá nhóm ngang hàng mới đã được phát hành và được sử dụng thành công;

- We have successfully transitioned the first hard fork in the Shelley era, which will introduce the basis for community voting on protocol parameters, and other important protocol changes

- Chúng tôi đã chuyển thành công Fork Fork đầu tiên trong kỷ nguyên Shelley, điều này sẽ giới thiệu cơ sở cho việc bỏ phiếu cộng đồng về các tham số giao thức và các thay đổi giao thức quan trọng khác

We will resume the countdown to *d*=0 at a similar rate, pausing again if necessary before finally transitioning to *d*=0 in March 2021.

Chúng tôi sẽ tiếp tục đếm ngược đến *d *= 0 với tốc độ tương tự, tạm dừng lại nếu cần thiết trước khi cuối cùng chuyển sang *d *= 0 vào tháng 3 năm 2021.

### **Other factors that affect decentralization: Saturation threshold**

### ** Các yếu tố khác ảnh hưởng đến phân cấp: ngưỡng bão hòa **

A second parameter – *k* – is used to drive growth in the number of pools by encouraging delegators to spread their stake. By setting a cap on the amount of stake that earns rewards (the saturation threshold), new delegators are directed towards pools that have less stake. In ideal conditions, the network will stabilise towards the specific number of pools that have been targeted. In practice, we saw from the ITN that many more pools than this number were supported by the setting that we chose. 

Một tham số thứ hai - * K * - được sử dụng để thúc đẩy tăng trưởng số lượng nhóm bằng cách khuyến khích các ủy viên phân bổ cổ phần của họ.
Bằng cách đặt giới hạn trên số lượng cổ phần kiếm được phần thưởng (ngưỡng bão hòa), các ủy viên mới được hướng tới các nhóm có ít cổ phần hơn.
Trong điều kiện lý tưởng, mạng sẽ ổn định về số lượng nhóm cụ thể đã được nhắm mục tiêu.
Trong thực tế, chúng tôi đã thấy từ ITN rằng nhiều nhóm hơn số này được hỗ trợ bởi cài đặt mà chúng tôi đã chọn.

The *k* parameter was set to 150 at the Shelley hard fork. This setting was chosen to balance the need to support a significant number of stake pools from the start of the Shelley era against the possibility that only a small number of effective pools would be set up by the community. In due course, it will be increased to reflect the substantial number of pools that have emerged in the Cardano ecosystem since the hard fork. This will spread stake, and so block production, among more pools. The overall goal in choosing the setting of the parameter will be to maximise the number of sustainable pools that the network can support, so creating a balanced ecosystem. In order to achieve this, a careful balance is required between opening up the opportunity to run a block-creating pool to as many pools as want to run the system, against the raw economics of running a pool (from bare metal servers, to cloud services, to people’s time), taking into account the rewards that can be earned from the actively delegated stake. Changing this parameter will therefore be done with a degree of caution and balance so that we ensure the long term success of a fully decentralized Cardano network. We’re now looking carefully at early pool data and doing some further modelling before making the next move. 

Tham số * K * được đặt thành 150 tại Shelley Hard Fork. Cài đặt này đã được chọn để cân bằng sự cần thiết phải hỗ trợ một số lượng đáng kể các nhóm cổ phần từ khi bắt đầu thời đại Shelley chống lại khả năng chỉ có một số lượng nhỏ các nhóm hiệu quả sẽ được cộng đồng thiết lập. Trong quá trình, nó sẽ được tăng lên để phản ánh số lượng đáng kể các nhóm đã xuất hiện trong hệ sinh thái Cardano kể từ hard fork. Điều này sẽ lan rộng cổ phần, và do đó chặn sản xuất, trong số nhiều hồ bơi hơn. Mục tiêu tổng thể trong việc lựa chọn cài đặt của tham số sẽ là tối đa hóa số lượng nhóm bền vững mà mạng có thể hỗ trợ, do đó tạo ra một hệ sinh thái cân bằng. Để đạt được điều này, cần có sự cân bằng cẩn thận giữa việc mở cơ hội để chạy một nhóm tạo khối tới nhiều hồ bơi như muốn chạy hệ thống, chống lại tính kinh tế thô của việc chạy một hồ bơi (từ các máy chủ kim loại trần, đến đám mây Dịch vụ, theo thời gian của mọi người), có tính đến phần thưởng có thể kiếm được từ cổ phần được ủy quyền tích cực. Do đó, việc thay đổi tham số này sẽ được thực hiện với một mức độ thận trọng và cân bằng để chúng tôi đảm bảo thành công lâu dài của một mạng Cardano phi tập trung hoàn toàn. Bây giờ chúng tôi đã xem xét cẩn thận dữ liệu hồ bơi sớm và thực hiện một số mô hình tiếp theo trước khi thực hiện bước tiếp theo.

### ***d* and pool rewards**

### *** d*và phần thưởng bể bơi **

Two questions remain: What is the effect of *d* on the rewards that a pool can earn, and can this parameter ever be increased?

Hai câu hỏi vẫn còn: ảnh hưởng của * d * đối với phần thưởng mà một nhóm có thể kiếm được, và tham số này có thể được tăng lên không?

Regarding rewards, as long as a pool produces at least one block, the value of the parameter has absolutely no effect on the rewards that a pool will earn – only on the number of blocks that are distributed to the pools. So if a pool has exactly 1% of the stake, it will earn precisely 1% of the total rewards, provided that it maintains its expected performance.

Về phần thưởng, miễn là một nhóm tạo ra ít nhất một khối, giá trị của tham số hoàn toàn không ảnh hưởng đến phần thưởng mà một nhóm sẽ kiếm được - chỉ trên số lượng khối được phân phối cho các nhóm.
Vì vậy, nếu một nhóm có chính xác 1% cổ phần, nó sẽ kiếm được chính xác 1% tổng số phần thưởng, miễn là nó duy trì hiệu suất dự kiến.

![d parameters and rewards](img/2020-08-14-the-decline-and-fall-of-centralization.008.png)

Finally, while *d* could in theory be increased, there would need to be a truly compelling reason to do so (a major protocol issue, or fundamental network security, for example.) We would never envision actually doing this in practice. Why? Simply because we want to smoothly and gradually reduce the parameter to 0 in order to achieve our objective of true decentralization. We’ll be making this journey carefully but with determination step by step. If each step is taken thoughtfully and with confidence, you should not need to retrace them? As *d* becomes 0, the centralized IO servers will be finally switched off, and Cardano will become a model of decentralized blockchain that others aspire to be.

Cuối cùng, trong khi về lý thuyết * d * có thể được tăng lên, thì cần phải có một lý do thực sự thuyết phục để làm như vậy (ví dụ như một vấn đề giao thức chính hoặc bảo mật mạng cơ bản.) Chúng tôi sẽ không bao giờ hình dung thực sự làm điều này trong thực tế.
Tại sao?
Đơn giản vì chúng tôi muốn giảm dần và giảm dần tham số xuống 0 để đạt được mục tiêu phân cấp thực sự của chúng tôi.
Chúng tôi sẽ thực hiện hành trình này một cách cẩn thận nhưng với quyết tâm từng bước.
Nếu mỗi bước được thực hiện một cách chu đáo và với sự tự tin, bạn không cần phải lấy lại chúng?
Khi * D * trở thành 0, các máy chủ IO tập trung cuối cùng sẽ bị tắt và Cardano sẽ trở thành mô hình của blockchain phi tập trung mà những người khác khao khát.

### **Conclusion**

### **Sự kết luận**

The decline of centralized entities coincides with Cardano's rise towards full and true decentralization. In the near future, the Cardano blockchain will be solely supported and operated by a strong community of stake pools whose best interest is the health and further development of the network.

Sự suy giảm của các thực thể tập trung trùng với sự gia tăng của Cardano đối với sự phân cấp đầy đủ và thực sự.
Trong tương lai gần, blockchain Cardano sẽ được hỗ trợ và vận hành bởi một cộng đồng mạnh mẽ của các nhóm cổ phần có mối quan tâm tốt nhất là sức khỏe và phát triển hơn nữa của mạng.

This journey, which began with Shelley and the implementation of the *d* parameter, will take Cardano through a path of evolutionary stages in which the network will become progressively more and more decentralized, as *d* decays. The journey will only end when the blockchain enters a state of irrevocable decentralization, a moment in time that will see networking, block production, and governance operating in harmony within a single environment.

Hành trình này, bắt đầu với Shelley và việc thực hiện tham số * d *, sẽ đưa Cardano đi qua một con đường của các giai đoạn tiến hóa trong đó mạng sẽ ngày càng phân cấp ngày càng nhiều hơn, như * d * phân rã.
Cuộc hành trình sẽ chỉ kết thúc khi blockchain bước vào trạng thái phân cấp không thể hủy bỏ, một thời điểm sẽ thấy mạng, sản xuất chặn và quản trị hoạt động hài hòa trong một môi trường duy nhất.

