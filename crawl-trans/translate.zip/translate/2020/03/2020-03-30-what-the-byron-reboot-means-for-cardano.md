# What the Byron reboot means for Cardano
### **New code delivers big benefits for the network and Daedalus users as we prepare for Shelley**
![](img/2020-03-30-what-the-byron-reboot-means-for-cardano.002.png) 30 March 2020![](img/2020-03-30-what-the-byron-reboot-means-for-cardano.002.png)[ Tim Harrison](tmp//en/blog/authors/tim-harrison/page-1/)![](img/2020-03-30-what-the-byron-reboot-means-for-cardano.003.png) 5 mins read

![Tim Harrison](img/2020-03-30-what-the-byron-reboot-means-for-cardano.004.png)[](tmp//en/blog/authors/tim-harrison/page-1/)
### [**Tim Harrison**](tmp//en/blog/authors/tim-harrison/page-1/)
VP of Community & Ecosystem

Communications

- ![](img/2020-03-30-what-the-byron-reboot-means-for-cardano.005.png)[](mailto:tim.harrison@iohk.io "Email")
- ![](img/2020-03-30-what-the-byron-reboot-means-for-cardano.006.png)[](https://uk.linkedin.com/in/timbharrison "LinkedIn")
- ![](img/2020-03-30-what-the-byron-reboot-means-for-cardano.007.png)[](https://twitter.com/timbharrison "Twitter")
- ![](img/2020-03-30-what-the-byron-reboot-means-for-cardano.008.png)[](https://github.com/timbharrison "GitHub")

![What the Byron reboot means for Cardano](img/2020-03-30-what-the-byron-reboot-means-for-cardano.009.jpeg)

The Byron reboot is a series of updates to multiple components of the Cardano network. Namely the Cardano node, but also the Cardano explorer, the wallet backend, and the Daedalus wallet itself. The first part of the Byron reboot â€“ a totally new node implementation â€“ has already been deployed to some relay nodes on the network, and the next few weeks will see core network nodes and more relays being incrementally upgraded to the new system. Soon, users will be able to experience the node improvements directly via a new version of the Daedalus wallet.

Khởi động lại Byron là một loạt các bản cập nhật cho nhiều thành phần của mạng Cardano.
Cụ thể là nút Cardano, nhưng cũng là nhà thám hiểm Cardano, phụ trợ ví và ví Daedalus.
Phần đầu tiên của việc khởi động lại Byron - một triển khai nút hoàn toàn mới - đã được triển khai đến một số nút chuyển tiếp trên mạng và vài tuần tới sẽ thấy các nút mạng lõi và nhiều rơle được nâng cấp lên hệ thống mới
.
Chẳng mấy chốc, người dùng sẽ có thể trải nghiệm các cải tiến nút trực tiếp thông qua phiên bản mới của ví Daedalus.

## **Why do we need a reboot?**

## ** Tại sao chúng ta cần khởi động lại? **

To prepare for the future, and for Shelley. The node that launched at the start of the Byron era was only ever going to take us so far. The new node implementation has been designed from the ground up to support not only imminent Shelley features, such as delegation and decentralization, but anything else that the future has in store. The improved design is modular, separating the ledger, consensus, and network components of the node, allowing any one of them to be changed, tweaked, and upgraded without affecting the others. 

Để chuẩn bị cho tương lai, và cho Shelley.
Nút được ra mắt khi bắt đầu thời đại Byron chỉ sẽ đưa chúng ta đến nay.
Việc triển khai nút mới đã được thiết kế từ đầu để hỗ trợ không chỉ các tính năng sắp xảy ra của Shelley, như phái đoàn và phân cấp, mà còn bất cứ điều gì khác mà tương lai có trong cửa hàng.
Thiết kế được cải tiến là mô -đun, tách sổ cái, sự đồng thuận và các thành phần mạng của nút, cho phép bất kỳ một trong số chúng được thay đổi, điều chỉnh và nâng cấp mà không ảnh hưởng đến người khác.

The reboot has also been an opportunity to apply evidence-based formal methods and testing to every single aspect of the node. Rather than try and make these substantial improvements to the existing code, it was more effective to work from scratch. All critical elements of the new node have been formally specified, and the final implementation tested against those specifications. Basic code quality and performance are now significantly higher and more robust across the board, as well as being easier to test and verify going forward.

Việc khởi động lại cũng là một cơ hội để áp dụng các phương pháp chính thức dựa trên bằng chứng và thử nghiệm cho mọi khía cạnh của nút.
Thay vì cố gắng và thực hiện những cải tiến đáng kể này đối với mã hiện có, việc làm việc từ đầu sẽ hiệu quả hơn.
Tất cả các yếu tố quan trọng của nút mới đã được chỉ định chính thức và việc triển khai cuối cùng được kiểm tra theo các thông số kỹ thuật đó.
Chất lượng mã cơ bản và hiệu suất hiện cao hơn và mạnh mẽ hơn đáng kể trên bảng, cũng như dễ dàng hơn để kiểm tra và xác minh trong tương lai.

## **Whatâ€™s involved?**

## ** Những gì liên quan? **

Improvements to the Cardano node, of course, but work has also been underway to improve the Cardano explorer, the wallet backend, and Daedalus itself. The new explorer has been redesigned to make it easier to use, as well as having an updated visual design and more information available. The improved wallet backend and associated services, collectively known as Adrestia, will allow exchanges and third-party developers to engage with the Cardano network using a collection of independent, self-contained libraries. The newly extended APIs have been explicitly designed to meet the needs of larger exchanges, enabling ada to be supported on even more platforms. And finally, a new and improved Daedalus release will see Yoroi wallet support, transaction filtering, parallel wallet restoration â€“ not to mention some significant performance improvements.

Tất nhiên, những cải tiến cho nút Cardano, nhưng công việc cũng đang được tiến hành để cải thiện Cardano Explorer, phụ trợ ví và chính Daedalus.
Explorer mới đã được thiết kế lại để giúp sử dụng dễ dàng hơn, cũng như có thiết kế hình ảnh cập nhật và có nhiều thông tin hơn.
Phụ trợ ví được cải tiến và các dịch vụ liên quan, được gọi chung là Adrestia, sẽ cho phép trao đổi và các nhà phát triển bên thứ ba tham gia với mạng Cardano bằng cách sử dụng một bộ sưu tập các thư viện độc lập, khép kín.
Các API mới mở rộng đã được thiết kế rõ ràng để đáp ứng nhu cầu của các trao đổi lớn hơn, cho phép ADA được hỗ trợ trên các nền tảng thậm chí nhiều hơn.
Và cuối cùng, một bản phát hành Daedalus mới và cải tiến sẽ thấy sự hỗ trợ của ví Yoroi, lọc giao dịch, phục hồi ví song song - không đề cập đến một số cải tiến hiệu suất đáng kể.

![Benefits of the Byron reboot](img/2020-03-30-what-the-byron-reboot-means-for-cardano.010.jpeg)

## **How will it impact the Cardano network?**

## ** Nó sẽ tác động đến mạng Cardano như thế nào? **

At the most fundamental level, the Byron reboot will improve the performance of the entire Cardano network. Transaction throughput capacity will increase, and the network will be able to handle much higher demand and transactions per second. The node improvements also make the node more efficient and reliable in terms of memory usage, increasing the viability of running a Cardano node on a low-spec machine or in poor network conditions, which, in turn, enables more users to participate in the Cardano network across the world. 

Ở cấp độ cơ bản nhất, việc khởi động lại Byron sẽ cải thiện hiệu suất của toàn bộ mạng Cardano.
Khả năng thông lượng giao dịch sẽ tăng và mạng sẽ có thể xử lý nhu cầu và giao dịch cao hơn nhiều mỗi giây.
Các cải tiến nút cũng làm cho nút hiệu quả và đáng tin cậy hơn về mặt sử dụng bộ nhớ, tăng khả năng chạy nút cardano trên máy spec thấp hoặc trong điều kiện mạng kém, đến lượt nó, cho phép nhiều người dùng tham gia vào Cardano
Mạng lưới trên toàn thế giới.

## **What does it mean for Daedalus users?**

## ** Ý nghĩa của người dùng Daedalus là gì? **

First, thereâ€™ll be a new rolling release of Daedalus that is designed to allow users to test the new node functionality and wallet backend, and to provide us with feedback. Weâ€™ll be sharing more about how that will work in our [monthly product update](https://www.crowdcast.io/e/ai0641sn/register) on Tuesday, March 31. Once the wallet has been user tested, feedback will be implemented in a new production version of Daedalus. Many of the issues users have experienced with Daedalus in the past were due to the underlying node, rather than Daedalus itself. The new node will go a long way to improving performance, and users should see Daedalus syncing and restoring wallets at significantly improved speeds.

Đầu tiên, sẽ có một bản phát hành Daedalus mới được thiết kế để cho phép người dùng kiểm tra chức năng nút mới và phụ trợ ví và cung cấp cho chúng tôi phản hồi.
Chúng tôi sẽ chia sẻ thêm về cách thức hoạt động trong [Cập nhật sản phẩm hàng tháng của chúng tôi] (https://www.crowdcast.io/e/ai0641sn/register) vào thứ ba, ngày 31 tháng 3.
Phản hồi sẽ được thực hiện trong một phiên bản sản xuất mới của Daedalus.
Nhiều vấn đề mà người dùng đã trải qua với Daedalus trong quá khứ là do nút cơ bản, thay vì chính Daedalus.
Nút mới sẽ đi một chặng đường dài để cải thiện hiệu suất và người dùng sẽ thấy Daedalus đồng bộ hóa và khôi phục ví với tốc độ được cải thiện đáng kể.

## **Whatâ€™s next?**

## ** tiếp theo là gì? **

The reboot commences with the deployment of a CLI and associated APIs to exchanges and wallet partners. The new node update will then be rolled out to more core and relay nodes on the Cardano mainnet within the next few weeks, followed by other reboot and continuing Daedalus improvements in the months ahead. The goal is to gradually and sustainably migrate the entire Cardano blockchain to working on the new node implementation, without any disruption or loss of service. After that comes the Haskell Shelley testnet, which will include onboarding stake pool operators from the Incentivized Testnet to help them set up and prepare for running their pools on the Shelley mainnet.

Việc khởi động lại bắt đầu với việc triển khai CLI và API liên quan đến trao đổi và đối tác ví.
Bản cập nhật nút mới sau đó sẽ được triển khai đến các nút cốt lõi hơn và chuyển tiếp trên Cardano Mainnet trong vài tuần tới, sau đó là khởi động lại khác và tiếp tục cải tiến Daedalus trong những tháng tới.
Mục tiêu là di chuyển dần dần và bền vững toàn bộ blockchain Cardano để làm việc với việc triển khai nút mới, mà không có bất kỳ sự gián đoạn hoặc mất dịch vụ nào.
Sau đó, Haskell Shelley Testnet, bao gồm các nhà khai thác nhóm cổ phần trên tàu từ Testnet được khuyến khích để giúp họ thiết lập và chuẩn bị để chạy nhóm của họ trên Shelley Mainnet.

The Byron reboot is the culmination of over 18 months of work by several IOHK development teams and represents a significant investment in the network-critical infrastructure required to support the Shelley era of Cardano. For more details on the reboot and how it will all roll out, tune in to Marchâ€™s product update on the [IOHK Crowdcast stream](https://www.crowdcast.io/e/ai0641sn/register) on March 31. Cardano product director Aparna Jue and members of her team will join me to discuss the latest on the reboot and the next steps for the project.

Việc khởi động lại Byron là đỉnh cao của hơn 18 tháng làm việc bởi một số nhóm phát triển IOHK và đại diện cho một khoản đầu tư đáng kể vào cơ sở hạ tầng quan trọng mạng cần thiết để hỗ trợ thời đại Shelley của Cardano.
Để biết thêm chi tiết về phần khởi động lại và tất cả sẽ được triển khai như thế nào, hãy theo dõi bản cập nhật sản phẩm của tháng ba trên [luồng đám đông IOHK] (https://www.crowdcast.io/e/ai0641sn/register) vào ngày 31 tháng 3
.

