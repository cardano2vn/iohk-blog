# Enter the Hydra: scaling distributed ledgers, the evidence-based way
### **Learn about Hydra: the multi-headed ledger protocol** 
![](img/2020-03-26-enter-the-hydra-scaling-distributed-ledgers-the-evidence-based-way.002.png) 26 March 2020![](img/2020-03-26-enter-the-hydra-scaling-distributed-ledgers-the-evidence-based-way.002.png)[ Prof Aggelos Kiayias](tmp//en/blog/authors/aggelos-kiayias/page-1/)![](img/2020-03-26-enter-the-hydra-scaling-distributed-ledgers-the-evidence-based-way.003.png) 10 mins read

![Prof Aggelos Kiayias](img/2020-03-26-enter-the-hydra-scaling-distributed-ledgers-the-evidence-based-way.004.png)[](tmp//en/blog/authors/aggelos-kiayias/page-1/)
### [**Prof Aggelos Kiayias**](tmp//en/blog/authors/aggelos-kiayias/page-1/)
Chief Scientist

Academic Research

- ![](img/2020-03-26-enter-the-hydra-scaling-distributed-ledgers-the-evidence-based-way.005.png)[](mailto:aggelos.kiayias@iohk.io "Email")
- ![](img/2020-03-26-enter-the-hydra-scaling-distributed-ledgers-the-evidence-based-way.006.png)[](tmp///www.youtube.com/watch?v=nB6eDbnkAk8 "YouTube")

![Enter the Hydra: scaling distributed ledgers, the evidence-based way ](img/2020-03-26-enter-the-hydra-scaling-distributed-ledgers-the-evidence-based-way.007.jpeg)

Scalability is the greatest challenge to blockchain adoption. By applying a principled, evidence-based approach, we have arrived at a solution for Cardano and networks similar to it: Hydra. Hydra is the culmination of extensive research, and a decisive step in enabling decentralized networks to securely scale to global requirements. 

Khả năng mở rộng là thách thức lớn nhất đối với việc áp dụng blockchain.
Bằng cách áp dụng một phương pháp nguyên tắc, dựa trên bằng chứng, chúng tôi đã đến một giải pháp cho Cardano và các mạng tương tự như nó: Hydra.
Hydra là đỉnh cao của nghiên cứu sâu rộng và là một bước quyết định trong việc cho phép các mạng phi tập trung vào quy mô an toàn theo các yêu cầu toàn cầu.

## **What is scalability and how do we measure it?**

## ** Khả năng mở rộng là gì và làm thế nào để chúng ta đo lường nó? **

Scaling a distributed ledger system refers to the capability of providing high transaction throughput, low latency, and minimal storage per node. These properties have been repeatedly touted as critical for the successful deployment of blockchain protocols as part of real-world systems. In terms of throughput, the VISA network [reportedly](https://usa.visa.com/run-your-business/small-business-tools/retail.html) handles an average of 1,736 payment transactions per second (TPS) with the capability of handling up to 24,000 TPS and is frequently used as a baseline comparison. Transaction latency is clearly desired to be as low as possible, with the ultimate goal of appearing instantaneous to the end-user. Other applications of distributed ledgers have a wide range of different requirements in terms of these metrics. When designing a general purpose distributed ledger, it is natural to strive to excel on all three counts. 

Việc mở rộng một hệ thống sổ cái phân tán đề cập đến khả năng cung cấp thông lượng giao dịch cao, độ trễ thấp và lưu trữ tối thiểu trên mỗi nút.
Các thuộc tính này đã được nhiều lần coi là rất quan trọng để triển khai thành công các giao thức blockchain như một phần của các hệ thống trong thế giới thực.
Về thông lượng, mạng Visa [được báo cáo] (https://usa.visa.com/run-your-business/small-business-tools/retail.html) Xử lý trung bình 1.736 giao dịch thanh toán mỗi giây (TPS)
với khả năng xử lý tới 24.000 TP và thường được sử dụng làm so sánh cơ bản.
Độ trễ giao dịch rõ ràng là mong muốn càng thấp càng tốt, với mục tiêu cuối cùng là xuất hiện tức thời cho người dùng cuối.
Các ứng dụng khác của sổ cái phân tán có một loạt các yêu cầu khác nhau về các số liệu này.
Khi thiết kế một sổ cái phân phối mục đích chung, việc cố gắng vượt trội là điều tự nhiên trên cả ba tội danh.

Deploying a system that provides satisfactory scaling for a certain use case requires an appropriate combination of two independent aspects: adopting a proper algorithmic design and deploying it over a suitable underlying hardware and network infrastructure.

Triển khai một hệ thống cung cấp tỷ lệ thỏa đáng cho một trường hợp sử dụng nhất định đòi hỏi sự kết hợp phù hợp của hai khía cạnh độc lập: áp dụng một thiết kế thuật toán phù hợp và triển khai nó trên cơ sở hạ tầng phần cứng và mạng cơ bản phù hợp.

When evaluating a particular algorithmic design, considering absolute numbers in terms of specific metrics can be misleading. The reason is that such absolute quantities must refer to a particular underlying hardware and network configuration which can blur the advantages and disadvantages of particular algorithms. Indeed, a poorly designed protocol may still perform well enough when deployed over superior hardware and networking.

Khi đánh giá một thiết kế thuật toán cụ thể, xem xét các số tuyệt đối về các số liệu cụ thể có thể gây hiểu lầm.
Lý do là các đại lượng tuyệt đối như vậy phải đề cập đến một cấu hình phần cứng và mạng cơ bản cụ thể có thể làm mờ các ưu điểm và nhược điểm của các thuật toán cụ thể.
Thật vậy, một giao thức được thiết kế kém vẫn có thể hoạt động đủ tốt khi được triển khai trên phần cứng và mạng vượt trội.

For this reason, it is more insightful to evaluate the ability of a protocol to reach the physical limits of the underlying network and hardware. This can be achieved by comparing the protocol with simple strawman protocols, in which all the design elements have been stripped away. For instance, if we want to evaluate the overhead of an encryption algorithm, we can compare the communication performance of two end-points using encryption against their performance when they simply exchange unencrypted messages. In such an experiment, the absolute message-per-second rate is unimportant. The important conclusion is the relative overhead that is added by the encryption algorithm. Moreover, in case the overhead approximates 0 for some configuration of the experimental setup, we can conclude that the algorithm approximates the physical limits of the underlying networkâ€™s message-passing ability for that particular configuration, and is hence optimal in this sense. 

Vì lý do này, việc đánh giá khả năng của một giao thức là sâu sắc hơn để đạt đến giới hạn vật lý của mạng và phần cứng cơ bản.
Điều này có thể đạt được bằng cách so sánh giao thức với các giao thức Strawman đơn giản, trong đó tất cả các yếu tố thiết kế đã bị loại bỏ.
Chẳng hạn, nếu chúng ta muốn đánh giá chi phí của thuật toán mã hóa, chúng ta có thể so sánh hiệu suất giao tiếp của hai điểm cuối bằng cách sử dụng mã hóa với hiệu suất của chúng khi chúng chỉ cần trao đổi các thông báo không được mã hóa.
Trong một thử nghiệm như vậy, tỷ lệ tin nhắn tuyệt đối trên mỗi giây là không quan trọng.
Kết luận quan trọng là chi phí tương đối được thêm vào bởi thuật toán mã hóa.
Hơn nữa, trong trường hợp chi phí xấp xỉ 0 cho một số cấu hình của thiết lập thử nghiệm, chúng ta có thể kết luận rằng thuật toán gần đúng với các giới hạn vật lý của khả năng thông báo của mạng cơ bản cho cấu hình cụ thể đó và do đó tối ưu theo nghĩa này.

## **Hydra â€“ 30,000-feet view**

## ** Hydra-lượt xem 30.000 feet **

Hydra is an off-chain scalability architecture for distributed ledgers, which addresses all three of the scalability challenges mentioned above: high transaction throughput, low latency, and minimal storage per node. While Hydra is being designed in conjunction with the Ouroboros protocol and the Cardano ledger, it may be employed over other systems as well, provided they share the necessary salient characteristics with Cardano.

Hydra là một kiến trúc khả năng mở rộng chuỗi cho các sổ cái phân tán, giải quyết cả ba thách thức về khả năng mở rộng được đề cập ở trên: thông lượng giao dịch cao, độ trễ thấp và lưu trữ tối thiểu trên mỗi nút.
Mặc dù Hydra đang được thiết kế kết hợp với giao thức Ouroboros và sổ cái Cardano, nhưng nó cũng có thể được sử dụng trên các hệ thống khác, miễn là họ chia sẻ các đặc điểm nổi bật cần thiết với Cardano.

Despite being an integrated system aimed at solving one problem â€“ scalability â€“ Hydra consists of several subprotocols. This is necessary as the Cardano ecosystem itself is heterogenous and consists of multiple entities with differing technical capabilities: the system supports block producers with associated stake pools, high-throughput wallets as used by exchanges, but also end-users with a wide variety of computational performance and availability characteristics. It is unrealistic to expect that a one-shoe-fits-all, single-protocol approach is sufficient to provide overall scalability for such a diverse set of network participants.

Mặc dù là một hệ thống tích hợp nhằm giải quyết một vấn đề - Khả năng mở rộng - Hydra Hydra bao gồm một số phụ.
Điều này là cần thiết vì hệ sinh thái Cardano không đồng nhất và bao gồm nhiều thực thể có khả năng kỹ thuật khác nhau: hệ thống hỗ trợ các nhà sản xuất khối với các nhóm cổ phần liên quan, ví thông lượng cao được sử dụng bởi các trao đổi, nhưng cũng có nhiều người dùng
hiệu suất và đặc điểm sẵn có.
Thật không thực tế khi hy vọng rằng một phương pháp tiếp cận giao thức đơn, phù hợp với một đôi giày là đủ để cung cấp khả năng mở rộng tổng thể cho một tập hợp những người tham gia mạng đa dạng như vậy.

The Hydra scalability architecture can be divided into four components: the head protocol, the tail protocol, the cross-head-and-tail communication protocol, as well as a set of supporting protocols for routing, reconfiguration, and virtualization. The centerpiece is the 'head' protocol, which enables a set of high-performance and high-availability participants (such as stake pools) to very quickly process large numbers of transactions with minimal storage requirements by way of a multiparty state channel â€“ a concept that generalizes two-party payment channels as implemented in the context of the Lightning network. It is complemented by the 'tail' protocol, which enables those high-performance participants to provide scalability for large numbers of end-users who may use the system from low-power devices, such as mobile phones, and who may be offline for extended periods of time. While heads and tails can already communicate via the Cardano mainchain, the cross-head-and-tail communication protocol provides an efficient offâ€“chain variant of this functionality. All this is tied together by routing and configuration management, while virtualisation facilitates faster communication generalizing head and tail communication. 

Kiến trúc khả năng mở rộng hydra có thể được chia thành bốn thành phần: giao thức đầu, giao thức đuôi, giao thức giao tiếp giữa hai đầu và đuôi, cũng như một tập hợp các giao thức hỗ trợ để định tuyến, cấu hình lại và ảo hóa. Trung tâm là giao thức 'đầu', cho phép một tập hợp những người tham gia hiệu suất cao và có sẵn cao (như nhóm cổ phần) để xử lý rất nhanh số lượng lớn các giao dịch với các yêu cầu lưu trữ tối thiểu bằng cách Một khái niệm khái quát hóa các kênh thanh toán hai bên như được triển khai trong bối cảnh mạng Lightning. Được bổ sung bởi giao thức 'đuôi', cho phép những người tham gia hiệu suất cao đó cung cấp khả năng mở rộng cho số lượng lớn người dùng cuối có thể sử dụng hệ thống từ các thiết bị công suất thấp, như điện thoại di động và những người có thể ngoại tuyến cho khoảng thời gian. Mặc dù các đầu và đuôi đã có thể giao tiếp thông qua Mainchain Cardano, giao thức giao tiếp bằng đuôi và đuôi cung cấp một biến thể chuỗi hiệu quả của chức năng này. Tất cả điều này được gắn kết với nhau bằng cách định tuyến và quản lý cấu hình, trong khi ảo hóa tạo điều kiện giao tiếp nhanh hơn truyền thông đầu và đuôi.

## **The Hydra head protocol**

## ** Giao thức đầu hydra **

The Hydra head protocol is the first component of the Hydra architecture to be publicly [released](https://eprint.iacr.org/2020/299). It allows a set of participants to create an off-chain state channel (called a head) wherein they can run smart contracts (or process simpler transactions) among each other without interaction with the underlying blockchain in the optimistic case where all head participants adhere to the protocol. The state channel offers very fast settlement and high transaction throughput; furthermore, it requires very little storage, as the off-chain transaction history can be deleted as soon as its resulting state has been secured via an offâ€“chain 'snapshot' operation.

Giao thức đầu hydra là thành phần đầu tiên của kiến trúc hydra được công khai [phát hành] (https://eprint.iacr.org/2020/299).
Nó cho phép một tập hợp người tham gia tạo một kênh trạng thái ngoài chuỗi (được gọi là đầu) trong đó họ có thể chạy các hợp đồng thông minh (hoặc xử lý các giao dịch đơn giản hơn) với nhau mà không cần tương tác với blockchain cơ bản trong trường hợp lạc quan trong đó tất cả những người tham gia đầu đều tuân thủ
giao thức.
Kênh nhà nước cung cấp giải quyết rất nhanh và thông lượng giao dịch cao;
Hơn nữa, nó đòi hỏi rất ít lưu trữ, vì lịch sử giao dịch ngoài chuỗi có thể bị xóa ngay khi trạng thái kết quả của nó được bảo mật thông qua hoạt động 'Chuỗi ảnh' của chuỗi.

Even in the pessimistic case where any number of participants misbehave, full safety is rigorously guaranteed. At any time, any participant can initiate the head's 'closure' with the effect that the head's state is transferred back to the (less efficient) blockchain. We emphasize that the execution of any smart contracts can be seamlessly continued on-chain. No funds can be generated off-chain, nor can any single, responsive head participant lose any funds.

Ngay cả trong trường hợp bi quan trong đó bất kỳ số lượng người tham gia nào bị nhầm lẫn, sự an toàn đầy đủ được đảm bảo nghiêm ngặt.
Bất cứ lúc nào, bất kỳ người tham gia nào cũng có thể bắt đầu 'đóng cửa' của đầu với hiệu ứng trạng thái của đầu được chuyển trở lại blockchain (kém hiệu quả).
Chúng tôi nhấn mạnh rằng việc thực hiện bất kỳ hợp đồng thông minh nào cũng có thể được tiếp tục liên tục trên chuỗi.
Không có tiền nào có thể được tạo ra ngoài chuỗi, cũng không thể có bất kỳ người tham gia đầu đáp ứng đơn nào bị mất bất kỳ khoản tiền nào.

The state channels implemented by Hydra are isomorphic in the sense that they make use of the same transaction format and contract code as the underlying blockchain: contracts can be directly moved back and forth between channels and the blockchain. Thus, state channels effectively yield parallel, off-chain ledger siblings. In other words, the ledger becomes multi-headed.

Các kênh trạng thái được thực hiện bởi Hydra là đẳng cấu theo nghĩa là chúng sử dụng cùng một định dạng giao dịch và mã hợp đồng như blockchain cơ bản: hợp đồng có thể được di chuyển trực tiếp qua lại giữa các kênh và blockchain.
Do đó, các kênh trạng thái mang lại hiệu quả các anh chị em sổ cái ngoài chuỗi song song.
Nói cách khác, sổ cái trở nên nhiều đầu.

Transaction confirmation in the head is achieved in full concurrency by an asynchronous off-chain certification process using multi-signatures. This high level of parallelism is enabled by use of the extended UTxO model ([EUTxO](https://github.com/hydra-supplementary-material/eutxo-spec/blob/master/extended-utxo-specification.pdf)). Transaction dependencies in the EUTxO model are explicit, which allows for state updates without unnecessary sequentialization of transactions that are independent of each other. 

Xác nhận giao dịch trong đầu đạt được sự đồng thời đầy đủ bởi một quy trình chứng nhận ngoài chuỗi không đồng bộ bằng cách sử dụng nhiều tín hiệu.
Mức độ song song cao này được kích hoạt bằng cách sử dụng mô hình UTXO mở rộng ([EUTXO] (https://github.com/hydra-supplityary-material
.
Sự phụ thuộc giao dịch trong mô hình EUTXO là rõ ràng, cho phép cập nhật trạng thái mà không cần giải quyết định tự không cần thiết của các giao dịch độc lập với nhau.

## **Experimental validation of the Hydra head protocol**

## ** Xác thực thử nghiệm giao thức đầu hydra **

As a first step towards experimentally validating the performance of the Hydra head protocol, we implemented a simulation. The simulation is parameterized by the time required by individual actions (validating transactions, verifying signatures, etc.), and carries out a realistic and timing-correct simulation of a cluster of distributed nodes forming a head. This results in realistic transaction confirmation time and throughput calculations.

Là bước đầu tiên hướng tới xác nhận thực nghiệm hiệu suất của giao thức đầu hydra, chúng tôi đã thực hiện một mô phỏng.
Mô phỏng được tham số hóa theo thời gian cần thiết bởi các hành động riêng lẻ (xác thực các giao dịch, xác minh chữ ký, v.v.) và thực hiện mô phỏng thực tế và đúng thời gian của một cụm các nút phân tán tạo thành đầu.
Điều này dẫn đến thời gian xác nhận giao dịch thực tế và tính toán thông lượng.

We see that a single Hydra head achieves up to roughly 1,000 TPS, so by running 1,000 heads in parallel (for example, one for each stake pool of the Shelley release), we should achieve a million TPS. Thatâ€™s impressive and puts us miles ahead of the competition, but why should we stop there? 2,000 heads will give us 2 million TPS â€“ and if someone demands a billion TPS, then we can tell them to just run a million heads. Furthermore, various performance improvements in the implementation can improve the 1,000 TPS single head measurement, further adding to the protocolâ€™s hypothetical performance. 

Chúng tôi thấy rằng một đầu hydra duy nhất đạt được khoảng 1.000 TPS, vì vậy bằng cách chạy song song 1.000 đầu (ví dụ, một cho mỗi nhóm cổ phần của phát hành Shelley), chúng tôi nên đạt được một triệu TPS.
Đó là ấn tượng và đưa chúng ta đi trước cuộc thi, nhưng tại sao chúng ta phải dừng lại ở đó?
2.000 đầu sẽ cho chúng tôi 2 triệu TP - và nếu ai đó yêu cầu một tỷ TPS, thì chúng tôi có thể bảo họ chỉ chạy một triệu đầu.
Hơn nữa, các cải tiến hiệu suất khác nhau trong việc thực hiện có thể cải thiện phép đo đầu đơn 1.000 TPS, thêm vào hiệu suất giả thuyết của giao thức.

So, can we just reach any TPS number that we want? In theory the answer is a solid yes, and that points to a problem with the dominant usage of TPS as a metric to compare systems. While it is tempting to reduce the complexity of assessing protocol performance to a single number, in practice this leads to an oversimplification. Without further context, a TPS number is close to meaningless. In order to properly interpret it, and make comparisons, you should at least ask for the size of the cluster (which influences the communication overhead); its geographic distribution (which determines how much time it takes for information to transit through the system); how the quality of service (transaction confirmation times, providing data to end users) is impacted by a high rate of transactions; how large and complicated the transactions are (which has an impact on transaction validation times, message propagation time, requirements on the local storage system, and composition of the head participants); and what kind of hardware and network connections were used in the experiments. Changing the complexity of transactions alone can change the TPS by a factor of three, as can be seen in the figures in the [paper](https://eprint.iacr.org/2020/299) (refer to Section 7 â€“ Simulations).

Vì vậy, chúng ta có thể đạt được bất kỳ số TPS nào mà chúng ta muốn không? Về lý thuyết, câu trả lời là có chắc chắn, và điều đó chỉ ra một vấn đề với việc sử dụng TPS chiếm ưu thế như một số liệu để so sánh các hệ thống. Mặc dù việc giảm sự phức tạp của việc đánh giá hiệu suất giao thức thành một số duy nhất, nhưng trong thực tế, điều này dẫn đến sự đơn giản hóa. Không có bối cảnh nào nữa, một số TPS gần với vô nghĩa. Để giải thích chính xác nó và so sánh, ít nhất bạn nên yêu cầu kích thước của cụm (ảnh hưởng đến chi phí giao tiếp); Phân phối địa lý của nó (xác định thời gian cần thông tin để vận chuyển qua hệ thống); Làm thế nào chất lượng dịch vụ (thời gian xác nhận giao dịch, cung cấp dữ liệu cho người dùng cuối) bị ảnh hưởng bởi tỷ lệ giao dịch cao; Các giao dịch lớn và phức tạp như thế nào (có tác động đến thời gian xác thực giao dịch, thời gian lan truyền tin nhắn, yêu cầu về hệ thống lưu trữ cục bộ và thành phần của người tham gia trưởng); và loại kết nối phần cứng và mạng nào đã được sử dụng trong các thí nghiệm. Thay đổi độ phức tạp của các giao dịch một mình có thể thay đổi TPS theo hệ số ba, như có thể thấy trong các số liệu trong [giấy] (https://eprint.iacr.org/2020/299) (tham khảo phần 7 - Mô phỏng của người Viking).

Clearly, we need a better standard. Is the Hydra head protocol a good protocol design? What we need to ask is whether it reaches the physical limits of the network, not a mere TPS number. Thus, for this first iteration of the evaluation of the Hydra head protocol, we used the following approach to ensure that the data we provide is properly meaningful: 

Rõ ràng, chúng ta cần một tiêu chuẩn tốt hơn.
Giao thức đầu hydra có phải là một thiết kế giao thức tốt không?
Những gì chúng ta cần hỏi là liệu nó có đạt đến giới hạn vật lý của mạng không, chứ không phải là số TPS đơn thuần.
Do đó, đối với lần lặp đầu tiên này về việc đánh giá giao thức đầu hydra, chúng tôi đã sử dụng phương pháp sau đây để đảm bảo rằng dữ liệu chúng tôi cung cấp có ý nghĩa chính xác:

1. We clearly list all the parameters that influence the simulation: transaction size, time to validate a single transaction, time needed for cryptographic operations, allocated bandwidth per node, cluster size and geographical distribution, and limits on the parallelism in which transactions can be issued. Without this controlled environment, it would be impossible to reproduce our numbers.

1. Chúng tôi liệt kê rõ ràng tất cả các tham số ảnh hưởng đến mô phỏng: kích thước giao dịch, thời gian để xác thực một giao dịch duy nhất, thời gian cần thiết cho các hoạt động mật mã, phân bổ băng thông trên mỗi nút, kích thước cụm và phân phối địa lý và giới hạn về sự song song trong đó các giao dịch có thể là
cấp.
Nếu không có môi trường được kiểm soát này, sẽ không thể tái tạo số của chúng tôi.

1. We compare the protocolâ€™s performance to baselines that provide precise and absolute limits of the underlying network and hardware infrastructure. How well we approach those limits tells us how much room there would be for further improvements. This follows the methodology explained above using the example of an encryption algorithm.

1. Chúng tôi so sánh hiệu suất của giao thức với các đường cơ sở cung cấp các giới hạn chính xác và tuyệt đối của cơ sở hạ tầng mạng và phần cứng cơ bản.
Chúng tôi tiếp cận tốt như thế nào các giới hạn đó cho chúng tôi biết sẽ có bao nhiêu phòng để cải thiện hơn nữa.
Điều này theo phương pháp giải thích ở trên bằng cách sử dụng ví dụ về thuật toán mã hóa.

We use two baselines for Hydra. The first, Full Trust, is universal: it applies to any protocol that distributes transactions amongst nodes and insists that each node validate transactions one after the other â€“ without even ensuring consensus. This yields a limit on TPS by simply adding the message delivery and validation times. How well we approach this limit tells us what price we are paying for consensus, without relying on comparison with other protocols. The second baseline, Hydra Unlimited, yields a TPS limit specifically for the head protocol and also provides the ideal latency and storage for any protocol. We achieve that by assuming that we can send enough transactions in parallel to completely amortize network round-trip times and that all actions can be carried out when needed, without resource contention. The baseline helps us answer the question of what can be achieved under ideal circumstances with the general design of Hydra (for a given set of values of the input parameters) as well as evaluate confirmation latency and storage overhead against any possible protocol. More details and graphs for those interested can be found in our [paper](https://eprint.iacr.org/2020/299) (again, Section 7 â€“ Simulations). 

Chúng tôi sử dụng hai đường cơ sở cho hydra. Sự tin tưởng đầu tiên, đầy đủ, là phổ quát: nó áp dụng cho bất kỳ giao thức nào phân phối các giao dịch giữa các nút và khẳng định rằng mỗi nút xác nhận các giao dịch từng người khác mà không đảm bảo đồng thuận. Điều này mang lại giới hạn cho TPS bằng cách thêm thời gian gửi và xác thực tin nhắn. Chúng tôi tiếp cận giới hạn này tốt như thế nào cho chúng tôi biết giá nào chúng tôi đang trả cho sự đồng thuận, mà không dựa vào so sánh với các giao thức khác. Đường cơ sở thứ hai, Hydra Unlimited, mang lại giới hạn TPS dành riêng cho giao thức đầu và cũng cung cấp độ trễ và lưu trữ lý tưởng cho bất kỳ giao thức nào. Chúng tôi đạt được điều đó bằng cách giả định rằng chúng tôi có thể gửi đủ giao dịch song song để khấu hao hoàn toàn thời gian khứ hồi và tất cả các hành động có thể được thực hiện khi cần thiết, mà không cần tranh chấp tài nguyên. Đường cơ sở giúp chúng tôi trả lời câu hỏi về những gì có thể đạt được trong các trường hợp lý tưởng với thiết kế chung của hydra (cho một tập hợp các giá trị nhất định của các tham số đầu vào) cũng như đánh giá độ trễ xác nhận và chi phí lưu trữ so với bất kỳ giao thức nào có thể. Thông tin chi tiết và đồ thị cho những người quan tâm có thể được tìm thấy trong [giấy] của chúng tôi (https://eprint.iacr.org/2020/299) (một lần nữa, phần 7 mô phỏng).

## **What comes next?**

## **Tiếp theo là gì?**

Solving the scalability question is the holy grail for the whole blockchain space. The time has come to apply a principled, evidence-based approach in designing and engineering blockchain scalability solutions. Comparing scalability proposals against well-defined baselines can be a significant aide in the design of such protocols. It provides solid evidence for the appropriateness of the design choices and ultimately leads to the engineering of effective and performant distributed ledger protocols that will provide the best possible absolute metrics for use cases of interest. While the Hydra head protocol is implemented and tested, we will, in time, release the rest of the Hydra components following the same principled approach. 

Giải quyết câu hỏi về khả năng mở rộng là Chén Thánh cho toàn bộ không gian blockchain.
Đã đến lúc áp dụng một cách tiếp cận nguyên tắc, dựa trên bằng chứng trong việc thiết kế và các giải pháp khả năng mở rộng blockchain kỹ thuật.
So sánh các đề xuất khả năng mở rộng với các đường cơ sở được xác định rõ có thể là một trợ lý quan trọng trong việc thiết kế các giao thức như vậy.
Nó cung cấp bằng chứng vững chắc cho sự phù hợp của các lựa chọn thiết kế và cuối cùng dẫn đến kỹ thuật của các giao thức sổ cái phân tán hiệu quả và hiệu quả sẽ cung cấp các số liệu tuyệt đối tốt nhất có thể cho các trường hợp sử dụng quan tâm.
Trong khi giao thức đầu hydra được thực hiện và thử nghiệm, theo thời gian, chúng tôi sẽ phát hành phần còn lại của các thành phần hydra theo cùng một cách tiếp cận nguyên tắc.

As a last note, Hydra is the joint effort of a number of researchers, whom I'd like to thank. These include Manuel Chakravarty, Sandro Coretti, Matthias Fitzi, Peter GaÅ¾i, Philipp Kant, and Alexander Russel. The research was also supported, in part, by EU Project No.780477, PRIVILEDGE, which we gratefully acknowledge.

Là một lưu ý cuối cùng, Hydra là nỗ lực chung của một số nhà nghiên cứu, người mà tôi muốn cảm ơn.
Chúng bao gồm Manuel Chakravarty, Sandro Coretti, Matthias Fitzi, Peter Gaå¾i, Philipp Kant và Alexander Russel.
Nghiên cứu cũng được hỗ trợ, một phần, bởi Dự án EU số 780477, Priviledge, mà chúng tôi rất biết ơn.

