# Actus smart contracts in Marlowe
### **Writing in the language of finance, rather than the language of blockchain**
![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.002.png) 13 October 2020![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.002.png)[ Prof Simon Thompson](tmp//en/blog/authors/simon-thompson/page-1/)![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.003.png) 12 mins read

![Prof Simon Thompson](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.004.png)[](tmp//en/blog/authors/simon-thompson/page-1/)
### [**Prof Simon Thompson**](tmp//en/blog/authors/simon-thompson/page-1/)
Technical Project Director

Research

- ![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.005.png)[](mailto:simon.thompson@iohk.io "Email")
- ![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.006.png)[](https://github.com/simonjohnthompson "GitHub")

![Actus smart contracts in Marlowe](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.007.jpeg)

*In our Developer Deep Dive series of occasional technical blogs, we invite IOHKâ€™s researchers and engineers to discuss their latest work and insights.*

*Trong loạt các blog kỹ thuật thường xuyên của nhà phát triển Deep Dive, chúng tôi mời các nhà nghiên cứu và kỹ sư của IOHK để thảo luận về công việc và hiểu biết mới nhất của họ.*

Marlowe is a domain-specific language for secure financial smart contracts that is being developed by IOHK for the Goguen capabilities of the Cardano blockchain. Following my [introductory post on Marlowe](https://iohk.io/en/blog/posts/2020/10/06/marlowe-industry-scale-finance-contracts-for-cardano/), in this Deep Dive post, we'll look at the details of the language, and the various ways of writing Marlowe smart contracts as we move into the era of decentralized finance (DeFi). After explaining our approach to oracles, which import â€˜real worldâ€™ information into a running contract, we look at the Algorithmic Contract Types Unified Standard ([Actus](https://www.actusfrf.org/)) for financial contracts, and explain how we have implemented this innovation in Marlowe.

Marlowe là một ngôn ngữ dành riêng cho miền cho các hợp đồng thông minh tài chính an toàn đang được IOHK phát triển cho khả năng Goguen của blockchain Cardano.
Theo dõi [bài viết giới thiệu của tôi trên Marlowe] (https://iohk.io/en/blog/posts/2020/10/06/marlowe-industry-scale-finance-contracts-for-cardano/), trong bài viết sâu rộng này
, chúng ta sẽ xem xét các chi tiết của ngôn ngữ và các cách viết hợp đồng thông minh khác nhau của Marlowe khi chúng ta chuyển sang kỷ nguyên tài chính phi tập trung (DEFI).
Sau khi giải thích cách tiếp cận của chúng tôi đối với các nhà tiên tri, việc nhập thông tin thế giới thực tế vào một hợp đồng đang hoạt động, chúng tôi xem xét các loại hợp đồng thuật toán tiêu chuẩn thống nhất ([Actus] (https://www.actusfrf.org/)) cho tài chính
Hợp đồng, và giải thích cách chúng tôi đã thực hiện sự đổi mới này ở Marlowe.

## **Marlowe in a nutshell**

## ** MARLOWE TUYỆT VỜI **

Marlowe is a small language, with a handful of constructs that, for each contract, describe behavior involving a fixed, finite set of *roles*.

Marlowe là một ngôn ngữ nhỏ, với một số ít các cấu trúc, đối với mỗi hợp đồng, mô tả hành vi liên quan đến một tập hợp hữu hạn, hữu hạn của *vai trò *.

- A running contract can make a *payment* to a role or to a public key.

- Hợp đồng đang chạy có thể thực hiện * thanh toán * cho một vai trò hoặc vào khóa công khai.

- In a complementary way, a contract can *wait* for an *action* by one of the roles, such as a *deposit* of currency, or a *choice* from a set of options. Crucially, a contract cannot wait indefinitely: if no action has been initiated by a given time (the *timeout*), then the contract will continue with another behavior, such as refunding any funds in the contract.

- Theo một cách bổ sung, một hợp đồng có thể * chờ * cho một * hành động * bởi một trong các vai trò, chẳng hạn như * tiền gửi * tiền tệ hoặc * lựa chọn * từ một tập hợp các tùy chọn.
Điều quan trọng, một hợp đồng không thể chờ đợi vô thời hạn: nếu không có hành động nào được bắt đầu bởi một thời gian nhất định (thời gian chờ *), thì hợp đồng sẽ tiếp tục với một hành vi khác, chẳng hạn như hoàn trả bất kỳ khoản tiền nào trong hợp đồng.

- Depending on the current state of a contract, it may *make a choice* between two future courses of action, which are themselves contracts.

- Tùy thuộc vào tình trạng hiện tại của hợp đồng, nó có thể * đưa ra lựa chọn * giữa hai khóa hành động trong tương lai, đó là hợp đồng.

- When no more actions are required, the contract will close, and any remaining currency in the contract will be refunded.

- Khi không cần thêm hành động, hợp đồng sẽ đóng cửa và bất kỳ loại tiền tệ nào còn lại trong hợp đồng sẽ được hoàn trả.

When a contract is run, the *roles* it involves are fulfilled by *participants*, which are identities on the blockchain. This model allows a role to be transferred during contract execution, so that roles in a running contract can be *traded*. Each role is represented by a *token* on the chain, and transferring this transfers the ability to perform the roleâ€™s actions. Taking this further, we can represent a single role with *multiple* tokens, thus allowing the role to be shared: this could be termed being â€˜securitizedâ€™.

Khi một hợp đồng được thực hiện, *vai trò *nó liên quan đến được hoàn thành bởi *người tham gia *, là danh tính trên blockchain.
Mô hình này cho phép chuyển giao một vai trò trong khi thực hiện hợp đồng, do đó, vai trò trong hợp đồng đang chạy có thể được *giao dịch *.
Mỗi vai trò được thể hiện bằng một * mã thông báo * trên chuỗi và chuyển giao này chuyển khả năng thực hiện các hành động của vai trò.
Đưa ra điều này xa hơn, chúng ta có thể đại diện cho một vai trò duy nhất với * nhiều * mã thông báo, do đó cho phép vai trò được chia sẻ: điều này có thể được gọi là - được bảo mật.

## **The Marlowe system**

## ** Hệ thống Marlowe **

We deliberately chose to make the language as simple as we can, so that it is straightforward to implement on Cardano and in the [Marlowe Playground](https://alpha.marlowe.iohkdev.io/#/simulation). Marlowe describes the flow of cryptocurrencies between participants, and for this to be implemented in practice on the Cardano blockchain, code has to be executed both on-chain and off-chain: remember, though, that just one Marlowe contract describes both parts. The on-chain part accepts and validates transactions that conform to the requirements of the smart contract: this part is implemented as a single Plutus script for all Marlowe contracts, with the particular Marlowe contract comprising a datum passed through the transactions. Off-chain, the Marlowe contract will be presented via the user interface and wallet, offering or, indeed, automating deposits and choices and receiving cryptocurrency payments.

Chúng tôi cố tình chọn làm cho ngôn ngữ đơn giản nhất có thể, để thực hiện trên Cardano và trong [Sân chơi Marlowe] (https://alpha.marlowe.iohkdev.io/#/simulation).
Marlowe mô tả dòng tiền điện tử giữa những người tham gia và để điều này được thực hiện trong thực tế trên blockchain Cardano, mã phải được thực thi cả trên chuỗi và ngoài chuỗi: Tuy nhiên, hãy nhớ rằng chỉ một hợp đồng Marlowe mô tả cả hai phần.
Phần trên chuỗi chấp nhận và xác nhận các giao dịch phù hợp với các yêu cầu của hợp đồng thông minh: Phần này được thực hiện dưới dạng một tập lệnh Plutus duy nhất cho tất cả các hợp đồng Marlowe, với hợp đồng Marlowe cụ thể bao gồm một dữ liệu được thông qua các giao dịch.
Off-chuỗi, hợp đồng Marlowe sẽ được trình bày thông qua giao diện người dùng và ví, cung cấp hoặc, thực sự, tự động hóa tiền gửi và lựa chọn và nhận thanh toán tiền điện tử.

![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.008.png)

Figure 1. Marlowe Playground simulates the ways that contracts behave

Hình 1. Sân chơi Marlowe mô phỏng các cách hành xử hợp đồng

In the Playground weâ€™re able to *simulate* contract behavior, so that potential users can walk through different ways that contracts will evolve, according to different actions taken by the participants. In the main simulation, Figure 1, users have an *omniscient point of view* and are able to perform actions by any participant, with the option at each point to undo the actions taken, and then to take a different path. The *wallet* simulation allows users to see behavior from one particular participantâ€™s perspective, thus simulating how that user will interact with the running contract once it is deployed on the blockchain.

Trong sân chơi, chúng tôi có thể * mô phỏng hành vi hợp đồng * để người dùng tiềm năng có thể đi qua các cách khác nhau mà các hợp đồng sẽ phát triển, theo các hành động khác nhau của những người tham gia.
Trong mô phỏng chính, Hình 1, người dùng có quan điểm * toàn tri * và có thể thực hiện các hành động của bất kỳ người tham gia nào, với tùy chọn tại mỗi điểm để hoàn tác các hành động được thực hiện, và sau đó đi một đường dẫn khác.
Mô phỏng * ví * cho phép người dùng thấy hành vi từ góc độ của một người tham gia cụ thể, do đó mô phỏng cách người dùng đó sẽ tương tác với hợp đồng đang chạy sau khi nó được triển khai trên blockchain.

This simplicity also makes it possible for us to model Marlowe contracts in an [SMT solver](https://en.wikipedia.org/wiki/Satisfiability_modulo_theories), a logic system for automatically checking the properties of systems. Using this model, which we call *static analysis*, for each contract we are able to check whether or not it might fail to fulfil a payment, and if the contract can fail we get *evidence* of how it fails, helping the author to rewrite the contract if they wish.

Sự đơn giản này cũng giúp chúng tôi có thể mô hình hóa các hợp đồng Marlowe trong [SMT Solver] (https://en.wikipedia.org/wiki/Satisfability_Modulo_Therories), một hệ thống logic để tự động kiểm tra các thuộc tính của các hệ thống.
Sử dụng mô hình này, mà chúng tôi gọi là *phân tích tĩnh *, đối với mỗi hợp đồng, chúng tôi có thể kiểm tra xem có thể không thực hiện được một khoản thanh toán hay không và nếu hợp đồng có thể thất bại, chúng tôi có nhận được *bằng chứng *về cách thức không thành công, giúp tác giả
để viết lại hợp đồng nếu họ muốn.

We can build a formal model of our implementation in a *proof assistant*, in which we are able to produce machine-checked proofs of how the language behaves. While the SMT solver works for individual contracts, the proof assistant can prove properties of contract templates, as well as the system itself: for instance, we can show that in any running contract, the accounts it references can never be in debit. Simulation, static analysis, and proof provide complementary levels of *assurance* for a contract to which users will be committing assets to ensure that the contract behaves as it should.

Chúng tôi có thể xây dựng một mô hình chính thức về việc triển khai của chúng tôi trong một *Trợ lý bằng chứng *, trong đó chúng tôi có thể đưa ra các bằng chứng được kiểm tra bằng máy về cách thức hoạt động của ngôn ngữ.
Mặc dù SMT Solver hoạt động cho các hợp đồng riêng lẻ, Trợ lý bằng chứng có thể chứng minh các thuộc tính của các mẫu hợp đồng, cũng như chính hệ thống: ví dụ, chúng tôi có thể chỉ ra rằng trong bất kỳ hợp đồng chạy nào, các tài khoản mà nó tham khảo không bao giờ có thể được ghi nợ.
Mô phỏng, phân tích tĩnh và bằng chứng cung cấp các mức độ bổ sung của * đảm bảo * cho hợp đồng mà người dùng sẽ cam kết tài sản để đảm bảo rằng hợp đồng hoạt động như bình thường.

## **Writing Marlowe contracts**

## ** Viết hợp đồng Marlowe **

We have seen how Marlowe contracts can be analysed in various ways, but how do authors actually write smart contracts in Marlowe? The Playground provides several ways of producing Marlowe contracts. Users can write Marlowe directly, but beginners often choose to build contracts visually, using an interactive Blockly editor. Figure 2 shows a section of an escrow contract.

Chúng ta đã thấy làm thế nào các hợp đồng Marlowe có thể được phân tích theo nhiều cách khác nhau, nhưng làm thế nào để các tác giả thực sự viết các hợp đồng thông minh trong Marlowe?
Sân chơi cung cấp một số cách sản xuất hợp đồng Marlowe.
Người dùng có thể viết trực tiếp Marlowe, nhưng người mới bắt đầu thường chọn xây dựng hợp đồng một cách trực quan, sử dụng trình chỉnh sửa khối tương tác.
Hình 2 cho thấy một phần của hợp đồng ký quỹ.

![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.009.png)

Figure 2. An escrow contract in Playgroundâ€™s interactive Blockly editor

Hình 2. Hợp đồng ký quỹ trong trình chỉnh sửa khối tương tác của sân chơi

Working in this visual editor has the advantage of showing all the options as you select how to fill in a part of the contract that is being developed. Alternatively, you can develop contracts in Haskell, because the Marlowe DSL is in fact *embedded* in Haskell. Figure 3 shows the same contract in Haskell: the blue and purple parts are Marlowe, and the black components are defined in Haskell, as abbreviations that make the overall contract more readable. This approach allows users to build up a smart contract step by step from components. In the code shown in Figure 3, the roles, Alice and Bob, are each asked to make a choice: if their choices match, they agree, and the contract proceeds one way; if not, then a third participant, Carol, is asked to arbitrate between them. The contracts *agreement* and *arbitrate* are defined later in the Haskell file.

Làm việc trong trình soạn thảo trực quan này có lợi thế là hiển thị tất cả các tùy chọn khi bạn chọn cách điền vào một phần của hợp đồng đang được phát triển.
Ngoài ra, bạn có thể phát triển các hợp đồng trong Haskell, bởi vì DSL Marlowe trên thực tế * nhúng * trong Haskell.
Hình 3 cho thấy cùng một hợp đồng trong Haskell: các bộ phận màu xanh và tím là Marlowe, và các thành phần màu đen được định nghĩa trong Haskell, vì chữ viết tắt làm cho hợp đồng tổng thể dễ đọc hơn.
Cách tiếp cận này cho phép người dùng xây dựng một hợp đồng thông minh từng bước từ các thành phần.
Trong mã được hiển thị trong Hình 3, các vai trò, Alice và Bob, mỗi người được yêu cầu đưa ra lựa chọn: nếu lựa chọn của họ phù hợp, họ đồng ý và hợp đồng tiến hành một chiều;
Nếu không, thì một người tham gia thứ ba, Carol, được yêu cầu phân xử giữa họ.
Hợp đồng * Thỏa thuận * và * Trọng tài * được xác định sau trong tệp Haskell.

![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.010.png)

Figure 3. The escrow contract in Haskell

Hình 3. Hợp đồng ký quỹ trong Haskell

Users will also be able to write their financial smart contracts using JavaScript, while still enjoying all the advantages of analysis, simulation, and proof, as provided by the Marlowe implementation.

Người dùng cũng sẽ có thể viết hợp đồng thông minh tài chính của họ bằng JavaScript, trong khi vẫn tận hưởng tất cả các lợi thế của phân tích, mô phỏng và bằng chứng, theo quy định của việc triển khai Marlowe.

## **Oracles**

## ** oracles **

One of the first questions we get asked when we describe Marlowe is about financial oracles, or how we can get a contract to take account of external data values, such as the exchange rate between ada and bitcoin. Abstractly, an oracle is just like a participant that makes a choice, and so the semantics of Marlowe can already deal with external values. However, we plan to support oracle values as part of the implementation, allowing contracts to access values directly from a stock market ticker or a data feed such as Coinbase. At the same time, the Plutus team is researching the best way to deal with oracles in general, and we can expect support for that in due course, though maybe not in the first full release of Marlowe and the Plutus Application Framework.

Một trong những câu hỏi đầu tiên chúng tôi nhận được khi chúng tôi mô tả Marlowe là về các nhà tiên tri tài chính hoặc làm thế nào chúng tôi có thể có được hợp đồng để tính đến các giá trị dữ liệu bên ngoài, chẳng hạn như tỷ giá hối đoái giữa ADA và Bitcoin.
Tóm tắt, một nhà tiên tri giống như một người tham gia đưa ra lựa chọn, và do đó, ngữ nghĩa của Marlowe đã có thể đối phó với các giá trị bên ngoài.
Tuy nhiên, chúng tôi có kế hoạch hỗ trợ các giá trị Oracle như là một phần của việc triển khai, cho phép các hợp đồng truy cập các giá trị trực tiếp từ một khoản tích tắc thị trường chứng khoán hoặc nguồn cấp dữ liệu như Coinbase.
Đồng thời, nhóm Plutus đang nghiên cứu cách tốt nhất để đối phó với các nhà tiên tri nói chung và chúng tôi có thể mong đợi sự hỗ trợ cho điều đó trong khóa học do, mặc dù có thể không phát hành đầy đủ đầu tiên của Marlowe và khung ứng dụng Plutus.

## **Actus for financial contracts**

## ** Actus cho hợp đồng tài chính **

Marlowe has the potential to give people the chance to make financial commitments and trades without a third party facilitating it: the blockchain ensures that the contract is followed.

Marlowe có khả năng cung cấp cho mọi người cơ hội thực hiện các cam kết và giao dịch tài chính mà không có bên thứ ba tạo điều kiện cho nó: Blockchain đảm bảo rằng hợp đồng được tuân thủ.

We are building a Marlowe implementation of disintermediated contracts to offer to end users who want to make peer-to-peer financial deals directly without the intervention of any third parties.

Chúng tôi đang xây dựng việc thực hiện Marlowe các hợp đồng không được điều hòa để cung cấp cho người dùng cuối muốn thực hiện các giao dịch tài chính ngang hàng trực tiếp mà không cần sự can thiệp của bất kỳ bên thứ ba nào.

The Actus Financial Research Foundation categorizes financial contracts by means of a [taxonomy](https://www.actusfrf.org/taxonomy) that is described in a detailed [technical specification](https://www.actusfrf.org/techspecs).

Tổ chức nghiên cứu tài chính Actus phân loại các hợp đồng tài chính bằng phương tiện [phân loại] (https://www.actusfrf.org/taxonomy) được mô tả trong một chi tiết [đặc điểm kỹ thuật] (https://www.actusfrf.org/techspecs
).

Actus builds on the understanding that financial contracts are legal agreements between two (or more) counterparties on the exchange of future cash flows. Historically, such legal agreements are described in natural language, leading to ambiguity and artificial diversity. As a response, Actus defines contracts by means of a set of contractual terms and deterministic functions mapping these terms to future payment obligations. Thereby, it is possible to describe most financial instruments through 31 contract types or modular templates.

Actus xây dựng dựa trên sự hiểu biết rằng các hợp đồng tài chính là các thỏa thuận pháp lý giữa hai (hoặc nhiều) đối tác trên việc trao đổi dòng tiền trong tương lai.
Trong lịch sử, các thỏa thuận pháp lý như vậy được mô tả bằng ngôn ngữ tự nhiên, dẫn đến sự mơ hồ và đa dạng nhân tạo.
Như một phản hồi, Actus định nghĩa các hợp đồng bằng một tập hợp các điều khoản hợp đồng và các chức năng xác định ánh xạ các điều khoản này theo nghĩa vụ thanh toán trong tương lai.
Do đó, có thể mô tả hầu hết các công cụ tài chính thông qua 31 loại hợp đồng hoặc mẫu mô -đun.

Next, we look at a simple example, and then we explain our full approach to implementing Actus, with complementary approaches providing different pros and cons.

Tiếp theo, chúng tôi xem xét một ví dụ đơn giản, và sau đó chúng tôi giải thích cách tiếp cận đầy đủ của chúng tôi để thực hiện Actus, với các phương pháp bổ sung cung cấp các ưu và nhược điểm khác nhau.

## **A first Actus example**

## ** Một ví dụ Actus đầu tiên **

A zero-coupon bond is a debt security that does not pay interest (a coupon) but is issued at a discount, rendering profit at maturity when the bond is redeemed for its full face value.

Trái phiếu không có đồng phạm là một bảo đảm nợ không trả lãi (phiếu giảm giá) nhưng được phát hành với giá giảm, mang lại lợi nhuận khi đáo hạn khi trái phiếu được đổi cho giá trị toàn diện.

For example, Figure 4 describes a contract whereby an investor can buy a bond that costs 1,000 lovelaces with 15% discount. She pays 850 lovelaces to the bond issuer before the start time, here slot 10.

Ví dụ, Hình 4 mô tả một hợp đồng, theo đó một nhà đầu tư có thể mua một trái phiếu có giá 1.000 người yêu thích với giảm giá 15%.
Cô trả 850 lovelaces cho nhà phát hành trái phiếu trước thời gian bắt đầu, ở đây Slot 10.

Later, after maturity date, slot 20 here, the investor can exchange the bond for its full notional value, ie, 1,000 lovelaces.

Sau đó, sau ngày đáo hạn, vị trí 20 ở đây, nhà đầu tư có thể trao đổi trái phiếu với giá trị đầy đủ về giá trị của nó, tức là 1.000 người yêu thích.

![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.011.png)

Figure 4. Contract for a zero-coupon bond with a 15% discount

Hình 4. Hợp đồng cho trái phiếu không có đồng gia đình với giảm giá 15%

This contract has a significant drawback. Once the investor has deposited the 850 lovelaces, it will be immediately paid to the issuer; if the investor does not invest quickly enough, ie before the timeout, the contract ends. After that, two outcomes are possible:

Hợp đồng này có một nhược điểm đáng kể.
Khi nhà đầu tư đã gửi 850 người yêu thích, nó sẽ được trả ngay lập tức cho nhà phát hành;
Nếu nhà đầu tư không đầu tư đủ nhanh, tức là trước thời gian chờ, hợp đồng kết thúc.
Sau đó, hai kết quả là có thể:

- the issuer deposits 1,000 lovelaces in the investor's account, and that sum is immediately paid to the investor in full;

- Nhà phát hành gửi 1.000 người yêu thích trong tài khoản của nhà đầu tư và số tiền đó ngay lập tức được trả cho nhà đầu tư đầy đủ;

- if the investor doesnâ€™t make the deposit, then the contract is closed and all the money in the contract is refunded, but there is no money in the contract at this point, so the investor loses her money.

- Nếu nhà đầu tư không thực hiện tiền gửi, thì hợp đồng đã đóng cửa và tất cả tiền trong hợp đồng được hoàn trả, nhưng không có tiền trong hợp đồng vào thời điểm này, vì vậy nhà đầu tư mất tiền.

How can we avoid this problem of the bond issuer defaulting? There are at least two ways to solve this: we could ask the issuer to deposit the full amount before the contract begins, but that would defeat the object of issuing the bond in the first place. More realistically, we could ask a third party to be a guarantor of the deal, as expressed here.

Làm thế nào chúng ta có thể tránh vấn đề này của nhà phát hành trái phiếu mặc định?
Có ít nhất hai cách để giải quyết vấn đề này: Chúng tôi có thể yêu cầu nhà phát hành gửi toàn bộ số tiền trước khi hợp đồng bắt đầu, nhưng điều đó sẽ đánh bại đối tượng phát hành trái phiếu ngay từ đầu.
Thực tế hơn, chúng tôi có thể yêu cầu một bên thứ ba là người bảo đảm thỏa thuận, như được thể hiện ở đây.

![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.012.png)

Figure 5. Improved contract with a guarantor

Hình 5. Hợp đồng được cải thiện với người bảo lãnh

## **Actus in Marlowe**

## ** Actus trong Marlowe **

Products in the Actus taxonomy, such as the principal at maturity contract, can be presented in different ways in Marlowe, according to the degree to which they can accept changes to their terms during the contract lifetime (Figure 6).

Các sản phẩm trong phân loại ACTUS, chẳng hạn như Hợp đồng Hợp đồng trưởng thành, có thể được trình bày theo những cách khác nhau trong Marlowe, theo mức độ mà họ có thể chấp nhận các thay đổi đối với các điều khoản của họ trong suốt thời gian hợp đồng (Hình 6).

![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.013.jpeg)

Figure 6. Actus taxonomy and Marlowe

Hình 6. Phân loại Actus và Marlowe

In the simplest case, all cash flows are set, or *frozen*, at contract initiation, so that it is entirely predictable how the contract will operate, assuming that all participants continue to engage with the contract during its lifetime. Contracts of this kind we call Actus-F (for fixed or frozen).

Trong trường hợp đơn giản nhất, tất cả các dòng tiền được đặt, hoặc *đóng băng *, khi bắt đầu hợp đồng, do đó hoàn toàn có thể dự đoán được hợp đồng sẽ hoạt động như thế nào, cho rằng tất cả những người tham gia tiếp tục tham gia vào hợp đồng trong suốt cuộc đời.
Hợp đồng thuộc loại này, chúng tôi gọi là Actus-F (đối với cố định hoặc đóng băng).

Dynamism â€“ that is change during contract evolution â€“ can happen in two ways. Participants can make *unscheduled payments* that require re-calculation of the remaining cash flows, and also the cash flows can be modified by taking into account *external risk factors*. The full generality of contracts that do both are modelled in Actus-M (for Marlowe).

Động lực - Đó là sự thay đổi trong quá trình tiến hóa hợp đồng - có thể xảy ra theo hai cách.
Người tham gia có thể thực hiện *thanh toán đột xuất *yêu cầu tính toán lại các dòng tiền còn lại và các dòng tiền cũng có thể được sửa đổi bằng cách tính đến *các yếu tố rủi ro bên ngoài *.
Toàn bộ tổng hợp các hợp đồng làm cả hai đều được mô hình hóa trong Actus-M (đối với Marlowe).

There are intermediate levels too: Actus-FS models fixed schedules: allowing risk factors to be taken into account, but with no unexpected payments; conversely, Actus-FR contracts allow payments to be made at unexpected points, but do not take into account any risk factors.

Cũng có các cấp trung gian: các mô hình Actus-FS cố định lịch trình: cho phép các yếu tố rủi ro được tính đến, nhưng không có khoản thanh toán bất ngờ;
Ngược lại, các hợp đồng ACTUS-FR cho phép thanh toán tại các điểm không mong muốn, nhưng không tính đến bất kỳ yếu tố rủi ro nào.

Finally, moving outside Marlowe, Actus-H (H for Haskell) models the contracts directly as programs in Plutus or Haskell, using Marlowe for validation of each transaction in the contract lifetime by generating Plutus code from the Marlowe description of the contract logic.

Cuối cùng, di chuyển bên ngoài Marlowe, Actus-H (H cho Haskell) mô hình trực tiếp các hợp đồng dưới dạng các chương trình trong Plutus hoặc Haskell, sử dụng Marlowe để xác nhận từng giao dịch trong thời gian sử dụng hợp đồng bằng cách tạo mã Plutus từ mô tả Marlowe về logic hợp đồng.

Why do we offer these different models of Actus contracts? The reason is that there is a *trade-off* between the dynamic nature of contracts and the *assurance* we can give to users about how the contracts will perform in advance of contract execution.

Tại sao chúng tôi cung cấp các mô hình khác nhau của các hợp đồng Actus?
Lý do là có một * đánh đổi * giữa bản chất năng động của các hợp đồng và * đảm bảo * chúng ta có thể cung cấp cho người dùng về cách các hợp đồng sẽ thực hiện trước khi thực hiện hợp đồng.

- Actus-F contracts present an entirely fixed schedule of payments, which can be scrutinized directly by the participants so that it is straightforward to see, for example, that all payments from such a contract will succeed.

- Hợp đồng Actus-F trình bày một lịch trình thanh toán hoàn toàn cố định, có thể được xem xét trực tiếp bởi những người tham gia để thấy đơn giản để xem, ví dụ, tất cả các khoản thanh toán từ hợp đồng đó sẽ thành công.

- Actus-FS and -FR contracts present more dynamism, but the contracts are readable and easy to scrutinize. Moreover, they are subject to (slower) static analysis to establish, for example, that all payments will succeed.

-Hợp đồng Actus -FS và -FR thể hiện sự năng động hơn, nhưng các hợp đồng có thể đọc được và dễ xem xét kỹ lưỡng.
Hơn nữa, chúng phải chịu phân tích tĩnh (chậm hơn) để thiết lập, ví dụ, tất cả các khoản thanh toán sẽ thành công.

- Actus-M contracts are expressed in Marlowe, and so can be analysed. Analysis is, however, substantially slower because of the unpredictability of the actions that the contract will undergo at any particular point in time. Note that assurance can be offered for scaled-down versions of contracts, which have the same computational content, but which evolve over a shorter time, thus involving fewer interactions.

- Hợp đồng Actus-M được thể hiện bằng Marlowe, và do đó có thể được phân tích.
Tuy nhiên, phân tích chậm hơn đáng kể vì sự không thể đoán trước của các hành động mà hợp đồng sẽ trải qua tại bất kỳ thời điểm cụ thể nào.
Lưu ý rằng sự đảm bảo có thể được cung cấp cho các phiên bản thu nhỏ của các hợp đồng, có cùng nội dung tính toán, nhưng phát triển trong một thời gian ngắn hơn, do đó liên quan đến ít tương tác hơn.

- Actus-H contracts are written in a combination of Plutus and Marlowe, and so are not amenable to static checking in the same way as the others. However, this platform offers corporate clients full extensibility and tailoring of the implementation of the Actus standard.

- Hợp đồng Actus-H được viết kết hợp giữa Sao Diêm Vương và Marlowe, và do đó không thể kiểm tra tĩnh theo cách tương tự như những người khác.
Tuy nhiên, nền tảng này cung cấp cho khách hàng doanh nghiệp mở rộng đầy đủ và điều chỉnh việc thực hiện tiêu chuẩn ACTUS.

In our implementation of Actus, available as a pre-release version in the [Labs tab of the Playground](https://alpha.marlowe.iohkdev.io/#/actus), users are able to *generate* Actus-F and -FS contracts from the terms of the contract, using a visual presentation of the data required.

Trong việc thực hiện Actus của chúng tôi, có sẵn như là phiên bản trước khi phát hành trong [tab Labs của sân chơi] (https://alpha.marlowe.iohkdev.io/#/actus), người dùng có thể * tạo * Actus-F
và -FS hợp đồng từ các điều khoản của hợp đồng, sử dụng trình bày trực quan về dữ liệu cần thiết.

![](img/2020-10-13-actus-financial-smart-contracts-in-marlowe.014.png)

Figure 7. The three items with asterisks are required for a principal at maturity contract

Hình 7. Ba mục có dấu hoa thị là cần thiết cho hiệu trưởng khi đáo hạn hợp đồng

For a principal at maturity contract, three items are required: the start and end date, and the notional amount of the contract (hence the items being starred in the template). Such a contract will comprise a simple load, in which the notional amount is transferred from the counterparty to the party at the start of the contract, and in the reverse direction at the maturity date.

Đối với một hiệu trưởng khi hợp đồng đáo hạn, ba mục được yêu cầu: ngày bắt đầu và ngày kết thúc và số tiền đáng chú ý của hợp đồng (do đó các mục được đặt sao trong mẫu).
Một hợp đồng như vậy sẽ bao gồm một tải đơn giản, trong đó số tiền đáng chú ý được chuyển từ đối tác sang bên khi bắt đầu hợp đồng và theo hướng ngược lại vào ngày đáo hạn.

Adding additional items will change the generated contract accordingly. In Figure 7, the party will have to transfer the notional plus the premium to the counterparty at maturity date, hence giving the counterparty an incentive to make the loan in the first place.

Thêm các mục bổ sung sẽ thay đổi hợp đồng được tạo cho phù hợp.
Trong Hình 7, bên sẽ phải chuyển nhượng đáng chú ý cộng với phí bảo hiểm cho đối tác vào ngày đáo hạn, do đó mang lại cho đối tác một động lực để thực hiện khoản vay ngay từ đầu.

## **Moving into a DeFi world with smart contracts**

## ** Chuyển sang một thế giới Defi với các hợp đồng thông minh **

As we have seen, finance professionals and developers now have a way to start creating financial smart contracts directly in Haskell or pure Marlowe, or visually, using the [Marlowe Playground](https://alpha.marlowe.iohkdev.io/#/simulation), depending on their programming expertise. In the Playground, you can simulate and analyse the contracts you create to test that they work properly and are ready to be issued into the world of decentralized finance when the Goguen stage of Cardano is implemented. IOHKâ€™s Marlowe team will continue implementing examples from the Actus standard, as we prepare to finalize the implementation of Marlowe on Cardano, and bring financial smart contracts to the blockchain itself.

Như chúng ta đã thấy, các chuyên gia và nhà phát triển tài chính hiện có cách bắt đầu tạo ra các hợp đồng thông minh tài chính trực tiếp trong Haskell hoặc Pure Marlowe, hoặc trực quan, sử dụng [Sân chơi Marlowe] (https://alpha.marlowe.iohkdev.io/#/
Mô phỏng), tùy thuộc vào chuyên môn lập trình của họ.
Trong sân chơi, bạn có thể mô phỏng và phân tích các hợp đồng bạn tạo để kiểm tra rằng chúng hoạt động đúng và sẵn sàng phát hành vào thế giới tài chính phi tập trung khi giai đoạn Goguen của Cardano được thực hiện.
Nhóm Marlowe của IOHK sẽ tiếp tục thực hiện các ví dụ từ tiêu chuẩn ACTUS, khi chúng tôi chuẩn bị hoàn thiện việc thực hiện Marlowe trên Cardano và đưa các hợp đồng thông minh tài chính cho chính Blockchain.

