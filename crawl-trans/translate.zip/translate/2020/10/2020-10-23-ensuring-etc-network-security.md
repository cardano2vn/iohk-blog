# Ensuring ETC Network Security
### **Ensuring ETC network security - a comparison of 51% Attack Resistance proposals for Ethereum Classic**
![](img/2020-10-23-ensuring-etc-network-security.002.png) 23 October 2020![](img/2020-10-23-ensuring-etc-network-security.002.png)[ Brian McKenna](tmp//en/blog/authors/brian-mckenna/page-1/)![](img/2020-10-23-ensuring-etc-network-security.003.png) 4 mins read

![Brian McKenna](img/2020-10-23-ensuring-etc-network-security.004.png)[](tmp//en/blog/authors/brian-mckenna/page-1/)
### [**Brian McKenna**](tmp//en/blog/authors/brian-mckenna/page-1/)
Product Manager

Operations

- ![](img/2020-10-23-ensuring-etc-network-security.005.png)[](https://www.linkedin.com/in/brian-mckenna-a284341a/ "LinkedIn")
- ![](img/2020-10-23-ensuring-etc-network-security.006.png)[](https://twitter.com/BrianMc36431138 "Twitter")
- ![](img/2020-10-23-ensuring-etc-network-security.007.png)[](https://github.com/brian-mckenna "GitHub")

![Ensuring ETC Network Security](img/2020-10-23-ensuring-etc-network-security.008.jpeg)

The Ethereum Classic network suffered from four 51% attacks between 2019 and 2020. Three of those attacks have occurred recently â€“ with just weeks between each other â€“ which resulted in expensive losses for stakeholders due to double spending and service disruption. A number of Ethereum Classic Improvement Proposals (ECIPs) followed after these attacks aiming to provide the immediate solution for 51% attack resistance.

Mạng lưới cổ điển Ethereum đã phải chịu bốn cuộc tấn công 51% từ năm 2019 đến 2020. Ba trong số các cuộc tấn công đó đã xảy ra gần đây - chỉ với vài tuần giữa nhau, điều này dẫn đến tổn thất đắt tiền cho các bên liên quan do chi tiêu gấp đôi và gián đoạn dịch vụ.
Một số đề xuất cải tiến Ethereum Classic (ECIP) theo sau sau khi các cuộc tấn công này nhằm cung cấp giải pháp ngay lập tức cho khả năng chống tấn công 51%.

IOHK, andÂ [ETC Coop](https://etccooperative.org/)Â have collaborated to provide Ethereum Classic stakeholders and the broader community with the knowledge and understanding on how to resist these issues. To support this activity, we have created aÂ [comparison document](https://static.iohk.io/docs/etc/ecip-comparison-for-51-attack-resistance.pdf)Â to showcase and summarize the different 51% attack mitigations. In it, ETC community members will be able to assess each proposal, understand any concerns, and be advised on how the ETC community can solve ETC network security issues together.

IOHK, vàâ [Coop] (https://etccoopy.org/) Â đã hợp tác để cung cấp cho các bên liên quan cổ điển Ethereum và cộng đồng rộng lớn hơn về kiến thức và sự hiểu biết về cách chống lại những vấn đề này.
Để hỗ trợ hoạt động này, chúng tôi đã tạo Aâ [Tài liệu so sánh] (https://static.iohk.io/docs/etc/ecip-comparison-for-51-attack-resistance.pdf) để giới thiệu và tóm tắt 51 khác nhau
% giảm thiểu tấn công.
Trong đó, vv Các thành viên cộng đồng sẽ có thể đánh giá từng đề xuất, hiểu bất kỳ mối quan tâm nào và được thông báo về cách cộng đồng ETC có thể giải quyết các vấn đề bảo mật mạng vv cùng nhau.

The ECIP that seems to be reaching adoption in the immediate term is ECIP 1100: Modified Exponential Subjective Scoring ([MESS](https://ecips.ethereumclassic.org/ECIPs/ecip-1100)). MESS is a modified version of Vitalik Buterinâ€™s Exponential Subjective Scoring (ESS) and aims to make larger chain reorganizations more difficult. However, we believe that it will not provide robust security and there is no guarantee that it will prevent further attacks. Whatâ€™s most concerning, however, about MESS, is that it has not been formally studied nor has its security been proven. Moreover, a series of potential attack vectors on MESS have already been identified.

ECIP dường như đang đạt được việc áp dụng trong thời hạn trước mắt là ECIP 1100: Điểm số chủ quan theo cấp số nhân được sửa đổi ([Mess] (https://ecips.ethereumClassic.org/ecips/ecip-1100)).
Mess là phiên bản sửa đổi của điểm số chủ quan theo cấp số nhân (ESS) của Vitalik và nhằm mục đích làm cho việc tái tổ chức chuỗi lớn hơn trở nên khó khăn hơn.
Tuy nhiên, chúng tôi tin rằng nó sẽ không cung cấp bảo mật mạnh mẽ và không có gì đảm bảo rằng nó sẽ ngăn chặn các cuộc tấn công tiếp theo.
Tuy nhiên, điều liên quan đến nhiều nhất về Mess, là nó chưa được nghiên cứu chính thức và bảo mật của nó cũng không được chứng minh.
Hơn nữa, một loạt các vectơ tấn công tiềm năng trên Mess đã được xác định.

## **Checkpointing is the way forward**

## ** CheckPoining là con đường phía trước **

[Checkpointing](https://ecips.ethereumclassic.org/ECIPs/ecip-1097), on the other hand, can make 51% attacks impossible with deterministic confidence of finality. This approach grants the ETC core developer community a safe space to innovate and implement the more speculative proposals that are underway. These may include MESS, Reducing the dag, Keccak-256, and many others. Considering that ETC value and user experience is currently hindered by the low-confidence and subjective finality of MESS, MESS doesnâ€™t provide high confidence for stakeholders to reduce confirmation times to desirable levels.

[CheckPoining] (https://ecips.ethereumClassic.org/ecips/ecip-1097), mặt khác, có thể khiến 51% tấn công không thể với sự tự tin xác định về tính hữu hạn.
Cách tiếp cận này cho phép cộng đồng nhà phát triển cốt lõi ETC một không gian an toàn để đổi mới và thực hiện các đề xuất đầu cơ hơn đang được tiến hành.
Chúng có thể bao gồm lộn xộn, giảm DAG, KECCAK-256 và nhiều người khác.
Xem xét rằng giá trị ETC và trải nghiệm người dùng hiện đang bị cản trở bởi sự tự tin thấp và tính hữu hạn chủ quan của Mess, Mess không mang lại sự tự tin cao cho các bên liên quan để giảm thời gian xác nhận xuống mức mong muốn.

The Ethereum Classic network is a minority proof of work blockchain in the Ethash environment. As of October 08, 2020, the Ethereumâ€™s network hashrate is ~248.16 TH/s, Nicehashâ€™s hashrate is ~9.34 TH/s, while Ethereum Classicâ€™s network hashrate is only ~3.47 TH/s . This means that Ethereum Classicâ€™s hashrate is only ~1.5% of Ethereumâ€™s and ~40% of Nicehashâ€™s, which is just one of many other mining rental platforms. It should be noted though, that non-Ethash networks that are minable by general purpose hardware can also be turned on to Ethereum Classic, which means that the Ethereum Classic network is even more of a minority proof of work blockchain than represented by the Ethereum and Nicehash comparisons above.

Mạng cổ điển Ethereum là một bằng chứng thiểu số về blockchain công việc trong môi trường Ethash.
Kể từ ngày 08 tháng 10 năm 2020, mạng HashRate mạng của Ethereum là ~ 248,16, Hashrate của NiceHash là ~ 9,34 th/s, trong khi mạng HashRate mạng của Ethereum Classic chỉ là ~ 3,47.
Điều này có nghĩa là Hashrate của Ethereum Classic chỉ là ~ 1,5% của Ethereum và ~ 40% của NiceHash, chỉ là một trong nhiều nền tảng cho thuê khai thác khác.
Tuy nhiên, cần lưu ý rằng các mạng không phải là Ethash có thể thu hút được bởi phần cứng mục đích chung cũng có thể được bật thành Ethereum Classic, điều đó có nghĩa là Mạng cổ điển Ethereum thậm chí còn là một bằng chứng thiểu số về blockchain công việc hơn là được đại diện bởi Ethereum và
So sánh NICEHASH ở trên.

It thus follows that the current security assumptions of the Ethereum Classic network no longer hold. Speculating ETCâ€™s network security on ETHâ€™s proof of stake timeline is also not a sustainable security strategy and arguably not competitive enough to increase the value of the network.

Do đó, theo sau rằng các giả định bảo mật hiện tại của mạng cổ điển Ethereum không còn nắm giữ nữa.
Việc đầu cơ bảo mật mạng của ETC trên Dòng thời gian chứng minh của ETHER cũng không phải là một chiến lược bảo mật bền vững và được cho là không đủ khả năng cạnh tranh để tăng giá trị của mạng.

## **Looking to the future**

## **Nhìn về tương lai**

Indeed, it goes further than that. ETC is at an important crossroads and the choices we make now will impact not only the future of the platform but of the whole ecosystem. Any 51% attack mitigation must be robust enough to give absolute certainty to ETC holders, users and service providers that their transactions will be secure.

Thật vậy, nó đi xa hơn thế.
ETC đang ở một ngã tư quan trọng và các lựa chọn mà chúng tôi đưa ra bây giờ sẽ tác động không chỉ về tương lai của nền tảng mà cả toàn bộ hệ sinh thái.
Bất kỳ giảm thiểu tấn công 51% nào cũng đủ mạnh để cung cấp sự chắc chắn tuyệt đối cho chủ sở hữu, người dùng và nhà cung cấp dịch vụ mà các giao dịch của họ sẽ được bảo mật.

We need to be decisive and resolute, while giving ourselves the time to get this right. If we adopt a suboptimal solution at this point, and there are further issues with the network, it is unlikely that our (thus far) patient stakeholders â€“ especially exchanges â€“ will remain so.

Chúng ta cần phải quyết đoán và kiên quyết, trong khi cho mình thời gian để có được điều này.
Nếu chúng tôi áp dụng một giải pháp tối ưu vào thời điểm này và có những vấn đề khác với mạng, thì không có khả năng các bên liên quan của bệnh nhân (cho đến nay) của chúng tôi - đặc biệt là trao đổi - sẽ vẫn như vậy.

Our focus at the moment is rightly on mitigation. But letâ€™s also ensure we remember the longer-term goal â€“ the health and sustainable success of Ethereum Classic. Letâ€™s move decisively to underpin the security of the network, and together look forward towards a new era of network growth, community growth and sustainable innovation.

Trọng tâm của chúng tôi tại thời điểm này là đúng về giảm thiểu.
Nhưng chúng ta cũng đảm bảo chúng ta nhớ mục tiêu dài hạn-thành công về sức khỏe và bền vững của Ethereum Classic.
Hãy di chuyển một cách quyết đoán để củng cố sự an toàn của mạng, và cùng nhau hướng tới một kỷ nguyên mới của tăng trưởng mạng, tăng trưởng cộng đồng và đổi mới bền vững.

*This post was originally published on the [ETC Cooperative blog*](https://etccooperative.org/posts/2020-10-20-ensuring-etc-network-security)*

*Bài đăng này ban đầu được xuất bản trên blog Hợp tác xã [vv*] (https://etccooperative.org/posts/2020-10-20

