# Marlowe: industry-scale financial smart contracts for the blockchain
### **Move over Solidity – this specialized language will bring decentralized finance to Cardano**
![](img/2020-10-06-marlowe-industry-scale-finance-contracts-for-cardano.002.png) 6 October 2020![](img/2020-10-06-marlowe-industry-scale-finance-contracts-for-cardano.002.png)[ Prof Simon Thompson](tmp//en/blog/authors/simon-thompson/page-1/)![](img/2020-10-06-marlowe-industry-scale-finance-contracts-for-cardano.003.png) 5 mins read

![Prof Simon Thompson](img/2020-10-06-marlowe-industry-scale-finance-contracts-for-cardano.004.png)[](tmp//en/blog/authors/simon-thompson/page-1/)
### [**Prof Simon Thompson**](tmp//en/blog/authors/simon-thompson/page-1/)
Technical Project Director

Research

- ![](img/2020-10-06-marlowe-industry-scale-finance-contracts-for-cardano.005.png)[](mailto:simon.thompson@iohk.io "Email")
- ![](img/2020-10-06-marlowe-industry-scale-finance-contracts-for-cardano.006.png)[](https://github.com/simonjohnthompson "GitHub")

![Marlowe: industry-scale financial smart contracts for the blockchain](img/2020-10-06-marlowe-industry-scale-finance-contracts-for-cardano.007.jpeg)

In this post, we introduce Marlowe, a new language for financial contracts, and describe the benefits of it being a domain-specific language (DSL). As a DSL it describes only *financial* contracts, rather than smart contracts in general. Because of this, it differs from general-purpose blockchain languages like Solidity and Bitcoin Script.

Trong bài đăng này, chúng tôi giới thiệu Marlowe, một ngôn ngữ mới cho các hợp đồng tài chính và mô tả lợi ích của nó là ngôn ngữ cụ thể về miền (DSL).
Là một DSL, nó chỉ mô tả các hợp đồng * tài chính *, thay vì hợp đồng thông minh nói chung.
Bởi vì điều này, nó khác với các ngôn ngữ blockchain có mục đích chung như solity và script bitcoin.

Marlowe is industry-scale. We have built Marlowe contracts based on examples from one of the leading projects for financial smart contracts, the Algorithmic Contract Types Unified Standards ([Actus](https://www.actusfrf.org/)) system. Currently, these and other examples can be seen in the [Marlowe Playground](https://alpha.marlowe.iohkdev.io), a browser-based environment in which users can create, edit, simulate, and analyse Marlowe contracts, without having to install or pay for anything.

Marlowe là quy mô công nghiệp.
Chúng tôi đã xây dựng các hợp đồng Marlowe dựa trên các ví dụ từ một trong những dự án hàng đầu cho các hợp đồng thông minh tài chính, các loại hợp đồng thuật toán tiêu chuẩn thống nhất ([Actus] (https://www.actusfrf.org/)).
Hiện tại, những ví dụ này và các ví dụ khác có thể được nhìn thấy trong [Sân chơi Marlowe] (https://alpha.marlowe.iohkdev.io), một môi trường dựa trên trình duyệt trong đó người dùng có thể tạo, chỉnh sửa, mô phỏng và phân tích hợp đồng Marlowe, mà không
phải cài đặt hoặc trả tiền cho bất cứ điều gì.

Who can use Marlowe? Marlowe is a platform for decentralized finance (DeFi) that supports direct, peer-to-peer lending, contracts for difference (CFD), and other similar instruments. Financial institutions can use it to develop and deploy custom instruments for their customers and clients, for example.

Ai có thể sử dụng Marlowe?
Marlowe là một nền tảng cho tài chính phi tập trung (DEFI) hỗ trợ cho vay trực tiếp, ngang hàng, hợp đồng cho sự khác biệt (CFD) và các công cụ tương tự khác.
Các tổ chức tài chính có thể sử dụng nó để phát triển và triển khai các công cụ tùy chỉnh cho khách hàng và khách hàng của họ, ví dụ.

As a part of the Goguen rollout, we will be completing the implementation of Marlowe on Cardano, giving users and organisations the opportunity to execute DeFi contracts they have written themselves or downloaded from a contract repository, transferring cryptoassets according to the contract terms. Marlowe will run first of all on the Cardano blockchain, but it is not tied to Cardano, and could run on other blockchains in the future.

Là một phần của buổi giới thiệu Goguen, chúng tôi sẽ hoàn thành việc thực hiện Marlowe trên Cardano, cho người dùng và tổ chức cơ hội thực hiện các hợp đồng DEFI mà họ đã tự viết hoặc tải xuống từ kho lưu trữ hợp đồng, chuyển tiền điện tử theo các điều khoản hợp đồng.
Marlowe sẽ chạy trước hết trên blockchain Cardano, nhưng nó không được gắn với Cardano và có thể chạy trên các blockchain khác trong tương lai.

Smart contracts running on Cardano will be able to access external data values, such as the exchange rate between ada and bitcoin, through *oracles*. In some ways, an oracle is just like a participant that makes a choice, and we plan to support oracle values as part of the implementation, allowing contracts to access values directly from a stock market ‘ticker’ or a popular data feed such as Coinbase.

Hợp đồng thông minh chạy trên Cardano sẽ có thể truy cập các giá trị dữ liệu bên ngoài, chẳng hạn như tỷ giá hối đoái giữa ADA và Bitcoin, thông qua *oracles *.
Theo một cách nào đó, một nhà tiên tri giống như một người tham gia đưa ra lựa chọn và chúng tôi dự định hỗ trợ các giá trị Oracle như một phần của việc thực hiện, cho phép các hợp đồng truy cập các giá trị trực tiếp từ thị trường chứng khoán 'Ticker' hoặc nguồn cấp dữ liệu phổ biến như Coinbase
.

Marlowe contracts can be used in many ways: for instance, a Marlowe program can automate the operation of a financial contract that transacts cryptocurrencies on a blockchain. Alternatively, for audit purposes, it could be used to record compliance of users’ actions to a contract being executed in the real world.

Hợp đồng Marlowe có thể được sử dụng theo nhiều cách: ví dụ, chương trình Marlowe có thể tự động hóa hoạt động của hợp đồng tài chính giao dịch tiền điện tử trên blockchain.
Ngoài ra, đối với mục đích kiểm toán, nó có thể được sử dụng để ghi lại việc tuân thủ các hành động của người dùng vào một hợp đồng được thực hiện trong thế giới thực.

Marlowe is just one example of a DSL running on a blockchain, but it is also an exemplar of how other DSLs might be created to cover supply-chain management, insurance, accounting, and so on, leveraging the experience of designing and building Marlowe on the Cardano platform.

Marlowe chỉ là một ví dụ về DSL chạy trên blockchain, nhưng nó cũng là một ví dụ về cách các DSL khác có thể được tạo ra để trang trải quản lý chuỗi cung ứng, bảo hiểm, v.v.
Nền tảng Cardano.

We have stressed that Marlowe is a special-purpose financial DSL, but what if you want to write other kinds of contract? To write those, Cardano has [Plutus, *a general purpose language*](https://www.youtube.com/watch?v=usMPt8KpBeI&vl=en) running on the blockchain. Plutus contracts can handle all kinds of cryptoassets, and don’t have the constraints of Marlowe contracts: for example, they are unconstrained in how long they will remain active, and in how many participants they can involve. Indeed, every Marlowe contract is run by a single Plutus program, the Marlowe interpreter.

Chúng tôi đã nhấn mạnh rằng Marlowe là một DSL tài chính có mục đích đặc biệt, nhưng nếu bạn muốn viết các loại hợp đồng khác thì sao?
Để viết chúng, Cardano có [Plutus, *một ngôn ngữ mục đích chung *] (https://www.youtube.com/watch?v=USMPT8KPBEI&vl=en) chạy trên blockchain.
Hợp đồng Plutus có thể xử lý tất cả các loại tiền điện tử và don lồng có những hạn chế của hợp đồng Marlowe: ví dụ, họ không bị ràng buộc trong việc họ sẽ hoạt động trong bao lâu và họ có thể tham gia bao nhiêu người tham gia.
Thật vậy, mọi hợp đồng Marlowe đều được điều hành bởi một chương trình Plutus duy nhất, người phiên dịch Marlowe.

## **Marlowe as a domain-specific language for DeFi**

## ** Marlowe là ngôn ngữ dành riêng cho miền cho defi **

Being domain-specific, rather than general purpose, has a number of advantages.

Là tên miền cụ thể, thay vì mục đích chung, có một số lợi thế.

Contracts are written in the language of finance, rather than the language of the blockchain. This means that some sorts of errors are impossible to write: so certain kinds of incorrect contracts are ruled out completely. For example, every Marlowe contract will have a finite lifetime after which it will perform no further actions, and at that point any funds tied up in the contract will be returned to the participants, meaning that funds in a contract can never be locked up indefinitely.

Hợp đồng được viết bằng ngôn ngữ tài chính, thay vì ngôn ngữ của blockchain.
Điều này có nghĩa là một số loại lỗi là không thể viết: vì vậy một số loại hợp đồng không chính xác được loại trừ hoàn toàn.
Ví dụ, mọi hợp đồng Marlowe sẽ có một thời gian hữu hạn sau đó nó sẽ không thực hiện thêm hành động nào nữa, và tại thời điểm đó, bất kỳ khoản tiền nào bị ràng buộc trong hợp đồng sẽ được trả lại cho những người tham gia, có nghĩa là các khoản tiền trong hợp đồng không bao giờ có thể bị khóa vô thời hạn
.

It is possible to analyse, completely automatically, how a contract will behave in all circumstances, without having to run it. For example, it is possible to determine whether a particular contract can fail to make a payment in some cases, or whether it is guaranteed to make full payments in every eventuality.

Có thể phân tích, hoàn toàn tự động, làm thế nào một hợp đồng sẽ hành xử trong mọi trường hợp, mà không cần phải chạy nó.
Ví dụ, có thể xác định liệu một hợp đồng cụ thể có thể không thực hiện thanh toán trong một số trường hợp hay không, liệu nó có được đảm bảo để thực hiện thanh toán đầy đủ trong mọi tình huống hay không.

Contract behaviour can be simulated in a browser, so that users can try out the different ways that a contract might behave, before committing funds and running it for real.

Hành vi hợp đồng có thể được mô phỏng trong trình duyệt, để người dùng có thể thử các cách khác nhau mà hợp đồng có thể hoạt động, trước khi cam kết và chạy nó thật.

Users can create their DeFi contracts in different ways: they can write them as text, but also use visual programming to create smart contracts by fitting together blocks that represent the different components. Users can also choose from a range of templates and customise them as needed.

Người dùng có thể tạo hợp đồng DEFI của họ theo những cách khác nhau: họ có thể viết chúng dưới dạng văn bản, nhưng cũng sử dụng lập trình trực quan để tạo hợp đồng thông minh bằng cách khớp các khối cùng nhau đại diện cho các thành phần khác nhau.
Người dùng cũng có thể chọn từ một loạt các mẫu và tùy chỉnh chúng khi cần thiết.

## **Next steps – and some prize challenges**

## ** Các bước tiếp theo - và một số thử thách giải thưởng **

Currently, Marlowe contracts can be written in Haskell or JavaScript or directly in Marlowe, and visually, using the Marlowe Playground, where it is also possible to simulate and analyse those contracts. Over the next few months we will continue revising and improving the user experience provided by the Playground, and continue implementing examples from the Actus project. At the same time, we will finalise the implementation of Marlowe on Cardano, so that Marlowe contracts will run on the blockchain itself. We look forward to sharing that work with you as soon as it is ready. 

Hiện tại, các hợp đồng của Marlowe có thể được viết bằng Haskell hoặc JavaScript hoặc trực tiếp trong Marlowe và trực quan, sử dụng sân chơi Marlowe, nơi cũng có thể mô phỏng và phân tích các hợp đồng đó.
Trong vài tháng tới, chúng tôi sẽ tiếp tục sửa đổi và cải thiện trải nghiệm người dùng do sân chơi cung cấp và tiếp tục thực hiện các ví dụ từ dự án Actus.
Đồng thời, chúng tôi sẽ hoàn thiện việc thực hiện Marlowe trên Cardano, để các hợp đồng của Marlowe sẽ chạy trên chính blockchain.
Chúng tôi mong muốn được chia sẻ công việc đó với bạn ngay khi nó đã sẵn sàng.

In the meantime, take a look at [Marlowe Playground](https://alpha.marlowe.iohkdev.io) or join in one of the two Marlowe-based challenges running this month – there’s a $10,000 cryptocurrency fund to [tackle the United Nations’ global development goals](https://iohk.io/en/blog/posts/2020/10/06/united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals/), and a [$5,000-prize Actus](https://wyohackathon.io/wyohackathon.html) event at the Wyoming Hackathon.

Trong khi đó, hãy xem [Sân chơi Marlowe] (https://alpha.marlowe.iohkdev.io) hoặc tham gia vào một trong hai thử thách dựa trên Marlowe trong tháng này-có một quỹ tiền điện tử trị giá 10.000 đô la để [giải quyết United United
Mục tiêu phát triển toàn cầu của các quốc gia] (https://iohk.io/en/blog/posts/2020/10/06/unites-sations-and-iohk-join-forces-to-use-blockchain-for-development-goals
.

