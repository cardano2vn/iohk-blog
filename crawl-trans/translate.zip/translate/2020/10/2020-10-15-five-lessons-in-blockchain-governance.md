# Five lessons in blockchain governance
### **Project Catalyst is bringing collective innovation to Cardano.**
![](img/2020-10-15-five-lessons-in-blockchain-governance.002.png) 15 October 2020![](img/2020-10-15-five-lessons-in-blockchain-governance.002.png)[ Dor Garbash](tmp//en/blog/authors/dor-garbash/page-1/)![](img/2020-10-15-five-lessons-in-blockchain-governance.003.png) 6 mins read

![Dor Garbash](img/2020-10-15-five-lessons-in-blockchain-governance.004.png)[](tmp//en/blog/authors/dor-garbash/page-1/)
### [**Dor Garbash**](tmp//en/blog/authors/dor-garbash/page-1/)
Head of Product

Commercial

- ![](img/2020-10-15-five-lessons-in-blockchain-governance.005.png)[](https://linkedin.com/in/garbash "LinkedIn")
- ![](img/2020-10-15-five-lessons-in-blockchain-governance.006.png)[](https://twitter.com/garbash "Twitter")
- ![](img/2020-10-15-five-lessons-in-blockchain-governance.007.png)[](https://github.com/Garbash "GitHub")

![Five lessons in blockchain governance](img/2020-10-15-five-lessons-in-blockchain-governance.008.jpeg)

Project Catalyst is, at its heart, a series of experiments in innovation and governance. Once it was decided to set up a funded system to encourage innovation for Cardano, the IOHK team decided to collaborate with our global community from the start. So, thatâ€™s what we did. Now, with two funds already incubating hundreds of proposals and fostering thousands of conversations, we wanted to share some of the things that weâ€™ve learned.

Project Catalyst, tại trung tâm của nó, là một loạt các thí nghiệm về đổi mới và quản trị.
Khi đã quyết định thành lập một hệ thống được tài trợ để khuyến khích sự đổi mới cho Cardano, nhóm IOHK đã quyết định hợp tác với cộng đồng toàn cầu của chúng tôi ngay từ đầu.
Vì vậy, đó là những gì chúng tôi đã làm.
Bây giờ, với hai khoản tiền đã ươm tạo hàng trăm đề xuất và thúc đẩy hàng ngàn cuộc trò chuyện, chúng tôi muốn chia sẻ một số điều mà chúng tôi đã học được.

1. **Our diversity is our strength**

1. ** Sự đa dạng của chúng tôi là sức mạnh của chúng tôi **

We knew that the Cardano community was crucial to realizing the full potential of Project Catalyst. But we did not fully realize the depth of the expertise available, nor its truly global reach. When we called for ideas for the project, people responded. To date, Project Catalyst has drawn 3000 registered users, 500 perspectives, 126 proposals and +5,000 comments from 70 countries around the globe. Building courses in Haskell engineering, boosting decentralized technology in West Africa, podcasts and blockchain applications in many fields are among the ideas pitched on our Ideascale innovation platform. Furthermore, each one of these has been refined by the Project Catalyst community. 

Chúng tôi biết rằng cộng đồng Cardano là rất quan trọng để nhận ra tiềm năng đầy đủ của chất xúc tác dự án.
Nhưng chúng tôi đã không hoàn toàn nhận ra chiều sâu của chuyên môn có sẵn, cũng như phạm vi toàn cầu thực sự của nó.
Khi chúng tôi kêu gọi ý tưởng cho dự án, mọi người đã trả lời.
Đến nay, Project Catalyst đã thu hút 3000 người dùng đã đăng ký, 500 quan điểm, 126 đề xuất và +5.000 bình luận từ 70 quốc gia trên toàn cầu.
Xây dựng các khóa học về Kỹ thuật Haskell, thúc đẩy công nghệ phi tập trung ở Tây Phi, podcast và các ứng dụng blockchain trong nhiều lĩnh vực là một trong những ý tưởng được đưa ra trên nền tảng đổi mới ý tưởng của chúng tôi.
Hơn nữa, mỗi một trong số này đã được cộng đồng Catalyst dự án tinh chỉnh.

With such a worldwide community of entrepreneurs, experts, and specialists, we are able to tap into a previously unknown well of ingenuity. Furthermore, the community itself is responsible for ensuring that the brightest ideas rise to the top. 

Với một cộng đồng doanh nhân, chuyên gia và chuyên gia trên toàn thế giới như vậy, chúng tôi có thể khai thác vào một sự khéo léo chưa được biết đến trước đây.
Hơn nữa, bản thân cộng đồng chịu trách nhiệm đảm bảo rằng những ý tưởng sáng nhất tăng lên hàng đầu.

2. **Community interest is self-interest**

2. ** Lợi ích cộng đồng là lợi ích cá nhân **

Proposals in Fund2 are vying for a share of an ada fund worth $250,000. This is an enormous incentive for individuals to make their pitch as strong as possible. However, we are working hard to ensure that there is an equal incentive for people to help develop the ideas of others, instead of focusing on just their own proposal. When a strong idea comes to fruition, it will inevitably benefit Cardano, and therefore every ada holder. Ultimately, we have learned that we need to provide a variety of motivations and experiences for the community to foster the most productive dialogue.

Các đề xuất trong Fund2 đang cạnh tranh cho một phần của một quỹ ADA trị giá 250.000 đô la.
Đây là một động lực khổng lồ cho các cá nhân để làm cho sân của họ mạnh nhất có thể.
Tuy nhiên, chúng tôi đang làm việc chăm chỉ để đảm bảo rằng có một động lực bình đẳng cho mọi người để giúp phát triển ý tưởng của người khác, thay vì chỉ tập trung vào đề xuất của riêng họ.
Khi một ý tưởng mạnh mẽ đi đến kết quả, chắc chắn nó sẽ mang lại lợi ích cho Cardano, và do đó mọi chủ sở hữu ADA.
Cuối cùng, chúng tôi đã học được rằng chúng tôi cần cung cấp nhiều động lực và kinh nghiệm cho cộng đồng để thúc đẩy cuộc đối thoại năng suất nhất.

Currently, Project Catalyst participants can give a limited number of â€˜kudosâ€™ or positive affirmations to people providing value to the Fund through their comments and proposals. This is meant to build communal support. We are also establishing a cohort of community advisers. These are registered participants who have no active proposals but want to provide thoughtful and fair advice to voters. The first of these community advisers are now joining up and we are looking forward to seeing how they will benefit the project. 

Hiện tại, những người tham gia Project Catalyst có thể cung cấp một số lượng hạn chế - Kudosâ € ™ hoặc khẳng định tích cực cho những người cung cấp giá trị cho quỹ thông qua các bình luận và đề xuất của họ.
Điều này có nghĩa là để xây dựng hỗ trợ chung.
Chúng tôi cũng đang thành lập một nhóm các cố vấn cộng đồng.
Đây là những người tham gia đã đăng ký không có đề xuất tích cực nhưng muốn cung cấp lời khuyên chu đáo và công bằng cho cử tri.
Người đầu tiên trong số các cố vấn cộng đồng này hiện đang tham gia và chúng tôi mong muốn được xem họ sẽ có lợi cho dự án như thế nào.

3. **Innovation requires a positive mindset**

3. ** Đổi mới đòi hỏi một tư duy tích cực **

Despite its many benefits, the digital world can be a toxic place. From YouTube scams and keyboard warriors, to Twitter trolls and spam emails, there sometimes seems no end to the pitfalls in online engagement. Project Catalyst is learning to minimize this activity if not eliminate it entirely. One way that we are working on this is by leveraging the experience of our Fund1 participants. These early pioneers are helping encourage mutual respect and collaboration, which we hope will proliferate through the entire system. However, we understand that is a tough goal for any global platform.

Mặc dù có nhiều lợi ích, thế giới kỹ thuật số có thể là một nơi độc hại.
Từ các trò lừa đảo của YouTube và các chiến binh bàn phím, đến những kẻ troll Twitter và email spam, đôi khi dường như không có kết thúc cho những cạm bẫy trong sự tham gia trực tuyến.
Project Catalyst là học cách giảm thiểu hoạt động này nếu không loại bỏ nó hoàn toàn.
Một cách mà chúng tôi đang làm việc này là bằng cách tận dụng kinh nghiệm của những người tham gia Fund1.
Những người tiên phong ban đầu này đang giúp khuyến khích sự tôn trọng và hợp tác lẫn nhau, mà chúng tôi hy vọng sẽ sinh sôi nảy nở trong toàn bộ hệ thống.
Tuy nhiên, chúng tôi hiểu rằng đó là một mục tiêu khó khăn cho bất kỳ nền tảng toàn cầu nào.

That being said, we have an automated reminder to encourage people to keep their thoughts focused on how feasible an idea is, how its effect can be measured and audited, and its potential impact on Cardano. We want to attract the most talented entrepreneurs, and so the more constructive the feedback, the nearer we come to fulfilling our strategic objective. Furthermore, the Catalyst team has published a guide for community behavior and feedback. If and when we detect abusive activity, we reserve the right to warn or ban the miscreants. Toxicity can damage the project and even Cardano as a whole, so our interventions will develop as the community grows. We remain focused on creating a forum for passionate discussions without constraining creativity.

Điều đó đang được nói, chúng tôi có một lời nhắc tự động để khuyến khích mọi người giữ suy nghĩ của họ tập trung vào một ý tưởng khả thi như thế nào, hiệu ứng của nó có thể được đo lường và kiểm toán như thế nào, và tác động tiềm năng của nó đối với Cardano.
Chúng tôi muốn thu hút các doanh nhân tài năng nhất, và vì vậy phản hồi mang tính xây dựng, chúng tôi càng đến gần để hoàn thành mục tiêu chiến lược của mình.
Hơn nữa, nhóm Catalyst đã xuất bản một hướng dẫn cho hành vi và phản hồi của cộng đồng.
Nếu và khi chúng ta phát hiện hoạt động lạm dụng, chúng ta có quyền cảnh báo hoặc cấm các hành vi sai trái.
Độc tính có thể làm hỏng dự án và thậm chí cả Cardano, vì vậy các can thiệp của chúng tôi sẽ phát triển khi cộng đồng phát triển.
Chúng tôi vẫn tập trung vào việc tạo ra một diễn đàn cho các cuộc thảo luận đam mê mà không hạn chế sự sáng tạo.

![](img/2020-10-15-five-lessons-in-blockchain-governance.009.png)

4. **Break down barriers to creativity**

4. ** Phá vỡ các rào cản đối với sự sáng tạo **

Thus far, we have been pleased with the progress Project Catalyst has made on the Ideascale innovation platform. It provides an easy-to-use interface for developing complex ideas. But no system is perfect. Some community members have found the interface overwhelming. For us to find and develop groundbreaking ideas, our working methods must always work to enhance creativity.

Cho đến nay, chúng tôi đã hài lòng với Progress Project Catalyst đã thực hiện trên nền tảng đổi mới ý tưởng.
Nó cung cấp một giao diện dễ sử dụng để phát triển các ý tưởng phức tạp.
Nhưng không có hệ thống là hoàn hảo.
Một số thành viên cộng đồng đã tìm thấy giao diện áp đảo.
Để chúng tôi tìm và phát triển các ý tưởng đột phá, các phương pháp làm việc của chúng tôi phải luôn hoạt động để tăng cường sự sáng tạo.

Currently, we are listening to community feedback through the Catalyst problem sensing challenge and feedback forms. This helps us hear what works and what needs iterating and improving. Ultimately, the proposals chosen and funded by Project Catalyst are only as good as their ability to be embraced and championed by the community. And great collaboration tools are vital for this.

Hiện tại, chúng tôi đang lắng nghe phản hồi của cộng đồng thông qua các hình thức cảm nhận và phản hồi vấn đề chất xúc tác.
Điều này giúp chúng tôi nghe những gì hoạt động và những gì cần lặp lại và cải thiện.
Cuối cùng, các đề xuất được lựa chọn và tài trợ bởi Project Catalyst chỉ tốt như khả năng của họ được cộng đồng chấp nhận và vô địch.
Và các công cụ cộng tác tuyệt vời là rất quan trọng cho việc này.

5. **Focus on the returns**

5. ** Tập trung vào lợi nhuận **

Every challenge within the program represents an intention to generate outcomes from the fund. We are now working on ways to measure the effect of these intentions and how they contribute to a challenge being met. These measures include measuring how many developers, entrepreneurs, businesses, and Dapps were developed as an outcome of every proposal. Ultimately, that which is measured can be managed.

Mọi thách thức trong chương trình đều thể hiện ý định tạo ra kết quả từ quỹ.
Chúng tôi hiện đang làm việc trên các cách để đo lường hiệu quả của các ý định này và cách chúng đóng góp cho một thách thức được đáp ứng.
Những biện pháp này bao gồm đo lường số lượng nhà phát triển, doanh nhân, doanh nghiệp và DAPP được phát triển như là kết quả của mọi đề xuất.
Cuối cùng, được đo lường có thể được quản lý.

For example, the current Fund2 challenge is:

Ví dụ: Thử thách Fund2 hiện tại là:

â€œ*How can we encourage developers and entrepreneurs to build DApps and businesses on top of Cardano in the next 6 months?*â€

â € œ*Làm thế nào chúng ta có thể khuyến khích các nhà phát triển và doanh nhân xây dựng DAPP và doanh nghiệp trên đỉnh Cardano trong 6 tháng tới?*"

This challenge is fairly open-ended, and deliberately so. These wide-ranging challenges are designed to encourage a broad spectrum of ideas. But not too broad, so we can still measure and track them effectively.

Thử thách này là khá mở, và cố tình như vậy.
Những thách thức trên phạm vi rộng này được thiết kế để khuyến khích một loạt các ý tưởng.
Nhưng không quá rộng, vì vậy chúng tôi vẫn có thể đo lường và theo dõi chúng một cách hiệu quả.

### **Applying the lessons**

### ** Áp dụng các bài học **

Weâ€™re building a system which will eventually be run, developed, and funded entirely by the community itself. In time, IOHK will only be involved with the daily operations of Cardano at the request of the community itself. However, until we are able to hand over total control to ada holders, we must maintain constant communication.

Chúng tôi xây dựng một hệ thống cuối cùng sẽ được điều hành, phát triển và tài trợ hoàn toàn bởi chính cộng đồng.
Trong thời gian, IOHK sẽ chỉ tham gia vào các hoạt động hàng ngày của Cardano theo yêu cầu của chính cộng đồng.
Tuy nhiên, cho đến khi chúng tôi có thể trao toàn bộ quyền kiểm soát cho chủ sở hữu ADA, chúng tôi phải duy trì giao tiếp liên tục.

Throughout the Project Catalyst program, we have worked to ensure that communication is a two-way street. We are redoubling these efforts by ensuring that we seek out feedback at every stage. We also ensure that community assessments will be performed at the conclusion of each fund. These interventions allow us to prioritize solving issues that are important to the community.

Trong suốt chương trình Project Catalyst, chúng tôi đã làm việc để đảm bảo rằng giao tiếp là một con đường hai chiều.
Chúng tôi đang tăng gấp đôi những nỗ lực này bằng cách đảm bảo rằng chúng tôi tìm kiếm phản hồi ở mọi giai đoạn.
Chúng tôi cũng đảm bảo rằng các đánh giá cộng đồng sẽ được thực hiện khi kết thúc từng quỹ.
Những can thiệp này cho phép chúng tôi ưu tiên giải quyết các vấn đề quan trọng đối với cộng đồng.

Project Catalyst has been an incredible journey. These are only five of the takeaways from our current process. As the experiment continues grows, we are looking forward to learning more, attracting more participants, and building a best-in-class governance system. This is only the beginning. 

Project Catalyst là một hành trình đáng kinh ngạc.
Đây chỉ là năm trong số các điểm từ quá trình hiện tại của chúng tôi.
Khi thí nghiệm tiếp tục phát triển, chúng tôi mong muốn tìm hiểu thêm, thu hút nhiều người tham gia hơn và xây dựng một hệ thống quản trị tốt nhất trong lớp.
Đây mới chỉ là sự bắt đầu.

*Get involved with Project Catalyst by logging on at Ideascale or joining our next [Crowdcast town hall](https://www.crowdcast.io/e/project-catalyst-weekly-3) on October 21.*

*Tham gia vào Project Catalyst bằng cách đăng nhập tại IdeasCale hoặc tham gia [Tòa thị chính Crowcast] tiếp theo của chúng tôi (https://www.crowdcast.io/e/project-catalyst-weekly-3) vào ngày 21 tháng 10.*

