# Bringing new value and utility to the Cardano blockchain
### **Adding metadata to transactions prepares Cardano to become part of the DeFi revolution**
![](img/2020-10-29-bringing-new-value-and-utility-to-the-cardano-blockchain.002.png) 29 October 2020![](img/2020-10-29-bringing-new-value-and-utility-to-the-cardano-blockchain.002.png)[ Alan McSherry](tmp//en/blog/authors/alan-mcsherry/page-1/)![](img/2020-10-29-bringing-new-value-and-utility-to-the-cardano-blockchain.003.png) 5 mins read

![Alan McSherry](img/2020-10-29-bringing-new-value-and-utility-to-the-cardano-blockchain.004.png)[](tmp//en/blog/authors/alan-mcsherry/page-1/)
### [**Alan McSherry**](tmp//en/blog/authors/alan-mcsherry/page-1/)
Solutions Architect

Engineering

- ![](img/2020-10-29-bringing-new-value-and-utility-to-the-cardano-blockchain.005.png)[](https://www.linkedin.com/in/alanmcsherry/ "LinkedIn")
- ![](img/2020-10-29-bringing-new-value-and-utility-to-the-cardano-blockchain.006.png)[](https://github.com/mcsherrylabs "GitHub")

![Bringing new value and utility to the Cardano blockchain](img/2020-10-29-bringing-new-value-and-utility-to-the-cardano-blockchain.007.jpeg)

With the rollout of Goguen, Cardano is becoming a smart contract platform. Adding metadata â€“ information about the data being processed â€“ to transactions is key to this, and last month this capability was added to the blockchain. From a focus on transactions, Cardano is now becoming a utility platform open for partnerships, enterprises, and commercial applications that can be used for the complex operations that will define the era of decentralized finance (DeFi).

Với sự triển khai của Goguen, Cardano đang trở thành một nền tảng hợp đồng thông minh.
Thêm siêu dữ liệu - Thông tin về dữ liệu được xử lý - vào các giao dịch là chìa khóa cho điều này và tháng trước, khả năng này đã được thêm vào blockchain.
Từ việc tập trung vào các giao dịch, Cardano hiện đang trở thành một nền tảng tiện ích mở cho quan hệ đối tác, doanh nghiệp và các ứng dụng thương mại có thể được sử dụng cho các hoạt động phức tạp sẽ xác định kỷ nguyên tài chính phi tập trung (DEFI).

With an increasing volume of financial cryptocurrency operations, the ability to access immutable data that cannot be altered is crucial, especially when it comes to applications such as wealth management. The Cardano blockchain maintains permanent records of processed transactions, ensuring that the history of financial activity is transparent and auditable. However, to grant more accountability and visibility to financial processes, context has to be added to these transactions. Additional information can include facts such as sender and receiver details, conditions, and time of processing. This is done by adding transaction metadata.

Với khối lượng hoạt động tiền điện tử tài chính ngày càng tăng, khả năng truy cập dữ liệu bất biến không thể thay đổi là rất quan trọng, đặc biệt là khi nói đến các ứng dụng như quản lý tài sản.
Blockchain Cardano duy trì hồ sơ vĩnh viễn về các giao dịch được xử lý, đảm bảo rằng lịch sử hoạt động tài chính là minh bạch và có thể kiểm toán.
Tuy nhiên, để cấp nhiều trách nhiệm và tầm nhìn cho các quy trình tài chính, bối cảnh phải được thêm vào các giao dịch này.
Thông tin bổ sung có thể bao gồm các sự kiện như người gửi và chi tiết người nhận, điều kiện và thời gian xử lý.
Điều này được thực hiện bằng cách thêm siêu dữ liệu giao dịch.

## **What is metadata?**

## ** Siêu dữ liệu là gì? **

Metadata refers to â€˜data about dataâ€™. In other words, it describes the context, content, and structure of records. As blockchain technology provides a transparent ledger for storing records immutably and securely, metadata generates trust with permanent data attestation.

Siêu dữ liệu đề cập đến â € ˜data về dữ liệu.
Nói cách khác, nó mô tả bối cảnh, nội dung và cấu trúc của hồ sơ.
Vì công nghệ blockchain cung cấp một sổ cái minh bạch để lưu trữ các hồ sơ một cách bất biến và an toàn, siêu dữ liệu tạo ra niềm tin với chứng thực dữ liệu vĩnh viễn.

All transactions happen for specific purposes, whether this is a payment for product or service, or a funds transfer to a family member. When a purchase is made online, for example, there is so much information that can follow along with the transaction. Metadata can tell the story of the product purchase reflecting its buyer and seller, the time of deal, product manufacturer, or the supply conditions. All of these records are important to maintain along with the transaction of wealth. 

Tất cả các giao dịch xảy ra cho các mục đích cụ thể, cho dù đây là khoản thanh toán cho sản phẩm hoặc dịch vụ hoặc chuyển tiền cho thành viên gia đình.
Ví dụ, khi mua hàng trực tuyến, có rất nhiều thông tin có thể theo dõi cùng với giao dịch.
Siêu dữ liệu có thể kể câu chuyện về việc mua sản phẩm phản ánh người mua và người bán của nó, thời gian giao dịch, nhà sản xuất sản phẩm hoặc điều kiện cung cấp.
Tất cả các hồ sơ này rất quan trọng để duy trì cùng với giao dịch của cải.

With the emergence of Bitcoin, developers started leveraging blockchain technology to put such little bits of additional data on the chain, knowing that the information would be available forever. Over time, adding metadata to the chain became commonplace.

Với sự xuất hiện của Bitcoin, các nhà phát triển đã bắt đầu tận dụng công nghệ blockchain để đặt các chút dữ liệu bổ sung như vậy vào chuỗi, biết rằng thông tin sẽ có sẵn mãi mãi.
Theo thời gian, việc thêm siêu dữ liệu vào chuỗi trở nên phổ biến.

Cardano is a third-generation distributed ledger. In terms of metadata, this means that Cardano is far more efficient in adding transactional information than earlier blockchains. While earlier blockchains supported 40-80 bytes of metadata, Cardanoâ€™s transaction size is currently around 16KB. Subtracting the size of the rest of the transaction (UTxOs, inputs, and outputs) still leaves the majority of 16KB for metadata.

Cardano là một sổ cái phân tán thế hệ thứ ba.
Về mặt siêu dữ liệu, điều này có nghĩa là Cardano hiệu quả hơn nhiều trong việc thêm thông tin giao dịch so với các blockchain trước đó.
Trong khi các blockchain trước đó hỗ trợ 40-80 byte siêu dữ liệu, quy mô giao dịch của Cardano hiện là khoảng 16kb.
Trừ quy mô của phần còn lại của giao dịch (UTXOS, đầu vào và đầu ra) vẫn để lại phần lớn 16kB cho siêu dữ liệu.

## **Why transaction metadata matters**

## ** Tại sao siêu dữ liệu giao dịch lại quan trọng **

Metadata is a handy way of certification and validation. It allows cryptocurrency assets to hold historical ownership, transfer or value details. This is highly beneficial when working with non-fungible â€“ unique â€“ assets representing value such as property or intellectual rights, for example. Additionally, a range of documents can be signed and certified using a public key that proves the documentâ€™s legitimacy. 

Siêu dữ liệu là một cách tiện dụng để chứng nhận và xác nhận.
Nó cho phép các tài sản tiền điện tử nắm giữ quyền sở hữu, chuyển nhượng hoặc chi tiết giá trị lịch sử.
Điều này rất có lợi khi làm việc với các tài sản độc đáo-tài sản độc đáo của họ đại diện cho giá trị như quyền tài sản hoặc quyền trí tuệ, chẳng hạn.
Ngoài ra, một loạt các tài liệu có thể được ký và chứng nhận bằng khóa công khai để chứng minh tính hợp pháp của tài liệu.

One of the most prominent uses for metadata is in a supply chain. Supply chain involves parties such as factories, customers, suppliers, and delivery services. To enable efficient data tracking, participants must provide confirmation of services that are interlinked, and these must be accessible by everyone for verification. In this case, metadata can provide a complete picture of supply chain processes with fixed recorded data on the blockchain ledger. This grants transparency, immutability, and trust for all stakeholders. 

Một trong những ứng dụng nổi bật nhất cho siêu dữ liệu là trong chuỗi cung ứng.
Chuỗi cung ứng liên quan đến các bên như nhà máy, khách hàng, nhà cung cấp và dịch vụ giao hàng.
Để cho phép theo dõi dữ liệu hiệu quả, người tham gia phải cung cấp xác nhận các dịch vụ được liên kết với nhau và chúng phải được mọi người truy cập để xác minh.
Trong trường hợp này, siêu dữ liệu có thể cung cấp một bức tranh hoàn chỉnh về các quy trình chuỗi cung ứng với dữ liệu được ghi cố định trên sổ cái blockchain.
Điều này cung cấp tính minh bạch, bất biến và niềm tin cho tất cả các bên liên quan.

**The Atala products**

** Các sản phẩm Atala **

The deployment of metadata on Cardano will see early commercialization through the Atala product suite, which includes Atala Prism, Atala Trace, and Atala Scan solutions. To enhance the overall product functionality in terms of data feasibility, accountability, and traceability, the IOHK team is implementing metadata support while integrating with the Cardano ledger. 

Việc triển khai siêu dữ liệu trên Cardano sẽ chứng kiến sự thương mại hóa sớm thông qua bộ sản phẩm Atala, bao gồm Prism Atala, Atala Trace và Atala Scan Solutions.
Để tăng cường chức năng sản phẩm tổng thể về tính khả thi, trách nhiệm và tính truy xuất của dữ liệu, nhóm IOHK đang thực hiện hỗ trợ siêu dữ liệu trong khi tích hợp với sổ cái Cardano.

[Atala Prism](https://www.atalaprism.io/) is a decentralized identity system that enables people to own their personal data and interact with organizations seamlessly, privately, and securely. The Atala Prism team is integrating metadata to certify and store DIDs and DID documents on Cardano. Also, it will be possible not only to create but also to revoke credentials such as university certificates. 

.
Nhóm Atala Prism đang tích hợp siêu dữ liệu để chứng nhận và lưu trữ các tài liệu trên Cardano.
Ngoài ra, sẽ không chỉ có thể tạo mà còn thu hồi các thông tin đăng nhập như chứng chỉ đại học.

Atala Trace and Atala Scan are being developed to enable brand owners to improve the visibility over supply chain processes and establish product provenance and auditability. In these cases, metadata integration will be used to record tamper-proof supply-chain records. 

Atala Trace và Atala Scan đang được phát triển để cho phép chủ sở hữu thương hiệu cải thiện khả năng hiển thị đối với các quy trình chuỗi cung ứng và thiết lập nguồn gốc và khả năng kiểm toán sản phẩm.
Trong những trường hợp này, tích hợp siêu dữ liệu sẽ được sử dụng để ghi lại các hồ sơ chuỗi cung ứng chống giả mạo.

## **Working with metadata**

## ** Làm việc với siêu dữ liệu **

There are different ways of working with metadata both for enterprises and the developer community. One such way is using the metadata service developed by IOHKâ€™s Professional Services Group. We have been working with a number of partners on integrations and have many more in the pipeline. So if youâ€™re running a business and also wish to ensure trust for your customers and partners while managing your transaction metadata securely, please contact us via **enterprise.solutions@iohk.io** to find out how to incorporate metadata services in your processes. 

Có nhiều cách khác nhau để làm việc với siêu dữ liệu cho cả doanh nghiệp và cộng đồng nhà phát triển.
Một cách như vậy là sử dụng dịch vụ siêu dữ liệu được phát triển bởi Nhóm dịch vụ chuyên nghiệp của IOHK.
Chúng tôi đã làm việc với một số đối tác về tích hợp và có nhiều hơn nữa trong đường ống.
Vì vậy, nếu bạn đang điều hành một doanh nghiệp và cũng muốn đảm bảo niềm tin cho khách hàng và đối tác của bạn trong khi quản lý siêu dữ liệu giao dịch của bạn một cách an toàn, vui lòng liên hệ với chúng tôi qua
trong các quy trình của bạn.

*Transaction metadata is an important early feature of Goguen utility and smart contract functionality, which will be enhanced and developed by many other capabilities over the months ahead. Stay tuned to this blog for all the updates on native assets, ERC20 convertor, Marlowe, Plutus and other smart contract languages as we roll these out.*

*Siêu dữ liệu giao dịch là một tính năng ban đầu quan trọng của chức năng hợp đồng thông minh và tiện ích thông minh, sẽ được tăng cường và phát triển bởi nhiều khả năng khác trong những tháng tới.
Hãy theo dõi blog này cho tất cả các bản cập nhật về tài sản bản địa, Trình chuyển đổi ERC20, Marlowe, Plutus và các ngôn ngữ hợp đồng thông minh khác khi chúng tôi triển khai chúng.*

