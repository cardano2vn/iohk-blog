# Developer challenge: using blockchain to support the UN’s sustainable development goals
### **IOHK has set up a $10,000 fund to invest in ideas for sustainable development based on Cardano.**
![](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.002.png) 6 October 2020![](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.002.png)[ Eric Czuleger](tmp//en/blog/authors/eric-czuleger/page-1/)![](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.003.png) 3 mins read

![Eric Czuleger](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.004.png)[](tmp//en/blog/authors/eric-czuleger/page-1/)
### [**Eric Czuleger**](tmp//en/blog/authors/eric-czuleger/page-1/)
Senior Content Editor

Marketing & Communications

- ![](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.005.png)[](mailto:eric.czuleger@iohk.io "Email")
- ![](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.006.png)[](https://www.linkedin.com/in/eric-czuleger-6b67a395/ "LinkedIn")
- ![](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.007.png)[](https://twitter.com/eczuleger "Twitter")

![Developer challenge: using blockchain to support the UN’s sustainable development goals](img/2020-10-06-united-nations-and-iohk-join-forces-to-use-blockchain-for-development-goals.008.jpeg)

Creating a decentralized financial and social operating system for the world is the core mission of Cardano. But it’s not one that we can accomplish alone. That’s why we are always on the lookout for relationships which help us build a global foundation for growth. So, we’re thrilled to announce our hackathon challenge to support the UN’s sustainable development goals (SDGs) designed to accelerate progress on fighting hunger, injustice, and climate change.

Tạo ra một hệ điều hành tài chính và xã hội phi tập trung cho thế giới là sứ mệnh cốt lõi của Cardano.
Nhưng nó không phải là một thứ mà chúng ta có thể hoàn thành một mình.
Đó là lý do tại sao chúng ta luôn luôn tìm kiếm các mối quan hệ giúp chúng ta xây dựng nền tảng toàn cầu cho sự phát triển.
Vì vậy, chúng tôi rất vui mừng được thông báo thách thức hackathon của mình để hỗ trợ các mục tiêu phát triển bền vững (SDG) của Liên Hợp Quốc được thiết kế để tăng tốc tiến bộ trong việc chống đói, bất công và biến đổi khí hậu.

## **Sustainability and blockchain**

## ** Tính bền vững và blockchain **

In this hackathon challenge we aim to give the blockchain community an opportunity to make an impact on international development. The challenge will draw on IOHK’s expertise in community-focused funding developed with Project Catalyst. This initiative brings innovation, voting, and decentralized funding to Cardano by crowdsourcing development proposals, and financing their implementation.

Trong thử thách hackathon này, chúng tôi mong muốn cung cấp cho cộng đồng blockchain một cơ hội để tạo ra ảnh hưởng đến sự phát triển quốc tế.
Thách thức sẽ dựa trên chuyên môn của IOHK, trong tài trợ tập trung vào cộng đồng được phát triển với Project Catalyst.
Sáng kiến này mang lại sự đổi mới, bỏ phiếu và tài trợ phi tập trung cho Cardano bằng cách cung cấp các đề xuất phát triển đám đông và tài trợ cho việc thực hiện của họ.

IOHK and United Nations personnel will use the Project Catalyst platform to find and fund initiatives that align with the UN’s Sustainable Development Goals. These goals were adopted by 193 world leaders in 2015. Each of the 17 targets focus on ending extreme poverty and hunger, fighting inequality and injustice, and tackling climate change by 2030.

Nhân viên IOHK và Liên Hợp Quốc sẽ sử dụng nền tảng Project Catalyst để tìm và tài trợ cho các sáng kiến phù hợp với các mục tiêu phát triển bền vững của Liên Hợp Quốc.
Những mục tiêu này đã được thông qua bởi 193 nhà lãnh đạo thế giới vào năm 2015. Mỗi mục tiêu trong số 17 mục tiêu tập trung vào việc chấm dứt nghèo đói và đói khát cực đoan, chống lại sự bất bình đẳng và bất công, và giải quyết biến đổi khí hậu vào năm 2030.

This IOHK-sponsored challenge hopes to promote projects based in the digitization of finance which increase the efficacy and transparency of funding for the UN’s Decade of Action. In the run-up to the 2030 deadline for achieving the global sustainability goals, the UN is marking 75 years since its establishment. Given that the transnational organization works on global collective action problems it has engaged with blockchain technology as a solution.

Thách thức do IOHK tài trợ này hy vọng sẽ thúc đẩy các dự án dựa trên việc số hóa tài chính làm tăng hiệu quả và tính minh bạch của tài trợ cho thập kỷ hành động của Liên Hợp Quốc.
Trong thời hạn đến hạn chót năm 2030 để đạt được các mục tiêu bền vững toàn cầu, Liên Hợp Quốc đang đánh dấu 75 năm kể từ khi thành lập.
Cho rằng tổ chức xuyên quốc gia hoạt động trên các vấn đề hành động tập thể toàn cầu mà nó đã tham gia vào công nghệ blockchain như một giải pháp.

## **Crowdsourcing the future**

## ** Đám đông tương lai **

Participants in the program can put forward ideas focused on any of the 17 goals. To encourage participation, IOHK is sponsoring a prize fund of ada worth $10,000 as well as ongoing support to bring the projects to fruition. Proposals will be judged by a panel of IOHK and UN employees. They will determine the winners based on an idea’s technical prowess, scalability and social impact, as well as its financial and volunteer support. The winning ideas will be able to seek the advice of experts from both the UN and IOHK to ensure that they are implemented in the most impactful way.

Những người tham gia chương trình có thể đưa ra các ý tưởng tập trung vào bất kỳ mục tiêu nào trong số 17 mục tiêu.
Để khuyến khích sự tham gia, IOHK đang tài trợ cho một quỹ giải thưởng của ADA trị giá 10.000 đô la cũng như hỗ trợ liên tục để đưa các dự án trở thành hiện thực.
Các đề xuất sẽ được đánh giá bởi một hội đồng nhân viên IOHK và Liên Hợp Quốc.
Họ sẽ xác định những người chiến thắng dựa trên năng lực kỹ thuật, khả năng mở rộng và tác động xã hội của ý tưởng, cũng như hỗ trợ tài chính và tình nguyện của nó.
Các ý tưởng chiến thắng sẽ có thể tìm kiếm lời khuyên của các chuyên gia từ cả Liên Hợp Quốc và IOHK để đảm bảo rằng chúng được thực hiện theo cách có tác động nhất.

To qualify for the scheme, entries must be open source and be created for use on the Cardano blockchain. Example code should be written in Marlowe, a domain specific language developed for financial contracts on Cardano. These do not need to be fully coded submissions. Instead they can be ideas which inspire anyone to get involved with blockchain technology and sustainable development. The proposal submission period opens on Saturday October 10th. Participants must be registered by then in order to submit. Entries must be finalized by October 18 at 11:59 MDT. Make sure to check the [official rules](https://static.iohk.io/docs/IOHK_UN_challenge.pdf) to learn more.

Để đủ điều kiện tham gia chương trình, các mục nhập phải được mở và được tạo để sử dụng trên blockchain Cardano.
Mã ví dụ nên được viết bằng Marlowe, một ngôn ngữ cụ thể về miền được phát triển cho các hợp đồng tài chính trên Cardano.
Chúng không cần phải được gửi đầy đủ các bài nộp.
Thay vào đó, chúng có thể là những ý tưởng truyền cảm hứng cho bất cứ ai tham gia vào công nghệ blockchain và phát triển bền vững.
Thời gian gửi đề xuất mở vào thứ Bảy ngày 10 tháng 10.
Người tham gia phải được đăng ký sau đó để nộp.
Các mục phải được hoàn thành trước ngày 18 tháng 10 lúc 11:59 MDT.
Hãy chắc chắn kiểm tra [Quy tắc chính thức] (https://static.iohk.io/docs/iohk_un_challenge.pdf) để tìm hiểu thêm.

Winners will be announced on October 24, United Nations Day, which marks the anniversary of the charter of the organization. We encourage everyone with an interest in using Cardano to achieve sustainability goals to get involved. Make your voice heard to help the UN’s [Decade of Action](https://www.un.org/sustainabledevelopment/decade-of-action/) now. If you are interested more generally in developing Cardano, join Project Catalyst on [Ideascale](https://cardano.ideascale.com/).

Người chiến thắng sẽ được công bố vào ngày 24 tháng 10, Ngày Liên Hợp Quốc, đánh dấu ngày kỷ niệm của Hiến chương của tổ chức.
Chúng tôi khuyến khích tất cả mọi người quan tâm đến việc sử dụng Cardano để đạt được các mục tiêu bền vững để tham gia.
Làm cho giọng nói của bạn được nghe để giúp UN UN [thập kỷ hành động] (https://www.un.org/selfainabledevelopment/decade-of-action/) ngay bây giờ.
Nếu bạn quan tâm chung hơn trong việc phát triển Cardano, hãy tham gia Project Catalyst trên [IdeasCale] (https://cardano.ideascale.com/).

